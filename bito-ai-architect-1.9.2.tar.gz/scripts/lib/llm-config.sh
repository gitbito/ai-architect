#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
#
# LLM Configuration Functions
# Shared functions for configuring LLM providers. Provider-specific details
# (prompts, env keys, validation, payload shape) live in the data-driven
# registry (llm-registry.sh); the functions here are generic loops over it.

# Source the provider metadata registry (idempotent via its own load guard).
source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/llm-registry.sh"

# No-op fallback so log_silent is safe to call when sourced standalone (e.g. tests).
command -v log_silent >/dev/null 2>&1 || log_silent() { :; }

# Global array to track configured providers
CONFIGURED_PROVIDERS=()

# Function: _llm_prompt_fields
# Prompts every prompt-able field of a provider in registry order, applying the
# field's pre_process hook (validate + convert) before persisting to ENV_LLM_FILE.
# -------------------------------------------------------------------
_llm_prompt_fields() {
    local id="$1" env kind required config pre post prompt raw row label
    # Collect the field rows first, THEN prompt. The prompts must read user input
    # from the terminal (stdin); iterating the field stream via a redirected loop
    # would both steal stdin and — on bash 3.2 — break `read -s` echo-suppression
    # for secret fields. Reading rows into an array up front keeps stdin clean.
    local rows=()
    while IFS= read -r row; do
        rows+=("$row")
    done < <(_llm_fields_tsv "$id")

    for row in "${rows[@]}"; do
        IFS=$'\x1f' read -r env kind required config pre post prompt <<< "$row"
        [ -z "$prompt" ] && continue                      # field carries no prompt -> never prompted
        # Prompt is base64 in the TSV so multi-line guidance survives the one-line
        # record. A non-empty field that decodes to nothing is a real failure (corrupt
        # registry / base64 mismatch), not a skip — surface it rather than silently
        # dropping the field (and later claiming the provider was configured).
        prompt=$(printf '%s' "$prompt" | base64 -d 2>/dev/null)
        if [ -z "$prompt" ]; then
            echo -e "${RED:-}⚠ Could not decode the prompt for field '${env}'.${NC:-}" >&2
            return 1
        fi
        # Split at the last newline: earlier lines print as guidance, the last is the label.
        label="$prompt"
        if [[ "$prompt" == *$'\n'* ]]; then
            printf '%s\n' "${prompt%$'\n'*}"
            label="${prompt##*$'\n'}"
        fi

        while true; do
            if [ "$kind" = "secret" ]; then
                read -s -r -p "$label " raw
                # Best-effort re-enable echo; never fatal (stty fails on a non-tty
                # stdin, which would otherwise trip the caller's ERR-trap rollback).
                stty echo 2>/dev/null || true
                echo ""
            else
                read -r -p "$label " raw
            fi

            if [ -n "$pre" ]; then
                raw=$("$pre" "$raw") || { echo -e "${RED:-}⚠ Invalid value. Please try again.${NC:-}"; continue; }
            fi
            if [ "$required" = "true" ] && [ -z "$raw" ]; then
                echo "Value cannot be empty."
                continue
            fi
            break
        done

        set_env_key_value "$env" "$raw" "$ENV_LLM_FILE"
    done
}

# LocalOpenAI reachability + auth gate. Probes the OpenAI list-models endpoint
# (<base_url>/models) — unlike an unauthenticated /health it also exercises the
# token, so a missing/wrong key fails here (401) not silently at inference time.
# Sends a Bearer only when a token is set. `curl` is stubbed in the unit suites.
_localopenai_health_check() {
    local url token connect_to="" probe resp rc code body
    url=$(grep "^LOCALOPENAI_BASE_URL=" "$ENV_LLM_FILE" 2>/dev/null | head -1 | cut -d= -f2-)
    token=$(grep "^LOCALOPENAI_API_KEY=" "$ENV_LLM_FILE" 2>/dev/null | head -1 | cut -d= -f2-)
    [ -z "$url" ] && return 1
    # base_url already carries the /v1 root, so the models endpoint is <base_url>/models.
    probe="${url%/}/models"
    # The host-access alias ai-architect-local only resolves inside containers
    # (docker-compose.yml maps it via host-gateway). From the operator's shell the
    # same server is the local machine, so pin the name to loopback for the probe;
    # any-port form keeps the URL's port.
    case "$url" in
        *"://ai-architect-local"*) connect_to="--connect-to ai-architect-local::127.0.0.1:" ;;
    esac
    # No -f, and -w the HTTP code as a trailing line, so we can log the response and
    # tell apart 401 (bad token) / 404 (wrong URL) / 000 (unreachable). Token not logged.
    # shellcheck disable=SC2086  # connect_to is a fixed flag, intentionally split
    if [ -n "$token" ]; then
        resp=$(curl -sS --max-time 5 $connect_to -H "Authorization: Bearer ${token}" -w $'\n%{http_code}' "$probe" 2>&1); rc=$?
    else
        resp=$(curl -sS --max-time 5 $connect_to -w $'\n%{http_code}' "$probe" 2>&1); rc=$?
    fi
    code="${resp##*$'\n'}"          # trailing line = HTTP status
    body="${resp%$'\n'*}"           # everything before = body
    LOCALOPENAI_LAST_HTTP="$code"
    log_silent "localopenai reachability: GET ${probe} -> HTTP ${code:-<none>}${token:+ (with token)}; response: $(printf '%s' "$body" | tr '\n\r' '  ' | cut -c1-500)"
    case "$code" in
        2*)          return 0 ;;
        ''|*[!0-9]*) return "$rc" ;;  # no parseable code (stub/edge) -> trust curl's exit
        *)           return 1 ;;
    esac
}

# LocalOpenAI post-configure hook (registry `post_configure`, dispatched by
# configure_llm). Verifies reachability; on failure the operator re-enters or saves
# anyway, so an unreachable server never traps the flow. $1 is the provider id.
_localopenai_configure_check() {
    local id="$1" action url
    while true; do
        url=$(grep "^LOCALOPENAI_BASE_URL=" "$ENV_LLM_FILE" 2>/dev/null | head -1 | cut -d= -f2-)
        echo "⏳ Verifying connection to ${url} ..."
        if _localopenai_health_check; then
            echo -e "${GREEN:-}✓  Server reachable${NC:-}"
            return 0
        fi
        echo -e "${RED:-}✗  Server did not accept the request (HTTP ${LOCALOPENAI_LAST_HTTP:-?}) — check the URL and, if it needs one, the API token. Full response is in the setup log.${NC:-}"
        read -r -p "  [r] re-enter details (default)   [s] save anyway (skip check): " action
        if [[ "$action" =~ ^[Ss] ]]; then
            print_warning " Saved without a successful reachability check — ensure the URL is reachable from the deployment"
            return 0
        fi
        _llm_prompt_fields "$id"
    done
}

# Function: configure_llm
# Interactive LLM provider configuration (menu + fields driven by the registry).
# -------------------------------------------------------------------
configure_llm() {

    CONFIGURED_PROVIDERS=()
    local continue_config="y"
    local total
    total=$(_llm_total_providers)

    while [[ "$continue_config" =~ ^[Yy]$ ]]; do

        # Auto-stop if every provider is configured
        if [[ ${#CONFIGURED_PROVIDERS[@]} -eq $total ]]; then
            echo -e "${GREEN:-}💡 All LLM providers have been configured.${NC:-}"
            break
        fi

        local provider_choice provider_name
        echo ""
        read -r -p "$(_llm_menu_string)" provider_choice

        provider_name=$(_llm_id_for_menu "$provider_choice")
        if [ -z "$provider_name" ]; then
            echo "✗ Invalid option. Please select 1–${total}."
            continue
        fi

        # Friendly label for user-facing messages; provider_name (id) drives all logic.
        local provider_label
        provider_label=$(_llm_label "$provider_name")

        # Skip duplicates
        if [[ " ${CONFIGURED_PROVIDERS[*]} " =~ " ${provider_name} " ]]; then
            echo -e "${YELLOW:-}⚠ $provider_label is already configured.${NC:-}"
        else
            echo -e "\n${BLUE:-}=== Configuring ${provider_label} ===${NC:-}\n"
            # Optional provider intro (registry `description`), then the field prompts.
            local provider_desc
            provider_desc=$(_llm_description "$provider_name")
            [ -n "$provider_desc" ] && { echo "$provider_desc"; echo ""; }
            if ! _llm_prompt_fields "$provider_name"; then
                echo -e "${RED:-}✗ Could not configure ${provider_label}; skipping.${NC:-}"
                continue
            fi
            # Optional post-configure hook (registry `post_configure`), dispatched by
            # name like pre_process/post_process — e.g. localopenai's reachability check.
            local post_hook
            post_hook=$(_llm_post_configure "$provider_name")
            if [ -n "$post_hook" ] && declare -F "$post_hook" >/dev/null 2>&1; then
                "$post_hook" "$provider_name"
            fi
            CONFIGURED_PROVIDERS+=("$provider_name")
            print_status " ${provider_label} configured successfully"
        fi

        # Exclusive gateway (e.g. Portkey) owns the configuration: stop asking.
        if [ "$(_llm_is_exclusive "$provider_name")" = "true" ]; then
            continue_config="n"
        elif [[ ${#CONFIGURED_PROVIDERS[@]} -lt $total ]]; then
            read -r -p "Do you also want to add an API token for another LLM? (y/N): " continue_config
        else
            continue_config="n"
        fi
    done

    _restrict_llm_env_file
    return 0
}

# Function: _restrict_llm_env_file
# Restricts the LLM env file to the owner (0600). It holds provider API keys and
# the AWS secret access key, but set_env_key_value creates it at the default
# umask (typically 0644) and in-place rewrites keep an existing file's mode, so
# this is also what tightens a file left 0644 by an older install. No-op when
# the file does not exist; never fails the caller.
# -------------------------------------------------------------------
_restrict_llm_env_file() {
    if [ -f "$ENV_LLM_FILE" ]; then
        chmod 600 "$ENV_LLM_FILE" 2>/dev/null || true
    fi
}

# Function: reset_all_llm_keys
# Clears every registry-defined LLM key (plus the default-provider marker) so a
# re-run starts from a clean slate.
# -------------------------------------------------------------------
reset_all_llm_keys() {
    local k
    while IFS= read -r k; do
        set_env_key_value "$k" "" "$ENV_LLM_FILE"
    done < <(_llm_all_env_keys)
    set_env_key_value "LLM_DEFAULT_PROVIDER" "" "$ENV_LLM_FILE"
}

# Returns 0 when any provider's detect_env_keys are ALL pre-exported (yaml-driven
# install bypass). Bedrock needs its full triple because AWS_ACCESS_KEY_ID /
# AWS_SECRET_ACCESS_KEY are ambient on AWS-tooled hosts and alone must not bypass
# the interactive prompt.
_llm_tokens_preset() {
    local id k all_set
    while IFS= read -r id; do
        all_set=1
        while IFS= read -r k; do
            [ -z "${!k:-}" ] && { all_set=0; break; }
        done < <(_llm_detect_keys "$id")
        [ "$all_set" -eq 1 ] && return 0
    done < <(llm_registry | jq -r '.providers[].id')
    return 1
}

# Persists every present field of a provider to ENV_LLM_FILE. Returns 0
# explicitly: the loop's last field can be an empty optional one (e.g.
# VERTEX_MODEL on vertex-ai), which leaves the final `[ -n … ] && …` at exit
# status 1; under the installer's set -e / ERR trap that would abort setup.
_llm_persist_present_fields() {
    local id="$1" env
    while IFS= read -r env; do
        if [ -n "${!env:-}" ]; then
            set_env_key_value "$env" "${!env}" "$ENV_LLM_FILE"
        fi
    done < <(llm_registry | jq -r --arg id "$id" '.providers[] | select(.id==$id) | .fields[].env')
    return 0
}

# Run a provider's optional `preset_check` advisory (registry) on the preset/yaml
# path. The value is already persisted, so a failed probe only warns.
_llm_run_preset_check() {
    local id="$1" fn
    fn=$(_llm_preset_check "$id")
    if [ -n "$fn" ] && declare -F "$fn" >/dev/null 2>&1; then
        "$fn" || print_warning " ${id}: server did not answer a reachability check — ensure the URL is reachable from the deployment"
    fi
}

# Writes pre-exported LLM tokens to ENV_LLM_FILE and populates CONFIGURED_PROVIDERS
# so default-provider resolution still works. Clears all keys first so stale values
# from a previous install do not linger.
_llm_persist_preset_tokens() {
    CONFIGURED_PROVIDERS=()
    reset_all_llm_keys

    local id primary env missing invalid newval
    local kind required config pre post prompt

    # Exclusive gateway wins outright: when its primary token is preset it owns
    # the configuration and direct providers are ignored.
    while IFS= read -r id; do
        primary=$(_llm_primary "$id")
        if [ -n "${!primary:-}" ]; then
            _llm_persist_present_fields "$id"
            CONFIGURED_PROVIDERS+=("$id")
            _restrict_llm_env_file
            return 0
        fi
    done < <(llm_registry | jq -r '.providers[] | select(.exclusive==true) | .id')

    # Direct providers: persist only when all required fields are present; a
    # partial set is warned and dropped (it would otherwise be silently skipped
    # from the cis-config PUT).
    while IFS= read -r id; do
        primary=$(_llm_primary "$id")
        [ -z "${!primary:-}" ] && continue
        missing=0
        while IFS= read -r env; do
            [ -z "${!env:-}" ] && missing=1
        done < <(_llm_required_envs "$id")
        if [ "$missing" -ne 0 ]; then
            print_warning "${id} not configured: one or more required fields are missing"
            continue
        fi
        # Validate+convert preset values via each field's pre_process (the same
        # hook the interactive path runs), e.g. resolve a Vertex SA file path to
        # base64. A rejected value warns and drops the whole provider.
        invalid=0
        while IFS=$'\x1f' read -r env kind required config pre post prompt; do
            [ -n "$pre" ] || continue
            [ -n "${!env:-}" ] || continue
            newval=$("$pre" "${!env}") || { invalid=1; break; }
            printf -v "$env" '%s' "$newval"
        done < <(_llm_fields_tsv "$id")
        if [ "$invalid" -ne 0 ]; then
            print_warning "${id} not configured: one or more field values are invalid"
            continue
        fi
        _llm_persist_present_fields "$id"
        CONFIGURED_PROVIDERS+=("$id")
        _llm_run_preset_check "$id"
    done < <(llm_registry | jq -r '.providers[] | select(.exclusive!=true) | .id')

    _restrict_llm_env_file
}

# Function: configure_llm_provider
# Main entry point for LLM provider configuration.
# Pass "force_interactive" to bypass preset-token detection (e.g. when called
# from `bitoarch update-llm-config` where load_env_config has already exported
# the existing tokens into the caller's shell).
# -------------------------------------------------------------------
configure_llm_provider() {
    local mode="${1:-}"

    if [ "$mode" = "force_interactive" ]; then
        reset_all_llm_keys
        configure_llm
    elif _llm_tokens_preset; then
        # Yaml-driven install: persist pre-exported tokens, skip prompt.
        _llm_persist_preset_tokens
    else
        reset_all_llm_keys
        configure_llm
    fi

    # Pick the default provider by rank (registry order), falling back to bito.
    local options=("${CONFIGURED_PROVIDERS[@]}" "bito")
    local selected_provider="" preferred p
    while IFS= read -r preferred; do
        for p in "${options[@]}"; do
            if [[ "$p" == "$preferred" ]]; then
                selected_provider="$preferred"
                break 2
            fi
        done
    done < <(_llm_ids_by_rank; echo "bito")
    set_env_key_value "LLM_DEFAULT_PROVIDER" "${selected_provider}" "$ENV_LLM_FILE"

    # Send LLM provider tracking event (suppress output to prevent HTTP status leakage)
    if [[ ${#CONFIGURED_PROVIDERS[@]} -gt 0 ]]; then
        local providers_csv=$(IFS=,; echo "${CONFIGURED_PROVIDERS[*]}")
        send_llm_provider_tracking "$providers_csv" >/dev/null 2>&1
    fi

    # Guarantee the secrets file is owner-only after the final write above, so
    # the postcondition holds at the entry point regardless of how the sub-paths
    # or set_env_key_value touch the mode.
    _restrict_llm_env_file
}

# Export functions
export -f _llm_tokens_preset
export -f _llm_persist_present_fields
export -f _restrict_llm_env_file
export -f _llm_persist_preset_tokens
export -f _llm_run_preset_check
export -f _llm_prompt_fields
export -f _localopenai_health_check
export -f configure_llm
export -f reset_all_llm_keys
export -f configure_llm_provider
