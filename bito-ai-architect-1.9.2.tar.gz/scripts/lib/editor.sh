#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
#
# scripts/lib/editor.sh
# Shared editor helper: resolve $EDITOR, warn on Windows editors, back up, open,
# and normalize BOM/CRLF after save. Resolution + backup + normalization ONLY --
# no schema validation (callers own that), so the same path serves both
# `bitoarch config edit` (repos.yaml, strict schema) and the install-time editor
# (install.yaml, no schema) without cross-wiring their rules.

if [ -n "${_BITOARCH_EDITOR_LOADED:-}" ]; then
    return 0
fi
_BITOARCH_EDITOR_LOADED=1

# log_silent fallback so this lib is safe to source standalone (e.g. tests, or
# the install path before output-blocks.sh defines the real one).
if ! command -v log_silent >/dev/null 2>&1; then log_silent() { :; }; fi

# Set by open_editor_with_normalization to the pre-edit backup path (empty when
# no backup was taken). Callers that roll back on validation failure read this.
EDITOR_PRE_EDIT_BACKUP=""

# Rewrite a file in place by piping it through a filter command. Uses an atomic
# temp-file + mv so a half-written rewrite can't truncate the source. Falls back
# to a sibling path if mktemp is unavailable.
# (Moved here from bitoarch.sh so config-edit and the install path share one
# copy -- single source of the normalization primitive, no drift.)
# Usage: _rewrite_in_place <file> <cmd...>
_rewrite_in_place() {
    local file="$1"; shift
    [ -f "$file" ] || return 1
    local tmp
    tmp="$(mktemp 2>/dev/null)" || tmp="${file}.norm.$$"
    if "$@" < "$file" > "$tmp"; then
        mv "$tmp" "$file"
    else
        local _rc=$?
        rm -f "$tmp" 2>/dev/null
        return $_rc
    fi
}

# Strip a leading UTF-8 BOM and convert CRLF -> LF, in place. BOM/CRLF ONLY --
# this never rewrites or strips YAML comments or any other content. Safe no-op
# when neither is present. Windows editors under WSL inject both and break YAML
# parsing (BITO-13283); this undoes exactly that and nothing else.
# Usage: normalize_bom_crlf <file>
normalize_bom_crlf() {
    local file="$1"
    [ -f "$file" ] || return 0
    # UTF-8 BOM = EF BB BF on the first three bytes.
    if head -c 3 "$file" 2>/dev/null | od -An -tx1 2>/dev/null | tr -d ' ' | grep -q '^efbbbf'; then
        _rewrite_in_place "$file" tail -c +4 \
            && log_silent "editor: stripped UTF-8 BOM from $file"
    fi
    # Portable CRLF detection: -lU is GNU-grep-only and silently no-ops on
    # BSD/Alpine grep, which is the primary code path for this fix on WSL.
    if LC_ALL=C grep -q $'\r' "$file" 2>/dev/null; then
        _rewrite_in_place "$file" tr -d '\r' \
            && log_silent "editor: converted CRLF -> LF in $file"
    fi
}

# Resolve the editor, warn on Windows-style editors, take a pre-edit backup,
# open <file>, then normalize BOM/CRLF. Sets EDITOR_PRE_EDIT_BACKUP. Returns the
# editor's exit code (non-zero short-circuits before normalization).
# Usage: open_editor_with_normalization <file> [backup_category]
open_editor_with_normalization() {
    local file="$1"
    local backup_category="${2:-config}"
    local editor="${VISUAL:-${EDITOR:-vi}}"

    EDITOR_PRE_EDIT_BACKUP=""

    # Warn (once, briefly) if the editor looks like a Windows binary -- these
    # inject BOM/CRLF that break YAML parsing (BITO-13283); we normalize after
    # save anyway. Match on basename (so /home/u/notepad-clone/vim does NOT
    # trip) plus WSL/Windows path shapes.
    local _editor_base _editor_is_windows=0
    _editor_base="$(basename -- "$editor")"
    case "$_editor_base" in
        *.exe|notepad*) _editor_is_windows=1 ;;
    esac
    case "$editor" in
        /mnt/c/*|*\\*) _editor_is_windows=1 ;;
    esac
    if [ "$_editor_is_windows" -eq 1 ]; then
        if command -v print_warning >/dev/null 2>&1; then
            print_warning "EDITOR='$editor' may inject BOM/CRLF; will normalize after save."
        fi
        log_silent "editor: detected Windows-style editor '$editor' for $file"
    fi

    # Pre-edit backup (silent -- path goes to the log only). A verbatim copy via
    # backup_config_file; comments and formatting are preserved. Best-effort: a
    # no-op when backup_config_file isn't sourced (e.g. the install path, where
    # the file is freshly seeded from the template and operator-owned anyway).
    if [ -f "$file" ] && command -v backup_config_file >/dev/null 2>&1; then
        EDITOR_PRE_EDIT_BACKUP=$(backup_config_file "$file" "$backup_category" 2>/dev/null) || EDITOR_PRE_EDIT_BACKUP=""
        [ -n "$EDITOR_PRE_EDIT_BACKUP" ] && log_silent "editor: pre-edit backup -> $EDITOR_PRE_EDIT_BACKUP"
    fi

    "$editor" "$file"
    local editor_rc=$?
    if [ "$editor_rc" -ne 0 ]; then
        log_silent "editor: '$editor' exited rc=$editor_rc on $file"
        return "$editor_rc"
    fi

    # Post-edit normalization: BOM + CRLF only (never touches comments/content).
    [ -f "$file" ] && normalize_bom_crlf "$file"
    return 0
}
