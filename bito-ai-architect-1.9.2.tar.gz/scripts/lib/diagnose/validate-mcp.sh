#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
# Diagnose / validate-mcp: deterministic MCP tool validation (curl + jq only).
#
# Exercises the running provider (cis-provider / ai-architect-provider) at
# ${PROVIDER_URL}/mcp. listRepositories is the ANCHOR; repo-specific checks
# chain off its output (no hardcoded repo/cluster names). 0 repos is NOT a
# failure -- the index may not be built yet right after a deploy.
#
# Surfaces in two places, sharing one engine (_vmcp_run_checks):
#   - live sweep   -> mcp_validate_live:      compact 1-line PASS/WARN/FAIL
#                     summary in the Connectivity section (UI-facing). Uses a
#                     tighter per-call timeout + an overall wall-clock budget so
#                     the always-on `diagnose` can't stall on a half-hung server.
#   - --bundle     -> collect_mcp_validation: full per-call request/response
#                     debug trace written to mcp-validation.txt (generous
#                     timeout, no budget).
#
# Severity model (consistent across tiers):
#   - tool ERROR on a valid call (non-200 or isError) => FAIL  -- a real
#     malfunction; a fully-broken metadata API therefore yields exit 2.
#   - response with an UNRECOGNIZED shape (none of the expected keys, yet valid
#     JSON) => WARN "unexpected response shape" -- guards against silent
#     "always green" if the server renames a field.
#   - response with a recognized shape but EMPTY content (0 results / unset
#     field / 0 clusters) => informational PASS -- content depends on the
#     customer's index, not on whether the tool works.
#   - 0 indexed repos => WARN (index not ready); negative-path tiers PASS when
#     the server responds gracefully (any HTTP code) rather than hanging.
#
# All network I/O funnels through _vmcp_http_post so tests stub one seam.
# _vmcp_call is invoked directly (never inside $(...)) so the globals it sets
# (_VMCP_INNER / _VMCP_LAST_HTTP / _RAW / _TIME) survive into the caller.

if [ -n "${_DIAGNOSE_VALIDATE_MCP_LOADED:-}" ]; then
    return 0
fi
_DIAGNOSE_VALIDATE_MCP_LOADED=1

# Well-known universal schema field used for getFieldPath / cross-repo checks.
_VMCP_KNOWN_FIELD="project_overview"

# ─── Run state (reset per run by _vmcp_reset) ───────────────────────────────
_vmcp_reset() {
    _VMCP_ID=0
    _VMCP_OUT=""                 # bundle detail file, or "" for live
    _VMCP_DEADLINE=""            # epoch deadline (live budget); "" = no budget
    _VMCP_ADVERTISED=""          # " name1 name2 ... " (space-padded)
    _VMCP_RESULTS=()             # "STATUS|id|msg"
    _VMCP_INNER=""               # inner result text of the last _vmcp_call
    _VMCP_LAST_HTTP=""
    _VMCP_LAST_TIME=""
    _VMCP_LAST_RAW=""
    _VMCP_INDEX_EMPTY=0
    _VMCP_NTOOLS=0
    _VMCP_NREPOS=0
    _VMCP_NCLUSTERS=0
    _VMCP_REPO_A=""              # anchor repo (first from listRepositories)
    _VMCP_REPO_LIST=" "          # space-padded set of page-1 repo names
    _VMCP_SEARCH_REPO_A=""       # top searchRepositories result
    _VMCP_CLUSTER_FIRST=""
    _VMCP_CLUSTER_LAST=""
    _VMCP_CODE_REPO=""           # searchCode hit, fed into getCode
    _VMCP_CODE_FILE=""
    _VMCP_CODE_LINE=""
}

# Build a tools/call "arguments" object: required purpose params + optional
# extra JSON fields (no leading comma). Example: _vmcp_args '"pageSize":10'
_vmcp_args() {
    local extra="${1:-}"
    printf '{"purposeType":"codebase_understanding","purpose":"bitoarch diagnose MCP validation","callerPlatform":"%s"%s}' \
        "${MCP_CALLER_PLATFORM:-BITOARCH_CLI}" "${extra:+,${extra}}"
}

# The ONLY function that performs network I/O. Echoes "<body>\n<http_code> <time>".
# Tests override this to return fixtures.
_vmcp_http_post() {
    local url="$1" token="$2" body="$3"
    local tls=""
    case "$url" in https://*) tls="-k" ;; esac
    curl -s -w '\n%{http_code} %{time_total}' --max-time "${VMCP_HTTP_TIMEOUT:-20}" $tls \
        -X POST "${url}/mcp" \
        -H "Authorization: Bearer ${token}" \
        -H "Content-Type: application/json" \
        -d "$body" 2>&1
}

# Low-level tools/call. Args: <tool> <arguments-json>. MUST be called directly
# (not in $(...)) so its globals persist. Sets _VMCP_INNER (inner result text),
# _VMCP_LAST_HTTP / _VMCP_LAST_TIME / _VMCP_LAST_RAW. Returns: 0 ok, 1
# transport/non-200, 3 isError. Assumes jq is present (entry points guard it).
_vmcp_call() {
    local tool="$1" args="$2"
    _VMCP_ID=$((_VMCP_ID + 1))
    local body resp _last
    body=$(printf '{"jsonrpc":"2.0","method":"tools/call","id":%d,"params":{"name":"%s","arguments":%s}}' \
        "$_VMCP_ID" "$tool" "$args")
    resp=$(_vmcp_http_post "$_VMCP_URL" "$_VMCP_TOKEN" "$body")
    _VMCP_LAST_RAW=$(printf '%s' "$resp" | sed '$d')
    _last=$(printf '%s' "$resp" | tail -1)
    _VMCP_LAST_HTTP="${_last%% *}"
    _VMCP_LAST_TIME=""; case "$_last" in *" "*) _VMCP_LAST_TIME="${_last#* }" ;; esac
    _vmcp_trace "tools/call ${tool}" "$body"

    _VMCP_INNER=""
    [ "$_VMCP_LAST_HTTP" = "200" ] || return 1
    if [ "$(printf '%s' "$_VMCP_LAST_RAW" | jq -r '.result.isError // false' 2>/dev/null)" = "true" ]; then
        return 3
    fi
    _VMCP_INNER=$(printf '%s' "$_VMCP_LAST_RAW" | jq -r '.result.content[0].text // empty' 2>/dev/null)
    return 0
}

# True when the last call got a real HTTP response (server handled it, even with
# an error/empty body) rather than hanging / dropping. Used by negative paths.
_vmcp_responded() {
    case "$_VMCP_LAST_HTTP" in
        200|4[0-9][0-9]) return 0 ;;   # handled, incl. structured 4xx rejects
        *) return 1 ;;                 # 000 timeout / 5xx / empty = crash/hang
    esac
}

# Recognized-shape check on _VMCP_INNER. Arg: a jq boolean expression over the
# parsed inner JSON (e.g. 'has("repositories")'). Returns 0 (recognized) when
# the inner text is NOT valid JSON (benefit of the doubt -- likely a large
# response truncated by the server's size guard, not shape drift), or when it
# is valid JSON and the expression is true. Returns 1 only for valid JSON that
# lacks the expected keys -- the genuine "shape drift" case (-> WARN).
_vmcp_recognized() {
    printf '%s' "$_VMCP_INNER" | jq -e . >/dev/null 2>&1 || return 0
    printf '%s' "$_VMCP_INNER" | jq -e "$1" >/dev/null 2>&1
}

# Over the live wall-clock budget? Only active when _VMCP_DEADLINE is set.
_vmcp_over_budget() {
    [ -n "${_VMCP_DEADLINE:-}" ] || return 1
    [ "$(date +%s 2>/dev/null || echo 0)" -gt "$_VMCP_DEADLINE" ] 2>/dev/null
}

# Record one check outcome. Args: <PASS|WARN|FAIL|SKIP> <id> <msg>.
_vmcp_record() {
    local st="$1" id="$2" msg="$3"
    _VMCP_RESULTS+=("${st}|${id}|${msg}")
    if [ -n "$_VMCP_OUT" ]; then
        printf '  [%s] %-4s %s\n' "$id" "$st" "$msg" | redact_stream >> "$_VMCP_OUT"
    fi
}

# Bundle-only: append a full request/response trace for one MCP call so a
# developer can debug exactly what was sent and received. No-op in live mode
# (_VMCP_OUT empty). Redacted; each response capped at VMCP_TRACE_MAX bytes.
_vmcp_trace() {
    [ -n "$_VMCP_OUT" ] || return 0
    local label="$1" req="$2" cap="${VMCP_TRACE_MAX:-10000}" inner iserr len
    {
        echo ""
        echo "  ▸ ${label}"
        echo "    REQUEST:"
        printf '%s\n' "$req" | { jq . 2>/dev/null || cat; } | sed 's/^/      /'
        echo "    RESPONSE: HTTP ${_VMCP_LAST_HTTP:-?}${_VMCP_LAST_TIME:+  time=${_VMCP_LAST_TIME}s}"
        if command -v jq >/dev/null 2>&1; then
            iserr=$(printf '%s' "$_VMCP_LAST_RAW" | jq -r '.result.isError // empty' 2>/dev/null)
            [ -n "$iserr" ] && echo "      isError: ${iserr}"
            inner=$(printf '%s' "$_VMCP_LAST_RAW" | jq -r '.result.content[0].text // empty' 2>/dev/null)
            if [ -n "$inner" ]; then
                len=$(printf '%s' "$inner" | wc -c | tr -d ' ')
                echo "      result (content[0].text):"
                printf '%s' "$inner" | { jq . 2>/dev/null || cat; } | head -c "$cap" | sed 's/^/        /'
                echo ""
                [ "${len:-0}" -gt "$cap" ] 2>/dev/null && echo "        ... (truncated; ${len} bytes, cap ${cap} -- raise VMCP_TRACE_MAX)"
            else
                printf '%s' "$_VMCP_LAST_RAW" | { jq . 2>/dev/null || cat; } | head -c "$cap" | sed 's/^/      /'
                echo ""
            fi
        else
            printf '%s' "$_VMCP_LAST_RAW" | head -c "$cap" | sed 's/^/      /'
            echo ""
        fi
    } | redact_stream >> "$_VMCP_OUT"
}

_vmcp_count() {
    local want="$1" n=0 r
    for r in "${_VMCP_RESULTS[@]}"; do [ "${r%%|*}" = "$want" ] && n=$((n + 1)); done
    echo "$n"
}

_vmcp_first_msg() {
    local want="$1" r rest
    for r in "${_VMCP_RESULTS[@]}"; do
        if [ "${r%%|*}" = "$want" ]; then rest="${r#*|}"; echo "${rest#*|}"; return 0; fi
    done
}

_vmcp_tool_available() {
    case " ${_VMCP_ADVERTISED} " in *" $1 "*) return 0 ;; *) return 1 ;; esac
}

# Populate _VMCP_ADVERTISED from tools/list. Called directly (globals persist).
# Returns 0 if >=1 tool advertised, 1 on transport/parse failure.
_vmcp_load_advertised() {
    _VMCP_ID=$((_VMCP_ID + 1))
    local body resp raw _last names
    body=$(printf '{"jsonrpc":"2.0","method":"tools/list","id":%d}' "$_VMCP_ID")
    resp=$(_vmcp_http_post "$_VMCP_URL" "$_VMCP_TOKEN" "$body")
    raw=$(printf '%s' "$resp" | sed '$d')
    _last=$(printf '%s' "$resp" | tail -1)
    _VMCP_LAST_RAW="$raw"
    _VMCP_LAST_HTTP="${_last%% *}"
    _VMCP_LAST_TIME=""; case "$_last" in *" "*) _VMCP_LAST_TIME="${_last#* }" ;; esac
    _vmcp_trace "tools/list" "$body"
    [ "$_VMCP_LAST_HTTP" = "200" ] || return 1
    names=$(printf '%s' "$raw" | jq -r '.result.tools[]?.name // empty' 2>/dev/null | tr '\n' ' ')
    _VMCP_ADVERTISED=" ${names} "
    [ -n "${names// /}" ]
}

# ─── Tier 2: Read operations (anchor + chain) ───────────────────────────────
_vmcp_tier2_read() {
    if ! _vmcp_tool_available listRepositories; then
        _vmcp_record SKIP T2.1 "listRepositories not advertised"
        _VMCP_INDEX_EMPTY=1
    else
        local rc total
        _vmcp_call listRepositories "$(_vmcp_args '"pageNumber":1,"pageSize":10')"; rc=$?
        if [ "$rc" -ne 0 ]; then
            _vmcp_record FAIL T2.1 "listRepositories tool error (http=${_VMCP_LAST_HTTP}, rc=${rc})"
            _VMCP_INDEX_EMPTY=1
        elif ! _vmcp_recognized 'has("items") or has("pagination")'; then
            _vmcp_record WARN T2.1 "listRepositories unexpected response shape (http=${_VMCP_LAST_HTTP})"
            _VMCP_INDEX_EMPTY=1
        else
            total=$(printf '%s' "$_VMCP_INNER" | jq -r '.pagination.total_items // (.items | length) // 0' 2>/dev/null)
            [ -z "$total" ] && total=0
            _VMCP_NREPOS="$total"
            _VMCP_REPO_LIST=" $(printf '%s' "$_VMCP_INNER" | jq -r '.items[]?.name // empty' 2>/dev/null | tr '\n' ' ') "
            if [ "$total" = "0" ]; then
                _VMCP_INDEX_EMPTY=1
                _vmcp_record WARN T2.1 "0 repos indexed -- index may not be built yet (not a failure)"
                _vmcp_record SKIP T2.2 "repo-specific checks skipped (no repositories to chain from)"
            else
                _vmcp_record PASS T2.1 "listRepositories returned ${total} repo(s)"
                _VMCP_REPO_A=$(printf '%s' "$_VMCP_INNER" | jq -r '.items[0].name // .items[0].repositoryName // empty' 2>/dev/null)
                if [ -n "$_VMCP_REPO_A" ]; then
                    _vmcp_record PASS T2.2 "anchored on repo: ${_VMCP_REPO_A}"
                    _vmcp_check_repo_info
                    _vmcp_check_schema
                    _vmcp_check_field_path
                else
                    _vmcp_record WARN T2.2 "could not extract a repo name to chain from"
                fi
            fi
        fi
    fi
    _vmcp_check_clusters
}

# T2.3 getRepositoryInfo(REPO_A, summary).
_vmcp_check_repo_info() {
    if ! _vmcp_tool_available getRepositoryInfo; then
        _vmcp_record SKIP T2.3 "getRepositoryInfo not advertised"; return 0
    fi
    local rc
    _vmcp_call getRepositoryInfo \
        "$(_vmcp_args "$(printf '"repositoryName":"%s","detailLevel":"summary"' "$_VMCP_REPO_A")")"; rc=$?
    if [ "$rc" -ne 0 ]; then
        _vmcp_record FAIL T2.3 "getRepositoryInfo(${_VMCP_REPO_A}) tool error (http=${_VMCP_LAST_HTTP}, rc=${rc})"
    elif _vmcp_recognized 'has("name")'; then
        _vmcp_record PASS T2.3 "getRepositoryInfo(${_VMCP_REPO_A}) returned data"
    else
        _vmcp_record WARN T2.3 "getRepositoryInfo(${_VMCP_REPO_A}) unexpected response shape (http=${_VMCP_LAST_HTTP})"
    fi
}

# T2.4 getRepositorySchema(REPO_A). Schema content is optional (PASS when
# present or merely responded); a tool error is a FAIL.
_vmcp_check_schema() {
    if ! _vmcp_tool_available getRepositorySchema; then
        _vmcp_record SKIP T2.4 "getRepositorySchema not advertised"; return 0
    fi
    local rc
    _vmcp_call getRepositorySchema "$(_vmcp_args "$(printf '"repositoryName":"%s","maxDepth":2' "$_VMCP_REPO_A")")"; rc=$?
    if [ "$rc" -ne 0 ]; then
        _vmcp_record FAIL T2.4 "getRepositorySchema(${_VMCP_REPO_A}) tool error (http=${_VMCP_LAST_HTTP}, rc=${rc})"
    elif _vmcp_recognized 'has("schema")'; then
        _vmcp_record PASS T2.4 "getRepositorySchema(${_VMCP_REPO_A}) returned a schema"
    elif _vmcp_recognized 'has("repository") or has("path")'; then
        _vmcp_record PASS T2.4 "getRepositorySchema(${_VMCP_REPO_A}) responded (no schema -- index may be partial)"
    else
        _vmcp_record WARN T2.4 "getRepositorySchema(${_VMCP_REPO_A}) unexpected response shape (http=${_VMCP_LAST_HTTP})"
    fi
}

# T2.5 getFieldPath(REPO_A, project_overview). Unset value is acceptable; a
# tool error is a FAIL; a missing .value key is shape drift (WARN).
_vmcp_check_field_path() {
    if ! _vmcp_tool_available getFieldPath; then
        _vmcp_record SKIP T2.5 "getFieldPath not advertised"; return 0
    fi
    local rc
    _vmcp_call getFieldPath "$(_vmcp_args "$(printf '"repositoryName":"%s","fieldPath":"%s"' "$_VMCP_REPO_A" "$_VMCP_KNOWN_FIELD")")"; rc=$?
    if [ "$rc" -ne 0 ]; then
        _vmcp_record FAIL T2.5 "getFieldPath(${_VMCP_REPO_A}.${_VMCP_KNOWN_FIELD}) tool error (http=${_VMCP_LAST_HTTP}, rc=${rc})"
    elif ! _vmcp_recognized 'has("value")'; then
        _vmcp_record WARN T2.5 "getFieldPath(${_VMCP_REPO_A}.${_VMCP_KNOWN_FIELD}) unexpected response shape (http=${_VMCP_LAST_HTTP})"
    elif printf '%s' "$_VMCP_INNER" | jq -e '(.value != null) and (.value != "")' >/dev/null 2>&1; then
        _vmcp_record PASS T2.5 "getFieldPath(${_VMCP_REPO_A}.${_VMCP_KNOWN_FIELD}) returned a value"
    else
        _vmcp_record PASS T2.5 "getFieldPath(${_VMCP_REPO_A}.${_VMCP_KNOWN_FIELD}) responded (field unset -- index may be partial)"
    fi
}

# T2.6 listClusters (capture ids) + T2.7 getClusterInfo(last). 0 clusters is
# acceptable on a fresh/small on-prem index.
_vmcp_check_clusters() {
    if ! _vmcp_tool_available listClusters; then
        _vmcp_record SKIP T2.6 "listClusters not advertised"; return 0
    fi
    local rc ccount
    _vmcp_call listClusters "$(_vmcp_args '"pageNumber":1,"pageSize":20')"; rc=$?
    if [ "$rc" -ne 0 ]; then
        _vmcp_record FAIL T2.6 "listClusters tool error (http=${_VMCP_LAST_HTTP}, rc=${rc})"; return 0
    elif ! _vmcp_recognized 'has("items")'; then
        _vmcp_record WARN T2.6 "listClusters unexpected response shape (http=${_VMCP_LAST_HTTP})"; return 0
    fi
    ccount=$(printf '%s' "$_VMCP_INNER" | jq -r '(.items // []) | length' 2>/dev/null); [ -z "$ccount" ] && ccount=0
    _VMCP_NCLUSTERS="$ccount"
    _VMCP_CLUSTER_FIRST=$(printf '%s' "$_VMCP_INNER" | jq -r '.items[0].id // empty' 2>/dev/null)
    _VMCP_CLUSTER_LAST=$(printf '%s' "$_VMCP_INNER" | jq -r '.items[-1].id // empty' 2>/dev/null)
    if [ "$ccount" = "0" ]; then
        _vmcp_record PASS T2.6 "listClusters responded (0 clusters -- acceptable on a small/diverse index)"
        return 0
    fi
    _vmcp_record PASS T2.6 "listClusters returned ${ccount} cluster(s)"

    if ! _vmcp_tool_available getClusterInfo; then
        _vmcp_record SKIP T2.7 "getClusterInfo not advertised"; return 0
    fi
    local rc2 repos
    _vmcp_call getClusterInfo "$(_vmcp_args "$(printf '"clusterId":"%s"' "$_VMCP_CLUSTER_LAST")")"; rc2=$?
    if [ "$rc2" -ne 0 ]; then
        _vmcp_record FAIL T2.7 "getClusterInfo(${_VMCP_CLUSTER_LAST}) tool error (http=${_VMCP_LAST_HTTP}, rc=${rc2})"; return 0
    fi
    repos=$(printf '%s' "$_VMCP_INNER" | jq -r '.repository_count // (.repositories | length) // 0' 2>/dev/null); [ -z "$repos" ] && repos=0
    if [ "$repos" -ge 1 ] 2>/dev/null; then
        _vmcp_record PASS T2.7 "getClusterInfo(${_VMCP_CLUSTER_LAST}) has ${repos} repo(s)"
    else
        _vmcp_record WARN T2.7 "getClusterInfo(${_VMCP_CLUSTER_LAST}) returned 0 repos"
    fi
}

# ─── Tier 3: Search operations ──────────────────────────────────────────────
_vmcp_tier3_search() {
    # T3.1 searchRepositories (ranker: returns ranked repos for any query on a
    # populated index). Tool error => FAIL; unrecognized shape => WARN.
    if _vmcp_tool_available searchRepositories; then
        local rc n
        _vmcp_call searchRepositories "$(_vmcp_args '"searchQuery":"service api backend","maxResults":5')"; rc=$?
        if [ "$rc" -ne 0 ]; then
            _vmcp_record FAIL T3.1 "searchRepositories tool error (http=${_VMCP_LAST_HTTP}, rc=${rc})"
        elif ! _vmcp_recognized 'has("repositories") or has("results") or has("items")'; then
            _vmcp_record WARN T3.1 "searchRepositories unexpected response shape (http=${_VMCP_LAST_HTTP})"
        else
            n=$(printf '%s' "$_VMCP_INNER" | jq -r '(.repositories // .results // .items // []) | length' 2>/dev/null); [ -z "$n" ] && n=0
            _VMCP_SEARCH_REPO_A=$(printf '%s' "$_VMCP_INNER" | jq -r '(.repositories // .results // .items)[0].name // empty' 2>/dev/null)
            _vmcp_record PASS T3.1 "searchRepositories returned ${n} result(s)"
        fi
    else
        _vmcp_record SKIP T3.1 "searchRepositories not advertised"
    fi

    # T3.2 searchWithinRepository(REPO_A, config -> main). Counts live under
    # ._search (not a flat array). Content-dependent: any successful response is
    # a PASS; all attempts erroring is a FAIL.
    if [ "$_VMCP_INDEX_EMPTY" = "1" ] || [ -z "$_VMCP_REPO_A" ]; then
        _vmcp_record SKIP T3.2 "searchWithinRepository skipped (no anchor repo)"
    elif _vmcp_tool_available searchWithinRepository; then
        local q rc2 any_ok n2 last_recognized
        any_ok=0; n2=0; last_recognized=1
        for q in config main; do
            _vmcp_call searchWithinRepository "$(_vmcp_args "$(printf '"repositoryName":"%s","searchQuery":"%s"' "$_VMCP_REPO_A" "$q")")"; rc2=$?
            if [ "$rc2" -eq 0 ]; then
                any_ok=1
                _vmcp_recognized 'has("_search")' && last_recognized=1 || last_recognized=0
                n2=$(printf '%s' "$_VMCP_INNER" | jq -r '._search.total_matches // ._search.returned_matches // 0' 2>/dev/null); [ -z "$n2" ] && n2=0
                [ "$n2" -ge 1 ] 2>/dev/null && break
            fi
        done
        if [ "$any_ok" -eq 0 ]; then
            _vmcp_record FAIL T3.2 "searchWithinRepository(${_VMCP_REPO_A}) tool error (http=${_VMCP_LAST_HTTP})"
        elif [ "$last_recognized" -eq 0 ]; then
            _vmcp_record WARN T3.2 "searchWithinRepository(${_VMCP_REPO_A}) unexpected response shape (http=${_VMCP_LAST_HTTP})"
        else
            _vmcp_record PASS T3.2 "searchWithinRepository(${_VMCP_REPO_A}) responded (${n2} match(es))"
        fi
    else
        _vmcp_record SKIP T3.2 "searchWithinRepository not advertised"
    fi

    # T3.3 searchCode (Go -> Python -> Java). Capture a hit for T4. Language-
    # dependent: any successful response is a PASS; all attempts erroring is FAIL.
    if _vmcp_tool_available searchCode; then
        local pat fp rc3 any_ok3 n3 pair
        any_ok3=0; n3=0
        for pair in 'func main|*.go' 'def main|*.py' 'public static void main|*.java'; do
            pat="${pair%|*}"; fp="${pair#*|}"
            _vmcp_call searchCode "$(_vmcp_args "$(printf '"pattern":"%s","filePattern":"%s","maxResults":5' "$pat" "$fp")")"; rc3=$?
            if [ "$rc3" -eq 0 ]; then
                any_ok3=1
                n3=$(printf '%s' "$_VMCP_INNER" | jq -r '(.matches // .results // .items // []) | length' 2>/dev/null); [ -z "$n3" ] && n3=0
                if [ "$n3" -ge 1 ] 2>/dev/null; then
                    _VMCP_CODE_REPO=$(printf '%s' "$_VMCP_INNER" | jq -r '(.matches // .results // .items)[0].repository // empty' 2>/dev/null)
                    _VMCP_CODE_FILE=$(printf '%s' "$_VMCP_INNER" | jq -r '(.matches // .results // .items)[0].file // (.matches // .results // .items)[0].filePath // empty' 2>/dev/null)
                    _VMCP_CODE_LINE=$(printf '%s' "$_VMCP_INNER" | jq -r '(.matches // .results // .items)[0].line_number // (.matches // .results // .items)[0].startLine // 1' 2>/dev/null)
                    break
                fi
            fi
        done
        if [ "$n3" -ge 1 ] 2>/dev/null; then
            _vmcp_record PASS T3.3 "searchCode hit ${_VMCP_CODE_REPO}/${_VMCP_CODE_FILE}:${_VMCP_CODE_LINE}"
        elif [ "$any_ok3" -eq 1 ]; then
            _vmcp_record PASS T3.3 "searchCode responded (0 matches for Go/Python/Java -- language may differ)"
        else
            _vmcp_record FAIL T3.3 "searchCode tool error (http=${_VMCP_LAST_HTTP})"
        fi
    else
        _vmcp_record SKIP T3.3 "searchCode not advertised"
    fi

    # T3.4 searchSymbols (main -> init -> handler). Content-dependent.
    if _vmcp_tool_available searchSymbols; then
        local sym rc4 any_ok4 n4
        any_ok4=0; n4=0
        for sym in main init handler; do
            _vmcp_call searchSymbols "$(_vmcp_args "$(printf '"pattern":"%s","maxResults":5' "$sym")")"; rc4=$?
            if [ "$rc4" -eq 0 ]; then
                any_ok4=1
                n4=$(printf '%s' "$_VMCP_INNER" | jq -r '(.symbols // .results // .items // []) | length' 2>/dev/null); [ -z "$n4" ] && n4=0
                [ "$n4" -ge 1 ] 2>/dev/null && break
            fi
        done
        if [ "$any_ok4" -eq 1 ]; then
            _vmcp_record PASS T3.4 "searchSymbols responded (${n4} result(s))"
        else
            _vmcp_record FAIL T3.4 "searchSymbols tool error (http=${_VMCP_LAST_HTTP})"
        fi
    else
        _vmcp_record SKIP T3.4 "searchSymbols not advertised"
    fi

    # T3.5 queryFieldAcrossRepositories(up to 3 repos, project_overview). The
    # real server returns .results as an object keyed by repo name.
    if [ "$_VMCP_INDEX_EMPTY" = "1" ]; then
        _vmcp_record SKIP T3.5 "queryFieldAcrossRepositories skipped (empty index)"
    elif _vmcp_tool_available queryFieldAcrossRepositories; then
        local repos3 rc5 n5
        repos3=$(printf '%s' "$_VMCP_REPO_LIST" | tr ' ' '\n' | grep -v '^$' | head -3 | jq -R . | jq -sc .)
        _vmcp_call queryFieldAcrossRepositories "$(_vmcp_args "$(printf '"repositories":%s,"fieldPath":"%s"' "$repos3" "$_VMCP_KNOWN_FIELD")")"; rc5=$?
        if [ "$rc5" -ne 0 ]; then
            _vmcp_record FAIL T3.5 "queryFieldAcrossRepositories tool error (http=${_VMCP_LAST_HTTP}, rc=${rc5})"
        elif ! _vmcp_recognized 'has("results")'; then
            _vmcp_record WARN T3.5 "queryFieldAcrossRepositories unexpected response shape (http=${_VMCP_LAST_HTTP})"
        else
            n5=$(printf '%s' "$_VMCP_INNER" | jq -r '.results | if type=="array" then length else length end' 2>/dev/null); [ -z "$n5" ] && n5=0
            _vmcp_record PASS T3.5 "queryFieldAcrossRepositories returned ${n5} result(s)"
        fi
    else
        _vmcp_record SKIP T3.5 "queryFieldAcrossRepositories not advertised"
    fi
}

# ─── Tier 4: Code retrieval ─────────────────────────────────────────────────
_vmcp_tier4_code() {
    if [ -z "$_VMCP_CODE_REPO" ] || [ -z "$_VMCP_CODE_FILE" ]; then
        _vmcp_record SKIP T4.1 "getCode skipped (no searchCode hit to retrieve)"; return 0
    fi
    if ! _vmcp_tool_available getCode; then
        _vmcp_record SKIP T4.1 "getCode not advertised"; return 0
    fi
    local rc lines
    _vmcp_call getCode "$(_vmcp_args "$(printf '"repositoryName":"%s","filePath":"%s","startLine":%s' "$_VMCP_CODE_REPO" "$_VMCP_CODE_FILE" "${_VMCP_CODE_LINE:-1}")")"; rc=$?
    if [ "$rc" -ne 0 ]; then
        _vmcp_record FAIL T4.1 "getCode(${_VMCP_CODE_FILE}) tool error (http=${_VMCP_LAST_HTTP}, rc=${rc})"; return 0
    fi
    lines=$(printf '%s' "$_VMCP_INNER" | jq -r '.returned_lines // ((.content // "") | if .=="" then 0 else 1 end)' 2>/dev/null); [ -z "$lines" ] && lines=0
    if [ "$lines" -ge 1 ] 2>/dev/null; then
        _vmcp_record PASS T4.1 "getCode(${_VMCP_CODE_FILE}) returned source content"
    else
        _vmcp_record FAIL T4.1 "getCode(${_VMCP_CODE_FILE}) returned no content (http=${_VMCP_LAST_HTTP})"
    fi
}

# ─── Tier 5: Negative paths (graceful errors, no crash/hang) ────────────────
# Bogus inputs SHOULD elicit an error/empty -- so success here means the server
# RESPONDED (any HTTP code) rather than hanging; isError on bogus input is fine.
_vmcp_tier5_negative() {
    if _vmcp_tool_available getRepositoryInfo; then
        _vmcp_call getRepositoryInfo "$(_vmcp_args '"repositoryName":"THIS-REPO-DOES-NOT-EXIST-XYZ-00000","detailLevel":"summary"')"
        if _vmcp_responded; then
            _vmcp_record PASS T5.1 "getRepositoryInfo(bogus) handled gracefully (http=${_VMCP_LAST_HTTP})"
        else
            _vmcp_record FAIL T5.1 "getRepositoryInfo(bogus) did not respond (http=${_VMCP_LAST_HTTP})"
        fi
    else
        _vmcp_record SKIP T5.1 "getRepositoryInfo not advertised"
    fi

    if _vmcp_tool_available getClusterInfo; then
        _vmcp_call getClusterInfo "$(_vmcp_args '"clusterId":"cluster_99999"')"
        if _vmcp_responded; then
            _vmcp_record PASS T5.2 "getClusterInfo(bogus) handled gracefully (http=${_VMCP_LAST_HTTP})"
        else
            _vmcp_record FAIL T5.2 "getClusterInfo(bogus) did not respond (http=${_VMCP_LAST_HTTP})"
        fi
    else
        _vmcp_record SKIP T5.2 "getClusterInfo not advertised"
    fi

    if [ -z "$_VMCP_REPO_A" ]; then
        _vmcp_record SKIP T5.3 "getFieldPath(bogus path) skipped (no anchor repo)"
    elif _vmcp_tool_available getFieldPath; then
        _vmcp_call getFieldPath "$(_vmcp_args "$(printf '"repositoryName":"%s","fieldPath":"nonexistent.deep.path.xyz"' "$_VMCP_REPO_A")")"
        if _vmcp_responded; then
            _vmcp_record PASS T5.3 "getFieldPath(bogus path) handled gracefully (http=${_VMCP_LAST_HTTP})"
        else
            _vmcp_record FAIL T5.3 "getFieldPath(bogus path) did not respond (http=${_VMCP_LAST_HTTP})"
        fi
    else
        _vmcp_record SKIP T5.3 "getFieldPath not advertised"
    fi
}

# ─── Tier 6: Cross-tool consistency ─────────────────────────────────────────
# (The cloud T6 compares getCapabilities.total vs listRepositories.total, but
# getCapabilities is not exposed on-prem -- so we cross-check tools that exist.)
_vmcp_tier6_consistency() {
    if [ "$_VMCP_INDEX_EMPTY" = "1" ] || [ -z "$_VMCP_SEARCH_REPO_A" ]; then
        _vmcp_record SKIP T6.1 "search/read consistency skipped (no search hit)"
    elif case "$_VMCP_REPO_LIST" in *" $_VMCP_SEARCH_REPO_A "*) true ;; *) false ;; esac; then
        _vmcp_record PASS T6.1 "searchRepositories hit '${_VMCP_SEARCH_REPO_A}' is in listRepositories"
    elif _vmcp_tool_available getRepositoryInfo; then
        _vmcp_call getRepositoryInfo "$(_vmcp_args "$(printf '"repositoryName":"%s","detailLevel":"summary"' "$_VMCP_SEARCH_REPO_A")")"
        if [ $? -eq 0 ] && _vmcp_recognized 'has("name")'; then
            _vmcp_record PASS T6.1 "searchRepositories hit '${_VMCP_SEARCH_REPO_A}' confirmed via getRepositoryInfo"
        else
            _vmcp_record WARN T6.1 "could not cross-confirm searchRepositories hit '${_VMCP_SEARCH_REPO_A}'"
        fi
    else
        _vmcp_record WARN T6.1 "could not cross-confirm searchRepositories hit '${_VMCP_SEARCH_REPO_A}'"
    fi

    if [ -z "$_VMCP_CLUSTER_FIRST" ]; then
        _vmcp_record SKIP T6.2 "cluster consistency skipped (no clusters)"
    elif _vmcp_tool_available getClusterInfo; then
        _vmcp_call getClusterInfo "$(_vmcp_args "$(printf '"clusterId":"%s"' "$_VMCP_CLUSTER_FIRST")")"
        if _vmcp_responded; then
            _vmcp_record PASS T6.2 "cluster spot-check: ${_VMCP_CLUSTER_FIRST} resolves"
        else
            _vmcp_record WARN T6.2 "cluster spot-check: ${_VMCP_CLUSTER_FIRST} did not resolve"
        fi
    else
        _vmcp_record SKIP T6.2 "getClusterInfo not advertised"
    fi
}

# ─── Engine ─────────────────────────────────────────────────────────────────
# Runs all tiers against _VMCP_URL/_VMCP_TOKEN. T1's tools/list doubles as the
# reachability check, so a dead endpoint fails fast. In live mode an overall
# wall-clock budget (_VMCP_DEADLINE) short-circuits remaining tiers.
_vmcp_run_checks() {
    if ! _vmcp_load_advertised; then
        _vmcp_record FAIL T1.1 "MCP endpoint did not return a tool list (http=${_VMCP_LAST_HTTP:-?})"
        return 0
    fi
    _VMCP_NTOOLS=$(printf '%s' "$_VMCP_ADVERTISED" | tr ' ' '\n' | grep -c .)
    _vmcp_record PASS T1.1 "tools/list OK (${_VMCP_NTOOLS} tools advertised)"
    _vmcp_tier2_read
    _vmcp_over_budget && { _vmcp_record WARN T0 "time budget exceeded -- remaining tiers skipped"; return 0; }
    _vmcp_tier3_search
    _vmcp_over_budget && { _vmcp_record WARN T0 "time budget exceeded -- remaining tiers skipped"; return 0; }
    _vmcp_tier4_code
    _vmcp_tier5_negative
    _vmcp_tier6_consistency
}

# ─── Live entry point (compact, UI-facing) ──────────────────────────────────
# Called from diag_section_connectivity after a successful endpoint probe. Emits
# ONE _diag_* summary line (plus per-tier detail with --verbose). Uses a tighter
# per-call timeout and an overall budget so the always-on `diagnose` stays snappy.
mcp_validate_live() {
    local verbose="${1:-false}"
    _vmcp_reset
    _VMCP_URL="${PROVIDER_URL:-}"
    _VMCP_TOKEN="${PROVIDER_TOKEN:-}"
    { [ -z "$_VMCP_URL" ] || [ -z "$_VMCP_TOKEN" ]; } && return 0
    if ! command -v jq >/dev/null 2>&1; then
        _diag_warn "MCP validation skipped (jq not installed)"
        return 0
    fi

    VMCP_HTTP_TIMEOUT="${VMCP_LIVE_HTTP_TIMEOUT:-8}"
    _VMCP_DEADLINE=$(( $(date +%s 2>/dev/null || echo 0) + ${VMCP_LIVE_BUDGET:-25} ))

    _vmcp_run_checks

    local fails warns
    fails=$(_vmcp_count FAIL)
    warns=$(_vmcp_count WARN)
    if [ "$fails" -gt 0 ]; then
        _diag_fail "MCP tool validation: ${fails} check(s) failed -- $(_vmcp_first_msg FAIL)" connectivity
    elif [ "$_VMCP_INDEX_EMPTY" = "1" ]; then
        _diag_warn "MCP reachable; 0 repos indexed yet (indexing may be pending)"
    elif [ "$warns" -gt 0 ]; then
        _diag_warn "MCP tools validated with warnings -- $(_vmcp_first_msg WARN)"
    else
        _diag_pass "MCP tools validated (${_VMCP_NTOOLS} tools, ${_VMCP_NREPOS} repo(s) indexed)"
    fi

    if [ "$verbose" = "true" ]; then
        local r
        for r in "${_VMCP_RESULTS[@]}"; do
            printf '      %s %s\n' "${r%%|*}" "${r#*|}" | sed 's/|/ /'
        done
    fi
    return 0
}

# ─── Bundle entry point (detailed) ──────────────────────────────────────────
# safe_step collector. Writes full per-call detail to mcp-validation.txt.
# rc 2 = soft-skip (no url/token/jq), consistent with the other collectors.
collect_mcp_validation() {
    local deployment_type="$1" out_dir="$2"
    local target="${out_dir}/mcp-validation.txt"

    _vmcp_reset
    _VMCP_OUT="$target"
    bundle_init_file "$target" "MCP Validation (deterministic tiers T1-T6)"

    _VMCP_URL="${PROVIDER_URL:-}"
    # Match the sibling collect_mcp's token precedence so one --bundle gives
    # consistent signals: BITO_MCP_ACCESS_TOKEN (canonical) -> PROVIDER_TOKEN
    # (legacy) -> BITO_API_KEY (last-resort).
    _VMCP_TOKEN="${BITO_MCP_ACCESS_TOKEN:-${PROVIDER_TOKEN:-${BITO_API_KEY:-}}}"
    if [ -z "$_VMCP_URL" ]; then
        echo "  PROVIDER_URL not set -- cannot validate MCP." >> "$target"
        _bundle_step_warn "mcp-validation" "PROVIDER_URL not set"
        return 2
    fi
    if [ -z "$_VMCP_TOKEN" ]; then
        echo "  No MCP token (BITO_MCP_ACCESS_TOKEN / PROVIDER_TOKEN / BITO_API_KEY) set -- cannot validate." >> "$target"
        _bundle_step_warn "mcp-validation" "no MCP token set"
        return 2
    fi
    if ! command -v jq >/dev/null 2>&1; then
        echo "  jq not installed -- MCP validation requires jq; skipped." >> "$target"
        _bundle_step_warn "mcp-validation" "jq not installed"
        return 2
    fi

    VMCP_HTTP_TIMEOUT="${VMCP_BUNDLE_HTTP_TIMEOUT:-20}"   # generous; no live budget
    _VMCP_DEADLINE=""

    {
        echo "Endpoint: ${PROVIDER_URL}/mcp"
        echo ""
        echo "Each check below shows the MCP request(s) and response(s) made, then"
        echo "its verdict ([Tx.y] PASS/WARN/FAIL/SKIP). Responses are capped at"
        echo "VMCP_TRACE_MAX bytes (default 10000); raise it for full payloads."
    } >> "$target"
    bundle_log_section "$target" "Request / response trace"
    _vmcp_run_checks

    bundle_log_section "$target" "Summary"
    echo "  pass=$(_vmcp_count PASS) warn=$(_vmcp_count WARN) fail=$(_vmcp_count FAIL) skip=$(_vmcp_count SKIP)" >> "$target"
    echo "  tools=${_VMCP_NTOOLS} repos=${_VMCP_NREPOS} clusters=${_VMCP_NCLUSTERS}" >> "$target"
    return 0
}
