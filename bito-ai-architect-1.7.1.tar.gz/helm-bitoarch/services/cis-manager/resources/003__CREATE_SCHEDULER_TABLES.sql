-- ============================================================================
-- Table: scheduled_tasks
-- Purpose: Job definitions with scheduling metadata, scoped per workspace.
--          Each workspace can have multiple task types.
-- ============================================================================
CREATE TABLE IF NOT EXISTS scheduled_tasks (
    id                VARCHAR(64)   NOT NULL,
    workspace_id      BIGINT        NOT NULL,
    task_type         VARCHAR(128)  NOT NULL COMMENT 'Registry key: basic_index, ai_index, etc.',

    -- Schedule type: "cron" or "interval"
    scheduler_type    VARCHAR(16)   NOT NULL DEFAULT 'interval',

    -- For interval-based: seconds between runs
    interval_seconds  INT           NULL,

    -- For cron-based: standard 5-field cron expression
    cron_expression   VARCHAR(128)  NULL,

    -- Execution tracking
    last_run          DATETIME      NULL     COMMENT 'Last execution start time',
    next_run          DATETIME      NOT NULL COMMENT 'Next scheduled execution time',
    last_status       VARCHAR(32)   NOT NULL DEFAULT 'pending'
                      COMMENT 'pending|running|success|failed|timeout -- tracks enqueue outcome',
    last_error        TEXT          NULL     COMMENT 'Error from last failed enqueue attempt',
    last_duration_ms  BIGINT        NULL     COMMENT 'Duration of enqueue call in ms',

    task_config       JSON          NULL,
    timeout_seconds   INT           NOT NULL DEFAULT 300
                      COMMENT 'Max time for enqueue operation (not the pipeline itself)',
    max_retries       INT           NOT NULL DEFAULT 3,
    retry_count       INT           NOT NULL DEFAULT 0,

    enabled           TINYINT(1)    NOT NULL DEFAULT 1,
    created_at        DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at        DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    PRIMARY KEY (id),
    UNIQUE KEY uk_workspace_task (workspace_id, task_type),
    INDEX idx_next_run_enabled (next_run, enabled),
    INDEX idx_workspace (workspace_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- ============================================================================
-- Table: scheduler_locks
-- Purpose: Distributed locking with TTL for scheduler task execution.
--          Ensures only one node enqueues a given task per schedule tick.
--          Separate from transient_state (see design doc Section 2 for rationale).
-- ============================================================================
CREATE TABLE IF NOT EXISTS scheduler_locks (
    lock_key      VARCHAR(255)  NOT NULL COMMENT 'Format: sched:<task_id>',
    node_id       VARCHAR(128)  NOT NULL COMMENT 'hostname-uuid identifying the node',
    acquired_at   DATETIME      NOT NULL,
    expires_at    DATETIME      NOT NULL COMMENT 'TTL-based expiry for crash recovery',

    PRIMARY KEY (lock_key),
    INDEX idx_expires (expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
