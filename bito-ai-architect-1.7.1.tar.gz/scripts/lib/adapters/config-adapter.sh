#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
# Bito's AI Architect CLI - Config Adapter
# Handles AI Architect Config service commands

# Source http-client for K8s port-forward support
if [ -z "$SCRIPT_DIR" ]; then
    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && cd ../.. && pwd)"
fi
source "${SCRIPT_DIR}/scripts/lib/http-client.sh" 2>/dev/null || true

# Source config-backup-manager for centralized backup utility
if [ -f "${SCRIPT_DIR}/scripts/lib/config-backup-manager.sh" ]; then
    source "${SCRIPT_DIR}/scripts/lib/config-backup-manager.sh"
fi

# Ensure config service is accessible (handles K8s port-forward automatically)
ensure_config_service_accessible() {
    # Get port from environment
    local CONFIG_PORT="${CIS_CONFIG_EXTERNAL_PORT:-5003}"
    
    # Ensure service is accessible (no-op for Docker, sets up port-forward for K8s)
    ensure_service_accessible "ai-architect-config" "$CONFIG_PORT" 2>/dev/null || true
}

# Helper function to encrypt secrets for config payload
config_encrypt_secrets() {
    local bito_key="$1"
    local git_json="$2"
    
    # Get encryption key from environment
    if [ -z "$SECRETS_ENCRYPTION_KEY" ]; then
        print_error "SECRETS_ENCRYPTION_KEY not found in environment"
        return 1
    fi
    
    # Set LOG_FILE if not already set (required by setup-utils.sh)
    if [ -z "$LOG_FILE" ]; then
        export LOG_FILE="/dev/null"
    fi
    
    # Source encryption function from setup-utils
    if [ -f "${SCRIPT_DIR}/setup-utils.sh" ]; then
        source "${SCRIPT_DIR}/setup-utils.sh"
    elif [ -f "./scripts/setup-utils.sh" ]; then
        source "./scripts/setup-utils.sh"
    else
        print_error "setup-utils.sh not found"
        return 1
    fi
    
    # Encrypt BITO API key
    local encrypted_bito=$(encrypt_secret "$bito_key" "$SECRETS_ENCRYPTION_KEY")
    if [ $? -ne 0 ] || [ -z "$encrypted_bito" ]; then
        print_error "Failed to encrypt Bito API key"
        return 1
    fi
    
    # Extract and encrypt git access token
    local git_token=$(echo "$git_json" | jq -r '.access_token')
    if [ -z "$git_token" ] || [ "$git_token" = "null" ]; then
        print_error "Git access token not found"
        return 1
    fi
    
    local encrypted_token=$(encrypt_secret "$git_token" "$SECRETS_ENCRYPTION_KEY")
    if [ $? -ne 0 ] || [ -z "$encrypted_token" ]; then
        print_error "Failed to encrypt git access token"
        return 1
    fi
    
    # Update git JSON with encrypted token
    local encrypted_git=$(echo "$git_json" | jq --arg token "$encrypted_token" '.access_token = $token')
    
    # Output encrypted values as JSON for easy parsing
    jq -n \
        --arg bito "$encrypted_bito" \
        --argjson git "$encrypted_git" \
        '{bito_key: $bito, git_json: $git}'
}

# ── Helper: Extract workspace_id from config API response and persist to env ──
_persist_workspace_id_from_response() {
    local body="$1"
    
    # Try to extract workspace_id from the response JSON
    local workspace_id=""
    if command -v jq >/dev/null 2>&1; then
        workspace_id=$(echo "$body" | jq -r '.workspace_id // .workspaceId // .data.workspace_id // .data.workspaceId // empty' 2>/dev/null)
    fi
    
    # Only persist if we got a valid numeric workspace_id
    if [ -n "$workspace_id" ] && [[ "$workspace_id" =~ ^[0-9]+$ ]]; then
        local env_file
        if command -v get_config_file >/dev/null 2>&1; then
            env_file=$(get_config_file)
        elif [ -n "${ENV_FILE:-}" ]; then
            env_file="$ENV_FILE"
        else
            env_file="${BITOARCH_CONFIG_DIR:-/usr/local/etc/bitoarch}/.env-bitoarch"
        fi
        
        if [ -f "$env_file" ] && command -v set_env_key_value >/dev/null 2>&1; then
            # Skip if workspace_id is already set to the same value (avoids unnecessary restart)
            local existing_wid=""
            existing_wid=$(grep -m1 '^XMCP_SSO_DEFAULT_WORKSPACE_ID=' "$env_file" 2>/dev/null | cut -d= -f2 | tr -d '"' | tr -d "'")
            if [ "$existing_wid" = "$workspace_id" ]; then
                log_silent "workspace_id=$workspace_id already set, skipping update and restart"
                return 0
            fi
            
            set_env_key_value "XMCP_SSO_DEFAULT_WORKSPACE_ID" "$workspace_id" "$env_file"
            log_silent "Persisted workspace_id=$workspace_id to $env_file (was: ${existing_wid:-empty})"

            # For K8s: update ConfigMap + restart provider to pick up new workspace_id
            local deployment_type="docker-compose"
            if type get_deployment_type >/dev/null 2>&1; then
                deployment_type=$(get_deployment_type)
            else
                local dt_file="${BITOARCH_CONFIG_DIR:-/usr/local/etc/bitoarch}/.deployment-type"
                [ -f "$dt_file" ] && deployment_type=$(cat "$dt_file")
            fi
            if [ "$deployment_type" = "kubernetes" ]; then
                # Reuse xmcp_restart_provider which handles: ConfigMap patch → rollout restart → port-forwards
                if command -v xmcp_restart_provider >/dev/null 2>&1; then
                    log_silent "K8s: restarting provider to sync workspace_id=$workspace_id"
                    xmcp_restart_provider >/dev/null 2>&1
                fi
            fi
        fi
    fi
}

# Config command handler
handle_config() {
    local command="$1"
    shift
    
    # Check for help
    if [ "$command" = "--help" ] || [ "$command" = "-h" ] || [ -z "$command" ]; then
        show_config_help
        return 0
    fi
    
    # Route to command
    case "$command" in
        repo)
            handle_config_repo "$@"
            ;;
        *)
            print_error "Unknown config command: $command"
            echo ""
            echo "Available commands: repo"
            echo -e "Use ${YELLOW}bitoarch --help${NC} for more information"
            return 1
            ;;
    esac
}

# Repository configuration commands
handle_config_repo() {
    local command="$1"
    shift
    
    case "$command" in
        get)
            config_repo_get "$@"
            ;;
        add)
            # Check if argument looks like a namespace or a file
            if [ -n "$1" ] && [ ! -f "$1" ] && [[ "$1" =~ ^[a-zA-Z0-9_-]+/[a-zA-Z0-9_.-]+$ ]]; then
                # It's a namespace pattern (org/repo)
                config_repo_add_namespace "$@"
            elif [ -n "$1" ] && [ -f "$1" ]; then
                # It's a file
                config_repo_add_from_file "$@"

            else
                print_error "Invalid argument. Expected namespace (org/repo) or YAML file path"
                echo ""
                echo "Usage:"
                echo -e "  ${YELLOW}bitoarch add-repo <namespace>${NC}        # Add single repository"
                echo -e "  ${YELLOW}bitoarch add-repos [yaml-file]${NC}       # Add from YAML file"
                echo ""
                echo "Examples:"
                echo -e "  ${YELLOW}bitoarch add-repo myorg/myrepo${NC}"
                echo -e "  ${YELLOW}bitoarch add-repos${NC}                   # Uses default config location"
                return 1
            fi
            ;;
        remove)
            config_repo_remove_namespace "$@"
            ;;
        update)
            config_repo_update_from_file "$@"
            ;;
        validate)
            config_repo_validate "$@"
            ;;
        --help|-h|"")
            cat << 'EOF'
REPOSITORY CONFIGURATION

COMMANDS:
  get                Get current configuration
  add <namespace>    Add single repository by namespace
  add <yaml-file>    Add repositories from YAML file
  remove <namespace> Remove repository by namespace
  update             Update configuration from YAML file
  validate           Validate configuration

Use 'bitoarch <command> --help' for command details
EOF
            ;;
        *)
            print_error "Unknown repo config command: $command"
            return 1
            ;;
    esac
}

# Get current configuration from cis-config
config_repo_get() {
    local show_raw=false
    
    # Parse options
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --help|-h)
                cat << 'EOF'
USAGE:
  bitoarch show-config [OPTIONS]

DESCRIPTION:
  Retrieve the current configuration from AI Architect Config service.
  Returns the complete workspace configuration including Git integration and repository settings.

OPTIONS:
  --raw    Show raw API response with secrets masked

EXAMPLES:
  bitoarch show-config
  bitoarch show-config --raw
  bitoarch show-config | jq '.repository'

NOTES:
  - Requires BITO_API_KEY to be set in environment
  - Connects to AI Architect Config service using CONFIG_URL from .env-bitoarch
  - Output is in JSON format
  - Secrets are automatically masked in output
EOF
                return 0
                ;;
            --raw)
                show_raw=true
                shift
                ;;
            *)
                shift
                ;;
        esac
    done
    
    # Get BITO API key from environment
    if [ -z "$BITO_API_KEY" ]; then
        print_error "BITO_API_KEY not found in environment"
        return 1
    fi
    
    # Get config external port from environment (default to 5003)
    local CONFIG_PORT="${CIS_CONFIG_EXTERNAL_PORT:-5003}"
    local CONFIG_URL="${CONFIG_URL:-http://localhost:${CONFIG_PORT}}"
    
    print_info "Fetching configuration from ${CONFIG_URL}..."
    
    # Make API call directly with curl
    local response=$(curl -s -w '\n%{http_code}' \
        -X GET \
        -H "Authorization: Bearer ${BITO_API_KEY}" \
        "${CONFIG_URL}/api/v1/config" 2>&1)
    
    # Extract HTTP code from last line
    local http_code=$(echo "$response" | tail -1)
    local body=$(echo "$response" | sed '$d')
    
    # Check HTTP code
    if [ "$http_code" -ge 200 ] && [ "$http_code" -lt 300 ]; then
        # Use appropriate render function based on --raw flag
        if [ "$show_raw" = "true" ]; then
            render_config_get_raw_block "$body"
        else
            render_config_get_summary_block "$body"
        fi
        return 0
    else
        render_config_get_failure_block "$http_code" "$body"
        return 1
    fi
}

# Update configuration from YAML file (generic YAML to JSON conversion with PUT method)
config_repo_update_from_file() {
    local yaml_file=""
    local show_raw=false
    
    # Parse options
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --help|-h)
                yaml_file="--help"
                shift
                ;;
            --raw)
                show_raw=true
                shift
                ;;
            *)
                if [ -z "$yaml_file" ] || [ "$yaml_file" = "--help" ]; then
                    yaml_file="$1"
                fi
                shift
                ;;
        esac
    done
    
    if [ "$yaml_file" = "--help" ]; then
        cat << 'EOF'
USAGE:
  bitoarch update-repos [yaml-file]

DESCRIPTION:
  Update the configuration with settings from a YAML file.
  If no file is specified, uses the default config file location.
  The entire YAML file is converted to JSON and sent to the Config API.

YAML FILE FORMAT:
  bito_access_key: ${BITO_API_KEY}
  integration:
    git:
      provider: ${GIT_PROVIDER}
      access_token: ${GIT_ACCESS_TOKEN}
  repository:
    repo_limit: 200
    repo_size_limit: "2GB"
    configured_repos:
      - namespace: "your-org/your-repo"
      - namespace: "another-org/another-repo"
  # Optional: LLM configuration
  # llm:
  #   providers:
  #     openai:
  #       model: "gpt-4"
  #       api_key: "${OPENAI_KEY}"

EXAMPLES:
  bitoarch update-repos                           # Uses default config location
  bitoarch update-repos /path/to/custom-config.yaml  # Use custom path if needed

NOTES:
  - File path is optional - defaults to standard config location
  - This is a PUT operation - performs full configuration update
  - Entire YAML file is converted to JSON generically 
  - Environment variables are automatically substituted from .env-bitoarch
  - API accepts JSON with Content-Type: application/json
  - Requires 'jq' and 'yq' (or python3 with PyYAML) for parsing
EOF
        return 0
    fi
    
    # If no file specified, use default from path-manager
    if [ -z "$yaml_file" ]; then
        if type get_repo_config_file >/dev/null 2>&1; then
            yaml_file=$(get_repo_config_file)
            log_silent "Using default config file: $yaml_file"
        else
            print_error "Cannot determine default config file location"
            print_info "Please specify the config file path explicitly"
            return 1
        fi
    fi

    # Validate file exists and is readable
    if [ ! -f "$yaml_file" ]; then
        print_error "Config file not found: $yaml_file"
        print_info "Please create the configuration file or specify a valid path"
        return 1
    fi

    if [ ! -r "$yaml_file" ]; then
        print_error "Cannot read config file: $yaml_file"
        print_info "Check file permissions"
        return 1
    fi
    
    # Verify we have jq for JSON processing
#    if ! require_command jq; then
#        print_error "jq is required for this operation"
#        print_info "Install jq: brew install jq (macOS) or apt-get install jq (Ubuntu)"
#        return 1
#    fi

    local json_data
#    json_data=$(build_cis_config_json  "$yaml_file")

    # ---- ENV validation --------------------------------------------------
    if [ -z "$BITO_API_KEY" ]; then
        print_error "BITO_API_KEY missing in environment"
        return 1
    fi

    # ---- Git integration JSON -------------------------------------------
    local git_raw_json
    git_raw_json=$(create_git_integration_json)
    if [ $? -ne 0 ] || [ -z "$git_raw_json" ]; then
        print_error "Failed generating Git integration JSON"
        return 1
    fi

    local git_json
    git_json=$(echo "$git_raw_json" | jq '.integration.git')


    # ---- LLM integration JSON -------------------------------------------
    local llm_raw_json
    llm_raw_json=$(create_llm_integration_json)
    if [ $? -ne 0 ] || [ -z "$llm_raw_json" ]; then
        print_error "Failed generating LLM provider JSON"
        return 1
    fi

    local llm_json
    llm_json=$(echo "$llm_raw_json" | jq '.llm')

    # ---- Scheduler config JSON ------------------------------------------
    local scheduler_json
    scheduler_json=$(create_scheduler_config_json)

    # ---- Extract configured repos ---------------------------------------
    local repos_json

    # Try yq first, fallback to python if not available
    if command -v yq >/dev/null 2>&1; then
        # Validate YAML syntax first
        if ! yq eval '.' "$yaml_file" >/dev/null 2>&1; then
            print_error "Invalid YAML syntax in $yaml_file"
            print_info "Please fix YAML syntax errors and try again"
            return 1
        fi

        # Check if the file has the required structure
        local has_structure=$(yq eval 'has("repository")' "$yaml_file" 2>/dev/null)
        if [ "$has_structure" != "true" ]; then
            print_error "Invalid config file structure: missing 'repository' key in $yaml_file"
            return 1
        fi

        repos_json=$(yq -o=json '.repository.configured_repos // []' "$yaml_file")
    elif command -v python3 >/dev/null 2>&1 && python3 -c "import yaml" 2>/dev/null; then
        # Validate YAML syntax first
        local validation_error
        validation_error=$(python3 -c "import yaml, sys; yaml.safe_load(open(sys.argv[1]))" "$yaml_file" 2>&1)
        if [ $? -ne 0 ]; then
            print_error "Invalid YAML syntax in $yaml_file"
            print_info "Error: $validation_error"
            return 1
        fi

        # Check if the file has the required structure
        local has_structure=$(python3 -c "import yaml, sys; data=yaml.safe_load(open(sys.argv[1])); print('true' if isinstance(data, dict) and 'repository' in data else 'false')" "$yaml_file" 2>/dev/null)
        if [ "$has_structure" != "true" ]; then
            print_error "Invalid config file structure: missing 'repository' key in $yaml_file"
            return 1
        fi

        repos_json=$(python3 -c "import yaml, json, sys; data=yaml.safe_load(open(sys.argv[1])); print(json.dumps(data.get('repository', {}).get('configured_repos', [])))" "$yaml_file" 2>/dev/null)
    else
        print_error "YAML processing tool not found"
        print_error "Please install either:"
        print_info "  • yq: https://github.com/mikefarah/yq#install"
        print_info "  • python3 with PyYAML: pip3 install PyYAML"
        return 1
    fi

    if [ -z "$repos_json" ] || [ "$repos_json" = "null" ]; then
        print_error "Failed reading repository.configured_repos from $yaml_file"
        return 1
    fi

    # Normalize: convert plain string → {"namespace": "..."}
    repos_json=$(echo "$repos_json" | jq '
        map(
            if type=="string" then { "namespace": . }
            else .
            end
        )
    ')

    # ---- Build final JSON payload ----------------------------------------
    local json_data
    if [ -n "$scheduler_json" ] && [ "$scheduler_json" != "null" ]; then
        json_data=$(jq -n \
            --arg access "$BITO_API_KEY" \
            --argjson git "$git_json" \
            --argjson llm "$llm_json" \
            --argjson repos "$repos_json" \
            --argjson scheduler "$scheduler_json" \
            '
            {
                bito_access_key: $access,
                integration: { git: $git },
                repository: { configured_repos: $repos },
                llm: $llm,
                scheduler: $scheduler
            }
            '
        )
    else
        json_data=$(jq -n \
            --arg access "$BITO_API_KEY" \
            --argjson git "$git_json" \
            --argjson llm "$llm_json" \
            --argjson repos "$repos_json" \
            '
            {
                bito_access_key: $access,
                integration: { git: $git },
                repository: { configured_repos: $repos },
                llm: $llm
            }
            '
        )
    fi

    if [ $? -ne 0 ] || [ -z "$json_data" ]; then
        print_error "Failed to build repository configuration JSON"
        return 1
    fi

    # Get config external port from environment (default to 5003)
    local CONFIG_PORT="${CIS_CONFIG_EXTERNAL_PORT:-5003}"
    local CONFIG_URL="${CONFIG_URL:-http://localhost:${CONFIG_PORT}}"

    print_info "Updating configuration at ${CONFIG_URL}..."

    # Send JSON to API with Bearer authentication using PUT method
    local response=$(curl -s -w '\n%{http_code}' \
        -X PUT \
        -H "Authorization: Bearer $BITO_API_KEY" \
        -H "Content-Type: application/json" \
        -d "$json_data" \
        "${CONFIG_URL}/api/v1/config" 2>&1)
    
    # Extract HTTP code from last line (silently to prevent leakage to stdout)
    local http_code=$(echo "$response" | tail -1 2>/dev/null)
    local body=$(echo "$response" | sed '$d' 2>/dev/null)
    
    # Use render functions for output
    if [ "$http_code" -ge 200 ] && [ "$http_code" -lt 300 ]; then
        # Backup successfully applied configuration
        backup_config_file "$yaml_file" "repo-config" >/dev/null 2>&1 || true
        
        render_config_add_success_block "$body" "$show_raw"
        _persist_workspace_id_from_response "$body"
        render_config_add_next_steps
        return 0
    else
        render_config_add_failure_block "$http_code" "$body"
        return 1
    fi
}


# Validate repository configuration
config_repo_validate() {
    local repo_name="$1"
    
    if [ -z "$repo_name" ]; then
        print_error "Usage: ${YELLOW}bitoarch validate-repo <repo-name>${NC}"
        return 1
    fi
    
    print_info "Validating configuration for '$repo_name'..."
    
    # Make API call
    local response=$(config_api_call "POST" "/api/v1/config/repositories/${repo_name}/validate")
    if [ $? -ne 0 ]; then
        return 1
    fi
    
    # Parse validation result
    if require_command jq; then
        local valid=$(echo "$response" | jq -r '.valid // false')
        if [ "$valid" = "true" ]; then
            print_success "Configuration is valid"
        else
            print_error "Configuration validation failed"
            echo "$response" | jq -r '.errors[] | "  • \(.)"'
            return 1
        fi
    else
        echo "$response"
    fi
}

# Add repositories from YAML file (generic YAML to JSON conversion)
config_repo_add_from_file() {
    local yaml_file=""
    local show_raw=false

    # Parse options
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --help|-h)
                yaml_file="--help"
                shift
                ;;
            --raw)
                show_raw=true
                shift
                ;;
            *)
                if [ -z "$yaml_file" ] || [ "$yaml_file" = "--help" ]; then
                    yaml_file="$1"
                fi
                shift
                ;;
        esac
    done

    if [ "$yaml_file" = "--help" ]; then
        cat << 'EOF'
USAGE:
  bitoarch add-repos [yaml-file]

DESCRIPTION:
  Configure AI Architect with repository settings from a YAML file.
  If no file is specified, uses the default config file location.
  The entire YAML file is converted to JSON and sent to the Config API.
  Environment variables in the YAML file (${VARIABLE}) are automatically replaced.

YAML FILE FORMAT:
  repository:
    configured_repos:
      - namespace: "your-org/your-repo"
      - namespace: "another-org/another-repo"

ENV PROPERTIES:
  - Update git properties from env file
  - Update llm properties from llm config env file

EXAMPLES:
  bitoarch add-repos                              # Uses default config location
  bitoarch add-repos /path/to/custom-config.yaml  # Use custom path if needed

NOTES:
  - File path is optional - defaults to standard config location
  - Entire YAML file is converted to JSON generically (no field-specific code)
  - Environment variables are automatically substituted from .env-bitoarch
  - API accepts JSON with Content-Type: application/json
  - Requires 'jq' and 'yq' (or python3 with PyYAML) for parsing
EOF
        return 0
    fi

    # If no file specified, use default from path-manager
    if [ -z "$yaml_file" ]; then
        if type get_repo_config_file >/dev/null 2>&1; then
            yaml_file=$(get_repo_config_file)
            log_silent "Using default config file: $yaml_file"
        else
            print_error "Cannot determine default config file location"
            print_info "Please specify the config file path explicitly"
            return 1
        fi
    fi

    # Validate file exists and is readable
    if [ ! -f "$yaml_file" ]; then
        print_error "Config file not found: $yaml_file"
        print_info "Please create the configuration file or specify a valid path"
        return 1
    fi

    if [ ! -r "$yaml_file" ]; then
        print_error "Cannot read config file: $yaml_file"
        print_info "Check file permissions"
        return 1
    fi

#    Verify we have jq for JSON processing
#    if ! require_command jq; then
#        print_error "jq is required for this operation"
#        print_info "Install jq: brew install jq (macOS) or apt-get install jq (Ubuntu)"
#        return 1
#    fi

    local json_data
#    json_data=$(build_cis_config_json  "$yaml_file")

    # ---- ENV validation --------------------------------------------------
    if [ -z "$BITO_API_KEY" ]; then
        print_error "BITO_API_KEY missing in environment"
        return 1
    fi

    # ---- Git integration JSON -------------------------------------------
    local git_raw_json
    git_raw_json=$(create_git_integration_json)
    if [ $? -ne 0 ] || [ -z "$git_raw_json" ]; then
        print_error "Failed generating Git integration JSON"
        return 1
    fi

    local git_json
    git_json=$(echo "$git_raw_json" | jq '.integration.git')

    # ---- LLM integration JSON -------------------------------------------
    local llm_raw_json
    llm_raw_json=$(create_llm_integration_json)
    if [ $? -ne 0 ] || [ -z "$llm_raw_json" ]; then
        print_error "Failed generating LLM provider JSON"
        return 1
    fi

    local llm_json
    llm_json=$(echo "$llm_raw_json" | jq '.llm')

    # ---- Scheduler config JSON ------------------------------------------
    local scheduler_json
    scheduler_json=$(create_scheduler_config_json)

    # ---- Extract configured repos ---------------------------------------
    local repos_json

    # Try yq first, fallback to python if not available
    if command -v yq >/dev/null 2>&1; then
        # Validate YAML syntax first
        if ! yq eval '.' "$yaml_file" >/dev/null 2>&1; then
            print_error "Invalid YAML syntax in $yaml_file"
            print_info "Please fix YAML syntax errors and try again"
            return 1
        fi

        # Check if the file has the required structure
        local has_structure=$(yq eval 'has("repository")' "$yaml_file" 2>/dev/null)
        if [ "$has_structure" != "true" ]; then
            print_error "Invalid config file structure: missing 'repository' key in $yaml_file"
            return 1
        fi

        repos_json=$(yq -o=json '.repository.configured_repos // []' "$yaml_file")
    elif command -v python3 >/dev/null 2>&1 && python3 -c "import yaml" 2>/dev/null; then
        # Validate YAML syntax first
        local validation_error
        validation_error=$(python3 -c "import yaml, sys; yaml.safe_load(open(sys.argv[1]))" "$yaml_file" 2>&1)
        if [ $? -ne 0 ]; then
            print_error "Invalid YAML syntax in $yaml_file"
            print_info "Error: $validation_error"
            return 1
        fi

        # Check if the file has the required structure
        local has_structure=$(python3 -c "import yaml, sys; data=yaml.safe_load(open(sys.argv[1])); print('true' if isinstance(data, dict) and 'repository' in data else 'false')" "$yaml_file" 2>/dev/null)
        if [ "$has_structure" != "true" ]; then
            print_error "Invalid config file structure: missing 'repository' key in $yaml_file"
            return 1
        fi

        repos_json=$(python3 -c "import yaml, json, sys; data=yaml.safe_load(open(sys.argv[1])); print(json.dumps(data.get('repository', {}).get('configured_repos', [])))" "$yaml_file" 2>/dev/null)
    else
        print_error "YAML processing tool not found"
        print_error "Please install either:"
        print_info "  • yq: https://github.com/mikefarah/yq#install"
        print_info "  • python3 with PyYAML: pip3 install PyYAML"
        return 1
    fi

    if [ -z "$repos_json" ] || [ "$repos_json" = "null" ]; then
        print_error "Failed reading repository.configured_repos from $yaml_file"
        return 1
    fi

    # Normalize: convert plain string → {"namespace": "..."}
    repos_json=$(echo "$repos_json" | jq '
        map(
            if type=="string" then { "namespace": . }
            else .
            end
        )
    ')

    # ---- Build final JSON payload ----------------------------------------
    local json_data
    if [ -n "$scheduler_json" ] && [ "$scheduler_json" != "null" ]; then
        json_data=$(jq -n \
            --arg access "$BITO_API_KEY" \
            --argjson git "$git_json" \
            --argjson llm "$llm_json" \
            --argjson repos "$repos_json" \
            --argjson scheduler "$scheduler_json" \
            '
            {
                bito_access_key: $access,
                integration: { git: $git },
                repository: { configured_repos: $repos },
                llm: $llm,
                scheduler: $scheduler
            }
            '
        )
    else
        json_data=$(jq -n \
            --arg access "$BITO_API_KEY" \
            --argjson git "$git_json" \
            --argjson llm "$llm_json" \
            --argjson repos "$repos_json" \
            '
            {
                bito_access_key: $access,
                integration: { git: $git },
                repository: { configured_repos: $repos },
                llm: $llm
            }
            '
        )
    fi

    if [ $? -ne 0 ] || [ -z "$json_data" ]; then
        print_error "Failed to build repository configuration JSON"
        return 1
    fi

    local CONFIG_PORT="${CIS_CONFIG_EXTERNAL_PORT:-5003}"
    local CONFIG_URL="${CONFIG_URL:-http://localhost:${CONFIG_PORT}}"

    log_silent "Sending configuration to ${CONFIG_URL}..."

    # Send JSON to API with Bearer authentication
    local response=$(curl -s -w '\n%{http_code}' \
        -X POST \
        -H "Authorization: Bearer $BITO_API_KEY" \
        -H "Content-Type: application/json" \
        -d "$json_data" \
        "${CONFIG_URL}/api/v1/config" 2>&1)

    # Extract HTTP code from last line
    local http_code=$(echo "$response" | tail -1)
    local body=$(echo "$response" | sed '$d')

    # Use render functions for output
    if [ "$http_code" -ge 200 ] && [ "$http_code" -lt 300 ]; then
        # Backup successfully applied configuration
        backup_config_file "$yaml_file" "repo-config" >/dev/null 2>&1 || true
        
        render_config_add_success_block "$body" "$show_raw"
        _persist_workspace_id_from_response "$body"
        render_config_add_next_steps
        return 0
    else
        render_config_add_failure_block "$http_code" "$body"
        return 1
    fi
}

# Add repositories from YAML file (generic YAML to JSON conversion)
config_repo_add_from_file_from_setup() {
    local yaml_file=""
    local show_raw=false
    
    # Parse options
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --help|-h)
                yaml_file="--help"
                shift
                ;;
            --raw)
                show_raw=true
                shift
                ;;
            *)
                if [ -z "$yaml_file" ] || [ "$yaml_file" = "--help" ]; then
                    yaml_file="$1"
                fi
                shift
                ;;
        esac
    done
    
    # If the filename is just the default name, resolve it using path-manager
    if [ "$yaml_file" = ".bitoarch-config.yaml" ]; then
        # Source path-manager if not already loaded
        if ! type get_repo_config_file >/dev/null 2>&1; then
            if [ -n "$SCRIPT_DIR" ]; then
                source "${SCRIPT_DIR}/scripts/lib/path-manager.sh" 2>/dev/null || true
            else
                source "$(dirname "${BASH_SOURCE[0]}")/../path-manager.sh" 2>/dev/null || true
            fi
        fi
        
        if type get_repo_config_file >/dev/null 2>&1; then
            yaml_file=$(get_repo_config_file)
            log_silent "Resolved config file to: $yaml_file"
        fi
    fi
    
    if [ "$yaml_file" = "--help" ] || [ -z "$yaml_file" ]; then
        cat << 'EOF'
USAGE:
  bitoarch add-repos <yaml-file>

DESCRIPTION:
  Configure AI Architect with repository settings from a YAML file.
  The entire YAML file is converted to JSON and sent to the Config API.
  Environment variables in the YAML file (${VARIABLE}) are automatically replaced.

YAML FILE FORMAT:
  repository:
    configured_repos:
      - namespace: "your-org/your-repo"
      - namespace: "another-org/another-repo"

ENV PROPERTIES:
  - Update git properties from env file
  - Update llm propertied from llm config env file

EXAMPLES:
  bitoarch add-repos                              # Uses default config location
  bitoarch add-repos /path/to/custom-config.yaml  # Use custom path if needed

NOTES:
  - Entire YAML file is converted to JSON generically (no field-specific code)
  - Environment variables are automatically substituted from .env-bitoarch
  - API accepts JSON with Content-Type: application/json
  - Requires 'jq' and 'yq' (or python3 with PyYAML) for parsing
  - See .bitoarch-config.yaml for complete example
EOF
        return 0
    fi
    
    if [ ! -f "$yaml_file" ]; then
        print_error "YAML file not found: $yaml_file"
        return 1
    fi
    
#    Verify we have jq for JSON processing
#    if ! require_command jq; then
#        print_error "jq is required for this operation"
#        print_info "Install jq: brew install jq (macOS) or apt-get install jq (Ubuntu)"
#        return 1
#    fi
    
    local json_data
#    json_data=$(build_cis_config_json  "$yaml_file")

    # ---- ENV validation --------------------------------------------------
    if [ -z "$BITO_API_KEY" ]; then
        log_silent "BITO_API_KEY missing in environment"
        return 1
    fi

    # ---- Git integration JSON -------------------------------------------
    local git_raw_json
    git_raw_json=$(create_git_integration_json)
    if [ $? -ne 0 ] || [ -z "$git_raw_json" ]; then
        log_silent "Failed generating Git integration JSON"
        return 1
    fi

    local git_json
    git_json=$(echo "$git_raw_json" | jq '.integration.git')


    # ---- LLM integration JSON -------------------------------------------
    local llm_raw_json
    llm_raw_json=$(create_llm_integration_json)
    if [ $? -ne 0 ] || [ -z "$llm_raw_json" ]; then
        log_silent "Failed generating LLM provider JSON"
        return 1
    fi

    local llm_json
    llm_json=$(echo "$llm_raw_json" | jq '.llm')

    # ---- Scheduler config JSON ------------------------------------------
    local scheduler_json
    scheduler_json=$(create_scheduler_config_json)

    # ---- Extract configured repos ---------------------------------------
    local repos_json

    # Try yq first, fallback to python if not available
    if command -v yq >/dev/null 2>&1; then
        repos_json=$(yq -o=json '.repository.configured_repos // []' "$yaml_file")
    elif command -v python3 >/dev/null 2>&1 && python3 -c "import yaml" 2>/dev/null; then
        repos_json=$(python3 -c "import yaml, json, sys; data=yaml.safe_load(open(sys.argv[1])); print(json.dumps(data.get('repository', {}).get('configured_repos', [])))" "$yaml_file" 2>/dev/null)
    else
        log_silent "YAML processing tool not found - need yq or python3+PyYAML"
        return 1
    fi

    if [ -z "$repos_json" ] || [ "$repos_json" = "null" ]; then
        log_silent "Failed reading repository.configured_repos from $yaml_file"
        return 1
    fi

    # Normalize: convert plain string → {"namespace": "..."}
    repos_json=$(echo "$repos_json" | jq '
        map(
            if type=="string" then { "namespace": . }
            else .
            end
        )
    ')
    log_silent "Configured repo details: $repos_json"

    # ---- Build final JSON payload ----------------------------------------
    local json_data
    if [ -n "$scheduler_json" ] && [ "$scheduler_json" != "null" ]; then
        json_data=$(jq -n \
            --arg access "$BITO_API_KEY" \
            --argjson git "$git_json" \
            --argjson llm "$llm_json" \
            --argjson repos "$repos_json" \
            --argjson scheduler "$scheduler_json" \
            '
            {
                bito_access_key: $access,
                integration: { git: $git },
                repository: { configured_repos: $repos },
                llm: $llm,
                scheduler: $scheduler
            }
            '
        )
    else
        json_data=$(jq -n \
            --arg access "$BITO_API_KEY" \
            --argjson git "$git_json" \
            --argjson llm "$llm_json" \
            --argjson repos "$repos_json" \
            '
            {
                bito_access_key: $access,
                integration: { git: $git },
                repository: { configured_repos: $repos },
                llm: $llm
            }
            '
        )
    fi

    if [ $? -ne 0 ] || [ -z "$json_data" ]; then
        print_error "Failed to build repository configuration JSON"
        return 1
    fi
    
    local CONFIG_PORT="${CIS_CONFIG_EXTERNAL_PORT:-5003}"
    local CONFIG_URL="${CONFIG_URL:-http://localhost:${CONFIG_PORT}}"
    
    log_silent "Sending configuration to ${CONFIG_URL}..."
    
    # Try POST first (for initial setup)
    local response=$(curl -s -w '\n%{http_code}' \
        -X POST \
        -H "Authorization: Bearer $BITO_API_KEY" \
        -H "Content-Type: application/json" \
        -d "$json_data" \
        "${CONFIG_URL}/api/v1/config" 2>&1)
    
    # Extract HTTP code from last line
    local http_code=$(echo "$response" | tail -1)
    local body=$(echo "$response" | sed '$d')
    
    # If config already exists (HTTP 500), retry with PUT (update)
    if [ "$http_code" = "500" ] && echo "$body" | grep -qi "config already exists"; then
        log_silent "Config exists, retrying with PUT (update) method..."
        
        response=$(curl -s -w '\n%{http_code}' \
            -X PUT \
            -H "Authorization: Bearer $BITO_API_KEY" \
            -H "Content-Type: application/json" \
            -d "$json_data" \
            "${CONFIG_URL}/api/v1/config" 2>&1)
        
        # Extract HTTP code from last line
        http_code=$(echo "$response" | tail -1)
        body=$(echo "$response" | sed '$d')
    fi

    log_silent "Configuration sent to ${CONFIG_URL} with HTTP $http_code"
    
    # Use render functions for output
    if [ "$http_code" -ge 200 ] && [ "$http_code" -lt 300 ]; then
        # Backup successfully applied configuration. Redirect stdout too --
        # backup_config_file echoes the path for callers that capture it; this
        # caller doesn't, so the bare stdout would leak the backup path into
        # the user-facing output.
        if command -v backup_config_file >/dev/null 2>&1; then
            backup_config_file "$yaml_file" "repo-config" >/dev/null 2>&1 || log_silent "Warning: Backup failed"
            log_silent "Configuration backup attempted"
        fi
        
        render_config_add_success_block "$body" "$show_raw"
        _persist_workspace_id_from_response "$body"
        return 0
    else
        render_config_add_failure_block "$http_code" "$body"
        return 1
    fi
}

# Add single repository by namespace
config_repo_add_namespace() {
    local namespace="$1"
    
    # Parse options
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --help|-h)
                cat << 'EOF'
USAGE:
  bitoarch add-repo <namespace>

DESCRIPTION:
  Add a single repository to the configured repositories list.
  Uses the API endpoint to add the repository by namespace and updates the local .bitoarch-config.yaml file.

ARGUMENTS:
  namespace    Repository namespace in format: org/repo

EXAMPLE:
  bitoarch add-repo myorg/myrepo

NOTES:
  - Requires BITO_API_KEY to be set in environment
  - Repository will be added to existing configuration
  - Updates both API and local .bitoarch-config.yaml file
  - Use 'bitoarch show-config' to verify changes
EOF
                return 0
                ;;
            *)
                namespace="$1"
                shift
                ;;
        esac
    done
    
    if [ -z "$namespace" ]; then
        print_error "Usage: ${YELLOW}bitoarch add-repo <namespace>${NC}"
        echo ""
        echo -e "Example: ${YELLOW}bitoarch add-repo myorg/myrepo${NC}"
        return 1
    fi
    
    # Validate namespace format
    if ! [[ "$namespace" =~ ^[a-zA-Z0-9_-]+/[a-zA-Z0-9_.-]+$ ]]; then
        print_error "Invalid namespace format. Expected: org/repo"
        echo ""
        echo "Example: myorg/myrepo"
        return 1
    fi
    
    # Get required environment variables
    if [ -z "$BITO_API_KEY" ]; then
        print_error "BITO_API_KEY not found in environment"
        return 1
    fi
    
    # Get config external port from environment (default to 5003 which maps to internal 9910)
    local CONFIG_PORT="${CIS_CONFIG_EXTERNAL_PORT:-5003}"
    local CONFIG_URL="${CONFIG_URL:-http://localhost:${CONFIG_PORT}}"
    
    print_info "Adding repository '${namespace}'..."
    
    # Create JSON payload
    local json_payload=$(jq -n \
        --arg ns "$namespace" \
        '{repositories: [{namespace: $ns}]}')
    
    # Make API call (uses raw token without Bearer prefix)
    local response=$(curl -s -w '\n%{http_code}' \
        -X POST \
        -H "accept: application/json" \
        -H "Content-Type: application/json" \
        -H "Authorization: ${BITO_API_KEY}" \
        -d "$json_payload" \
        "${CONFIG_URL}/api/v1/config/repository/add" 2>&1)
    
    # Extract HTTP code from last line
    local http_code=$(echo "$response" | tail -1)
    local body=$(echo "$response" | sed '$d')
    
    # Check HTTP code and render appropriate output
    if [ "$http_code" -ge 200 ] && [ "$http_code" -lt 300 ]; then
        # API call succeeded, now update local .bitoarch-config.yaml 
        # Source path-manager if not already loaded
        if ! type get_repo_config_file >/dev/null 2>&1; then
            source "${SCRIPT_DIR}/scripts/lib/path-manager.sh" 2>/dev/null || true
        fi
        
        local config_file
        if type get_repo_config_file >/dev/null 2>&1; then
            config_file=$(get_repo_config_file)
        else
            config_file=".bitoarch-config.yaml"
        fi
        
        if [ -f "$config_file" ]; then
            print_info "Updating local .bitoarch-config.yaml file..."
            
            # Check if namespace already exists in .bitoarch-config.yaml 
            local exists=false
            if command -v yq >/dev/null 2>&1; then
                if yq eval ".repository.configured_repos[] | select(.namespace == \"${namespace}\")" "$config_file" 2>/dev/null | grep -q "namespace"; then
                    exists=true
                fi
            elif command -v python3 >/dev/null 2>&1; then
                if python3 -c "import yaml; data=yaml.safe_load(open('$config_file')); print(any(r.get('namespace') == '$namespace' for r in data.get('repository', {}).get('configured_repos', [])))" 2>/dev/null | grep -q "True"; then
                    exists=true
                fi
            fi
            
            if [ "$exists" = "false" ]; then
                # Backup config file before modification
                backup_config_file "$config_file" "repo-config" >/dev/null 2>&1 || true
                
                # Add namespace to .bitoarch-config.yaml 
                if command -v yq >/dev/null 2>&1; then
                    # Use yq to add the namespace
                    yq eval ".repository.configured_repos += [{\"namespace\": \"${namespace}\"}]" -i "$config_file" 2>/dev/null
                    if [ $? -eq 0 ]; then
                        print_success "Updated .bitoarch-config.yaml with new repository"
                    else
                        print_warning "API call succeeded but failed to update .bitoarch-config.yaml automatically"
                        print_info "Please manually add '- namespace: ${namespace}' to .bitoarch-config.yaml "
                    fi
                elif command -v python3 >/dev/null 2>&1; then
                    # Use python to add the namespace
                    python3 << EOF
import yaml
try:
    with open('$config_file', 'r') as f:
        data = yaml.safe_load(f)
    
    if 'repository' not in data:
        data['repository'] = {}
    if 'configured_repos' not in data['repository']:
        data['repository']['configured_repos'] = []
    
    data['repository']['configured_repos'].append({'namespace': '$namespace'})
    
    with open('$config_file', 'w') as f:
        yaml.dump(data, f, default_flow_style=False, sort_keys=False)
    
    print("SUCCESS")
except Exception as e:
    print(f"ERROR: {e}")
EOF
                    if [ $? -eq 0 ]; then
                        print_success "Updated .bitoarch-config.yaml with new repository"
                    else
                        print_warning "API call succeeded but failed to update .bitoarch-config.yaml automatically"
                        print_info "Please manually add '- namespace: ${namespace}' to .bitoarch-config.yaml "
                    fi
                else
                    print_warning "yq or python3 not available - .bitoarch-config.yaml not updated"
                    print_info "Please manually add '- namespace: ${namespace}' to .bitoarch-config.yaml under repository.configured_repos"
                fi
            else
                print_info "Repository already exists in .bitoarch-config.yaml "
            fi
        else
            print_warning ".bitoarch-config.yaml not found - only API updated"
            print_info "Repository added to API but .bitoarch-config.yaml not found for local update"
        fi
        
        render_repo_add_success_block "$namespace" "$body"
        _persist_workspace_id_from_response "$body"
        return 0
    else
        render_repo_add_failure_block "$namespace" "$http_code" "$body"
        return 1
    fi
}

# Remove repository by namespace
config_repo_remove_namespace() {
    local namespace="$1"
    
    # Parse options
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --help|-h)
                cat << 'EOF'
USAGE:
  bitoarch remove-repo <namespace>

DESCRIPTION:
  Remove a repository from the configured repositories list.
  Uses the API endpoint to remove the repository by namespace and updates the local .bitoarch-config.yaml file.

ARGUMENTS:
  namespace    Repository namespace in format: org/repo

EXAMPLE:
  bitoarch remove-repo myorg/myrepo

NOTES:
  - Requires BITO_API_KEY to be set in environment
  - Repository will be removed from configuration
  - Updates both API and local .bitoarch-config.yaml file
  - Use 'bitoarch show-config' to verify changes
EOF
                return 0
                ;;
            *)
                namespace="$1"
                shift
                ;;
        esac
    done
    
    if [ -z "$namespace" ]; then
        print_error "Usage: ${YELLOW}bitoarch remove-repo <namespace>${NC}"
        echo ""
        echo -e "Example: ${YELLOW}bitoarch remove-repo myorg/myrepo${NC}"
        return 1
    fi
    
    # Validate namespace format
    if ! [[ "$namespace" =~ ^[a-zA-Z0-9_-]+/[a-zA-Z0-9_.-]+$ ]]; then
        print_error "Invalid namespace format. Expected: org/repo"
        echo ""
        echo "Example: myorg/myrepo"
        return 1
    fi
    
    # Get required environment variables
    if [ -z "$BITO_API_KEY" ]; then
        print_error "BITO_API_KEY not found in environment"
        return 1
    fi
    
    # Get config external port from environment (default to 5003 which maps to internal 9910)
    local CONFIG_PORT="${CIS_CONFIG_EXTERNAL_PORT:-5003}"
    local CONFIG_URL="${CONFIG_URL:-http://localhost:${CONFIG_PORT}}"
    
    print_info "Removing repository '${namespace}'..."
    
    # Create JSON payload
    local json_payload=$(jq -n \
        --arg ns "$namespace" \
        '{repositories: [{namespace: $ns}]}')
    
    # Make API call (uses raw token without Bearer prefix)
    local response=$(curl -s -w '\n%{http_code}' \
        -X POST \
        -H "accept: application/json" \
        -H "Content-Type: application/json" \
        -H "Authorization: ${BITO_API_KEY}" \
        -d "$json_payload" \
        "${CONFIG_URL}/api/v1/config/repository/remove" 2>&1)
    
    # Extract HTTP code from last line
    local http_code=$(echo "$response" | tail -1)
    local body=$(echo "$response" | sed '$d')
    
    # Check HTTP code and render appropriate output
    if [ "$http_code" -ge 200 ] && [ "$http_code" -lt 300 ]; then
        # API call succeeded, now update local .bitoarch-config.yaml 
        # Source path-manager if not already loaded
        if ! type get_repo_config_file >/dev/null 2>&1; then
            source "${SCRIPT_DIR}/scripts/lib/path-manager.sh" 2>/dev/null || true
        fi
        
        local config_file
        if type get_repo_config_file >/dev/null 2>&1; then
            config_file=$(get_repo_config_file)
        else
            config_file=".bitoarch-config.yaml"
        fi
        
        if [ -f "$config_file" ]; then
            print_info "Updating local .bitoarch-config.yaml file..."
            
            # Check if namespace exists in .bitoarch-config.yaml 
            local exists=false
            if command -v yq >/dev/null 2>&1; then
                if yq eval ".repository.configured_repos[] | select(.namespace == \"${namespace}\")" "$config_file" 2>/dev/null | grep -q "namespace"; then
                    exists=true
                fi
            elif command -v python3 >/dev/null 2>&1; then
                if python3 -c "import yaml; data=yaml.safe_load(open('$config_file')); print(any(r.get('namespace') == '$namespace' for r in data.get('repository', {}).get('configured_repos', [])))" 2>/dev/null | grep -q "True"; then
                    exists=true
                fi
            fi
            
            if [ "$exists" = "true" ]; then
                # Backup config file before modification
                backup_config_file "$config_file" "repo-config" >/dev/null 2>&1 || true
                
                # Remove namespace from .bitoarch-config.yaml 
                if command -v yq >/dev/null 2>&1; then
                    # Use yq to remove the namespace
                    yq eval "del(.repository.configured_repos[] | select(.namespace == \"${namespace}\"))" -i "$config_file" 2>/dev/null
                    if [ $? -eq 0 ]; then
                        print_success "Updated .bitoarch-config.yaml - removed repository"
                    else
                        print_warning "API call succeeded but failed to update .bitoarch-config.yaml automatically"
                        print_info "Please manually remove '- namespace: ${namespace}' from .bitoarch-config.yaml "
                    fi
                elif command -v python3 >/dev/null 2>&1; then
                    # Use python to remove the namespace
                    python3 << EOF
import yaml
try:
    with open('$config_file', 'r') as f:
        data = yaml.safe_load(f)
    
    if 'repository' in data and 'configured_repos' in data['repository']:
        data['repository']['configured_repos'] = [
            r for r in data['repository']['configured_repos']
            if r.get('namespace') != '$namespace'
        ]
    
    with open('$config_file', 'w') as f:
        yaml.dump(data, f, default_flow_style=False, sort_keys=False)
    
    print("SUCCESS")
except Exception as e:
    print(f"ERROR: {e}")
EOF
                    if [ $? -eq 0 ]; then
                        print_success "Updated .bitoarch-config.yaml - removed repository"
                    else
                        print_warning "API call succeeded but failed to update .bitoarch-config.yaml automatically"
                        print_info "Please manually remove '- namespace: ${namespace}' from .bitoarch-config.yaml "
                    fi
                else
                    print_warning "yq or python3 not available - .bitoarch-config.yaml not updated"
                    print_info "Please manually remove '- namespace: ${namespace}' from .bitoarch-config.yaml under repository.configured_repos"
                fi
            else
                print_info "Repository not found in .bitoarch-config.yaml "
            fi
        else
            print_warning ".bitoarch-config.yaml not found - only API updated"
            print_info "Repository removed from API but .bitoarch-config.yaml not found for local update"
        fi
        
        render_repo_remove_success_block "$namespace" "$body"
        _persist_workspace_id_from_response "$body"
        return 0
    else
        render_repo_remove_failure_block "$namespace" "$http_code" "$body"
        return 1
    fi
}

build_cis_config_json() {
    local yaml_file="$1"

    # ---- ENV validation --------------------------------------------------
    if [ -z "$BITO_API_KEY" ]; then
        log_silent "BITO_API_KEY missing in environment"
        return 1
    fi

    # ---- Git integration JSON -------------------------------------------
    local git_raw_json
    git_raw_json=$(create_git_integration_json)
    if [ $? -ne 0 ] || [ -z "$git_raw_json" ]; then
        log_silent "Failed generating Git integration JSON"
        return 1
    fi

    local git_json
    git_json=$(echo "$git_raw_json" | jq '.integration.git')


    # ---- LLM integration JSON -------------------------------------------
    local llm_raw_json
    llm_raw_json=$(create_llm_integration_json)
    if [ $? -ne 0 ] || [ -z "$llm_raw_json" ]; then
        log_silent "Failed generating LLM provider JSON"
        return 1
    fi

    local llm_json
    llm_json=$(echo "$llm_raw_json" | jq '.llm')

    # ---- Scheduler config JSON ------------------------------------------
    local scheduler_json
    scheduler_json=$(create_scheduler_config_json)

    # ---- Extract configured repos ---------------------------------------
    local repos_json

    # Try yq first, fallback to python if not available
    if command -v yq >/dev/null 2>&1; then
        repos_json=$(yq -o=json '.repository.configured_repos // []' "$yaml_file")
    elif command -v python3 >/dev/null 2>&1 && python3 -c "import yaml" 2>/dev/null; then
        repos_json=$(python3 -c "import yaml, json, sys; data=yaml.safe_load(open(sys.argv[1])); print(json.dumps(data.get('repository', {}).get('configured_repos', [])))" "$yaml_file" 2>/dev/null)
    else
        log_silent "YAML processing tool not found - need yq or python3+PyYAML"
        return 1
    fi

    if [ -z "$repos_json" ] || [ "$repos_json" = "null" ]; then
        log_silent "Failed reading repository.configured_repos from $yaml_file"
        return 1
    fi

    # Normalize: convert plain string → {"namespace": "..."}
    repos_json=$(echo "$repos_json" | jq '
        map(
            if type=="string" then { "namespace": . }
            else .
            end
        )
    ')
    log_silent "Configured repo details: $repos_json"

    # ---- Build final JSON payload ----------------------------------------
    local final_json
    if [ -n "$scheduler_json" ] && [ "$scheduler_json" != "null" ]; then
        final_json=$(jq -n \
                --arg access "$BITO_API_KEY" \
                --argjson git $git_json \
                --argjson llm $llm_json \
                --argjson repos $repos_json \
                --argjson scheduler "$scheduler_json" \
                '
                {
                    bito_access_key: $access,
                    integration: { git: $git },
                    repository: { configured_repos: $repos },
                    llm: $llm,
                    scheduler: $scheduler
                }
                '
        )
    else
        final_json=$(jq -n \
                --arg access "$BITO_API_KEY" \
                --argjson git $git_json \
                --argjson llm $llm_json \
                --argjson repos $repos_json \
                '
                {
                    bito_access_key: $access,
                    integration: { git: $git },
                    repository: { configured_repos: $repos },
                    llm: $llm
                }
                '
        )
    fi

    echo $final_json
}

# Utility function to create Git integration JSON from environment variables
create_git_integration_json() {
    # Get Git configuration from environment variables
    local git_provider="${GIT_PROVIDER:-}"
    local git_token="${GIT_ACCESS_TOKEN:-}"
    local git_domain="${GIT_DOMAIN_URL:-}"
    local git_user="${GIT_USER:-}"

    # Validate required environment variables
    if [ -z "$git_provider" ]; then
        print_error "GIT_PROVIDER not found in environment"
        return 1
    fi
    
    if [ -z "$git_token" ]; then
        print_error "GIT_ACCESS_TOKEN not found in environment"
        return 1
    fi
    
    # Create JSON structure using jq
#    if ! require_command jq; then
#        print_error "jq is required for JSON creation"
#        print_info "Install jq: brew install jq (macOS) or apt-get install jq (Ubuntu)"
#        return 1
#    fi
    
    # Build the Git integration JSON
    local git_json
    if [ -n "$git_domain" ]; then
        # Include domain URL if provided
        git_json=$(jq -n \
            --arg provider "$git_provider" \
            --arg token "$git_token" \
            --arg domain "$git_domain" \
            --arg user "$git_user" \
            '{
                "integration": {
                    "git": {
                        "provider": $provider,
                        "access_token": $token,
                        "domain": $domain,
                        "auth_type": "personal_access_token",
                        "username": $user
                    }
                }
            }')
    else
        # Standard structure without domain URL
        git_json=$(jq -n \
            --arg provider "$git_provider" \
            --arg token "$git_token" \
            --arg user "$git_user" \
            '{
                "integration": {
                    "git": {
                        "provider": $provider,
                        "access_token": $token,
                        "auth_type": "personal_access_token",
                        "username": $user
                    }
                }
            }')
    fi
    
    # Validate JSON creation
    if [ $? -ne 0 ] || [ -z "$git_json" ] || [ "$git_json" = "null" ]; then
        log_silent "Failed to create Git integration JSON"
        return 1
    fi
    
    # Output the JSON
    echo "$git_json"
    return 0
}

# Creates LLM integration JSON from environment variables
# Reads LLM_DEFAULT_PROVIDER, ANTHROPIC_API_TOKEN, OPENAI_API_TOKEN, GROK_API_TOKEN
# Returns JSON structure with provider configuration
create_llm_integration_json() {

    # Get LLM configuration from environment
    local default_provider="${LLM_DEFAULT_PROVIDER:-bito}"
    local anthropic_token="${ANTHROPIC_API_TOKEN}"
    local openai_token="${OPENAI_API_TOKEN}"
    local xai_grok_token="${XAI_API_TOKEN}"
    local portkey_token="${PORTKEY_API_TOKEN}"
    local portkey_url="${PORTKEY_API_URL}"
    local portkey_model="${PORTKEY_MODEL_NAME}"
    
#    print_info "Creating LLM integration JSON with default provider: $default_provider"

    # Start building the providers object
    local providers_json="{}"
    
    # Add Anthropic provider if token exists
    if [ -n "$anthropic_token" ]; then
#        print_info "Adding Anthropic provider configuration"
        providers_json=$(echo "$providers_json" | jq --arg token "$anthropic_token" '. + {"anthropic": {"api_key": $token}}')
    fi
    
    # Add OpenAI provider if token exists
    if [ -n "$openai_token" ]; then
#        print_info "Adding OpenAI provider configuration"
        providers_json=$(echo "$providers_json" | jq --arg token "$openai_token" '. + {"openai": {"api_key": $token}}')
    fi
    
    # Add Grok provider if token exists
    if [ -n "$xai_grok_token" ]; then
#        print_info "Adding Grok provider configuration"
        providers_json=$(echo "$providers_json" | jq --arg token "$xai_grok_token" '. + {"xai": {"api_key": $token}}')
    fi
    
    # Add Portkey provider if token exists
    if [ -n "$portkey_token" ]; then
        providers_json="{}"
        providers_json=$(echo "$providers_json" | jq --arg token "$portkey_token" --arg url "$portkey_url" --arg model "$portkey_model" '. + {"portkey": {"api_key": $token, "api_url": $url, "model": $model}}')
    fi
    
    # Create the final LLM JSON structure
    local llm_json
    llm_json=$(jq -n \
        --arg default_provider "$default_provider" \
        --argjson providers "$providers_json" \
        '{
            "llm": {
                "provider_configured": $default_provider,
                "providers": $providers
            }
        }')
    
    # Validate JSON creation
    if [ $? -ne 0 ] || [ -z "$llm_json" ] || [ "$llm_json" = "null" ]; then
        log_silent "Failed to create LLM integration JSON"
        return 1
    fi
    
    # Output the JSON
    echo "$llm_json"
    return 0
}

# Creates Scheduler configuration JSON from environment variables
# Reads CIS_SCHEDULER_ENABLED, SCHEDULER_BASIC_INDEX_INTERVAL, SCHEDULER_INDEX_INTERVAL
# Returns JSON structure with scheduler task configurations
create_scheduler_config_json() {
    local scheduler_enabled="${CIS_SCHEDULER_ENABLED:-true}"
    local basic_index_interval="${SCHEDULER_BASIC_INDEX_INTERVAL:-24h}"
    local ai_index_interval="${SCHEDULER_INDEX_INTERVAL:-7d}"

    # Only include scheduler config if enabled
    if [ "$scheduler_enabled" != "true" ]; then
        echo "null"
        return 0
    fi

    local scheduler_json
    scheduler_json=$(jq -n \
        --arg basic_interval "$basic_index_interval" \
        --arg ai_interval "$ai_index_interval" \
        '{
            "tasks": [
                {
                    "task_type": "basic_index",
                    "enabled": true,
                    "interval_expression": $basic_interval
                },
                {
                    "task_type": "ai_index",
                    "enabled": true,
                    "interval_expression": $ai_interval
                }
            ]
        }')

    if [ $? -ne 0 ] || [ -z "$scheduler_json" ] || [ "$scheduler_json" = "null" ]; then
        log_silent "Failed to create Scheduler config JSON"
        return 1
    fi

    echo "$scheduler_json"
    return 0
}

# Export functions
# Git Repositories API call
# Calls the /api/v1/git/repositories endpoint with environment variables
# TODO: not using it, due to log and console print message.
git_repositories_api() {
    log_silent "Calling Git Repositories API..."
    
    # Source environment variables
#    source_env_file
    
    # Check for required environment variables
    if [ -z "$GIT_PROVIDER" ]; then
        print_error "GIT_PROVIDER environment variable is required"
        return 1
    fi
    
    if [ -z "$GIT_ACCESS_TOKEN" ]; then
        print_error "GIT_ACCESS_TOKEN environment variable is required"
        return 1
    fi
    
    if [ -z "$BITO_API_KEY" ]; then
        print_error "BITO_API_KEY environment variable is required"
        return 1
    fi
    
    # Check if jq is available
    if ! command -v jq >/dev/null 2>&1; then
        print_error "jq is required but not installed. Please install jq first."
        print_error "Install with: brew install jq (macOS) or apt-get install jq (Ubuntu)"
        return 1
    fi
    
    # Build configuration URL
    local CONFIG_PORT="${CIS_CONFIG_EXTERNAL_PORT:-5003}"
    local CONFIG_HOST="localhost"
    
    # Detect if running in Kubernetes mode and get node IP
    if [ "${DEPLOYMENT_TYPE}" = "kubernetes" ] && command -v kubectl >/dev/null 2>&1; then
        local NODE_IP=$(kubectl get nodes -o jsonpath='{.items[0].status.addresses[?(@.type=="InternalIP")].address}' 2>/dev/null)
        if [ -n "$NODE_IP" ]; then
            CONFIG_HOST="$NODE_IP"
            log_silent "Detected Kubernetes deployment, using node IP: $NODE_IP"
        else
            log_silent "Could not get Kubernetes node IP, falling back to localhost"
        fi
    fi
    
    local CONFIG_URL="${CONFIG_URL:-http://${CONFIG_HOST}:${CONFIG_PORT}}"
    local API_ENDPOINT="${CONFIG_URL}/api/v1/git/repositories"
    
    # Set domain (empty string if not provided)
    local GIT_DOMAIN="${GIT_DOMAIN_URL:-}"
    
    log_silent "Calling API endpoint: $API_ENDPOINT"
    log_silent "Using provider: $GIT_PROVIDER"
    
    # Build JSON payload using jq
    local json_payload
    json_payload=$(jq -n \
        --arg provider "$GIT_PROVIDER" \
        --arg domain "$GIT_DOMAIN" \
        --arg token "$GIT_ACCESS_TOKEN" \
        --arg username "" \
        '{
            "provider": $provider,
            "domain": $domain,
            "token": $token,
            "username": $username
        }')
    
    if [ $? -ne 0 ]; then
        log_silent "Failed to create JSON payload"
        return 1
    fi
    
    # Make the API call
    local response
    local http_code
    
    response=$(curl -s -w '\n%{http_code}' \
        --location "$API_ENDPOINT" \
        --header "Authorization: Bearer $BITO_API_KEY" \
        --header "Content-Type: application/json" \
        --data "$json_payload" 2>/dev/null)
    
    if [ $? -ne 0 ]; then
        log_silent "Failed to make API call to $API_ENDPOINT"
        return 1
    fi
    
    # Extract HTTP code and response body
    log_silent "Raw response: $response"

    http_code="${response: -3}"
    response_body="${response:0:${#response}-3}"

    log_silent "Body extracted: ${#response_body} bytes"
    
    # Check HTTP status code
    case "$http_code" in
        2*)
            log_silent "Git repositories API call successful (HTTP $http_code) Response: $response_body"
            echo "$response_body" >&2
            return 0
            ;;
        4*)
            log_silent "Client error (HTTP $http_code): $response_body"
            return 1
            ;;
        5*)
            log_silent "Server error (HTTP $http_code): $response_body"
            return 1
            ;;
        *)
            log_silent "Unexpected HTTP status code: $http_code"
            log_silent "Response: $response_body"
            return 1
            ;;
    esac
}


# Create repository configuration YAML from Git repositories API response
create_repo_config_from_api() {
    set +e
    log_silent "Creating repository configuration from Git repositories API..."
    
    # Source environment variables
#    source_env_file

    log_silent "Calling Git Repositories API..."

    # Check for required environment variables
    if [ -z "$GIT_PROVIDER" ]; then
        log_silent "GIT_PROVIDER environment variable is required"
        return 1
    fi

    if [ -z "$GIT_ACCESS_TOKEN" ]; then
        log_silent "GIT_ACCESS_TOKEN environment variable is required"
        return 1
    fi

    if [ -z "$BITO_API_KEY" ]; then
        log_silent "BITO_API_KEY environment variable is required"
        return 1
    fi

    # Check if jq is available
    if ! command -v jq >/dev/null 2>&1; then
        log_silent "jq is required but not installed. Please install jq first."
        log_silent "Install with: brew install jq (macOS) or apt-get install jq (Ubuntu)"
        return 1
    fi

    # Build configuration URL
    local CONFIG_PORT="${CIS_CONFIG_EXTERNAL_PORT:-5003}"
    local CONFIG_URL="${CONFIG_URL:-http://localhost:${CONFIG_PORT}}"
    local API_ENDPOINT="${CONFIG_URL}/api/v1/git/repositories"
    
    # Ensure config service is accessible (sets up port-forward for K8s if needed)
    ensure_config_service_accessible

    # Set domain (empty string if not provided)
    local GIT_DOMAIN="${GIT_DOMAIN_URL:-}"

    log_silent "Calling API endpoint: $API_ENDPOINT"
    log_silent "Using provider: $GIT_PROVIDER"

    # Build JSON payload using jq
    local json_payload
    json_payload=$(jq -n \
        --arg provider "$GIT_PROVIDER" \
        --arg domain "$GIT_DOMAIN" \
        --arg token "$GIT_ACCESS_TOKEN" \
        --arg username "$GIT_USER" \
        '{
            "provider": $provider,
            "domain": $domain,
            "token": $token,
            "username": $username
        }')

    if [ $? -ne 0 ]; then
        log_silent "Failed to create JSON payload"
        return 1
    fi

    # Make the API call
    local response
    local http_code

    response=$(curl -s -w '\n%{http_code}' \
        --location "$API_ENDPOINT" \
        --header "Authorization: $BITO_API_KEY" \
        --header "Content-Type: application/json" \
        --data "$json_payload" 2>/dev/null)

    if [ $? -ne 0 ]; then
        log_silent "Failed to make API call to $API_ENDPOINT"
        return 1
    fi

    # Extract HTTP code and response body
    log_silent "Raw response: $response"

    http_code="${response: -3}"
    response_body="${response:0:${#response}-3}"

    log_silent "Body extracted: ${#response_body} bytes"

    # Check HTTP status code
    case "$http_code" in
        2*)
            log_silent "Git repositories API call successful (HTTP $http_code) Response: $response_body"
            ;;
        4*)
            log_silent "Client error (HTTP $http_code): $response_body"
            ;;
        5*)
            log_silent "Server error (HTTP $http_code): $response_body"
            ;;
        *)
            log_silent "Unexpected HTTP status code: $http_code"
            log_silent "Response: $response_body"
            ;;
    esac
    
    # Call the Git repositories API
    local api_response
#    api_response=$(git_repositories_api)
    api_response=$response_body


    log_silent "API response: $api_response"
    
    if [ $? -ne 0 ]; then
        print_error "Failed to get repositories from API"
        return 1
    fi
    
    # Check if jq is available
    if ! command -v jq >/dev/null 2>&1; then
        log_silent "jq is required but not installed. Please install jq first."
        log_silent "Install with: brew install jq (macOS) or apt-get install jq (Ubuntu)"
        return 1
    fi
    
    # Parse the API response and validate structure
    local success
    success=$(echo "$api_response" | jq -r '.success // false' 2>/dev/null)
    
    if [ "$success" != "true" ]; then
        log_silent "API response indicates failure or invalid JSON structure"
        log_silent "Response: $api_response"
        return 1
    fi

    log_silent "API response indicates success"

    # Extract repositories array
    local repositories
    repositories=$(echo "$api_response" | jq -r '.repositories // []' 2>/dev/null)
    
    if [ "$repositories" = "[]" ] || [ "$repositories" = "null" ]; then
        log_warn "No repositories found in API response"
        repositories="[]"
    fi
    
    # Count repositories
    local repo_count
    repo_count=$(echo "$repositories" | jq 'length' 2>/dev/null)
    
    log_silent "Found $repo_count repositories to configure"
    
    # Get config file location using path-manager
    # Source path-manager if not already loaded
    if ! type get_repo_config_file >/dev/null 2>&1; then
        if [ -n "$SCRIPT_DIR" ]; then
            source "${SCRIPT_DIR}/scripts/lib/path-manager.sh" 2>/dev/null || true
        else
            source "$(dirname "${BASH_SOURCE[0]}")/../path-manager.sh" 2>/dev/null || true
        fi
    fi
    
    local config_file
    if type get_repo_config_file >/dev/null 2>&1; then
        config_file=$(get_repo_config_file)
    else
        config_file=".bitoarch-config.yaml"
    fi
    
    log_silent "Creating config file at: $config_file"

    # Build the complete YAML content in memory
    yaml_content="repository:\n  configured_repos:"

    # Add each repository namespace
    if [ "$repo_count" -gt 0 ]; then
        while IFS= read -r full_name; do
            if [ -n "$full_name" ]; then
                yaml_content="${yaml_content}\n    - namespace: ${full_name}"
            fi
        done <<< "$(echo "$repositories" | jq -r '.[] | select(.full_name != null) | .full_name')"
    else
        # Add empty array on same line
        yaml_content="${yaml_content}: []"
    fi

    # Write the complete content in one step using printf to preserve newlines
    printf "%b\n" "$yaml_content" > "$config_file"
    
    # Verify file was created successfully
    if [ -f "$config_file" ]; then
        log_silent "Successfully created $config_file with $repo_count repositories"
        echo ""
        print_info "$repo_count repositories added for indexing"
        log_silent "Repo config written to: $config_file"
        echo ""

        # Show the generated content
        log_silent "Generated configuration:"
#        cat "$config_file"

        return 0
    else
        log_silent "Failed to create $config_file"
        return 1
    fi
    set -e
}


fetch_repo_config_from_api() {
    set +e
    log_silent "Creating repository configuration from Git repositories API..."
    echo "⏳ Getting the repository list from your git account... (this may take 30–50 seconds)"
     # Parse arguments for force-load flag
    local force_load="false"
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --force-load)
                force_load="true"
                shift
                ;;
            *)
                # Unknown option, just ignore
                shift
                ;;
        esac
    done

    # Source environment variables
#    source_env_file

    log_silent "Calling Git Repositories API..."

    # Check for required environment variables
    if [ -z "$GIT_PROVIDER" ]; then
        log_silent "GIT_PROVIDER environment variable is required"
        return 1
    fi

    if [ -z "$GIT_ACCESS_TOKEN" ]; then
        log_silent "GIT_ACCESS_TOKEN environment variable is required"
        return 1
    fi

    if [ -z "$BITO_API_KEY" ]; then
        log_silent "BITO_API_KEY environment variable is required"
        return 1
    fi

    # Check if jq is available
    if ! command -v jq >/dev/null 2>&1; then
        log_silent "jq is required but not installed. Please install jq first."
        log_silent "Install with: brew install jq (macOS) or apt-get install jq (Ubuntu)"
        return 1
    fi

    # Build configuration URL
    local CONFIG_PORT="${CIS_CONFIG_EXTERNAL_PORT:-5003}"
    local CONFIG_URL="${CONFIG_URL:-http://localhost:${CONFIG_PORT}}"
    local API_ENDPOINT="${CONFIG_URL}/api/v1/git/repositories"

    # Add force_load parameter if specified
    if [ "$force_load" = "true" ]; then
        API_ENDPOINT="${API_ENDPOINT}?force_load=true"
        log_silent "Force loading repositories from git provider"
    fi

    # Ensure config service is accessible (sets up port-forward for K8s if needed)
    ensure_config_service_accessible

    # Set domain (empty string if not provided)
    local GIT_DOMAIN="${GIT_DOMAIN_URL:-}"

    log_silent "Calling API endpoint: $API_ENDPOINT"
    log_silent "Using provider: $GIT_PROVIDER"

    # Build JSON payload using jq
    local json_payload
    json_payload=$(jq -n \
        --arg provider "$GIT_PROVIDER" \
        --arg domain "$GIT_DOMAIN" \
        --arg token "$GIT_ACCESS_TOKEN" \
        --arg username "$GIT_USER" \
        '{
            "provider": $provider,
            "domain": $domain,
            "token": $token,
            "username": $username
        }')

    if [ $? -ne 0 ]; then
        log_silent "Failed to create JSON payload"
        return 1
    fi

    # Make the API call
    local response
    local http_code

    response=$(curl -s -w '\n%{http_code}' \
        --location "$API_ENDPOINT" \
        --header "Authorization: $BITO_API_KEY" \
        --header "Content-Type: application/json" \
        --data "$json_payload" 2>/dev/null)

    if [ $? -ne 0 ]; then
        log_silent "Failed to make API call to $API_ENDPOINT"
        return 1
    fi

    # Extract HTTP code and response body
    log_silent "Raw response: $response"

    http_code="${response: -3}"
    response_body="${response:0:${#response}-3}"

    log_silent "Body extracted: ${#response_body} bytes"

    # Check HTTP status code - use render function for user-friendly errors
    case "$http_code" in
        2*)
            log_silent "Git repositories API call successful (HTTP $http_code) Response: $response_body"
            ;;
        *)
            # Non-success codes: parse nested status if present (e.g., status=401 in error message)
            log_silent "API error (HTTP $http_code): $response_body"
            
            # Extract nested status code from error message if present
            local actual_status="$http_code"
            local actual_error="$response_body"
            
            # Parse error message from JSON if possible
            if command -v jq >/dev/null 2>&1 && echo "$response_body" | jq . >/dev/null 2>&1; then
                local error_msg=$(echo "$response_body" | jq -r '.error // .message // ""')
                
                # Check for nested status code in error message
                if echo "$error_msg" | grep -q "status="; then
                    actual_status=$(echo "$error_msg" | sed -n 's/.*status=\([0-9]*\).*/\1/p')
                    log_silent "Extracted nested HTTP status: $actual_status"
                fi
                
                # Extract nested body if present
                if echo "$error_msg" | grep -q "body="; then
                    local nested_body=$(echo "$error_msg" | sed -n 's/.*body=\({[^}]*}\).*/\1/p')
                    if [ -n "$nested_body" ] && command -v jq >/dev/null 2>&1; then
                        # Try to extract message from nested body
                        local nested_msg=$(echo "$nested_body" | jq -r '.message // ""' 2>/dev/null)
                        if [ -n "$nested_msg" ]; then
                            actual_error="$nested_msg"
                        fi
                    fi
                fi
            fi
            
            render_fetch_repo_list_failure_block "$actual_status" "$actual_error"
            return 1
            ;;
    esac

    # Call the Git repositories API
    local api_response
#    api_response=$(git_repositories_api)
    api_response=$response_body


    log_silent "API response: $api_response"

    # Check if jq is available
    if ! command -v jq >/dev/null 2>&1; then
        log_silent "jq is required but not installed. Please install jq first."
        log_silent "Install with: brew install jq (macOS) or apt-get install jq (Ubuntu)"
        return 1
    fi

    # Parse the API response and validate structure
    local success
    success=$(echo "$api_response" | jq -r '.success // false' 2>/dev/null)

    if [ "$success" != "true" ]; then
        # API returned success:false - use render function for consistent error display
        render_fetch_repo_list_failure_block "200" "$api_response"
        log_silent "API failure response: $api_response"
        return 1
    fi

    log_silent "API response indicates success"

    # Extract repositories array
    local repositories
    repositories=$(echo "$api_response" | jq -r '.repositories // []' 2>/dev/null)

    if [ "$repositories" = "[]" ] || [ "$repositories" = "null" ]; then
        log_warn "No repositories found in API response"
        repositories="[]"
    fi

    # Count repositories
    local repo_count
    repo_count=$(echo "$repositories" | jq 'length' 2>/dev/null)

    log_silent "Found $repo_count repositories to configure"

    # Get config file location using path-manager
    # Source path-manager if not already loaded
    if ! type get_repo_list_file >/dev/null 2>&1; then
        if [ -n "$SCRIPT_DIR" ]; then
            source "${SCRIPT_DIR}/scripts/lib/path-manager.sh" 2>/dev/null || true
        else
            source "$(dirname "${BASH_SOURCE[0]}")/../path-manager.sh" 2>/dev/null || true
        fi
    fi

    local repo_list_file
    if type get_repo_list_file >/dev/null 2>&1; then
        repo_list_file=$(get_repo_list_file)
    else
        repo_list_file=".git-repo-list.yaml"
    fi

    log_silent "Creating config file at: $repo_list_file"

    # Start building the YAML content
    cat > "$repo_list_file" << 'EOF'
repository:
  configured_repos:
EOF

    # Add each repository namespace
    if [ "$repo_count" -gt 0 ]; then
        echo "$repositories" | jq -r '.[] | select(.full_name != null) | .full_name' | while read -r full_name; do
            if [ -n "$full_name" ]; then
                echo "    - namespace: $full_name" >> "$repo_list_file"
            fi
        done
    else
        # Add empty array if no repositories
        echo "    []" >> "$repo_list_file"
    fi

    # Verify file was created successfully
    if [ -f "$repo_list_file" ]; then
        log_silent "Successfully created $repo_list_file with $repo_count repositories"
        echo ""
        echo -e "📝 Found $repo_count repositories. The complete repository list has been added to $repo_list_file for reference."
        echo ""

        # Show the generated content
        log_silent "Generated configuration:"

        return 0
    else
        log_silent "Failed to create $repo_list_file"
        return 1
    fi
    set -e
}

export -f handle_config
export -f handle_config_repo
export -f config_repo_get
export -f config_repo_add_from_file
export -f config_repo_update_from_file
export -f config_repo_add_namespace
export -f config_repo_remove_namespace
export -f create_git_integration_json
export -f create_llm_integration_json
export -f create_scheduler_config_json
export -f git_repositories_api
export -f create_repo_config_from_api
export -f fetch_repo_config_from_api
