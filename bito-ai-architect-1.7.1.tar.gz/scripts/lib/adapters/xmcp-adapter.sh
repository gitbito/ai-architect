#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
# Bito's AI Architect CLI - xMCP Adapter
# Handles xMCP SSO operations and configuration management

# Source required dependencies
ADAPTER_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Source http-client for API calls
if [ -n "${SCRIPT_DIR:-}" ] && [ -f "${SCRIPT_DIR}/lib/http-client.sh" ]; then
    source "${SCRIPT_DIR}/lib/http-client.sh"
elif [ -f "${ADAPTER_DIR}/../http-client.sh" ]; then
    source "${ADAPTER_DIR}/../http-client.sh"
fi

# Source env-generator for set_env_key_value function
if [ -n "${SCRIPT_DIR:-}" ] && [ -f "${SCRIPT_DIR}/env-generator.sh" ]; then
    source "${SCRIPT_DIR}/env-generator.sh"
elif [ -f "${ADAPTER_DIR}/../../env-generator.sh" ]; then
    source "${ADAPTER_DIR}/../../env-generator.sh"
fi

# Source setup-utils for encrypt_secret function
if [ -n "${SCRIPT_DIR:-}" ] && [ -f "${SCRIPT_DIR}/setup-utils.sh" ]; then
    source "${SCRIPT_DIR}/setup-utils.sh"
elif [ -f "${ADAPTER_DIR}/../../setup-utils.sh" ]; then
    source "${ADAPTER_DIR}/../../setup-utils.sh"
fi

if [ -z "${LOG_FILE:-}" ]; then
    LOG_FILE="${BITOARCH_LOG_DIR:-/usr/local/etc/bitoarch/var/logs}/setup.log"
    mkdir -p "$(dirname "$LOG_FILE")" 2>/dev/null || true
fi

# ============================================================================
# UTILITY FUNCTIONS
# ============================================================================

# Returns "-k" for https URLs (Standalone HTTPS uses an mkcert self-signed
# cert on localhost; -k keeps us scheme-aware without depending on host
# trust state). Empty for http URLs. Use unquoted in curl arg list.
_xmcp_curl_tls_opts() {
    case "${1:-}" in
        https://*) printf -- "-k" ;;
    esac
}

# Calculate human-readable expiry display from ISO 8601 expiry timestamp
# Usage: _sso_calculate_expiry_display "2026-03-24T22:50:06.000Z"
# Returns: "23h 15m" or "45 minute(s)" or "expired"
_sso_calculate_expiry_display() {
    local expiry_timestamp="$1"
    
    if [ -z "$expiry_timestamp" ] || [ "$expiry_timestamp" = "null" ]; then
        echo "30 minutes"
        return 0
    fi
    
    local current_epoch=$(date -u +%s 2>/dev/null || echo "0")
    local expiry_epoch=0
    
    # Parse ISO 8601 — macOS vs Linux
    if [[ "$OSTYPE" == "darwin"* ]]; then
        local expiry_clean="${expiry_timestamp%%.*}"
        expiry_clean="${expiry_clean%%Z}"
        expiry_epoch=$(date -u -j -f "%Y-%m-%dT%H:%M:%S" "$expiry_clean" +%s 2>/dev/null || echo "0")
    else
        expiry_epoch=$(date -u -d "$expiry_timestamp" +%s 2>/dev/null || echo "0")
    fi
    
    if [ "$expiry_epoch" -le 0 ] || [ "$current_epoch" -le 0 ] 2>/dev/null; then
        echo "30 minutes"
        return 0
    fi
    
    local remaining=$((expiry_epoch - current_epoch))
    
    if [ "$remaining" -le 0 ]; then
        echo "expired"
        return 1
    elif [ "$remaining" -lt 3600 ]; then
        local mins=$((remaining / 60))
        echo "${mins} minute(s)"
    else
        local hours=$((remaining / 3600))
        local mins=$(( (remaining % 3600) / 60 ))
        if [ "$mins" -gt 0 ]; then
            echo "${hours}h ${mins}m"
        else
            echo "${hours} hour(s)"
        fi
    fi
    return 0
}

# ============================================================================
# API CALL FUNCTIONS
# ============================================================================

# Call xMCP SSO setup endpoint
# Returns: project_id, tenant_id, tenant_key, setup_url, setup_url_expiry
xmcp_sso_setup() {
    local workspace_id="$1"
    
    if [ -z "$workspace_id" ]; then
        msg_error "Workspace ID is required"
        return 1
    fi
    
    # Validate workspace_id is numeric
    if ! [[ "$workspace_id" =~ ^[0-9]+$ ]]; then
        msg_error "Workspace ID must be a number"
        return 1
    fi
    
    local provider_port="${CIS_PROVIDER_EXTERNAL_PORT:-8080}"
    local provider_url="${PROVIDER_URL:-http://localhost:${provider_port}}"
    
    log_silent "Calling SSO setup endpoint at ${provider_url}..." 2>/dev/null
    
    # Build JSON payload
    local json_payload
    json_payload=$(jq -n \
        --argjson workspace_id "$workspace_id" \
        '{
            workspace_id: $workspace_id,
            region: "us",
            provider: "descope"
        }')
    
    if [ $? -ne 0 ] || [ -z "$json_payload" ]; then
        print_error "Failed to create JSON payload"
        return 1
    fi
    
    # Make API call with internal API key
    local response
    response=$(curl -s -w '\n%{http_code}' $(_xmcp_curl_tls_opts "$provider_url") \
        -X POST \
        -H "X-Internal-API-Key: ${BITO_API_KEY}" \
        -H "Content-Type: application/json" \
        -d "$json_payload" \
        "${provider_url}/v1/internal/sso/setup" 2>&1)
    
    if [ $? -ne 0 ]; then
        print_error "Failed to make API call to ${provider_url}/v1/internal/sso/setup"
        return 1
    fi
    
    # Extract HTTP code and body
    local http_code=$(echo "$response" | tail -1)
    local body=$(echo "$response" | sed '$d')
    
    # Check HTTP status
    if [ "$http_code" -ge 200 ] && [ "$http_code" -lt 300 ]; then
        log_silent "SSO setup API call successful (HTTP $http_code)" 2>/dev/null
        echo "$body"
        return 0
    elif [ "$http_code" = "403" ]; then
        # Workspace not authorized — signal caller with exit code 2
        log_silent "SSO setup: workspace not authorized (HTTP 403)" 2>/dev/null
        return 2
    else
        log_silent "SSO setup failed (HTTP $http_code)" 2>/dev/null
        log_silent "Response: $body" 2>/dev/null
        
        # Try to parse error message
        if command -v jq >/dev/null 2>&1; then
            local error_msg=$(echo "$body" | jq -r '.error // .message // "Unknown error"' 2>/dev/null)
            print_error "$error_msg" >&2
        else
            print_error "SSO setup failed" >&2
        fi
        return 1
    fi
}

# Verify tenant SSO configuration
# Returns: sso_configured, auth_type, idp_name, domains
xmcp_sso_verify_tenant() {
    local workspace_id="$1"
    
    if [ -z "$workspace_id" ]; then
        print_error "Workspace ID is required for tenant verification"
        return 1
    fi
    
    local provider_port="${CIS_PROVIDER_EXTERNAL_PORT:-8080}"
    local provider_url="${PROVIDER_URL:-http://localhost:${provider_port}}"
    
    # Build JSON payload — xmcp expects workspace_id (converts to tenantId internally)
    local json_payload
    json_payload=$(jq -n \
        --argjson workspace_id "$workspace_id" \
        '{
            workspace_id: $workspace_id
        }')
    
    if [ $? -ne 0 ] || [ -z "$json_payload" ]; then
        print_error "Failed to create JSON payload"
        return 1
    fi
    
    # Make API call
    local response
    response=$(curl -s -w '\n%{http_code}' $(_xmcp_curl_tls_opts "$provider_url") \
        -X POST \
        -H "X-Internal-API-Key: ${BITO_API_KEY}" \
        -H "Content-Type: application/json" \
        -d "$json_payload" \
        "${provider_url}/v1/internal/sso/verify-tenant" 2>&1)
    
    if [ $? -ne 0 ]; then
        print_error "Failed to make API call to ${provider_url}/v1/internal/sso/verify-tenant"
        return 1
    fi
    
    # Extract HTTP code and body
    local http_code=$(echo "$response" | tail -1)
    local body=$(echo "$response" | sed '$d')
    
    # Check HTTP status
    if [ "$http_code" -ge 200 ] && [ "$http_code" -lt 300 ]; then
        log_silent "Tenant verification successful (HTTP $http_code)"
        echo "$body"
        return 0
    else
        log_silent "Tenant verification failed (HTTP $http_code)"
        log_silent "Response: $body"
        
        # Try to parse error message
        if command -v jq >/dev/null 2>&1; then
            local error_msg=$(echo "$body" | jq -r '.error // .message // "Unknown error"' 2>/dev/null)
            print_error "Error: $error_msg"
        else
            print_error "Tenant verification failed"
        fi
        return 1
    fi
}

# Generate new SSO setup link (for expired URLs)
# Returns: setup_url, setup_url_expiry
xmcp_sso_generate_setup_link() {
    local workspace_id="$1"
    
    if [ -z "$workspace_id" ]; then
        print_error "Workspace ID is required"
        return 1
    fi
    
    # Validate workspace_id is numeric
    if ! [[ "$workspace_id" =~ ^[0-9]+$ ]]; then
        print_error "Workspace ID must be a number"
        return 1
    fi
    
    local provider_port="${CIS_PROVIDER_EXTERNAL_PORT:-8080}"
    local provider_url="${PROVIDER_URL:-http://localhost:${provider_port}}"
    
    log_silent "Generating new SSO setup link..." 2>/dev/null
    
    # Build JSON payload
    local json_payload
    json_payload=$(jq -n \
        --argjson workspace_id "$workspace_id" \
        '{
            workspace_id: $workspace_id,
            provider: "descope"
        }')
    
    if [ $? -ne 0 ] || [ -z "$json_payload" ]; then
        print_error "Failed to create JSON payload"
        return 1
    fi
    
    # Make API call with internal API key
    local response
    response=$(curl -s -w '\n%{http_code}' $(_xmcp_curl_tls_opts "$provider_url") \
        -X POST \
        -H "X-Internal-API-Key: ${BITO_API_KEY}" \
        -H "Content-Type: application/json" \
        -d "$json_payload" \
        "${provider_url}/v1/internal/sso/setup-link" 2>&1)
    
    if [ $? -ne 0 ]; then
        print_error "Failed to make API call to ${provider_url}/v1/internal/sso/setup-link"
        return 1
    fi
    
    # Extract HTTP code and body
    local http_code=$(echo "$response" | tail -1)
    local body=$(echo "$response" | sed '$d')
    
    # Check HTTP status
    if [ "$http_code" -ge 200 ] && [ "$http_code" -lt 300 ]; then
        log_silent "Setup link generation successful (HTTP $http_code)" 2>/dev/null
        echo "$body"
        return 0
    else
        log_silent "Setup link generation failed (HTTP $http_code)" 2>/dev/null
        log_silent "Response: $body" 2>/dev/null
        
        # Try to parse error message
        if command -v jq >/dev/null 2>&1; then
            local error_msg=$(echo "$body" | jq -r '.error // .message // "Unknown error"' 2>/dev/null)
            print_error "$error_msg" >&2
        else
            print_error "Setup link generation failed" >&2
        fi
        return 1
    fi
}

# Rotate SSO tenant-scoped key
# Returns: project_id, tenant_id, tenant_key (new), tenant_valid, sso_configured, protocol
xmcp_sso_rotate_key() {
    local workspace_id="$1"
    
    if [ -z "$workspace_id" ]; then
        print_error "Workspace ID is required"
        return 1
    fi
    
    # Validate workspace_id is numeric
    if ! [[ "$workspace_id" =~ ^[0-9]+$ ]]; then
        print_error "Workspace ID must be a number"
        return 1
    fi
    
    local provider_port="${CIS_PROVIDER_EXTERNAL_PORT:-8080}"
    local provider_url="${PROVIDER_URL:-http://localhost:${provider_port}}"
    
    print_info "Rotating SSO tenant key..." >&2
    
    # Build JSON payload
    local json_payload
    json_payload=$(jq -n \
        --argjson workspace_id "$workspace_id" \
        '{
            workspace_id: $workspace_id,
            provider: "descope"
        }')
    
    if [ $? -ne 0 ] || [ -z "$json_payload" ]; then
        print_error "Failed to create JSON payload"
        return 1
    fi
    
    # Make API call
    local response
    response=$(curl -s -w '\n%{http_code}' $(_xmcp_curl_tls_opts "$provider_url") \
        -X POST \
        -H "X-Internal-API-Key: ${BITO_API_KEY}" \
        -H "Content-Type: application/json" \
        -d "$json_payload" \
        "${provider_url}/v1/internal/sso/rotate-key" 2>&1)
    
    if [ $? -ne 0 ]; then
        print_error "Failed to make API call to ${provider_url}/v1/internal/sso/rotate-key"
        return 1
    fi
    
    # Extract HTTP code and body
    local http_code=$(echo "$response" | tail -1)
    local body=$(echo "$response" | sed '$d')
    
    # Check HTTP status
    if [ "$http_code" -ge 200 ] && [ "$http_code" -lt 300 ]; then
        log_silent "Key rotation successful (HTTP $http_code)"
        echo "$body"
        return 0
    else
        log_silent "Key rotation failed (HTTP $http_code)"
        log_silent "Response: $body"
        
        # Try to parse error message
        if command -v jq >/dev/null 2>&1; then
            local error_msg=$(echo "$body" | jq -r '.error // .message // "Unknown error"' 2>/dev/null)
            print_error "$error_msg"
        else
            print_error "Key rotation failed"
        fi
        return 1
    fi
}

# Delete SSO configuration on server (permanent removal)
xmcp_sso_delete() {
    local workspace_id="$1"
    
    if [ -z "$workspace_id" ]; then
        print_error "Workspace ID is required"
        return 1
    fi
    
    local provider_port="${CIS_PROVIDER_EXTERNAL_PORT:-8080}"
    local provider_url="${PROVIDER_URL:-http://localhost:${provider_port}}"
    
    log_silent "Calling SSO delete endpoint..." 2>/dev/null
    
    local json_payload
    json_payload=$(jq -n \
        --argjson workspace_id "$workspace_id" \
        '{
            workspace_id: $workspace_id
        }')
    
    if [ $? -ne 0 ] || [ -z "$json_payload" ]; then
        print_error "Failed to create JSON payload"
        return 1
    fi
    
    local response
    response=$(curl -s -w '\n%{http_code}' $(_xmcp_curl_tls_opts "$provider_url") \
        -X POST \
        -H "X-Internal-API-Key: ${BITO_API_KEY}" \
        -H "Content-Type: application/json" \
        -d "$json_payload" \
        "${provider_url}/v1/internal/sso/delete-setup" 2>&1)
    
    if [ $? -ne 0 ]; then
        print_error "Failed to make API call to ${provider_url}/v1/internal/sso/delete"
        return 1
    fi
    
    local http_code=$(echo "$response" | tail -1)
    local body=$(echo "$response" | sed '$d')
    
    if [ "$http_code" -ge 200 ] && [ "$http_code" -lt 300 ]; then
        log_silent "SSO delete successful (HTTP $http_code)"
        echo "$body"
        return 0
    else
        log_silent "SSO delete failed (HTTP $http_code)" 2>/dev/null
        log_silent "Response: $body" 2>/dev/null
        if command -v jq >/dev/null 2>&1; then
            local error_msg=$(echo "$body" | jq -r '.error // .message // "Unknown error"' 2>/dev/null)
            print_error "$error_msg" >&2
        else
            print_error "SSO delete failed" >&2
        fi
        return 1
    fi
}

# ============================================================================
# CONFIGURATION MANAGEMENT FUNCTIONS
# ============================================================================

# Save SSO configuration to .env-bitoarch
xmcp_sso_save_config() {
    local project_id="$1"
    local tenant_id="$2"
    local tenant_key="$3"
    local workspace_id="$4"
    local setup_url="$5"
    local setup_url_expiry="$6"
    
    # Get env file path from path-manager
    local env_file
    if command -v get_config_file >/dev/null 2>&1; then
        env_file=$(get_config_file)
    elif [ -n "${ENV_FILE:-}" ]; then
        env_file="$ENV_FILE"
    else
        env_file="${BITOARCH_CONFIG_DIR:-/usr/local/etc/bitoarch}/.env-bitoarch"
    fi
    
    if [ ! -f "$env_file" ]; then
        print_error "Environment file not found: $env_file"
        return 1
    fi
    
    print_info "Saving SSO configuration..."
    
    # Encrypt tenant key
    local encrypted_key
    if [ -n "$SECRETS_ENCRYPTION_KEY" ] && command -v encrypt_secret >/dev/null 2>&1; then
        encrypted_key=$(encrypt_secret "$tenant_key" "$SECRETS_ENCRYPTION_KEY")
        if [ $? -ne 0 ] || [ -z "$encrypted_key" ]; then
            print_error "Failed to encrypt tenant key"
            return 1
        fi
    else
        print_warning "Encryption key not available, storing tenant key as-is"
        encrypted_key="$tenant_key"
    fi
    
    # Update environment variables
    set_env_key_value "XMCP_SSO_ENABLED" "true" "$env_file"
    set_env_key_value "XMCP_SSO_DEFAULT_PROVIDER" "descope" "$env_file"
    set_env_key_value "XMCP_SSO_PROJECT_ID" "$project_id" "$env_file"
    set_env_key_value "XMCP_SSO_TENANT_ID" "$tenant_id" "$env_file"
    set_env_key_value "XMCP_SSO_TENANT_KEY" "$encrypted_key" "$env_file"
    set_env_key_value "XMCP_SSO_DEFAULT_WORKSPACE_ID" "$workspace_id" "$env_file"
    set_env_key_value "XMCP_SSO_SETUP_URL" "$setup_url" "$env_file"
    set_env_key_value "XMCP_SSO_SETUP_URL_EXPIRY" "$setup_url_expiry" "$env_file"
    set_env_key_value "MCP_OAUTH_ENABLED" "true" "$env_file"
    
    msg_success "SSO configuration saved to $env_file"
    return 0
}

# ============================================================================
# SERVICE MANAGEMENT FUNCTIONS
# ============================================================================

# Patch K8s ConfigMap with env vars from .env-bitoarch (fast alternative to helm upgrade)
# Usage: _k8s_patch_configmap_from_env <namespace> <env_file>
_k8s_patch_configmap_from_env() {
    local namespace="$1"
    local env_file="$2"
    
    if [ ! -f "$env_file" ]; then
        log_silent "Env file not found: $env_file — skipping ConfigMap patch"
        return 1
    fi
    
    # Source env file to get latest values
    source "$env_file" 2>/dev/null
    
    # Build JSON patch from all KEY=VALUE pairs in the env file
    local patch_json='{"data":{'
    local first=true
    while IFS='=' read -r key value; do
        # Remove surrounding quotes
        value="${value#\"}"
        value="${value%\"}"
        value="${value#\'}"
        value="${value%\'}"
        # Escape special JSON characters in value
        value=$(printf '%s' "$value" | jq -Rs '.' 2>/dev/null || printf '"%s"' "$value")
        if [ "$first" = true ]; then
            patch_json="${patch_json}\"${key}\":${value}"
            first=false
        else
            patch_json="${patch_json},\"${key}\":${value}"
        fi
    done < <(grep -E '^[A-Z_][A-Z0-9_]*=' "$env_file" 2>/dev/null)
    patch_json="${patch_json}}}"
    
    # Patch ConfigMap directly
    log_silent "Patching ConfigMap bitoarch-env-all in namespace $namespace..."
    if kubectl patch configmap bitoarch-env-all -n "$namespace" --field-manager=helm --type merge -p "$patch_json" >/dev/null 2>&1; then
        log_silent "ConfigMap patched successfully"
        return 0
    else
        log_silent "ConfigMap patch failed, provider may use stale config until next helm upgrade"
        return 1
    fi
}

# Restart xMCP provider service
# Callers must save env vars to .env-bitoarch BEFORE calling this function
xmcp_restart_provider() {
    print_info "Restarting xMCP provider service..."
    
    # Detect deployment type
    local deployment_type="docker-compose"
    if type get_deployment_type >/dev/null 2>&1; then
        deployment_type=$(get_deployment_type)
    else
        local dt_file="${BITOARCH_CONFIG_DIR:-/usr/local/etc/bitoarch}/.deployment-type"
        [ -f "$dt_file" ] && deployment_type=$(cat "$dt_file")
    fi
    
    if [ "$deployment_type" = "kubernetes" ]; then
        local namespace="bito-ai-architect"
        
        print_info "Updating provider configuration in Kubernetes..."
        
        # Resolve env file path
        local env_file
        if command -v get_config_file >/dev/null 2>&1; then
            env_file=$(get_config_file)
        elif [ -n "${ENV_FILE:-}" ]; then
            env_file="$ENV_FILE"
        else
            env_file="${BITOARCH_CONFIG_DIR:-/usr/local/etc/bitoarch}/.env-bitoarch"
        fi
        
        # Patch ConfigMap with latest env vars (fast — skips helm upgrade)
        _k8s_patch_configmap_from_env "$namespace" "$env_file"
        
        # Source kubernetes-manager for setup_port_forwards if not available
        if ! command -v setup_port_forwards >/dev/null 2>&1; then
            local km=""
            if [ -f "${SCRIPT_DIR:-}/kubernetes-manager.sh" ]; then
                km="${SCRIPT_DIR}/kubernetes-manager.sh"
            elif [ -f "${SCRIPT_DIR:-}/scripts/kubernetes-manager.sh" ]; then
                km="${SCRIPT_DIR}/scripts/kubernetes-manager.sh"
            fi
            [ -n "$km" ] && source "$km" 2>/dev/null
        fi

        # Restart provider pod to pick up updated ConfigMap
        if kubectl rollout restart deployment ai-architect-provider -n "$namespace" >/dev/null 2>&1; then
            kubectl rollout status deployment ai-architect-provider -n "$namespace" --timeout=90s >/dev/null 2>&1
            # Re-establish port-forwards (pod restart breaks existing forwards)
            if command -v setup_port_forwards >/dev/null 2>&1; then
                log_silent "Re-establishing port-forwards after restart..."
                setup_port_forwards "$namespace"
            fi
            msg_success "Provider restarted successfully"
            return 0
        else
            print_error "Failed to restart provider deployment"
            return 1
        fi
    else
        # Docker Compose deployment
        local orig_dir=$(pwd)
        cd "${PROJECT_ROOT:-.}" 2>/dev/null || {
            print_error "Failed to change to project directory"
            return 1
        }
        
        # Get env file path from path-manager
        local env_file
        if command -v get_config_file >/dev/null 2>&1; then
            env_file=$(get_config_file)
        elif [ -n "${ENV_FILE:-}" ]; then
            env_file="$ENV_FILE"
        else
            env_file="${BITOARCH_CONFIG_DIR:-/usr/local/etc/bitoarch}/.env-bitoarch"
        fi
        
        print_info "Restarting provider in Docker Compose..."
        
        # Try docker compose (v2) first, then docker-compose (v1)
        if docker compose --env-file "$env_file" up -d --force-recreate ai-architect-provider 2>/dev/null; then
            cd "$orig_dir"
            msg_success "Provider restarted successfully"
            return 0
        elif docker-compose --env-file "$env_file" up -d --force-recreate ai-architect-provider 2>/dev/null; then
            cd "$orig_dir"
            msg_success "Provider restarted successfully"
            return 0
        else
            cd "$orig_dir"
            print_error "Failed to restart provider container"
            return 1
        fi
    fi
}

# ============================================================================
# CLI COMMAND HANDLERS
# ============================================================================

# Main SSO command handler
handle_sso() {
    local subcommand="$1"
    shift
    
    # Ensure provider service is accessible (handles K8s port-forward if needed)
    local provider_port="${CIS_PROVIDER_EXTERNAL_PORT:-8080}"
    if command -v ensure_service_accessible >/dev/null 2>&1; then
        ensure_service_accessible "ai-architect-provider" "$provider_port"
    fi
    
    # Check for help
    if [ "$subcommand" = "--help" ] || [ "$subcommand" = "-h" ] || [ -z "$subcommand" ]; then
        show_sso_help
        return 0
    fi
    
    # Route to subcommand
    case "$subcommand" in
        setup)
            sso_setup_interactive "$@"
            ;;
        status)
            sso_status_interactive "$@"
            ;;
        enable)
            sso_enable_interactive "$@"
            ;;
        disable)
            sso_disable_interactive "$@"
            ;;
        rotate-key)
            sso_rotate_key_interactive "$@"
            ;;
        *)
            print_error "Unknown SSO command: $subcommand"
            echo ""
            echo "Available commands: setup, status, enable, disable, rotate-key"
            echo -e "Use ${YELLOW}bitoarch sso --help${NC} for more information"
            return 1
            ;;
    esac
}

# Show SSO help
show_sso_help() {
    cat << 'EOF'
USAGE:
  bitoarch sso <command>

DESCRIPTION:
  Manage SSO configuration for your AI Architect deployment

COMMANDS:
  setup         Configure SSO (Enterprise IdP or Bito)
  status        Check SSO configuration and IdP verification status
  enable        Re-enable previously disabled SSO
  disable       Disable SSO configuration
  rotate-key    Rotate SSO keys

OPTIONS:
  --help, -h    Show this help

EXAMPLES:
  # Set up SSO
  bitoarch sso setup

  # Check SSO status
  bitoarch sso status

  # Temporarily disable SSO
  bitoarch sso disable

  # Re-enable SSO
  bitoarch sso enable

  # Rotate SSO key
  bitoarch sso rotate-key

EOF
}

# ── Helper: Enable SSO without Enterprise IdP (Bito Auth fallback via descope) ──
# Provider stays "descope" — xmcp auto-triggers Bito Auth when IdP is not configured
_sso_enable_without_idp() {
    local env_file
    if command -v get_config_file >/dev/null 2>&1; then
        env_file=$(get_config_file)
    elif [ -n "${ENV_FILE:-}" ]; then
        env_file="$ENV_FILE"
    else
        env_file="${BITOARCH_CONFIG_DIR:-/usr/local/etc/bitoarch}/.env-bitoarch"
    fi
    
    set_env_key_value "XMCP_SSO_ENABLED" "true" "$env_file"
    set_env_key_value "XMCP_SSO_DEFAULT_PROVIDER" "descope" "$env_file"
    set_env_key_value "XMCP_SSO_PROJECT_ID" "" "$env_file"
    set_env_key_value "XMCP_SSO_TENANT_KEY" "" "$env_file"
    set_env_key_value "XMCP_SSO_SETUP_URL" "" "$env_file"
    set_env_key_value "XMCP_SSO_SETUP_URL_EXPIRY" "" "$env_file"
    set_env_key_value "MCP_OAUTH_ENABLED" "true" "$env_file"
    return 0
}

# ── Helper: Show setup URL, wait for IdP config, then verify ──
_sso_show_url_and_verify() {
    local setup_url="$1"
    local workspace_id="$2"
    local setup_log="$3"
    local setup_url_expiry="${4:-${XMCP_SSO_SETUP_URL_EXPIRY:-}}"
    
    # Validate setup_url before showing
    if [ -z "$setup_url" ] || [ "$setup_url" = "null" ]; then
        echo ""
        msg_warn "No setup URL was returned from the API"
        echo -e "  To retry: ${YELLOW}bitoarch sso setup${NC}"
        echo ""
        return 1
    fi
    
    # Calculate expiry display (expired URLs are handled by _sso_resolve_setup_url upstream)
    local expiry_display
    expiry_display=$(_sso_calculate_expiry_display "$setup_url_expiry")
    
    render_sso_setup_url_block "$setup_url" "$expiry_display"
    
    # Trap Ctrl+C for friendly exit
    trap 'echo ""; echo ""; msg_info "SSO setup interrupted. To resume: ${YELLOW}bitoarch sso setup${NC}"; trap - INT; return 1' INT
    read -r -p "Press Enter once IdP configuration is complete..."
    trap - INT
    echo ""
    
    local verify_response
    verify_response=$(xmcp_sso_verify_tenant "$workspace_id") || {
        render_sso_verify_failed_block
        return 1
    }
    
    local sso_configured=$(echo "$verify_response" | jq -r '.sso_configured // false' 2>/dev/null)
    if [ "$sso_configured" = "true" ]; then
        render_sso_setup_complete_block "Enterprise IdP"
        echo "[$(date -u +%Y-%m-%dT%H:%M:%S%z)] SSO: verified successfully" >> "$setup_log"
        return 0
    fi
    
    render_sso_verify_failed_block
    return 1
}

# ── Helper: Get valid setup URL (reuse if not expired, otherwise regenerate) ──
_sso_resolve_setup_url() {
    local workspace_id="$1"
    local setup_log="$2"
    local existing_url="${XMCP_SSO_SETUP_URL:-}"
    local existing_expiry="${XMCP_SSO_SETUP_URL_EXPIRY:-}"
    
    # Check if existing URL is still valid
    if [ -n "$existing_url" ] && [ -n "$existing_expiry" ]; then
        local current_epoch=$(date -u +%s 2>/dev/null || echo "0")
        local expiry_clean="${existing_expiry%%.*}"
        expiry_clean="${expiry_clean%%Z}"
        local expiry_epoch=0
        if [[ "$OSTYPE" == "darwin"* ]]; then
            expiry_epoch=$(date -u -j -f "%Y-%m-%dT%H:%M:%S" "$expiry_clean" +%s 2>/dev/null || echo "0")
        else
            expiry_epoch=$(date -u -d "$existing_expiry" +%s 2>/dev/null || echo "0")
        fi
        
        if [ "$current_epoch" -lt "$expiry_epoch" ] 2>/dev/null; then
            echo "$existing_url"
            return 0
        fi
    fi
    
    # URL expired or missing — generate a new one
    [ -z "$workspace_id" ] && return 1
    
    local link_response
    link_response=$(xmcp_sso_generate_setup_link "$workspace_id") || return 1
    
    local new_setup_url=$(echo "$link_response" | jq -r '.data.setupUrl // .data.setup_url' 2>/dev/null)
    local new_setup_url_expiry=$(echo "$link_response" | jq -r '.data.setupUrlExpiry // .data.setup_url_expiry' 2>/dev/null)
    
    [ -z "$new_setup_url" ] || [ "$new_setup_url" = "null" ] && return 1
    
    # Persist new URL and expiry to env file
    local env_file
    if command -v get_config_file >/dev/null 2>&1; then
        env_file=$(get_config_file)
    else
        env_file="${BITOARCH_CONFIG_DIR:-/usr/local/etc/bitoarch}/.env-bitoarch"
    fi
    set_env_key_value "XMCP_SSO_SETUP_URL" "$new_setup_url" "$env_file"
    set_env_key_value "XMCP_SSO_SETUP_URL_EXPIRY" "$new_setup_url_expiry" "$env_file"
    echo "[$(date -u +%Y-%m-%dT%H:%M:%S%z)] SSO: regenerated setup link" >> "$setup_log"
    
    echo "$new_setup_url"
    return 0
}

# ── Helper: Full /sso/setup flow (API → save → restart → URL → verify) ──
# workspace_id is passed by caller (sso_setup_interactive already resolved it)
_sso_run_full_setup() {
    local workspace_id="$1"
    local setup_log="$2"
    
    echo ""
    msg_info "Initialising SSO Setup..."
    
    # Reuse existing valid URL if SSO already configured (avoids fresh 30-min expiry each time)
    if [ -n "${XMCP_SSO_PROJECT_ID:-}" ] && [ -n "${XMCP_SSO_TENANT_KEY:-}" ]; then
        local resolved_url
        resolved_url=$(_sso_resolve_setup_url "$workspace_id" "$setup_log") && [ -n "$resolved_url" ] && {
            log_silent "SSO: reusing existing setup URL"
            _sso_show_url_and_verify "$resolved_url" "$workspace_id" "$setup_log"
            return $?
        }
    fi
    
    # Call /sso/setup API
    local setup_response
    local setup_exit_code=0
    setup_response=$(xmcp_sso_setup "$workspace_id") || setup_exit_code=$?
    
    if [ "$setup_exit_code" -eq 2 ]; then
        # Workspace not authorized (HTTP 403) — propagate to caller
        log_silent "SSO: workspace $workspace_id not authorized (403)"
        return 2
    elif [ "$setup_exit_code" -ne 0 ]; then
        echo ""
        msg_error "SSO setup failed"
        echo -e "  ${YELLOW}Possible causes:${NC}"
        echo "    • Provider service may not be running"
        echo "    • Network connectivity issue"
        echo -e "  To retry: ${YELLOW}bitoarch sso setup${NC}"
        echo ""
        return 1
    fi
    
    # Parse and validate response
    local success=$(echo "$setup_response" | jq -r '.success // false')
    if [ "$success" != "true" ]; then
        msg_error "SSO setup API returned failure"
        return 1
    fi
    
    local project_id=$(echo "$setup_response" | jq -r '.data.projectId // .data.project_id')
    local tenant_id=$(echo "$setup_response" | jq -r '.data.tenantId // .data.tenant_id')
    local tenant_key=$(echo "$setup_response" | jq -r '.data.managementKey // .data.tenantKey // .data.tenant_key')
    local setup_url=$(echo "$setup_response" | jq -r '.data.setupUrl // .data.setup_url')
    local setup_url_expiry=$(echo "$setup_response" | jq -r '.data.setupUrlExpiry // .data.setup_url_expiry')
    
    # Save config to .env-bitoarch (silent — logs to setup.log)
    echo "[$(date -u +%Y-%m-%dT%H:%M:%S%z)] SSO: saving config for workspace $workspace_id" >> "$setup_log"
    xmcp_sso_save_config "$project_id" "$tenant_id" "$tenant_key" "$workspace_id" "$setup_url" "$setup_url_expiry" >> "$setup_log" 2>&1
    if [ $? -ne 0 ]; then
        log_silent "SSO: failed to save config"
        msg_error "Failed to save SSO configuration"
        return 1
    fi
    log_silent "SSO: config saved, restarting provider"
    
    # Silent restart provider to pick up new SSO config
    echo "[$(date -u +%Y-%m-%dT%H:%M:%S%z)] SSO: restarting provider" >> "$setup_log"
    xmcp_restart_provider >> "$setup_log" 2>&1 && sleep 5
    
    # Show URL and verify IdP configuration (pass expiry explicitly — env file may not be sourced yet)
    _sso_show_url_and_verify "$setup_url" "$workspace_id" "$setup_log" "$setup_url_expiry"
}

# ============================================================================
# Helper: Check if SSO is fully configured
# Returns 0 if configured (bito provider OR descope with project_id)
# ============================================================================
_is_sso_fully_configured() {
    [ "${XMCP_SSO_ENABLED:-false}" = "true" ] || return 1
    local provider="${XMCP_SSO_DEFAULT_PROVIDER:-}"
    [ "$provider" = "bito" ] && return 0
    [ -n "${XMCP_SSO_PROJECT_ID:-}" ] && [ "${XMCP_SSO_PROJECT_ID}" != "null" ] && return 0
    return 1
}

# ============================================================================
# Helper: Ask user for IdP choice and route accordingly
# ============================================================================
_sso_ask_idp_and_configure() {
    local workspace_id="$1"
    local setup_log="$2"
    
    log_silent "SSO: asking IdP choice for workspace_id=$workspace_id"
    
    render_sso_idp_choice_block
    
    local idp_choice=""
    read -r -p "Do you have an Enterprise Identity Provider? (y/N): " idp_choice
    log_silent "SSO: IdP choice='$idp_choice'"
    
    if [[ ! "$idp_choice" =~ ^[Yy]$ ]]; then
        # Bito Auth fallback path — provider stays descope, xmcp auto-triggers Bito Auth
        log_silent "SSO: user chose Bito auth (no Enterprise IdP)"
        msg_info "Configuring SSO with Bito authentication..."
        _sso_enable_without_idp
        echo "[$(date -u +%Y-%m-%dT%H:%M:%S%z)] SSO: configured with Bito fallback" >> "$setup_log"
        log_silent "SSO: restarting provider for Bito"
        xmcp_restart_provider >> "$setup_log" 2>&1 && sleep 3
        render_sso_bito_auth_enabled_block
        return 0
    fi
    
    # Enterprise IdP path
    log_silent "SSO: user chose Enterprise IdP, running full setup"
    local setup_result=0
    _sso_run_full_setup "$workspace_id" "$setup_log" || setup_result=$?
    log_silent "SSO: _sso_run_full_setup returned exit_code=$setup_result"
    
    if [ "$setup_result" -eq 2 ]; then
        # Workspace not authorized (403) — show error with resolution steps
        log_silent "SSO: workspace $workspace_id not authorized (403)"
        render_sso_workspace_invalid_block "$workspace_id"
        return 1
    fi
    
    return $setup_result
}

# ============================================================================
# Interactive SSO setup — simplified 3-path design
#
#   Path A: Not configured / incomplete → ask IdP choice → configure
#   Path B: Configured → ask reconfigure → if yes, Path A
#   (Incomplete = descope provider but missing project_id/key)
# ============================================================================
sso_setup_interactive() {
    local setup_log
    if command -v get_setup_log >/dev/null 2>&1; then
        setup_log=$(get_setup_log)
    else
        setup_log="${BITOARCH_LOG_DIR:-/usr/local/etc/bitoarch/var/logs}/setup.log"
    fi
    mkdir -p "$(dirname "$setup_log")" 2>/dev/null
    
    log_silent "SSO: sso_setup_interactive started"
    
    echo ""
    echo -e "${BLUE}=== SSO Configuration ===${NC}"
    echo ""
    
    # ── Require workspace ID from add-repos ──
    local workspace_id="${XMCP_SSO_DEFAULT_WORKSPACE_ID:-}"
    if ! [[ "$workspace_id" =~ ^[0-9]+$ ]]; then
        log_silent "SSO: workspace_id not configured, aborting"
        render_sso_workspace_required_block
        return 1
    fi
    log_silent "SSO: using workspace_id=$workspace_id from config"
    msg_info "Using workspace ID from configuration: $workspace_id"
    
    # ── Path A: Not configured → fresh setup ──
    if ! _is_sso_fully_configured; then
        _sso_ask_idp_and_configure "$workspace_id" "$setup_log"
        return $?
    fi
    
    # ── Path B: Already configured → ask reconfigure ──
    render_sso_already_configured_block
    echo ""
    read -r -p "Would you like to reconfigure SSO? (y/N): " reconfigure_choice
    
    if [[ ! "$reconfigure_choice" =~ ^[Yy]$ ]]; then
        command -v platform_mcp >/dev/null 2>&1 && platform_mcp
        return 0
    fi
    
    _sso_ask_idp_and_configure "$workspace_id" "$setup_log"
    return $?
}

# ============================================================================
# SSO Status — with verification
# ============================================================================
sso_status_interactive() {
    log_silent "SSO: sso_status_interactive called"
    local sso_enabled="${XMCP_SSO_ENABLED:-false}"
    local sso_provider="${XMCP_SSO_DEFAULT_PROVIDER:-}"
    local workspace_id="${XMCP_SSO_DEFAULT_WORKSPACE_ID:-}"
    local oauth_enabled="${MCP_OAUTH_ENABLED:-false}"
    
    # ── SSO disabled ──
    if [ "$sso_enabled" != "true" ]; then
        render_sso_status_disabled_block
        return 0
    fi
    
    # ── SSO enabled with Descope project_id + tenant_key → verify IdP ──
    if [ -n "${XMCP_SSO_PROJECT_ID:-}" ] && [ -n "${XMCP_SSO_TENANT_KEY:-}" ]; then
        local verify_response=""
        verify_response=$(xmcp_sso_verify_tenant "$workspace_id" 2>/dev/null)
        local sso_configured=$(echo "$verify_response" | jq -r '.sso_configured // false' 2>/dev/null)
        
        if [ "$sso_configured" = "true" ]; then
            render_sso_status_verified_block "$workspace_id" "Enterprise IdP" "$oauth_enabled"
        else
            render_sso_status_unverified_block "$workspace_id" "$oauth_enabled"
        fi
        return 0
    fi
    
    # ── SSO enabled but no project_id/tenant_key → Bito Auth fallback ──
    render_sso_status_bito_block "$workspace_id" "$oauth_enabled"
    return 0
}

# ============================================================================
# SSO Disable
# ============================================================================
sso_disable_interactive() {
    log_silent "SSO: sso_disable_interactive called"
    local sso_enabled="${XMCP_SSO_ENABLED:-false}"
    
    if [ "$sso_enabled" != "true" ]; then
        render_sso_status_disabled_block
        return 0
    fi
    
    local sso_provider="${XMCP_SSO_DEFAULT_PROVIDER:-}"
    local auth_mode="Bito"
    [ "$sso_provider" != "bito" ] && [ -n "${XMCP_SSO_PROJECT_ID:-}" ] && auth_mode="Enterprise IdP"
    
    local env_file
    if command -v get_config_file >/dev/null 2>&1; then env_file=$(get_config_file)
    else env_file="${BITOARCH_CONFIG_DIR:-/usr/local/etc/bitoarch}/.env-bitoarch"; fi
    
    local mcp_token="${BITO_MCP_ACCESS_TOKEN:-}"
    
    # ── Bito Auth: simple disable (no server-side IdP to manage) ──
    if [ "$auth_mode" = "Bito" ]; then
        render_sso_disable_bito_prompt_block
        local confirm=""
        read -r -p "Disable SSO? (y/N): " confirm
        if [[ ! "$confirm" =~ ^[Yy]$ ]]; then
            msg_info "SSO not disabled"
            return 0
        fi
        set_env_key_value "XMCP_SSO_ENABLED" "false" "$env_file"
        xmcp_restart_provider >/dev/null 2>&1
        render_sso_disabled_temp_block "$mcp_token"
        return 0
    fi
    
    # ── Enterprise IdP: offer temporary or permanent removal ──
    render_sso_disable_prompt_block "$auth_mode"
    
    local disable_choice=""
    while [[ ! "$disable_choice" =~ ^[12]$ ]]; do
        read -r -p "Choose (1-2): " disable_choice
    done
    
    if [ "$disable_choice" = "1" ]; then
        # Temporary disable — preserve config
        set_env_key_value "XMCP_SSO_ENABLED" "false" "$env_file"
        xmcp_restart_provider >/dev/null 2>&1
        render_sso_disabled_temp_block "$mcp_token"
    else
        # Permanent remove — delete server-side + reset all config
        local workspace_id="${XMCP_SSO_DEFAULT_WORKSPACE_ID:-}"
        if [ -n "$workspace_id" ]; then
            msg_info "Removing IdP configuration from server..."
            xmcp_sso_delete "$workspace_id" >/dev/null 2>&1 || true
        fi
        set_env_key_value "XMCP_SSO_ENABLED" "false" "$env_file"
        set_env_key_value "XMCP_SSO_DEFAULT_PROVIDER" "" "$env_file"
        set_env_key_value "XMCP_SSO_PROJECT_ID" "" "$env_file"
        set_env_key_value "XMCP_SSO_TENANT_ID" "" "$env_file"
        set_env_key_value "XMCP_SSO_TENANT_KEY" "" "$env_file"
        set_env_key_value "XMCP_SSO_SETUP_URL" "" "$env_file"
        set_env_key_value "XMCP_SSO_SETUP_URL_EXPIRY" "" "$env_file"
        xmcp_restart_provider >/dev/null 2>&1
        render_sso_disabled_permanent_block "$mcp_token"
    fi
    return 0
}

# ============================================================================
# SSO Enable
# ============================================================================
sso_enable_interactive() {
    log_silent "SSO: sso_enable_interactive called"
    local sso_enabled="${XMCP_SSO_ENABLED:-false}"
    local sso_provider="${XMCP_SSO_DEFAULT_PROVIDER:-}"
    
    # Already enabled
    if [ "$sso_enabled" = "true" ]; then
        local auth_mode="Bito"
        [ "$sso_provider" != "bito" ] && [ -n "${XMCP_SSO_PROJECT_ID:-}" ] && auth_mode="Enterprise IdP"
        render_sso_already_enabled_block "$auth_mode"
        return 0
    fi
    
    local env_file
    if command -v get_config_file >/dev/null 2>&1; then env_file=$(get_config_file)
    else env_file="${BITOARCH_CONFIG_DIR:-/usr/local/etc/bitoarch}/.env-bitoarch"; fi
    
    # Provider = bito → just re-enable
    if [ "$sso_provider" = "bito" ]; then
        set_env_key_value "XMCP_SSO_ENABLED" "true" "$env_file"
        xmcp_restart_provider >/dev/null 2>&1
        render_sso_enabled_block "Bito"
        return 0
    fi
    
    # Provider = descope with valid config → re-enable
    if [ -n "${XMCP_SSO_PROJECT_ID:-}" ] && [ -n "${XMCP_SSO_TENANT_KEY:-}" ]; then
        set_env_key_value "XMCP_SSO_ENABLED" "true" "$env_file"
        xmcp_restart_provider >/dev/null 2>&1
        render_sso_enabled_block "Enterprise IdP"
        return 0
    fi
    
    # Incomplete config — cannot re-enable
    render_sso_enable_incomplete_block
    return 1
}

# Interactive key rotation
sso_rotate_key_interactive() {
    log_silent "SSO: sso_rotate_key_interactive called"

    # Check if SSO is enabled
    local sso_enabled="${XMCP_SSO_ENABLED:-false}"

    if [ "$sso_enabled" != "true" ]; then
        render_sso_rotate_not_enabled_block
        return 1
    fi
    
    # Get workspace ID
    local workspace_id="${XMCP_SSO_DEFAULT_WORKSPACE_ID}"
    
    if [ -z "$workspace_id" ]; then
        print_error "Workspace ID not found in configuration"
        return 1
    fi
    
    # Verify Enterprise IdP is configured (rotation only applies to IdP mode)
    if [ -z "${XMCP_SSO_PROJECT_ID:-}" ] || [ -z "${XMCP_SSO_TENANT_KEY:-}" ]; then
        render_sso_rotate_requires_idp_block
        return 0
    fi
    
    # Verify current tenant SSO is active before rotating
    local verify_response
    verify_response=$(xmcp_sso_verify_tenant "$workspace_id" 2>/dev/null)
    local sso_configured=$(echo "$verify_response" | jq -r '.sso_configured // false' 2>/dev/null)
    if [ "$sso_configured" != "true" ]; then
        render_sso_status_unverified_block "$workspace_id" "true"
        return 0
    fi
    
    # Confirm rotation
    echo -e "${YELLOW}⚠${NC} This will rotate the SSO tenant key"
    echo ""
    read -r -p "Continue? (y/N): " confirm
    
    if [[ ! "$confirm" =~ ^[Yy]$ ]]; then
        print_info "Key rotation cancelled"
        return 0
    fi
    
    # Call rotation API 
    local rotate_response
    rotate_response=$(xmcp_sso_rotate_key "$workspace_id" 2>/dev/null)
    
    if [ $? -ne 0 ]; then
        print_error "Key rotation failed"
        return 1
    fi
    
    if ! command -v jq >/dev/null 2>&1; then
        print_error "jq is required for key rotation"
        return 1
    fi
    
    local success=$(echo "$rotate_response" | jq -r '.success // false')
    if [ "$success" != "true" ]; then
        print_error "Key rotation API returned failure"
        return 1
    fi
    
    local project_id=$(echo "$rotate_response" | jq -r '.data.projectId // .data.project_id')
    local tenant_id=$(echo "$rotate_response" | jq -r '.data.tenantId // .data.tenant_id')
    local new_tenant_key=$(echo "$rotate_response" | jq -r '.data.managementKey // .data.tenantKey // .data.tenant_key')
    
    # Save config + restart 
    xmcp_sso_save_config "$project_id" "$tenant_id" "$new_tenant_key" "$workspace_id" "" "" >/dev/null 2>&1
    if [ $? -ne 0 ]; then
        print_error "Failed to save new tenant key"
        return 1
    fi
    
    xmcp_restart_provider >/dev/null 2>&1
    if [ $? -ne 0 ]; then
        print_warning "Provider restart failed - please restart manually"
        return 1
    fi
    
    render_sso_key_rotated_block
    return 0
}

# Export functions
export -f xmcp_sso_setup
export -f xmcp_sso_verify_tenant
export -f xmcp_sso_generate_setup_link
export -f xmcp_sso_rotate_key
export -f xmcp_sso_delete
export -f xmcp_sso_save_config
export -f xmcp_restart_provider
export -f handle_sso
export -f sso_setup_interactive
export -f sso_status_interactive
export -f sso_disable_interactive
export -f sso_enable_interactive
export -f sso_rotate_key_interactive
export -f show_sso_help
