#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
#
# Shared reset: stop services, remove volumes, clear data dirs, delete
# configs, reset install.yaml to the blank template. Called by setup.sh
# --clean and scripts/lib/uninstall.sh. Dependencies are guarded so the
# lib works whether or not setup.sh's environment is loaded.

if [ -n "${_BITOARCH_RESET_LIB_LOADED:-}" ]; then
    return 0
fi
_BITOARCH_RESET_LIB_LOADED=1

# Derive PLATFORM_DIR from this file's location if caller didn't set it.
if [ -z "${PLATFORM_DIR:-}" ]; then
    PLATFORM_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
fi

# Ensure path-manager is available (get_config_file et al.).
if ! command -v get_config_file >/dev/null 2>&1; then
    if [ -f "${PLATFORM_DIR}/scripts/lib/path-manager.sh" ]; then
        # shellcheck disable=SC1091
        source "${PLATFORM_DIR}/scripts/lib/path-manager.sh"
    fi
fi

# Fallback log helpers when cli-core.sh hasn't been sourced (CDN uninstall).
if ! command -v print_info >/dev/null 2>&1; then
    print_info()    { echo "[INFO] $*"    >&2; }
    print_warning() { echo "[WARN] $*"    >&2; }
    print_error()   { echo "[ERROR] $*"   >&2; }
fi
if ! command -v log_silent >/dev/null 2>&1; then
    log_silent()    { :; }
fi

# v2 plugin preferred; respects already-exported DOCKER_COMPOSE_CMD.
_reset_detect_compose_cmd() {
    if [ -n "${DOCKER_COMPOSE_CMD:-}" ]; then
        echo "$DOCKER_COMPOSE_CMD"
        return 0
    fi
    if command -v docker >/dev/null 2>&1 && docker compose version >/dev/null 2>&1; then
        echo "docker compose"
        return 0
    fi
    if command -v docker-compose >/dev/null 2>&1; then
        echo "docker-compose"
        return 0
    fi
    return 1
}

_reset_stop_services() {
    local deployment="${1:-docker}"

    if [ "$deployment" = "kubernetes" ]; then
        if ! command -v uninstall_helm_release >/dev/null 2>&1; then
            [ -f "${PLATFORM_DIR}/scripts/kubernetes-manager.sh" ] && \
                source "${PLATFORM_DIR}/scripts/kubernetes-manager.sh" 2>/dev/null || true
        fi
        if command -v uninstall_helm_release >/dev/null 2>&1; then
            uninstall_helm_release "bito-ai-architect" "bitoarch" "true"
        else
            print_warning "Kubernetes deployment detected but helm helper not loaded; skipping."
        fi
        return 0
    fi

    local compose_cmd
    if ! compose_cmd=$(_reset_detect_compose_cmd); then
        print_warning "Neither 'docker compose' nor 'docker-compose' found; skipping service shutdown."
        return 0
    fi

    local compose_file="${PLATFORM_DIR}/docker-compose.yml"
    local env_file="${ENV_FILE:-}"
    if [ -z "$env_file" ] && command -v get_config_file >/dev/null 2>&1; then
        env_file="$(get_config_file 2>/dev/null)"
    fi

    print_info "Stopping services and removing volumes..."
    if [ -f "$compose_file" ]; then
        if [ -n "$env_file" ] && [ -f "$env_file" ]; then
            $compose_cmd -f "$compose_file" --env-file "$env_file" down --remove-orphans --volumes >/dev/null 2>&1 \
                || $compose_cmd -f "$compose_file" down --remove-orphans --volumes >/dev/null 2>&1 \
                || true
        else
            $compose_cmd -f "$compose_file" down --remove-orphans --volumes >/dev/null 2>&1 || true
        fi
    fi

    # Name-based cleanup: compose may miss stragglers if project name drifted.
    local c v
    for c in ai-architect-mysql ai-architect-config ai-architect-manager \
             ai-architect-provider ai-architect-tracker ai-architect-backup-scheduler \
             ai-architect-init-dirs ai-architect-provider-config-init; do
        docker rm -f "$c" >/dev/null 2>&1 || true
    done
    for v in ai_architect_mysql_data ai_architect_data ai_architect_backups ai_architect_temp; do
        docker volume rm "$v" >/dev/null 2>&1 || true
    done
    docker network rm ai-architect-network >/dev/null 2>&1 || true
}

# Escalates to sudo when docker created bind-mount targets as root.
_reset_clear_data_dirs() {
    local d
    local failed=false
    for d in "${PLATFORM_DIR}/var/logs/" \
             "${PLATFORM_DIR}/services/cis-provider/data/" \
             "${PLATFORM_DIR}/services/cis-provider/metadata/"; do
        [ -d "$d" ] || continue
        if rm -rf "${d}"* 2>/dev/null; then
            log_silent "Cleaned: $d"
            continue
        fi
        if command -v sudo >/dev/null 2>&1; then
            if sudo rm -rf "${d}"* 2>/dev/null; then
                log_silent "Cleaned with sudo: $d"
            else
                print_warning "Failed to clean: $d"
                failed=true
            fi
        else
            print_warning "Could not clean $d (root-owned; no sudo available)"
            failed=true
        fi
    done

    if $failed; then
        print_info "Manual cleanup: sudo rm -rf ${PLATFORM_DIR}/var/logs/* ${PLATFORM_DIR}/services/cis-provider/{data,metadata}/*"
    fi
}

_reset_remove_sql_init() {
    rm -f "${PLATFORM_DIR}/services/mysql/init/02-cis-config-"*.sql 2>/dev/null || true
    rm -f "${PLATFORM_DIR}/services/mysql/init/03-cis-manager-"*.sql 2>/dev/null || true
    rm -f "${PLATFORM_DIR}/services/mysql/init/04-"*.sql 2>/dev/null || true
}

_reset_remove_config_files() {
    if ! command -v get_config_file >/dev/null 2>&1; then
        print_warning "path-manager not loaded; skipping config file cleanup."
        return 0
    fi

    local env_file llm_file deployment_file repo_config repo_list
    env_file=$(get_config_file 2>/dev/null)
    llm_file=$(get_llm_config_file 2>/dev/null)
    deployment_file=$(get_deployment_type_file 2>/dev/null)
    repo_config=$(get_repo_config_file 2>/dev/null)
    repo_list=""
    if command -v get_repo_list_file >/dev/null 2>&1; then
        repo_list=$(get_repo_list_file 2>/dev/null)
    fi

    # Backup preserves api key / git token against accidental reset.
    if [ -f "$env_file" ] && command -v backup_config_file >/dev/null 2>&1; then
        backup_config_file "$env_file" "env" >/dev/null 2>&1 || true
    fi

    rm -f "$llm_file"        2>/dev/null || true
    rm -f "$env_file"        2>/dev/null || true
    rm -f "$deployment_file" 2>/dev/null || true
    rm -f "$repo_config"     2>/dev/null || true
    [ -n "$repo_list" ] && rm -f "$repo_list" 2>/dev/null || true

    # Legacy copies / symlinks at the platform root.
    rm -f "${PLATFORM_DIR}/.env-bitoarch"         2>/dev/null || true
    rm -f "${PLATFORM_DIR}/.env-llm-bitoarch"     2>/dev/null || true
    rm -f "${PLATFORM_DIR}/.deployment-type"      2>/dev/null || true
    rm -f "${PLATFORM_DIR}/.bitoarch-config.yaml" 2>/dev/null || true
    rm -f "${PLATFORM_DIR}/.bitoarch-values.yaml" 2>/dev/null || true
    rm -f "${PLATFORM_DIR}/bitoarch-install.yaml" 2>/dev/null || true
    rm -f "${PLATFORM_DIR}/setup.log"             2>/dev/null || true
}

# Back up then restore from blank template so secrets are wiped but the
# file remains editable. Uninstall removes it entirely afterwards.
_reset_install_yaml() {
    local home_yaml="${HOME}/.bitoarch/install.yaml"
    local template="${PLATFORM_DIR}/install.yaml.default"

    if [ -f "$home_yaml" ] && [ -f "$template" ]; then
        if command -v backup_config_file >/dev/null 2>&1; then
            backup_config_file "$home_yaml" "install-yaml" >/dev/null 2>&1 || true
        fi
        cp "$template" "$home_yaml" 2>/dev/null || true
        log_silent "Reset install yaml at $home_yaml"
    fi
}

# Archive logs before cleaning (Enterprise has unified-log-manager).
_reset_archive_logs() {
    local archiver="${PLATFORM_DIR}/scripts/unified-log-manager.sh"
    [ -x "$archiver" ] || return 0
    "$archiver" clean-archive 2>/dev/null || true
}

# AUTO_SETUP=true (uninstall orchestrator / CI) skips the confirmation prompt.
reset_run() {
    if [ "${AUTO_SETUP:-}" != "true" ]; then
        print_warning "This will remove ALL data related to AI Architect including databases and configurations!"
        local reply
        read -r -p "Are you sure you want to continue? Type 'yes' to confirm: " reply
        echo ""
        if [ "$reply" != "yes" ]; then
            print_info "Reset cancelled."
            return 0
        fi
    fi

    _reset_archive_logs

    local deployment="docker"
    if command -v get_deployment_type >/dev/null 2>&1; then
        deployment=$(get_deployment_type 2>/dev/null || echo "docker")
    fi

    _reset_stop_services    "$deployment"
    _reset_clear_data_dirs
    _reset_remove_sql_init
    _reset_remove_config_files
    _reset_install_yaml

    if command -v render_clean_complete_block >/dev/null 2>&1; then
        render_clean_complete_block "All containers" "All volumes"
    else
        print_info "Reset complete."
    fi
}

export -f reset_run
