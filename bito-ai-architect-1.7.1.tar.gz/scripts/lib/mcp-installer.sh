#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
#
# scripts/lib/mcp-installer.sh
# -----------------------------------------------------------------------------
# Auto-register the local MCP endpoint with installed coding agents
# (Claude Code, Cursor, Windsurf, VS Code, Junie). Delegates the actual
# IDE detection + config writes to the hosted bitointtools/BitoMCPinstall
# bootstrap, which we invoke in --non-interactive mode.
#
# Public API (load guard prevents double-source from start/restart paths):
#   mcp_installer_run         Standalone install hook -- self-gates on
#                             MCP_AUTO_INSTALL + MCP_USER_EMAIL.
#   mcp_installer_cli         `bitoarch mcp-install` dispatch handler.
#   mcp_installer_uninstall   Best-effort deregistration; never blocks.
# -----------------------------------------------------------------------------

if [ -n "${_BITOARCH_MCP_INSTALLER_LIB_LOADED:-}" ]; then
    return 0
fi
_BITOARCH_MCP_INSTALLER_LIB_LOADED=1

if [ -z "${PLATFORM_DIR:-}" ]; then
    PLATFORM_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
fi
if [ -z "${SCRIPT_DIR:-}" ]; then
    SCRIPT_DIR="$PLATFORM_DIR"
fi

if [ -f "${PLATFORM_DIR}/scripts/lib/path-manager.sh" ]; then
    # shellcheck disable=SC1091
    source "${PLATFORM_DIR}/scripts/lib/path-manager.sh"
fi
if [ -f "${PLATFORM_DIR}/scripts/lib/output-blocks.sh" ]; then
    # shellcheck disable=SC1091
    source "${PLATFORM_DIR}/scripts/lib/output-blocks.sh"
fi
if [ -f "${PLATFORM_DIR}/scripts/lib/constants.sh" ]; then
    # shellcheck disable=SC1091
    source "${PLATFORM_DIR}/scripts/lib/constants.sh"
fi
if [ -f "${PLATFORM_DIR}/scripts/lib/install-yaml.sh" ]; then
    # shellcheck disable=SC1091
    source "${PLATFORM_DIR}/scripts/lib/install-yaml.sh"
fi

# Last-resort log fallbacks when sourced from CDN / ad-hoc shell.
if ! command -v msg_info    >/dev/null 2>&1; then msg_info()    { echo "[INFO] $*"  >&2; }; fi
if ! command -v msg_warn    >/dev/null 2>&1; then msg_warn()    { echo "[WARN] $*"  >&2; }; fi
if ! command -v msg_error   >/dev/null 2>&1; then msg_error()   { echo "[ERROR] $*" >&2; }; fi
if ! command -v msg_success >/dev/null 2>&1; then msg_success() { echo "[OK] $*"    >&2; }; fi
if ! command -v log_silent  >/dev/null 2>&1; then log_silent()  { :; }; fi

# RFC-5322-ish; sufficient for catching obvious typos without false rejects.
_MCP_INSTALLER_EMAIL_RE='^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$'

# -----------------------------------------------------------------------------
# Helpers
# -----------------------------------------------------------------------------

_mcp_installer_validate_email() {
    [[ "$1" =~ $_MCP_INSTALLER_EMAIL_RE ]]
}

_mcp_installer_log_path() {
    local log_dir
    if command -v get_log_dir >/dev/null 2>&1; then
        log_dir="$(get_log_dir)"
    else
        log_dir="${HOME}/.local/bitoarch/var/log"
    fi
    mkdir -p "$log_dir" 2>/dev/null || true
    echo "${log_dir}/mcp-install.log"
}

_mcp_installer_compute_url() {
    local transport="${MCP_TRANSPORT:-http}"
    local port="${CIS_PROVIDER_EXTERNAL_PORT:-5001}"
    echo "${transport}://localhost:${port}/mcp"
}

# Build a BitoMCPinstall CDN URL from the configured base + a relative path
# (install.sh / uninstall.sh).
_mcp_installer_cdn_url() {
    local path="$1"
    local base="${MCP_INSTALLER_BASE_URL:-https://mcp-setup-staging.bito.ai}"
    echo "${base%/}/${path#/}"
}

# Update install.yaml's .user_email so subsequent `restart --force`
# preserves the email without re-prompting. Silent when yq is missing or
# the yaml hasn't been seeded yet.
_mcp_installer_persist_email() {
    local email="$1"
    [ -n "$email" ] || return 0
    command -v yq >/dev/null 2>&1 || return 0
    command -v get_install_yaml_file >/dev/null 2>&1 || return 0
    local yaml
    yaml="$(get_install_yaml_file)"
    [ -f "$yaml" ] || return 0
    local esc=${email//\"/\\\"}
    yq eval -i ".user_email = \"$esc\"" "$yaml" 2>/dev/null \
        && log_silent "mcp-installer: persisted email to $yaml"
}

# -----------------------------------------------------------------------------
# Public API
# -----------------------------------------------------------------------------

# Self-gating Standalone install hook. Returns 0 (no-op) on Enterprise or
# whenever auto-install is disabled / email missing -- callers wire it
# unconditionally and rely on env to opt in.
mcp_installer_run() {
    [ "${MCP_AUTO_INSTALL:-false}" = "true" ] || return 0
    [ -n "${MCP_USER_EMAIL:-}" ] || {
        log_silent "mcp-installer: MCP_USER_EMAIL empty; skipping auto-install"
        return 0
    }
    [ -n "${BITO_MCP_ACCESS_TOKEN:-}" ] || {
        log_silent "mcp-installer: BITO_MCP_ACCESS_TOKEN not set; skipping auto-install."
        _mcp_installer_emit_manual_fallback "BITO_MCP_ACCESS_TOKEN missing"
        return 0
    }

    if ! command -v curl >/dev/null 2>&1; then
        log_silent "mcp-installer: curl not installed; skipping auto-install."
        _mcp_installer_emit_manual_fallback "curl not installed"
        return 0
    fi

    local install_url="$(_mcp_installer_cdn_url install.sh)"
    local mcp_url log
    mcp_url="$(_mcp_installer_compute_url)"
    log="$(_mcp_installer_log_path)"

    log_silent "mcp-installer: install=${install_url} mcp_url=${mcp_url} email=${MCP_USER_EMAIL}"

    echo "--- $(date -u +%FT%TZ) mcp-installer run ---" >> "$log" 2>/dev/null || true

    # Subshell + export: env vars must reach BOTH pipeline components (curl
    # AND the spawned bash); a `VAR=val curl | bash` prefix would only set
    # them on curl. Avoids `bash -c "...$install_url..."` which would
    # interpolate the URL in the parent shell.
    local rc=0
    (
        export MCP_URL="$mcp_url"
        export BEARER_TOKEN="$BITO_MCP_ACCESS_TOKEN"
        export USER_EMAIL="$MCP_USER_EMAIL"
        curl -fsSL "$install_url" | bash -s -- --non-interactive
    ) >> "$log" 2>&1
    rc=$?

    _mcp_installer_summarize "$log"

    if [ $rc -ne 0 ]; then
        log_silent "mcp-installer: bootstrap exit ${rc}; see ${log}"
        _mcp_installer_emit_manual_fallback "auto-install exit ${rc}"
        return 0
    fi

    log_silent "mcp-installer: install completed → ${log}"
    return 0
}

_mcp_installer_emit_manual_fallback() {
    local reason="${1:-unknown}"
    local url="${BITO_STANDALONE_MCP_DOCS_URL:-https://docs.bito.ai/ai-architect/standalone-mcp-coding-agents}"
    local log
    log="$(_mcp_installer_log_path)"

    : "${YELLOW:=$'\033[1;33m'}"
    : "${BLUE:=$'\033[1;34m'}"
    : "${BOLD:=$'\033[1m'}"
    : "${NC:=$'\033[0m'}"

    echo ""
    echo -e "${BOLD}${YELLOW}MCP auto-registration could not complete${NC} (${reason})."
    echo -e "Configure your coding agents manually: ${BLUE}${url}${NC}"
    echo -e "Detailed log: ${log}"
    echo ""
}

# Reads the latest "mcp-installer run" section from the log and prints one
# verdict line per coding agent. No hardcoded agent registry -- we match the
# bootstrap's own ✓/⚠/ℹ output by phrase ("configured successfully",
# "configuration updated", "mcp.json updated", "directory not found",
# "not detected", "not installed", "requires manual") and extract the agent
# name from each matched line. New IDEs added upstream surface here
# automatically as long as they follow the bootstrap's existing phrasing
# convention. ANSI codes from the upstream output are stripped before matching.
_mcp_installer_summarize() {
    local log="$1"
    [ -f "$log" ] || return 0

    local section
    section=$(awk '
        /^--- [0-9TZ:.+-]+ mcp-installer run ---$/ { buf=""; next }
        { buf = buf $0 ORS }
        END { printf "%s", buf }
    ' "$log" 2>/dev/null)
    [ -n "$section" ] || return 0

    local g="\033[0;32m" y="\033[1;33m" b="\033[1;34m" r="\033[0;31m" n="\033[0m"

    local rendered
    rendered=$(printf "%s" "$section" | awk -v g="$g" -v y="$y" -v b="$b" -v r="$r" -v n="$n" '
        BEGIN { ESC = sprintf("%c", 27) }
        function emit(sym, color, name, suffix) {
            if (name == "" || seen[name]++) return
            printf "    %s%s%s %s%s\n", color, sym, n, name, suffix
        }
        {
            line = $0
            gsub(ESC "\\[[0-9;]*[a-zA-Z]", "", line)
        }
        line ~ /^✓ .* (configured successfully|configuration updated|mcp\.json updated)/ {
            name = line
            sub(/^✓ /, "", name)
            sub(/ (configured successfully|configuration updated|mcp\.json updated).*$/, "", name)
            emit("✓", g, name, "")
            next
        }
        line ~ /^ℹ .* requires manual/ {
            name = line
            sub(/^ℹ /, "", name)
            sub(/ requires manual.*$/, "", name)
            emit("ℹ", b, name, " (manual setup required)")
            next
        }
        line ~ /^⚠ .* (directory not found|not detected|not installed)/ {
            name = line
            sub(/^⚠ /, "", name)
            sub(/ (directory not found|not detected|not installed).*$/, "", name)
            emit("⚠", y, name, " (not installed)")
            next
        }
        line ~ /^✗ Failed to update .* config/ {
            name = line
            sub(/^✗ Failed to update /, "", name)
            sub(/ config.*$/, "", name)
            emit("✗", r, name, " (config update failed; backup preserved)")
            next
        }
    ')
    [ -n "$rendered" ] || return 0

    # %b interprets the backslash escapes inside $b / $n; without it bash
    # printf would emit the literal "\033[1;34m". Two trailing newlines:
    # $(...) strips trailing \n's, so we emit the last item's \n (folded into
    # %s by the rebuild) plus an explicit blank line for visual separation
    # from whatever block follows.
    printf '  %bCoding agent MCP setup:%b\n%s\n\n' "$b" "$n" "$rendered"
}

# `bitoarch mcp-install` dispatch. Forces auto-install on for this run
# even when .env-bitoarch has MCP_AUTO_INSTALL=false, so users can re-register
# after installing a new IDE without editing config.
mcp_installer_cli() {
    local email="${MCP_USER_EMAIL:-}"
    local non_interactive=false
    while [ $# -gt 0 ]; do
        case "$1" in
            --email)
                email="${2:-}"
                shift 2
                ;;
            --email=*)
                email="${1#*=}"
                shift
                ;;
            --non-interactive|-y)
                non_interactive=true
                shift
                ;;
            --help|-h)
                cat <<EOF
USAGE:
  bitoarch mcp-install [--email <addr>] [--non-interactive]

Registers the local MCP server with installed coding agents
(Claude Code, Cursor, Windsurf, VS Code, Junie).

OPTIONS:
  --email <addr>      Email address to associate with the MCP registration.
                      Reused from ~/.bitoarch/install.yaml when omitted.
  --non-interactive   Fail (instead of prompting) when --email is missing.
  --help, -h          Show this help.
EOF
                return 0
                ;;
            *)
                msg_error "Unknown argument: $1"
                return 1
                ;;
        esac
    done

    if [ -z "$email" ] && command -v _install_yaml_read_value >/dev/null 2>&1 \
            && command -v get_install_yaml_file >/dev/null 2>&1; then
        local yaml
        yaml="$(get_install_yaml_file)"
        if [ -f "$yaml" ]; then
            email="$(_install_yaml_read_value "$yaml" '.user_email')"
            case "$email" in null|~) email="" ;; esac
        fi
    fi

    if [ -z "$email" ]; then
        if [ "$non_interactive" = "true" ] || [ ! -t 0 ]; then
            msg_error "Email required: pass --email <addr> or set user_email in ~/.bitoarch/install.yaml."
            return 1
        fi
        local reply
        read -r -p "Email for MCP registration: " reply
        email="$reply"
    fi

    if ! _mcp_installer_validate_email "$email"; then
        msg_error "Invalid email: ${email}"
        return 1
    fi

    if [ -z "${BITO_MCP_ACCESS_TOKEN:-}" ] && command -v get_config_file >/dev/null 2>&1; then
        local env_file
        env_file="$(get_config_file)"
        if [ -f "$env_file" ]; then
            # shellcheck disable=SC1090
            set -a; source "$env_file"; set +a
        fi
    fi

    export MCP_USER_EMAIL="$email"
    export MCP_AUTO_INSTALL=true

    if ! mcp_installer_run; then
        return 1
    fi

    _mcp_installer_persist_email "$email"
    return 0
}

# Strip the BitoAIArchitect entry from a single IDE config file. Preserves
# every other key in the file. Best-effort; logs silently on parse error.
_mcp_installer_strip_bito_entry() {
    local file="$1"
    [ -f "$file" ] || return 0
    command -v jq >/dev/null 2>&1 || return 0

    jq -e '(.mcpServers.BitoAIArchitect != null) or (.servers.BitoAIArchitect != null)' "$file" >/dev/null 2>&1 || return 0

    local tmp
    tmp="$(mktemp)" || return 0
    if jq 'del(.mcpServers.BitoAIArchitect, .servers.BitoAIArchitect)' "$file" > "$tmp" 2>/dev/null; then
        mv "$tmp" "$file"
        log_silent "mcp-installer: stripped BitoAIArchitect from $file"
    else
        rm -f "$tmp"
        log_silent "mcp-installer: parse failed for $file; left as-is"
    fi
}

# Local IDE-config cleanup. Replaces the upstream curl|bash uninstall, which
# blocked on /dev/tty prompts that ignored --non-interactive. Same outcome
# (BitoAIArchitect entries removed from each IDE), no prompts, no network.
mcp_installer_uninstall() {
    log_silent "mcp-installer: uninstall start"
    local f
    for f in \
        "${HOME}/.claude.json" \
        "${HOME}/.cursor/mcp.json" \
        "${HOME}/.codeium/windsurf/mcp_config.json" \
        "${HOME}/Library/Application Support/Code/User/mcp.json" \
        "${HOME}/.config/Code/User/mcp.json" \
        "${HOME}/.junie/mcp/mcp.json"
    do
        _mcp_installer_strip_bito_entry "$f"
    done
    log_silent "mcp-installer: uninstall done"
    return 0
}

export -f mcp_installer_run
export -f mcp_installer_cli
export -f mcp_installer_uninstall
