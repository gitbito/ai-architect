#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
# Bito's AI Architect - Static URLs and Constants
# Centralized location for all documentation links and static resources

# Prevent multiple sourcing
if [ -n "${_BITOARCH_CONSTANTS_LOADED:-}" ]; then
    return 0
fi
_BITOARCH_CONSTANTS_LOADED=1

# Documentation URLs
export BITO_API_KEY_URL="https://alpha.bito.ai/home/advanced"
export BITO_WORKSPACE_ID_URL="https://alpha.bito.ai/home/advance-settings"
export GIT_TOKEN_DOCS_URL="https://docs.bito.ai/ai-architect/install-ai-architect-self-hosted#git-provider"
export MCP_SETUP_DOCS_URL="https://docs.bito.ai/ai-architect/install-ai-architect-self-hosted#setting-up-ai-architect-mcp-in-coding-agents"
export BITO_STANDALONE_MCP_DOCS_URL="https://docs.bito.ai/ai-architect/standalone-mcp-coding-agents"
export AI_ARCHITECT_DOCS_URL="https://docs.bito.ai/ai-architect/install-ai-architect-self-hosted"
# Canonical landing page for all AI Architect docs (index of sub-pages).
# Prefer this over deep-links in user-facing CLI output so readers can
# navigate to the latest-indexed version of any page.
export AI_ARCHITECT_DOCS_HOME_URL="https://docs.bito.ai/ai-architect"

# bitointtools/BitoMCPinstall CDN base. Override via env (e.g. for prod or
# air-gapped mirrors). install/uninstall URLs are built from this base.
export MCP_INSTALLER_BASE_URL="${MCP_INSTALLER_BASE_URL:-https://mcp-setup-staging.bito.ai}"

# Product Branding
export PRODUCT_NAME="Bito's AI Architect"
export PRODUCT_SHORT_NAME="AI Architect"

# Service Display Names (human-readable, for UI output)
export SERVICE_CONFIG_DISPLAY="AI Architect Config"
export SERVICE_MANAGER_DISPLAY="AI Architect Manager"
export SERVICE_PROVIDER_DISPLAY="AI Architect Provider"
export SERVICE_TRACKER_DISPLAY="AI Architect Tracker"
export SERVICE_MYSQL_DISPLAY="MySQL Database"

# Service Container Names (Docker Compose service identifiers -- also the
# Kubernetes deployment names). New code referencing a service by literal
# name should use these constants. NOTE: the codebase has many legacy
# literal references; do not mass-rewrite without a separate validation
# pass (container names appear in helm chart YAML, kubectl selectors,
# docker ps queries, etc.).
export SERVICE_MYSQL_NAME="ai-architect-mysql"
export SERVICE_CONFIG_NAME="ai-architect-config"
export SERVICE_MANAGER_NAME="ai-architect-manager"
export SERVICE_PROVIDER_NAME="ai-architect-provider"
export SERVICE_TRACKER_NAME="ai-architect-tracker"

# User-facing Service List
# ------------------------
# Canonical user-facing service list. Background services (tracker,
# backup-scheduler) are intentionally excluded from UI / health / failure
# enumeration. Deployment-neutral -- consumed by both Docker lifecycle
# (docker-manager.sh) and output rendering (output-blocks.sh). Add a
# service here to make it participate in health waits, failure
# enumeration, and "N of M failed" counts. Composed from SERVICE_*_NAME
# constants above so there is ONE source of truth per service identifier.
BITOARCH_USER_SERVICES=(
    "$SERVICE_MYSQL_NAME"
    "$SERVICE_CONFIG_NAME"
    "$SERVICE_MANAGER_NAME"
    "$SERVICE_PROVIDER_NAME"
)
export BITOARCH_USER_SERVICES

# Count of user-facing services (used by output-blocks for "N of M failed").
bitoarch_user_service_count() {
    echo "${#BITOARCH_USER_SERVICES[@]}"
}
export -f bitoarch_user_service_count
