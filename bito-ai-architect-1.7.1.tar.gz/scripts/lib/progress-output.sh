#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
#
# scripts/lib/progress-output.sh
# -----------------------------------------------------------------------------
# Compact, consistent progress output for lifecycle commands.
#
# Public API:
#   progress_run <label> -- <cmd args...>     Single-step: label, timing, ✓/✗
#   progress_start_multi <total>              Init N-of-M step counter
#   progress_step <label> -- <cmd args...>    [N/M] step inside a multi block
#   progress_end_multi <success_label>        Close the multi block with total
#   progress_fail <label> <log_path>          Shared failure formatter
#
# Design: NO backgrounded spinner subshell. A backgrounded `(while true) &`
# + `kill $!` pattern has a non-deterministic race (macOS in particular)
# where the TERM signal can land on the parent bash itself, killing the
# caller with exit 143 mid-output. We use an in-place line-rewrite pattern
# (terraform/helm-style) instead:
#   write  "[+] <label> ..."      (no newline)
#   run    wrapped cmd silenced to log
#   write  " ✓ done (Ns)\n"       (completes the line)
# On a TTY the final write appends; off-TTY it appends too. Either way the
# user sees exactly one line per step with no risk of signal races.
#
# Reuses RED/GREEN/NC from cli-core.sh (with fallbacks so this lib is safe
# to source from the CDN uninstall bootstrap recovery path).
# -----------------------------------------------------------------------------

if [ -n "${_BITOARCH_PROGRESS_OUTPUT_LOADED:-}" ]; then
    return 0
fi
_BITOARCH_PROGRESS_OUTPUT_LOADED=1

: "${RED:=$'\033[0;31m'}"
: "${GREEN:=$'\033[0;32m'}"
: "${YELLOW:=$'\033[1;33m'}"
: "${NC:=$'\033[0m'}"

# Multi-step state (reset by progress_start_multi).
PROGRESS_STEP=0
PROGRESS_TOTAL=0
PROGRESS_MULTI_START=0

# -----------------------------------------------------------------------------
# Internal: mktemp a per-invocation log path for a label.
# -----------------------------------------------------------------------------
_progress_log_path() {
    local label="$1"
    local slug
    slug=$(echo "$label" | tr '[:upper:] ' '[:lower:]-' | tr -cd '[:alnum:]-')
    mktemp -t "bitoarch-${slug:-progress}.XXXXXX.log"
}

# -----------------------------------------------------------------------------
# Internal: write a start-of-line prefix (no newline). Flushes via printf.
# -----------------------------------------------------------------------------
_progress_emit_start() {
    local label="$1"
    printf '[+] %s ... ' "$label"
}

# -----------------------------------------------------------------------------
# Internal: write the line-completion suffix (with newline).
# Args: rc, elapsed, log_file
# -----------------------------------------------------------------------------
_progress_emit_end() {
    local rc="$1" elapsed="$2" log_file="$3"
    case "$rc" in
        0)
            printf '%b✓%b done (%ds)\n' "$GREEN" "$NC" "$elapsed"
            [ -n "$log_file" ] && rm -f "$log_file"
            ;;
        2)
            # Convention: rc=2 means "soft-timeout / warming up" -- not a
            # failure, not a full success. Used by wait_for_services_healthy
            # and any caller that chains it. Caller inspects rc downstream
            # and decides what to print in the body.
            printf '%b⏳%b done (%ds)\n' "$YELLOW" "$NC" "$elapsed"
            [ -n "$log_file" ] && rm -f "$log_file"
            ;;
        *)
            printf '%b✗%b failed (%ds) → log: %s\n' "$RED" "$NC" "$elapsed" "$log_file" >&2
            ;;
    esac
}

# -----------------------------------------------------------------------------
# Public: progress_run <label> -- <cmd args...>
# Pattern: write "[+] label ... " (no \n), run cmd silenced, write "✓/✗ ..."
# Same line. No backgrounded spinner, no signal races.
# -----------------------------------------------------------------------------
progress_run() {
    local label="$1"; shift
    [ "${1:-}" = "--" ] && shift

    if [ -z "$label" ] || [ $# -eq 0 ]; then
        echo "progress_run: usage: progress_run <label> -- <cmd args...>" >&2
        return 2
    fi

    local log_file
    log_file=$(_progress_log_path "$label")
    local start=$SECONDS

    # On a TTY: run child in background, poll with kill -0 (EXISTENCE
    # check -- does NOT send a signal), animate a braille spinner by
    # rewriting the current line. kill -0 is used deliberately: any
    # real signal could race with the parent shell's own job control.
    # Off a TTY (CI / pipes): run child foreground, static prefix line.
    local rc=0
    if [ -t 1 ] && [ "${BITOARCH_NO_SPINNER:-}" != "1" ]; then
        # Start child in background, silenced.
        (
            COMPOSE_PROGRESS=plain BUILDKIT_PROGRESS=plain \
                "$@" >"$log_file" 2>&1
        ) &
        local child=$!
        local spinner='⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏'
        local i=0
        # Poll until child exits. `kill -0` only checks for existence.
        while kill -0 "$child" 2>/dev/null; do
            local c=${spinner:$i:1}
            printf '\r[+] %s %s' "$label" "$c"
            i=$(( (i + 1) % ${#spinner} ))
            sleep 0.1
        done
        wait "$child" 2>/dev/null
        rc=$?
        # Clear the spinner line before emitting the final status.
        printf '\r\033[K'
    else
        _progress_emit_start "$label"
        COMPOSE_PROGRESS=plain BUILDKIT_PROGRESS=plain \
            "$@" >"$log_file" 2>&1 || rc=$?
    fi

    local elapsed=$((SECONDS - start))
    # On TTY we already cleared the line; re-emit the full "[+] label ... "
    # prefix so _progress_emit_end can append the ✓/✗ suffix on the same
    # visual line.
    [ -t 1 ] && [ "${BITOARCH_NO_SPINNER:-}" != "1" ] && _progress_emit_start "$label"
    _progress_emit_end "$rc" "$elapsed" "$log_file"
    return "$rc"
}

# -----------------------------------------------------------------------------
# Public: progress_start_multi <total>
# -----------------------------------------------------------------------------
progress_start_multi() {
    PROGRESS_TOTAL="${1:-0}"
    PROGRESS_STEP=0
    PROGRESS_MULTI_START=$SECONDS
}

# -----------------------------------------------------------------------------
# Public: progress_step <label> -- <cmd args...>
# -----------------------------------------------------------------------------
progress_step() {
    local label="$1"; shift
    [ "${1:-}" = "--" ] && shift

    if [ -z "$label" ] || [ $# -eq 0 ]; then
        echo "progress_step: usage: progress_step <label> -- <cmd args...>" >&2
        return 2
    fi

    PROGRESS_STEP=$((PROGRESS_STEP + 1))
    local log_file
    log_file=$(_progress_log_path "$label")
    local start=$SECONDS

    # Write step prefix (no newline); run silenced; complete the line.
    printf '[%d/%d] %-40s ' "$PROGRESS_STEP" "$PROGRESS_TOTAL" "$label"

    local rc=0
    COMPOSE_PROGRESS=plain BUILDKIT_PROGRESS=plain \
        "$@" >"$log_file" 2>&1 || rc=$?

    local elapsed=$((SECONDS - start))

    if [ "$rc" -eq 0 ]; then
        printf '%b✓%b %4ds\n' "$GREEN" "$NC" "$elapsed"
        rm -f "$log_file"
    else
        printf '%b✗%b %4ds → log: %s\n' "$RED" "$NC" "$elapsed" "$log_file" >&2
    fi
    return "$rc"
}

# -----------------------------------------------------------------------------
# Public: progress_end_multi <success_label>
# -----------------------------------------------------------------------------
progress_end_multi() {
    local label="${1:-Done}"
    local total=$((SECONDS - PROGRESS_MULTI_START))
    printf '\n%b✓%b %s (%ds total)\n' "$GREEN" "$NC" "$label" "$total"
}

# -----------------------------------------------------------------------------
# Public: progress_fail <label> <log_path>
# Used by callers that want to report a failure without having run the
# command through progress_run (e.g. a precondition failed).
# -----------------------------------------------------------------------------
progress_fail() {
    local label="$1"
    local log_path="${2:-}"
    if [ -n "$log_path" ]; then
        printf '[+] %s ... %b✗%b failed → log: %s\n' \
            "$label" "$RED" "$NC" "$log_path" >&2
    else
        printf '[+] %s ... %b✗%b failed\n' "$label" "$RED" "$NC" >&2
    fi
}
