#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
#
# scripts/lib/cert-cron.sh
# Daily auto-renewal scheduler for the mkcert leaf cert. Mirrors the
# BitoMCPinstall (BITO-13163) pattern: launchd / systemd-user / crontab,
# 09:30 daily, best-effort, idempotent.

if [ -n "${_BITOARCH_CERT_CRON_LIB_LOADED:-}" ]; then
    return 0
fi
_BITOARCH_CERT_CRON_LIB_LOADED=1

# scripts/bitoarch.sh sets SCRIPT_DIR=scripts/, not the project root, so
# derive from BASH_SOURCE regardless.
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
PLATFORM_DIR="$SCRIPT_DIR"

if [ -f "${SCRIPT_DIR}/scripts/lib/path-manager.sh" ]; then
    # shellcheck disable=SC1091
    source "${SCRIPT_DIR}/scripts/lib/path-manager.sh"
fi

if ! command -v log_silent >/dev/null 2>&1; then log_silent() { :; }; fi

_CERT_CRON_LABEL="ai.bito.bitoarch-cert-renew"
_CERT_CRON_UNIT="bitoarch-cert-renew"
_CERT_CRON_SENTINEL="# BITOARCH_CERT_RENEW"
_CERT_CRON_DEFAULT_TIME="09:30"

_cert_cron_platform() {
    case "$(uname -s)" in
        Darwin) echo "macos" ;;
        Linux)
            if grep -qiE 'microsoft|wsl' /proc/version 2>/dev/null; then
                echo "wsl"
            else
                echo "linux"
            fi
            ;;
        *) echo "unknown" ;;
    esac
}

_cert_cron_bin() {
    local candidate
    for candidate in "${HOME}/.local/bin/bitoarch" "/usr/local/bin/bitoarch"; do
        [ -x "$candidate" ] && { echo "$candidate"; return 0; }
    done
    if [ -n "${PLATFORM_DIR:-}" ] && [ -x "${PLATFORM_DIR}/scripts/bitoarch.sh" ]; then
        echo "${PLATFORM_DIR}/scripts/bitoarch.sh"
        return 0
    fi
    if [ -n "${SCRIPT_DIR:-}" ] && [ -x "${SCRIPT_DIR}/scripts/bitoarch.sh" ]; then
        echo "${SCRIPT_DIR}/scripts/bitoarch.sh"
        return 0
    fi
    echo ""
    return 1
}

_cert_cron_log_dir() {
    if command -v get_log_dir >/dev/null 2>&1; then
        get_log_dir
    else
        echo "${HOME}/.local/bitoarch/var/log"
    fi
}

_cert_cron_template_dir() {
    echo "${SCRIPT_DIR}/scripts/lib/scheduler"
}

# Returns 0 (opted out) when BITOARCH_CERT_AUTO_RENEW is explicitly false/0
# in .env-bitoarch.
_cert_cron_opted_out() {
    local env_file
    if command -v get_config_file >/dev/null 2>&1; then
        env_file="$(get_config_file 2>/dev/null)"
    fi
    [ -n "${env_file:-}" ] && [ -f "$env_file" ] || return 1
    grep -qE '^[[:space:]]*BITOARCH_CERT_AUTO_RENEW[[:space:]]*=[[:space:]]*("?false"?|"?0"?)[[:space:]]*$' "$env_file" 2>/dev/null
}

# BITOARCH_CERT_RENEW_TIME (HH:MM, 24h) overrides the default 09:30. Read
# from process env first, then .env-bitoarch. Validates HH:MM strictly.
cert_cron_time() {
    local t="${BITOARCH_CERT_RENEW_TIME:-}"
    if [ -z "$t" ] && command -v get_config_file >/dev/null 2>&1; then
        local env_file
        env_file="$(get_config_file 2>/dev/null)"
        if [ -n "$env_file" ] && [ -f "$env_file" ]; then
            t="$(grep -E '^[[:space:]]*BITOARCH_CERT_RENEW_TIME[[:space:]]*=' "$env_file" 2>/dev/null \
                 | tail -1 \
                 | sed -E 's/^[[:space:]]*BITOARCH_CERT_RENEW_TIME[[:space:]]*=[[:space:]]*"?([^"]*)"?[[:space:]]*$/\1/')"
        fi
    fi
    cert_cron_time_validate "$t" || t="$_CERT_CRON_DEFAULT_TIME"
    echo "$t"
}

cert_cron_time_validate() {
    [[ "${1:-}" =~ ^([0-1][0-9]|2[0-3]):[0-5][0-9]$ ]]
}

_cert_cron_render() {
    local template="$1" bin log_dir t hour minute
    bin="$(_cert_cron_bin)" || return 1
    log_dir="$(_cert_cron_log_dir)"
    [ -n "$bin" ] && [ -n "$log_dir" ] || return 1
    t="$(cert_cron_time)"
    hour=$((10#${t%%:*}))
    minute=$((10#${t##*:}))
    sed -e "s|{{BITOARCH_BIN}}|${bin}|g" \
        -e "s|{{LOG_DIR}}|${log_dir}|g" \
        -e "s|{{HOUR}}|${hour}|g" \
        -e "s|{{MINUTE}}|${minute}|g" \
        -e "s|{{HHMM}}|${t}|g" \
        "$template"
}

_cert_cron_install_macos() {
    local template plist_dest log_dir
    template="$(_cert_cron_template_dir)/${_CERT_CRON_LABEL}.plist.template"
    plist_dest="${HOME}/Library/LaunchAgents/${_CERT_CRON_LABEL}.plist"
    log_dir="$(_cert_cron_log_dir)"

    [ -f "$template" ] || {
        log_silent "cert-cron: launchd template missing at $template"
        return 1
    }

    mkdir -p "$(dirname "$plist_dest")" "$log_dir" 2>/dev/null || true

    # unload-before-write so launchd picks up the new plist
    launchctl unload "$plist_dest" 2>/dev/null || true

    if ! _cert_cron_render "$template" > "$plist_dest" 2>/dev/null; then
        log_silent "cert-cron: failed to render launchd plist"
        return 1
    fi

    if launchctl load "$plist_dest" 2>/dev/null; then
        log_silent "cert-cron: scheduled via launchd (${_CERT_CRON_LABEL}, daily $(cert_cron_time))"
    else
        log_silent "cert-cron: launchctl load failed; plist in place at ${plist_dest}"
    fi
    return 0
}

_cert_cron_uninstall_macos() {
    local plist_dest="${HOME}/Library/LaunchAgents/${_CERT_CRON_LABEL}.plist"
    [ -f "$plist_dest" ] || return 0
    launchctl unload "$plist_dest" 2>/dev/null || true
    rm -f "$plist_dest" 2>/dev/null
    log_silent "cert-cron: removed launchd agent ${_CERT_CRON_LABEL}"
    return 0
}

_cert_cron_systemd_available() {
    command -v systemctl >/dev/null 2>&1 && \
        systemctl --user list-units --no-pager >/dev/null 2>&1
}

_cert_cron_install_systemd() {
    local svc_t tmr_t sysd_dir svc_dest tmr_dest
    svc_t="$(_cert_cron_template_dir)/${_CERT_CRON_UNIT}.service.template"
    tmr_t="$(_cert_cron_template_dir)/${_CERT_CRON_UNIT}.timer.template"
    [ -f "$svc_t" ] && [ -f "$tmr_t" ] || return 1

    sysd_dir="${XDG_CONFIG_HOME:-${HOME}/.config}/systemd/user"
    mkdir -p "$sysd_dir" "$(_cert_cron_log_dir)" 2>/dev/null || true
    svc_dest="${sysd_dir}/${_CERT_CRON_UNIT}.service"
    tmr_dest="${sysd_dir}/${_CERT_CRON_UNIT}.timer"

    _cert_cron_render "$svc_t" > "$svc_dest" 2>/dev/null || return 1
    _cert_cron_render "$tmr_t" > "$tmr_dest" 2>/dev/null || return 1

    systemctl --user daemon-reload 2>/dev/null || return 1
    systemctl --user enable --now "${_CERT_CRON_UNIT}.timer" 2>/dev/null || return 1
    log_silent "cert-cron: scheduled via systemd-user timer (${_CERT_CRON_UNIT}.timer, daily $(cert_cron_time))"
    return 0
}

_cert_cron_install_cron() {
    command -v crontab >/dev/null 2>&1 || return 1
    local bin tmp_cron line t h m
    bin="$(_cert_cron_bin)" || return 1
    [ -n "$bin" ] || return 1
    t="$(cert_cron_time)"
    h=$((10#${t%%:*}))
    m=$((10#${t##*:}))
    line="${m} ${h} * * * ${bin} mcp-cert renew --check ${_CERT_CRON_SENTINEL}"
    tmp_cron="$(mktemp)" || return 1
    crontab -l 2>/dev/null | grep -v "${_CERT_CRON_SENTINEL}" > "$tmp_cron" || true
    echo "$line" >> "$tmp_cron"
    if crontab "$tmp_cron" 2>/dev/null; then
        rm -f "$tmp_cron"
        log_silent "cert-cron: scheduled via crontab (daily ${t})"
        return 0
    fi
    rm -f "$tmp_cron"
    return 1
}

_cert_cron_install_linux() {
    if _cert_cron_systemd_available && _cert_cron_install_systemd; then
        return 0
    fi
    log_silent "cert-cron: systemd-user unavailable; trying crontab"
    if _cert_cron_install_cron; then
        return 0
    fi
    log_silent "cert-cron: neither systemd-user nor crontab available; cron skipped"
    return 0
}

_cert_cron_uninstall_linux() {
    local sysd_dir tmp_cron
    sysd_dir="${XDG_CONFIG_HOME:-${HOME}/.config}/systemd/user"

    if [ -f "${sysd_dir}/${_CERT_CRON_UNIT}.timer" ] || \
       [ -f "${sysd_dir}/${_CERT_CRON_UNIT}.service" ]; then
        if command -v systemctl >/dev/null 2>&1; then
            systemctl --user disable --now "${_CERT_CRON_UNIT}.timer" 2>/dev/null || true
        fi
        rm -f "${sysd_dir}/${_CERT_CRON_UNIT}.timer" \
              "${sysd_dir}/${_CERT_CRON_UNIT}.service" 2>/dev/null
        command -v systemctl >/dev/null 2>&1 && \
            systemctl --user daemon-reload 2>/dev/null || true
        log_silent "cert-cron: removed systemd-user timer ${_CERT_CRON_UNIT}.timer"
    fi

    if command -v crontab >/dev/null 2>&1 && \
       crontab -l 2>/dev/null | grep -q "${_CERT_CRON_SENTINEL}"; then
        tmp_cron="$(mktemp)" || return 0
        crontab -l 2>/dev/null | grep -v "${_CERT_CRON_SENTINEL}" > "$tmp_cron" || true
        if [ -s "$tmp_cron" ]; then
            crontab "$tmp_cron" 2>/dev/null || true
        else
            crontab -r 2>/dev/null || true
        fi
        rm -f "$tmp_cron"
        log_silent "cert-cron: removed crontab entry"
    fi
    return 0
}

cert_cron_install() {
    [ "${MCP_TRANSPORT:-http}" = "https" ] || return 0

    if _cert_cron_opted_out; then
        log_silent "cert-cron: BITOARCH_CERT_AUTO_RENEW=false; skipping schedule install"
        cert_cron_uninstall
        return 0
    fi

    case "$(_cert_cron_platform)" in
        macos)     _cert_cron_install_macos ;;
        linux|wsl) _cert_cron_install_linux ;;
        *)
            log_silent "cert-cron: unsupported platform ($(uname -s)); skipping"
            return 0
            ;;
    esac
    return 0
}

cert_cron_uninstall() {
    case "$(_cert_cron_platform)" in
        macos)     _cert_cron_uninstall_macos ;;
        linux|wsl) _cert_cron_uninstall_linux ;;
    esac
    return 0
}

cert_cron_status() {
    local plist_dest sysd_dir
    plist_dest="${HOME}/Library/LaunchAgents/${_CERT_CRON_LABEL}.plist"
    sysd_dir="${XDG_CONFIG_HOME:-${HOME}/.config}/systemd/user"

    case "$(_cert_cron_platform)" in
        macos)
            [ -f "$plist_dest" ] && { echo "scheduled via launchd (${_CERT_CRON_LABEL})"; return 0; }
            ;;
        linux|wsl)
            if [ -f "${sysd_dir}/${_CERT_CRON_UNIT}.timer" ]; then
                echo "scheduled via systemd-user timer (${_CERT_CRON_UNIT}.timer)"
                return 0
            fi
            if command -v crontab >/dev/null 2>&1 && \
               crontab -l 2>/dev/null | grep -q "${_CERT_CRON_SENTINEL}"; then
                echo "scheduled via crontab"
                return 0
            fi
            ;;
    esac
    echo "not scheduled"
    return 1
}

export -f cert_cron_install
export -f cert_cron_uninstall
export -f cert_cron_status
export -f cert_cron_time
export -f cert_cron_time_validate
