#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
#
# LLM Configuration Functions
# Shared functions for configuring LLM providers

# Global array to track configured providers
CONFIGURED_PROVIDERS=()

# Function: get_provider_metadata
# Maps user selection → provider details
# Returns provider_name, url_key, token_key, example_url
# -------------------------------------------------------------------
get_provider_metadata() {
    case "$1" in
        1)
            provider_name="anthropic"
            url_key="ANTHROPIC_API_URL"
            token_key="ANTHROPIC_API_TOKEN"
            example_url="https://api.anthropic.com"
            ;;
        2)
            provider_name="xai"
            url_key="XAI_API_URL"
            token_key="XAI_API_TOKEN"
            example_url="https://api.x.ai/v1"
            ;;
        3)
            provider_name="openai"
            url_key="OPENAI_API_URL"
            token_key="OPENAI_API_TOKEN"
            example_url="https://api.openai.com/v1"
            ;;
        4)
            provider_name="portkey"
            url_key="PORTKEY_API_URL"
            token_key="PORTKEY_API_TOKEN"
            model_key="PORTKEY_MODEL_NAME"
            example_url="https://api.portkey.ai/v1"
            ;;
        *)
            return 1
            ;;
    esac
}

# Function: configure_llm
# Interactive LLM provider configuration
# -------------------------------------------------------------------
configure_llm() {

    CONFIGURED_PROVIDERS=()
    local continue_config="y"

    while [[ "$continue_config" =~ ^[Yy]$ ]]; do

        # Auto-stop if all providers are configured
        if [[ ${#CONFIGURED_PROVIDERS[@]} -eq 4 ]]; then
            echo -e "${GREEN}💡 All LLM providers have been configured.${NC}"
            break
        fi

        local provider_choice
        echo ""
        read -r -p "Configure LLM: 1) Anthropic 2) XAI Grok 3) OpenAI 4) Portkey [1-4]: " provider_choice

        get_provider_metadata "$provider_choice" || {
            echo "✗ Invalid option. Please select 1–4."
            continue
        }

        # Skip duplicates
        if [[ " ${CONFIGURED_PROVIDERS[*]} " =~ " ${provider_name} " ]]; then
            echo -e "${YELLOW}⚠ $provider_name is already configured.${NC}"
        else
            echo -e "\n${BLUE}=== Configuring ${provider_name} ===${NC}\n"

            # Special handling for Portkey (requires model and optional URL)
            if [[ "$provider_name" == "portkey" ]]; then
                local url=""
                local default_url="https://api.portkey.ai/v1"
                while true; do
                    read -r -p "Enter Portkey API URL (press Enter to use default: $default_url): " url

                    # If user pressed Enter without input, set to empty
                    if [[ -z "$url" ]]; then
                        url=""
                        break
                    fi

                    # Remove trailing slash if present
                    url="${url%/}"

                    # If user entered the default value, set to empty
                    if [[ "$url" == "$default_url" ]]; then
                        url=""
                        break
                    fi

                    # Validate URL format (must start with http:// or https://)
                    if [[ "$url" =~ ^https?://[a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*(/.*)?$ ]]; then
                        break
                    else
                        echo -e "${RED}⚠ Invalid URL format. URL must start with http:// or https://${NC}"
                    fi
                done

                set_env_key_value "PORTKEY_API_URL" "$url" "$ENV_LLM_FILE"

                local model=""
                while [[ -z "$model" ]]; do
                    read -r -p "Enter Portkey model (format: @provider/model-name): " model

                    if [[ -z "$model" ]]; then
                        echo -e "${RED}⚠ Model name is required. Please enter a value.${NC}"
                    elif ! [[ "$model" =~ ^@[^/]+/[^/]+$ ]]; then
                        echo -e "${RED}⚠ Invalid model format. Expected: @provider/model-name (e.g. @slug/claude-haiku).${NC}"
                        model=""
                    fi
                done

                set_env_key_value "PORTKEY_MODEL_NAME" "$model" "$ENV_LLM_FILE"
            fi

            local token=""
            while [[ -z "$token" ]]; do
                read -s -r -p "Enter ${provider_name} API token (input hidden): " token
                stty echo; echo ""
                [[ -z "$token" ]] && echo "Token cannot be empty."
            done

            set_env_key_value "${token_key}" "${token}" "$ENV_LLM_FILE"

            CONFIGURED_PROVIDERS+=("$provider_name")
            print_status " ${provider_name} configured successfully"
        fi

        # Ask whether to configure another provider only if some remain
        # Skip asking for more providers if Portkey is selected (it's a gateway)
        if [[ " ${CONFIGURED_PROVIDERS[*]} " =~ " portkey " ]]; then
            continue_config="n"
        elif [[ ${#CONFIGURED_PROVIDERS[@]} -lt 4 ]]; then
            read -r -p "Do you also want to add an API token for another LLM? (y/N): " continue_config

            if [[ -z "$continue_config" || "$continue_config" =~ ^[Nn]$ ]]; then
                if [[ ${#CONFIGURED_PROVIDERS[@]} -eq 1 && " ${CONFIGURED_PROVIDERS[*]} " =~ " xai " ]]; then
                    echo -e "${RED}⚠ XAI Grok API key alone cannot be used.${NC}"
                    echo -e "${YELLOW}Please configure another LLM (Anthropic or OpenAI).${NC}"
                    continue_config="y"  # Force loop to continue
                fi
            fi
        else
            continue_config="n"
        fi
    done
    return 0
}

# Function: reset_all_llm_keys
# Clears all LLM provider keys to ensure clean state
# -------------------------------------------------------------------
reset_all_llm_keys() {
    # Clear all LLM provider keys
    set_env_key_value "ANTHROPIC_API_URL" "" "$ENV_LLM_FILE"
    set_env_key_value "ANTHROPIC_API_TOKEN" "" "$ENV_LLM_FILE"
    set_env_key_value "XAI_API_URL" "" "$ENV_LLM_FILE"
    set_env_key_value "XAI_API_TOKEN" "" "$ENV_LLM_FILE"
    set_env_key_value "OPENAI_API_URL" "" "$ENV_LLM_FILE"
    set_env_key_value "OPENAI_API_TOKEN" "" "$ENV_LLM_FILE"
    set_env_key_value "PORTKEY_API_URL" "" "$ENV_LLM_FILE"
    set_env_key_value "PORTKEY_API_TOKEN" "" "$ENV_LLM_FILE"
    set_env_key_value "PORTKEY_MODEL_NAME" "" "$ENV_LLM_FILE"
    set_env_key_value "LLM_DEFAULT_PROVIDER" "" "$ENV_LLM_FILE"
}

# Returns 0 when any LLM token is pre-exported (yaml-driven install bypass).
_llm_tokens_preset() {
    [ -n "${ANTHROPIC_API_TOKEN:-}" ] && return 0
    [ -n "${OPENAI_API_TOKEN:-}" ]    && return 0
    [ -n "${XAI_API_TOKEN:-}" ]       && return 0
    [ -n "${PORTKEY_API_TOKEN:-}" ]   && return 0
    return 1
}

# Writes pre-exported LLM tokens to $ENV_LLM_FILE and populates
# CONFIGURED_PROVIDERS so LLM_DEFAULT_PROVIDER resolution still works.
# Clears all LLM keys first so stale values from a previous install do not
# linger if the new yaml defines a smaller provider set.
_llm_persist_preset_tokens() {
    CONFIGURED_PROVIDERS=()
    reset_all_llm_keys

    if [ -n "${ANTHROPIC_API_TOKEN:-}" ]; then
        set_env_key_value "ANTHROPIC_API_TOKEN" "${ANTHROPIC_API_TOKEN}" "$ENV_LLM_FILE"
        CONFIGURED_PROVIDERS+=("anthropic")
    fi
    if [ -n "${OPENAI_API_TOKEN:-}" ]; then
        set_env_key_value "OPENAI_API_TOKEN" "${OPENAI_API_TOKEN}" "$ENV_LLM_FILE"
        CONFIGURED_PROVIDERS+=("openai")
    fi
    if [ -n "${XAI_API_TOKEN:-}" ]; then
        set_env_key_value "XAI_API_TOKEN" "${XAI_API_TOKEN}" "$ENV_LLM_FILE"
        CONFIGURED_PROVIDERS+=("xai")
    fi
    if [ -n "${PORTKEY_API_TOKEN:-}" ]; then
        set_env_key_value "PORTKEY_API_TOKEN" "${PORTKEY_API_TOKEN}" "$ENV_LLM_FILE"
        if [ -n "${PORTKEY_API_URL:-}" ]; then
            set_env_key_value "PORTKEY_API_URL" "${PORTKEY_API_URL}" "$ENV_LLM_FILE"
        fi
        if [ -n "${PORTKEY_MODEL_NAME:-}" ]; then
            set_env_key_value "PORTKEY_MODEL_NAME" "${PORTKEY_MODEL_NAME}" "$ENV_LLM_FILE"
        fi
        CONFIGURED_PROVIDERS+=("portkey")
    fi
}

# Function: configure_llm_provider
# Main entry point for LLM provider configuration
# Pass "force_interactive" to bypass preset-token detection (e.g. when called
# from `bitoarch update-llm-config` where load_env_config has already exported
# the existing tokens into the caller's shell).
# -------------------------------------------------------------------
configure_llm_provider() {
    local mode="${1:-}"

    if [ "$mode" = "force_interactive" ]; then
        reset_all_llm_keys
        configure_llm
    elif _llm_tokens_preset; then
        # Yaml-driven install: persist pre-exported tokens, skip prompt.
        _llm_persist_preset_tokens
    else
        reset_all_llm_keys
        configure_llm
    fi

    # Build final selection list (configured providers + bito)
    local options=("${CONFIGURED_PROVIDERS[@]}" "bito")
    local prefer_order=("portkey" "xai" "openai" "anthropic" "bito")

    selected_provider=""

    for preferred in "${prefer_order[@]}"; do
        for p in "${options[@]}"; do
            if [[ "$p" == "$preferred" ]]; then
                selected_provider="$preferred"
                break 2
            fi
        done
    done
    set_env_key_value "LLM_DEFAULT_PROVIDER" "${selected_provider}" "$ENV_LLM_FILE"

    # Send LLM provider tracking event (suppress output to prevent HTTP status leakage)
    if [[ ${#CONFIGURED_PROVIDERS[@]} -gt 0 ]]; then
        local providers_csv=$(IFS=,; echo "${CONFIGURED_PROVIDERS[*]}")
        send_llm_provider_tracking "$providers_csv" >/dev/null 2>&1
    fi
}

# Export functions
export -f _llm_tokens_preset
export -f _llm_persist_preset_tokens
export -f get_provider_metadata
export -f configure_llm
export -f reset_all_llm_keys
export -f configure_llm_provider
