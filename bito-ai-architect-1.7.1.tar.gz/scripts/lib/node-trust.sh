#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
#
# Inject NODE_EXTRA_CA_CERTS (mkcert root CA) into the user session so Node-
# based IDE MCP clients trust the local cert. Node ignores OS trust stores,
# so mkcert -install alone isn't enough.

if [ -n "${_BITOARCH_NODE_TRUST_LIB_LOADED:-}" ]; then
    return 0
fi
_BITOARCH_NODE_TRUST_LIB_LOADED=1

if [ -z "${SCRIPT_DIR:-}" ]; then
    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
fi

if [ -f "${SCRIPT_DIR}/scripts/lib/path-manager.sh" ]; then
    # shellcheck disable=SC1091
    source "${SCRIPT_DIR}/scripts/lib/path-manager.sh"
fi
if [ -f "${SCRIPT_DIR}/scripts/lib/output-blocks.sh" ]; then
    # shellcheck disable=SC1091
    source "${SCRIPT_DIR}/scripts/lib/output-blocks.sh"
fi
if [ -f "${SCRIPT_DIR}/scripts/lib/mcp-cert.sh" ]; then
    # shellcheck disable=SC1091
    source "${SCRIPT_DIR}/scripts/lib/mcp-cert.sh"
fi
if [ -f "${SCRIPT_DIR}/scripts/lib/mcp-installer.sh" ]; then
    # shellcheck disable=SC1091
    source "${SCRIPT_DIR}/scripts/lib/mcp-installer.sh"
fi

if ! command -v log_silent >/dev/null 2>&1; then log_silent() { :; }; fi

_NODE_TRUST_PROFILE_BEGIN="# >>> bitoarch NODE_EXTRA_CA_CERTS (managed) >>>"
_NODE_TRUST_PROFILE_END="# <<< bitoarch NODE_EXTRA_CA_CERTS (managed) <<<"
_NODE_TRUST_LINUX_ENV_FILE="${HOME}/.config/environment.d/bitoarch.conf"

_node_trust_platform() {
    case "$(uname -s)" in
        Darwin) echo "macos" ;;
        Linux)
            if grep -qiE 'microsoft|wsl' /proc/version 2>/dev/null; then
                echo "wsl"
            else
                echo "linux"
            fi
            ;;
        *) echo "unknown" ;;
    esac
}

# Resolves the mkcert CA root (issuer) -- not the leaf -- which is what
# NODE_EXTRA_CA_CERTS must point at for Node TLS to validate the chain.
_node_trust_cert_path() {
    local mkcert_bin="" caroot=""

    if command -v mkcert >/dev/null 2>&1; then
        mkcert_bin="$(command -v mkcert)"
    elif command -v get_user_cache_dir >/dev/null 2>&1 && \
         [ -x "$(get_user_cache_dir)/bin/mkcert" ]; then
        mkcert_bin="$(get_user_cache_dir)/bin/mkcert"
    fi

    if [ -n "$mkcert_bin" ]; then
        caroot="$("$mkcert_bin" -CAROOT 2>/dev/null)"
        if [ -n "$caroot" ] && [ -f "$caroot/rootCA.pem" ]; then
            echo "$caroot/rootCA.pem"
            return 0
        fi
    fi

    case "$(uname -s)" in
        Darwin) echo "${HOME}/Library/Application Support/mkcert/rootCA.pem" ;;
        Linux)  echo "${XDG_DATA_HOME:-${HOME}/.local/share}/mkcert/rootCA.pem" ;;
        *)      echo "${HOME}/.local/share/mkcert/rootCA.pem" ;;
    esac
}

# launchctl env only flows to processes spawned AFTER setenv; the shell-rc
# sentinel block ensures new shells (and tools they spawn) see the var.
_node_trust_profile_apply() {
    local file="$1" cert="$2"
    [ -n "$file" ] || return 0
    # Don't append a new block if strip couldn't safely remove the old one.
    _node_trust_profile_strip "$file" || return 1
    {
        echo ""
        echo "$_NODE_TRUST_PROFILE_BEGIN"
        echo "if [ -f \"$cert\" ]; then"
        echo "    if [ -n \"\${NODE_EXTRA_CA_CERTS:-}\" ] && [ \"\${NODE_EXTRA_CA_CERTS}\" != \"$cert\" ]; then"
        echo "        export NODE_EXTRA_CA_CERTS=\"\${NODE_EXTRA_CA_CERTS}:$cert\""
        echo "    else"
        echo "        export NODE_EXTRA_CA_CERTS=\"$cert\""
        echo "    fi"
        echo "fi"
        echo "$_NODE_TRUST_PROFILE_END"
    } >> "$file"
    log_silent "node-trust: appended sentinel block to ${file}"
}

_node_trust_profile_strip() {
    local file="$1"
    [ -f "$file" ] || return 0
    grep -qF "$_NODE_TRUST_PROFILE_BEGIN" "$file" 2>/dev/null || return 0
    local tmp
    tmp="$(mktemp "${file}.bito.XXXXXX")" || return 1
    # END { exit 2 } if BEGIN was seen without a matching END — without this
    # guard, the awk would silently drop everything below an unclosed BEGIN.
    awk -v begin="$_NODE_TRUST_PROFILE_BEGIN" -v end="$_NODE_TRUST_PROFILE_END" '
        $0 == begin { skipping=1; next }
        $0 == end   { skipping=0; next }
        !skipping
        END { if (skipping) exit 2 }
    ' "$file" > "$tmp"
    local rc=$?
    if [ "$rc" -ne 0 ]; then
        rm -f "$tmp"
        log_silent "node-trust: unclosed sentinel block in ${file}; refusing to rewrite (preserves content)"
        return 1
    fi
    mv "$tmp" "$file"
    log_silent "node-trust: removed sentinel block from ${file}"
}

_node_trust_install_macos() {
    local cert="$1"
    if command -v launchctl >/dev/null 2>&1; then
        if launchctl setenv NODE_EXTRA_CA_CERTS "$cert" 2>/dev/null; then
            log_silent "node-trust: launchctl setenv NODE_EXTRA_CA_CERTS=${cert}"
        else
            log_silent "node-trust: launchctl setenv failed."
        fi
    else
        log_silent "node-trust: launchctl not found."
    fi

    _node_trust_profile_apply "${HOME}/.zshrc" "$cert"
    [ -f "${HOME}/.zprofile" ]     && _node_trust_profile_apply "${HOME}/.zprofile"     "$cert"
    [ -f "${HOME}/.bash_profile" ] && _node_trust_profile_apply "${HOME}/.bash_profile" "$cert"
    [ -f "${HOME}/.bashrc" ]       && _node_trust_profile_apply "${HOME}/.bashrc"       "$cert"
    return 0
}

_node_trust_uninstall_macos() {
    command -v launchctl >/dev/null 2>&1 && \
        launchctl unsetenv NODE_EXTRA_CA_CERTS 2>/dev/null || true
    _node_trust_profile_strip "${HOME}/.zshrc"
    _node_trust_profile_strip "${HOME}/.zprofile"
    _node_trust_profile_strip "${HOME}/.bash_profile"
    _node_trust_profile_strip "${HOME}/.bashrc"
    return 0
}

_node_trust_install_linux() {
    local cert="$1"
    mkdir -p "$(dirname "$_NODE_TRUST_LINUX_ENV_FILE")" 2>/dev/null || true
    cat > "$_NODE_TRUST_LINUX_ENV_FILE" <<EOF
NODE_EXTRA_CA_CERTS=${cert}
EOF
    chmod 0644 "$_NODE_TRUST_LINUX_ENV_FILE" 2>/dev/null || true
    log_silent "node-trust: wrote ${_NODE_TRUST_LINUX_ENV_FILE}"

    _node_trust_profile_apply "${HOME}/.profile" "$cert"
    [ -f "${HOME}/.bashrc" ]       && _node_trust_profile_apply "${HOME}/.bashrc"       "$cert"
    [ -f "${HOME}/.zshrc" ]        && _node_trust_profile_apply "${HOME}/.zshrc"        "$cert"
    [ -f "${HOME}/.zprofile" ]     && _node_trust_profile_apply "${HOME}/.zprofile"     "$cert"
    [ -f "${HOME}/.bash_profile" ] && _node_trust_profile_apply "${HOME}/.bash_profile" "$cert"
    return 0
}

_node_trust_uninstall_linux() {
    rm -f "$_NODE_TRUST_LINUX_ENV_FILE" 2>/dev/null && \
        log_silent "node-trust: removed ${_NODE_TRUST_LINUX_ENV_FILE}"
    _node_trust_profile_strip "${HOME}/.profile"
    _node_trust_profile_strip "${HOME}/.bashrc"
    _node_trust_profile_strip "${HOME}/.zshrc"
    _node_trust_profile_strip "${HOME}/.zprofile"
    _node_trust_profile_strip "${HOME}/.bash_profile"
    return 0
}

_NODE_TRUST_WSL_CMD="/mnt/c/Windows/System32/cmd.exe"

_node_trust_install_wsl_windows() {
    local cert="$1" win_path
    [ -x "$_NODE_TRUST_WSL_CMD" ] || { log_silent "node-trust: cmd.exe not reachable; Windows env skipped."; return 0; }
    command -v wslpath >/dev/null 2>&1 || { log_silent "node-trust: wslpath missing; Windows env skipped."; return 0; }
    win_path="$(wslpath -w "$cert" 2>/dev/null)"
    [ -n "$win_path" ] || return 0
    if "$_NODE_TRUST_WSL_CMD" /C "setx NODE_EXTRA_CA_CERTS \"$win_path\"" >/dev/null 2>&1; then
        log_silent "node-trust: WSL → Windows setx NODE_EXTRA_CA_CERTS=$win_path"
    else
        log_silent "node-trust: WSL → Windows setx failed."
    fi
}

_node_trust_uninstall_wsl_windows() {
    [ -x "$_NODE_TRUST_WSL_CMD" ] || return 0
    "$_NODE_TRUST_WSL_CMD" /C 'reg delete "HKCU\Environment" /v NODE_EXTRA_CA_CERTS /f' >/dev/null 2>&1 \
        && log_silent "node-trust: WSL → Windows env var removed" \
        || log_silent "node-trust: WSL → Windows reg delete failed (likely already unset)"
}

# JB auto-loads PEM files dropped under <product>/options/certificates/
# at IDE startup, so the bundled JRE trusts the cert without a UI prompt.
_NODE_TRUST_JB_CERT_FILENAME="bitoarch-mkcert-rootCA.crt"

_node_trust_jb_config_root() {
    case "$(_node_trust_platform)" in
        macos)     echo "${HOME}/Library/Application Support/JetBrains" ;;
        linux|wsl) echo "${HOME}/.config/JetBrains" ;;
        *)         echo "" ;;
    esac
}

_node_trust_install_jb() {
    local cert="$1" root prod_dir cert_dir target n=0
    root="$(_node_trust_jb_config_root)"
    [ -n "$root" ] && [ -d "$root" ] || return 0

    for prod_dir in "$root"/*/; do
        [ -d "$prod_dir" ] || continue
        case "$(basename "$prod_dir")" in
            consentOptions|GeneralLog|RemoteDev*) continue ;;
        esac
        cert_dir="${prod_dir}options/certificates"
        mkdir -p "$cert_dir" 2>/dev/null || continue
        target="${cert_dir}/${_NODE_TRUST_JB_CERT_FILENAME}"
        if cp "$cert" "$target" 2>/dev/null; then
            chmod 0644 "$target" 2>/dev/null || true
            log_silent "node-trust: JB cert installed at ${target}"
            n=$((n+1))
        fi
    done
    [ "$n" -gt 0 ] && log_silent "node-trust: JB updated ${n} product(s)"
    return 0
}

_node_trust_uninstall_jb() {
    local root prod_dir target
    root="$(_node_trust_jb_config_root)"
    [ -n "$root" ] && [ -d "$root" ] || return 0
    for prod_dir in "$root"/*/; do
        target="${prod_dir}options/certificates/${_NODE_TRUST_JB_CERT_FILENAME}"
        [ -f "$target" ] && rm -f "$target" && \
            log_silent "node-trust: JB cert removed from ${target}"
    done
    return 0
}

# IDE list comes from BitoMCPinstall's ✓ entries in mcp-install.log so the
# restart hint matches what was actually configured.
_node_trust_mcp_log() {
    if command -v _mcp_installer_log_path >/dev/null 2>&1; then
        _mcp_installer_log_path
    elif command -v get_log_dir >/dev/null 2>&1; then
        echo "$(get_log_dir)/mcp-install.log"
    else
        echo "${HOME}/.local/bitoarch/var/log/mcp-install.log"
    fi
}

node_trust_configured_ides() {
    local log
    log="$(_node_trust_mcp_log)"
    [ -f "$log" ] || return 0

    awk '
        /^--- [0-9TZ:.+-]+ mcp-installer run ---$/ { buf=""; next }
        { buf = buf $0 ORS }
        END { printf "%s", buf }
    ' "$log" 2>/dev/null | awk '
        BEGIN { ESC = sprintf("%c", 27) }
        {
            line = $0
            gsub(ESC "\\[[0-9;]*[a-zA-Z]", "", line)
        }
        line ~ /^✓ .* (configured successfully|configuration updated|mcp\.json updated)/ {
            name = line
            sub(/^✓ /, "", name)
            sub(/ (configured successfully|configuration updated|mcp\.json updated).*$/, "", name)
            if (name != "" && !seen[name]++) print name
        }
    '
}

_node_trust_restart_action() {
    case "$1" in
        "Claude Code")              echo "If using the CLI: open a new terminal (or run \`exec \$SHELL -l\`) and rerun \`claude\`. If using Claude Desktop: Cmd+Q and reopen." ;;
        "Cursor")                   echo "Quit Cursor (Cmd/Ctrl+Q) and reopen." ;;
        "Windsurf")                 echo "Quit Windsurf (Cmd/Ctrl+Q) and reopen." ;;
        "VS Code"|"VS Code (GitHub Copilot)") echo "Quit VS Code (Cmd/Ctrl+Q) and reopen, or run \"Developer: Reload Window\"." ;;
        "Junie")                    echo "Quit your JetBrains IDE running Junie and reopen." ;;
        "JetBrains AI Assistant")   echo "Quit your JetBrains IDE and reopen." ;;
        *)                          echo "Quit $1 and reopen." ;;
    esac
}

node_trust_install() {
    [ "${MCP_TRANSPORT:-http}" = "https" ] || return 0

    local cert
    cert="$(_node_trust_cert_path)"
    if [ ! -f "$cert" ]; then
        log_silent "node-trust: cert not found at ${cert}; skipping."
        return 0
    fi

    local platform
    platform="$(_node_trust_platform)"
    case "$platform" in
        macos) _node_trust_install_macos "$cert" ;;
        linux) _node_trust_install_linux "$cert" ;;
        wsl)
            _node_trust_install_linux "$cert"
            _node_trust_install_wsl_windows "$cert"
            ;;
        *)
            log_silent "node-trust: unsupported platform ($(uname -s)); skipping."
            return 0
            ;;
    esac

    _node_trust_install_jb "$cert"
    _node_trust_emit_restart_hints "$cert"
    return 0
}

node_trust_uninstall() {
    local platform
    platform="$(_node_trust_platform)"
    case "$platform" in
        macos)     _node_trust_uninstall_macos ;;
        linux|wsl) _node_trust_uninstall_linux ;;
    esac
    [ "$platform" = "wsl" ] && _node_trust_uninstall_wsl_windows
    _node_trust_uninstall_jb
    return 0
}

: "${YELLOW:=$'\033[1;33m'}"
: "${BLUE:=$'\033[1;34m'}"
: "${GREEN:=$'\033[0;32m'}"
: "${BOLD:=$'\033[1m'}"
: "${NC:=$'\033[0m'}"

_node_trust_emit_restart_hints() {
    local cert="$1"
    local detected
    detected="$(node_trust_configured_ides)"

    log_silent "node-trust: cert=${cert}"
    if [ -z "$detected" ]; then
        log_silent "node-trust: no configured IDEs in mcp-install.log; skipping restart hint."
        return 0
    fi

    # User-facing block: this is the sole user action gating the install.
    echo ""
    echo -e "${BOLD}${BLUE}One-time IDE restart required${NC} ${YELLOW}(coding agents must reload to trust the local MCP cert):${NC}"
    while IFS= read -r ide; do
        [ -n "$ide" ] || continue
        printf "  ${GREEN}•${NC} %s — %s\n" "$ide" "$(_node_trust_restart_action "$ide")"
    done <<< "$detected"
    echo ""
}

export -f node_trust_install
export -f node_trust_uninstall
export -f node_trust_configured_ides
