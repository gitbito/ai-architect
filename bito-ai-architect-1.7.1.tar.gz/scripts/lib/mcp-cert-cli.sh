#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
#
# `bitoarch mcp-cert <subcmd>` dispatcher.

if [ -n "${_BITOARCH_MCP_CERT_CLI_LIB_LOADED:-}" ]; then
    return 0
fi
_BITOARCH_MCP_CERT_CLI_LIB_LOADED=1

# scripts/bitoarch.sh sets SCRIPT_DIR=scripts/, not the project root, so
# derive from BASH_SOURCE regardless.
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
PLATFORM_DIR="$SCRIPT_DIR"

# shellcheck disable=SC1091
[ -f "${SCRIPT_DIR}/scripts/lib/path-manager.sh" ] && source "${SCRIPT_DIR}/scripts/lib/path-manager.sh"
# shellcheck disable=SC1091
[ -f "${SCRIPT_DIR}/scripts/lib/mcp-cert.sh" ]     && source "${SCRIPT_DIR}/scripts/lib/mcp-cert.sh"
# shellcheck disable=SC1091
[ -f "${SCRIPT_DIR}/scripts/lib/cert-cron.sh" ]    && source "${SCRIPT_DIR}/scripts/lib/cert-cron.sh"

if ! command -v msg_info    >/dev/null 2>&1; then msg_info()    { echo "[INFO] $*"  >&2; }; fi
if ! command -v msg_warn    >/dev/null 2>&1; then msg_warn()    { echo "[WARN] $*"  >&2; }; fi
if ! command -v msg_error   >/dev/null 2>&1; then msg_error()   { echo "[ERROR] $*" >&2; }; fi
if ! command -v msg_success >/dev/null 2>&1; then msg_success() { echo "[OK] $*"    >&2; }; fi
if ! command -v log_silent  >/dev/null 2>&1; then log_silent()  { :; }; fi

: "${YELLOW:=$'\033[1;33m'}"
: "${GREEN:=$'\033[0;32m'}"
: "${RED:=$'\033[0;31m'}"
: "${BLUE:=$'\033[1;34m'}"
: "${NC:=$'\033[0m'}"

_mcp_cert_cli_help() {
    cat <<EOF
USAGE:
  bitoarch mcp-cert <subcommand>

SUBCOMMANDS:
  status              Show cert verdict, days remaining, paths, scheduler state
  renew               Force re-issue cert; restart cis-provider so it loads
  renew --check       Renew only if expiring within 60 days (cron entry point)
  paths               Print cert path
  schedule            Show current renew time + scheduler state
  schedule HH:MM      Set renew time (24h) and reinstall the scheduler
  --help, -h          Show this help

NOTES:
  Auto-renewal runs daily at 09:30 via the OS-native scheduler (launchd on
  macOS, systemd-user timer or crontab on Linux). Override the time with
  \`bitoarch mcp-cert schedule HH:MM\` (persists to .env-bitoarch). To opt
  out entirely, set BITOARCH_CERT_AUTO_RENEW=false in .env-bitoarch and
  re-run \`bitoarch install\`.
EOF
}

_mcp_cert_cli_render_status() {
    local summary verdict days cert sched
    summary="$(mcp_cert_status_summary 2>/dev/null)"
    verdict="$(echo "$summary" | cut -d'|' -f1)"
    days="$(echo "$summary"    | cut -d'|' -f2)"
    cert="$(echo "$summary"    | cut -d'|' -f3-)"

    # cert_cron_status intentionally returns rc=1 when "not scheduled" so other
    # callers can branch on it. We don't care about the rc here -- only the
    # text -- and we have to defend against any caller that has `set -e` on.
    if command -v cert_cron_status >/dev/null 2>&1; then
        sched="$(cert_cron_status 2>/dev/null || true)"
    else
        sched="unknown"
    fi
    [ -n "$sched" ] || sched="unknown"

    echo ""
    echo -e "${BLUE}MCP cert status${NC}"
    case "$verdict" in
        ok)          printf "  Verdict:   ${GREEN}✓ valid${NC} for %s days\n" "$days" ;;
        warn)        printf "  Verdict:   ${YELLOW}⚠ expires in %s days${NC} — run \`bitoarch mcp-cert renew\`\n" "$days" ;;
        expired)     printf "  Verdict:   ${RED}✗ expired${NC} — run \`bitoarch mcp-cert renew\`\n" ;;
        missing)     printf "  Verdict:   ${RED}✗ cert not found${NC} — run \`bitoarch mcp-cert renew\` or re-install\n" ;;
        unsupported) printf "  Verdict:   ${YELLOW}⚠ cannot determine${NC} (openssl missing or notAfter unparsable)\n" ;;
        *)           printf "  Verdict:   %s\n" "${verdict:-unknown}" ;;
    esac
    printf "  Cert:      %s\n" "$cert"
    printf "  Scheduler: %s\n" "$sched"
    echo ""
}

_mcp_cert_cli_force_renew() {
    if ! command -v mcp_cert_regenerate >/dev/null 2>&1; then
        msg_error "mcp_cert_regenerate not available"
        return 1
    fi

    msg_info "Regenerating MCP cert (forced)..."
    if ! mcp_cert_regenerate; then
        msg_error "Cert regeneration failed; see setup.log"
        return 1
    fi
    msg_success "Cert regenerated"

    # Export HOST_MCP_CERT_DIR + XMCP_INTERNAL_PORT so xmcp_restart_provider's
    # docker-compose invocation mounts the freshly-issued cert.
    mcp_cert_prepare_for_compose >/dev/null 2>&1 || true

    if [ -f "${SCRIPT_DIR}/scripts/lib/adapters/xmcp-adapter.sh" ]; then
        # shellcheck disable=SC1091
        source "${SCRIPT_DIR}/scripts/lib/adapters/xmcp-adapter.sh"
        if command -v xmcp_restart_provider >/dev/null 2>&1; then
            msg_info "Restarting cis-provider..."
            if xmcp_restart_provider >/dev/null 2>&1; then
                msg_success "cis-provider restarted"
            else
                msg_warn "cis-provider restart skipped/failed (cert will load on next start)"
            fi
        fi
    fi

    if [ -f "${SCRIPT_DIR}/scripts/lib/node-trust.sh" ]; then
        # shellcheck disable=SC1091
        source "${SCRIPT_DIR}/scripts/lib/node-trust.sh"
        command -v node_trust_install >/dev/null 2>&1 && \
            node_trust_install >/dev/null 2>&1 || true
    fi
    return 0
}

_mcp_cert_cli_paths() {
    printf "Cert: %s\n" "$(_mcp_cert_crt_path 2>/dev/null)"
}

# Persists BITOARCH_CERT_RENEW_TIME=HH:MM to .env-bitoarch and re-installs
# the scheduler so the new time takes effect immediately.
_mcp_cert_cli_schedule() {
    local arg="${1:-}"
    if [ -z "$arg" ] || [ "$arg" = "show" ]; then
        local _t _s
        _t="$(cert_cron_time 2>/dev/null || true)"
        _s="$(cert_cron_status 2>/dev/null || true)"
        printf "Renew time: %s\n" "${_t:-09:30}"
        printf "Scheduler:  %s\n" "${_s:-unknown}"
        return 0
    fi
    if ! cert_cron_time_validate "$arg"; then
        msg_error "Invalid time format: '${arg}'. Expected HH:MM (24h, e.g. 14:45)."
        return 1
    fi
    local env_file
    env_file="$(get_config_file 2>/dev/null)"
    if [ -z "$env_file" ] || [ ! -f "$env_file" ]; then
        msg_error "Config file not found; install first or run from an installed host."
        return 1
    fi
    if grep -qE '^[[:space:]]*BITOARCH_CERT_RENEW_TIME[[:space:]]*=' "$env_file"; then
        local tmp="${env_file}.tmp.$$"
        sed -E "s|^[[:space:]]*BITOARCH_CERT_RENEW_TIME[[:space:]]*=.*|BITOARCH_CERT_RENEW_TIME=${arg}|" \
            "$env_file" > "$tmp" && mv "$tmp" "$env_file"
    else
        echo "BITOARCH_CERT_RENEW_TIME=${arg}" >> "$env_file"
    fi
    log_silent "mcp-cert schedule: persisted BITOARCH_CERT_RENEW_TIME=${arg} to ${env_file}"

    BITOARCH_CERT_RENEW_TIME="$arg" cert_cron_install || {
        msg_error "Scheduler reinstall failed; see setup.log."
        return 1
    }
    msg_success "Renew time set to ${arg}; scheduler updated."
}

mcp_cert_cli() {
    local subcmd="${1:-}"
    shift || true

    case "$subcmd" in
        ""|--help|-h|help)
            _mcp_cert_cli_help
            return 0
            ;;
        status)
            _mcp_cert_cli_render_status
            return 0
            ;;
        renew)
            local check=false
            while [ $# -gt 0 ]; do
                case "$1" in
                    --check) check=true; shift ;;
                    *) msg_error "Unknown argument: $1"; return 1 ;;
                esac
            done
            if [ "$check" = "true" ]; then
                mcp_cert_renew_check
                local _summary _verdict _days
                _summary="$(mcp_cert_status_summary)"
                _verdict="${_summary%%|*}"
                _days="$(echo "$_summary" | cut -d'|' -f2)"
                case "$_verdict" in
                    ok)          msg_info    "Cert valid for ${_days} days; no renewal needed." ;;
                    warn)        msg_success "Cert renewed (was within 60-day window)." ;;
                    expired)     msg_success "Cert renewed (was expired)." ;;
                    missing)     msg_warn    "Cert generation skipped or failed; see setup.log." ;;
                    unsupported) msg_warn    "Cert state cannot be determined (openssl missing)." ;;
                esac
                return 0
            fi
            _mcp_cert_cli_force_renew
            return $?
            ;;
        paths)
            _mcp_cert_cli_paths
            return 0
            ;;
        schedule)
            _mcp_cert_cli_schedule "$@"
            return $?
            ;;
        *)
            msg_error "Unknown mcp-cert subcommand: $subcmd"
            echo ""
            _mcp_cert_cli_help
            return 1
            ;;
    esac
}

export -f mcp_cert_cli
