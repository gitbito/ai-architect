#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
#
# `bitoarch uninstall` = reset_run (shared with setup.sh --clean) + CLI
# symlink + install.yaml + system paths + install dir.

if [ -n "${_BITOARCH_UNINSTALL_LIB_LOADED:-}" ]; then
    return 0
fi
_BITOARCH_UNINSTALL_LIB_LOADED=1

if [ -z "${PLATFORM_DIR:-}" ]; then
    PLATFORM_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
fi

uninstall_run() {
    if [ "${1:-}" = "--help" ] || [ "${1:-}" = "-h" ]; then
        _uninstall_show_help
        return 0
    fi

    _uninstall_confirm || { print_info "Uninstall cancelled."; return 0; }

    # Deregister the local MCP from coding agents BEFORE reset_run so the
    # cis-provider container is still reachable for the bootstrap's checks.
    # Best-effort -- never blocks uninstall.
    if [ -f "${PLATFORM_DIR}/scripts/lib/mcp-installer.sh" ]; then
        # shellcheck disable=SC1091
        source "${PLATFORM_DIR}/scripts/lib/mcp-installer.sh"
        mcp_installer_uninstall || true
    fi

    if [ -f "${PLATFORM_DIR}/scripts/lib/node-trust.sh" ]; then
        # shellcheck disable=SC1091
        source "${PLATFORM_DIR}/scripts/lib/node-trust.sh"
        node_trust_uninstall || true
    fi
    if [ -f "${PLATFORM_DIR}/scripts/lib/cert-cron.sh" ]; then
        # shellcheck disable=SC1091
        source "${PLATFORM_DIR}/scripts/lib/cert-cron.sh"
        cert_cron_uninstall || true
    fi
    if [ -f "${PLATFORM_DIR}/scripts/lib/mcp-cert.sh" ]; then
        # shellcheck disable=SC1091
        source "${PLATFORM_DIR}/scripts/lib/mcp-cert.sh"
        mcp_cert_trust_uninstall || true
    fi
    # Wipe the bitoarch user cache (mkcert binary + leaf cert + key). Path
    # comes from path-manager so layouts only need updating in one place.
    if command -v get_user_cache_dir >/dev/null 2>&1; then
        local _cache_dir
        _cache_dir="$(get_user_cache_dir 2>/dev/null)"
        [ -n "$_cache_dir" ] && [ -d "$_cache_dir" ] && rm -rf "$_cache_dir" 2>/dev/null || true
    fi

    # AUTO_SETUP=true skips reset_run's prompt (_uninstall_confirm already ran).
    if [ -f "${PLATFORM_DIR}/scripts/lib/reset.sh" ]; then
        # shellcheck disable=SC1091
        source "${PLATFORM_DIR}/scripts/lib/reset.sh"
        AUTO_SETUP=true reset_run || \
            print_warning "Reset reported errors; continuing uninstall"
    else
        print_warning "reset.sh not found at ${PLATFORM_DIR}/scripts/lib/; skipping service cleanup"
    fi

    _uninstall_remove_cli_symlink
    _uninstall_remove_install_yaml
    _uninstall_remove_system_paths
    _uninstall_remove_install_dir
    _uninstall_remove_conventional_install_dir
}

# Removes both layouts' trees (system + user) since machines that toggled
# layouts may have both. Path list comes from path-manager constants only.
_uninstall_remove_system_paths() {
    if [ -z "${BITOARCH_SYSTEM_CONFIG_DIR:-}" ] || [ -z "${BITOARCH_USER_CONFIG_DIR:-}" ]; then
        print_warning "path-manager.sh constants unavailable; skipping system-path cleanup."
        print_info    "Run manually: sudo rm -rf /usr/local/etc/bitoarch /usr/local/var/bitoarch /usr/local/lib/bitoarch"
        print_info    "Run manually: rm -rf \"\${HOME}/.local/bitoarch\""
        return 0
    fi

    local paths_to_nuke=()
    local v
    for v in BITOARCH_SYSTEM_CONFIG_DIR BITOARCH_SYSTEM_VAR_DIR BITOARCH_SYSTEM_LIB_DIR \
             BITOARCH_USER_CONFIG_DIR   BITOARCH_USER_VAR_DIR   BITOARCH_USER_LIB_DIR; do
        [ -n "${!v:-}" ] && paths_to_nuke+=("${!v}")
    done

    local system_prefix="${BITOARCH_SYSTEM_PREFIX:-/usr/local}"
    local user_prefix="${BITOARCH_USER_PREFIX:-${HOME}/.local}"

    local p
    local needs_sudo=false
    for p in "${paths_to_nuke[@]}"; do
        [ -d "$p" ] || continue
        case "$p" in
            "${system_prefix}"/*) needs_sudo=true ;;
        esac
    done

    # Pre-auth visibly: without this, sudo rm silently fails under redirected stderr.
    if $needs_sudo && command -v sudo >/dev/null 2>&1; then
        print_info "Removing system paths under ${system_prefix} may require sudo."
        if ! sudo -v; then
            print_warning "Could not obtain sudo credentials; ${system_prefix} paths will remain."
            needs_sudo=false
        fi
    fi

    for p in "${paths_to_nuke[@]}"; do
        [ -d "$p" ] || continue

        if rm -rf "$p" 2>/dev/null && [ ! -d "$p" ]; then
            log_silent "Removed system path: $p"
            continue
        fi

        if $needs_sudo; then
            sudo rm -rf "$p"
        fi

        if [ -d "$p" ]; then
            print_error "Failed to remove ${p}"
            print_info  "Run manually: sudo rm -rf \"${p}\""
        else
            log_silent "Removed system path: $p"
        fi
    done

    rmdir "${user_prefix}/bitoarch" 2>/dev/null || true
}

# Both editions install to $HOME/bito-ai-architect; clean it even when
# PLATFORM_DIR points elsewhere (e.g. a release-staging dir the CLI linked from).
_uninstall_remove_conventional_install_dir() {
    local conventional_dir="${HOME}/bito-ai-architect"

    [ -d "$conventional_dir" ] || return 0

    case "$conventional_dir" in
        "$PLATFORM_DIR"|"${PLATFORM_DIR%/}"/) return 0 ;;
    esac

    if [ -d "${conventional_dir}/.git" ]; then
        print_warning "Legacy install dir contains a .git/ (looks like a git clone); NOT removing: ${conventional_dir}"
        return 0
    fi

    if [ ! -f "${conventional_dir}/setup.sh" ] && \
       [ ! -f "${conventional_dir}/scripts/bitoarch.sh" ] && \
       [ ! -f "${conventional_dir}/bitoarch" ]; then
        return 0
    fi

    print_info "Removing legacy installation directory: ${conventional_dir}..."
    if ! rm -rf "$conventional_dir" 2>/dev/null; then
        sudo rm -rf "$conventional_dir" 2>/dev/null || \
            print_warning "Could not remove ${conventional_dir}; please remove manually"
    fi
}

# AUTO_SETUP=true skips this prompt (CDN uninstall bootstrap prompts upstream).
_uninstall_confirm() {
    if [ "${AUTO_SETUP:-}" = "true" ]; then
        return 0
    fi

    echo ""
    print_warning "${YELLOW:-}This will COMPLETELY remove Bito AI Architect from this machine:${NC:-}"
    echo "  - All containers and named volumes"
    echo "  - All configuration files and logs"
    echo "  - The bitoarch CLI symlink + ~/.bitoarch/install.yaml"
    echo "  - The installation directory"
    echo ""
    echo "Docker IMAGES are kept (run 'docker image prune' to reclaim space)."
    echo ""
    local reply
    read -r -p "Type 'yes' to confirm: " reply
    echo ""
    [ "$reply" = "yes" ]
}

_uninstall_remove_install_yaml() {
    local dir="${HOME}/.bitoarch"
    [ -d "$dir" ] || return 0

    rm -f "${dir}/install.yaml"         2>/dev/null
    rm -f "${dir}/install.yaml.bkp"     2>/dev/null
    rm -f "${dir}/install.yaml.default" 2>/dev/null
    find "$dir" -maxdepth 1 -name 'install.yaml.backup*' -delete 2>/dev/null || true

    # rmdir only removes if empty — safe if user has unrelated files under ~/.bitoarch/.
    rmdir "$dir" 2>/dev/null && log_silent "Removed empty install yaml dir: $dir"
    return 0
}

# -----------------------------------------------------------------------------
# Help
# -----------------------------------------------------------------------------
_uninstall_show_help() {
    cat <<EOF
USAGE:
  bitoarch uninstall
  <cdn-uninstall-url> | bash       (for broken-CLI recovery; CDN-hosted)

DESCRIPTION:
  Completely remove Bito AI Architect from this machine. Strict superset of
  \`bitoarch reset\`: removes everything reset removes, PLUS the bitoarch
  CLI symlink and the installation directory.

WHAT IS REMOVED (everything reset removes, plus):
  - \$HOME/.local/bin/bitoarch   (the CLI symlink)
  - ~/.bitoarch/                (install.yaml + .bkp/.backup* variants)
  - ~/bito-ai-architect/        (installation directory)
  - Release tarballs under <install-dir>/releases/
  - Standard-path config + var trees for BOTH layouts (logs, backups,
    templates, stale configs):
      /usr/local/etc/bitoarch/, /usr/local/var/bitoarch/   (system layout)
      ~/.local/bitoarch/etc/,  ~/.local/bitoarch/var/      (user layout)

WHAT IS KEPT:
  - Docker images (run \`docker image prune\` to reclaim space)

OPTIONS:
  --help, -h    Show this help

NOTES:
  Non-reversible. To re-install afterward, re-run the install bootstrap
  (see ${AI_ARCHITECT_DOCS_URL:-https://docs.bito.ai/ai-architect/install-ai-architect-self-hosted}).

  SAFETY: if the install directory contains a .git/ (i.e. is a cloned
  repository), the directory is NOT removed. Use \`bitoarch reset\` instead.
EOF
}

_uninstall_remove_cli_symlink() {
    local cli_target="$HOME/.local/bin/bitoarch"
    if [ -L "$cli_target" ] || [ -f "$cli_target" ]; then
        rm -f "$cli_target" 2>/dev/null && log_silent "CLI symlink removed"
    fi
}

# Guards: suspicious paths, git working trees (dev clones), non-bitoarch dirs.
_uninstall_remove_install_dir() {
    local install_dir="${PLATFORM_DIR}"

    case "$install_dir" in
        ""|"/"|"/tmp"|"$HOME"|"/home"|"/root"|"/etc"|"/usr"|"/usr/local"|"/var")
            print_error "Refusing to remove suspicious install directory: ${install_dir}"
            print_info  "Please remove manually if intended."
            return 1
            ;;
    esac

    if [ -d "${install_dir}/.git" ]; then
        print_warning "Install directory contains a .git/ (looks like a git clone); NOT removing."
        print_info    "Install dir kept:  ${install_dir}"
        print_info    "If this was intentional, remove the directory manually after confirming."
        return 0
    fi

    if [ ! -f "${install_dir}/setup.sh" ] && \
       [ ! -f "${install_dir}/scripts/bitoarch.sh" ]; then
        print_warning "Install dir ${install_dir} does not look like a bitoarch install; skipping"
        return 0
    fi

    print_info "Removing installation directory: ${install_dir}..."

    # setup.sh --clean may leave LOG_FILE inside install_dir; silence it.
    LOG_FILE=/dev/null

    [ -d "${install_dir}/releases" ] && rm -rf "${install_dir}/releases" 2>/dev/null || true
    cd "$HOME" 2>/dev/null || cd / 2>/dev/null || true

    rm -rf "$install_dir" 2>/dev/null
    if [ -d "$install_dir" ] && command -v sudo >/dev/null 2>&1; then
        sudo rm -rf "$install_dir"
    fi

    if [ -d "$install_dir" ]; then
        print_error "Failed to remove installation directory: ${install_dir}"
        print_info  "Run manually: sudo rm -rf \"${install_dir}\""
    else
        print_info "Installation directory removed"
    fi
    echo ""
    echo "To reinstall, re-run your install command."
}
