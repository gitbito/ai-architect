#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai

# AI Architect Service Builder
# This script builds service binaries from sibling repositories

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Get the parent directory (where all repos should be)
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PARENT_DIR="$(dirname "$SCRIPT_DIR")"

# Print colored output
print_status() {
    echo -e "${GREEN}✓${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}⚠${NC} $1"
}

print_error() {
    echo -e "${RED}✗${NC} $1"
}

print_info() {
    echo -e "${BLUE}ℹ${NC} $1"
}

# Function to build a Go service
build_go_service() {
    local service_name=$1
    local repo_path="$PARENT_DIR/$service_name"
    local output_dir="$SCRIPT_DIR/services/$service_name/bin"
    local binary_name="$service_name"
    
    print_info "Building $service_name..."
    
    # Check if repository exists
    if [ ! -d "$repo_path" ]; then
        print_error "Repository not found: $repo_path"
        return 1
    fi
    
    # Create output directory
    mkdir -p "$output_dir"
    
    # Change to repository directory
    cd "$repo_path"
    
    # Check if it's a Go project
    if [ ! -f "go.mod" ]; then
        print_error "go.mod not found in $repo_path. Not a Go project?"
        return 1
    fi
    
    # Build the binary
    print_info "  Building Go binary for $service_name..."
    if go build -o "$output_dir/$binary_name" .; then
        print_status "  Successfully built $service_name binary"
        chmod +x "$output_dir/$binary_name"
        
        # Show binary info
        local binary_size=$(du -sh "$output_dir/$binary_name" | cut -f1)
        print_info "  Binary size: $binary_size"
        print_info "  Location: $output_dir/$binary_name"
    else
        print_error "  Failed to build $service_name"
        return 1
    fi
    
    return 0
}

# Function to build Node.js service (cis-provider)
build_node_service() {
    local service_name=$1
    local repo_path="$PARENT_DIR/$service_name"
    local output_dir="$SCRIPT_DIR/services/$service_name"
    
    print_info "Setting up $service_name (Node.js)..."
    
    # Check if repository exists
    if [ ! -d "$repo_path" ]; then
        print_error "Repository not found: $repo_path"
        return 1
    fi
    
    # Check if it's a Node.js project
    if [ ! -f "$repo_path/package.json" ]; then
        print_error "package.json not found in $repo_path. Not a Node.js project?"
        return 1
    fi
    
    # Copy source files to the service directory
    print_info "  Copying source files..."
    
    # Create necessary directories
    mkdir -p "$output_dir/src"
    mkdir -p "$output_dir/config"
    
    # Copy package.json and source files
    cp "$repo_path/package.json" "$output_dir/"
    
    # Copy source directory if it exists
    if [ -d "$repo_path/src" ]; then
        cp -r "$repo_path/src/"* "$output_dir/src/"
    fi
    
    # Copy config files if they exist
    if [ -d "$repo_path/config" ]; then
        cp -r "$repo_path/config/"* "$output_dir/config/" 2>/dev/null || true
    fi
    
    # Copy additional files that might be needed
    for file in "index.js" "server.js" "app.js" ".env-bitoarch.default"; do
        if [ -f "$repo_path/$file" ]; then
            cp "$repo_path/$file" "$output_dir/"
        fi
    done
    
    print_status "  Successfully set up $service_name"
    return 0
}

# Main execution
main() {
    echo -e "${BLUE}CIS Platform Service Builder${NC}"
    echo "==============================="
    echo ""
    
    print_info "Parent directory: $PARENT_DIR"
    print_info "CIS Platform directory: $SCRIPT_DIR"
    echo ""
    
    # Build services
    local failed_services=()
    
    # Build cis-config (Go service)
    if ! build_go_service "cis-config"; then
        failed_services+=("cis-config")
    fi
    echo ""
    
    # Build cis-manager (Go service)  
    if ! build_go_service "cis-manager"; then
        failed_services+=("cis-manager")
    fi
    echo ""
    
    # Check if cis-provider exists as separate repo
    if [ -d "$PARENT_DIR/cis-provider" ]; then
        print_info "Found separate cis-provider repository"
        if ! build_node_service "cis-provider"; then
            failed_services+=("cis-provider")
        fi
    else
        print_info "Using existing cis-provider setup in platform"
    fi
    
    # Summary
    echo ""
    echo "==============================="
    if [ ${#failed_services[@]} -eq 0 ]; then
        print_status "All services built successfully!"
        echo ""
        print_info "Next steps:"
        print_info "1. Run './setup.sh' to deploy the platform"
        print_info "2. Services will use the newly built binaries"
    else
        print_error "Failed to build: ${failed_services[*]}"
        echo ""
        print_info "Please check the error messages above and ensure:"
        print_info "1. All repositories exist in $PARENT_DIR"
        print_info "2. Go is installed and available in PATH"
        print_info "3. All dependencies are satisfied"
        exit 1
    fi
}

# Handle command line arguments
case "${1:-}" in
    --help|-h)
        echo "CIS Platform Service Builder"
        echo ""
        echo "Usage: $0 [service_name]"
        echo ""
        echo "Options:"
        echo "  --help, -h           Show this help message"
        echo "  cis-config           Build only cis-config service"
        echo "  cis-manager          Build only cis-manager service" 
        echo "  cis-provider         Build only cis-provider service"
        echo ""
        echo "If no service is specified, all services will be built."
        ;;
    cis-config)
        print_info "Building only cis-config..."
        build_go_service "cis-config"
        ;;
    cis-manager)
        print_info "Building only cis-manager..."
        build_go_service "cis-manager"
        ;;
    cis-provider)
        print_info "Building only cis-provider..."
        build_node_service "cis-provider"
        ;;
    "")
        main
        ;;
    *)
        print_error "Unknown service: $1"
        echo "Run '$0 --help' for usage information"
        exit 1
        ;;
esac
