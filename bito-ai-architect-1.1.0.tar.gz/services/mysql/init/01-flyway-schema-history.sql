--
-- Copyright (c) 2023-2025 Bito Inc.
-- All rights reserved.
--
-- This source code is proprietary and confidential to Bito Inc.
-- Unauthorized copying, modification, distribution, or use is strictly prohibited.
--
-- For licensing information, see the COPYRIGHT file in the root directory.
--
-- @company Bito Inc.
-- @website https://bito.ai
--
-- ============================================================================
-- Flyway Schema History Tables for CIS Services
-- ============================================================================
-- These tables track SQL migrations for cis-config and cis-manager services
-- following Flyway's schema history pattern

-- ============================================================================
-- Flyway Schema History for CIS Config Service (in code_intelligence database)
-- ============================================================================
USE code_intelligence;

CREATE TABLE IF NOT EXISTS flyway_schema_history_config (
    installed_rank INT NOT NULL,
    version VARCHAR(50),
    description VARCHAR(200) NOT NULL,
    type VARCHAR(20) NOT NULL,
    script VARCHAR(1000) NOT NULL,
    checksum INT,
    installed_by VARCHAR(100) NOT NULL,
    installed_on TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    execution_time INT NOT NULL,
    success BOOLEAN NOT NULL,
    PRIMARY KEY (installed_rank),
    INDEX idx_config_success (success)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- CIS Config baseline migration
INSERT INTO flyway_schema_history_config 
(installed_rank, version, description, type, script, checksum, installed_by, execution_time, success)
VALUES 
(1, '1.0.0', 'Baseline - Initial schema from Docker image', 'SQL', '001_CREATE_CIS_TABLE.sql', 0, 'cis_platform', 0, TRUE)
ON DUPLICATE KEY UPDATE version=version;

-- ============================================================================
-- Flyway Schema History for CIS Manager Service (in code_intelligence database)
-- ============================================================================
USE code_intelligence;

CREATE TABLE IF NOT EXISTS flyway_schema_history_manager (
    installed_rank INT NOT NULL,
    version VARCHAR(50),
    description VARCHAR(200) NOT NULL,
    type VARCHAR(20) NOT NULL,
    script VARCHAR(1000) NOT NULL,
    checksum INT,
    installed_by VARCHAR(100) NOT NULL,
    installed_on TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    execution_time INT NOT NULL,
    success BOOLEAN NOT NULL,
    PRIMARY KEY (installed_rank),
    INDEX idx_manager_success (success)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- CIS Manager baseline migration
INSERT INTO flyway_schema_history_manager
(installed_rank, version, description, type, script, checksum, installed_by, execution_time, success)
VALUES 
(1, '1.0.0', 'Baseline - Initial schema from Docker image', 'SQL', 'database.sql', 0, 'cis_platform', 0, TRUE)
ON DUPLICATE KEY UPDATE version=version;

COMMIT;
