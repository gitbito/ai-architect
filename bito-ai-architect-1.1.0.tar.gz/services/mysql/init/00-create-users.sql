--
-- Copyright (c) 2023-2025 Bito Inc.
-- All rights reserved.
--
-- This source code is proprietary and confidential to Bito Inc.
-- Unauthorized copying, modification, distribution, or use is strictly prohibited.
--
-- For licensing information, see the COPYRIGHT file in the root directory.
--
-- @company Bito Inc.
-- @website https://bito.ai
--
-- ============================================================================
-- CIS Platform User Management
-- MySQL 8.0 Compatible, Cross-Platform (macOS, Linux, Windows)
-- ============================================================================

-- This script runs automatically when MySQL container is first created.
-- Docker MySQL automatically creates 'cis_user' from MYSQL_USER and MYSQL_PASSWORD env vars.
-- We grant permissions to this user for the code_intelligence database.

-- ============================================================================
-- Future: Per-Service Users (Currently Not Used)
-- ============================================================================
-- Uncomment and update docker-compose.yml to use dedicated users per service
-- for improved security. Replace hardcoded passwords with env vars when enabling.

-- CREATE USER IF NOT EXISTS 'cis_config_user'@'%' IDENTIFIED BY 'PLACEHOLDER_CONFIG_PASS';
-- GRANT ALL PRIVILEGES ON `code_intelligence`.* TO 'cis_config_user'@'%';

-- CREATE USER IF NOT EXISTS 'cis_manager_user'@'%' IDENTIFIED BY 'PLACEHOLDER_MANAGER_PASS';
-- GRANT ALL PRIVILEGES ON `code_intelligence`.* TO 'cis_manager_user'@'%';

-- CREATE USER IF NOT EXISTS 'cis_provider_user'@'%' IDENTIFIED BY 'PLACEHOLDER_PROVIDER_PASS';
-- GRANT ALL PRIVILEGES ON `code_intelligence`.* TO 'cis_provider_user'@'%';

-- ============================================================================
-- Shared User (Backward Compatibility)
-- ============================================================================
-- Docker automatically creates 'cis_user'@'%' from MYSQL_USER and MYSQL_PASSWORD env vars
-- This user can connect from any host (%), including Docker network IPs like 172.18.0.x
-- We just need to grant proper permissions to this user

-- Grant privileges to the user Docker created (cis_user@'%')
-- Note: Docker already created this user with the correct password from MYSQL_PASSWORD env var
GRANT ALL PRIVILEGES ON `code_intelligence`.* TO 'cis_user'@'%';

-- ============================================================================
-- Apply Changes
-- ============================================================================
FLUSH PRIVILEGES;

-- ============================================================================
-- NOTES:
-- - All services currently use 'cis_user' in docker-compose.yml
-- - To use per-service users, update docker-compose.yml environment:
--     cis-config: DB_USER=cis_config_user, DB_PASSWORD=cis_config_pass_2024!
--     cis-manager: DB_USER=cis_manager_user, DB_PASSWORD=cis_manager_pass_2024!
--     cis-provider: DB_USER=cis_provider_user, DB_PASSWORD=cis_provider_pass_2024!
-- ============================================================================
