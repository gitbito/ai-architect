#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
# MySQL Health Check Script for CIS Platform

set -e

# Use environment variables that match docker-compose.yml
DB_USER="${MYSQL_USER:-cis_user}"
DB_PASSWORD="${MYSQL_PASSWORD}"
DB_NAME="${MYSQL_DATABASE:-cis_platform}"

# Simple ping test first
if ! mysqladmin ping -h localhost --silent 2>/dev/null; then
    echo "MySQL server is not responding"
    exit 1
fi

# Test root connection if available
if [ -n "${MYSQL_ROOT_PASSWORD}" ]; then
    if mysqladmin ping -h localhost -u root -p"${MYSQL_ROOT_PASSWORD}" --silent 2>/dev/null; then
        echo "MySQL health check passed (root connection)"
        exit 0
    fi
fi

# Test user connection if credentials are available
if [ -n "${DB_PASSWORD}" ]; then
    if mysql -h localhost -u "${DB_USER}" -p"${DB_PASSWORD}" -e "SELECT 1;" "${DB_NAME}" >/dev/null 2>&1; then
        echo "MySQL health check passed (user connection)"
        exit 0
    fi
fi

# Fallback: just check if MySQL process is running
if mysqladmin ping -h localhost --silent 2>/dev/null; then
    echo "MySQL health check passed (basic ping)"
    exit 0
fi

echo "MySQL health check failed"
exit 1
