--
-- Copyright (c) 2023-2025 Bito Inc.
-- All rights reserved.
--
-- This source code is proprietary and confidential to Bito Inc.
-- Unauthorized copying, modification, distribution, or use is strictly prohibited.
--
-- For licensing information, see the COPYRIGHT file in the root directory.
--
-- @company Bito Inc.
-- @website https://bito.ai
--
USE code_intelligence;
-- Repository Metadata Table
CREATE TABLE IF NOT EXISTS repo_metadata (
    id VARCHAR(255) PRIMARY KEY,
    repo_name VARCHAR(255) NOT NULL,
    project_id VARCHAR(255) NOT NULL,
    integration_id BIGINT NOT NULL,
    provider VARCHAR(50) NOT NULL,
    workspace_id BIGINT NOT NULL,
    index_state VARCHAR(50) NOT NULL,
    last_commit_id VARCHAR(255),
    repo_size BIGINT,
    created TIMESTAMP NOT NULL,
    updated TIMESTAMP NOT NULL,
    last_sync TIMESTAMP,
    UNIQUE (repo_name, workspace_id)
);

-- Index Analytics Table
CREATE TABLE IF NOT EXISTS index_analytics (
    id VARCHAR(255) PRIMARY KEY,
    repo_id VARCHAR(255) NOT NULL,
    integration_id BIGINT NOT NULL,
    provider VARCHAR(50) NOT NULL,
    index_status VARCHAR(50) NOT NULL,
    start_time TIMESTAMP NOT NULL,
    end_time TIMESTAMP,
    error_reason TEXT,
    repo_name VARCHAR(255) NOT NULL,
    index_type VARCHAR(50) NOT NULL,
    commit_id VARCHAR(255),
    workspace_id BIGINT NOT NULL,
    created TIMESTAMP NOT NULL,
    updated TIMESTAMP NOT NULL,
    FOREIGN KEY (repo_id) REFERENCES repo_metadata(id)
);

-- Index Audit Table
CREATE TABLE IF NOT EXISTS index_audit (
    id VARCHAR(255) PRIMARY KEY,
    repo_id VARCHAR(255) NOT NULL,
    integration_id BIGINT NOT NULL,
    provider VARCHAR(50) NOT NULL,
    index_id VARCHAR(255) NOT NULL,
    index_current_state VARCHAR(50) NOT NULL,
    repo_name VARCHAR(255) NOT NULL,
    workspace_id BIGINT NOT NULL,
    created TIMESTAMP NOT NULL,
    FOREIGN KEY (repo_id) REFERENCES repo_metadata(id),
    FOREIGN KEY (index_id) REFERENCES index_analytics(id)
);

-- Transient State Table
CREATE TABLE IF NOT EXISTS transient_state (
    repo_id VARCHAR(255) PRIMARY KEY,
    repo_name VARCHAR(255) NOT NULL,
    provider VARCHAR(50) NOT NULL,
    integration_id BIGINT NOT NULL,
    workspace_id BIGINT NOT NULL,
    state VARCHAR(50) NOT NULL,
    start_time TIMESTAMP NOT NULL,
    lock_expiry TIMESTAMP NOT NULL
);

-- Create indexes for common queries
CREATE INDEX idx_repo_metadata_workspace ON repo_metadata(workspace_id);
CREATE INDEX idx_repo_metadata_namespace ON repo_metadata(repo_name, workspace_id);
CREATE INDEX idx_index_analytics_repo ON index_analytics(repo_id);
CREATE INDEX idx_index_analytics_workspace ON index_analytics(workspace_id);
CREATE INDEX idx_index_audit_repo ON index_audit(repo_id);
CREATE INDEX idx_index_audit_workspace ON index_audit(workspace_id);

-- drop the foreign key constraints
ALTER TABLE index_audit DROP CONSTRAINT index_audit_ibfk_1;
ALTER TABLE index_audit DROP CONSTRAINT index_audit_ibfk_2;
ALTER TABLE index_analytics DROP CONSTRAINT index_analytics_ibfk_1;

CREATE TABLE `index_log` (
    `id` int(11)  NOT NULL AUTO_INCREMENT,
    `repo_id` VARCHAR(255) DEFAULT NULL,
    `workspace_id` BIGINT NOT NULL,
    `request_id` VARCHAR(255) NOT NULL,
    `event_type` VARCHAR(128) NOT NULL,
    `status` varchar(128) NOT NULL,
    `event_data` JSON NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_workspace_id` (`workspace_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
