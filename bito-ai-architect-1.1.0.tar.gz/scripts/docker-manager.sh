#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai

handle_docker_daemon() {
    local SUDO_CMD="$1"
    
    if is_container_environment; then
        print_info "Container environment detected"
        
        if [ -S /var/run/docker.sock ] && docker info >/dev/null 2>&1; then
            print_status "Docker configured (using host daemon)"
            return 0
        fi
        
        if command -v dockerd >/dev/null 2>&1; then
            print_info "Starting Docker daemon in container..."
            dockerd >/dev/null 2>&1 &
            
            # Fast retry loop - checks every second for up to 10 seconds
            # Most daemons start in 1-2 seconds, so minimal performance impact
            local wait_time=0
            while [ $wait_time -lt 10 ]; do
                if docker info >/dev/null 2>&1; then
                    print_status "Docker configured (container daemon ready)"
                    return 0
                fi
                sleep 1
                wait_time=$((wait_time + 1))
            done
            
            print_warning "Docker daemon not responding within 10 seconds"
        fi
        
        print_status "Docker Engine installed successfully"
        print_warning "Container environment - Docker daemon requires privileged mode or host socket"
    else
        print_info "Server environment - configuring Docker service..."
        
        if $SUDO_CMD systemctl start docker >/dev/null 2>&1 && \
           $SUDO_CMD systemctl enable docker >/dev/null 2>&1; then
            local wait_time=0
            while [ $wait_time -lt 30 ]; do
                if docker info >/dev/null 2>&1; then
                    print_status "Docker Engine installed and started successfully"
                    return 0
                fi
                sleep 2
                wait_time=$((wait_time + 2))
            done
            print_error "Docker service started but daemon not responding"
            exit 1
        else
            print_error "Failed to start Docker service"
            exit 1
        fi
    fi
}

install_docker_common() {
    local package_manager="$1"
    local distro_name="$2"
    local SUDO_CMD="$3"
    
    print_info "Installing Docker Engine on $distro_name..."
    
    curl -fsSL https://get.docker.com -o get-docker.sh
    $SUDO_CMD sh get-docker.sh
    
    if [ "$EUID" -ne 0 ]; then
        $SUDO_CMD usermod -aG docker $USER
    fi
    
    if ! is_container_environment; then
        $SUDO_CMD systemctl start docker >/dev/null 2>&1
        $SUDO_CMD systemctl enable docker >/dev/null 2>&1
    fi
    
    rm -f get-docker.sh
    
    handle_docker_daemon "$SUDO_CMD"
}

install_docker() {
    print_info "Installing Docker Engine for server deployment..."
    
    local SUDO_CMD=""
    if [ "$EUID" -ne 0 ]; then
        SUDO_CMD="sudo"
    fi
    
    if [[ "$OSTYPE" == "linux-gnu"* ]] || \
       [[ -f "/etc/redhat-release" ]] || \
       [[ -f "/etc/debian_version" ]]; then
        if command -v apt-get >/dev/null 2>&1; then
            install_docker_common "apt-get" "Ubuntu/Debian" "$SUDO_CMD"
        elif command -v yum >/dev/null 2>&1; then
            install_docker_common "yum" "CentOS/RHEL/Fedora" "$SUDO_CMD"
        elif command -v dnf >/dev/null 2>&1; then
            install_docker_common "dnf" "Modern Fedora/RHEL" "$SUDO_CMD"
        else
            print_error "Unsupported Linux distribution. Please install Docker manually."
            print_info "Supported: Ubuntu, Debian, CentOS, RHEL, Fedora"
            exit 1
        fi
    elif [[ "$OSTYPE" == "darwin"* ]]; then
        print_info "Docker Engine installation is not automated for macOS"
        print_info "This platform is designed for Linux server deployment"
        echo ""
        print_info "For local development on macOS, please install Docker manually:"
        echo ""
        print_info "OPTION 1: Install Docker + Colima (Recommended):"
        print_command "brew install docker docker-compose colima"
        print_command "colima start --cpu 2 --memory 4 --disk 20"
        echo ""
        print_info "OPTION 2: Install Docker Desktop (Alternative):"
        print_command "Download from: https://www.docker.com/products/docker-desktop"
        echo ""
        print_info "Then run this script again."
        exit 1
    else
        print_error "Unsupported operating system for server deployment: $OSTYPE"
        print_info "This script is designed for Linux server environments"
        print_info "Supported: Ubuntu, Debian, CentOS, RHEL, Fedora"
        print_info "For other systems, please install Docker manually"
        exit 1
    fi
}
