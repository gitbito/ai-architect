#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
# Bito's AI Architect CLI - Provider Adapter
# Handles Provider (MCP Server) commands

# List repositories
provider_repo_list() {
    # Check for help first
    if [ "$1" = "--help" ] || [ "$1" = "-h" ]; then
        cat << 'EOF'
USAGE:
  bitoarch index-repo-list [OPTIONS]

OPTIONS:
  --status <active|all>    Filter by status (default: all)
  --limit <number>         Limit results (default: 50)
  --format <table|json>    Output format
  --help, -h               Show this help

EXAMPLES:
  bitoarch index-repo-list
  bitoarch index-repo-list --status active
  bitoarch index-repo-list --limit 10 --format json
EOF
        return 0
    fi
    
    local status="all"
    local limit=50
    
    # Parse options
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --status)
                status="$2"
                shift 2
                ;;
            --status=*)
                status="${1#*=}"
                shift
                ;;
            --limit)
                limit="$2"
                shift 2
                ;;
            *)
                shift
                ;;
        esac
    done
    
    print_info "Listing repositories..."
    
    # Build arguments safely using jq (required for proper JSON escaping)
    if ! require_command jq; then
        print_error "jq is required for this operation"
        print_info "Install jq: brew install jq (macOS) or apt-get install jq (Ubuntu)"
        return 1
    fi
    
    # Build complete JSON-RPC request to call listRepositories tool with parsed arguments
    local request=$(jq -n --arg status "$status" --argjson limit "$limit" \
        '{jsonrpc: "2.0", method: "tools/call", id: 1, params: {name: "listRepositories", arguments: {status: $status, limit: $limit}}}')
    
    # Make MCP request
    local result=$(mcp_request "$request")
    if [ $? -ne 0 ]; then
        return 1
    fi
    
    # Format output
    format_mcp_content "$result" "$OUTPUT_FORMAT"
}

# Get repository info
provider_repo_info() {
    local name="$1"
    local dependencies="false"
    
    if [ -z "$name" ]; then
        print_error "Usage: bitoarch repo-info <name> [--dependencies]"
        return 1
    fi
    
    shift
    
    # Parse options
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --dependencies)
                dependencies="true"
                shift
                ;;
            *)
                shift
                ;;
        esac
    done
    
    print_info "Getting info for '$name'..."
    
    # Build arguments safely using jq (required for proper JSON escaping)
    if ! require_command jq; then
        print_error "jq is required for this operation"
        print_info "Install jq: brew install jq (macOS) or apt-get install jq (Ubuntu)"
        return 1
    fi
    
    # Build complete JSON-RPC request to call getRepositoryInfo tool
    local request=$(jq -n --arg name "$name" --arg deps "$dependencies" \
        '{jsonrpc: "2.0", method: "tools/call", id: 1, params: {name: "getRepositoryInfo", arguments: {repositoryName: $name, includeIncomingDependencies: ($deps == "true"), includeOutgoingDependencies: ($deps == "true")}}}')
    
    # Make MCP request
    local result=$(mcp_request "$request")
    if [ $? -ne 0 ]; then
        return 1
    fi
    
    format_mcp_content "$result" "$OUTPUT_FORMAT"
}

# Get MCP capabilities
provider_mcp_capabilities() {
    local output_file=""
    
    # Parse options
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --output|-o)
                output_file="$2"
                shift 2
                ;;
            --help|-h)
                cat << 'EOF'
USAGE:
  bitoarch mcp-capabilities [OPTIONS]

OPTIONS:
  --output, -o <file>    Save output to JSON file

EXAMPLES:
  bitoarch mcp-capabilities
  bitoarch mcp-capabilities --output capabilities.json
EOF
                return 0
                ;;
            *)
                shift
                ;;
        esac
    done
    
    # Build JSON-RPC request for initialize
    local request='{"jsonrpc": "2.0", "method": "initialize", "id": 1, "params": {"protocolVersion": "2024-11-05", "capabilities": {}, "clientInfo": {"name": "cis-cli", "version": "1.0.0"}}}'
    local auth_header="Authorization: Bearer $PROVIDER_TOKEN"
    
    local response=$(http_request "POST" "${PROVIDER_URL}/mcp" "$auth_header" "$request")
    if [ $? -ne 0 ]; then
        return 1
    fi
    
    # Output to file or formatted stdout
    if [ -n "$output_file" ]; then
        # Save beautified JSON to file
        if require_command jq; then
            echo "$response" | jq '.' > "$output_file"
        else
            echo "$response" > "$output_file"
        fi
        print_success "Output saved to: $output_file"
    else
        # Use standard formatting for stdout (same as repo list)
        format_mcp_content "$response" "$OUTPUT_FORMAT"
    fi
}

# List MCP tools
provider_mcp_tools() {
    local output_file=""
    local show_details="false"
    
    # Parse options
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --output|-o)
                output_file="$2"
                shift 2
                ;;
            --details|--summary)
                show_details="true"
                shift
                ;;
            --help|-h)
                cat << 'EOF'
USAGE:
  bitoarch mcp-tools [OPTIONS]

OPTIONS:
  --details, --summary   Show detailed tool information
  --output, -o <file>    Save output to JSON file

EXAMPLES:
  bitoarch mcp-tools                  List tool names only
  bitoarch mcp-tools --details        Show full tool details
  bitoarch mcp-tools --output tools.json
EOF
                return 0
                ;;
            *)
                shift
                ;;
        esac
    done
    
    # Build JSON-RPC request for tools/list
    local request='{"jsonrpc": "2.0", "method": "tools/list", "id": 1}'
    local auth_header="Authorization: Bearer $PROVIDER_TOKEN"
    
    local response=$(http_request "POST" "${PROVIDER_URL}/mcp" "$auth_header" "$request")
    if [ $? -ne 0 ]; then
        return 1
    fi
    
    # Output to file or formatted stdout
    if [ -n "$output_file" ]; then
        # Save beautified JSON to file
        if require_command jq; then
            echo "$response" | jq '.' > "$output_file"
        else
            echo "$response" > "$output_file"
        fi
        print_success "Output saved to: $output_file"
    else
        # Use block render function with show_details flag
        render_mcp_tools_list_block "$response" "$show_details"
    fi
}

# List MCP resources
provider_mcp_resources() {
    local output_file=""
    
    # Parse options
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --output|-o)
                output_file="$2"
                shift 2
                ;;
            --help|-h)
                cat << 'EOF'
USAGE:
  bitoarch mcp-resources [OPTIONS]

OPTIONS:
  --output, -o <file>    Save output to JSON file

EXAMPLES:
  bitoarch mcp-resources
  bitoarch mcp-resources --output resources.json
EOF
                return 0
                ;;
            *)
                shift
                ;;
        esac
    done
    
    # Build JSON-RPC request for resources/list
    local request='{"jsonrpc": "2.0", "method": "resources/list", "id": 1}'
    local auth_header="Authorization: Bearer $PROVIDER_TOKEN"
    
    local response=$(http_request "POST" "${PROVIDER_URL}/mcp" "$auth_header" "$request")
    if [ $? -ne 0 ]; then
        return 1
    fi
    
    # Output to file or formatted stdout
    if [ -n "$output_file" ]; then
        # Save beautified JSON to file
        if require_command jq; then
            echo "$response" | jq '.' > "$output_file"
        else
            echo "$response" > "$output_file"
        fi
        print_success "Output saved to: $output_file"
    else
        # Use standard formatting for stdout (same as repo list)
        format_mcp_content "$response" "$OUTPUT_FORMAT"
    fi
}

# Test MCP connection
provider_mcp_test() {
    print_info "Testing MCP connection..."
    
    # Test MCP endpoint directly with tools/list request using simple curl
    local response=$(curl -s --max-time 10 --connect-timeout 5 \
        -X POST "${PROVIDER_URL}/mcp" \
        -H "Authorization: Bearer $PROVIDER_TOKEN" \
        -H "Content-Type: application/json" \
        -d '{"jsonrpc": "2.0", "method": "tools/list", "id": 1}' 2>&1)
    
    local curl_exit=$?
    
    # Check curl exit code
    if [ $curl_exit -eq 0 ] && [ -n "$response" ]; then
        # Check if response contains valid MCP data
        if echo "$response" | grep -q '"result"'; then
            print_success "MCP endpoint: OK"
            print_success "Authentication: OK"
            print_success "Connection test passed"
            return 0
        fi
    fi
    
    # Handle specific error cases
    if [ $curl_exit -eq 28 ]; then
        print_error "MCP endpoint test failed: Connection timeout"
    elif [ $curl_exit -eq 7 ]; then
        print_error "MCP endpoint test failed: Cannot connect to server"
    else
        print_error "MCP endpoint test failed"
    fi
    
    echo "Endpoint: ${PROVIDER_URL}/mcp"
    echo "Check that the provider service is running: bitoarch status"
    return 1
}

# Get information about a specific MCP tool
provider_mcp_tool_info() {
    local tool_name="$1"
    
    if [ -z "$tool_name" ]; then
        print_error "Usage: bitoarch mcp-tool-info <toolname>"
        echo ""
        echo "EXAMPLE:"
        echo "  bitoarch mcp-tool-info listRepositories"
        return 1
    fi
    
    if ! require_command jq; then
        print_error "jq is required for this operation"
        return 1
    fi
    
    # Fetch tool list
    local request='{"jsonrpc": "2.0", "method": "tools/list", "id": 1}'
    local auth_header="Authorization: Bearer $PROVIDER_TOKEN"
    
    local response=$(http_request "POST" "${PROVIDER_URL}/mcp" "$auth_header" "$request")
    if [ $? -ne 0 ]; then
        return 1
    fi
    
    # Extract tool info
    local tool_data=$(echo "$response" | jq --arg name "$tool_name" '.result.tools[] | select(.name == $name)' 2>/dev/null)
    
    if [ -z "$tool_data" ] || [ "$tool_data" = "null" ]; then
        print_error "Tool '$tool_name' not found"
        echo ""
        echo "Use 'bitoarch mcp-tools' to see available tools"
        return 1
    fi
    
    # Extract fields
    local description=$(echo "$tool_data" | jq -r '.description // "No description available"')
    local schema=$(echo "$tool_data" | jq -r '.inputSchema // {}')
    
    # Display tool info
    echo ""
    echo -e "${BLUE}Tool: ${BOLD}$tool_name${NC}"
    echo ""
    echo -e "${CYAN}Description:${NC}"
    echo "  $description"
    echo ""
    
    # Display input schema if available
    if [ "$schema" != "{}" ] && [ "$schema" != "null" ]; then
        echo -e "${CYAN}Input Parameters:${NC}"
        
        # Extract required and optional properties
        local properties=$(echo "$schema" | jq -r '.properties // {}')
        local required=$(echo "$schema" | jq -r '.required // []')
        
        if [ "$properties" != "{}" ]; then
            echo "$properties" | jq -r 'to_entries[] | "  • \(.key): \(.value.description // .value.type)"' 2>/dev/null
        else
            echo "  (no parameters)"
        fi
        echo ""
    fi
}

# Export functions
export -f provider_repo_list
export -f provider_repo_info
export -f provider_mcp_capabilities
export -f provider_mcp_tools
export -f provider_mcp_resources
export -f provider_mcp_test
export -f provider_mcp_tool_info
