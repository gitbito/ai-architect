# Bito's AI Architect — Enterprise Setup Guide

Enterprise install for multi-user or shared-server deployments. Supports Docker Compose and Kubernetes — the installer prompts you to pick.

> **Evaluating on your laptop?** Use the faster [Standalone Setup Guide](standalone-setup-guide.md) instead (one-command install, under 5 minutes).

---

## 1. Prerequisites

### Common (all deployments)

- **Bito API key** — from https://alpha.bito.ai/home/advanced
- **Git provider credentials** — GitHub, GitLab, Bitbucket, or Azure DevOps personal access token
- **Package tarball** — `bito-cis-*.tar.gz` from your release channel

### Docker Compose

| | Minimum | Recommended |
|--|--------|-------------|
| Docker | Desktop 20.10+ with Compose v2 | Docker Desktop 4.x+ |
| Docker RAM | 6 GB | 8 GB+ |
| Docker CPUs | 3 | 4+ |
| Disk | 10 GB | 50 GB+ |
| Ports | 5001–5005 free on localhost | Same (or customize) |

### Kubernetes

- `kubectl` and `helm` 3.x installed locally
- Access to a Kubernetes cluster (cluster config reachable via `kubectl cluster-info`)
- Ingress: none required — the platform ships its own ingress controller (class `ai-architect-nginx`). To reuse the cluster's existing controller instead, set `BITOARCH_INGRESS_CLASS` (e.g. `nginx`, `traefik`)
- Cluster resources: minimum 4 CPUs and 8 GB RAM available for the namespace

---

## 2. Install

```bash
tar -xzf bito-cis-*.tar.gz
cd bito-cis-*
./scripts/bitoarch-install.sh
```

When required values are missing, the installer asks (under **QUICK CONFIGURATION**, after the deployment-method prompt) how you want to provide them:

- **[1] Standard** — opens `~/.bitoarch/install.yaml` in your `$EDITOR` to fill every value in one pass (save & quit to continue).
- **[2] Guided** — answers each value at a sequential prompt.

Anything left blank is still prompted for; the choice is skipped in non-interactive runs (`--auto` / no TTY) and when the values are already pre-seeded.

You'll be prompted for (Guided, or for anything left blank under Standard):

1. **Deployment method** — Docker Compose (1) or Kubernetes (2)
2. **Bito API Key**
3. **Git provider** — GitLab / GitHub / Bitbucket / Azure DevOps + personal access token

The installer will:
- Validate prerequisites (Docker or kubectl/helm, ports, resources)
- Generate secure passwords, JWT, MCP token
- Deploy services (Provider, Manager, Config, Tracker, MySQL)
- Install the `bitoarch` CLI globally
- Print your MCP URL and access token on success

### Customize ports (optional)

Edit `.env-bitoarch.default` **before** install to override default ports:

```bash
CIS_PROVIDER_EXTERNAL_PORT=5001   # MCP server
CIS_MANAGER_EXTERNAL_PORT=5002
CIS_CONFIG_EXTERNAL_PORT=5003
MYSQL_EXTERNAL_PORT=5004
CIS_TRACKER_EXTERNAL_PORT=5005
```

---

## 3. Connect MCP client

Get your MCP URL and token:

```bash
bitoarch mcp-info
```

### Claude Desktop

`~/Library/Application Support/Claude/claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "ai-architect": {
      "url": "http://<host>:5001/mcp",
      "headers": { "Authorization": "Bearer <TOKEN>" }
    }
  }
}
```

### Cursor / VS Code

Settings → MCP → Add Server. Paste URL + token.

---

## 4. Add repositories

Edit `.bitoarch-config.yaml`:

```yaml
repository:
  configured_repos:
    - namespace: your-org/backend-api
    - namespace: your-org/frontend-app
```

Apply and index:

```bash
bitoarch add-repos
bitoarch index-repos
bitoarch index-status
```

Status values: `in_progress` | `completed` | `failed`. See `bitoarch index-status --raw` for the full API payload.

---

## 5. Insights (optional)

Insights features analyze commit history, Jira tickets, and Confluence docs to surface engineering activity metrics. They run independently of code indexing and are optional.

**During install:** the installer prompts for each feature. Pre-seed via `~/.bitoarch/install.yaml` to skip prompts (uncomment the `insights:` section and fill in values).

**After install:**

```bash
bitoarch insights enable git              # commit-history insights (reuses git creds)
bitoarch insights enable ticket-tracker   # prompts for Jira base URL + email + API token
bitoarch insights enable docs             # prompts for Confluence URL + email + API token
bitoarch insights run                     # trigger analysis
bitoarch insights config                  # check what's enabled
```

**Manage Jira project scope:**

```bash
bitoarch insights discover-tracker-projects   # interactive selection from accessible projects
bitoarch insights tracker-projects list       # show current keys
bitoarch insights tracker-projects add PROJ   # add a project key
bitoarch insights tracker-projects remove PROJ
```

**Credential rotation:**

```bash
bitoarch insights update-ticket-tracker    # re-enter Jira creds (validates before saving)
bitoarch insights update-doc-config        # re-enter Confluence creds
```

> Atlassian API tokens: [id.atlassian.com/manage-profile/security/api-tokens](https://id.atlassian.com/manage-profile/security/api-tokens). Provide the Confluence base URL without `/wiki` — the platform normalizes it automatically.

Full command list: [CLI Reference — Insights](CLI_REFERENCE.md#insights).

---

## 6. Deployment-specific notes

### Docker Compose

Services expose ports 5001–5005 on `localhost`. Logs live in `var/logs/` and in `docker compose logs`.

```bash
bitoarch status          # service health
bitoarch logs            # tail all services
bitoarch logs cis-provider
```

### Kubernetes

Services run in the `bito-ai-architect` namespace with ClusterIP (internal-only). External access goes through the bundled ingress controller (or your own via `BITOARCH_INGRESS_CLASS`); port-forward works for testing.

**Via Ingress (recommended for enterprise):**

```bash
curl http://your-domain.com/api/provider/health
curl http://your-domain.com/api/manager/health
curl http://your-domain.com/api/config/health
curl http://your-domain.com/api/tracker/health
```

**Via port-forward (testing/dev):**

```bash
kubectl port-forward svc/ai-architect-provider 8080:8080 -n bito-ai-architect
curl http://localhost:8080/health
```

**In-cluster (pod-to-pod):**

```bash
kubectl run curl --image=curlimages/curl -it --rm --restart=Never -n bito-ai-architect -- \
  curl http://ai-architect-provider:8080/health
```

**Check pods:**

```bash
kubectl get pods -n bito-ai-architect
kubectl logs -n bito-ai-architect -l app.kubernetes.io/component=provider --tail=100 -f
```

### Deploy to an existing Kubernetes cluster (cluster.yaml)

AI Architect deploys onto any existing cluster — EKS, GKE, AKS, or self-hosted — described by an operator-owned profile at `$HOME/.bitoarch/cluster.yaml` (template: `cluster.yaml.default` in the install directory; override the path with `CLUSTER_YAML=<path>`). If the file is absent, the installer behaves exactly as before.

**1. Connect — the cluster is identified by a kubectl context.** Your cloud CLI creates it:

| Cluster | One-time command |
|---|---|
| EKS | `aws eks update-kubeconfig --region <r> --name <cluster>` |
| GKE | `gcloud container clusters get-credentials <cluster> --region <r>` |
| AKS | `az aks get-credentials --resource-group <rg> --name <cluster>` |
| Self-hosted | use the kubeconfig your platform team provides (`KUBECONFIG=<path>`) |

Put the resulting context name in `cluster.yaml → context:`. Every kubectl/helm call the installer makes is pinned to it; an invalid context fails before anything deploys. With `context` empty, the installer asks you to confirm the current context.

**2. Storage** — set `storage.shared_class` to a ReadWriteMany class (EFS / Filestore / Azure Files / NFS / CephFS) with `storage.access_mode: ReadWriteMany` for multi-node, and `storage.mysql_class` to a block class (gp3 / PD / Azure Disk / Longhorn). MySQL must never use an NFS-family class.

*No CSI driver? Static provisioning works too — automatically.* When the NFS share already exists (a provisioned Filestore/EFS instance), no StorageClass is needed: set `storage.nfs.server` and `storage.nfs.path` in `cluster.yaml` alongside `storage.shared_class` (which becomes the binding name). The installer then creates the share subdirectories and one PersistentVolume per shared volume (`data`, `backups`, `temp`, `logs`, `insights`) itself, and preflight verifies them. Alternatively, platform teams that prefer to manage volumes themselves can pre-create equivalent PVs manually and leave `storage.nfs` empty — preflight accepts either form. Either way the chart's claims bind by name; the server IP/path never enter the chart.

```yaml
apiVersion: v1
kind: PersistentVolume
metadata:
  name: bitoarch-shared-data            # repeat for backups/temp/logs/insights
spec:
  capacity:
    storage: 20Gi                       # >= the claim size (data 20Gi; backups 10Gi; temp/logs/insights 5Gi)
  accessModes: [ReadWriteMany]
  persistentVolumeReclaimPolicy: Retain
  storageClassName: bito-shared-nfs     # the string you set in cluster.yaml storage.shared_class
  nfs:
    server: <filestore-or-nfs-ip>       # e.g. 10.2.0.132
    path: /<share>/data                 # one subdirectory per volume keeps them separate
```

**3. Node pools** — if your platform team dedicates a node group/pool, set its label under `scheduling.node_selector` (EKS `eks.amazonaws.com/nodegroup: <name>`, GKE `cloud.google.com/gke-nodepool: <name>`, AKS `agentpool: <name>`), plus `scheduling.tolerations` when the pool is tainted. Every AI Architect pod lands there. Per-service overrides live under `services.<name>.node_selector/tolerations` (e.g. pin only workers to a bigger pool).

**4. Scaling** — `services.worker|config|manager|tracker.replicas` run multiple pods, spread across nodes. `spread: soft` (default) *prefers* an even spread but lets pods co-locate; `strict` *enforces* it (Kubernetes `maxSkew: 1` with `DoNotSchedule`) — one pod per node when nodes ≥ replicas, and with fewer nodes the surplus co-locates as evenly as possible rather than piling onto one node (3 replicas on 2 nodes → 2+1, nothing left `Pending`). `strict` also switches the service to a vacate-then-replace rollout so the distribution survives a restart, at the cost of a brief single-replica dip. `off` disables the preference. Replicas above 1 require `access_mode: ReadWriteMany` — preflight enforces this. The MCP provider, MySQL and Temporal always run one replica (placement is still configurable).

**5. Private registries** — create the secret once (`kubectl create secret docker-registry <name> -n bito-ai-architect ...`) and reference it as `image_pull_secret: <name>`; all pods inherit it via the ServiceAccount.

**Preflight.** Before deploying, the installer validates the target: context exists, RBAC verbs, storage classes present, MySQL-not-on-NFS, Pod Security posture (namespaces enforcing `restricted` are rejected — the chart needs `baseline`), pull-secret existence, node-pool labels matching real nodes, and a server-side helm dry-run against the live cluster. Failures print the exact remediation; nothing is installed on failure.

**Least-privilege RBAC.** The installer needs, in the `bito-ai-architect` namespace: create/get/list/watch on `deployments`, `statefulsets`, `jobs`, `services`, `persistentvolumeclaims`, `secrets`, `configmaps`, `serviceaccounts`, `pods` (+ `pods/log`, `pods/portforward`), plus either `create namespace` cluster-scoped or a pre-created namespace, and read on `storageclasses` and `nodes`. Grant via a namespace-scoped Role/RoleBinding plus a small ClusterRole for the reads.

---

## 7. Operations

```bash
bitoarch status                     # health
bitoarch logs [service]             # tail
bitoarch restart                    # restart services
bitoarch restart --force            # reload env + recreate
bitoarch update                     # pull latest images (per versions/service-versions.json)
bitoarch upgrade                    # upgrade platform (blue/green, data preserved)
bitoarch upgrade --version=1.8.0    # upgrade to a specific version
```

Full command list: [CLI Reference](CLI_REFERENCE.md).

### Plugin auto-update & air-gapped operation

Installed plugins check for updates once a day (~09:30 local, small jitter; override with
`BITOARCH_PLUGIN_UPDATE_TIME=HH:MM`). Updates are **staged only** — nothing is applied
automatically. The check downloads the new package, verifies its SHA-256 checksum and GPG
signature (publisher key bundled with the CLI), stages it on disk, and records it; the
operator applies it explicitly:

```bash
bitoarch info                        # shows the auto-update posture
bitoarch plugin upgrade <name>       # apply a staged update
```

Disable the check entirely with `BITOARCH_PLUGIN_AUTO_UPDATE=false` in the base env.

**Outbound connections** (all HTTPS, initiated from this host — nothing inbound):

| Purpose | Destination | When | Off switch |
|---|---|---|---|
| Plugin update check | `$BITOARCH_PLUGIN_DOWNLOAD_URL/ai-architect-plugins/<name>/<name>-latest.json` | Daily (scheduler) | `BITOARCH_PLUGIN_AUTO_UPDATE=false` |
| Plugin package download | same base URL, `<name>/<version>/<name>-<version>.tar.gz` | On update check / `plugin install <name>` by name | Install from a local path instead |
| Plugin catalog (install offer) | same base URL, `catalog.json` | End of base install (interactive) | Declines gracefully offline |

**Air-gapped sites** — two supported patterns, no code changes:

1. **Internal mirror**: mirror the `ai-architect-plugins` CDN tree to an internal HTTPS host
   and set `BITOARCH_PLUGIN_DOWNLOAD_URL=https://<mirror>` in the base env. Update checks,
   catalog, and installs then stay inside your network.
2. **Fully offline**: set `BITOARCH_PLUGIN_AUTO_UPDATE=false` and install/upgrade from local
   packages — `bitoarch plugin install /path/to/<name>-<version>.tar.gz` (or a directory).
   Point `BITOARCH_PLUGIN_PACKAGES_DIR=/path/to/packages` to resolve plugins by name locally.

Signature verification applies in every pattern; a package that fails checksum or GPG
verification is discarded and never staged.

---

## 8. Credentials & SSO

Secrets live in `.env-bitoarch` (path: `bitoarch config path env`):

- `BITO_API_KEY` — Bito authentication
- `GIT_ACCESS_TOKEN` — Git provider PAT
- `BITO_MCP_ACCESS_TOKEN` — MCP server token (auto-generated)
- Database passwords and JWT secret (auto-generated)

**Keep `.env-bitoarch` secure — back it up.**

### Rotate credentials

```bash
bitoarch update-api-key
bitoarch update-git-creds
bitoarch rotate-mcp-token
```

### SSO (optional)

By default, MCP uses a static bearer token. Enable SSO for user-level auth:

```bash
bitoarch sso setup       # choose Enterprise IdP (SAML/OIDC) or Bito
bitoarch sso status
bitoarch sso disable     # temporary or permanent
bitoarch sso enable      # re-enable after temporary disable
bitoarch sso rotate-key
```

When SSO is enabled, `bitoarch mcp-info` reflects the active auth mode.

---

## 9. Troubleshooting

```bash
# Live diagnostic sweep — pass/warn/fail per section
bitoarch diagnose
bitoarch diagnose --verbose

# Services not starting — check logs
bitoarch logs
tail -f setup.log

# Port conflicts (Docker Compose) — edit BEFORE install
vim .env-bitoarch.default   # change CIS_*_EXTERNAL_PORT values

# Indexing stuck
bitoarch index-status --raw
bitoarch logs cis-manager
bitoarch stop-indexing && bitoarch index-repos

# Kubernetes pod issues
kubectl describe pod <pod> -n bito-ai-architect
kubectl logs <pod> -n bito-ai-architect --previous    # after CrashLoopBackOff

# MCP connectivity check
bitoarch mcp-test
```

**Escalating to Bito support:** run `bitoarch diagnose --bundle` to produce a redacted `.tar.gz` containing system info, logs, config, DB health, indexing/temporal state, and local tracking events (tokens/secrets masked; event fields like email/IP retained for triage). Share the archive with support@bito.ai when opening a ticket.

---

## 10. Uninstall

```bash
bitoarch uninstall --purge   # wipe containers/volumes/config; keep install dir
bitoarch uninstall    # full removal
```

Docker images are kept — run `docker image prune` to reclaim disk.

For Kubernetes, `bitoarch uninstall` removes the Helm release and namespace.

---

## 11. Additional Resources

- [CLI Reference](CLI_REFERENCE.md) — complete command documentation
- [Setup Guide](https://docs.bito.ai/ai-architect/install-ai-architect-self-hosted) — official self-hosted install docs
- [How to Use AI Architect](https://docs.bito.ai/ai-architect/install-ai-architect-self-hosted#how-to-use-ai-architect) — integrations with Claude, Cursor, etc.
