# Bito's AI Architect CLI — Command Reference

Complete reference for the `bitoarch` command-line interface.

`bitoarch` is installed globally by the install bootstrap and works against Docker Compose, Standalone, and Kubernetes deployments. All commands support `--help` for per-command usage.

---

## Getting Help

| Command | Shows |
|---------|-------|
| `bitoarch --help` \| `-h` | Top-level help with all commands |
| `bitoarch <command> --help` | Command-specific usage and flags |
| `bitoarch --version` \| `-v` | CLI version |

---

## Status

Pre-install-safe — these commands degrade gracefully if services aren't running yet.

| Command | Description |
|---------|-------------|
| `bitoarch status` | Show all services status |
| `bitoarch health` | Check health of all services |
| `bitoarch info` | Show platform information (version, ports, endpoints) |
| `bitoarch diagnose` | Live pass/warn/fail sweep across prereqs, install, filesystem, config, services, connectivity, and certs |
| `bitoarch diagnose --bundle` | Collect a sharable `diagnostics-<timestamp>.tar.gz` for Bito support. Secrets auto-redacted. Optional: `--output <path>`, `--keep-workdir` |

**Examples:**

```bash
bitoarch diagnose                              # live sweep
bitoarch diagnose --verbose
bitoarch diagnose --section services           # one section only
bitoarch diagnose --bundle                     # produce .tar.gz for support
bitoarch diagnose --bundle --output /tmp/debug
```

The bundle includes system info, service status + resource usage, last 1000 lines of container + app logs, redacted `.env`, DB health, connectivity probes, indexing status, temporal status, and local tracking events (on-prem analytics events captured under `tracking/`; embedded tokens/secrets are masked, while event fields such as email and ip_address are retained for support triage). Share the resulting archive with support@bito.ai.

---

## Lifecycle

| Command | Description |
|---------|-------------|
| `bitoarch start` | Start stopped services (idempotent) |
| `bitoarch stop` | Stop all services (keeps data) |
| `bitoarch restart [--force]` | Restart services. `--force` reloads env and recreates containers |
| `bitoarch logs [service]` | Tail service logs (`-f`). All services if `service` omitted |
| `bitoarch update` | Refresh service images per `versions/service-versions.json` (installed plugins update too) |
| `bitoarch upgrade [--version=<ver>]` | Upgrade platform (latest by default). Blue/green tarball swap; data preserved |
| `bitoarch uninstall` | Remove the services. Data and config are kept; `bitoarch start` restores |
| `bitoarch uninstall --purge` | Remove services, volumes, config, and logs. Keeps install directory and config backups |

**Examples:**

```bash
bitoarch restart --force            # reload env + recreate containers
bitoarch logs cis-provider          # tail one service
bitoarch upgrade                    # upgrade to latest
bitoarch upgrade --version=1.8.0    # upgrade to a specific version
```

> Rollback is not supported after a successful upgrade. The tarball keeps the previous install at `<parent>/bito-ai-architect-<old>` until you remove it.

---

## Repositories

| Command | Description |
|---------|-------------|
| `bitoarch add-repo <namespace>` | Add one repository (e.g. `myorg/my-repo`) |
| `bitoarch remove-repo <namespace>` | Remove one repository |
| `bitoarch add-repos [file]` | Load repos from YAML. Uses `.bitoarch-config.yaml` if `file` omitted |
| `bitoarch update-repos [file]` | Update repos from YAML. Uses `.bitoarch-config.yaml` if `file` omitted |
| `bitoarch repo-info <name> [--dependencies]` | Show repository details (add `--dependencies` to include incoming/outgoing deps) |
| `bitoarch fetch-repo-list [--force-load]` | Sync repo list from your git provider. `--force-load` ignores local cache |

**Examples:**

```bash
bitoarch add-repo myorg/backend-api
bitoarch add-repo mygroup/mysubgroup/backend-api   # GitLab nested subgroup
bitoarch add-repos                           # loads default config
bitoarch add-repos ./custom-repos.yaml
bitoarch repo-info backend-api --dependencies
```

---

## Indexing

| Command | Description |
|---------|-------------|
| `bitoarch show-config` | Show current indexing configuration |
| `bitoarch index-repos [--only-new-repos]` | Trigger workspace repository indexing. `--only-new-repos` skips incremental updates for existing repos |
| `bitoarch index-status [--raw] [--output json]` | Check indexing status. `--raw` dumps the full API response; `--output json` emits machine-readable JSON |
| `bitoarch index-repo-list` | List indexed repositories |
| `bitoarch pause-indexing` | Pause an in-progress indexing run |
| `bitoarch resume-indexing` | Resume a paused indexing run |
| `bitoarch stop-indexing` | Stop indexing completely |
| `bitoarch create-index-scheduler` | Create scheduled indexing tasks |
| `bitoarch update-index-scheduler` | Update existing scheduled indexing tasks |

**Examples:**

```bash
bitoarch index-repos
bitoarch index-repos --only-new-repos
bitoarch index-status --raw                  # debugging
bitoarch index-status --output json          # scriptable
bitoarch index-repo-list
```

> One indexing job runs per workspace at a time. If you add a repo mid-run, re-trigger `index-repos` after the current job finishes.

---

## Configuration

| Command | Description |
|---------|-------------|
| `bitoarch update-api-key` | Update Bito API key (interactive or `--api-key <key> [--restart]`) |
| `bitoarch update-git-creds` | Update Git provider credentials (interactive or `--provider <p> --token <t> [--restart]`) |
| `bitoarch update-llm-config` | Update custom LLM provider configuration (interactive) |
| `bitoarch rotate-mcp-token [<new-token>]` | Rotate MCP access token. Omit arg to auto-generate |
| `bitoarch config path [env\|repos\|llm]` | Print the absolute path of a config file (default: `env`) |
| `bitoarch config edit [env\|repos\|llm]` | Open a config file in `$EDITOR` (default: `env`) |

**Config file types:**

| Type | File | Purpose |
|------|------|---------|
| `env` | `.env-bitoarch` | Main environment config (ports, credentials, secrets) |
| `repos` | `.bitoarch-config.yaml` | Repository list |
| `llm` | `.env-llm-bitoarch` | Custom LLM provider configuration |

**Examples:**

```bash
bitoarch config path repos          # prints path to .bitoarch-config.yaml
bitoarch config edit env            # edit .env-bitoarch
bitoarch update-api-key --api-key bito_xxx --restart
bitoarch update-git-creds --provider github --token ghp_xxx --restart
bitoarch rotate-mcp-token           # auto-generates a new token
```

---

## Insights

Optional features that analyze commit history, Jira tickets, and Confluence docs to surface engineering activity insights. Each feature runs independently; all three work better together.

| Command | Description |
|---------|-------------|
| `bitoarch insights config` | Show enabled insights features, providers, and credentials |
| `bitoarch insights status` | Show detailed insights workflow status (phase, per-feature progress) |
| `bitoarch insights run [--force]` | Run insights analysis on-demand (independent of indexing). `--force` re-runs even if data hasn't changed |
| `bitoarch insights enable <feature>` | Enable an insights feature (interactive). Features: `git`, `ticket-tracker`, `docs` |
| `bitoarch insights disable <feature>` | Disable an insights feature |
| `bitoarch insights tracker-projects list` | List currently configured project keys |
| `bitoarch insights tracker-projects add <KEY> [KEY …]` | Add project keys to analyze |
| `bitoarch insights tracker-projects remove <KEY> [KEY …]` | Remove project keys |
| `bitoarch insights tracker-projects set <KEY> [KEY …]` | Replace all configured keys |
| `bitoarch insights discover-tracker-projects` | List accessible ticket-tracker projects with markers for currently selected ones |
| `bitoarch insights update-ticket-tracker` | Update ticket-tracker credentials (interactive) |
| `bitoarch insights update-doc-config` | Update doc integration credentials (interactive) |

**Prerequisites:**

| Feature | Requires |
|---------|----------|
| Git Insights | Git provider credentials (already configured during install) |
| Ticket Tracker | Jira base URL + email + [Atlassian API token](https://id.atlassian.com/manage-profile/security/api-tokens) |
| Docs | Confluence URL + email + Atlassian API token |

**Examples:**

```bash
bitoarch insights enable git
bitoarch insights enable ticket-tracker       # prompts for Jira creds
bitoarch insights enable docs                 # prompts for Confluence creds
bitoarch insights config                      # verify what's enabled
bitoarch insights run                         # trigger analysis
bitoarch insights run --force                 # re-run even if no new data

bitoarch insights discover-tracker-projects   # interactive project selection
bitoarch insights tracker-projects add PROJ INFRA

bitoarch insights update-ticket-tracker       # rotate Jira token
bitoarch insights update-doc-config           # rotate Confluence token
```

**Lookback window:**

Insights analyzes the most recent N days of history (default 180). Git and Jira can have separate windows via `INSIGHTS_GIT_LOOKBACK_DAYS` and `INSIGHTS_JIRA_LOOKBACK_DAYS` in `.env-bitoarch`. Use `bitoarch insights set-lookback [git|ticket-tracker] [DAYS]` to change.

**Troubleshooting:**

```bash
# "Existing Jira credentials failed validation"
# → Atlassian API token may have expired. Regenerate at
#   https://id.atlassian.com/manage-profile/security/api-tokens
bitoarch insights update-ticket-tracker

# Confluence URL issues (double /wiki path)
# → Provide the base URL without /wiki (e.g. https://acme.atlassian.net)
bitoarch insights update-doc-config

# "Create base config first"
# → Run bitoarch add-repos before enabling insights
bitoarch add-repos
bitoarch insights enable ticket-tracker
```

---

## SSO

SSO is optional and disabled by default (bearer-token auth). When enabled, `bitoarch mcp-info` reflects the active auth mode.

| Command | Description |
|---------|-------------|
| `bitoarch sso setup` | Configure SSO (interactive: Enterprise IdP or Bito) |
| `bitoarch sso status` | Check SSO configuration and IdP verification |
| `bitoarch sso enable` | Re-enable previously disabled SSO |
| `bitoarch sso disable` | Disable SSO (interactive: temporary or permanent) |
| `bitoarch sso rotate-key` | Rotate SSO tenant management key |

**Auth modes:**

| Mode | Description |
|------|-------------|
| Bearer Token | Default — static MCP access token (SSO disabled) |
| Bito | SSO via Bito — no external IdP required |
| Enterprise IdP | SSO via your SAML/OIDC provider (Okta, Azure AD, etc.) |

**Examples:**

```bash
bitoarch sso setup
bitoarch sso status
bitoarch sso disable                # choose temporary or permanent
bitoarch sso enable                 # after temporary disable
bitoarch sso rotate-key
```

---

## MCP

| Command | Description |
|---------|-------------|
| `bitoarch mcp-info` | Show MCP URL, access token, and active auth mode |
| `bitoarch mcp-test` | End-to-end MCP connectivity check |
| `bitoarch mcp-tools [--details] [--summary] [--output <file>]` | List available MCP tools |
| `bitoarch mcp-tool-info <name>` | Show details for one MCP tool |
| `bitoarch mcp-capabilities [--output <file>]` | Show MCP server capabilities |

**Examples:**

```bash
bitoarch mcp-info
bitoarch mcp-test
bitoarch mcp-tools --details
bitoarch mcp-tool-info search_code
bitoarch mcp-capabilities --output caps.json
```

> Standalone installs additionally expose `bitoarch mcp-install` (auto-register the local MCP with installed coding agents) and `bitoarch mcp-cert` (HTTPS cert lifecycle). See the [Standalone Setup Guide](standalone-setup-guide.md).

---

## Common Workflows

### First-time setup

Install runs via the bootstrap (`curl … | bash` / `./scripts/bitoarch-install.sh`), not a `bitoarch` subcommand. When required values (Bito API key, git provider/token) are missing, the bootstrap asks how to provide them: **[1] Standard** opens `~/.bitoarch/install.yaml` in your `$EDITOR` to fill everything in one pass, or **[2] Guided** prompts for each value in turn. The choice is skipped under `--auto` / no TTY and when the values are already pre-seeded. See the [standalone](standalone-setup-guide.md) / [enterprise](enterprise-setup-guide.md) setup guides for details. After install:

```bash
bitoarch status                     # verify services are up
bitoarch add-repos                  # load repos from .bitoarch-config.yaml
bitoarch index-repos                # start indexing
bitoarch index-status               # monitor progress
bitoarch mcp-info                   # grab MCP URL + token for your client
```

### Adding new repositories

```bash
bitoarch add-repo myorg/new-repo
bitoarch index-repos                # index only the new repo will still trigger a run
# or:
bitoarch index-repos --only-new-repos
```

### Indexing control

```bash
bitoarch index-repos
bitoarch pause-indexing
bitoarch resume-indexing
bitoarch stop-indexing
```

### Daily operations

```bash
bitoarch status
bitoarch health
bitoarch index-status
bitoarch index-repo-list
```

### Troubleshooting

```bash
bitoarch status
bitoarch health
bitoarch logs                       # all services
bitoarch logs cis-manager           # one service
bitoarch index-status --raw
bitoarch mcp-test
bitoarch show-config
```

### Insights

```bash
bitoarch insights enable git
bitoarch insights enable ticket-tracker
bitoarch insights run
bitoarch insights config
```

### Credential rotation

```bash
bitoarch update-api-key
bitoarch update-git-creds
bitoarch insights update-ticket-tracker      # Jira token
bitoarch insights update-doc-config          # Confluence token
bitoarch rotate-mcp-token
bitoarch sso rotate-key             # only if SSO is enabled
```

### Tear-down

```bash
bitoarch stop                       # pause services
bitoarch uninstall --purge          # remove services + volumes + config (keeps install dir + backups)
bitoarch uninstall                  # remove services; data + config kept (start restores)
```

---

## Environment Variables

Config lives in `.env-bitoarch` (path: `bitoarch config path env`). Key variables:

| Variable | Purpose |
|----------|---------|
| `BITO_API_KEY` | Bito authentication key |
| `GIT_PROVIDER` | Git provider (`github`, `gitlab`, `bitbucket`, `azure-devops`) |
| `GIT_ACCESS_TOKEN` | Git personal access token |
| `BITO_MCP_ACCESS_TOKEN` | MCP server access token |
| `CIS_PROVIDER_EXTERNAL_PORT` | MCP server port (default: 5001 standalone / 8080 k8s) |
| `CIS_MANAGER_EXTERNAL_PORT` | Manager API port |
| `CIS_CONFIG_EXTERNAL_PORT` | Config API port |
| `CIS_TRACKER_EXTERNAL_PORT` | Tracker API port |
| `MYSQL_EXTERNAL_PORT` | MySQL external port |
| `INSIGHTS_GIT_ENABLED` | Enable git commit insights (`true`/`false`) |
| `INSIGHTS_TICKET_TRACKER_ENABLED` | Enable Jira ticket insights (`true`/`false`) |
| `INSIGHTS_DOCS_ENABLED` | Enable Confluence docs insights (`true`/`false`) |
| `INSIGHTS_GIT_LOOKBACK_DAYS` | Git insights lookback period (default: 180 days) |
| `INSIGHTS_JIRA_LOOKBACK_DAYS` | Jira insights lookback period (default: 180 days) |
| `CIS_REPO_LIMIT` | Max repositories configurable for indexing (default: 50; server hard-max: 500). Editable in `.env-bitoarch` + re-run `bitoarch config apply` — no reinstall |
| `CIS_REPO_SIZE_LIMIT` | Max indexable size per repository, in bytes (default: 1073741824 = 1GB) |
| `SCHEDULER_BASIC_INDEX_INTERVAL` | XMCP incremental (basic) index interval (default: 1h; configurable, e.g. `1h`, `24h`) |
| `STORAGE_ACCESS_MODE` | Access mode for shared app-data PVCs (Kubernetes; default `ReadWriteOnce`). Set `ReadWriteMany` for multi-node shared storage |
| `SHARED_STORAGE_CLASS` | StorageClass for shared app-data PVCs (Kubernetes; empty = global/auto-detected). Any RWX provider — EFS / GCP Filestore / Azure Files / NFS / Rook-Ceph |
| `MYSQL_STORAGE_CLASS` | StorageClass for the MySQL PVC (Kubernetes; empty = global). Keep on block storage — never NFS/RWX |
| _(no env var)_ | The kubectl context is **not** settable by environment variable. Set `context:` in `cluster.yaml`; empty there means the current context is used (the installer asks you to confirm it) |
| `K8S_IMAGE_PULL_SECRET` | Existing docker-registry secret in the namespace for private registries (Kubernetes; empty = public pulls). Usually set via `cluster.yaml` |

See `.env-bitoarch.default` in the install directory for the full list with defaults.

### Storage classes (Kubernetes, multi-node / shared storage)

By default all persistent volumes use the cluster's auto-detected StorageClass with `ReadWriteOnce` — unchanged for existing single-node and Docker Compose installs. To run across multiple nodes, put shared application data on a `ReadWriteMany` (RWX) class while keeping MySQL on block storage:

| Scenario | Settings |
|----------|----------|
| Default (single node / Docker) | none — local class + `ReadWriteOnce` |
| Multi-node, shared RWX storage | `SHARED_STORAGE_CLASS=<rwx-class>`, `STORAGE_ACCESS_MODE=ReadWriteMany`, `MYSQL_STORAGE_CLASS=<block-class>`. The chart never creates a StorageClass by default, so the cluster's existing classes are used with no extra action |

`<rwx-class>` is any ReadWriteMany-capable StorageClass (AWS EFS `efs.csi.aws.com`, GCP Filestore, Azure Files, NFS subdir provisioner, Rook-Ceph). MySQL must stay on a block / `ReadWriteOnce` class — databases are not safe on NFS/EFS.

> **Migrating an existing install:** a PVC's access mode and StorageClass are immutable after creation. An existing single-node install cannot switch to RWX in place — provision new PVCs on the RWX class and copy the data over before switching.

---

## Related Docs

- [Standalone Setup Guide](standalone-setup-guide.md) — single-machine developer install (shipped with standalone tarball)
- [Enterprise Setup Guide](enterprise-setup-guide.md) — multi-user / shared-server install, Docker Compose or Kubernetes (shipped with enterprise tarball)
