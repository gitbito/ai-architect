#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
# Bito's AI Architect Backup Script - Zero Data Loss Guarantee
# Creates comprehensive backups of database, configurations, and service data

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[1;34m'
NC='\033[0m' # No Color

# docker compose vs docker-compose: resolve once (Colima/older hosts ship only the standalone binary).
if docker compose version >/dev/null 2>&1; then COMPOSE="docker compose"; else COMPOSE="docker-compose"; fi

# Configuration
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PLATFORM_DIR="$(dirname "$SCRIPT_DIR")"

# This script also runs standalone (./scripts/backup.sh, cron), where nothing has
# set LOG_FILE -- without this every `2>>"${LOG_FILE:-/dev/null}"` below discards
# the reason and the warnings would name an empty path.
if [ -z "${LOG_FILE:-}" ] && [ -f "${SCRIPT_DIR}/lib/path-manager.sh" ]; then
    # shellcheck source=/dev/null
    . "${SCRIPT_DIR}/lib/path-manager.sh" >/dev/null 2>&1 || true
    command -v bitoarch_resolve_log_file >/dev/null 2>&1 && LOG_FILE="$(bitoarch_resolve_log_file)"
fi
LOG_FILE="${LOG_FILE:-/dev/null}"
ENV_FILE="${PLATFORM_DIR}/.env-bitoarch"
DATE=$(date +%Y%m%d_%H%M%S)

# Source environment for BACKUP_PATH
if [ -f "$ENV_FILE" ]; then
    source "$ENV_FILE"
fi

# Use BACKUP_PATH from config, fallback to container default
BACKUP_DIR="${BACKUP_PATH:-/opt/cis/backups}"

# The env file's DB contract is MYSQL_USER/MYSQL_DATABASE; accept the legacy
# DB_USER/DB_NAME names but fall back to the real keys so dumps authenticate.
DB_USER="${DB_USER:-${MYSQL_USER:-}}"
DB_NAME="${DB_NAME:-${MYSQL_DATABASE:-}}"

# Logging function
log() {
    echo "[$(date +'%Y-%m-%d %H:%M:%S')] $1" | tee -a "$BACKUP_DIR/backup.log"
}

print_status() {
    echo -e "${GREEN}✓${NC} $1"
    log "SUCCESS: $1"
}

print_error() {
    echo -e "${RED}✗${NC} $1"
    log "ERROR: $1"
}

print_info() {
    echo -e "${BLUE}ℹ${NC} $1"
    log "INFO: $1"
}

print_warning() {
    echo -e "${YELLOW}⚠${NC} $1"
    log "WARNING: $1"
}

# Create backup directory structure
create_backup_structure() {
    local backup_name="backup_${DATE}"
    local backup_path="${BACKUP_DIR}/${backup_name}"
    
    mkdir -p "${backup_path}"/{database,configs,volumes,services,metadata}
    echo "$backup_path"
}

# Backup database with transaction consistency
backup_database() {
    local backup_path="$1"
    local db_backup_path="${backup_path}/database"
    
    print_info "Creating database backup..."
    
    if [ ! -f "$ENV_FILE" ]; then
        print_error "Environment file not found: $ENV_FILE"
        exit 1
    fi
    
    # Source environment variables
    source "$ENV_FILE"
    
    # Check if MySQL container is running
    if ! $COMPOSE --env-file "${PLATFORM_DIR}/.env-bitoarch" -f "${PLATFORM_DIR}/docker-compose.yml" ps ai-architect-mysql | grep -q "Up"; then
        print_error "MySQL container is not running"
        exit 1
    fi
    
    # Create full database backup with consistent snapshot
    print_info "Creating full database dump..."
    $COMPOSE --env-file "${PLATFORM_DIR}/.env-bitoarch" -f "${PLATFORM_DIR}/docker-compose.yml" exec -T ai-architect-mysql mysqldump \
        --single-transaction \
        --no-tablespaces \
        --routines \
        --triggers \
        --events \
        --hex-blob \
        --user="$DB_USER" \
        --password="$MYSQL_PASSWORD" \
        "$DB_NAME" > "${db_backup_path}/full_backup.sql"
    
    # Create structure-only backup
    $COMPOSE --env-file "${PLATFORM_DIR}/.env-bitoarch" -f "${PLATFORM_DIR}/docker-compose.yml" exec -T ai-architect-mysql mysqldump \
        --no-data \
        --no-tablespaces \
        --routines \
        --triggers \
        --events \
        --user="$DB_USER" \
        --password="$MYSQL_PASSWORD" \
        "$DB_NAME" > "${db_backup_path}/schema_only.sql"
    
    # Export system configuration (optional legacy table; skip cleanly when absent)
    $COMPOSE --env-file "${PLATFORM_DIR}/.env-bitoarch" -f "${PLATFORM_DIR}/docker-compose.yml" exec -T ai-architect-mysql mysql \
        --user="$DB_USER" \
        --password="$MYSQL_PASSWORD" \
        --database="$DB_NAME" \
        --execute="SELECT * FROM system_config;" \
        --batch --raw > "${db_backup_path}/system_config.tsv" 2>/dev/null || true
    [ -s "${db_backup_path}/system_config.tsv" ] || rm -f "${db_backup_path}/system_config.tsv"
    
    # Plugin databases follow the same dump logic as the base database: enumerate
    # every non-system database beyond DB_NAME (plugins provision their own DBs,
    # e.g. task_analyzer_service) and dump each as plugin-db_<name>.sql. Uses root
    # because plugin DB users are scoped to their own database. Generic by
    # convention — no plugin names here; restore picks these up by filename.
    local _extra_dbs _extra_db _root_pw _pdump
    _root_pw="$(grep -m1 '^MYSQL_ROOT_PASSWORD=' "$ENV_FILE" | cut -d= -f2-)"
    if [ -n "$_root_pw" ]; then
        _extra_dbs="$($COMPOSE --env-file "${PLATFORM_DIR}/.env-bitoarch" -f "${PLATFORM_DIR}/docker-compose.yml" exec -T ai-architect-mysql mysql \
            --user=root --password="$_root_pw" --batch --skip-column-names \
            --execute="SHOW DATABASES;" 2>/dev/null \
            | grep -vxE "information_schema|performance_schema|mysql|sys|${DB_NAME}|temporal.*" || true)"
        for _extra_db in $_extra_dbs; do
            print_info "Backing up plugin database: ${_extra_db}"
            _pdump="${db_backup_path}/plugin-db_${_extra_db}.sql"
            # Best-effort per plugin, but a failure must be visible and must not leave a partial
            # dump behind (restore would import truncated data); stderr goes to the backup log.
            if ! $COMPOSE --env-file "${PLATFORM_DIR}/.env-bitoarch" -f "${PLATFORM_DIR}/docker-compose.yml" exec -T ai-architect-mysql mysqldump \
                --single-transaction --routines --triggers --events --hex-blob \
                --user=root --password="$_root_pw" \
                "$_extra_db" > "$_pdump" 2>>"$BACKUP_DIR/backup.log"; then
                print_warning "Plugin database backup failed for '${_extra_db}'; removed partial dump (see backup.log)"
                rm -f "$_pdump"
            fi
        done
    fi

    # Create binary log backup for point-in-time recovery. The metadata must
    # not claim binlogs that were never captured — restore is the worst place
    # to discover they're missing.
    print_info "Backing up binary logs..."
    local binlog_entry="binlogs.tar.gz" binlog_rc
    $COMPOSE --env-file "${PLATFORM_DIR}/.env-bitoarch" -f "${PLATFORM_DIR}/docker-compose.yml" exec ai-architect-mysql \
        sh -c "cd /var/log/mysql && tar -czf - mysql-bin.*" > "${db_backup_path}/binlogs.tar.gz" 2>>"${LOG_FILE:-/dev/null}"
    binlog_rc=$?
    # tar exit 1 is "some files differ", NOT a failure: MySQL appends to the active
    # binlog while tar reads it, so a live instance hits this routinely and the
    # archive still contains every file. Only exit >=2 means no usable archive.
    # Treating any non-zero rc as failure deleted a valid point-in-time-recovery
    # archive and told the operator PITR was unavailable.
    if [ "$binlog_rc" -ge 2 ]; then
        print_warning "Binary log backup failed — point-in-time recovery will not be available (reason in ${LOG_FILE})"
        rm -f "${db_backup_path}/binlogs.tar.gz"
        binlog_entry="unavailable"
    elif [ "$binlog_rc" -ne 0 ]; then
        log_silent "Binary log backup: tar reported files changed while reading (rc=${binlog_rc}); the archive is complete and has been kept"
    fi

    # Create metadata file
    cat > "${db_backup_path}/backup_metadata.json" << EOF
{
    "timestamp": "${DATE}",
    "database_name": "${DB_NAME}",
    "backup_type": "full",
    "mysql_version": "$($COMPOSE --env-file "${PLATFORM_DIR}/.env-bitoarch" -f "${PLATFORM_DIR}/docker-compose.yml" exec -T ai-architect-mysql mysql --version | head -1)",
    "platform_version": "${VERSION_CURRENT:-1.0.0}",
    "backup_files": {
        "full_backup": "full_backup.sql",
        "schema_only": "schema_only.sql",
        "system_config": "system_config.tsv",
        "binary_logs": "${binlog_entry}"
    }
}
EOF
    
    print_status "Database backup completed"
}

# Backup configuration files
backup_configurations() {
    local backup_path="$1"
    local config_backup_path="${backup_path}/configs"
    
    print_info "Backing up configurations..."
    
    # Copy environment file
    cp "$ENV_FILE" "${config_backup_path}/.env-bitoarch.backup"
    
    # Copy docker-compose and related files
    local config_ok=true
    cp "${PLATFORM_DIR}/docker-compose.yml" "${config_backup_path}/"
    if [ -f "${PLATFORM_DIR}/.env-bitoarch.default" ]; then
        cp "${PLATFORM_DIR}/.env-bitoarch.default" "${config_backup_path}/" \
            || { config_ok=false; print_warning "Failed to back up .env-bitoarch.default"; }
    fi
    
    # Copy service configurations
    if [ -d "${PLATFORM_DIR}/config" ]; then
        cp -r "${PLATFORM_DIR}/config" "${config_backup_path}/" \
            || { config_ok=false; print_warning "Failed to back up ${PLATFORM_DIR}/config"; }
    fi
    
    # Copy service-specific configs
    for service in ai-architect-manager ai-architect-config ai-architect-provider; do
        service_config_dir="${PLATFORM_DIR}/services/${service}/config"
        if [ -d "$service_config_dir" ]; then
            mkdir -p "${config_backup_path}/services/${service}"
            cp -r "$service_config_dir" "${config_backup_path}/services/${service}/" \
                || { config_ok=false; print_warning "Failed to back up ${service} config"; }
        fi
    done
    
    # Plugin configs + service logs (no-op when no plugin is installed).
    local _plugins_root="${BITOARCH_CONFIG_DIR:-$PLATFORM_DIR}/plugins" _pl
    if [ -d "$_plugins_root" ]; then
        mkdir -p "${config_backup_path}/plugins"
        cp -r "$_plugins_root/." "${config_backup_path}/plugins/" 2>/dev/null || true
        for _pl in "$_plugins_root"/*/; do
            [ -d "$_pl" ] || continue
            _pl="$(basename "$_pl")"
            $COMPOSE -p "ai-architect-${_pl}" logs --no-color \
                > "${config_backup_path}/plugins/${_pl}.service.log" 2>/dev/null || true
        done
    fi

    # Plugin state journal (state.json + siblings) follows the same config-backup
    # path as everything above — without it a restore resurrects plugin configs
    # the engine does not know about.
    local _plugins_state="${BITOARCH_VAR_DIR:-/usr/local/var/bitoarch}/plugins"
    if [ -d "$_plugins_state" ]; then
        mkdir -p "${config_backup_path}/plugins-state"
        cp -r "$_plugins_state/." "${config_backup_path}/plugins-state/" 2>/dev/null || true
    fi

    if [ "$config_ok" = "true" ]; then
        print_status "Configuration backup completed"
    else
        print_warning "Configuration backup completed with errors — see warnings above"
    fi
}

# Backup Docker volumes
backup_volumes() {
    local backup_path="$1"
    local volume_backup_path="${backup_path}/volumes"
    local vol_ok=true
    
    print_info "Backing up Docker volumes..."
    
    # Volumes = everything the LIVE platform actually mounts: every volume attached
    # to a running ai-architect-* container (base services, plugins, dependency
    # packs — the naming convention covers them all). This resolves compose's
    # project-prefixed names to the real volumes and never sweeps in stale volumes
    # from older installs. Falls back to the compose-declared set when the stack
    # is stopped. Restore already handles any *.tar.gz it finds.
    local volumes
    volumes=$(docker ps -q --filter "name=ai-architect-" 2>/dev/null \
        | xargs docker inspect --format '{{range .Mounts}}{{if eq .Type "volume"}}{{.Name}}{{"\n"}}{{end}}{{end}}' 2>/dev/null \
        | grep -v '^$' | grep -vE '^[0-9a-f]{64}$' | sort -u)
    if [ -z "$volumes" ]; then
        volumes=$($COMPOSE --env-file "${PLATFORM_DIR}/.env-bitoarch" -f "${PLATFORM_DIR}/docker-compose.yml" config --volumes)
    fi

    for volume in $volumes; do
        print_info "Backing up volume: $volume"
        
        # Create volume backup using temporary container
        docker run --rm \
            -v "${volume}:/source" \
            -v "${volume_backup_path}:/backup" \
            alpine:latest \
            tar -czf "/backup/${volume}.tar.gz" -C /source . 2>>"${LOG_FILE:-/dev/null}" || {
            vol_ok=false
            print_warning "Failed to backup volume: $volume (reason in ${LOG_FILE})"
        }
    done
    
    # "completed" must not be claimed when a volume failed -- restore is the worst
    # place to discover a tarball is missing.
    if [ "$vol_ok" = true ]; then
        print_status "Volume backup completed"
    else
        print_warning "Volume backup completed with errors — see the warnings above"
    fi
}

# Backup service data and metadata
backup_service_data() {
    local backup_path="$1"
    local service_backup_path="${backup_path}/services"
    
    print_info "Backing up service data..."
    
    # Backup ai-architect-provider metadata
    if $COMPOSE --env-file "${PLATFORM_DIR}/.env-bitoarch" -f "${PLATFORM_DIR}/docker-compose.yml" ps ai-architect-provider | grep -q "Up"; then
        $COMPOSE --env-file "${PLATFORM_DIR}/.env-bitoarch" -f "${PLATFORM_DIR}/docker-compose.yml" exec ai-architect-provider \
            tar -czf - -C /app metadata 2>>"${LOG_FILE:-/dev/null}" > "${service_backup_path}/ai-architect-provider-metadata.tar.gz" \
            || print_warning "Provider metadata backup failed (reason in ${LOG_FILE})"
    fi
    
    # Backup application logs (last 7 days)
    for service in ai-architect-manager ai-architect-config ai-architect-provider; do
        if $COMPOSE --env-file "${PLATFORM_DIR}/.env-bitoarch" -f "${PLATFORM_DIR}/docker-compose.yml" ps "$service" | grep -q "Up"; then
            $COMPOSE --env-file "${PLATFORM_DIR}/.env-bitoarch" -f "${PLATFORM_DIR}/docker-compose.yml" logs --since="168h" "$service" \
                > "${service_backup_path}/${service}-recent.log" 2>/dev/null || true
        fi
    done
    
    print_status "Service data backup completed"
}

# Create backup manifest
create_backup_manifest() {
    local backup_path="$1"
    local manifest_file="${backup_path}/BACKUP_MANIFEST.json"
    
    print_info "Creating backup manifest..."
    
    # Calculate checksums
    local db_checksum=""
    local config_checksum=""
    
    if [ -f "${backup_path}/database/full_backup.sql" ]; then
        db_checksum=$(sha256sum "${backup_path}/database/full_backup.sql" | cut -d' ' -f1)
    fi
    
    if [ -f "${backup_path}/configs/.env-bitoarch.backup" ]; then
        config_checksum=$(sha256sum "${backup_path}/configs/.env-bitoarch.backup" | cut -d' ' -f1)
    fi
    
    cat > "$manifest_file" << EOF
{
    "backup_info": {
        "timestamp": "${DATE}",
        "platform_version": "${VERSION_CURRENT:-1.0.0}",
        "backup_type": "full",
        "created_by": "$(whoami)",
        "hostname": "$(hostname)"
    },
    "components": {
        "database": {
            "included": true,
            "checksum": "${db_checksum}",
            "size_bytes": $(stat -f%z "${backup_path}/database/full_backup.sql" 2>/dev/null || echo "0")
        },
        "configurations": {
            "included": true,
            "checksum": "${config_checksum}",
            "files_count": $(find "${backup_path}/configs" -type f | wc -l 2>/dev/null || echo "0")
        },
        "volumes": {
            "included": true,
            "volume_count": $(find "${backup_path}/volumes" -name "*.tar.gz" | wc -l 2>/dev/null || echo "0")
        },
        "service_data": {
            "included": true,
            "metadata_included": true
        }
    },
    "restore_instructions": {
        "command": "./scripts/restore.sh $(basename "$backup_path")",
        "prerequisites": ["Docker running", "Platform stopped"],
        "estimated_time_minutes": 10
    }
}
EOF
    
    print_status "Backup manifest created"
}

# Compress backup
compress_backup() {
    local backup_path="$1"
    local backup_name=$(basename "$backup_path")
    local compressed_backup="${BACKUP_DIR}/${backup_name}.tar.gz"
    
    print_info "Compressing backup..."
    
    cd "$BACKUP_DIR"
    tar -czf "${backup_name}.tar.gz" "$backup_name"
    
    # Verify compressed backup
    if [ -f "$compressed_backup" ]; then
        local compressed_size=$(stat -f%z "$compressed_backup" 2>/dev/null || stat -c%s "$compressed_backup" 2>/dev/null || echo "0")
        print_status "Backup compressed: $compressed_backup ($(numfmt --to=iec $compressed_size))"
        
        # Remove uncompressed backup
        rm -rf "$backup_path"
        
        echo "$compressed_backup"
    else
        print_error "Failed to create compressed backup"
        exit 1
    fi
}

# Cleanup old backups
cleanup_old_backups() {
    local retention_days=${BACKUP_RETENTION_DAYS:-30}
    
    print_info "Cleaning up backups older than $retention_days days..."
    
    find "$BACKUP_DIR" -name "backup_*.tar.gz" -type f -mtime +$retention_days -delete 2>/dev/null || true
    
    local remaining_backups=$(find "$BACKUP_DIR" -name "backup_*.tar.gz" -type f | wc -l)
    print_status "Cleanup completed. $remaining_backups backup(s) retained"
}

# Kubernetes backup functions
backup_kubernetes_pvcs() {
    local backup_path="$1"
    local pvc_backup_path="${backup_path}/pvcs"
    local pvc_ok=true
    
    print_info "Backing up Kubernetes PVCs..."
    
    local namespace="bito-ai-architect"
    local pvcs=$(kubectl get pvc -n "$namespace" -o jsonpath='{.items[*].metadata.name}' 2>/dev/null || echo "")
    
    if [ -z "$pvcs" ]; then
        print_warning "No PVCs found to backup"
        return 0
    fi
    
    mkdir -p "$pvc_backup_path"
    
    for pvc in $pvcs; do
        print_info "Backing up PVC: $pvc"
        
        # Create a temporary pod to access PVC
        kubectl run pvc-backup-pod-$$ \
            --namespace="$namespace" \
            --image=busybox:1.36 \
            --restart=Never \
            --overrides="{
              \"apiVersion\": \"v1\",
              \"spec\": {
                \"containers\": [{
                  \"name\": \"backup\",
                  \"image\": \"busybox:1.36\",
                  \"command\": [\"sleep\", \"3600\"],
                  \"volumeMounts\": [{
                    \"name\": \"data\",
                    \"mountPath\": \"/data\"
                  }]
                }],
                \"volumes\": [{
                  \"name\": \"data\",
                  \"persistentVolumeClaim\": {
                    \"claimName\": \"$pvc\"
                  }
                }]
              }
            }" >/dev/null 2>>"${LOG_FILE:-/dev/null}"
        
        # Wait for pod to be ready
        kubectl wait --for=condition=Ready pod/pvc-backup-pod-$$ -n "$namespace" --timeout=60s >/dev/null 2>>"${LOG_FILE:-/dev/null}"
        
        # Backup PVC data
        kubectl exec -n "$namespace" pvc-backup-pod-$$ -- tar czf - -C /data . > "${pvc_backup_path}/${pvc}.tar.gz" 2>>"${LOG_FILE:-/dev/null}" || {
            pvc_ok=false
            print_warning "Failed to backup PVC: $pvc (reason in ${LOG_FILE})"
        }
        
        # Cleanup
        # A failed cleanup leaves an orphan pod holding the PVC; the next backup then
        # fails to create its own pod for reasons that look unrelated.
        kubectl delete pod pvc-backup-pod-$$ -n "$namespace" --force --grace-period=0 >/dev/null 2>>"${LOG_FILE:-/dev/null}" \
            || print_warning "Could not remove the temporary pod pvc-backup-pod-$$ in ${namespace}; remove it manually"
    done
    
    if [ "$pvc_ok" = true ]; then
        print_status "PVC backup completed"
    else
        print_warning "PVC backup completed with errors — see the warnings above"
    fi
}

backup_kubernetes_resources() {
    local backup_path="$1"
    local resource_backup_path="${backup_path}/resources"
    
    print_info "Backing up Kubernetes resources..."
    
    local namespace="bito-ai-architect"
    mkdir -p "$resource_backup_path"
    
    local res_failed=""

    # Backup ConfigMaps
    kubectl get configmaps -n "$namespace" -o yaml > "${resource_backup_path}/configmaps.yaml" 2>>"${LOG_FILE:-/dev/null}" || res_failed="${res_failed} configmaps"

    # Backup Secrets (base64 encoded)
    kubectl get secrets -n "$namespace" -o yaml > "${resource_backup_path}/secrets.yaml" 2>>"${LOG_FILE:-/dev/null}" || res_failed="${res_failed} secrets"

    # Backup Helm release values
    if command -v helm >/dev/null 2>&1; then
        helm get values bitoarch -n "$namespace" > "${resource_backup_path}/helm-values.yaml" 2>>"${LOG_FILE:-/dev/null}" || res_failed="${res_failed} helm-values"
    fi

    # Backup deployments
    kubectl get deployments -n "$namespace" -o yaml > "${resource_backup_path}/deployments.yaml" 2>>"${LOG_FILE:-/dev/null}" || res_failed="${res_failed} deployments"

    # Backup services
    kubectl get services -n "$namespace" -o yaml > "${resource_backup_path}/services.yaml" 2>>"${LOG_FILE:-/dev/null}" || res_failed="${res_failed} services"

    if [ -z "$res_failed" ]; then
        print_status "Kubernetes resources backed up"
    else
        print_warning "Kubernetes resources backed up with failures:${res_failed} (check RBAC permissions)"
    fi
}

backup_kubernetes_database() {
    local backup_path="$1"
    local db_backup_path="${backup_path}/database"
    
    print_info "Backing up database from Kubernetes..."
    
    local namespace="bito-ai-architect"
    
    # Find MySQL pod
    local mysql_pod=$(kubectl get pods -n "$namespace" -l "app.kubernetes.io/component=mysql" -o jsonpath='{.items[0].metadata.name}' 2>/dev/null || echo "")
    
    if [ -z "$mysql_pod" ]; then
        print_error "MySQL pod not found"
        return 1
    fi
    
    # Get credentials from secrets
    local db_user=$(kubectl get secret bitoarch-secrets -n "$namespace" -o jsonpath='{.data.mysql-user}' 2>/dev/null | base64 -d)
    local db_password=$(kubectl get secret bitoarch-secrets -n "$namespace" -o jsonpath='{.data.mysql-password}' 2>/dev/null | base64 -d)
    local db_name=$(kubectl get secret bitoarch-secrets -n "$namespace" -o jsonpath='{.data.mysql-database}' 2>/dev/null | base64 -d)
    
    mkdir -p "$db_backup_path"
    
    # Create full database backup
    kubectl exec -n "$namespace" "$mysql_pod" -- mysqldump \
        --single-transaction \
        --no-tablespaces \
        --routines \
        --triggers \
        --events \
        --hex-blob \
        --user="$db_user" \
        --password="$db_password" \
        "$db_name" > "${db_backup_path}/full_backup.sql" 2>/dev/null || {
        print_error "Database backup failed"
        return 1
    }
    
    # Create schema-only backup
    kubectl exec -n "$namespace" "$mysql_pod" -- mysqldump \
        --no-data \
        --no-tablespaces \
        --routines \
        --triggers \
        --events \
        --user="$db_user" \
        --password="$db_password" \
        "$db_name" > "${db_backup_path}/schema_only.sql" 2>/dev/null || true
    
    print_status "Database backup completed"
}

backup_kubernetes() {
    local backup_path="$1"
    
    print_info "Creating Kubernetes backup..."
    
    backup_kubernetes_database "$backup_path"
    backup_kubernetes_pvcs "$backup_path"
    backup_kubernetes_resources "$backup_path"
    
    print_status "Kubernetes backup completed"
}

# Main backup function
main() {
    echo -e "${BLUE}Bito's AI Architect Backup - Zero Data Loss${NC}"
    echo "================================================"
    echo ""
    
    # Create backup directory if it doesn't exist
    mkdir -p "$BACKUP_DIR"
    
    # Detect deployment type
    local deployment_type="docker-compose"
    if [ -f "${PLATFORM_DIR}/.deployment-type" ]; then
        deployment_type=$(cat "${PLATFORM_DIR}/.deployment-type")
    fi

    # Pin to the cluster.yaml context so a K8s backup targets the right cluster on
    # a drifted current-context (no-op when inherited from the CLI / no context).
    if [ "$deployment_type" = "kubernetes" ]; then
        command -v _pin_kube_context >/dev/null 2>&1 \
            || source "${SCRIPT_DIR}/lib/cluster-yaml.sh" 2>/dev/null || true
        if command -v _pin_kube_context >/dev/null 2>&1; then
            _pin_kube_context || exit 1
        fi
    fi

    # Check if platform is running
    if [ "$deployment_type" = "kubernetes" ]; then
        if ! kubectl get namespace bito-ai-architect >/dev/null 2>&1; then
            print_warning "Kubernetes namespace not found. Creating offline backup..."
        fi
    else
        if ! $COMPOSE --env-file "${PLATFORM_DIR}/.env-bitoarch" -f "${PLATFORM_DIR}/docker-compose.yml" ps | grep -q "Up"; then
            print_warning "Bito's AI Architect is not running. Creating offline backup..."
        fi
    fi
    
    # Create backup structure
    local backup_path=$(create_backup_structure)
    local backup_name=$(basename "$backup_path")
    
    print_info "Starting backup: $backup_name"
    
    # Perform backup components based on deployment type
    if [ "$deployment_type" = "kubernetes" ]; then
        backup_kubernetes "$backup_path"
        backup_configurations "$backup_path"
    else
        backup_database "$backup_path"
        backup_configurations "$backup_path"
        backup_volumes "$backup_path"
        backup_service_data "$backup_path"
    fi
    
    create_backup_manifest "$backup_path"
    
    # Compress and finalize
    local compressed_backup=$(compress_backup "$backup_path")
    
    # Cleanup old backups
    cleanup_old_backups
    
    echo ""
    print_status "Backup completed successfully!"
    echo -e "${BLUE}Backup location:${NC} $compressed_backup"
    echo -e "${BLUE}Restore command:${NC} ./scripts/restore.sh $backup_name"
    echo ""
}

# Handle command line arguments
case "${1:-}" in
    --help|-h)
        echo "Bito's AI Architect Backup Script"
        echo ""
        echo "Usage: $0 [options]"
        echo ""
        echo "Options:"
        echo "  --help, -h      Show this help message"
        echo "  --quick         Quick backup (database + configs only)"
        echo "  --full          Full backup (all components) [default]"
        echo ""
        echo "Environment variables:"
        echo "  BACKUP_RETENTION_DAYS    Days to keep backups (default: 30)"
        ;;
    --quick)
        print_info "Quick backup mode selected"
        # Override functions for quick backup
        backup_volumes() { print_info "Skipping volumes in quick mode"; }
        backup_service_data() { print_info "Skipping service data in quick mode"; }
        main
        ;;
    --full|"")
        main
        ;;
    *)
        echo "Unknown option: $1"
        echo "Use --help for usage information"
        exit 1
        ;;
esac
