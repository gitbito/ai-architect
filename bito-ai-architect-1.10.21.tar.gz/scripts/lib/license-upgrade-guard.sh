#!/bin/bash
#
# Copyright (c) 2023-2026 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
# License check before an upgrade to a release that enforces licensing.
# `bitoarch upgrade` runs the INSTALLED upgrade.sh, which sources this file from
# the NEW package right after extracting it, before anything is applied. A target
# whose versions/service-versions.json doesn't set platform_info.license_enforced
# changes nothing.

if [ -n "${_BITOARCH_LICENSE_UPGRADE_GUARD_LOADED:-}" ]; then
    return 0
fi
_BITOARCH_LICENSE_UPGRADE_GUARD_LOADED=1

# The new build's services refuse a clock this far behind their build time.
_LUG_CLOCK_TOLERANCE_SECONDS=$((48 * 3600))

_lug_error() { if type msg_error >/dev/null 2>&1; then msg_error "$1"; else echo "✗ $1" >&2; fi; }
_lug_info()  { if type msg_info  >/dev/null 2>&1; then msg_info  "$1"; else echo "ℹ $1" >&2; fi; }
_lug_warn()  { if type msg_warn  >/dev/null 2>&1; then msg_warn  "$1"; else echo "⚠ $1" >&2; fi; }
_lug_log()   { echo "[$(date '+%Y-%m-%d %H:%M:%S')] license upgrade guard: $1" >> "${LOG_FILE:-/dev/null}" 2>/dev/null || true; }

# The running install's license, read with the new package's config-adapter and
# the installed env (API key, cis-config port; on Kubernetes the adapter opens
# the port-forward). Returns config_fetch_license's code: 0 answered, 2 no
# license API (an install from before licensing), 3 API key refused, 1 no answer.
_lug_fetch_license() {   # <new_dir> <installed_env_file>
    local new_dir="$1" env_file="$2"
    (
        # config-adapter.sh finds its helpers under SCRIPT_DIR, the package root.
        export SCRIPT_DIR="$new_dir"
        if [ -f "$env_file" ]; then set -a; . "$env_file" >/dev/null 2>&1; set +a; fi
        . "$new_dir/scripts/lib/path-manager.sh" >/dev/null 2>&1 || true
        . "$new_dir/scripts/lib/adapters/config-adapter.sh" >/dev/null 2>&1 || exit 1
        config_fetch_license 15
    )
}

# Why the license stops this upgrade, or nothing when it doesn't.
_lug_refusal() {   # <license-json> <target-version>
    local body="$1" target="$2" state msg aia rerr creason
    state=$(printf '%s' "$body" | jq -r '.state // "missing"' 2>/dev/null)
    case "$state" in
        valid|expiring|grace)
            aia=$(printf '%s' "$body" | jq -r '.is_ai_architect_enabled == true' 2>/dev/null)
            [ "$aia" = "true" ] && return 0
            echo "This install's license includes no AI Architect product. Contact your Bito account team before upgrading."
            return 0 ;;
    esac
    msg="This install has no valid license (${state}). Release ${target} refuses service without one. Run 'bitoarch license request' first, or re-run with --force to upgrade anyway."
    creason=$(printf '%s' "$body" | jq -r '[.clock_invalid_reason, .reason] | map(select(. != null and . != "")) | first // empty' 2>/dev/null)
    rerr=$(printf '%s' "$body" | jq -r 'if .connectivity == "online" then (.last_renew_error // "") else "" end' 2>/dev/null)
    if [ "$state" = "clock_invalid" ] && [ -n "$creason" ]; then
        msg="${msg} The license can't be checked because of the system clock: ${creason}."
    elif [ -n "$rerr" ]; then
        msg="${msg} License renewal is failing: ${rerr}."
    fi
    echo "$msg"
}

# Warns when this machine's clock is more than 48 h behind the new build: the
# new services would report clock_invalid. A warning only; it never stops.
_lug_clock_check() {   # <new_dir>
    local built now
    built=$(jq -r '.platform_info.build_timestamp // empty | fromdateiso8601' "$1/version-manifest.json" 2>/dev/null) || return 0
    [[ "$built" =~ ^[0-9]+$ ]] || return 0
    now=$(date -u +%s)
    if [ $((built - now)) -gt "$_LUG_CLOCK_TOLERANCE_SECONDS" ]; then
        _lug_warn "This machine's clock is more than 48 hours behind the new release's build time ($(jq -r '.platform_info.build_timestamp' "$1/version-manifest.json")). After the upgrade the license would be clock_invalid. Fix the system clock before upgrading."
        _lug_log "clock $(date -u +%Y-%m-%dT%H:%M:%SZ) is more than 48h behind the build"
    fi
}

# upgrade_license_guard <new_dir> <force 0|1> <installed_env_file>
# Returns 0 to go on with the upgrade, 1 to stop it.
upgrade_license_guard() {
    local new_dir="$1" force="${2:-0}" env_file="${3:-}" target body rc=0 why=""
    jq -e '.platform_info.license_enforced == true' "$new_dir/versions/service-versions.json" >/dev/null 2>&1 || return 0
    target=$(jq -r '.platform_info.version // "the new release"' "$new_dir/versions/service-versions.json" 2>/dev/null)

    _lug_clock_check "$new_dir"

    body=$(_lug_fetch_license "$new_dir" "$env_file") || rc=$?
    if [ "$rc" -eq 2 ]; then
        why="This install has no license yet (it predates licensing). Release ${target} refuses service without one. Run 'bitoarch license request' first, or re-run with --force to upgrade anyway."
    elif [ "$rc" -eq 3 ]; then
        why="The license could not be checked: AI Architect did not accept your Bito API key. Run 'bitoarch update-api-key' to set the right key, or re-run with --force to upgrade anyway."
    elif [ "$rc" -ne 0 ]; then
        why="The license could not be checked: ai-architect-config did not answer. Start AI Architect and check 'bitoarch license status', or re-run with --force to upgrade anyway."
    else
        why=$(_lug_refusal "$body" "$target")
    fi
    if [ -z "$why" ]; then
        _lug_log "license allows the upgrade to ${target}"
        return 0
    fi
    if [ "$force" = "1" ]; then
        _lug_warn "Upgrading anyway (--force): ${why}"
        _lug_log "upgrade forced past the license check: ${why}"
        return 0
    fi
    _lug_error "$why"
    _lug_log "upgrade refused: ${why}"
    return 1
}
