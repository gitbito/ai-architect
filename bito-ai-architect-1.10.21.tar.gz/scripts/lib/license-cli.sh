#!/bin/bash
#
# Copyright (c) 2023-2026 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
# Bito's AI Architect CLI - bitoarch license request | status | install | report,
# and the one-line license status every other command prints first.
# Everything here reads cis-config's GET /api/v1/license and
# POST /api/v1/license/validate (config-adapter.sh); nothing calls Bito.

if [ -n "${_BITOARCH_LICENSE_CLI_LOADED:-}" ]; then
    return 0
fi
_BITOARCH_LICENSE_CLI_LOADED=1

# Fields the messages need, joined with the unit separator so empty fields keep
# their place (read with a whitespace IFS would collapse them). An online key
# folds its grace into expires_at and has no grace_until, so access ends then.
_lic_fields() {   # <json>
    printf '%s' "$1" | jq -r '[
        .state, .connectivity, .kid_class, .license_id,
        (.days_left | if . == null then "" else tostring end),
        (.expires_at // "" | .[0:10]), (.contract_expires_at // "" | .[0:10]),
        (.grace_until // .expires_at // "" | .[0:10]), (.starts_at // "" | .[0:10]),
        .last_renew_error, (.last_renew_ok_at // "" | .[0:10]),
        ([.clock_invalid_reason, .reason] | map(select(. != null and . != "")) | first),
        (.is_ai_architect_enabled | if . == null then "" else tostring end),
        (.products["ai-architect"]?.status // "not licensed")
    ] | map(. // "" | tostring) | join("\u001f")' 2>/dev/null
}

# "N days" for a person: days_left is rounded down, so 0 is the last, partial day.
_lic_days() {   # <n>
    case "$1" in
        0) echo "less than a day" ;;
        1) echo "1 day" ;;
        *) echo "$1 days" ;;
    esac
}

# The one-line message for a license view, or nothing when there is nothing to
# say (valid, renewing fine). Wording follows the plan's message table.
license_status_message() {   # <json>
    local st conn kid id days exp cexp grace start rerr rok cir aie pst renew_fail=""
    IFS=$'\x1f' read -r st conn kid id days exp cexp grace start rerr rok cir aie pst < <(_lic_fields "$1")

    # A usable key that doesn't cover AI Architect: every gate refuses, so say
    # why even though the key itself is fine. An online key without AI
    # Architect means the workspace has no active contract; the product status
    # ("expired" for a workspace that never had a contract) would mislead. Only
    # an online install renews, so only there does a new contract arrive by
    # itself. Offline, the key ID and status go to Bito with the request.
    case "$st" in valid|expiring|grace)
        if [ "$aie" = "false" ]; then
            if [ "$kid" = "online" ] && [ "$conn" = "online" ]; then
                echo "This workspace has no active AI Architect contract with Bito. Contact your Bito account team; AI Architect turns on automatically within an hour after the contract is set up."
            elif [ "$kid" = "online" ]; then
                echo "This workspace has no active AI Architect contract with Bito. Contact your Bito account team, then run 'bitoarch license request' and install the offline key Bito sends."
            else
                echo "License ${id} does not include AI Architect (ai-architect: ${pst//_/ }). Run 'bitoarch license request' and send the code to Bito."
            fi
            return 0
        fi ;;
    esac

    if [ "$conn" = "online" ] && [ -n "$rerr" ]; then
        if [ -n "$rok" ]; then
            renew_fail="License renewal has failed since ${rok} (${rerr}); the current key expires on ${exp}. Restore access to Bito, or request an offline key."
        else
            renew_fail="License renewal is failing (${rerr}); the current key expires on ${exp}. Restore access to Bito, or request an offline key."
        fi
    fi

    case "$st" in
        valid)
            [ -z "$renew_fail" ] || echo "$renew_fail" ;;
        expiring)
            if [ "$conn" = "offline" ] && [ "$kid" = "online" ]; then
                echo "This install is offline, and its last online key expires in $(_lic_days "$days"), on ${exp}. Run 'bitoarch license request' and install the offline key Bito sends."
            elif [ -n "$renew_fail" ]; then
                echo "$renew_fail"
            elif [ "$conn" = "online" ]; then
                echo "Your Bito contract ends in $(_lic_days "$days"), on ${cexp:-$exp}. Contact your Bito account team to renew it; AI Architect picks up the renewed contract automatically."
            else
                echo "License ${id} expires in $(_lic_days "$days"), on ${exp}. Run 'bitoarch license request' to renew it."
            fi ;;
        grace)
            if [ "$conn" = "online" ]; then
                echo "Your Bito contract ended on ${cexp:-$exp}; access ends on ${grace}. Contact your Bito account team."
            else
                echo "License ${id} expired on ${exp}; its grace period ends on ${grace}. Run 'bitoarch license request' to renew it now."
            fi ;;
        missing)
            if [ "$conn" = "online" ]; then
                echo "AI Architect could not get a license from Bito: ${rerr:-no key has been received yet}. Check the network connection and BITO_API_KEY, or run 'bitoarch license request' for an offline key."
            else
                echo "AI Architect needs a license on this install. Run 'bitoarch license request' and send the code to Bito."
            fi ;;
        expired)
            echo "AI Architect license ${id} expired on ${exp}. Run 'bitoarch license request' to renew it." ;;
        not_started)
            echo "License ${id} starts on ${start}." ;;
        invalid)
            # cir carries the view's reason (e.g. "key is for another install").
            echo "The license key is not valid for this install: ${cir:-${rerr:-run 'bitoarch license status' for details}}." ;;
        clock_invalid)
            echo "The license cannot be checked because of the system clock: ${cir:-the clock is behind what this install has seen}. Fix the clock, then run 'bitoarch license status'." ;;
        unsupported)
            echo "License ${id} needs a newer version of AI Architect. Upgrade AI Architect, then install the key again." ;;
        not_licensed)
            echo "License ${id} does not include AI Architect. Contact your Bito account team." ;;
    esac
    return 0
}

# Prints the license line, on stderr, before a command's own output when the
# license needs attention. Silent when cis-config can't answer quickly or has no
# license API, for commands where it would only get in the way or slow down
# (lifecycle and logs), and on Kubernetes unless a port-forward is already open.
# A build that does not enforce says so, so nobody reads the line as a block.
license_status_line_maybe() {   # <command>
    case "${1:-}" in
        license|config|uninstall|stop|start|restart|update|upgrade|logs|help|"") return 0 ;;
    esac
    command -v config_fetch_license >/dev/null 2>&1 || return 0
    local body msg
    body=$(
        if [ -z "${BITO_API_KEY:-}" ]; then
            env_file="$(get_config_file 2>/dev/null)"
            [ -f "$env_file" ] || exit 1
            BITO_API_KEY=$(grep -m1 '^BITO_API_KEY=' "$env_file" | cut -d= -f2- | tr -d "\"'")
            CIS_CONFIG_EXTERNAL_PORT=$(grep -m1 '^CIS_CONFIG_EXTERNAL_PORT=' "$env_file" | cut -d= -f2- | tr -d "\"'")
            [ -n "$BITO_API_KEY" ] || exit 1
            export BITO_API_KEY CIS_CONFIG_EXTERNAL_PORT
        fi
        config_fetch_license 3 reuse
    ) || return 0
    msg=$(license_status_message "$body")
    [ -n "$msg" ] || return 0
    [ "$(printf '%s' "$body" | jq -r '.enforced // false' 2>/dev/null)" = "true" ] || msg="${msg} (Not enforced in this version.)"
    echo -e "${YELLOW}⚠ ${msg}${NC}" >&2
    return 0
}

# The license view on stdout, or an explanation on stderr and 1. Callers capture
# stdout, so the explanation must not go there (print_error writes to stdout).
_lic_get() {
    local body rc=0
    body=$(config_fetch_license 15) || rc=$?
    case "$rc" in
        0) ;;
        2) print_error "This AI Architect version has no license service. Upgrade AI Architect first." >&2; return 1 ;;
        3) print_error "AI Architect did not accept your Bito API key, so the license could not be read. Run 'bitoarch update-api-key' to set the right key." >&2; return 1 ;;
        *) print_error "Could not reach the license service (ai-architect-config). Check 'bitoarch status'." >&2; return 1 ;;
    esac
    if [ "$(printf '%s' "$body" | jq -r '.mode // empty' 2>/dev/null)" = "multi-tenant" ]; then
        print_error "Licenses apply to on-prem (single-tenant) installs only." >&2
        return 1
    fi
    printf '%s' "$body"
}

# days_left counts to the contract end for an online key that renews (online
# connectivity), else to the key's own expiry; the date shown is the same one.
# Past that date (grace) days_left goes negative, so grace names the day access
# ends instead. An online key without AI Architect is a workspace with no
# contract, whatever the key's own state.
_lic_state_text() {   # <json>
    printf '%s' "$1" | jq -r '
        def days: if . == 0 then "less than a day" elif . == 1 then "1 day" else "\(.) days" end;
        (.kid_class == "online" and .connectivity == "online" and .contract_expires_at != null) as $contract
        | if (.state == "valid" or .state == "expiring" or .state == "grace")
                and .is_ai_architect_enabled == false and .kid_class == "online" then
            "no active AI Architect contract"
        elif .state == "grace" then
            "grace period, access ends on \(.grace_until // .expires_at // "" | .[0:10])"
                + (if $contract then " (contract ended on \(.contract_expires_at[0:10]))"
                   elif .expires_at then " (expired on \(.expires_at[0:10]))" else "" end)
        elif .state == "valid" or .state == "expiring" then
            .state + (if .days_left != null then ", \(.days_left | days) left" else "" end)
                   + (if $contract then " (contract ends on \(.contract_expires_at[0:10]))"
                      elif .expires_at then " (expires on \(.expires_at[0:10]))" else "" end)
        elif .state == "missing" then "missing (no key installed)"
        else .state end' 2>/dev/null
}

# bitoarch license request: the activation code to send to Bito. Unsigned and
# secret-free: what licensetool needs to sign a key for this install.
license_request() {
    case "${1:-}" in -h|--help) _license_help; return 0 ;; esac
    local body
    body=$(_lic_get) || return 1
    license_print_request "$body"
}

# Prints the activation code for a license view (the installer passes the view
# it already has), in go-common's license/SPEC.md "Activation code" format:
# BITOACT1.<unpadded base64url of the JSON>, every field from the view. Returns
# 1, with the reason on stderr, while the install has no install ID, no
# workspace ID or no license library to report.
license_print_request() {   # <json>
    local body="$1" install_id ws request code
    install_id=$(printf '%s' "$body" | jq -r '.install_id // empty' 2>/dev/null)
    ws=$(printf '%s' "$body" | jq -r '.workspace_id // 0' 2>/dev/null)
    if [ -z "$install_id" ]; then
        print_error "This install has no install ID yet; cis-config creates it when it first starts. Start AI Architect, then run this again." >&2
        return 1
    fi
    if ! [[ "$ws" =~ ^[1-9][0-9]*$ ]]; then
        print_error "cis-config has not recorded this install's Bito workspace ID yet, so a key can't be bound to it. Check 'bitoarch license status', then run this again." >&2
        return 1
    fi
    if [ "$(printf '%s' "$body" | jq -r '(.library.max_major != null) and ((.library.catalogs // {}) | length > 0)' 2>/dev/null)" != "true" ]; then
        print_error "This AI Architect version does not report its license library. Upgrade AI Architect first." >&2
        return 1
    fi
    # The active key's three fields go together, or not at all.
    request=$(printf '%s' "$body" | jq -c '{
        workspace_id, install_id,
        product: "ai-architect",
        max_major: .library.max_major,
        crit: (.library.crit // []),
        catalog_versions: .library.catalogs
    } + (if [.license_id, .issued_at, .kid_class] | all(. != null and . != "")
         then {active_license_id: .license_id, active_issued_at: .issued_at, active_kid_class: .kid_class}
         else {} end)')
    code="BITOACT1.$(printf '%s' "$request" | base64 | tr '+/' '-_' | tr -d '=\n')"

    print_header "License activation request"
    printf '%s' "$request" | jq -r '
        "  Workspace:   \(.workspace_id)",
        "  Install:     \(.install_id)",
        "  Product:     \(.product) (catalog v\(.catalog_versions[.product] // "?"))",
        "  Active key:  " + (if .active_license_id then "\(.active_license_id) (\(.active_kid_class) key, issued \(.active_issued_at[0:10]))" else "none" end)'
    echo ""
    echo "Send this activation code to Bito. It contains no secrets."
    echo ""
    echo "$code"
    echo ""
    print_info "When Bito sends the key, install it with: bitoarch license install --from-file <file>"
}

# bitoarch license status
license_status() {
    case "${1:-}" in -h|--help) _license_help; return 0 ;; esac
    local body msg
    body=$(_lic_get) || return 1
    print_header "License"
    echo "  Connectivity:  $(printf '%s' "$body" | jq -r '.connectivity // "unknown"')"
    echo "  State:         $(_lic_state_text "$body")"
    printf '%s' "$body" | jq -r '
        (if (.license_id // "") != "" then "  License ID:    \(.license_id) (\(.kid_class) key)" else empty end),
        "  Workspace:     \(.workspace_id)",
        "  Install ID:    \(.install_id // "not created yet")",
        (if (.products // {}) | length > 0 then
            "  Products:      " + ([.products | to_entries[] | "\(.key) (\(.value.status // "not licensed" | gsub("_"; " ")))"] | join(", "))
         else empty end),
        (if (.unknown // []) | length > 0 then "  Ignored:       " + (.unknown | join(", ")) + " (not known to this version)" else empty end),
        (if .connectivity == "online" then
            "  Renewal:       " + (if (.last_renew_error // "") != "" then "failing (\(.last_renew_error))"
                                 elif .last_renew_ok_at then "working" else "no renewal yet" end)
                              + (if .last_renew_ok_at then ", last success on \(.last_renew_ok_at[0:10])" else "" end)
         else empty end),
        (if has("enforced") then
            "  Enforcement:   " + (if .enforced then "on" else "off (this version reports the license but does not enforce it)" end)
         else empty end),
        ({configured: "your own provider", bito: "Bito", byok_required: "none configured"}[.llm_provider_state // ""]
         | if . then "  LLM provider:  \(.)" else empty end)'
    msg=$(license_status_message "$body")
    if [ -n "$msg" ]; then
        echo ""
        print_warning "$msg"
    fi
    if [ "$(printf '%s' "$body" | jq -r '.llm_provider_state // empty')" = "byok_required" ]; then
        echo ""
        print_warning "This air-gapped install has no LLM provider, and Bito's LLM is not available offline. Configure your own with: bitoarch update-llm-config"
    fi
    return 0
}

# bitoarch license install [<key> | --from-file <path> | -]
# Validates first and changes nothing unless the key would become active; then
# writes the key to the env file and install.yaml and restarts cis-config and
# cis-manager. cis-worker needs no restart: its gated calls go through cis-config.
license_install() {
    local key="" from_file="" read_stdin=false
    while [ $# -gt 0 ]; do
        case "$1" in
            --from-file)
                [ -n "${2:-}" ] || { print_error "--from-file needs the path of the key file. Nothing was changed."; return 1; }
                from_file="$2"; shift 2 ;;
            -) read_stdin=true; shift ;;
            -h|--help) _license_help; return 0 ;;
            -*) print_error "Unknown option: $1"; return 1 ;;
            *) key="$1"; shift ;;
        esac
    done

    if [ -n "$from_file" ]; then
        [ -r "$from_file" ] || { print_error "Cannot read ${from_file}. Nothing was changed."; return 1; }
        key=$(cat "$from_file")
    elif [ -z "$key" ]; then
        if [ "$read_stdin" = true ] || [ ! -t 0 ]; then
            key=$(cat)
        else
            read -r -s -p "Paste the license key (input hidden): " key; echo ""
        fi
    fi
    key=$(printf '%s' "$key" | tr -d '[:space:]')
    if ! [[ "$key" =~ ^BITO1\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+$ ]]; then
        print_error "That is not a license key (expected one line starting with BITO1.). Nothing was changed."
        return 1
    fi

    local result rc=0
    result=$(config_validate_license "$key") || rc=$?
    case "$rc" in
        0) ;;
        2) print_error "This AI Architect version has no license service. Upgrade AI Architect first."; return 1 ;;
        3) print_error "AI Architect did not accept your Bito API key, so the license key could not be checked. Nothing was changed. Run 'bitoarch update-api-key' to set the right key."; return 1 ;;
        *) print_error "Could not reach the license service (ai-architect-config) to check the key. Nothing was changed."; return 1 ;;
    esac
    if [ "$(printf '%s' "$result" | jq -r '.ok')" != "true" ]; then
        print_error "The license key was not installed. Nothing was changed."
        printf '%s' "$result" | jq -r '.checks[]? | select(.ok == false) | "  • \(.name): \(.reason)"'
        return 1
    fi
    if [ "$(printf '%s' "$result" | jq -r '.would_activate')" != "true" ]; then
        # The same key again is not an error: it is already the one in use.
        if [ "$(grep -m1 '^BITO_LICENSE_KEY=' "$(get_config_file 2>/dev/null)" 2>/dev/null | cut -d= -f2-)" = "$key" ]; then
            print_success "License $(printf '%s' "$result" | jq -r '.license_id // empty') is already installed. Nothing was changed."
            return 0
        fi
        print_error "The key is valid but would not become active: this install already has a newer key. Nothing was changed."
        return 1
    fi

    local new_id env_file yaml
    new_id=$(printf '%s' "$result" | jq -r '.license_id // empty')
    env_file="$(get_config_file)"
    yaml="$(get_install_yaml_file 2>/dev/null)"
    platform_set_license_key "$key" "$env_file" "$yaml" || {
        print_error "Could not write the key to ${env_file}"
        return 1
    }
    export BITO_LICENSE_KEY="$key"
    print_success "License ${new_id} saved"
    print_info "Restarting ai-architect-config and ai-architect-manager..."
    ENV_FILE="$env_file" platform_restart_license_services ai-architect-config ai-architect-manager || return 1

    # Wait for cis-config to come back with the new key active.
    local waited=0 body=""
    while [ "$waited" -lt 120 ]; do
        body=$(config_fetch_license 5 2>/dev/null) && [ "$(printf '%s' "$body" | jq -r '.license_id // empty')" = "$new_id" ] && break
        body=""
        sleep 3; waited=$((waited + 3))
    done
    if [ -z "$body" ]; then
        print_warning "The key is saved, but cis-config has not reported it yet. Check with: bitoarch license status"
        return 0
    fi
    print_success "License ${new_id} installed: $(_lic_state_text "$body")"
    print_info "If repository setup was skipped because of the license, finish it with: bitoarch setup --resume"
    return 0
}

# bitoarch license report: the evidence to send to Bito, on stdout.
license_report() {
    case "${1:-}" in -h|--help) _license_help; return 0 ;; esac
    local body cfg ws bytes cap repos repo_cap min_build cfg_rc=0 no_cfg=false
    local indexed="unavailable (could not read the database)"
    body=$(_lic_get) || return 1
    cfg=$(config_fetch_config "${BITO_API_KEY:-}" 2>/dev/null) || cfg_rc=$?

    ws=$(printf '%s' "$body" | jq -r '.workspace_id // 0')
    [ "$ws" != "0" ] || ws="${BITO_WORKSPACE_ID:-0}"
    # No key yet: the workspace cis-config runs as. No saved configuration yet
    # means no repositories, so nothing is indexed.
    if ! [[ "$ws" =~ ^[1-9][0-9]*$ ]]; then
        case "$cfg_rc" in
            0) ws=$(printf '%s' "$cfg" | jq -r '.workspace_id // empty' 2>/dev/null) ;;
            2) no_cfg=true ;;
        esac
    fi
    if [ "$no_cfg" = true ]; then
        ws=0; indexed="0 MB (no repositories configured yet)"
    elif ! [[ "$ws" =~ ^[1-9][0-9]*$ ]]; then
        ws=0; indexed="unavailable (workspace unknown)"
    elif command -v sql_exec_query >/dev/null 2>&1 \
       && bytes=$(sql_exec_query "${MYSQL_DATABASE:-code_intelligence}" \
            "SELECT COALESCE(SUM(repo_size), 0) FROM repo_metadata WHERE workspace_id=${ws};" 2>/dev/null) \
       && [[ "$bytes" =~ ^[0-9]+$ ]]; then
        # Whole MB rounded up, the figure cis-manager compares with max_indexed_mb.
        indexed="$(( (bytes + 1048575) / 1048576 )) MB"
    fi
    cap=$(printf '%s' "$body" | jq -r '.products["ai-architect"]?.limits.max_indexed_mb // empty' 2>/dev/null)
    case "$cap" in ""|-1) cap="unlimited" ;; *) cap="${cap} MB" ;; esac

    # Configured repositories: what cis-config counts against max_index_repos.
    case "$cfg_rc" in
        0) repos="$(printf '%s' "$cfg" | jq -r '[.repository.configured_repos[]?] | length' 2>/dev/null) configured" ;;
        2) repos="0 configured" ;;
        *) repos="unavailable (could not reach ai-architect-config)" ;;
    esac
    repo_cap=$(printf '%s' "$body" | jq -r '.products["ai-architect"]?.limits.max_index_repos // empty' 2>/dev/null)
    case "$repo_cap" in ""|-1) repo_cap="unlimited" ;; esac

    # The running cis-config version (min_build), from the license view like
    # everything else. A cis-config that doesn't serve it yet is read from its
    # install row instead: one row (id 1), rewritten at each start.
    if [ "$(printf '%s' "$body" | jq -r 'has("min_build")' 2>/dev/null)" = "true" ]; then
        min_build=$(printf '%s' "$body" | jq -r '.min_build // ""' 2>/dev/null)
        [ -n "$min_build" ] || min_build="not recorded"
    elif command -v sql_exec_query >/dev/null 2>&1 \
       && min_build=$(sql_exec_query "${MYSQL_DATABASE:-code_intelligence}" \
            "SELECT COALESCE(min_build, '') FROM license_install WHERE id = 1;" 2>/dev/null); then
        [ -n "$min_build" ] || min_build="not recorded"
    else
        min_build="unavailable (could not read the database)"
    fi

    echo "AI Architect license report"
    echo "Generated: $(date -u '+%Y-%m-%dT%H:%M:%SZ')"
    echo ""
    printf '%s' "$body" | jq -r --arg ws "$ws" --arg mb "$min_build" '
        "Install",
        "  Workspace:      \($ws)",
        "  Install ID:     \(.install_id // "")",
        "  Connectivity:   \(.connectivity // "")",
        "  Min build:      \($mb)",
        "",
        "License",
        "  State:          \(.state)",
        (if (.license_id // "") != "" then "  License ID:     \(.license_id)  (\(.kid_class // "") key)" else "  License ID:     none" end),
        "  Issued:         \(.issued_at // "")",
        "  Starts:         \(.starts_at // "")",
        "  Expires:        \(.expires_at // "")",
        "  Contract ends:  \(.contract_expires_at // "")",
        "  Grace until:    \(.grace_until // "")",
        "  Days left:      \(.days_left // "")",
        "  Products:       " + ([(.products // {}) | to_entries[] | "\(.key) " + (if .value then "\(.value.status) (catalog v\(.value.catalog_version))" else "not licensed" end)] | join(", ")),
        "  Ignored:        " + ((.unknown // []) | join(", ")),
        "",
        "Clock",
        "  Effective now:  \(.effective_now // "")",
        "  Clock skew:     \(.clock_skew_seconds // 0) s",
        "  Clock problem:  \(.clock_invalid_reason // "")",
        "  Inputs:",
        ((.effective_now_inputs // {}) | to_entries[] | "    \(.key): \(.value)"),
        "",
        "Renewal",
        "  Last success:   \(.last_renew_ok_at // "")",
        "  Last error:     \(.last_renew_error // "")",
        "",
        "Library",
        "  Max major:      \(.library.max_major // "")",
        "  Understood crit: " + ((.library.crit // []) | join(", ")),
        "  Catalogs:       " + ([(.library.catalogs // {}) | to_entries[] | "\(.key) v\(.value)"] | join(", "))'
    echo ""
    echo "Usage"
    echo "  Repositories:   ${repos} (limit: ${repo_cap})"
    echo "  Indexed size:   ${indexed} (limit: ${cap})"
    echo ""
    echo "Plugins installed"
    _lic_report_plugins
    echo ""
    # The key's plugin flags; a plugin is licensed only when its flag is true.
    echo "Plugins licensed"
    printf '%s' "$body" | jq -r '(.products["ai-architect"]?.features // {}) as $f
        | ("slack_ai_assistant_enabled", "is_jira_analysis_enabled", "is_linear_analysis_enabled")
        | "  \(.): " + (if $f["agent-config.public." + .] == true then "yes" else "no" end)' 2>/dev/null
}

# Installed plugins from the plugin journal, read only: a report never changes
# plugin state, so the live-health reconcile `plugin list` does is skipped.
_lic_report_plugins() {
    type journal_read >/dev/null 2>&1 \
        || . "$(dirname "${BASH_SOURCE[0]}")/plugin/state-journal.sh" 2>/dev/null || true
    local journal
    if ! type journal_read >/dev/null 2>&1 || ! journal=$(journal_read 2>/dev/null); then
        echo "  unavailable (could not read the plugin journal)"
        return 0
    fi
    printf '%s' "$journal" | jq -r '(.plugins // {}) | to_entries
        | if length == 0 then "  none installed"
          else .[] | "  \(.key) \(.value.version // "unknown version") (\(.value.status // "unknown"))" end' 2>/dev/null \
        || echo "  unavailable (could not read the plugin journal)"
}

_license_help() {
    cat <<'EOF'
USAGE:
  bitoarch license request          Print the activation code to send to Bito
  bitoarch license status           Show the license: state, days left, products
  bitoarch license install <key>    Install the key Bito sends
  bitoarch license install --from-file <path>
  bitoarch license install -        Read the key from stdin
  bitoarch license report           Print the license evidence and usage for Bito

NOTES:
  - install checks the key first and changes nothing if it is refused.
  - Prefer --from-file or stdin: the key then stays out of your shell history.
EOF
}

license_cli_main() {
    local sub="${1:-}"
    shift 2>/dev/null || true
    case "$sub" in
        request) license_request "$@" ;;
        status)  license_status "$@" ;;
        install) license_install "$@" ;;
        report)  license_report "$@" ;;
        ""|-h|--help|help) _license_help ;;
        *) print_error "Unknown license command: ${sub}"; _license_help; return 1 ;;
    esac
}
