#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PLATFORM_DIR="$SCRIPT_DIR"  # Explicitly save platform root directory

# Source path manager for standard Unix paths
source "${SCRIPT_DIR}/scripts/lib/path-manager.sh"
# Offline Wingman bundle: seeds the shared shelf from assets shipped in the
# package. Every entry point no-ops when the package carries no bundle.
# wingman-shelf.sh comes first: it defines _wingman_fs_apply, which the bundle's
# already-seeded check uses to read the shelf marker in-container. Without it that
# check is inert and every helm apply re-seeds a shelf that is already correct.
# shellcheck disable=SC1091
source "${SCRIPT_DIR}/scripts/lib/wingman-shelf.sh" 2>/dev/null \
    || { [ -f "${SCRIPT_DIR}/scripts/lib/wingman-shelf.sh" ] && type log_silent >/dev/null 2>&1 \
         && log_silent "wingman bundle: "${SCRIPT_DIR}/scripts/lib/wingman-shelf.sh" exists but failed to load; offline seeding unavailable"; true; }
# shellcheck disable=SC1091
source "${SCRIPT_DIR}/scripts/lib/wingman-bundle.sh" 2>/dev/null \
    || { [ -f "${SCRIPT_DIR}/scripts/lib/wingman-bundle.sh" ] && type log_silent >/dev/null 2>&1 \
         && log_silent "wingman bundle: "${SCRIPT_DIR}/scripts/lib/wingman-bundle.sh" exists but failed to load; offline seeding unavailable"; true; }

# Seed the shared Wingman shelf BEFORE a helm apply, for the reason in
# wingman_bundle_seed_before_helm: `--wait` blocks on pod readiness and on the
# post-install hook, that hook waits for the worker to attach as a Temporal poller,
# and the worker's wait-for-wingman init blocks on an empty shelf. Seeding after the
# apply cannot run in that case -- helm never returns. The claim usually still
# exists, so a rendered manifest is only produced when it has to be re-created
# (after a purge, or a stop that let a deleted claim finalize).
_seed_wingman_before_helm_apply() {
    local ns="${1:-bito-ai-architect}" vf="$2"
    type wingman_bundle_seed_before_helm >/dev/null 2>&1 || return 0
    wingman_bundle_present 2>/dev/null || return 0
    local _rendered=""
    if ! kubectl get pvc "${WINGMAN_BUNDLE_K8S_PVC:-bitoarch-wingman}" -n "$ns" >/dev/null 2>&1; then
        _rendered="$(helm template bitoarch "${SCRIPT_DIR}/helm-bitoarch" --namespace "$ns" ${vf:+--values "$vf"} 2>/dev/null)"
    fi
    wingman_bundle_seed_before_helm "$ns" "$_rendered" bitoarch
}

# Install-mode feature-flag readers (sso_ui_suppressed, auto_generate_mcp_token,
# compact_install_progress, mcp_auto_install_enabled, auto_recovery_enabled).
# Read from env + .env-bitoarch -- install_run persists them for SA; prod
# leaves them unset → verbose legacy behavior.
# shellcheck disable=SC1091
if [ -f "${SCRIPT_DIR}/scripts/lib/bitoarch-config.sh" ]; then
    source "${SCRIPT_DIR}/scripts/lib/bitoarch-config.sh" \
        || echo "WARN: scripts/lib/bitoarch-config.sh failed to load; using legacy output defaults" >&2
fi

# Use path-manager functions for file locations
ENV_FILE="$(get_config_file)"
ENV_LLM_FILE="$(get_llm_config_file)"
LOG_FILE="$(bitoarch_resolve_log_file 2>/dev/null || get_setup_log)"

# Export for background processes (parallel deployment)
export ENV_FILE
export ENV_LLM_FILE
export LOG_FILE
export SCRIPT_DIR
export PLATFORM_DIR

SETUP_IN_PROGRESS=false
SERVICES_WERE_RUNNING=false
DEPLOYMENT_STARTED=false

ENV_GENERATOR="${SCRIPT_DIR}/scripts/env-generator.sh"
if [ ! -f "$ENV_GENERATOR" ]; then
    echo "ERROR: env-generator.sh not found at $ENV_GENERATOR"
    exit 1
fi
source "$ENV_GENERATOR"

# Source other utilities
source "${SCRIPT_DIR}/scripts/setup-utils.sh"
source "${SCRIPT_DIR}/scripts/docker-manager.sh"
# kubernetes-manager.sh is excluded from the Standalone tarball (SA is
# Docker-only by design). Guard the source so SA install doesn't die here;
# every K8s-specific caller (deploy_kubernetes, bitoarch.sh K8s branches)
# is already gated on deployment_type = kubernetes, so the functions
# defined here are never invoked in SA.
if [ -f "${SCRIPT_DIR}/scripts/kubernetes-manager.sh" ]; then
    source "${SCRIPT_DIR}/scripts/kubernetes-manager.sh"
fi
source "${SCRIPT_DIR}/scripts/prerequisites-manager.sh"
source "${SCRIPT_DIR}/scripts/service-manager.sh"
source "${SCRIPT_DIR}/scripts/sql-migration-manager.sh"
source "${SCRIPT_DIR}/scripts/lib/adapters/config-adapter.sh"
source "${SCRIPT_DIR}/scripts/lib/adapters/manager-adapter.sh"
source "${SCRIPT_DIR}/scripts/lib/adapters/tracker-adapter.sh"

# Source config-backup-manager for centralized backup utility
if [ -f "${SCRIPT_DIR}/scripts/lib/config-backup-manager.sh" ]; then
    source "${SCRIPT_DIR}/scripts/lib/config-backup-manager.sh"
fi

# -------------------------------------------------------------------
# Function: get_repo_count_from_config
# Parses .bitoarch-config.yaml and returns the count of configured repos
# -------------------------------------------------------------------
get_repo_count_from_config() {
    # Use path-manager to get actual config file location (standard or legacy)
    local config_file=$(get_repo_config_file)

    if [ ! -f "$config_file" ]; then
        echo "0"
        return 0
    fi

    # Exclude the seeded placeholder so fresh installs don't look reconfigured.
    local repo_count=$(grep -E "^\s*- namespace:" "$config_file" 2>/dev/null \
        | grep -Ev "your-username/your-repo-name" \
        | wc -l | tr -d ' ')
    echo "${repo_count:-0}"
}

ask_llm_config_choice() {
    echo ""
    echo -e "${BLUE}=== LLM Provider Configuration ===${NC}"
    read -r -p "Do you want to configure a custom LLM provider? (y/n): " configure_llm

    if [[ "$configure_llm" =~ ^[Yy]$ ]]; then
        return 0
    fi
    return 1
}

# Insights prompts (ask_git_insights_enabled / ask_ticket_tracker_config /
# ask_docs_config) are defined in scripts/lib/insights-prompts.sh. The CLI
# module (insights-cli.sh) adds env persistence + subcommand handlers and
# sources insights-prompts.sh internally, so a single source covers both.
if [ -f "${SCRIPT_DIR}/scripts/lib/insights-cli.sh" ]; then
    source "${SCRIPT_DIR}/scripts/lib/insights-cli.sh"
elif [ -f "${SCRIPT_DIR}/scripts/lib/insights-prompts.sh" ]; then
    source "${SCRIPT_DIR}/scripts/lib/insights-prompts.sh"
fi

# Source shared LLM configuration functions
if [ -f "${SCRIPT_DIR}/scripts/lib/llm-config.sh" ]; then
    source "${SCRIPT_DIR}/scripts/lib/llm-config.sh"
fi

# Single source of the Bito-hosted LLM notice, shown on both the fresh-install and
# re-install paths when indexing entitlement is active.
print_bito_llm_notice() {
    echo ""
    echo -e "${YELLOW}ℹ Using Bito's LLM keys to index your code. No LLM keys are required from you.${NC}"
}

# BITO-15512: give temporal_user a password on the path that skips the generator.
#
# A true fresh install -- no .env-bitoarch at all -- is fine: generate_env_file
# calls generate_env_with_params (scripts/env-generator.sh), which generates
# TEMPORAL_MYSQL_PASSWORD. This function then no-ops at its guard.
#
# A PRE-EXISTING env file is not fine. generate_env_file returns early on "Using
# existing configuration" without reaching the generator, so an operator who
# copies .env-bitoarch.default into place -- or re-installs over an env derived
# from it -- keeps the template's EMPTY value. That is the path reproduced.
#
# The consequence is a dead install, not a weak secret.
# services/mysql/init/02-create-temporal-user.sh reads the value as
# ${TEMPORAL_MYSQL_PASSWORD:?...}, so on first boot the MySQL entrypoint aborts,
# temporal_user is never created, and temporal crash-loops on "Access denied
# for user 'temporal_user' (using password: NO)". It never reports healthy, the
# bootstrap is skipped, the custom search attributes are never registered, and
# indexing cannot start -- the BITO-15520 symptom, one layer above where that
# ticket traced it.
#
# Called after all env writing, so it sees the final file on either path. It
# fills only an empty value or the CHANGE_THIS_PASSWORD placeholder: an existing
# password is never rotated out from under an initialised MySQL data volume.
ensure_temporal_mysql_password() {
    [ -f "$ENV_FILE" ] || return 0
    grep -qE '^TEMPORAL_MYSQL_PASSWORD=(CHANGE_THIS_PASSWORD)?$' "$ENV_FILE" || return 0

    local pass
    pass=$(generate_secret)
    sed -i.bak "s|^TEMPORAL_MYSQL_PASSWORD=.*|TEMPORAL_MYSQL_PASSWORD=${pass}|" "$ENV_FILE"
    rm -f "${ENV_FILE}.bak"
    log_silent "Generated TEMPORAL_MYSQL_PASSWORD (the template ships it empty)"
}

# BITO-15501: backfill ONPREM_LLM_PROVIDER on the path that skips the generator.
#
# The same gap ensure_temporal_mysql_password closes, for the other key that
# matters on this path. On a fresh install configure_llm_provider exports the
# chosen provider and generate_env_with_params writes it. But when .env-bitoarch
# already exists, generate_env_file returns early ("Using existing
# configuration") and neither runs -- so an operator who pre-places the
# template got a filled MySQL password and an EMPTY provider, and without the
# provider cis-config cannot seed a BYOK row and the entitlement bypass stays
# inert.
#
# Source is LLM_DEFAULT_PROVIDER in .env-llm-bitoarch, the same value the
# provider step already writes there. Only an empty value is filled: an
# operator-set provider is never overwritten.
ensure_onprem_llm_provider() {
    [ -f "$ENV_FILE" ] || return 0
    [ -n "${ENV_LLM_FILE:-}" ] && [ -f "$ENV_LLM_FILE" ] || return 0

    local current
    current=$(grep -E '^ONPREM_LLM_PROVIDER=' "$ENV_FILE" | head -1 | cut -d= -f2-)
    [ -z "$current" ] || return 0

    local provider
    provider=$(grep -E '^LLM_DEFAULT_PROVIDER=' "$ENV_LLM_FILE" | head -1 | cut -d= -f2- | tr -d '"'"'"' ')
    [ -n "$provider" ] || return 0

    set_env_key_value "ONPREM_LLM_PROVIDER" "$provider" "$ENV_FILE"
    rm -f "${ENV_FILE}.bak"
    log_silent "Backfilled ONPREM_LLM_PROVIDER=${provider} from ${ENV_LLM_FILE}"
}

# Reads KEY from FILE (default: the env file), quotes and spaces stripped.
# Empty when absent.
_env_file_value() {
    local file="${2:-$ENV_FILE}"
    [ -f "$file" ] || return 0
    grep -E "^$1=" "$file" | head -1 | cut -d= -f2- | tr -d '"'"'"' '
}

# True when ENTITLEMENT_BYOK_LOCAL_BYPASS_ENABLED is on: an air-gapped deployment
# that runs on the customer's own LLM and has to work without reaching Bito. Off
# by default; the operator turns it on with install.yaml's
# byok_local_bypass_enabled (or the variable itself). An explicit value wins,
# then the env file on a re-run, then the template the env file comes from.
_byok_local_bypass_enabled() {
    local value="${ENTITLEMENT_BYOK_LOCAL_BYPASS_ENABLED:-}" file="$ENV_FILE"
    if [ -z "$value" ]; then
        [ -f "$file" ] || file="${SCRIPT_DIR}/.env-bitoarch.default"
        value=$(_env_file_value ENTITLEMENT_BYOK_LOCAL_BYPASS_ENABLED "$file")
    fi
    [ "$value" = "true" ]
}

# Writes an explicitly set ENTITLEMENT_BYOK_LOCAL_BYPASS_ENABLED into the env
# file, where cis-config reads it. Called after all env writing.
ensure_byok_local_bypass() {
    local value="${ENTITLEMENT_BYOK_LOCAL_BYPASS_ENABLED:-}"
    [ -f "$ENV_FILE" ] && [ -n "$value" ] || return 0
    [ "$(_env_file_value ENTITLEMENT_BYOK_LOCAL_BYPASS_ENABLED)" != "$value" ] || return 0

    set_env_key_value "ENTITLEMENT_BYOK_LOCAL_BYPASS_ENABLED" "$value" "$ENV_FILE"
    rm -f "${ENV_FILE}.bak"
    log_silent "Persisted ENTITLEMENT_BYOK_LOCAL_BYPASS_ENABLED=${value} to ${ENV_FILE}"
}

# Decides BITO_CONNECTIVITY: "online" (the license is fetched and renewed from
# Bito) or "offline" (air-gapped: nothing contacts Bito). A value from
# install.yaml, the environment or the env file wins and must be one of the two.
# Without one, an existing install derives it from the BYOK local bypass, as
# cis-config does, and a fresh install ("ask") asks.
resolve_bito_connectivity() {
    local mode="${1:-derive}" value="${BITO_CONNECTIVITY:-}" from="install.yaml or the environment"
    [ -n "$value" ] || { value=$(_env_file_value BITO_CONNECTIVITY); from="${ENV_FILE}"; }
    case "$value" in
        online|offline) ;;
        "")
            if [ "$mode" = "ask" ]; then
                _ask_bito_connectivity
                return 0
            fi
            if _byok_local_bypass_enabled; then value=offline; else value=online; fi
            ;;
        *)
            print_error "Connectivity '${value}' from ${from} must be online or offline. Fix it and re-run."
            exit 1
            ;;
    esac
    export BITO_CONNECTIVITY="$value"
}

# Asks online (1) or offline (2) without contacting Bito, so an air-gapped
# install makes no connection before it is told it is offline. The words online
# and offline are accepted too. Only the BYOK local bypass suggests an answer
# (offline); otherwise the operator must choose, so Enter never picks a mode.
# AUTO_SETUP, no terminal to ask on (stdin, else the terminal itself for piped
# installs) or EOF takes the suggestion, else online.
_ask_bito_connectivity() {
    local suggested="" answer="" input="" tty="${_BITOARCH_TTY:-/dev/tty}"
    if _byok_local_bypass_enabled; then suggested=offline; fi
    export BITO_CONNECTIVITY="${suggested:-online}"
    [ "${AUTO_SETUP:-}" != "true" ] || return 0
    if [ -t 0 ]; then
        input=/dev/stdin
    elif { : < "$tty"; } 2>/dev/null; then
        input="$tty"
    fi
    [ -n "$input" ] || return 0

    echo ""
    echo "=== Connectivity ==="
    echo "  1) online   this machine can reach Bito: the license is fetched and renewed automatically"
    echo "  2) offline  air-gapped: nothing contacts Bito, and the license key comes from Bito by email"
    # Read the whole loop from one open input: reopening it per answer would
    # replay the first line of a file or pipe forever.
    while true; do
        # EOF with nothing typed keeps the choice above; a last line without a
        # newline is still read.
        read -r -p "Choose [1-2]${suggested:+ (default 2)}: " answer || [ -n "$answer" ] \
            || { print_info "No answer given: using ${BITO_CONNECTIVITY}."; return 0; }
        answer=$(echo "${answer:-$suggested}" | tr '[:upper:]' '[:lower:]')
        case "$answer" in
            1|online) export BITO_CONNECTIVITY=online; return 0 ;;
            2|offline) export BITO_CONNECTIVITY=offline; return 0 ;;
        esac
        print_error "Please choose 1 (online) or 2 (offline)."
    done < "$input"
}

# Writes BITO_CONNECTIVITY into the env file, where cis-config reads it, unless
# it already holds that value. Called after all env writing.
ensure_bito_connectivity() {
    local value="${BITO_CONNECTIVITY:-}"
    [ -f "$ENV_FILE" ] && [ -n "$value" ] || return 0
    [ "$(_env_file_value BITO_CONNECTIVITY)" != "$value" ] || return 0

    set_env_key_value "BITO_CONNECTIVITY" "$value" "$ENV_FILE"
    rm -f "${ENV_FILE}.bak"
    log_silent "Persisted BITO_CONNECTIVITY=${value} to ${ENV_FILE}"
    return 0
}

# True when the install runs without Bito: offline, or the BYOK local bypass on.
# Such an install needs its workspace id locally and runs on its own LLM.
_runs_without_bito() {
    bito_offline || _byok_local_bypass_enabled
}

# On an install that runs without Bito (offline, or the BYOK local bypass on),
# decides BITO_WORKSPACE_ID, which cis-config needs to create its first config
# row without Bito. Required like the API key: a value from the environment,
# install.yaml or the existing env file wins and must be a number; otherwise the
# user is asked -- on stdin when it is a terminal, else on the terminal itself
# (piped stdin) -- and with no terminal to ask on, the install stops.
resolve_bito_workspace_id() {
    _runs_without_bito || return 0
    local id="${BITO_WORKSPACE_ID:-}" from="install.yaml or the environment" input="" tty="${_BITOARCH_TTY:-/dev/tty}"
    [ -n "$id" ] || { id=$(_env_file_value BITO_WORKSPACE_ID); from="${ENV_FILE}"; }

    if [ -n "$id" ] && ! [[ "$id" =~ ^[1-9][0-9]*$ ]]; then
        print_error "Bito workspace ID '${id}' from ${from} is not a number. Fix it and re-run."
        exit 1
    fi
    if [ -z "$id" ]; then
        if [ -t 0 ]; then
            input=/dev/stdin
        elif { : < "$tty"; } 2>/dev/null; then
            input="$tty"
        fi
        if [ -n "$input" ]; then
            echo ""
            print_info "Your Bito workspace ID is needed to run without Bito. Find it at ${BITO_WORKSPACE_ID_URL}"
            while true; do
                read -r -p "Enter your Bito workspace ID: " id || [ -n "$id" ] || break
                [[ "$id" =~ ^[1-9][0-9]*$ ]] && break
                print_error "Workspace ID must be a number. Please try again."
                id=""
            done < "$input"
        fi
        if [ -z "$id" ]; then
            print_error "This install runs without Bito, but no Bito workspace ID is set. Set bito_workspace_id in install.yaml (find it at ${BITO_WORKSPACE_ID_URL}) and re-run."
            exit 1
        fi
    fi
    export BITO_WORKSPACE_ID="$id"
}

# Writes BITO_WORKSPACE_ID into the env file on an install that runs without
# Bito; otherwise cis-config learns the workspace from Bito. Called after all env
# writing, so it covers both the fresh and the existing-env path. Only an empty
# value is filled: an operator-set id is never overwritten.
ensure_bito_workspace_id() {
    _runs_without_bito || return 0
    [ -f "$ENV_FILE" ] && [ -n "${BITO_WORKSPACE_ID:-}" ] || return 0
    [ -z "$(_env_file_value BITO_WORKSPACE_ID)" ] || return 0

    set_env_key_value "BITO_WORKSPACE_ID" "$BITO_WORKSPACE_ID" "$ENV_FILE"
    rm -f "${ENV_FILE}.bak"
    log_silent "Persisted BITO_WORKSPACE_ID=${BITO_WORKSPACE_ID} to ${ENV_FILE}"
}

# The LLM decision for both install paths: returns 0 when Bito's hosted LLM
# applies. On an install that runs without Bito, Bito is not asked -- the
# deployment runs on the customer's own LLM. Otherwise Bito decides.
_uses_bito_llm() {
    _runs_without_bito && return 1
    check_indexing_enabled "$1" "$2" >/dev/null 2>&1
}

generate_env_file() {
    # Source constants for URLs (needed by notice + indexing blocks below)
    if [ -f "${SCRIPT_DIR}/scripts/lib/constants.sh" ]; then
        source "${SCRIPT_DIR}/scripts/lib/constants.sh"
    fi

    if [ -f "$ENV_FILE" ]; then
        # Re-install path: mirror fresh-install section order for visual parity.
        render_security_notice_block
        render_credentials_section_start_block
        print_info "Using existing configuration"
        echo ""

        # Decide the LLM status line from the SAME entitlement check the fresh-install
        # path uses, so re-runs don't falsely claim Bito-hosted LLM for custom-LLM
        # customers who aren't entitled. The old token-inference read the wrong file
        # (.env-bitoarch vs .env-llm-bitoarch) and missed most providers. Reads mirror
        # install-yaml.sh's env reader: head -1 guards a duplicate key, and both quote
        # styles are stripped.
        local _tracking_url _bito_key
        _tracking_url=$(grep -E "^TRACKING_SERVICE_BASE_URL=" "$ENV_FILE" 2>/dev/null | cut -d= -f2- | head -1 | tr -d '"' | tr -d "'")
        [ -z "$_tracking_url" ] && [ -f "${SCRIPT_DIR}/.env-bitoarch.default" ] && \
            _tracking_url=$(grep -E "^TRACKING_SERVICE_BASE_URL=" "${SCRIPT_DIR}/.env-bitoarch.default" 2>/dev/null | cut -d= -f2- | head -1 | tr -d '"' | tr -d "'")
        _bito_key=$(grep -E "^BITO_API_KEY=" "$ENV_FILE" 2>/dev/null | cut -d= -f2- | head -1 | tr -d '"' | tr -d "'")
        resolve_bito_connectivity
        resolve_bito_workspace_id
        if _uses_bito_llm "${_tracking_url}" "${_bito_key:-${BITO_API_KEY:-}}"; then
            print_bito_llm_notice
        else
            # Custom-LLM path only: show cost per MB (these customers pay their provider).
            render_indexing_information_block
            print_info "Using your existing custom LLM configuration."
        fi
        return
    fi

    # Notice is informational; shown on every fresh install regardless of
    # whether the API-key prompt follows.
    render_security_notice_block

    render_credentials_section_start_block

    # Quick-configuration choice: Standard (open the config in an editor and fill
    # it in one pass) vs Guided (the step-by-step prompts below). Rendered here so
    # it appears under the QUICK CONFIGURATION header, on the fresh-install path
    # only. No-op under AUTO_SETUP / non-TTY, or when the mandatory values are
    # already present; anything left blank still falls through to the prompts.
    if command -v _install_maybe_offer_editor >/dev/null 2>&1; then
        # `|| true`: setup.sh runs under `set -e`, so a failing $EDITOR (rc 127,
        # vim :cq, Ctrl+D, …) would otherwise abort the whole install before the
        # editor helper's rc-capture / graceful fallback runs. Suppressing errexit
        # for this call chain preserves the "never hard-fail an interactive
        # install" contract -- the flow degrades to Guided prompts.
        _install_maybe_offer_editor "${BITOARCH_INSTALL_YAML_FILE:-$(get_install_yaml_file 2>/dev/null)}" || true
    fi

    # BITO_API_KEY is required. When pre-set via env (SA install.yaml),
    # skip the prompt header -- no prompt is about to follow.
    local BITO_API_KEY="${BITO_API_KEY:-}"
    if [ -z "$BITO_API_KEY" ]; then
        render_api_key_prompt_header_block
        while [ -z "$BITO_API_KEY" ]; do
            read -s -p "Enter your Bito API Key (input hidden): " BITO_API_KEY
            echo ""
            if [ -z "$BITO_API_KEY" ]; then
                echo -e "${RED}✗ Bito API Key cannot be empty. Please try again.${NC}"
                echo ""
            fi
        done
    fi


    echo ""
    
    # Call tracking endpoint with dummy data after user enters BITO_API_KEY
    # This sends a setup_started event to track the initialization
    local tracking_url=""
    if [ -f "${SCRIPT_DIR}/.env-bitoarch.default" ]; then
        tracking_url=$(grep "^TRACKING_SERVICE_BASE_URL=" "${SCRIPT_DIR}/.env-bitoarch.default" 2>/dev/null | cut -d'=' -f2)
        TRACKING_SERVICE_BASE_URL="$tracking_url"
    fi

    # Online or offline first: an install that turns out offline must not have
    # sent its key or an install event to Bito. The key check below skips itself
    # offline.
    resolve_bito_connectivity ask
    echo ""

    if [[ -n "$tracking_url" ]]; then
        # Build dummy data for tracking
        local tracking_data
        tracking_data=$(cat <<TRACKING_EOF
{
    "deployment_mode": "self_hosted"
}
TRACKING_EOF
        )
        
        # Non-strict install (matches development): fail on invalid key (403)
        # but warn-and-continue when the tracking endpoint is unreachable
        # (air-gapped / locked-down networks). Runtime auth failures surface
        # later via `bitoarch update-api-key` if the key turns out bad.
        if ! validate_and_print_bito_api_key_status "$BITO_API_KEY" "architect_install_started" "$tracking_url" "" "false"; then
            exit 1
        fi
    fi

    # Coding Agent Registration (Standalone HTTPS only). Optional -- registers
    # the local MCP endpoint with installed IDEs. Skipped on Enterprise (http
    # default) and when MCP_USER_EMAIL is pre-filled via install.yaml.
    if [ "${MCP_TRANSPORT:-http}" = "https" ] && [ -z "${MCP_USER_EMAIL:-}" ]; then
        echo -e "${BLUE}=== Coding Agent Registration ===${NC}"
        echo -e "${YELLOW}ℹ Optional - registers MCP with installed coding agents${NC}"
        echo ""
        echo -e "Supported: Claude Code, Cursor, Windsurf, VS Code, Junie. Press Enter to skip."
        echo ""
        read -r -p "Enter email for MCP registration: " MCP_USER_EMAIL
        echo ""
    fi

    # Collect Git Provider (REQUIRED) and Access Token (required unless the
    # provider is local). Skip the "=== Git Integration ===" header +
    # docs-pointer block when both provider AND token are already set (YAML
    # pre-fill in SA). Prompts below only fire when values are missing, so
    # the header is only useful when the user actually has to read it.
    local GIT_PROVIDER="${GIT_PROVIDER:-}"
    local GIT_ACCESS_TOKEN="${GIT_ACCESS_TOKEN:-}"
    local GIT_DOMAIN_URL="${GIT_DOMAIN_URL:-}"
    local GIT_USER="${GIT_USER:-}"
    local GIT_AZURE_ORG="${GIT_AZURE_ORG:-}"
    # GitHub App auth (additive; PAT stays default). Pre-filled from install.yaml
    # via the yaml->env mapping when present. These locals are visible (dynamic
    # scope) to generate_env_with_params, which persists them to .env-bitoarch.
    local GIT_AUTH_TYPE="${GIT_AUTH_TYPE:-}"
    local GIT_APP_ID="${GIT_APP_ID:-}"
    local GIT_INSTALLATION_ID="${GIT_INSTALLATION_ID:-}"
    local GIT_APP_PRIVATE_KEY_B64="${GIT_APP_PRIVATE_KEY_B64:-}"

    if [ -z "$GIT_PROVIDER" ] || [ -z "$GIT_ACCESS_TOKEN" ]; then
        echo -e "${BLUE}=== Git Integration ===${NC}"
        echo -e "${YELLOW}⚠ Select a Git provider to proceed. An access token is required unless you choose Local (pre-cloned repos)${NC}"
        echo ""
        echo -e "See documentation: ${BLUE}${GIT_TOKEN_DOCS_URL:-https://docs.bito.ai/ai-architect/install-ai-architect-self-hosted#git-provider}${NC}"
        echo ""
    fi
    
    # Git Provider selection
    while [ -z "$GIT_PROVIDER" ]; do
        read -p "Select Git provider (1) GitLab  (2) GitHub  (3) Bitbucket  (4) Azure DevOps  (5) Local (pre-cloned repos)  [1-5]: " git_choice

        case $git_choice in
            1) GIT_PROVIDER="gitlab" ;;
            2) GIT_PROVIDER="github" ;;
            3) GIT_PROVIDER="bitbucket" ;;
            4) GIT_PROVIDER="azure-devops" ;;
            5) GIT_PROVIDER="local" ;;
            *)
                echo -e "${RED}✗${NC} Invalid choice. Please select 1-5"
                ;;
        esac
    done

    # Enterprise / domain FIRST (before the auth-method choice) so a GitHub App
    # validation on GitHub Enterprise targets the right API base. Skipped for Azure
    # DevOps (it carries an organization instead), for the local provider (no
    # remote at all), and when a token is pre-filled.
    if [ -z "$GIT_ACCESS_TOKEN" ]; then
        if [[ "$GIT_PROVIDER" != "azure-devops" && "$GIT_PROVIDER" != "local" ]]; then
            echo ""
            read -r -p "Is this an enterprise version of $GIT_PROVIDER (e.g., https://my.company.com)? (y/N):" is_enterprise
            if [[ "$is_enterprise" =~ ^[Yy]$ ]]; then
                while [ -z "$GIT_DOMAIN_URL" ]; do
                    read -r -p "Enter domain for enterprise $GIT_PROVIDER: " GIT_DOMAIN_URL
                    if [ -z "$GIT_DOMAIN_URL" ]; then
                        echo -e "${RED}✗${NC} Git domain is required for enterprise"
                    fi
                done
            fi
        fi
    fi

    # GitHub App vs Personal Access Token (github only; other providers -> PAT).
    # No-op for non-github, an explicit auth_type, a pre-filled PAT, or non-TTY;
    # emits its own leading blank line only when it actually prompts.
    prompt_git_auth_method

    # Azure DevOps cloud needs the org regardless of whether the token was
    # pre-supplied (the org forms the clone/API URL root), so collect it outside
    # the token gate — otherwise a YAML/standalone pre-fill with a token but no
    # org yields a broken clone URL. With no terminal (auto/non-interactive
    # install) there is no way to prompt, so fail fast with a clear message
    # instead of looping on EOF.
    if azure_org_needed "$GIT_PROVIDER" "$GIT_AZURE_ORG"; then
        echo ""
        if [ -t 0 ]; then
            collect_azure_org
        else
            echo -e "${RED}✗${NC} azure-devops requires an organization. Set git.organization (e.g. myorg) for non-interactive installs." >&2
            exit 1
        fi
    fi

    if [ -z "$GIT_ACCESS_TOKEN" ]; then
        if [[ "$GIT_PROVIDER" == "bitbucket" ]]; then
            echo ""
            echo -e "🛠 Configuring user authentication..."

            if [[ -z "$GIT_DOMAIN_URL" ]]; then
                # No domain → ask for email
                while [[ -z "$GIT_USER" ]]; do
                    read -r -p "Enter your Bitbucket account email: " GIT_USER
                    [[ -z "$GIT_USER" ]] && echo "⚠ Email is required. Please try again."
                done
            else
                # Domain exists → ask for username
                while [[ -z "$GIT_USER" ]]; do
                    read -r -p "Enter your Bitbucket username: " GIT_USER
                    [[ -z "$GIT_USER" ]] && echo "⚠ Username is required. Please try again."
                done
            fi

            echo -e "✅ Bitbucket user set: $GIT_USER"
        fi
    fi


    
    if [ "${GIT_AUTH_TYPE:-}" = "app" ]; then
        # GitHub App: collect App ID / Installation ID / .pem path (a fresh install
        # requires a key). No PAT token in App mode. The .pem is base64-encoded and
        # never echoed (fingerprint only).
        echo ""
        echo -e "🛠 Configuring GitHub App authentication..."
        collect_github_app_credentials fresh || { print_error "GitHub App setup incomplete."; exit 1; }
        GIT_ACCESS_TOKEN=""
    elif [ "$GIT_PROVIDER" = "local" ]; then
        # Local provider: credential-less by design. Repositories are copied in
        # after installation with 'bitoarch import-repos <path>'.
        GIT_ACCESS_TOKEN=""
        echo ""
        print_info "No git credentials needed. After installation, import your pre-cloned repositories with: bitoarch import-repos <path>"
    else
        # Git Access Token input (Personal Access Token). The post-read echo
        # terminates the hidden-input line — emitted only when we actually prompted,
        # so a YAML-prefilled token doesn't print a stray blank line before the status.
        while [ -z "$GIT_ACCESS_TOKEN" ]; do
            echo ""
            read -s -p "Enter Git access token (input hidden): " GIT_ACCESS_TOKEN
            echo ""
            if [ -z "$GIT_ACCESS_TOKEN" ]; then
                echo -e "${RED}✗${NC} Git access token is required"
            fi
        done
    fi

    print_info "Git provider configured (${GIT_PROVIDER})"

    # Send git integration tracking event
    # Determine if this is enterprise based on user response
    local is_enterprise_bool="false"
    if [[ "$is_enterprise" =~ ^[Yy]$ ]]; then
        is_enterprise_bool="true"
    fi

    # Call tracking with git integration event
    send_git_integration_tracking "$GIT_PROVIDER" "$is_enterprise_bool" "$GIT_DOMAIN_URL"

    # Insights features (optional). Each helper is a no-op when its primary env
    # var is already set (install.yaml pre-fill or upgrade). Defaults to disabled
    # so silent installs and pre-existing customers see no behaviour change.
    # Hook defined in install.sh; delegates to ask_git_insights_enabled et al.
    _install_collect_insights_prompts

    local tracking_url=""
    if [ -f "${SCRIPT_DIR}/.env-bitoarch.default" ]; then
        tracking_url=$(grep "^TRACKING_SERVICE_BASE_URL=" "${SCRIPT_DIR}/.env-bitoarch.default" 2>/dev/null | cut -d'=' -f2)
    fi

    local custom_llm_configured=false
    # Bito-hosted LLM takes precedence when indexing is enabled; else fall
    # back to yaml-preset tokens or interactive prompt via configure_llm_provider.
    # With the BYOK local bypass on, Bito is not asked and the workspace id is
    # settled first (see resolve_bito_workspace_id).
    # The indexing-information block (cost per MB) is shown only on the custom-LLM
    # path -- Bito-hosted-LLM customers don't pay a provider directly.
    resolve_bito_workspace_id
    if _uses_bito_llm "${tracking_url}" "${BITO_API_KEY}"; then
        print_bito_llm_notice
    else
        render_indexing_information_block
        configure_llm_provider
        custom_llm_configured=true
    fi
    # env-generator.sh gates the "generated" banner on the same flag.
    export CUSTOM_LLM_CONFIGURED="$custom_llm_configured"

    if [[ "${AUTO_SETUP:-}" == "true" ]]; then
        print_info "Auto-setup mode: using defaults with secure generated passwords"
    elif [ "$custom_llm_configured" = "true" ]; then
        echo ""
        echo -e "${BLUE}${BOLD}⚡ Quick Configuration${NC}"
        echo "  Using defaults (recommended for quick setup)"
        echo ""
    fi

    DB_ROOT_PASS=$(generate_secret)
    DB_USER_PASS=$(generate_secret)
    JWT_SECRET=$(generate_secret)
    CIS_MANAGER_API_KEY=$(generate_secret)
    CIS_CONFIG_API_KEY=$(generate_secret)
    CIS_PROVIDER_API_KEY=$(generate_secret)
    SECRETS_ENCRYPTION_KEY=$(generate_encryption_key)
    
    # Read ONLY port defaults from .env-bitoarch.default if it exists (don't overwrite user inputs!)
    if [ -f "${SCRIPT_DIR}/.env-bitoarch.default" ]; then
        log_silent "Reading default port configuration from .env-bitoarch.default"
        # Extract only port variables using grep
        local temp_provider_port=$(grep "^CIS_PROVIDER_EXTERNAL_PORT=" "${SCRIPT_DIR}/.env-bitoarch.default" 2>/dev/null | cut -d'=' -f2 || echo "8080")
        local temp_manager_port=$(grep "^CIS_MANAGER_EXTERNAL_PORT=" "${SCRIPT_DIR}/.env-bitoarch.default" 2>/dev/null | cut -d'=' -f2 || echo "9090")
        local temp_config_port=$(grep "^CIS_CONFIG_EXTERNAL_PORT=" "${SCRIPT_DIR}/.env-bitoarch.default" 2>/dev/null | cut -d'=' -f2 || echo "8081")
        local temp_mysql_port=$(grep "^MYSQL_EXTERNAL_PORT=" "${SCRIPT_DIR}/.env-bitoarch.default" 2>/dev/null | cut -d'=' -f2 || echo "3306")
        local temp_tracker_port=$(grep "^CIS_TRACKER_EXTERNAL_PORT=" "${SCRIPT_DIR}/.env-bitoarch.default" 2>/dev/null | cut -d'=' -f2 || echo "9090")

        # Only use if not empty
        [ -n "$temp_provider_port" ] && CIS_PROVIDER_EXTERNAL_PORT="$temp_provider_port"
        [ -n "$temp_manager_port" ] && CIS_MANAGER_EXTERNAL_PORT="$temp_manager_port"
        [ -n "$temp_config_port" ] && CIS_CONFIG_EXTERNAL_PORT="$temp_config_port"
        [ -n "$temp_mysql_port" ] && MYSQL_EXTERNAL_PORT="$temp_mysql_port"
        [ -n "$temp_tracker_port" ] && CIS_TRACKER_EXTERNAL_PORT="$temp_tracker_port"
    fi
    
    # Load service versions from versions/service-versions.json (single source of truth)
    local versions_file="${SCRIPT_DIR}/versions/service-versions.json"
    if [ -f "$versions_file" ]; then
        if command -v jq >/dev/null 2>&1; then
            CIS_CONFIG_VERSION=$(jq -r '.services."cis-config".version' "$versions_file" 2>/dev/null || echo "latest")
            CIS_MANAGER_VERSION=$(jq -r '.services."cis-manager".version' "$versions_file" 2>/dev/null || echo "latest")
            CIS_PROVIDER_VERSION=$(jq -r '.services."cis-provider".version' "$versions_file" 2>/dev/null || echo "latest")
            CIS_TRACKER_VERSION=$(jq -r '.services."cis-tracker".version' "$versions_file" 2>/dev/null || echo "latest")
            TEMPORAL_VERSION=$(jq -r '.services."temporal".version' "$versions_file" 2>/dev/null || echo "latest")
            CIS_WORKER_VERSION=$(jq -r '.services."cis-worker".version' "$versions_file" 2>/dev/null || echo "latest")
        else
            # Fallback parsing without jq
            CIS_CONFIG_VERSION=$(grep -A 10 '"cis-config"' "$versions_file" | grep '"version"' | head -1 | cut -d'"' -f4 || echo "latest")
            CIS_MANAGER_VERSION=$(grep -A 10 '"cis-manager"' "$versions_file" | grep '"version"' | head -1 | cut -d'"' -f4 || echo "latest")
            CIS_PROVIDER_VERSION=$(grep -A 10 '"cis-provider"' "$versions_file" | grep '"version"' | head -1 | cut -d'"' -f4 || echo "latest")
            CIS_TRACKER_VERSION=$(grep -A 10 '"cis-tracker"' "$versions_file" | grep '"version"' | head -1 | cut -d'"' -f4 || echo "latest")
            TEMPORAL_VERSION=$(grep -A 10 '"temporal"' "$versions_file" | grep '"version"' | head -1 | cut -d'"' -f4 || echo "latest")
            CIS_WORKER_VERSION=$(grep -A 10 '"cis-worker"' "$versions_file" | grep '"version"' | head -1 | cut -d'"' -f4 || echo "latest")
        fi
        log_silent "Service versions loaded from $versions_file"
        log_silent "  AI Architect Config: $CIS_CONFIG_VERSION"
        log_silent "  AI Architect Manager: $CIS_MANAGER_VERSION"
        log_silent "  AI Architect Provider: $CIS_PROVIDER_VERSION"
        log_silent "  AI Architect Tracker: $CIS_TRACKER_VERSION"
        log_silent "  AI Architect Worker: $CIS_WORKER_VERSION"

    else
        print_warning "versions/service-versions.json not found, using 'latest' tags"
        CIS_CONFIG_VERSION="latest"
        CIS_MANAGER_VERSION="latest"
        CIS_PROVIDER_VERSION="latest"
        CIS_TRACKER_VERSION="latest"
    fi
    
    # Auto-generate the MCP access token silently. Power users can pre-seed
    # BITO_MCP_ACCESS_TOKEN in the environment (or .env-bitoarch) to supply
    # a custom token -- it will be respected if already set.
    if [ -z "${BITO_MCP_ACCESS_TOKEN:-}" ]; then
        BITO_MCP_ACCESS_TOKEN=$(generate_secret)
    fi


    
    # Use external ports from .env-bitoarch.default if available, otherwise use defaults
    CIS_PROVIDER_EXTERNAL_PORT=${CIS_PROVIDER_EXTERNAL_PORT:-8080}
    CIS_MANAGER_EXTERNAL_PORT=${CIS_MANAGER_EXTERNAL_PORT:-9090}
    CIS_CONFIG_EXTERNAL_PORT=${CIS_CONFIG_EXTERNAL_PORT:-8081}
    MYSQL_EXTERNAL_PORT=${MYSQL_EXTERNAL_PORT:-3306}
    CIS_TRACKER_EXTERNAL_PORT=${CIS_TRACKER_EXTERNAL_PORT:-9920}
    
    log_silent "Using port configurations: Provider:$CIS_PROVIDER_EXTERNAL_PORT Manager:$CIS_MANAGER_EXTERNAL_PORT Config:$CIS_CONFIG_EXTERNAL_PORT MySQL:$MYSQL_EXTERNAL_PORT Tracker:$CIS_TRACKER_EXTERNAL_PORT"
    log_silent "Secure passwords and tokens: auto-generated"
    
    prompt_mcp_tls_setup

    log_silent "Generating .env-bitoarch from template (.env-bitoarch.default)..."
    
    # Call env-generator function with all collected parameters
    generate_env_with_params "$ENV_FILE" \
        "$BITO_API_KEY" "$DB_ROOT_PASS" "$DB_USER_PASS" "$JWT_SECRET" \
        "$CIS_MANAGER_API_KEY" "$CIS_CONFIG_API_KEY" "$CIS_PROVIDER_API_KEY" \
        "$BITO_MCP_ACCESS_TOKEN" "$SECRETS_ENCRYPTION_KEY" \
        "$CIS_CONFIG_VERSION" "$CIS_MANAGER_VERSION" "$CIS_PROVIDER_VERSION" \
        "$CIS_PROVIDER_EXTERNAL_PORT" "$CIS_MANAGER_EXTERNAL_PORT" "$CIS_CONFIG_EXTERNAL_PORT" "$MYSQL_EXTERNAL_PORT" \
        "$GIT_PROVIDER" "$GIT_ACCESS_TOKEN" "$GIT_DOMAIN_URL" "$GIT_USER" "$CIS_TRACKER_EXTERNAL_PORT" "$CIS_TRACKER_VERSION" "$GIT_AZURE_ORG"
    
    [ $? -ne 0 ] && return 1

    log_silent "Env file created: $ENV_FILE"

    # Standalone install: collect email + flip MCP transport/auto-install
    # in .env-bitoarch so the cert + coding-agent flow opt in. Enterprise
    # (SKIP_SSO_PROMPT unset) keeps template defaults (http / false / "").
    if [ "${SKIP_SSO_PROMPT:-false}" = "true" ]; then
        if [ -n "${MCP_USER_EMAIL:-}" ] && \
           ! [[ "$MCP_USER_EMAIL" =~ ^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$ ]]; then
            print_warning "Invalid email '${MCP_USER_EMAIL}'; auto-registration disabled."
            MCP_USER_EMAIL=""
        fi
        : "${MCP_TRANSPORT:=https}"
        : "${MCP_AUTO_INSTALL:=true}"
        sed -i.bak \
            -e "s|^MCP_TRANSPORT=.*|MCP_TRANSPORT=${MCP_TRANSPORT}|" \
            -e "s|^MCP_AUTO_INSTALL=.*|MCP_AUTO_INSTALL=${MCP_AUTO_INSTALL}|" \
            -e "s|^MCP_USER_EMAIL=.*|MCP_USER_EMAIL=${MCP_USER_EMAIL}|" \
            "$ENV_FILE" 2>>"${LOG_FILE:-/dev/null}" && rm -f "${ENV_FILE}.bak" \
            || log_silent "Failed to persist MCP_* settings to $ENV_FILE"
        export MCP_TRANSPORT MCP_AUTO_INSTALL MCP_USER_EMAIL
    elif [ -n "${MCP_TLS_CERT_FILE:-}" ]; then
        # Kubernetes keeps the provider on HTTP (the ingress does TLS).
        _tls_transport="https"
        [ "${DEPLOYMENT_METHOD:-}" = "kubernetes" ] && _tls_transport="http"
        grep -q '^BITOARCH_INGRESS_HOST=' "$ENV_FILE" 2>/dev/null \
            || printf 'BITOARCH_INGRESS_HOST=\n' >> "$ENV_FILE"
        grep -q '^MCP_TLS_HOST=' "$ENV_FILE" 2>/dev/null \
            || printf 'MCP_TLS_HOST=\n' >> "$ENV_FILE"
        sed -i.bak \
            -e "s|^MCP_TRANSPORT=.*|MCP_TRANSPORT=${_tls_transport}|" \
            -e "s|^MCP_TLS_CERT_FILE=.*|MCP_TLS_CERT_FILE=${MCP_TLS_CERT_FILE}|" \
            -e "s|^MCP_TLS_KEY_FILE=.*|MCP_TLS_KEY_FILE=${MCP_TLS_KEY_FILE}|" \
            -e "s|^BITOARCH_INGRESS_HOST=.*|BITOARCH_INGRESS_HOST=${BITOARCH_INGRESS_HOST:-}|" \
            -e "s|^MCP_TLS_HOST=.*|MCP_TLS_HOST=${MCP_TLS_HOST:-${BITOARCH_INGRESS_HOST:-}}|" \
            "$ENV_FILE" && rm -f "${ENV_FILE}.bak" \
            || { export _BITOARCH_INSTALL_CLOSED=1; print_error "Could not save the MCP certificate settings to $ENV_FILE"; exit 1; }
    fi

    # Persist INSIGHTS_* values into .env-bitoarch (no-op when feature disabled
    # since template defaults are already empty).
    _install_persist_insights_env "$ENV_FILE"
}

prepare_data_directories() {
    log_silent "Preparing all service directories with proper permissions..."
    
    # Source .env to get directory paths if file exists
    if [ -f "$ENV_FILE" ]; then
        source "$ENV_FILE"
    fi
    
    # Get config directory from path-manager (handles standard vs legacy paths)
    local config_dir="$(get_config_dir)"

    # Ensure config directory exists and is writable
    mkdir -p "$config_dir" 2>/dev/null || {
        if command -v sudo >/dev/null 2>&1; then
            sudo mkdir -p "$config_dir"
            sudo chown -R "$USER:$(id -gn)" "$config_dir"
        fi
    }

    # Get log directory from path-manager (handles standard vs legacy paths)
    local log_dir="$(get_log_dir)"

    # Ensure log directory exists and is writable
    mkdir -p "$log_dir" 2>/dev/null || {
        if command -v sudo >/dev/null 2>&1; then
            sudo mkdir -p "$log_dir"
            sudo chown -R "$USER:$(id -gn)" "$log_dir"
        fi
    }

    # Create service-specific log directories
    create_log_dirs

    # Define all directories that need full permissions for containers
    local directories=(
        "${SCRIPT_DIR}/${HOST_DATA_DIR:-services/cis-provider/data}"
        "$log_dir"
        "${SCRIPT_DIR}/${HOST_PROVIDER_METADATA_DIR:-services/cis-provider/metadata}"
    )
    
    local failed_dirs=()
    local success_count=0
    
    # Create and set permissions for each directory
    for dir in "${directories[@]}"; do
        # Create directory if it doesn't exist
        mkdir -p "$dir" 2>/dev/null
        
        # Absolute modes, not relative ones: a relative "g+w,o-w" on a directory
        # created under umask 077 yields drwx-w---- — write without execute, so
        # the account cannot even traverse it. 0755 states the intent outright.
        #
        # Ownership is best-effort: the chown needs root. A failure goes to setup.log
        # only -- no container writes these (the services log to Docker), so it is not
        # a failure of this directory. The mode pass below runs regardless.
        chown -R "$(resolve_service_uid)" "$dir" 2>/dev/null \
            || log_silent "Could not set owner $(resolve_service_uid) on $dir (needs root); left with the installing account"

        # Each pass is independent and non-fatal. find -exec ... + returns non-zero
        # if any single invocation fails, so chaining these with && would let one
        # unchmod-able file abort the whole installer.
        find "$dir" -type d -exec chmod 0755 {} + 2>/dev/null || mode_failed=1
        find "$dir" -type f -exec chmod go-w {} + 2>/dev/null || mode_failed=1

        if [ "${mode_failed:-0}" -eq 0 ]; then
            success_count=$((success_count + 1))
            log_silent "Set owner-writable, non-world-writable permissions on $dir"
        else
            mode_failed=0
            failed_dirs+=("$dir")
        fi
    done
    
    # Report results
    if [ ${#failed_dirs[@]} -eq 0 ]; then
        log_silent "Set owner-writable, non-world-writable permissions on all service directories (${success_count}/${#directories[@]})"
    else
        # Warn, do not fail. These directories are pre-existing state the operator
        # may not own (a prior sudo install is the common case); aborting here would
        # turn a fixable permission warning into a failed install.
        print_warning "Could not fully set permissions on ${#failed_dirs[@]} directories:"
        for dir in "${failed_dirs[@]}"; do
            echo "  - $dir"
        done
        print_warning "If a service reports a permission error, run: sudo chown -R $(resolve_service_uid) ${failed_dirs[*]}"
    fi
    
    log_silent "All service directories prepared with proper permissions"
}

prepare_service_sql_scripts() {
    log_silent "Preparing service SQL scripts for MySQL initialization..."
    
    local mysql_init_dir="${SCRIPT_DIR}/services/mysql/init"
    local scripts_copied=0
    
    # Copy cis-config SQL scripts (numbered 02-* to run after 00 and 01)
    local config_sql_dir="${SCRIPT_DIR}/services/cis-config/resources/sql"
    if [ -d "$config_sql_dir" ]; then
        for sql_file in "$config_sql_dir"/*.sql; do
            if [ -f "$sql_file" ]; then
                local filename=$(basename "$sql_file")
                local dest_file="${mysql_init_dir}/02-cis-config-${filename}"
                cp "$sql_file" "$dest_file"
                # Force a readable mode so MySQL init can read the scripts
                # regardless of the invoking shell's umask (e.g. 0077).
                chmod 644 "$dest_file"
                scripts_copied=$((scripts_copied + 1))
                log_silent "Copied: $filename -> 02-cis-config-${filename}"
            fi
        done
    fi
    
    # Copy cis-manager SQL scripts (database.sql first with 03-, others with 04-)
    local manager_sql_dir="${SCRIPT_DIR}/services/cis-manager/resources"
    if [ -d "$manager_sql_dir" ]; then
        # Handle database.sql separately with 03- prefix (must run first)
        if [ -f "$manager_sql_dir/database.sql" ]; then
            cp "$manager_sql_dir/database.sql" "${mysql_init_dir}/03-cis-manager-database.sql"
            chmod 644 "${mysql_init_dir}/03-cis-manager-database.sql"
            scripts_copied=$((scripts_copied + 1))
            log_silent "Copied: database.sql -> 03-cis-manager-database.sql"
        fi

        # Copy all other SQL files with 04- prefix (run after database.sql)
        for sql_file in "$manager_sql_dir"/*.sql; do
            if [ -f "$sql_file" ]; then
                local filename=$(basename "$sql_file")
                # Skip database.sql as it's already handled above
                if [ "$filename" != "database.sql" ]; then
                    local dest_file="${mysql_init_dir}/04-cis-manager-${filename}"
                    cp "$sql_file" "$dest_file"
                    chmod 644 "$dest_file"
                    scripts_copied=$((scripts_copied + 1))
                    log_silent "Copied: $filename -> 04-cis-manager-${filename}"
                fi
            fi
        done
    fi
    
    if [ $scripts_copied -gt 0 ]; then
        log_silent "Prepared $scripts_copied SQL script(s) for MySQL initialization"
        log_silent "SQL scripts will execute in order: 00-*, 01-*, 02-*, 03-*, 04-*"
    else
        log_silent "No service SQL scripts found to prepare"
    fi
    
    return 0
}


ask_repo_setup_mode() {
    local choice_normalized=""
    local tracking_url=""
    if [ -f "${SCRIPT_DIR}/.env-bitoarch.default" ]; then
        tracking_url=$(grep "^TRACKING_SERVICE_BASE_URL=" "${SCRIPT_DIR}/.env-bitoarch.default" 2>/dev/null | cut -d'=' -f2)
    fi
    # AUTO_SETUP=true: skip the prompt and default to "auto" mode. Used by the
    # Standalone install bootstrap (--auto flag) and any CI/automation caller.
    if [[ "${AUTO_SETUP:-}" == "true" ]]; then
        choice="auto"
    fi
    while true; do
        if [[ "${AUTO_SETUP:-}" != "true" ]]; then
            echo ""
            # Piped installs (curl | bash) leave stdin non-TTY: read the choice from the
            # terminal instead; with no terminal at all, default to auto (AUTO_SETUP contract)
            # rather than looping "Invalid choice" on an unreadable stdin.
            if [ -t 0 ]; then
                read -r -p "Choose setup mode (auto/manual): " choice
            elif [ -r /dev/tty ] && [ -w /dev/tty ]; then
                read -r -p "Choose setup mode (auto/manual): " choice < /dev/tty || choice="auto"
            else
                choice="auto"
            fi
        fi

        # Normalize: convert input to lowercase
        choice_normalized=$(echo "$choice" | tr '[:upper:]' '[:lower:]')

        case "$choice_normalized" in
            auto|a)
                SETUP_MODE="auto"
                echo ""
                print_info "⚙️  Auto mode selected. Saving configuration..."
                echo ""

                if [ -f "$ENV_LLM_FILE" ]; then
                    source "$ENV_LLM_FILE"
                fi

                config_repo_add_from_file_from_setup ".bitoarch-config.yaml"
                if [ $? -ne 0 ]; then
                    print_error "Failed to save configuration automatically."
                    render_manual_repo_config_block
                    SETUP_MODE="failed"
                    return 0
                fi

                print_status "Configuration saved successfully!"
                echo ""

                # Push insights features that the prompts captured. Base config
                # row exists now (created by config_repo_add_from_file_from_setup
                # above), so the cis-config single-tenant insights endpoints
                # will accept these PUTs.
                _install_push_insights_config

                # Send tracking event for auto mode

                send_deployment_tracking "auto" "configuration_saved" ""

                manager_sync_simple
                echo ""
                return 0
                ;;

            manual|m)
                SETUP_MODE="manual"
                echo ""
                echo -e "🧩 Manual configuration selected."
                echo ""

                # Send tracking event for manual mode

                send_deployment_tracking "manual" "manual_setup_started" ""

                render_manual_config_instructions_block

                echo ""
                return 0
                ;;

            *)
                print_error "Invalid choice. Please type 'auto' or 'manual'."
                echo ""
                ;;
        esac
    done
}

setup_configuration() {
    # Load environment variables from .env-bitoarch if it exists
    # This is needed to fetch Git provider credentials (GIT_PROVIDER, GIT_ACCESS_TOKEN, BITO_API_KEY)
    if [ -f "$ENV_FILE" ]; then
        source "$ENV_FILE"
    fi

    # On k8s, open the config port-forward on demand before any config API call.
    command -v ensure_config_service_accessible >/dev/null 2>&1 && ensure_config_service_accessible

    # Check if we should skip repo reconfiguration
    local repo_count=$(get_repo_count_from_config)
    
    # Only ask if config already exists with repos
    if [ "$repo_count" -gt 0 ] && ! render_repo_reconfiguration_prompt_block "$repo_count"; then
        # Return 2 to indicate config was skipped (user said no)
        return 2
    fi

    
    # Local provider: no remote to enumerate. Save the configuration with an
    # empty repo list now (git integration + LLM + scheduler); repositories are
    # imported and registered afterwards with 'bitoarch import-repos'.
    if [ "${GIT_PROVIDER:-}" = "local" ]; then
        local local_cfg_file
        if type get_repo_config_file >/dev/null 2>&1; then
            local_cfg_file=$(get_repo_config_file)
        else
            local_cfg_file=".bitoarch-config.yaml"
        fi
        # This is the LIVE repos file that import-repos registers into; only
        # seed it when it holds no repos yet -- reconfiguring on a restart must
        # not wipe previously imported namespaces (import can't restore them:
        # unchanged repos are skipped by the same-HEAD check).
        if [ ! -f "$local_cfg_file" ] || ! grep -q 'namespace:' "$local_cfg_file" 2>/dev/null; then
            printf "repository:\n  configured_repos: []\n" > "$local_cfg_file"
        fi

        if [ -f "$ENV_LLM_FILE" ]; then
            source "$ENV_LLM_FILE"
        fi
        # `if !` keeps the failure branch reachable under `set -e` (a bare call
        # would exit the script before the check on restart paths).
        if ! config_repo_add_from_file_from_setup "$local_cfg_file"; then
            print_error "Failed to save configuration."
            render_manual_repo_config_block
            SETUP_MODE="failed"
            return 0
        fi
        SETUP_MODE="auto"
        print_status "Configuration saved!"
        _install_push_insights_config
        send_deployment_tracking "auto" "configuration_saved" ""
        echo ""
        print_info "Import your pre-cloned repositories with: ${YELLOW}bitoarch import-repos <path>${NC}"
        echo ""
        return 0
    fi

    # Proceed with configuration
    echo ""
    echo -e "⏳ Fetching repository list from your git provider (30-50s)..."

    # Start loader in background
#    show_loader "Fetching repository metadata"

    # Export deployment type for API calls
    export DEPLOYMENT_TYPE=$(get_deployment_type)

    create_repo_config_from_api
    load_cfg_exit_code=$?

    if [ $load_cfg_exit_code -ne 0 ]; then
        print_error "Failed to fetch repository information."
        render_manual_repo_config_block
        SETUP_MODE="failed"
        return 0
    fi


    echo ""
    # -------------------------------
    # 3. Ask user for auto/manual setup
    # -------------------------------

    render_repo_config_choice_block
    ask_repo_setup_mode

}

# True when the license API says this install has no usable license and
# enforcement is on; sets LICENSE_STATE / LICENSE_REASON for the message. Usable
# means a key in a usable state (valid, expiring, grace) that also covers AI
# Architect: is_ai_architect_enabled alone does not fold in the state, so a
# clock_invalid key would otherwise pass. With "wait" (a fresh install only), an
# online install first waits up to BITOARCH_LICENSE_WAIT_SECONDS (default 120,
# wall clock) for Bito to issue its first key. A cis-config without the license
# API (404), one that does not answer, or one that does not enforce never blocks.
_license_blocks_setup() {   # [wait]
    LICENSE_STATE=""; LICENSE_REASON=""; LICENSE_VIEW=""
    command -v config_fetch_license >/dev/null 2>&1 || return 1
    local body st start=$SECONDS wait_max="${BITOARCH_LICENSE_WAIT_SECONDS:-120}" step=5 wait=false announced=false
    if [ "${1:-}" = "wait" ] && ! bito_offline; then wait=true; fi
    while true; do
        body=$(config_fetch_license 2>/dev/null) || return 1
        [ "$(printf '%s' "$body" | jq -r '.enforced // false' 2>/dev/null)" = "true" ] || return 1
        st=$(printf '%s' "$body" | jq -r '.state // empty' 2>/dev/null)
        case "$st" in
            valid|expiring|grace)
                [ "$(printf '%s' "$body" | jq -r '.is_ai_architect_enabled // false' 2>/dev/null)" != "true" ] || return 1 ;;
        esac
        LICENSE_VIEW="$body"
        LICENSE_STATE="$st"
        LICENSE_REASON=$(printf '%s' "$body" | jq -r '[.clock_invalid_reason, .reason, .last_renew_error] | map(select(. != null and . != "")) | first // empty' 2>/dev/null)
        if [ "$wait" = true ] && [ $((SECONDS - start)) -lt "$wait_max" ]; then
            [ "$announced" = true ] || { echo -e "⏳ Waiting for this install's license from Bito (up to ${wait_max}s)..."; announced=true; }
            sleep "$step"
            continue
        fi
        log_silent "Repository setup deferred: license state=${LICENSE_STATE:-?} reason=${LICENSE_REASON:-none}"
        return 0
    done
}

# The license-needed block, then the activation code built from the view the
# gate just read (no second request).
_render_license_required() {
    render_license_required_block "$LICENSE_STATE" "$LICENSE_REASON"
    if source "${SCRIPT_DIR}/scripts/lib/license-cli.sh" 2>/dev/null; then
        license_print_request "$LICENSE_VIEW" 2>/dev/null || true
    fi
}

# Repository setup, unless the license blocks it: then the steps that need a
# license are left for 'bitoarch setup --resume' (SETUP_MODE=manual keeps the
# SSO prompt and plugin deploys quiet) and the operator is told how to get a key.
# Otherwise setup_configuration's own return code passes through unchanged.
# "wait" (a fresh install only) lets an online install wait for its first key.
_setup_configuration_or_defer() {   # [wait]
    if _license_blocks_setup "${1:-}"; then
        SETUP_MODE="manual"
        _render_license_required
        return 0
    fi
    setup_configuration
}

# setup.sh --resume: finishes what an install without a usable license left
# out, once a key is installed -- the repository setup (the first saved
# configuration carries the git settings), then the plugins declared in
# install.yaml. Returns 1 when not installed or still not licensed.
resume_setup() {
    if [ ! -f "$ENV_FILE" ]; then
        print_error "AI Architect is not installed: ${ENV_FILE} not found"
        return 1
    fi
    setup_env_for_config
    if _license_blocks_setup; then
        _render_license_required
        return 1
    fi
    local result=0
    setup_configuration || result=$?
    # 2 = the operator kept an existing repository configuration.
    [ "$result" -ne 2 ] || return 0
    if [ -f "${SCRIPT_DIR}/scripts/lib/plugin/preseed.sh" ]; then
        # shellcheck disable=SC1091
        . "${SCRIPT_DIR}/scripts/lib/plugin/preseed.sh" 2>/dev/null || true
    fi
    if command -v plugin_setup_phase >/dev/null 2>&1; then
        plugin_setup_phase "$(get_install_yaml_file)" "${SETUP_MODE:-}" || true
    fi
    return 0
}

display_success() {
    source "$ENV_FILE"
    # A proper closing was shown -> the installer's EXIT trap must stay quiet.
    export _BITOARCH_INSTALL_CLOSED=1
    # Use block-level render function
    local mcp_url
    mcp_url="$(mcp_public_url)"
    [ -n "$mcp_url" ] || mcp_url="${MCP_TRANSPORT:-http}://$(mcp_url_host):$CIS_PROVIDER_EXTERNAL_PORT/mcp"
    render_deploy_success_block \
        "$BITO_MCP_ACCESS_TOKEN" \
        "$mcp_url" \
        "$HOME/.local/bin/bitoarch" \
        "${GIT_PROVIDER}" \
        "${SETUP_MODE:-manual}"
}

# Prompt for SSO setup during initial deployment (shared by K8s and Docker).
#
# Gating (intentional double-layer):
#   1. Outer gate (caller): SKIP_SSO_PROMPT=true  → caller does NOT invoke us
#      (SA install suppresses the prompt; SSO deferred to `bitoarch sso setup`).
#   2. Inner gate (below):  SETUP_MODE=manual     → we return silently because
#      render_config_add_next_steps already lists "Configure SSO" as a numbered
#      step in the printed instructions; an interactive prompt would be
#      redundant. Auto mode gets the prompt (installation is ending; last
#      interactive moment for the user).
prompt_sso_setup() {
    # SSO signs users in through Bito, which an offline install never contacts.
    if command -v bito_offline >/dev/null 2>&1 && bito_offline; then
        log_silent "SSO prompt skipped: offline install (SSO sign-in goes through Bito)"
        return 0
    fi
    if [[ "${SETUP_MODE:-}" != "manual" ]]; then
        # Re-source env so workspace_id from add-repos is available
        [ -f "$ENV_FILE" ] && source "$ENV_FILE"

        render_sso_config_prompt_block
        read -r -p "Would you like to configure SSO? (y/N): " sso_choice

        if [[ "$sso_choice" =~ ^[Yy]$ ]]; then
            if [ -f "${SCRIPT_DIR}/scripts/lib/adapters/xmcp-adapter.sh" ]; then
                source "${SCRIPT_DIR}/scripts/lib/adapters/xmcp-adapter.sh"
                handle_sso "setup" || true
            else
                print_warning "SSO adapter not found"
                echo -e "   Run ${YELLOW}bitoarch sso setup${NC} to configure SSO later"
            fi
        else
            render_sso_deferred_block
        fi
    fi
}

# Enterprise: serve MCP over HTTPS with the customer's own certificate, from
# install.yaml's mcp_tls or the questions below. Only the paths are stored. On
# Docker every compose up copies the files in (mcp_cert_prepare_for_compose); on
# Kubernetes the ingress serves them from a TLS secret and the provider stays on
# HTTP behind it. BITOARCH_INGRESS_HOST names the host developers use: the
# configured one as given, else the certificate's only name, else asked (install.yaml
# takes its first name). A configured host the certificate does not cover still
# installs; `bitoarch diagnose` reports it. Standalone keeps its local mkcert
# certificate. Runs before the env file is written, so a refusal leaves nothing
# behind and a re-run asks again.
prompt_mcp_tls_setup() {
    local why choice="" asked=0 k8s=0 host="${BITOARCH_INGRESS_HOST:-}" given=0 names plain listed=0
    [ "${DEPLOYMENT_METHOD:-}" = "kubernetes" ] && k8s=1
    if [ -n "${MCP_TLS_CERT_FILE:-}${MCP_TLS_KEY_FILE:-}" ] && [ "${SKIP_SSO_PROMPT:-false}" = "true" ]; then
        export _BITOARCH_INSTALL_CLOSED=1
        print_error "Your own MCP certificate (mcp_tls in install.yaml) is supported only for Enterprise. Remove it and re-run the install."
        exit 1
    fi
    [ "${SKIP_SSO_PROMPT:-false}" != "true" ] || return 0

    # shellcheck disable=SC1091
    source "${SCRIPT_DIR}/scripts/lib/mcp-cert.sh"
    if [ -z "${MCP_TLS_CERT_FILE:-}${MCP_TLS_KEY_FILE:-}" ]; then
        [ "${AUTO_SETUP:-}" != "true" ] || return 0
        echo ""
        read -r -p "Enable SSL for MCP with your own certificate? (y/N): " choice || true
        [[ "$choice" =~ ^[Yy]$ ]] || return 0
        asked=1
    fi
    while :; do
        if [ "$asked" -eq 1 ]; then
            read -r -p "Certificate file, PEM with its chain (Enter to skip SSL): " MCP_TLS_CERT_FILE || MCP_TLS_CERT_FILE=""
            [ -n "$MCP_TLS_CERT_FILE" ] || { MCP_TLS_KEY_FILE=""; return 0; }
            read -r -p "Private key file, PEM: " MCP_TLS_KEY_FILE || MCP_TLS_KEY_FILE=""
        fi
        if why="$(mcp_cert_check_custom "${MCP_TLS_CERT_FILE:-}" "${MCP_TLS_KEY_FILE:-}")"; then
            mcp_cert_valid_for "$MCP_TLS_CERT_FILE" && break
            why="the certificate has expired"
        fi
        if [ "$asked" -eq 0 ]; then
            export _BITOARCH_INSTALL_CLOSED=1
            print_error "MCP certificate from install.yaml not usable: ${why}. Fix mcp_tls and re-run the install."
            exit 1
        fi
        print_error "MCP certificate not usable: ${why}"
    done
    # Choices: the certificate's names (wildcards are listed but must be typed out).
    names="$(mcp_cert_dns_names "$MCP_TLS_CERT_FILE")"
    plain="$(printf '%s\n' "$names" | grep -v '^\*' | grep .)"
    [ -z "$host" ] || given=1
    [ -n "$host" ] || [ "$(printf '%s\n' "$names" | grep -c .)" != 1 ] || host="$plain"
    [ -n "$host" ] || [ "$asked" -eq 1 ] || host="$(printf '%s\n' "$plain" | head -n 1)"
    while :; do
        if [ -z "$host" ] && [ "$asked" -eq 1 ]; then
            if [ "$listed" -eq 0 ]; then
                echo "The certificate covers these host names:"
                printf '%s\n' "$plain" | grep . | awk '{printf "  %d) %s\n", NR, $0}'
                printf '%s\n' "$names" | grep '^\*' | sed 's/^/     /; s/$/  (type a name under it)/'
                listed=1
            fi
            read -r -p "Host name developers use to reach this server${plain:+ [1]}: " host \
                || { MCP_TLS_CERT_FILE=""; MCP_TLS_KEY_FILE=""; return 0; }
            host="${host:-${plain:+1}}"
            if [[ "$host" =~ ^[0-9]+$ ]]; then
                host="$(printf '%s\n' "$plain" | sed -n "${host}p")"
                [ -n "$host" ] || { print_error "MCP host not usable: there is no host with that number"; continue; }
            fi
            [ -n "$host" ] || { print_error "MCP host not usable: enter a host name the certificate covers"; continue; }
        fi
        if [[ "$host" == *[!A-Za-z0-9.-]* ]]; then
            why="${host} is not a host name"
        elif [ "$asked" -eq 1 ] && [ "$given" -eq 0 ] && ! mcp_cert_covers_host "$MCP_TLS_CERT_FILE" "$host"; then
            why="the certificate does not cover ${host}"
        else
            break
        fi
        if [ "$asked" -eq 0 ]; then
            export _BITOARCH_INSTALL_CLOSED=1
            print_error "MCP host not usable: ${why}. Fix deployment.ingress.host and re-run the install."
            exit 1
        fi
        print_error "MCP host not usable: ${why}"
        host="" given=0
    done
    mcp_cert_covers_host "$MCP_TLS_CERT_FILE" "$host" \
        || log_silent "MCP host '${host:-none}' is not covered by ${MCP_TLS_CERT_FILE}; bitoarch diagnose reports it" || true
    # MCP_TLS_HOST keeps this host for MCP; BITOARCH_INGRESS_HOST is shared with
    # the plugins, whose PUBLIC_URL may move it later.
    export MCP_TLS_CERT_FILE MCP_TLS_KEY_FILE BITOARCH_INGRESS_HOST="$host" MCP_TLS_HOST="$host"
    [ "$k8s" -eq 1 ] || export MCP_TRANSPORT=https
}

cleanup_on_interrupt() {
    local exit_code=${1:-1}

    # Stop the spinner/loader if running
    stop_loader 2>/dev/null || true

    echo ""
    
    if [[ "${DEPLOYMENT_COMPLETED:-false}" == "true" ]]; then
        # Deployment already finished before the interrupt: the services are healthy and
        # the configuration is saved -- tearing anything down here would destroy a good
        # install. Leave everything running and point at the remaining setup.
        _gb_open "" "Your services are up and the configuration is saved — nothing was removed."
        _gb_bullet "Check status" "bitoarch status"
        _gb_bullet "Finish setup" "" "re-run your install command (completed steps are kept)"
    elif [[ "$DEPLOYMENT_STARTED" == "true" ]] && [[ "$SERVICES_WERE_RUNNING" == "false" ]]; then
        # The trap already printed the interrupted headline; this block only narrates cleanup.
        printf '   Cleaning up the partial deployment...\n\n'

        local cleanup_cmd="${DOCKER_COMPOSE_CMD:-docker-compose}"

        printf "   %-25s" "Stopping services"
        if eval "$cleanup_cmd down --timeout 30" >/dev/null 2>&1; then
            printf "${GREEN}✓${NC} stopped\n"
        else
            printf "${YELLOW}⚠${NC} timed out\n"
            eval "$cleanup_cmd kill" >/dev/null 2>&1 || true
            eval "$cleanup_cmd rm -f" >/dev/null 2>&1 || true
            printf "   %-25s${GREEN}✓${NC} force stopped\n" "Force cleanup"
        fi

        printf "   %-25s" "Releasing resources"
        eval "$cleanup_cmd down --remove-orphans --volumes" >/dev/null 2>&1 || true
        printf "${GREEN}✓${NC} released\n"

        echo ""
        print_status "Partial deployment cleaned up — safe to re-run the install command"

    elif [[ "$DEPLOYMENT_STARTED" == "true" ]] && [[ "$SERVICES_WERE_RUNNING" == "true" ]]; then
        print_info "Setup interrupted - existing services remain running"
        print_warning "Services may be in inconsistent state if restart was interrupted"
        print_info "Consider running: docker compose restart"
        
    else
        print_info "Setup cancelled - no changes made to services"
        if [[ "$SERVICES_WERE_RUNNING" == "true" ]]; then
            print_status "Your services remain running"
        fi
    fi
    
    exit $exit_code
}

cleanup_on_error() {
    # These branches print their own message -> suppress the installer's generic EXIT closing.
    export _BITOARCH_INSTALL_CLOSED=1
    if [[ "$DEPLOYMENT_STARTED" == "true" ]]; then
        print_error "Setup failed during deployment"
        cleanup_on_interrupt 1
    else
        print_error "Setup failed during initialization"
        print_info "No cleanup needed - services unaffected"
        exit 1
    fi
}

# Shared guidance block (headline flush left, body indented, compact — one shape
# for every "here's what to do next" moment): optional colored headline + detail
# + "💡 Next steps" header; bullets and Logs/Docs footer lines are composable.
_gb_open() {   # [headline] [detail]
    [ -n "${1:-}" ] && printf '%b%s%b\n' "${YELLOW:-}" "$1" "${NC:-}"
    [ -n "${2:-}" ] && printf '%s\n' "$2"
    printf '%b💡 Next steps%b\n' "${BOLD:-}" "${NC:-}"
}
_gb_bullet() {   # <label> <command> [suffix] — empty command renders suffix as plain text
    if [ -n "${2:-}" ]; then
        printf '• %-15s %b%s%b%s\n' "$1:" "${YELLOW:-}" "$2" "${NC:-}" "${3:+ $3}"
    else
        printf '• %-15s %s\n' "$1:" "${3:-}"
    fi
}
_gb_kv() { printf '%b%s:%b %s\n' "${BOLD:-}" "$1" "${NC:-}" "$2"; }

cleanup_on_sigint() {
    export _BITOARCH_INSTALL_CLOSED=1
    echo ""
    printf '%b🛑 Setup interrupted (Ctrl+C)%b\n' "${YELLOW:-}" "${NC:-}"
    cleanup_on_interrupt 130
}

cleanup_on_sigterm() {
    export _BITOARCH_INSTALL_CLOSED=1
    echo ""
    print_warning "Setup terminated by system"
    cleanup_on_interrupt 143
}

install_cli() {
    local cli_source="${PLATFORM_DIR}/scripts/bitoarch.sh"
    local cli_bin_dir="$HOME/.local/bin"
    local cli_target="$cli_bin_dir/bitoarch"
    
    log_silent "Installing CLI to $cli_bin_dir"
    
    if [ ! -f "$cli_source" ]; then
        print_warning "CLI script not found, skipping CLI installation"
        log_silent "CLI not found at expected location: $cli_source"
        return 1
    fi
    
    # Create directory if it doesn't exist
    mkdir -p "$cli_bin_dir"
    
    # Make CLI executable and create symlink
    chmod +x "$cli_source"
    ln -sf "$cli_source" "$cli_target"
    
    # Add to PATH for current session (immediate availability)
    export PATH="$cli_bin_dir:$PATH"
    
    # Add to shell configs for future sessions (only if not already present)
    PATH_EXPORT_LINE='export PATH="$HOME/.local/bin:$PATH"'
    CLI_CONFIG_FILES="$HOME/.zshrc $HOME/.bashrc $HOME/.profile $HOME/.bash_profile"
    CLI_ADDED_TO_ANY=false
    CLI_FOUND_CONFIG=false
    
    for config_file in $CLI_CONFIG_FILES; do
        if [ -f "$config_file" ]; then
            CLI_FOUND_CONFIG=true
            # Check if PATH export already exists (using grep -F for fixed string matching)
            if ! grep -qF '.local/bin' "$config_file" 2>/dev/null; then
                echo "$PATH_EXPORT_LINE" >> "$config_file"
                log_silent "Added PATH to $config_file"
                CLI_ADDED_TO_ANY=true
            else
                log_silent "PATH already present in $config_file, skipping"
            fi
        fi
    done
    
    # Fallback: if no rc files found, create .bash_profile
    if [ "$CLI_FOUND_CONFIG" = "false" ]; then
        echo "$PATH_EXPORT_LINE" > "$HOME/.bash_profile"
        log_silent "No shell config files found, created $HOME/.bash_profile with PATH"
        CLI_ADDED_TO_ANY=true
    fi
    
    log_silent "CLI successfully installed to $cli_target"
    return 0
}

rotate_mcp_token() {
    local new_token="$1"
    
    print_info "Rotating MCP access token..."
    
    # Validate token is provided
    if [ -z "$new_token" ]; then
        print_error "Token cannot be empty"
        return 1
    fi
    
    # Update .env file
    if [ -f "$ENV_FILE" ]; then
        sed -i.bak "s/^BITO_MCP_ACCESS_TOKEN=.*/BITO_MCP_ACCESS_TOKEN=${new_token}/" "$ENV_FILE"
        print_status "Updated token in .env-bitoarch"
    else
        print_error ".env file not found"
        return 1
    fi
    
    # Reload environment
    source "$ENV_FILE"
    export BITO_MCP_ACCESS_TOKEN="$new_token"
    
    # Restart ai-architect-provider to pick up new token from environment
    print_info "Restarting ai-architect-provider service to apply new token..."
    cd "$(dirname "$SCRIPT_DIR")" 2>/dev/null || cd "$PLATFORM_DIR" 2>/dev/null || true
    eval "${DOCKER_COMPOSE_CMD:-docker-compose} restart ai-architect-provider" >/dev/null 2>&1
    
    echo ""
    print_status "MCP token rotated successfully"
    print_info "The provider will apply the new token from environment at startup"
    echo ""
    print_info "New MCP URL: ${MCP_TRANSPORT:-http}://$(mcp_url_host):${CIS_PROVIDER_EXTERNAL_PORT}/mcp"
    print_info "New Token: ${new_token}"
    echo ""
    
    return 0
}

# Check Docker Compose port availability
check_docker_ports() {
    log_silent "Checking port availability for Docker Compose..."
    
    # Read port values from .env-bitoarch.default
    local temp_provider_port=$(grep "^CIS_PROVIDER_EXTERNAL_PORT=" "${SCRIPT_DIR}/.env-bitoarch.default" 2>/dev/null | cut -d'=' -f2 || echo "8080")
    local temp_manager_port=$(grep "^CIS_MANAGER_EXTERNAL_PORT=" "${SCRIPT_DIR}/.env-bitoarch.default" 2>/dev/null | cut -d'=' -f2 || echo "9090")
    local temp_config_port=$(grep "^CIS_CONFIG_EXTERNAL_PORT=" "${SCRIPT_DIR}/.env-bitoarch.default" 2>/dev/null | cut -d'=' -f2 || echo "8081")
    local temp_tracker_port=$(grep "^CIS_TRACKER_EXTERNAL_PORT=" "${SCRIPT_DIR}/.env-bitoarch.default" 2>/dev/null | cut -d'=' -f2 || echo "9920")
    
    local port_conflicts=()
    
    if command -v lsof >/dev/null 2>&1; then
        if lsof -i ":${temp_provider_port}" >/dev/null 2>&1; then
            port_conflicts+=("${temp_provider_port}")
        fi
        if lsof -i ":${temp_manager_port}" >/dev/null 2>&1; then
            port_conflicts+=("${temp_manager_port}")
        fi
        if lsof -i ":${temp_config_port}" >/dev/null 2>&1; then
            port_conflicts+=("${temp_config_port}")
        fi
        if lsof -i ":${temp_tracker_port}" >/dev/null 2>&1; then
            port_conflicts+=("${temp_tracker_port}")
        fi
    fi
    
    if [ ${#port_conflicts[@]} -gt 0 ]; then
        echo ""
        echo -e "${RED}⚠ Port conflicts detected${NC}"
        echo ""
        echo "The following ports are already in use:"
        for port in "${port_conflicts[@]}"; do
            echo -e "  - ${RED}${port}${NC}"
        done
        echo ""
        echo -e "${YELLOW}To resolve:${NC}"
        echo "  1. Edit .env-bitoarch.default and change the conflicting port values"
        echo "  2. Re-run your install command"
        echo ""
        exit 1
    fi

    print_status "All required ports are available"
}

# Check Kubernetes external port availability (for port-forwards)
check_k8s_external_ports() {
    print_info "Checking external port availability in Kubernetes cluster..."
    
    # Read port values from .env-bitoarch.default
    local temp_provider_port=$(grep "^CIS_PROVIDER_EXTERNAL_PORT=" "${SCRIPT_DIR}/.env-bitoarch.default" 2>/dev/null | cut -d'=' -f2 || echo "5001")
    local temp_manager_port=$(grep "^CIS_MANAGER_EXTERNAL_PORT=" "${SCRIPT_DIR}/.env-bitoarch.default" 2>/dev/null | cut -d'=' -f2 || echo "5002")
    local temp_config_port=$(grep "^CIS_CONFIG_EXTERNAL_PORT=" "${SCRIPT_DIR}/.env-bitoarch.default" 2>/dev/null | cut -d'=' -f2 || echo "5003")
    local temp_mysql_port=$(grep "^MYSQL_EXTERNAL_PORT=" "${SCRIPT_DIR}/.env-bitoarch.default" 2>/dev/null | cut -d'=' -f2 || echo "5004")
    local temp_tracker_port=$(grep "^CIS_TRACKER_EXTERNAL_PORT=" "${SCRIPT_DIR}/.env-bitoarch.default" 2>/dev/null | cut -d'=' -f2 || echo "5005")
    
    local ports=($temp_provider_port $temp_manager_port $temp_config_port $temp_mysql_port $temp_tracker_port)
    local conflicts=()
    
    # Check if jq is available for JSON parsing
    if command -v jq >/dev/null 2>&1; then
        # Check if any NodePort services already use these ports
        for port in "${ports[@]}"; do
            if kubectl get svc --all-namespaces -o json 2>/dev/null | \
               jq -r '.items[].spec.ports[]? | select(.nodePort=='$port') | .nodePort' 2>/dev/null | \
               grep -q "^${port}$"; then
                conflicts+=("$port")
            fi
        done
    else
        # Fallback: grep through kubectl output
        local all_nodeports=$(kubectl get svc --all-namespaces -o wide 2>/dev/null | grep -oE ":[0-9]{5}/" | tr -d ':/' | sort -u)
        for port in "${ports[@]}"; do
            if echo "$all_nodeports" | grep -q "^${port}$"; then
                conflicts+=("$port")
            fi
        done
    fi
    
    if [ ${#conflicts[@]} -gt 0 ]; then
        echo ""
        echo -e "${RED}⚠ Port conflicts detected${NC}"
        echo ""
        echo "The following ports are already in use in your Kubernetes cluster:"
        for port in "${conflicts[@]}"; do
            echo -e "  - ${RED}${port}${NC}"
        done
        echo ""
        echo -e "${YELLOW}To resolve:${NC}"
        echo "  1. Edit .env-bitoarch.default and change the conflicting port values"
        echo "  2. Re-run your install command"
        echo ""
        exit 1
    fi

    print_status "All required ports are available"
}

# Setup environment variables for CONFIG_URL (used by setup_configuration)
setup_env_for_config() {
    local deployment_type=$(get_deployment_type)
    
    if [ "$deployment_type" = "kubernetes" ]; then
        # Kubernetes: source .env-bitoarch for credentials, then set CONFIG_URL
        if [ -f "$ENV_FILE" ]; then
            source "$ENV_FILE"
        fi
        
        # Read port from .env-bitoarch.default if not set
        if [ -z "$CIS_CONFIG_EXTERNAL_PORT" ] && [ -f "${SCRIPT_DIR}/.env-bitoarch.default" ]; then
            CIS_CONFIG_EXTERNAL_PORT=$(grep "^CIS_CONFIG_EXTERNAL_PORT=" "${SCRIPT_DIR}/.env-bitoarch.default" 2>/dev/null | cut -d'=' -f2 || echo "5003")
        fi
        CIS_CONFIG_EXTERNAL_PORT=${CIS_CONFIG_EXTERNAL_PORT:-5003}
        
        # Port-forwards work through localhost regardless of cluster type (KIND, GKE, etc.)
        local config_host="localhost"
        local namespace="bito-ai-architect"
        
        # Wait for pods to be ready before we make any config API calls.
        log_silent "Waiting for pods to be ready after restart..."
        if wait_for_k8s_services "$namespace" 180; then
            log_silent "All pods are ready"
        else
            print_warning "Some pods may still be initializing"
        fi

        # Capture service logs after pods are ready
        if [ -f "${SCRIPT_DIR}/scripts/unified-log-manager.sh" ]; then
            "${SCRIPT_DIR}/scripts/unified-log-manager.sh" sync || true
        fi

        # Drop stale forwards (pods changed on restart); the CLI reopens them on demand.
        log_silent "Cleaning up old port-forwards..."
        pkill -f "kubectl.*port-forward.*${namespace}" 2>/dev/null || true

        export CONFIG_URL="http://${config_host}:${CIS_CONFIG_EXTERNAL_PORT}"
        export CIS_CONFIG_EXTERNAL_PORT
        export DEPLOYMENT_TYPE="kubernetes"
    else
        # Docker: source .env-bitoarch and export necessary variables
        if [ -f "$ENV_FILE" ]; then
            source "$ENV_FILE"
            export CONFIG_URL="http://localhost:${CIS_CONFIG_EXTERNAL_PORT}"
            export DEPLOYMENT_TYPE="docker-compose"
        fi
    fi
}

# Ask single-node vs multi-node (Kubernetes only). Multi-node needs a
# cluster.yaml (cluster context, scheduling, shared storage, pull secret), so
# seed the template and let the operator edit it before we deploy. Single-node
# keeps the existing backward-compatible path (cluster.yaml optional).
ask_cluster_topology() {
    echo ""
    echo -e "${BLUE}=== Cluster Topology ===${NC}"
    echo "  1) Single-node  — all pods on one node (default; no extra config)"
    echo "  2) Multi-node   — pods scheduled across nodes; needs a cluster.yaml"
    echo "                    (cluster context, scheduling, shared storage, pull secret)"
    echo ""

    local choice=""
    read -p "Select cluster topology [1-2, default: 1]: " choice
    choice=${choice:-1}

    if [ "$choice" != "2" ]; then
        print_info "Selected: Single-node"
        return 0
    fi

    print_info "Selected: Multi-node"
    local cluster_yaml="${CLUSTER_YAML:-$HOME/.bitoarch/cluster.yaml}"
    local template="${SCRIPT_DIR}/cluster.yaml.default"
    # If a VALID cluster.yaml already exists, use it as-is and skip the editor --
    # reopening a good file only risks breaking it. Open the editor only to
    # create the file (absent) or fix it (present but not valid YAML).
    source "${SCRIPT_DIR}/scripts/lib/cluster-yaml.sh" 2>/dev/null || true
    if [ -f "$cluster_yaml" ]; then
        if type _cluster_yaml_validate >/dev/null 2>&1 && _cluster_yaml_validate "$cluster_yaml"; then
            print_info "Using existing cluster.yaml (valid): $cluster_yaml"
            return 0
        fi
        print_warning "Existing cluster.yaml is not valid YAML -- opening it so you can fix it: $cluster_yaml"
        [ -n "${_CLUSTER_YAML_ERR:-}" ] && print_warning "  parser: ${_CLUSTER_YAML_ERR}"
    elif [ -f "$template" ]; then
        mkdir -p "$(dirname "$cluster_yaml")"
        cp "$template" "$cluster_yaml"
        print_info "Created a cluster.yaml template at: $cluster_yaml"
    else
        print_warning "cluster.yaml template not found at $template; create $cluster_yaml manually"
        return 0
    fi

    # Open it in the operator's editor — the same helper the install.yaml
    # pre-seed uses (resolves $VISUAL/$EDITOR/vi, backs up, normalizes BOM/CRLF).
    source "${SCRIPT_DIR}/scripts/lib/editor.sh" 2>/dev/null || true
    if type open_editor_with_normalization >/dev/null 2>&1; then
        open_editor_with_normalization "$cluster_yaml" "cluster"
    else
        echo ""
        echo "Edit this file to match your cluster: $cluster_yaml"
        read -p "Press Enter once you've finished editing cluster.yaml to continue... " _
    fi
    return 0
}

# Ask user for deployment method
ask_deployment_method() {
    # Check if deployment type already exists (from previous setup)
    local existing_deployment=$(get_deployment_type)
    
    if [ "$existing_deployment" != "unknown" ]; then
        local deployment_display=""
        if [ "$existing_deployment" = "kubernetes" ]; then
            deployment_display="Kubernetes"
        else
            deployment_display="Docker Compose"
        fi
        
        print_info "Using existing deployment method: $deployment_display"
        DEPLOYMENT_METHOD="$existing_deployment"
        
        # Re-validate K8s prerequisites if kubernetes
        if [ "$DEPLOYMENT_METHOD" = "kubernetes" ]; then
            if ! check_k8s_prerequisites; then
                render_k8s_not_available_block
                exit 1
            fi
        fi
        return 0
    fi
    
    echo ""
    echo -e "${BLUE}=== Deployment Method ===${NC}"
    echo "Choose how to deploy Bito's AI Architect:"
    echo "  1) Docker Compose"
    echo "  2) Kubernetes (requires existing K8s cluster)"
    echo ""

    local choice=""
    read -p "Select deployment method [1-2, default: 1]: " choice
    choice=${choice:-1}

    case $choice in
        1)
            DEPLOYMENT_METHOD="docker-compose"
            print_info "Selected: Docker Compose"
            save_deployment_type "docker-compose"
            return 0
            ;;
        2)
            DEPLOYMENT_METHOD="kubernetes"
            print_info "Selected: Kubernetes"

            # Ask topology BEFORE the prerequisite checks: multi-node seeds and
            # opens cluster.yaml, whose context: names the target cluster. The
            # checks below (via _cluster_apply_yaml) then pin to that context, so
            # we validate the cluster the operator actually chose -- not whatever
            # the current kubectl context happens to be.
            ask_cluster_topology

            # Check K8s prerequisites (with auto-install)
            if ! check_k8s_prerequisites; then
                render_k8s_not_available_block
                exit 1
            fi

            save_deployment_type "kubernetes"
            return 0
            ;;
        *)
            print_warning "Invalid choice, using Docker Compose"
            DEPLOYMENT_METHOD="docker-compose"
            save_deployment_type "docker-compose"
            return 0
            ;;
    esac
}

# Deploy to Kubernetes
deploy_kubernetes() {
    log_silent "Deploying to Kubernetes..."
    
    # Source values-generator functions
    source "${SCRIPT_DIR}/scripts/values-generator.sh"
    
    # Extract latest provider default.json from image to update helm chart ConfigMap
    # This ensures fresh K8s deployments have the latest config from the image
    log_silent "Extracting latest provider configuration from image..."

    # Source env to get provider image
    if [ -f "$ENV_FILE" ]; then
        source "$ENV_FILE"
    fi

    local provider_image="${CIS_PROVIDER_IMAGE:-}"
    local helm_config_path="${SCRIPT_DIR}/helm-bitoarch/services/cis-provider/config/default.json"

    if [ -n "$provider_image" ]; then
        # Pull the image first to ensure we have the latest
        if docker pull "$provider_image" >> "$LOG_FILE" 2>&1; then
            # Create temp container and extract config
            if docker create --name temp-provider-config-fresh "$provider_image" >/dev/null 2>>"${LOG_FILE:-/dev/null}"; then
                if docker cp temp-provider-config-fresh:/opt/bito/xmcp/config/default.json "$helm_config_path" 2>> "${LOG_FILE:-/dev/null}"; then
                    log_silent "Provider configuration extracted for Helm chart"
                else
                    print_warning "Could not extract provider config from image, using packaged config"
                fi
                docker rm temp-provider-config-fresh >/dev/null 2>&1 || true
            else
                print_warning "Could not create temp container for config extraction"
            fi
        else
            print_warning "Could not pull provider image for config extraction, using packaged config"
        fi
    else
        print_warning "Provider image not set, using packaged config"
    fi

    # Cluster profile (context/storage/scheduling from cluster.yaml), static-NFS
    # prep, and preflight are MULTI-NODE ONLY -- gated on the presence of
    # cluster.yaml (multi-node seeds it; single-node has none, and reset deletes
    # it). Single-node deploys exactly as before: none of this runs, nothing is
    # checked.
    if [ -f "${CLUSTER_YAML:-$HOME/.bitoarch/cluster.yaml}" ]; then
        source "${SCRIPT_DIR}/scripts/lib/cluster-yaml.sh" 2>/dev/null || true
        source "${SCRIPT_DIR}/scripts/lib/k8s-preflight.sh" 2>/dev/null || true
        if type _cluster_apply_yaml >/dev/null 2>&1; then
            _cluster_apply_yaml
            # Static provisioning: create share subdirectories + PersistentVolumes
            # when cluster.yaml carries storage.nfs (no-op otherwise). Runs before
            # preflight so preflight verifies the PVs it just created.
            if ! _cluster_prepare_static_nfs; then
                print_error "Static NFS volume preparation failed"
                return 1
            fi
        fi
        if type run_k8s_preflight >/dev/null 2>&1; then
            if ! run_k8s_preflight "bito-ai-architect"; then
                return 1
            fi
        fi
    fi

    # Generate K8s values file from .env-bitoarch
    log_silent "Generating Kubernetes values from environment configuration..."

    # Get values file path from path-manager
    local values_file
    if type get_k8s_values_file >/dev/null 2>&1; then
        values_file=$(get_k8s_values_file)
    else
        values_file="${SCRIPT_DIR}/.bitoarch-values.yaml"
    fi
    
    if ! generate_k8s_values_from_env; then
        print_error "Failed to generate Kubernetes values"
        return 1
    fi
    
    log_silent "Generated Kubernetes values file: $values_file"
    
    # Deploy via Helm
    local namespace="bito-ai-architect"
    local chart_dir="${SCRIPT_DIR}/helm-bitoarch"
    
    if [ ! -f "$values_file" ]; then
        print_error "Values file not found: $values_file"
        return 1
    fi
    
    # Deploy
    if deploy_helm_chart "$chart_dir" "$values_file" "$namespace"; then
        if wait_for_k8s_services "$namespace"; then
            log_silent "Kubernetes deployment successful"
            # The Wingman shelf is filled by the chart-owned populate Job
            # (07b-wingman-populate.yaml), created in the same helm apply as
            # manager/worker so it runs concurrently with their wait-for-wingman
            # init -- not triggered from the CLI here.
            # Match docker's install output: no per-service table here (that's
            # `bitoarch status`); just say how the deployment is reached.
            render_k8s_access_block "$namespace"
            return 0
        else
            print_error "Kubernetes services failed to become ready"
            return 1
        fi
    else
        print_error "Helm deployment failed"
        return 1
    fi
}

# Silently restart/wait on the Temporal StatefulSet during k8s restart/update flows.
# action: "restart" restarts then waits; "status-only" just waits for rollout.
# log_target: file to capture kubectl output (default /dev/null).
# Returns non-zero if the rollout status times out or fails.
handle_temporal_statefulset() {
    local action="$1"
    local namespace="$2"
    local log_target="${3:-${LOG_FILE:-/dev/null}}"
    if [[ "$action" == "restart" ]]; then
        kubectl rollout restart statefulset ai-architect-temporal -n "$namespace" >>"$log_target" 2>&1 || true
    fi
    kubectl rollout status statefulset ai-architect-temporal -n "$namespace" --timeout=3m >>"$log_target" 2>&1
}

# Silently run a docker-compose subcommand against the Temporal service.
# subcmd: the compose subcommand + flags, e.g. "restart", "pull",
#         "up -d --force-recreate", "up -d --force-recreate --no-deps".
# log_target: file to capture compose output (default /dev/null).
# Requires $compose_cmd to be defined in the caller's scope.
run_temporal_compose() {
    local subcmd="$1"
    local log_target="${2:-${LOG_FILE:-/dev/null}}"
    # Both paths absolute: the dispatcher execs setup.sh without cd'ing, so a
    # relative --env-file (and an unpinned -f) resolve against the caller's CWD.
    eval "$compose_cmd -f \"${SCRIPT_DIR}/docker-compose.yml\" --env-file \"$ENV_FILE\" $subcmd ai-architect-temporal" >>"$log_target" 2>&1
}

# Returns 0 if the service is shown to users, 1 if it's an internal-only
# dependency (status/progress goes to log_silent, not the terminal).
is_user_facing_service() {
    case "$1" in
        ai-architect-tracker) return 1 ;;
        *) return 0 ;;
    esac
}

main() {
    # Set up traps only for main deployment flow
    trap cleanup_on_error ERR
    trap cleanup_on_sigint SIGINT
    trap cleanup_on_sigterm SIGTERM
    
    # Rotate setup.log if needed before starting
    if [ -f "${SCRIPT_DIR}/scripts/unified-log-manager.sh" ]; then
        "${SCRIPT_DIR}/scripts/unified-log-manager.sh" rotate-setup 2>/dev/null || true
    fi
    
    echo -e "${BLUE}Bito's AI Architect - Installation${NC}"
    echo "===================================="
    echo ""

    # CRITICAL FIX: Create standard directories BEFORE any file operations
    # This prevents "No such file or directory" errors when saving deployment type
    local layout=$(get_layout)
    if [ "$layout" = "system" ] || [ "$layout" = "user" ]; then
        if ! create_standard_dirs "$layout" 2>/dev/null; then
            print_warning "Failed to create $layout directories, falling back to user layout"
            # Force user layout fallback
            export BITOARCH_LAYOUT="user"
            init_paths
            ENV_FILE="$(get_config_file)"
            ENV_LLM_FILE="$(get_llm_config_file)"
            LOG_FILE="$(bitoarch_resolve_log_file 2>/dev/null || get_setup_log)"
            if ! create_standard_dirs "user" 2>/dev/null; then
                print_error "Cannot create user directories, installation cannot proceed"
                exit 1
            fi
            log_silent "Forced fallback to user layout at ~/.local/bitoarch"
        fi
    fi

    # Ensure log directory exists before creating log file
    mkdir -p "$(dirname "$LOG_FILE")" 2>/dev/null || {
        if command -v sudo >/dev/null 2>&1; then
            sudo mkdir -p "$(dirname "$LOG_FILE")"
            sudo chown -R "$USER:$(id -gn)" "$(dirname "$LOG_FILE")"
        fi
    }

    touch "$LOG_FILE"

    touch "$LOG_FILE"
    log_silent "Bito's AI Architect setup started at $(date)"
    log_silent "Working directory: $SCRIPT_DIR"
    log_silent "Log file: $LOG_FILE"
    log_silent "Using layout: $(get_layout)"
    log_silent "Config directory: $(get_config_dir)"

    # Check if migration from legacy installation is needed
    if needs_migration && [ ! -f "$ENV_FILE" ]; then
        print_info "Legacy installation detected - migration will occur during first setup"
        log_silent "Migration will be triggered: legacy layout detected"
    fi

    check_prerequisites
    install_cli

    # Auto-migrate if this is an upgrade from legacy installation
    if needs_migration && [ -f "${PLATFORM_DIR}/.env-bitoarch" ]; then
        print_info "Migrating from legacy installation to standard Unix paths..."
        if "${SCRIPT_DIR}/scripts/migrate-to-standard-paths.sh" --auto; then
            print_status "Migration completed successfully"
            # Reinitialize paths after migration
            init_paths
            ENV_FILE="$(get_config_file)"
            ENV_LLM_FILE="$(get_llm_config_file)"
            LOG_FILE="$(bitoarch_resolve_log_file 2>/dev/null || get_setup_log)"
        else
            print_error "Migration failed"
            exit 1
        fi
    fi

    check_existing_services

    # Ask for deployment method (skipped when DEPLOYMENT_METHOD is already set,
    # e.g. by the Standalone install bootstrap which hard-codes docker-compose,
    # by install.yaml's deployment.method, or by a user env-var pre-fill for
    # non-interactive K8s installs).
    if [ -z "${DEPLOYMENT_METHOD:-}" ]; then
        ask_deployment_method
    else
        # Pre-filled paths bypass ask_deployment_method; still validate K8s prerequisites.
        if [ "$DEPLOYMENT_METHOD" = "kubernetes" ] && ! check_k8s_prerequisites; then
            render_k8s_not_available_block
            exit 1
        fi
        # Persist so post-install CLI (bitoarch status / logs / info) branches
        # correctly; ask_deployment_method is where the save normally happens.
        save_deployment_type "$DEPLOYMENT_METHOD"
    fi
    
    # Check ports based on deployment method (before collecting credentials)
    if [ "$DEPLOYMENT_METHOD" = "kubernetes" ]; then
        check_k8s_external_ports
    else
        check_docker_ports
    fi
    
    # Before anything is chowned to it: a UID the service images cannot run as would
    # produce an install that completes and then crash-loops on permission errors.
    validate_service_uid || exit 1

    # CRITICAL: Create directories BEFORE generating env file
    # This ensures /usr/local/etc/bitoarch/ exists before we try to copy files there
    prepare_data_directories

    # Now collect credentials (only if ports are available)
    generate_env_file
    ensure_temporal_mysql_password
    ensure_onprem_llm_provider
    ensure_byok_local_bypass
    ensure_bito_connectivity
    ensure_bito_workspace_id

    # Deploy based on selected method
    if [ "$DEPLOYMENT_METHOD" = "kubernetes" ]; then
        # Kubernetes deployment path
        log_silent "Deployment method: Kubernetes"
        
        if deploy_kubernetes; then
            # Kubernetes deployment: the CLI reaches services over on-demand localhost port-forwards
            local config_host="localhost"

            # Read port from .env-bitoarch if available
            if [ -f "$ENV_FILE" ]; then
                source "$ENV_FILE"
            fi
            if [ -z "$CIS_CONFIG_EXTERNAL_PORT" ] && [ -f "${SCRIPT_DIR}/.env-bitoarch.default" ]; then
                CIS_CONFIG_EXTERNAL_PORT=$(grep "^CIS_CONFIG_EXTERNAL_PORT=" "${SCRIPT_DIR}/.env-bitoarch.default" 2>/dev/null | cut -d'=' -f2 || echo "5003")
            fi
            CIS_CONFIG_EXTERNAL_PORT=${CIS_CONFIG_EXTERNAL_PORT:-5003}

            # CONFIG_URL is localhost; config-adapter opens the config forward on demand.
            export CONFIG_URL="http://${config_host}:${CIS_CONFIG_EXTERNAL_PORT}"
            export CIS_CONFIG_EXTERNAL_PORT
            export DEPLOYMENT_TYPE="kubernetes"

            # deploy_kubernetes already gated on pod readiness; capture service logs.
            if [ -f "${SCRIPT_DIR}/scripts/unified-log-manager.sh" ]; then
                "${SCRIPT_DIR}/scripts/unified-log-manager.sh" sync || true
            fi

            # Capture return code without triggering set -e error trap
            local config_result=0
            _setup_configuration_or_defer wait || config_result=$?

            # Only show full success block for fresh setups (return 0 or 1)
            # Skip for existing config unchanged (return 2)
            if [ $config_result -ne 2 ]; then
                # Skip SSO prompt when caller requests it (e.g. Standalone
                # install, which defers SSO to post-install via `bitoarch sso setup`).
                [ "${SKIP_SSO_PROMPT:-false}" = "true" ] || prompt_sso_setup
                # install.sh defers this to render AFTER the plugin phase
                # (standalone: right before the MCP installer; enterprise: last).
                [ "${BITOARCH_DEFER_SUCCESS_BLOCK:-}" = "1" ] || display_success
                log_silent "Bito's AI Architect setup completed successfully at $(date)"
            else
                # return, not exit: main is sourced into install_run, which still
                # runs the post-install steps (MCP, cert cron, autostart, plugins).
                log_silent "Repository configuration unchanged - setup completed at $(date)"
                return 0
            fi
        else
            export _BITOARCH_INSTALL_CLOSED=1   # own message below -> suppress the generic EXIT closing
            print_error "Kubernetes deployment failed"
            print_info "Check detailed logs: $LOG_FILE"
            exit 1
        fi
    else
        # Docker Compose deployment path (existing flow)
        log_silent "Deployment method: Docker Compose"

        prepare_service_sql_scripts  # Copy service SQL scripts to MySQL init directory
        # The provider is pinned to the service account; a non-root extraction
        # under a restrictive umask leaves its mounts unreadable to that account.
        ensure_provider_mounts_readable "${SCRIPT_DIR}" || true

        # Pre-compose-up: provision HTTPS cert + flip XMCP_INTERNAL_PORT.
        # Self-gating on MCP_TRANSPORT=https; harmless on http installs.
        if [ -f "${SCRIPT_DIR}/scripts/lib/mcp-cert.sh" ]; then
            # shellcheck disable=SC1091
            source "${SCRIPT_DIR}/scripts/lib/mcp-cert.sh"
            mcp_cert_prepare_for_compose 2>>"${LOG_FILE:-/dev/null}" || true
        fi

        # A deploy-time failure/timeout (a container fails the health gate, or an image pull runs
        # long) returns non-zero here. Without this guard, `set -e` would exit silently at the
        # spinner; instead point the operator at status + logs + the safe resume.
        if ! deploy_services; then
            export _BITOARCH_INSTALL_CLOSED=1   # own message -> suppress the generic EXIT closing
            echo ""
            if [ "${DEPLOYMENT_METHOD:-docker-compose}" = "kubernetes" ]; then
                _dep_watch="kubectl get pods -n ${BITOARCH_K8S_NAMESPACE:-bito-ai-architect}"
                _dep_ready="pods are Running"
            else
                _dep_watch="docker ps --filter name=ai-architect"
                _dep_ready="containers are Up"
            fi
            _gb_open "⏳ Services are taking longer than expected to start" \
                "Most often the container images are still downloading — check the logs for details."
            _gb_bullet "Watch progress" "$_dep_watch"
            _gb_bullet "Check status" "bitoarch status"
            _gb_bullet "Resume install" "bitoarch start" "(safe to re-run once $_dep_ready)"
            _gb_kv "Logs" "$LOG_FILE"
            _gb_kv "Docs" "https://docs.bito.ai/ai-architect/install-ai-architect-self-hosted"
            exit 1
        fi

        if wait_for_services; then
            DEPLOYMENT_COMPLETED=true
            validate_deployment
            render_deploy_success_banner

            # Capture service logs after initial deployment
            if [ -f "${SCRIPT_DIR}/scripts/unified-log-manager.sh" ]; then
                "${SCRIPT_DIR}/scripts/unified-log-manager.sh" sync || true
            fi

            # Capture return code without triggering set -e error trap
            local config_result=0
            _setup_configuration_or_defer wait || config_result=$?

            # Only show full success block for fresh setups (return 0 or 1)
            # Skip for existing config unchanged (return 2)
            if [ $config_result -ne 2 ]; then
                # Skip SSO prompt when caller requests it (e.g. Standalone
                # install, which defers SSO to post-install via `bitoarch sso setup`).
                [ "${SKIP_SSO_PROMPT:-false}" = "true" ] || prompt_sso_setup
                # install.sh defers this to render AFTER the plugin phase
                # (standalone: right before the MCP installer; enterprise: last).
                [ "${BITOARCH_DEFER_SUCCESS_BLOCK:-}" = "1" ] || display_success
            fi

            log_silent "Bito's AI Architect setup completed successfully at $(date)"
        else
            export _BITOARCH_INSTALL_CLOSED=1   # own message below -> suppress the generic EXIT closing
            echo ""
            print_error "Service health check failed"
            print_info "Check detailed logs: $LOG_FILE"
            print_info "View service logs: ${DOCKER_COMPOSE_CMD:-docker-compose} logs"
            
            # Show CLI installation status
            local cli_target="$HOME/.local/bin/bitoarch"
            if [ -L "$cli_target" ] || [ -f "$cli_target" ]; then
                echo ""
                print_status "CLI installed to ~/.local/bin/bitoarch"
                print_info "To activate: source ~/.${SHELL##*/}rc (or restart terminal)"
            fi
            
            exit 1
        fi
    fi
}

show_status() {
    echo -e "${BLUE}AI Architect - Service Status${NC}"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo ""
    
    local running_services=$(docker ps -q --filter "name=ai-architect-" 2>/dev/null | wc -l)
    
    if [ "$running_services" -eq 0 ]; then
        print_warning "No AI Architect services are currently running"
        echo ""
        # Unified CLI: bitoarch is installed by setup.sh in both prod and
        # standalone, so this hint works in both modes.
        print_info "To start services, run: ${YELLOW}bitoarch start${NC}"
        return 0
    fi
    
    local services=(
        "ai-architect-mysql:MySQL Database:3306"
        "ai-architect-config:AI Architect Config:8081"
        "ai-architect-manager:AI Architect Manager:9090"
        "ai-architect-provider:AI Architect Provider:8080"
        "ai-architect-worker:AI Architect Worker:"
    )
    
    echo -e "${BLUE}📊 Service Health & Status${NC}"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    
    for service_info in "${services[@]}"; do
        local container_name=$(echo "$service_info" | cut -d: -f1)
        local display_name=$(echo "$service_info" | cut -d: -f2)
        local port=$(echo "$service_info" | cut -d: -f3)
        
        if ! docker ps -a --format '{{.Names}}' | grep -q "^${container_name}$"; then
            printf "   %-25s ${YELLOW}➖ Not Created${NC}\n" "$display_name"
            continue
        fi
        
        local status=$(docker inspect --format='{{.State.Status}}' "$container_name" 2>/dev/null || echo "unknown")
        local health=$(docker inspect --format='{{.State.Health.Status}}' "$container_name" 2>/dev/null || echo "no_health")
        
        local running_time=0
        local started_at=$(docker inspect --format='{{.State.StartedAt}}' "$container_name" 2>/dev/null)
        
        if [ -n "$started_at" ] && [ "$started_at" != "0001-01-01T00:00:00Z" ]; then
            local clean_time=$(echo "$started_at" | sed 's/\.[0-9]*Z$/Z/')
            
            local start_epoch=""
            if [[ "$OSTYPE" == "darwin"* ]]; then
                local time_no_z=$(echo "$clean_time" | sed 's/Z$//')
                start_epoch=$(date -u -j -f "%Y-%m-%dT%H:%M:%S" "$time_no_z" "+%s" 2>/dev/null || echo "")
            else
                start_epoch=$(date -d "$clean_time" "+%s" 2>/dev/null || echo "")
            fi
            
            if [ -n "$start_epoch" ] && [ "$start_epoch" -gt 0 ]; then
                local now=$(date +%s)
                running_time=$((now - start_epoch))
            fi
        fi
        
        local uptime_str=""
        if [ "$running_time" -gt 0 ]; then
            if [ "$running_time" -lt 60 ]; then
                uptime_str="${running_time}s"
            elif [ "$running_time" -lt 3600 ]; then
                uptime_str="$((running_time / 60))m"
            else
                uptime_str="$((running_time / 3600))h"
            fi
        fi
        
        # Build detail string — conditionally include port
        local detail_str=""
        if [ -n "$port" ]; then
            detail_str="(up ${uptime_str}, port ${port})"
        else
            detail_str="(up ${uptime_str})"
        fi
        local static_detail=""
        if [ -n "$port" ]; then
            static_detail="(port ${port})"
        fi

        case "$status" in
            "running")
                if [[ "$health" == "healthy" ]]; then
                    printf "   %-25s ${GREEN}✅ Healthy${NC}      ${detail_str}\n" "$display_name"
                elif [[ "$health" == "starting" ]]; then
                    printf "   %-25s ${YELLOW}⏳ Starting${NC}     ${detail_str}\n" "$display_name"
                elif [[ "$health" == "unhealthy" ]]; then
                    printf "   %-25s ${RED}⚠️  Unhealthy${NC}   ${detail_str}\n" "$display_name"
                else
                    printf "   %-25s ${GREEN}✅ Running${NC}      ${detail_str}\n" "$display_name"
                fi
                ;;
            "restarting")
                printf "   %-25s ${YELLOW}🔄 Restarting${NC}   ${static_detail}\n" "$display_name"
                ;;
            "exited"|"dead")
                printf "   %-25s ${RED}⏹️  Stopped${NC}      ${static_detail}\n" "$display_name"
                ;;
            "created")
                printf "   %-25s ${YELLOW}📦 Created${NC}      ${static_detail}\n" "$display_name"
                ;;
            *)
                printf "   %-25s ${YELLOW}❓ Unknown${NC}      ${static_detail}\n" "$display_name"
                ;;
        esac
    done
    
    echo ""
    echo -e "${BLUE}🔧 Quick Commands${NC}"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo -e "  • View logs:                 ${YELLOW}bitoarch logs${NC}"
    echo -e "  • Restart services:          ${YELLOW}bitoarch restart${NC}"
    echo -e "  • Force Restart services:    ${YELLOW}bitoarch restart --force${NC}"
    echo -e "  • Stop services:             ${YELLOW}bitoarch stop${NC}"
    echo ""
}

show_help() {
    echo "AI Architect Setup Script"
    echo ""
    echo "Usage: $0 [options]"
    echo ""
    echo "Options:"
    echo "  --help, -h        Show this help message"
    echo "  --status          Show current service status"
    echo "  --logs            Show service logs"
    echo "  --stop            Stop all services (preserves containers)"
    echo "  --restart         Restart all services"
    echo "  --force-restart   Restart all services and reapply env variables"
    echo "  --resume          Finish repository and plugin setup after a license key is installed"
    echo "  --update          Force pull latest images based on service-versions.json and restart services"
    echo "  --clean           Remove all data and services"
    echo ""
}

# Source guard: when setup.sh is sourced by another script (e.g. Standalone's
# scripts/lib/install.sh delegating to main()), the CLI dispatcher below must
# NOT auto-run. When setup.sh is executed directly (legacy production flow),
# everything runs as before.
if [ "${BASH_SOURCE[0]}" != "${0}" ]; then
    return 0 2>/dev/null || true
fi

# Pin kubectl/helm to the cluster.yaml context (via KUBECONFIG) for direct
# setup.sh lifecycle flags (--stop/--restart/--status/--logs/--update/--clean)
# so they target the right cluster on a drifted current-context. No-op when
# invoked via the CLI (KUBECONFIG already exported) or when cluster.yaml sets no
# context; the interactive install path pins separately in check_k8s_prerequisites.
if [ "$(get_deployment_type 2>/dev/null)" = "kubernetes" ]; then
    command -v _pin_kube_context >/dev/null 2>&1 \
        || source "$(dirname "${BASH_SOURCE[0]}")/scripts/lib/cluster-yaml.sh" 2>/dev/null || true
    if command -v _pin_kube_context >/dev/null 2>&1; then
        _pin_kube_context || exit 1
    fi
fi

case "${1:-}" in
    --help|-h)
        show_help
        ;;
    --status)
        # Check deployment type
        DEPLOYMENT_TYPE=$(get_deployment_type)
        
        if [ "$DEPLOYMENT_TYPE" = "kubernetes" ]; then
            # Kubernetes status
            namespace="bito-ai-architect"
            
            # Check if any deployments exist and are running (not scaled to 0)
            deployment_count=$(kubectl get deployment -n "$namespace" -l "app.kubernetes.io/name=bitoarch" 2>/dev/null | wc -l | xargs)
            
            if [ "$deployment_count" -le 1 ]; then
                # No deployments found (only header line or namespace doesn't exist)
                echo -e "${BLUE}AI Architect - Service Status${NC}"
                echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
                echo ""
                print_warning "No AI Architect services are currently running"
                echo ""
                print_info "To start services, run: ${YELLOW}bitoarch start${NC}"
                exit 0
            fi
            
            # Check if deployments are scaled to 0 (stopped)
            running_replicas=$(kubectl get deployment -n "$namespace" -l "app.kubernetes.io/name=bitoarch" -o jsonpath='{.items[*].spec.replicas}' 2>/dev/null | tr ' ' '+' | bc 2>/dev/null || echo "0")
            
            if [ "$running_replicas" -eq 0 ]; then
                # Deployments exist but are scaled to 0 (stopped)
                echo -e "${BLUE}AI Architect - Service Status${NC}"
                echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
                echo ""
                print_warning "No AI Architect services are currently running"
                echo ""
                print_info "To start services, run: ${YELLOW}bitoarch start${NC}"
                exit 0
            fi
            
            get_k8s_service_status "$namespace"
            render_k8s_access_block "$namespace"
        else
            # Docker Compose status
            show_status
        fi
        ;;
    --logs)
        # Check deployment type
        DEPLOYMENT_TYPE=$(get_deployment_type)
        
        if [ "$DEPLOYMENT_TYPE" = "kubernetes" ]; then
            # Kubernetes logs
            namespace="bito-ai-architect"
            get_k8s_logs "$namespace" "" "true"
        else
            # Docker Compose logs
            compose_cmd="${DOCKER_COMPOSE_CMD:-}"
            if [ -z "$compose_cmd" ]; then
                if command -v docker >/dev/null 2>&1 && docker compose version >/dev/null 2>&1; then
                    compose_cmd="docker compose"
                elif command -v docker-compose >/dev/null 2>&1; then
                    compose_cmd="docker-compose"
                else
                    print_error "Neither 'docker compose' nor 'docker-compose' found"
                    exit 1
                fi
            fi
            eval "${compose_cmd} --env-file \"${ENV_FILE}\" logs -f"
        fi
        ;;
    --stop)
        print_info "Stopping Bito's AI Architect services..."
        
        # Check deployment type
        DEPLOYMENT_TYPE=$(get_deployment_type)
        
        if [ "$DEPLOYMENT_TYPE" = "kubernetes" ]; then
            # Kubernetes stop (scale to 0 + delete services to free NodePorts)
            namespace="bito-ai-architect"
            
            # Check if services are running (not already stopped/scaled to 0)
            if ! check_k8s_services_running "$namespace"; then
                render_services_not_running_block
                exit 0
            fi
            
            # Capture logs BEFORE stopping (while pods still exist)
            if [ -f "${SCRIPT_DIR}/scripts/unified-log-manager.sh" ]; then
                "${SCRIPT_DIR}/scripts/unified-log-manager.sh" sync || true
            fi
            
            print_info "Stopping Kubernetes deployment..."
            
            # Kill port-forwards first (so they don't point to deleted pods)
            if command -v kill_port_forwards >/dev/null 2>&1; then
                kill_port_forwards "$namespace"
            else
                # Inline cleanup if function not available
                PF_PIDS=$(ps aux | grep "kubectl port-forward" | grep -E "(-n |--namespace=|-n=)$namespace" | grep -v grep | awk '{print $2}')
                if [ -n "$PF_PIDS" ]; then
                    print_info "Terminating port-forwards..."
                    echo "$PF_PIDS" | xargs kill -9 2>/dev/null || true
                fi
            fi
            
            if kubectl scale deployment --all --replicas=0 -n "$namespace" >> "$LOG_FILE" 2>&1; then
                print_info "Pods stopped (scaled to 0 replicas)"
            else
                print_warning "Failed to scale deployments"
            fi

            # Temporal is a StatefulSet (helm-bitoarch/templates/16-temporal-statefulset.yaml)
            # — `kubectl scale deployment --all` does NOT touch StatefulSets, so scale them
            # to 0 explicitly. `|| true` keeps stop idempotent for installs without any
            # StatefulSets.
            kubectl scale statefulset --all --replicas=0 -n "$namespace" >> "$LOG_FILE" 2>&1 || true

            # Delete services to free NodePorts (matching Docker Compose behavior)
            if kubectl delete svc --all -n "$namespace" >> "$LOG_FILE" 2>&1; then
                print_status "Services deleted - NodePorts freed"
            else
                print_warning "Failed to delete services"
            fi
            
            print_status "Kubernetes deployment stopped"
        else
            # Docker Compose stop
            compose_cmd="${DOCKER_COMPOSE_CMD:-}"
            if [ -z "$compose_cmd" ]; then
                if command -v docker >/dev/null 2>&1 && docker compose version >/dev/null 2>&1; then
                    compose_cmd="docker compose"
                elif command -v docker-compose >/dev/null 2>&1; then
                    compose_cmd="docker-compose"
                else
                    print_error "Neither 'docker compose' nor 'docker-compose' found"
                    exit 1
                fi
            fi
            
            # Capture logs BEFORE stopping (while containers still exist)
            if [ -f "${SCRIPT_DIR}/scripts/unified-log-manager.sh" ]; then
                "${SCRIPT_DIR}/scripts/unified-log-manager.sh" sync || true
            fi
            
            # Stop services (preserve containers for quick restart).
            # Use absolute paths for both -f and --env-file so the command
            # works regardless of the caller's CWD (bitoarch stop is invoked
            # from anywhere; dispatcher does not cd). ENV_FILE is path-manager-
            # resolved; COMPOSE_FILE is pinned to the repo root.
            compose_file="${SCRIPT_DIR}/docker-compose.yml"
            compose_base="$compose_cmd -f \"$compose_file\""
            if [ -f "$ENV_FILE" ]; then
                compose_base="$compose_base --env-file \"$ENV_FILE\""
            fi
            if eval "$compose_base stop" >> "$LOG_FILE" 2>&1; then
                print_status "Services stopped (containers preserved)"
            else
                print_error "Failed to stop services"
                print_info "Trying force stop..."
                eval "$compose_base kill" >> "$LOG_FILE" 2>&1 || true
            fi
        fi
        
        render_stop_complete_block
        ;;
    --clean)
        # Shared with scripts/lib/uninstall.sh; CLI symlink preserved here.
        # shellcheck disable=SC1091
        source "${SCRIPT_DIR}/scripts/lib/reset.sh"
        reset_run
        ;;
    --from-existing-config)
        print_info "Starting AI Architect with existing configuration..."
        
        # Check if config exists
        if [[ ! -f ".env-bitoarch" ]]; then
            print_error "No existing configuration found (.env-bitoarch missing)"
            exit 1
        fi
        
        # Must call check_prerequisites to initialize DOCKER_COMPOSE_CMD
        check_prerequisites
        install_cli
        check_existing_services
        check_ports
        # Same gate as the main install path: this one starts from an existing
        # .env-bitoarch, which is exactly where an edited UID would come from.
        validate_service_uid || exit 1
        prepare_data_directories
        prepare_service_sql_scripts
        ensure_provider_mounts_readable "${SCRIPT_DIR}" || true

        if [ -f "${SCRIPT_DIR}/scripts/lib/mcp-cert.sh" ]; then
            # shellcheck disable=SC1091
            source "${SCRIPT_DIR}/scripts/lib/mcp-cert.sh"
            mcp_cert_prepare_for_compose 2>>"${LOG_FILE:-/dev/null}" || true
        fi

        # Now deploy with existing config
        deploy_services

        if wait_for_services; then
            DEPLOYMENT_COMPLETED=true
            validate_deployment
            print_status "Services started successfully with existing configuration"
        else
            print_error "Service health check failed"
            exit 1
        fi
        exit 0
        ;;
    --resume)
        resume_setup
        exit $?
        ;;
    --restart)
        print_info "Restarting AI Architect services..."
        
        # Check deployment type
        DEPLOYMENT_TYPE=$(get_deployment_type)
        
        if [ "$DEPLOYMENT_TYPE" = "kubernetes" ]; then
            namespace="bito-ai-architect"

            # NOTE: --restart is the back-end for both `bitoarch restart` (bounce
            # running services) AND `bitoarch start` (come up from a stopped
            # state). `bitoarch stop` scales deployments to 0 and deletes
            # Services to free NodePorts, so the "stopped" state we must handle
            # here is exactly: release exists, deployments at 0 replicas,
            # Services deleted. We do NOT early-exit when services are not
            # running -- that is the path that leads to redeploy below.

            # Capture logs BEFORE restart (while old pods still exist)
            if [ -f "${SCRIPT_DIR}/scripts/unified-log-manager.sh" ]; then
                "${SCRIPT_DIR}/scripts/unified-log-manager.sh" sync || true
            fi

            # Check if services exist (trim whitespace from wc -l for macOS/Linux compatibility)
            svc_count=$(kubectl get svc -n "$namespace" 2>/dev/null | wc -l | xargs)

            if [ "$svc_count" -le 1 ]; then
                # Services were deleted (only header line), need to redeploy via Helm
                print_info "Services were stopped, redeploying..."

                # Source values-generator to regenerate if needed
                source "${SCRIPT_DIR}/scripts/values-generator.sh"

                # Values file lives under the path-manager-resolved config
                # dir (e.g. /usr/local/etc/bitoarch), NOT SCRIPT_DIR. Fall
                # back to SCRIPT_DIR only when path-manager isn't loaded.
                values_file=""
                if type get_k8s_values_file >/dev/null 2>&1; then
                    values_file=$(get_k8s_values_file)
                fi
                [ -z "$values_file" ] && values_file="${SCRIPT_DIR}/.bitoarch-values.yaml"

                # Always regenerate from env: the env file is the source of truth
                # (e.g. an ingress host adopted since the last deploy).
                print_info "Regenerating Kubernetes values..."
                if ! generate_k8s_values_from_env; then
                    print_error "Failed to generate Kubernetes values"
                    exit 1
                fi

                # Redeploy via Helm (will recreate services and scale up)
                _seed_wingman_before_helm_apply "${BITOARCH_K8S_NAMESPACE:-bito-ai-architect}" "$values_file" || {
                    wingman_bundle_seed_failed 2>/dev/null || true
                    exit 1
                }
                if helm upgrade --install bitoarch "${SCRIPT_DIR}/helm-bitoarch" \
                    --namespace "$namespace" \
                    --values "$values_file" \
                    --wait \
                    --timeout "${K8S_HELM_TIMEOUT:-10m}" >>"$(bitoarch_resolve_log_file 2>/dev/null || get_setup_log)" 2>&1; then
                    print_status "Services redeployed successfully"
                else
                    print_error "Failed to redeploy services (details: $(get_setup_log 2>/dev/null))"
                    exit 1
                fi
            else
                # Services exist, just restart pods
                echo ""
                log_silent "Restarting deployments in order..."
                
                # Restart all deployments at once (parallel for speed)
                if ! kubectl -n "$namespace" rollout restart deployment -l "app.kubernetes.io/name=bitoarch" >> "$LOG_FILE" 2>&1; then
                    echo ""
                    print_error "Failed to initiate restart"
                    print_info "Check logs: kubectl logs -n $namespace"
                    exit 1
                fi

                # Temporal is a StatefulSet, not a Deployment — restart it separately
                kubectl -n "$namespace" rollout restart statefulset -l "app.kubernetes.io/name=bitoarch" >> "$LOG_FILE" 2>&1 || true

                # User-facing services only (tracker is background). Per-deployment
                # rollout status is tracked silently via log_silent; we emit a
                # single summary line at the end for a compact UX consistent
                # with `bitoarch restart` Docker path.
                deployments=("ai-architect-mysql" "ai-architect-temporal" "ai-architect-config" "ai-architect-tracker" "ai-architect-manager" "ai-architect-provider" "ai-architect-worker")
                restart_failed=false

                for deployment in "${deployments[@]}"; do
                    if [[ "$deployment" == "ai-architect-temporal" ]]; then
                        handle_temporal_statefulset "status-only" "$namespace" || restart_failed=true
                        continue
                    fi

                    # Tracker needs longer timeout due to init container dependencies on config/manager
                    timeout="3m"
                    if [[ "$deployment" == "ai-architect-tracker" ]]; then
                        timeout="10m"
                    fi

                    is_user_facing_service "$deployment" && printf "   %-25s" "$deployment"

                    # Check if deployment rolled out successfully
                    if kubectl rollout status deployment "$deployment" -n "$namespace" --timeout=3m >> "$LOG_FILE" 2>&1; then
                        log_silent "  ✅ $deployment restarted"
                    else
                        log_silent "  ⏱ $deployment timed out"
                        restart_failed=true
                    fi
                done

                if [ "$restart_failed" = true ]; then
                    print_warning "Some deployments timed out"
                    print_info "Services may still be starting - check status: ${YELLOW}bitoarch status${NC}"
                else
                    print_status "All deployments restarted successfully"
                    print_info "Check status: ${YELLOW}bitoarch status${NC}"
                fi
            fi
            
            # Setup environment for config API calls (works for both Docker & K8s)
            setup_env_for_config
            
            # Ask if user wants to reconfigure repos after restart
            # Capture return code without triggering set -e error trap
            _setup_configuration_or_defer || true
        else
            # Docker Compose restart
            compose_cmd="${DOCKER_COMPOSE_CMD:-}"
            if [ -z "$compose_cmd" ]; then
                if command -v docker >/dev/null 2>&1 && docker compose version >/dev/null 2>&1; then
                    compose_cmd="docker compose"
                elif command -v docker-compose >/dev/null 2>&1; then
                    compose_cmd="docker-compose"
                else
                    print_error "Neither 'docker compose' nor 'docker-compose' found"
                    exit 1
                fi
            fi

            # Check if services are running
            running_services=$(docker ps -q --filter "name=ai-architect-" 2>/dev/null | wc -l)
            if [ "$running_services" -eq 0 ]; then
                render_services_not_running_block
                exit 0
            fi

            # Capture logs BEFORE restart (while old containers still exist)
            if [ -f "${SCRIPT_DIR}/scripts/unified-log-manager.sh" ]; then
                "${SCRIPT_DIR}/scripts/unified-log-manager.sh" sync || true
            fi

            # Restart all services
            echo ""

            # `docker compose restart` does not honor depends_on; cis-manager
            # and cis-config panic if MySQL isn't ready. Use `stop + up -d`
            # so compose gates dependents on MySQL healthy.
            services="ai-architect-mysql ai-architect-temporal ai-architect-config ai-architect-tracker ai-architect-manager ai-architect-worker ai-architect-provider"
            restart_failed=false

            if eval "$compose_cmd -f \"${SCRIPT_DIR}/docker-compose.yml\" --env-file \"$ENV_FILE\" stop $services" >> "$LOG_FILE" 2>&1 && \
               eval "$compose_cmd -f \"${SCRIPT_DIR}/docker-compose.yml\" --env-file \"$ENV_FILE\" up -d $services" >> "$LOG_FILE" 2>&1; then
                print_status "All services restarted successfully"
                print_info "Check status: ${YELLOW}bitoarch status${NC}"
            else
                restart_failed=true
                print_warning "Restart failed"
                print_info "Check logs: ${YELLOW}bitoarch logs${NC}"
                exit 1
            fi
            
            # Ask if user wants to reconfigure repos after restart
            _setup_configuration_or_defer
        fi
        ;;
      --force-restart)
        print_info "Force Restarting AI Architect services with updated configuration..."

        # Backup .env-bitoarch before applying changes (silent)
        if [ -f "$ENV_FILE" ] && command -v backup_config_file >/dev/null 2>&1; then
            backup_config_file "$ENV_FILE" "env" >> "$LOG_FILE" 2>&1
        fi

        # Check deployment type
        DEPLOYMENT_TYPE=$(get_deployment_type)
        
        if [ "$DEPLOYMENT_TYPE" = "kubernetes" ]; then
            # Kubernetes force restart with config update
            namespace="bito-ai-architect"
            
            # Check if services are running (not stopped/scaled to 0)
            if ! check_k8s_services_running "$namespace"; then
                render_services_not_running_block
                exit 0
            fi
            
            # Capture logs BEFORE force restart (while old pods still exist)
            if [ -f "${SCRIPT_DIR}/scripts/unified-log-manager.sh" ]; then
                "${SCRIPT_DIR}/scripts/unified-log-manager.sh" sync || true
            fi
            
            log_silent "Regenerating Kubernetes configuration from .env-bitoarch..."

            # Reload install.yaml -> env_file BEFORE regenerating helm values,
            # so any user edits to $HOME/.bitoarch/install.yaml (api key,
            # ports, resource limits) flow into the K8s deployment. This
            # gives K8s prod the same live-reload contract as Docker.
            # No-op when yaml absent. Sources install-yaml.sh directly (not
            # install.sh) -- only the helpers are needed here.
            if [ -f "${SCRIPT_DIR}/scripts/lib/install-yaml.sh" ]; then
                # shellcheck disable=SC1091
                source "${SCRIPT_DIR}/scripts/lib/install-yaml.sh"
                command -v validate_install_yaml_api_key >/dev/null 2>&1 \
                    && { validate_install_yaml_api_key "$ENV_FILE" || exit 1; }
                command -v apply_install_yaml_to_env_file >/dev/null 2>&1 \
                    && apply_install_yaml_to_env_file "$ENV_FILE"
            fi

            # Regenerate values from .env-bitoarch
            source "${SCRIPT_DIR}/scripts/values-generator.sh"
            if ! generate_k8s_values_from_env; then
                print_error "Failed to regenerate Kubernetes values"
                exit 1
            fi
            
            log_silent "Configuration regenerated"
            
            # Apply updated configuration via Helm upgrade
            # Don't use --reuse-values with --values (contradictory flags cause conflicts)
            # Helm won't modify PVCs since their specs haven't changed - only ConfigMaps/Secrets are updated
            # Use get_k8s_values_file to get actual file path (supports standard Unix paths)
            k8s_values_file="$(get_k8s_values_file)"
            log_silent "Applying configuration update via Helm..."
            _seed_wingman_before_helm_apply "${BITOARCH_K8S_NAMESPACE:-bito-ai-architect}" "$k8s_values_file" || {
                wingman_bundle_seed_failed 2>/dev/null || true
                exit 1
            }
            if helm upgrade --install bitoarch "${SCRIPT_DIR}/helm-bitoarch" \
                --namespace "$namespace" \
                --values "$k8s_values_file" \
                --wait \
                --timeout 5m 2>&1 | tee -a "$LOG_FILE" | grep -q "has been upgraded"; then
                log_silent "Configuration applied successfully"
            else
                print_warning "Helm upgrade may have timed out (check logs)"
                log_silent "Continuing with pod restart..."
            fi

            log_silent "Force restarting services with updated configuration..."

            # User-facing services only; tracker is a background service.
            # Per-deployment status goes to setup.log via log_silent; a single
            # summary line hits the terminal (compact UX, consistent with
            # bitoarch CLI path).
            deployments=("ai-architect-mysql" "ai-architect-temporal" "ai-architect-config" "ai-architect-tracker" "ai-architect-manager" "ai-architect-provider" "ai-architect-worker")
            restart_failed=false
            for deployment in "${deployments[@]}"; do

                if [[ "$deployment" == "ai-architect-temporal" ]]; then
                    handle_temporal_statefulset "restart" "$namespace" || restart_failed=true
                    continue
                fi

                is_user_facing_service "$deployment" && printf "   %-25s" "$deployment"

                if kubectl rollout restart deployment "$deployment" -n "$namespace" >> "$LOG_FILE" 2>&1; then
                    if kubectl rollout status deployment "$deployment" -n "$namespace" --timeout=$timeout >> "$LOG_FILE" 2>&1; then
                        log_silent "  ✅ $deployment restarted"
                    else
                        log_silent "  ⏱ $deployment timed out"
                        restart_failed=true
                    fi
                else
                    log_silent "  ❌ $deployment failed"
                    restart_failed=true
                fi
            done

            if [ "$restart_failed" = true ]; then
                print_warning "Some deployments failed or timed out"
                print_info "Check status: ${YELLOW}bitoarch status${NC}"
            else
                print_status "All services force restarted successfully with updated configuration"
                print_info "Check status: ${YELLOW}bitoarch status${NC}"
            fi
            
            # Setup environment for config API calls (works for both Docker & K8s)
            setup_env_for_config
            
            # Ask if user wants to reconfigure repos after restart
            # Capture return code without triggering set -e error trap
            _setup_configuration_or_defer || true
        else
            # Docker Compose force restart with config update
            
            # Determine docker compose command
            compose_cmd="${DOCKER_COMPOSE_CMD:-}"
            if [ -z "$compose_cmd" ]; then
                if command -v docker >/dev/null 2>&1 && docker compose version >/dev/null 2>&1; then
                    compose_cmd="docker compose"
                elif command -v docker-compose >/dev/null 2>&1; then
                    compose_cmd="docker-compose"
                else
                    print_error "Neither 'docker compose' nor 'docker-compose' found"
                    exit 1
                fi
            fi

            # Check if services are running
            running_services=$(docker ps -q --filter "name=ai-architect-" 2>/dev/null | wc -l)
            if [ "$running_services" -eq 0 ]; then
                render_services_not_running_block
                exit 0
            fi

            # Capture logs BEFORE force restart (while old containers still exist)
            if [ -f "${SCRIPT_DIR}/scripts/unified-log-manager.sh" ]; then
                "${SCRIPT_DIR}/scripts/unified-log-manager.sh" sync || true
            fi

            # Force recreate all services with updated environment
            echo ""
            log_silent "Force restarting services with updated configuration..."

            # Single `up -d --force-recreate` (no per-service loop, no
            # --no-deps) so compose gates config/manager on MySQL healthy.
            services="ai-architect-mysql ai-architect-temporal ai-architect-config ai-architect-tracker ai-architect-manager ai-architect-worker ai-architect-provider"
            restart_failed=false

            if eval "$compose_cmd -f \"${SCRIPT_DIR}/docker-compose.yml\" --env-file \"$ENV_FILE\" up -d --force-recreate $services" >> "$LOG_FILE" 2>&1; then
                print_status "All services force restarted successfully with updated configuration"
                print_info "Check status: ${YELLOW}bitoarch status${NC}"
            else
                restart_failed=true
                print_warning "Force restart failed"
                print_info "Check logs: ${YELLOW}bitoarch logs${NC}"
                exit 1
            fi
            
            # Ask if user wants to reconfigure repos after restart
            _setup_configuration_or_defer
        fi
        ;;
    --update)
        print_info "Updating AI Architect - Force pulling latest images and restarting services..."
        
        # Backup .env-bitoarch before update (silent)
        if [ -f "$ENV_FILE" ] && command -v backup_config_file >/dev/null 2>&1; then
            backup_config_file "$ENV_FILE" "env" >> "$LOG_FILE" 2>&1
        fi
        
        # Check deployment type
        DEPLOYMENT_TYPE=$(get_deployment_type)
        
        # Load service versions from versions/service-versions.json
        versions_file="${SCRIPT_DIR}/versions/service-versions.json"
        if [ ! -f "$versions_file" ]; then
            print_error "versions/service-versions.json not found"
            exit 1
        fi
        
        if [ "$DEPLOYMENT_TYPE" = "kubernetes" ]; then
            # Kubernetes update
            namespace="bito-ai-architect"
            
            # Check if services are running (not stopped/scaled to 0)
            if ! check_k8s_services_running "$namespace"; then
                render_services_not_running_block
                exit 0
            fi
            
            # Capture logs BEFORE update (while old pods still exist)
            if [ -f "${SCRIPT_DIR}/scripts/unified-log-manager.sh" ]; then
                "${SCRIPT_DIR}/scripts/unified-log-manager.sh" sync || true
            fi
            
            print_info "Pulling latest images for Kubernetes deployment..."
            echo ""
            
            # Read versions and images from service-versions.json
            if command -v jq >/dev/null 2>&1; then
                CIS_CONFIG_VERSION=$(jq -r '.services."cis-config".version' "$versions_file" 2>/dev/null || echo "latest")
                CIS_CONFIG_IMAGE_BASE=$(jq -r '.services."cis-config".image' "$versions_file" 2>/dev/null || echo "docker.io/bitoai/cis-config")
                
                CIS_MANAGER_VERSION=$(jq -r '.services."cis-manager".version' "$versions_file" 2>/dev/null || echo "latest")
                CIS_MANAGER_IMAGE_BASE=$(jq -r '.services."cis-manager".image' "$versions_file" 2>/dev/null || echo "docker.io/bitoai/cis-manager")
                
                CIS_PROVIDER_VERSION=$(jq -r '.services."cis-provider".version' "$versions_file" 2>/dev/null || echo "latest")
                CIS_PROVIDER_IMAGE_BASE=$(jq -r '.services."cis-provider".image' "$versions_file" 2>/dev/null || echo "docker.io/bitoai/cis-provider")
                
                CIS_TRACKER_VERSION=$(jq -r '.services."cis-tracker".version' "$versions_file" 2>/dev/null || echo "latest")
                CIS_TRACKER_IMAGE_BASE=$(jq -r '.services."cis-tracker".image' "$versions_file" 2>/dev/null || echo "docker.io/bitoai/cis-tracker")

                CIS_WORKER_VERSION=$(jq -r '.services."cis-worker".version' "$versions_file" 2>/dev/null || echo "latest")
                CIS_WORKER_IMAGE_BASE=$(jq -r '.services."cis-worker".image' "$versions_file" 2>/dev/null || echo "docker.io/bitoai/cis-worker")
            else
                CIS_CONFIG_VERSION=$(grep -A 10 '"cis-config"' "$versions_file" | grep '"version"' | head -1 | cut -d'"' -f4 || echo "latest")
                CIS_CONFIG_IMAGE_BASE=$(grep -A 10 '"cis-config"' "$versions_file" | grep '"image"' | head -1 | cut -d'"' -f4 || echo "docker.io/bitoai/cis-config")
                
                CIS_MANAGER_VERSION=$(grep -A 10 '"cis-manager"' "$versions_file" | grep '"version"' | head -1 | cut -d'"' -f4 || echo "latest")
                CIS_MANAGER_IMAGE_BASE=$(grep -A 10 '"cis-manager"' "$versions_file" | grep '"image"' | head -1 | cut -d'"' -f4 || echo "docker.io/bitoai/cis-manager")
                
                CIS_PROVIDER_VERSION=$(grep -A 10 '"cis-provider"' "$versions_file" | grep '"version"' | head -1 | cut -d'"' -f4 || echo "latest")
                CIS_PROVIDER_IMAGE_BASE=$(grep -A 10 '"cis-provider"' "$versions_file" | grep '"image"' | head -1 | cut -d'"' -f4 || echo "docker.io/bitoai/cis-provider")
                
                CIS_TRACKER_VERSION=$(grep -A 10 '"cis-tracker"' "$versions_file" | grep '"version"' | head -1 | cut -d'"' -f4 || echo "latest")
                CIS_TRACKER_IMAGE_BASE=$(grep -A 10 '"cis-tracker"' "$versions_file" | grep '"image"' | head -1 | cut -d'"' -f4 || echo "docker.io/bitoai/cis-tracker")

                CIS_WORKER_VERSION=$(grep -A 10 '"cis-worker"' "$versions_file" | grep '"version"' | head -1 | cut -d'"' -f4 || echo "latest")
                CIS_WORKER_IMAGE_BASE=$(grep -A 10 '"cis-worker"' "$versions_file" | grep '"image"' | head -1 | cut -d'"' -f4 || echo "docker.io/bitoai/cis-worker")
            fi
            
            log_silent "Target versions:"
            log_silent "  AI Architect Config: $CIS_CONFIG_VERSION"
            log_silent "  AI Architect Manager: $CIS_MANAGER_VERSION"
            log_silent "  AI Architect Provider: $CIS_PROVIDER_VERSION"
            log_silent "  AI Architect Tracker: $CIS_TRACKER_VERSION"
            log_silent "  AI Architect Worker: $CIS_WORKER_VERSION"
            echo ""
            
            # Update .env-bitoarch with new versions AND images (use real file, not symlink)
            env_config_file="$(get_config_file)"
            if [ -f "$env_config_file" ]; then
                sed -i.bak "s|^CIS_CONFIG_VERSION=.*|CIS_CONFIG_VERSION=${CIS_CONFIG_VERSION}|" "$env_config_file"
                sed -i.bak "s|^CIS_CONFIG_IMAGE=.*|CIS_CONFIG_IMAGE=${CIS_CONFIG_IMAGE_BASE}:${CIS_CONFIG_VERSION}|" "$env_config_file"
                
                sed -i.bak "s|^CIS_MANAGER_VERSION=.*|CIS_MANAGER_VERSION=${CIS_MANAGER_VERSION}|" "$env_config_file"
                sed -i.bak "s|^CIS_MANAGER_IMAGE=.*|CIS_MANAGER_IMAGE=${CIS_MANAGER_IMAGE_BASE}:${CIS_MANAGER_VERSION}|" "$env_config_file"
                
                sed -i.bak "s|^CIS_PROVIDER_VERSION=.*|CIS_PROVIDER_VERSION=${CIS_PROVIDER_VERSION}|" "$env_config_file"
                sed -i.bak "s|^CIS_PROVIDER_IMAGE=.*|CIS_PROVIDER_IMAGE=${CIS_PROVIDER_IMAGE_BASE}:${CIS_PROVIDER_VERSION}|" "$env_config_file"
                
                sed -i.bak "s|^CIS_TRACKER_VERSION=.*|CIS_TRACKER_VERSION=${CIS_TRACKER_VERSION}|" "$env_config_file"
                sed -i.bak "s|^CIS_TRACKER_IMAGE=.*|CIS_TRACKER_IMAGE=${CIS_TRACKER_IMAGE_BASE}:${CIS_TRACKER_VERSION}|" "$env_config_file"

                if [ -n "${CIS_WORKER_IMAGE_BASE:-}" ] && [ -n "${CIS_WORKER_VERSION:-}" ]; then
                    sed -i.bak "s|^CIS_WORKER_VERSION=.*|CIS_WORKER_VERSION=${CIS_WORKER_VERSION}|" "$env_config_file"
                    sed -i.bak "s|^CIS_WORKER_IMAGE=.*|CIS_WORKER_IMAGE=${CIS_WORKER_IMAGE_BASE}:${CIS_WORKER_VERSION}|" "$env_config_file"
                fi
            fi
            
            # Regenerate values with new versions and imagePullPolicy=Always to force pull
            source "${SCRIPT_DIR}/scripts/values-generator.sh"
            if ! generate_k8s_values_from_env "Always"; then
                print_error "Failed to regenerate Kubernetes values"
                exit 1
            fi
            
            # Extract latest provider default.json from new image to update helm chart ConfigMap
            print_info "Extracting latest provider configuration from new image..."
            provider_image="${CIS_PROVIDER_IMAGE_BASE}:${CIS_PROVIDER_VERSION}"
            helm_config_path="${SCRIPT_DIR}/helm-bitoarch/services/cis-provider/config/default.json"

            # Pull the image first to ensure we have the latest
            if docker pull "$provider_image" >> "$LOG_FILE" 2>&1; then
                # Create temp container and extract config
                if docker create --name temp-provider-config-k8s "$provider_image" >/dev/null 2>>"${LOG_FILE:-/dev/null}"; then
                    if docker cp temp-provider-config-k8s:/opt/bito/xmcp/config/default.json "$helm_config_path" 2>> "${LOG_FILE:-/dev/null}"; then
                        log_silent "Provider configuration extracted for Helm chart"
                    else
                        print_warning "Could not extract provider config from image, using existing config"
                    fi
                    docker rm temp-provider-config-k8s >/dev/null 2>&1 || true
                else
                    print_warning "Could not create temp container for config extraction"
                fi
            else
                print_warning "Could not pull provider image for config extraction"
            fi

            # Apply updated configuration via Helm upgrade (will pull new images)
            # Use get_k8s_values_file to get actual file path (supports standard Unix paths)
            k8s_values_file="$(get_k8s_values_file)"
            print_info "Applying update via Helm (pulling new images)..."
            _seed_wingman_before_helm_apply "${BITOARCH_K8S_NAMESPACE:-bito-ai-architect}" "$k8s_values_file" || {
                wingman_bundle_seed_failed 2>/dev/null || true
                exit 1
            }
            if helm upgrade --install bitoarch "${SCRIPT_DIR}/helm-bitoarch" \
                --namespace "$namespace" \
                --values "$k8s_values_file" \
                --wait \
                --timeout 10m >> "$LOG_FILE" 2>&1; then
                print_status "Images updated successfully"
            else
                print_error "Failed to apply update"
                print_info "Check logs: cat $LOG_FILE"
                print_info "Check Helm release: helm list -n $namespace"
                exit 1
            fi
            
            echo ""
            print_info "Restarting services with updated images..."
            
            deployments=("ai-architect-mysql" "ai-architect-temporal" "ai-architect-config" "ai-architect-tracker" "ai-architect-manager" "ai-architect-provider" "ai-architect-worker")
            restart_failed=false

            for deployment in "${deployments[@]}"; do
                if [[ "$deployment" == "ai-architect-temporal" ]]; then
                    handle_temporal_statefulset "restart" "$namespace" "$LOG_FILE" || restart_failed=true
                    continue
                fi

                if is_user_facing_service "$deployment"; then
                    printf "   %-25s" "$deployment"
                    if kubectl rollout restart deployment "$deployment" -n "$namespace" >> "$LOG_FILE" 2>&1; then
                        if kubectl rollout status deployment "$deployment" -n "$namespace" --timeout=3m >> "$LOG_FILE" 2>&1; then
                            printf "${GREEN}✅ Updated${NC}\n"
                        else
                            printf "${YELLOW}⏱ Timeout${NC}\n"
                            restart_failed=true
                        fi
                    else
                        printf "${RED}❌ Failed${NC}\n"
                        restart_failed=true
                    fi
                else
                    if kubectl rollout restart deployment "$deployment" -n "$namespace" >> "$LOG_FILE" 2>&1; then
                        if kubectl rollout status deployment "$deployment" -n "$namespace" --timeout=3m >> "$LOG_FILE" 2>&1; then
                            log_silent "  ✅ $deployment updated"
                        else
                            log_silent "  ⏱ $deployment timed out"
                            restart_failed=true
                        fi
                    else
                        log_silent "  ❌ $deployment failed"
                        restart_failed=true
                    fi
                fi
            done
            
            echo ""
            if [ "$restart_failed" = true ]; then
                print_warning "Some services failed or timed out"
                print_info "Check status: ${YELLOW}bitoarch status${NC}"
                exit 1
            else
                print_status "All services updated successfully"
                
                # Drop stale forwards (pods changed on update); the CLI reopens them on demand.
                pkill -f "kubectl.*port-forward.*${namespace}" 2>/dev/null || true

                # Wait for pods to be stable, then capture service logs.
                if wait_for_k8s_services "$namespace" 60; then
                    if [ -f "${SCRIPT_DIR}/scripts/unified-log-manager.sh" ]; then
                        "${SCRIPT_DIR}/scripts/unified-log-manager.sh" sync || true
                    fi
                fi
                
                print_info "Check status: ${YELLOW}bitoarch status${NC}"
            fi
        else
            # Docker Compose update
            compose_cmd="${DOCKER_COMPOSE_CMD:-}"
            if [ -z "$compose_cmd" ]; then
                if command -v docker >/dev/null 2>&1 && docker compose version >/dev/null 2>&1; then
                    compose_cmd="docker compose"
                elif command -v docker-compose >/dev/null 2>&1; then
                    compose_cmd="docker-compose"
                else
                    print_error "Neither 'docker compose' nor 'docker-compose' found"
                    exit 1
                fi
            fi
            
            # Check if services are running
            running_services=$(docker ps -q --filter "name=ai-architect-" 2>/dev/null | wc -l)
            if [ "$running_services" -eq 0 ]; then
                print_warning "No AI Architect services are currently running"
                print_info "To start services, run: ${YELLOW}bitoarch start${NC}"
                exit 0
            fi
            
            # Capture logs BEFORE update (while old containers still exist)
            if [ -f "${SCRIPT_DIR}/scripts/unified-log-manager.sh" ]; then
                "${SCRIPT_DIR}/scripts/unified-log-manager.sh" sync || true
            fi
            
            # DOCKER FIX: Refresh versions from service-versions.json to .env-bitoarch
            # This replaces the manual sed commands and ensures single source of truth
            # Use get_config_file to get actual file path (not symlink) for sed compatibility
            env_config_file="$(get_config_file)"
            print_info "Refreshing service versions from ${versions_file}..."
            if ! refresh_versions_from_service_json "$env_config_file"; then
                print_error "Failed to refresh versions from service-versions.json"
                exit 1
            fi

            # Source the updated env file to get version info for display
            source "$env_config_file"

            # Extract versions from IMAGE variables (format: docker.io/bitoai/service:version)
            config_version="${CIS_CONFIG_IMAGE##*:}"
            manager_version="${CIS_MANAGER_IMAGE##*:}"
            provider_version="${CIS_PROVIDER_IMAGE##*:}"
            tracker_version="${CIS_TRACKER_IMAGE##*:}"
            mysql_version="${MYSQL_IMAGE##*:}"

            log_silent "Target versions from ${versions_file}:"
            log_silent "  AI Architect Config: ${config_version}"
            log_silent "  AI Architect Manager: ${manager_version}"
            log_silent "  AI Architect Provider: ${provider_version}"
            log_silent "  AI Architect Tracker: ${tracker_version}"
            log_silent "  MySQL: ${mysql_version}"
            echo ""
                        
            echo ""
            print_info "Pulling latest images (this may take a few minutes)..."
            
            # Pull images one by one with progress
            services=("ai-architect-mysql" "ai-architect-temporal" "ai-architect-config" "ai-architect-tracker" "ai-architect-manager" "ai-architect-worker" "ai-architect-provider")
            pull_failed=false
            
            for service in "${services[@]}"; do
                if [ "$service" = "ai-architect-temporal" ]; then
                    run_temporal_compose "pull" "$LOG_FILE" || pull_failed=true
                    continue
                fi

                if is_user_facing_service "$service"; then
                    printf "   %-25s" "$service"
                    if eval "$compose_cmd -f \"${SCRIPT_DIR}/docker-compose.yml\" --env-file \"$ENV_FILE\" pull $service" >> "$LOG_FILE" 2>&1; then
                        printf "${GREEN}✅ Pulled${NC}\n"
                    else
                        printf "${RED}❌ Failed${NC}\n"
                        pull_failed=true
                    fi
                else
                    if eval "$compose_cmd -f \"${SCRIPT_DIR}/docker-compose.yml\" --env-file \"$ENV_FILE\" pull $service" >> "$LOG_FILE" 2>&1; then
                        log_silent "  ✅ $service pulled"
                    else
                        log_silent "  ❌ $service pull failed"
                        pull_failed=true
                    fi
                fi
            done
            
            if [ "$pull_failed" = true ]; then
                echo ""
                print_error "Failed to pull some images"
                print_info "Check logs: cat $LOG_FILE"
                exit 1
            fi
            
            # Extract latest provider default.json from new image
            echo ""
            print_info "Extracting latest provider configuration from new image..."
            docker_config_path="${SCRIPT_DIR}/services/cis-provider/config/default.json"

            # Create temp container and extract config
            if docker create --name temp-provider-config-docker "${CIS_PROVIDER_IMAGE}" >/dev/null 2>>"${LOG_FILE:-/dev/null}"; then
                if docker cp temp-provider-config-docker:/opt/bito/xmcp/config/default.json "$docker_config_path" 2>> "${LOG_FILE:-/dev/null}"; then
                    # 0600: the provider rewrites this file with its signing secret and
                    # tokens on every start (provider-startup.sh builds default.json.tmp
                    # and mv's it over), as the owner, so no other account needs it.
                    chmod 0600 "$docker_config_path"
                    print_status "Provider configuration extracted from latest image"
                else
                    print_warning "Could not extract provider config from image, using existing config"
                fi
                docker rm temp-provider-config-docker >/dev/null 2>&1 || true
            else
                print_warning "Could not create temp container for config extraction"
            fi

            echo ""
            print_info "Restarting services with updated images..."

            # Single `up -d --force-recreate` without --no-deps so compose
            # brings MySQL up first and gates config/manager on MySQL healthy.
            # A per-service loop with --no-deps would race MySQL startup.
            # Include the wingman-populate one-shot so `update` re-checks the CDN and refreshes the shared
            # shelf (highest-version-wins); compose orders it before manager/worker via depends_on.
            services_str="ai-architect-mysql ai-architect-temporal ai-architect-wingman-populate ai-architect-config ai-architect-tracker ai-architect-manager ai-architect-provider ai-architect-worker"
            restart_failed=false
            if eval "$compose_cmd -f \"${SCRIPT_DIR}/docker-compose.yml\" --env-file \"$ENV_FILE\" up -d --force-recreate $services_str" >> "$LOG_FILE" 2>&1; then
                print_status "All services updated successfully with latest images"
                print_info "Check status: ${YELLOW}bitoarch status${NC}"
            else
                restart_failed=true
                print_warning "Update failed"
                print_info "Check logs: ${YELLOW}bitoarch logs${NC}"
                exit 1
            fi
        fi
        ;;
    *)
        # Check if an unknown option was provided
        if [[ "${1:-}" == --* ]]; then
            print_error "Unknown option: ${1}"
            echo ""
            show_help
            exit 1
        else
            # No option provided, run main setup
            main
        fi
        ;;
esac
