#!/bin/sh
#
# Register the custom search attributes that cis-platform workflows expect.
# Idempotent: failures from "already exists" are ignored.
#
set -eu

: "${TEMPORAL_ADDRESS:=ai-architect-temporal:7233}"
: "${NAMESPACE:=cis-onprem}"

echo "================================================"
echo "Setting up Temporal Search Attributes"
echo "Address:   ${TEMPORAL_ADDRESS}"
echo "Namespace: ${NAMESPACE}"
echo "================================================"

# Wait for namespace to be accessible (may take a few seconds after creation)
echo "Waiting for namespace '${NAMESPACE}' to be accessible..."
max_attempts=30
attempt=0
until temporal operator namespace describe -n "${NAMESPACE}" --address "${TEMPORAL_ADDRESS}" >/dev/null 2>&1; do
    attempt=$((attempt + 1))
    if [ "${attempt}" -ge "${max_attempts}" ]; then
        echo "ERROR: Namespace '${NAMESPACE}' not accessible after ${max_attempts} attempts" >&2
        exit 1
    fi
    echo "  not ready, retrying in 10s (attempt ${attempt}/${max_attempts})..."
    sleep 10
done
echo "Namespace '${NAMESPACE}' is accessible"

create_sa() {
    name="$1"
    type="$2"
    echo "  creating search attribute ${name} (${type})..."
    temporal operator search-attribute create \
        --address "${TEMPORAL_ADDRESS}" \
        --namespace "${NAMESPACE}" \
        --name "${name}" \
        --type "${type}" || echo "    (already exists or non-fatal error — continuing)"
}

create_sa "workspace_id"         "Int"
create_sa "repository_namespace" "Keyword"
create_sa "session_id"           "Keyword"
create_sa "deployment_mode"      "Keyword"

echo ""
echo "Search attributes for namespace '${NAMESPACE}':"
temporal operator search-attribute list \
    --address "${TEMPORAL_ADDRESS}" \
    --namespace "${NAMESPACE}" || true

echo ""
echo "Search attributes setup complete"
