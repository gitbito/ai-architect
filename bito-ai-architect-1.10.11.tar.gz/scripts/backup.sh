#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
# Bito's AI Architect Backup Script
# Backs up the database dump, configurations, and indexed data — nothing else.
# Clones, wingman bundles and temp trees are re-derivable and deliberately
# excluded; archiving whole volumes once made each backup embed the backups
# volume itself, compounding until the host disk filled.

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[1;34m'
NC='\033[0m' # No Color

# docker compose vs docker-compose: resolve once (Colima/older hosts ship only the standalone binary).
if docker compose version >/dev/null 2>&1; then COMPOSE="docker compose"; else COMPOSE="docker-compose"; fi

# Configuration
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PLATFORM_DIR="$(dirname "$SCRIPT_DIR")"

# This script also runs standalone (./scripts/backup.sh, cron), where nothing has
# set LOG_FILE -- without this every `2>>"${LOG_FILE:-/dev/null}"` below discards
# the reason and the warnings would name an empty path.
if [ -z "${LOG_FILE:-}" ] && [ -f "${SCRIPT_DIR}/lib/path-manager.sh" ]; then
    # shellcheck source=/dev/null
    . "${SCRIPT_DIR}/lib/path-manager.sh" >/dev/null 2>&1 || true
    command -v bitoarch_resolve_log_file >/dev/null 2>&1 && LOG_FILE="$(bitoarch_resolve_log_file)"
fi
LOG_FILE="${LOG_FILE:-/dev/null}"
ENV_FILE="${PLATFORM_DIR}/.env-bitoarch"
DATE=$(date +%Y%m%d_%H%M%S)

# Source environment for BACKUP_PATH
if [ -f "$ENV_FILE" ]; then
    source "$ENV_FILE"
fi

# Use BACKUP_PATH from config, fallback to container default
BACKUP_DIR="${BACKUP_PATH:-/opt/cis/backups}"

# The env file's DB contract is MYSQL_USER/MYSQL_DATABASE; accept the legacy
# DB_USER/DB_NAME names but fall back to the real keys so dumps authenticate.
DB_USER="${DB_USER:-${MYSQL_USER:-}}"
DB_NAME="${DB_NAME:-${MYSQL_DATABASE:-}}"

# Logging function
log() {
    echo "[$(date +'%Y-%m-%d %H:%M:%S')] $1" | tee -a "$BACKUP_DIR/backup.log"
}

print_status() {
    echo -e "${GREEN}✓${NC} $1"
    log "SUCCESS: $1"
}

print_error() {
    echo -e "${RED}✗${NC} $1"
    log "ERROR: $1"
}

print_info() {
    echo -e "${BLUE}ℹ${NC} $1"
    log "INFO: $1"
}

print_warning() {
    echo -e "${YELLOW}⚠${NC} $1"
    log "WARNING: $1"
}

# Create backup directory structure
create_backup_structure() {
    local backup_name="backup_${DATE}"
    local backup_path="${BACKUP_DIR}/${backup_name}"
    
    mkdir -p "${backup_path}"/{database,configs,volumes,metadata}
    echo "$backup_path"
}

# Backup database with transaction consistency
backup_database() {
    local backup_path="$1"
    local db_backup_path="${backup_path}/database"
    
    print_info "Creating database backup..."
    
    if [ ! -f "$ENV_FILE" ]; then
        print_error "Environment file not found: $ENV_FILE"
        exit 1
    fi
    
    # Source environment variables
    source "$ENV_FILE"
    
    # This is the Compose branch; Kubernetes is served by backup_kubernetes_database
    # alongside the PVC and resource backups. If we are reached on a Kubernetes
    # deployment the dispatcher mis-routed, and continuing would write a
    # database-only archive with empty volumes/ and no cluster resources -- which
    # main() would still exit 0 on, and upgrade.sh would accept as a restore point.
    # Fail closed instead.
    if command -v get_deployment_type >/dev/null 2>&1 \
       && [ "$(get_deployment_type 2>/dev/null)" = "kubernetes" ]; then
        print_error "Kubernetes deployment routed into the Compose backup path -- refusing to write an incomplete backup"
        exit 1
    fi

    # Check if MySQL container is running
    if ! $COMPOSE --env-file "${PLATFORM_DIR}/.env-bitoarch" -f "${PLATFORM_DIR}/docker-compose.yml" ps ai-architect-mysql | grep -q "Up"; then
        print_error "MySQL container is not running"
        exit 1
    fi
    
    # Create full database backup with consistent snapshot
    print_info "Creating full database dump..."
    $COMPOSE --env-file "${PLATFORM_DIR}/.env-bitoarch" -f "${PLATFORM_DIR}/docker-compose.yml" exec -T ai-architect-mysql mysqldump \
        --single-transaction \
        --no-tablespaces \
        --routines \
        --triggers \
        --events \
        --hex-blob \
        --user="$DB_USER" \
        --password="$MYSQL_PASSWORD" \
        "$DB_NAME" > "${db_backup_path}/full_backup.sql"
    
    # Create structure-only backup
    $COMPOSE --env-file "${PLATFORM_DIR}/.env-bitoarch" -f "${PLATFORM_DIR}/docker-compose.yml" exec -T ai-architect-mysql mysqldump \
        --no-data \
        --no-tablespaces \
        --routines \
        --triggers \
        --events \
        --user="$DB_USER" \
        --password="$MYSQL_PASSWORD" \
        "$DB_NAME" > "${db_backup_path}/schema_only.sql"
    
    # Export system configuration (optional legacy table; skip cleanly when absent)
    $COMPOSE --env-file "${PLATFORM_DIR}/.env-bitoarch" -f "${PLATFORM_DIR}/docker-compose.yml" exec -T ai-architect-mysql mysql \
        --user="$DB_USER" \
        --password="$MYSQL_PASSWORD" \
        --database="$DB_NAME" \
        --execute="SELECT * FROM system_config;" \
        --batch --raw > "${db_backup_path}/system_config.tsv" 2>/dev/null || true
    [ -s "${db_backup_path}/system_config.tsv" ] || rm -f "${db_backup_path}/system_config.tsv"
    
    # Plugin databases follow the same dump logic as the base database: enumerate
    # every non-system database beyond DB_NAME (plugins provision their own DBs,
    # e.g. task_analyzer_service) and dump each as plugin-db_<name>.sql. Uses root
    # because plugin DB users are scoped to their own database. Generic by
    # convention — no plugin names here; restore picks these up by filename.
    local _extra_dbs _extra_db _root_pw _pdump
    _root_pw="$(grep -m1 '^MYSQL_ROOT_PASSWORD=' "$ENV_FILE" | cut -d= -f2-)"
    if [ -n "$_root_pw" ]; then
        _extra_dbs="$($COMPOSE --env-file "${PLATFORM_DIR}/.env-bitoarch" -f "${PLATFORM_DIR}/docker-compose.yml" exec -T ai-architect-mysql mysql \
            --user=root --password="$_root_pw" --batch --skip-column-names \
            --execute="SHOW DATABASES;" 2>/dev/null \
            | grep -vxE "information_schema|performance_schema|mysql|sys|${DB_NAME}|temporal.*" || true)"
        for _extra_db in $_extra_dbs; do
            print_info "Backing up plugin database: ${_extra_db}"
            _pdump="${db_backup_path}/plugin-db_${_extra_db}.sql"
            # Best-effort per plugin, but a failure must be visible and must not leave a partial
            # dump behind (restore would import truncated data); stderr goes to the backup log.
            if ! $COMPOSE --env-file "${PLATFORM_DIR}/.env-bitoarch" -f "${PLATFORM_DIR}/docker-compose.yml" exec -T ai-architect-mysql mysqldump \
                --single-transaction --routines --triggers --events --hex-blob \
                --user=root --password="$_root_pw" \
                "$_extra_db" > "$_pdump" 2>>"$BACKUP_DIR/backup.log"; then
                print_warning "Plugin database backup failed for '${_extra_db}'; removed partial dump (see backup.log)"
                rm -f "$_pdump"
            fi
        done
    fi

    # Create metadata file
    cat > "${db_backup_path}/backup_metadata.json" << EOF
{
    "timestamp": "${DATE}",
    "database_name": "${DB_NAME}",
    "backup_type": "full",
    "mysql_version": "$($COMPOSE --env-file "${PLATFORM_DIR}/.env-bitoarch" -f "${PLATFORM_DIR}/docker-compose.yml" exec -T ai-architect-mysql mysql --version | head -1)",
    "platform_version": "${VERSION_CURRENT:-1.0.0}",
    "backup_files": {
        "full_backup": "full_backup.sql",
        "schema_only": "schema_only.sql",
        "system_config": "system_config.tsv"
    }
}
EOF
    
    print_status "Database backup completed"
}

# Backup configuration files
backup_configurations() {
    local backup_path="$1"
    local config_backup_path="${backup_path}/configs"
    
    print_info "Backing up configurations..."
    
    # Copy environment file
    cp "$ENV_FILE" "${config_backup_path}/.env-bitoarch.backup"
    
    # Copy docker-compose and related files
    local config_ok=true
    cp "${PLATFORM_DIR}/docker-compose.yml" "${config_backup_path}/"
    if [ -f "${PLATFORM_DIR}/.env-bitoarch.default" ]; then
        cp "${PLATFORM_DIR}/.env-bitoarch.default" "${config_backup_path}/" \
            || { config_ok=false; print_warning "Failed to back up .env-bitoarch.default"; }
    fi
    
    # Copy service configurations
    if [ -d "${PLATFORM_DIR}/config" ]; then
        cp -r "${PLATFORM_DIR}/config" "${config_backup_path}/" \
            || { config_ok=false; print_warning "Failed to back up ${PLATFORM_DIR}/config"; }
    fi
    
    # Copy service-specific configs
    for service in ai-architect-manager ai-architect-config ai-architect-provider; do
        service_config_dir="${PLATFORM_DIR}/services/${service}/config"
        if [ -d "$service_config_dir" ]; then
            mkdir -p "${config_backup_path}/services/${service}"
            cp -r "$service_config_dir" "${config_backup_path}/services/${service}/" \
                || { config_ok=false; print_warning "Failed to back up ${service} config"; }
        fi
    done
    
    # Plugin configs + service logs (no-op when no plugin is installed).
    local _plugins_root="${BITOARCH_CONFIG_DIR:-$PLATFORM_DIR}/plugins" _pl
    if [ -d "$_plugins_root" ]; then
        mkdir -p "${config_backup_path}/plugins"
        cp -r "$_plugins_root/." "${config_backup_path}/plugins/" 2>/dev/null || true
        for _pl in "$_plugins_root"/*/; do
            [ -d "$_pl" ] || continue
            _pl="$(basename "$_pl")"
            $COMPOSE -p "ai-architect-${_pl}" logs --no-color \
                > "${config_backup_path}/plugins/${_pl}.service.log" 2>/dev/null || true
        done
    fi

    # Plugin state journal (state.json + siblings) follows the same config-backup
    # path as everything above — without it a restore resurrects plugin configs
    # the engine does not know about.
    local _plugins_state="${BITOARCH_VAR_DIR:-/usr/local/var/bitoarch}/plugins"
    if [ -d "$_plugins_state" ]; then
        mkdir -p "${config_backup_path}/plugins-state"
        cp -r "$_plugins_state/." "${config_backup_path}/plugins-state/" 2>/dev/null || true
    fi

    if [ "$config_ok" = "true" ]; then
        print_status "Configuration backup completed"
    else
        print_warning "Configuration backup completed with errors — see warnings above"
    fi
}

# Backup indexed data (the data/index-data subtree of the platform data volume).
# Deliberately NOT a full-volume sweep: clones are re-derivable from git, wingman
# and temp trees are re-downloaded/regenerated, and sweeping every mounted volume
# also archived the backups volume itself — each backup embedded all previous
# ones and grew until the host disk filled. The tarball keeps volume-root-relative
# paths (./data/index-data/...) so restore_volumes extracts it unchanged.
backup_index_data() {
    local backup_path="$1"
    local volume_backup_path="${backup_path}/volumes"

    print_info "Backing up indexed data..."

    # Resolve the real (project-prefixed) volume mounted at the platform data
    # root by a running container; fall back to a name lookup when stopped.
    local data_volume
    data_volume=$(docker ps -q --filter "name=ai-architect-" 2>/dev/null \
        | xargs docker inspect --format '{{range .Mounts}}{{if and (eq .Type "volume") (eq .Destination "/opt/bito/ai-architect")}}{{.Name}}{{"\n"}}{{end}}{{end}}' 2>/dev/null \
        | grep -v '^$' | sort -u | head -1)
    if [ -z "$data_volume" ]; then
        data_volume=$(docker volume ls --format '{{.Name}}' 2>/dev/null | grep -E '(^|_)ai_architect_data$' | head -1)
    fi
    if [ -z "$data_volume" ]; then
        print_warning "Platform data volume not found; indexed data was not backed up"
        return 0
    fi

    if ! docker run --rm -v "${data_volume}:/source:ro" alpine:latest \
        test -d /source/data/index-data 2>>"${LOG_FILE:-/dev/null}"; then
        print_warning "No indexed data in volume ${data_volume} yet; skipping indexed-data backup"
        return 0
    fi

    print_info "Backing up indexed data from volume: $data_volume"
    # indexer-temp is scratch space and may be huge mid-run; never archive it.
    local tar_rc=0
    docker run --rm \
        -v "${data_volume}:/source:ro" \
        -v "${volume_backup_path}:/backup" \
        alpine:latest \
        tar -czf "/backup/${data_volume}.tar.gz" -C /source \
            --exclude='./data/index-data/indexer-temp' \
            --exclude='./data/index-data/indexer-temp/*' \
            ./data/index-data 2>>"${LOG_FILE:-/dev/null}" || tar_rc=$?

    # tar exit 1 is "some files changed while reading" — routine while indexing
    # is running; the archive is still usable. Only exit >=2 means no archive.
    if [ "$tar_rc" -ge 2 ]; then
        rm -f "${volume_backup_path}/${data_volume}.tar.gz"
        print_warning "Indexed data backup failed (reason in ${LOG_FILE})"
    else
        [ "$tar_rc" -eq 1 ] && log "INFO: indexed-data tar reported files changed while reading; the archive has been kept"
        print_status "Indexed data backup completed"
    fi
}

# Create backup manifest
create_backup_manifest() {
    local backup_path="$1"
    local manifest_file="${backup_path}/BACKUP_MANIFEST.json"
    
    print_info "Creating backup manifest..."
    
    # Calculate checksums
    local db_checksum=""
    local config_checksum=""
    
    if [ -f "${backup_path}/database/full_backup.sql" ]; then
        db_checksum=$(sha256sum "${backup_path}/database/full_backup.sql" | cut -d' ' -f1)
    fi
    
    if [ -f "${backup_path}/configs/.env-bitoarch.backup" ]; then
        config_checksum=$(sha256sum "${backup_path}/configs/.env-bitoarch.backup" | cut -d' ' -f1)
    fi
    
    cat > "$manifest_file" << EOF
{
    "backup_info": {
        "timestamp": "${DATE}",
        "platform_version": "${VERSION_CURRENT:-1.0.0}",
        "backup_type": "full",
        "created_by": "$(whoami)",
        "hostname": "$(hostname)"
    },
    "components": {
        "database": {
            "included": true,
            "checksum": "${db_checksum}",
            "size_bytes": $(stat -f%z "${backup_path}/database/full_backup.sql" 2>/dev/null || echo "0")
        },
        "configurations": {
            "included": true,
            "checksum": "${config_checksum}",
            "files_count": $(find "${backup_path}/configs" -type f | wc -l 2>/dev/null || echo "0")
        },
        "index_data": {
            "included": true,
            "archive_count": $(find "${backup_path}/volumes" "${backup_path}/pvcs" -name "*.tar.gz" 2>/dev/null | wc -l | tr -d ' '),
            "contents": "data/index-data only; clones, wingman, temp and the backups store are excluded as re-derivable"
        }
    },
    "restore_instructions": {
        "command": "./scripts/restore.sh $(basename "$backup_path")",
        "prerequisites": ["Docker running", "Platform stopped"],
        "estimated_time_minutes": 10
    }
}
EOF
    
    print_status "Backup manifest created"
}

# Compress backup
compress_backup() {
    local backup_path="$1"
    local backup_name=$(basename "$backup_path")
    local compressed_backup="${BACKUP_DIR}/${backup_name}.tar.gz"
    
    print_info "Compressing backup..."
    
    cd "$BACKUP_DIR"
    tar -czf "${backup_name}.tar.gz" "$backup_name"
    
    # Verify compressed backup
    if [ -f "$compressed_backup" ]; then
        local compressed_size=$(stat -f%z "$compressed_backup" 2>/dev/null || stat -c%s "$compressed_backup" 2>/dev/null || echo "0")
        print_status "Backup compressed: $compressed_backup ($(numfmt --to=iec $compressed_size))"
        
        # Remove uncompressed backup
        rm -rf "$backup_path"
        
        echo "$compressed_backup"
    else
        print_error "Failed to create compressed backup"
        exit 1
    fi
}

# Cleanup old backups. Count-based, not age-based: an age window keeps every
# backup of a young deployment (nothing is ever 30 days old) — exactly when a
# small host can least afford it.
cleanup_old_backups() {
    local retention_count=${BACKUP_RETENTION_COUNT:-3}

    print_info "Cleaning up old backups (keeping the newest ${retention_count})..."

    # Names embed the timestamp (backup_YYYYMMDD_HHMMSS), so a reverse name sort
    # is newest-first and immune to mtime drift from copies/moves.
    find "$BACKUP_DIR" -maxdepth 1 -name "backup_*.tar.gz" -type f 2>/dev/null \
        | sort -r | tail -n +$((retention_count + 1)) \
        | while IFS= read -r old_backup; do rm -f "$old_backup"; done

    local remaining_backups=$(find "$BACKUP_DIR" -maxdepth 1 -name "backup_*.tar.gz" -type f | wc -l | tr -d ' ')
    print_status "Cleanup completed. $remaining_backups backup(s) retained"
}

# Kubernetes backup functions
backup_kubernetes_pvcs() {
    local backup_path="$1"
    local pvc_backup_path="${backup_path}/pvcs"
    local pvc_ok=true
    
    print_info "Backing up Kubernetes PVCs..."

    local namespace="bito-ai-architect"
    # Only the data PVC is archived, and only its data/index-data subtree (same
    # policy as the docker path): clones/wingman/temp/logs are re-derivable, and
    # the backups PVC must never be swept into a backup of itself.
    local pvcs=$(kubectl get pvc -n "$namespace" -o jsonpath='{.items[*].metadata.name}' 2>/dev/null | tr ' ' '\n' | grep -x "bitoarch-data" || echo "")

    if [ -z "$pvcs" ]; then
        print_warning "Data PVC (bitoarch-data) not found; indexed data was not backed up"
        return 0
    fi

    mkdir -p "$pvc_backup_path"

    for pvc in $pvcs; do
        print_info "Backing up PVC: $pvc"
        
        # Create a temporary pod to access PVC
        kubectl run pvc-backup-pod-$$ \
            --namespace="$namespace" \
            --image=busybox:1.36 \
            --restart=Never \
            --overrides="{
              \"apiVersion\": \"v1\",
              \"spec\": {
                \"containers\": [{
                  \"name\": \"backup\",
                  \"image\": \"busybox:1.36\",
                  \"command\": [\"sleep\", \"3600\"],
                  \"volumeMounts\": [{
                    \"name\": \"data\",
                    \"mountPath\": \"/data\"
                  }]
                }],
                \"volumes\": [{
                  \"name\": \"data\",
                  \"persistentVolumeClaim\": {
                    \"claimName\": \"$pvc\"
                  }
                }]
              }
            }" >/dev/null 2>>"${LOG_FILE:-/dev/null}"
        
        # Wait for pod to be ready
        kubectl wait --for=condition=Ready pod/pvc-backup-pod-$$ -n "$namespace" --timeout=60s >/dev/null 2>>"${LOG_FILE:-/dev/null}"
        
        # Backup only the indexed data, with PVC-root-relative paths so the
        # existing restore path extracts the archive at the PVC root unchanged.
        if kubectl exec -n "$namespace" pvc-backup-pod-$$ -- test -d /data/data/index-data 2>>"${LOG_FILE:-/dev/null}"; then
            kubectl exec -n "$namespace" pvc-backup-pod-$$ -- tar czf - -C /data \
                --exclude='./data/index-data/indexer-temp' \
                --exclude='./data/index-data/indexer-temp/*' \
                ./data/index-data > "${pvc_backup_path}/${pvc}.tar.gz" 2>>"${LOG_FILE:-/dev/null}" || {
                pvc_ok=false
                print_warning "Failed to backup PVC: $pvc (reason in ${LOG_FILE})"
            }
        else
            print_warning "No indexed data in PVC ${pvc} yet; skipping indexed-data backup"
        fi
        
        # Cleanup
        # A failed cleanup leaves an orphan pod holding the PVC; the next backup then
        # fails to create its own pod for reasons that look unrelated.
        kubectl delete pod pvc-backup-pod-$$ -n "$namespace" --force --grace-period=0 >/dev/null 2>>"${LOG_FILE:-/dev/null}" \
            || print_warning "Could not remove the temporary pod pvc-backup-pod-$$ in ${namespace}; remove it manually"
    done
    
    if [ "$pvc_ok" = true ]; then
        print_status "PVC backup completed"
    else
        print_warning "PVC backup completed with errors — see the warnings above"
    fi
}

backup_kubernetes_resources() {
    local backup_path="$1"
    local resource_backup_path="${backup_path}/resources"
    
    print_info "Backing up Kubernetes resources..."
    
    local namespace="bito-ai-architect"
    mkdir -p "$resource_backup_path"
    
    local res_failed=""

    # Backup ConfigMaps
    kubectl get configmaps -n "$namespace" -o yaml > "${resource_backup_path}/configmaps.yaml" 2>>"${LOG_FILE:-/dev/null}" || res_failed="${res_failed} configmaps"

    # Backup Secrets (base64 encoded)
    kubectl get secrets -n "$namespace" -o yaml > "${resource_backup_path}/secrets.yaml" 2>>"${LOG_FILE:-/dev/null}" || res_failed="${res_failed} secrets"

    # Backup Helm release values
    if command -v helm >/dev/null 2>&1; then
        helm get values bitoarch -n "$namespace" > "${resource_backup_path}/helm-values.yaml" 2>>"${LOG_FILE:-/dev/null}" || res_failed="${res_failed} helm-values"
    fi

    # Backup deployments
    kubectl get deployments -n "$namespace" -o yaml > "${resource_backup_path}/deployments.yaml" 2>>"${LOG_FILE:-/dev/null}" || res_failed="${res_failed} deployments"

    # Backup services
    kubectl get services -n "$namespace" -o yaml > "${resource_backup_path}/services.yaml" 2>>"${LOG_FILE:-/dev/null}" || res_failed="${res_failed} services"

    if [ -z "$res_failed" ]; then
        print_status "Kubernetes resources backed up"
    else
        print_warning "Kubernetes resources backed up with failures:${res_failed} (check RBAC permissions)"
    fi
}

backup_kubernetes_database() {
    local backup_path="$1"
    local db_backup_path="${backup_path}/database"
    
    print_info "Backing up database from Kubernetes..."
    
    local namespace="bito-ai-architect"
    
    # Find MySQL pod
    local mysql_pod=$(kubectl get pods -n "$namespace" -l "app.kubernetes.io/component=mysql" -o jsonpath='{.items[0].metadata.name}' 2>/dev/null || echo "")
    
    if [ -z "$mysql_pod" ]; then
        print_error "MySQL pod not found"
        return 1
    fi
    
    # Get credentials from secrets
    local db_user=$(kubectl get secret bitoarch-secrets -n "$namespace" -o jsonpath='{.data.mysql-user}' 2>/dev/null | base64 -d)
    local db_password=$(kubectl get secret bitoarch-secrets -n "$namespace" -o jsonpath='{.data.mysql-password}' 2>/dev/null | base64 -d)
    local db_name=$(kubectl get secret bitoarch-secrets -n "$namespace" -o jsonpath='{.data.mysql-database}' 2>/dev/null | base64 -d)
    
    mkdir -p "$db_backup_path"
    
    # Create full database backup
    kubectl exec -n "$namespace" "$mysql_pod" -- mysqldump \
        --single-transaction \
        --no-tablespaces \
        --routines \
        --triggers \
        --events \
        --hex-blob \
        --user="$db_user" \
        --password="$db_password" \
        "$db_name" > "${db_backup_path}/full_backup.sql" 2>/dev/null || {
        print_error "Database backup failed"
        return 1
    }
    
    # Create schema-only backup
    kubectl exec -n "$namespace" "$mysql_pod" -- mysqldump \
        --no-data \
        --no-tablespaces \
        --routines \
        --triggers \
        --events \
        --user="$db_user" \
        --password="$db_password" \
        "$db_name" > "${db_backup_path}/schema_only.sql" 2>/dev/null || true
    
    print_status "Database backup completed"
}

backup_kubernetes() {
    local backup_path="$1"
    
    print_info "Creating Kubernetes backup..."
    
    backup_kubernetes_database "$backup_path"
    backup_kubernetes_pvcs "$backup_path"
    backup_kubernetes_resources "$backup_path"
    
    print_status "Kubernetes backup completed"
}

# Main backup function
main() {
    echo -e "${BLUE}Bito's AI Architect Backup - Zero Data Loss${NC}"
    echo "================================================"
    echo ""
    
    # Create backup directory if it doesn't exist
    mkdir -p "$BACKUP_DIR"
    
    # Detect deployment type. The marker lives in the config dir -- see
    # path-manager's get_deployment_type_file() -- not in the install dir. Reading
    # PLATFORM_DIR here found nothing on the installed layouts, so every Kubernetes
    # deployment silently fell through to "docker-compose" and took the Compose
    # branch below: backup_database failed against a pod-hosted MySQL, and
    # backup_kubernetes_pvcs / backup_kubernetes_resources never ran at all.
    local deployment_type=""
    if ! command -v get_deployment_type >/dev/null 2>&1 \
       && [ -f "${SCRIPT_DIR}/lib/path-manager.sh" ]; then
        # shellcheck source=/dev/null
        . "${SCRIPT_DIR}/lib/path-manager.sh" >/dev/null 2>&1 || true
    fi
    if command -v get_deployment_type >/dev/null 2>&1; then
        deployment_type="$(get_deployment_type 2>/dev/null)"
    fi
    case "$deployment_type" in
        docker-compose|kubernetes) ;;
        *)
            # Fall back to the install-dir copy for layouts path-manager cannot
            # resolve, then to the historical default.
            if [ -f "${PLATFORM_DIR}/.deployment-type" ]; then
                deployment_type=$(cat "${PLATFORM_DIR}/.deployment-type")
            else
                deployment_type="docker-compose"
            fi
            ;;
    esac

    # Pin to the cluster.yaml context so a K8s backup targets the right cluster on
    # a drifted current-context (no-op when inherited from the CLI / no context).
    if [ "$deployment_type" = "kubernetes" ]; then
        command -v _pin_kube_context >/dev/null 2>&1 \
            || source "${SCRIPT_DIR}/lib/cluster-yaml.sh" 2>/dev/null || true
        if command -v _pin_kube_context >/dev/null 2>&1; then
            _pin_kube_context || exit 1
        fi
    fi

    # Check if platform is running
    if [ "$deployment_type" = "kubernetes" ]; then
        if ! kubectl get namespace bito-ai-architect >/dev/null 2>&1; then
            print_warning "Kubernetes namespace not found. Creating offline backup..."
        fi
    else
        if ! $COMPOSE --env-file "${PLATFORM_DIR}/.env-bitoarch" -f "${PLATFORM_DIR}/docker-compose.yml" ps | grep -q "Up"; then
            print_warning "Bito's AI Architect is not running. Creating offline backup..."
        fi
    fi
    
    # Create backup structure
    local backup_path=$(create_backup_structure)
    local backup_name=$(basename "$backup_path")
    
    print_info "Starting backup: $backup_name"
    
    # Perform backup components based on deployment type
    if [ "$deployment_type" = "kubernetes" ]; then
        backup_kubernetes "$backup_path"
        backup_configurations "$backup_path"
    else
        backup_database "$backup_path"
        backup_configurations "$backup_path"
        backup_index_data "$backup_path"
    fi
    
    create_backup_manifest "$backup_path"
    
    # Compress and finalize
    local compressed_backup=$(compress_backup "$backup_path")
    
    # Cleanup old backups
    cleanup_old_backups
    
    echo ""
    print_status "Backup completed successfully!"
    echo -e "${BLUE}Backup location:${NC} $compressed_backup"
    echo -e "${BLUE}Restore command:${NC} ./scripts/restore.sh $backup_name"
    echo ""
}

# Handle command line arguments
case "${1:-}" in
    --help|-h)
        echo "Bito's AI Architect Backup Script"
        echo ""
        echo "Usage: $0 [options]"
        echo ""
        echo "Options:"
        echo "  --help, -h      Show this help message"
        echo "  --quick         Quick backup (database + configs only)"
        echo "  --full          Full backup (database + configs + indexed data) [default]"
        echo ""
        echo "Environment variables:"
        echo "  BACKUP_RETENTION_COUNT   Number of backups to keep (default: 3)"
        ;;
    --quick)
        print_info "Quick backup mode selected"
        # Override functions for quick backup
        backup_index_data() { print_info "Skipping indexed data in quick mode"; }
        main
        ;;
    --full|"")
        main
        ;;
    *)
        echo "Unknown option: $1"
        echo "Use --help for usage information"
        exit 1
        ;;
esac
