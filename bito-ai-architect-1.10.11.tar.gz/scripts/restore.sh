#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
# Bito's AI Architect Restore Script - Zero Data Loss Recovery
# Restores database, configurations, and service data from backup
# Supports both Docker Compose and Kubernetes deployments

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[1;34m'
NC='\033[0m' # No Color

# docker compose vs docker-compose: resolve once (Colima/older hosts ship only the standalone binary).
if docker compose version >/dev/null 2>&1; then COMPOSE="docker compose"; else COMPOSE="docker-compose"; fi

# Configuration
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PLATFORM_DIR="$(dirname "$SCRIPT_DIR")"

# This script also runs standalone (./scripts/restore.sh <backup>), where nothing
# has set LOG_FILE -- without this every `2>>"${LOG_FILE:-/dev/null}"` below
# discards the reason and the warnings render "(reason in )" with an empty path.
# Same block as backup.sh.
if [ -z "${LOG_FILE:-}" ] && [ -f "${SCRIPT_DIR}/lib/path-manager.sh" ]; then
    # shellcheck source=/dev/null
    . "${SCRIPT_DIR}/lib/path-manager.sh" >/dev/null 2>&1 || true
    command -v bitoarch_resolve_log_file >/dev/null 2>&1 && LOG_FILE="$(bitoarch_resolve_log_file)"
fi
LOG_FILE="${LOG_FILE:-/dev/null}"
ENV_FILE="${PLATFORM_DIR}/.env-bitoarch"
TEMP_RESTORE_DIR="${PLATFORM_DIR}/temp_restore"

# Source environment for BACKUP_PATH
if [ -f "$ENV_FILE" ]; then
    source "$ENV_FILE"
fi

# Use BACKUP_PATH from config, fallback to container default
BACKUP_DIR="${BACKUP_PATH:-/opt/cis/backups}"

# The env file's DB contract is MYSQL_USER/MYSQL_DATABASE; accept the legacy
# DB_USER/DB_NAME names but fall back to the real keys so imports authenticate.
DB_USER="${DB_USER:-${MYSQL_USER:-}}"
DB_NAME="${DB_NAME:-${MYSQL_DATABASE:-}}"

# Logging function
log() {
    echo "[$(date +'%Y-%m-%d %H:%M:%S')] $1" | tee -a "$BACKUP_DIR/restore.log"
}

print_status() {
    echo -e "${GREEN}✓${NC} $1"
    log "SUCCESS: $1"
}

print_error() {
    echo -e "${RED}✗${NC} $1"
    log "ERROR: $1"
}

print_info() {
    echo -e "${BLUE}ℹ${NC} $1"
    log "INFO: $1"
}

print_warning() {
    echo -e "${YELLOW}⚠${NC} $1"
    log "WARNING: $1"
}

# Validate backup file
validate_backup() {
    local backup_file="$1"
    
    print_info "Validating backup file..."
    
    if [ ! -f "$backup_file" ]; then
        print_error "Backup file not found: $backup_file"
        exit 1
    fi
    
    # Check if it's a valid tar.gz file
    if ! tar -tzf "$backup_file" >/dev/null 2>&1; then
        print_error "Invalid backup file format: $backup_file"
        exit 1
    fi
    
    # Check for required components
    local required_files=("BACKUP_MANIFEST.json" "database/full_backup.sql" "configs/.env-bitoarch.backup")
    
    for file in "${required_files[@]}"; do
        if ! tar -tzf "$backup_file" | grep -q "$file"; then
            print_error "Missing required component in backup: $file"
            exit 1
        fi
    done
    
    print_status "Backup file validation passed"
}

# Extract backup
extract_backup() {
    local backup_file="$1"
    local extract_dir="$2"
    
    print_info "Extracting backup..."
    
    mkdir -p "$extract_dir"
    cd "$(dirname "$extract_dir")"
    tar -xzf "$backup_file"
    
    print_status "Backup extracted to: $extract_dir"
}

# Read backup manifest
read_backup_manifest() {
    local extract_dir="$1"
    local manifest_file="${extract_dir}/BACKUP_MANIFEST.json"
    
    if [ ! -f "$manifest_file" ]; then
        print_error "Backup manifest not found"
        exit 1
    fi
    
    # Parse manifest using basic shell commands (no jq dependency)
    BACKUP_VERSION=$(grep '"platform_version"' "$manifest_file" | cut -d'"' -f4)
    BACKUP_TIMESTAMP=$(grep '"timestamp"' "$manifest_file" | cut -d'"' -f4)
    
    print_info "Backup information:"
    echo "  - Platform Version: $BACKUP_VERSION"
    echo "  - Created: $BACKUP_TIMESTAMP"
}

# Pre-restore validation
pre_restore_validation() {
    local extract_dir="$1"
    
    print_info "Running pre-restore validation..."
    
    # Check if platform is currently running
    if $COMPOSE --env-file "${PLATFORM_DIR}/.env-bitoarch" -f "${PLATFORM_DIR}/docker-compose.yml" ps | grep -q "Up"; then
        print_warning "Bito's AI Architect is currently running"
        
        # Check if running in interactive terminal
        if [ -t 0 ]; then
            # Interactive mode - ask user
            read -p "Stop the platform before restore? [y/N]: " -r REPLY
            if [[ $REPLY =~ ^[Yy]$ ]]; then
                print_info "Stopping Bito's AI Architect..."
                $COMPOSE --env-file "${PLATFORM_DIR}/.env-bitoarch" -f "${PLATFORM_DIR}/docker-compose.yml" down
            else
                print_error "Cannot restore while platform is running"
                exit 1
            fi
        else
            # Non-interactive mode (CI/CD) - default to not stopping (safe default)
            print_error "Cannot restore while platform is running (non-interactive mode)"
            print_info "Stop the platform manually with: docker compose down"
            exit 1
        fi
    fi
    
    # Validate database backup integrity
    local db_backup="${extract_dir}/database/full_backup.sql"
    if [ -f "$db_backup" ]; then
        # Basic SQL file validation
        if ! grep -q "CREATE\|INSERT\|UPDATE" "$db_backup"; then
            print_error "Database backup appears to be corrupted"
            exit 1
        fi
        
        # Check for backup completion marker
        if ! tail -5 "$db_backup" | grep -q "Dump completed"; then
            print_warning "Database backup may be incomplete"
        fi
    fi
    
    print_status "Pre-restore validation completed"
}

# Create pre-restore backup
create_pre_restore_backup() {
    print_info "Creating pre-restore backup of current state..."
    
    if [ -f "$ENV_FILE" ]; then
        # Create backup using existing backup script
        "${SCRIPT_DIR}/backup.sh" --quick
        print_status "Pre-restore backup created"
    else
        print_warning "No current installation found, skipping pre-restore backup"
    fi
}

# Restore configurations
restore_configurations() {
    local extract_dir="$1"
    local config_dir="${extract_dir}/configs"
    
    print_info "Restoring configurations..."
    
    # Restore environment file
    if [ -f "${config_dir}/.env-bitoarch.backup" ]; then
        cp "${config_dir}/.env-bitoarch.backup" "$ENV_FILE"
        chmod 600 "$ENV_FILE"
        print_status "Environment configuration restored"
    fi
    
    # Restore docker-compose.yml if it exists in backup
    if [ -f "${config_dir}/docker-compose.yml" ]; then
        cp "${config_dir}/docker-compose.yml" "${PLATFORM_DIR}/"
        print_status "Docker Compose configuration restored"
    fi
    
    # Restore service configurations
    if [ -d "${config_dir}/services" ]; then
        if cp -r "${config_dir}/services" "${PLATFORM_DIR}/"; then
            print_status "Service configurations restored"
        else
            print_warning "Service configuration restore failed — see errors above"
            RESTORE_PARTIAL_FAILURE="${RESTORE_PARTIAL_FAILURE:+${RESTORE_PARTIAL_FAILURE}, }service configuration"
        fi
    fi
    
    # Restore platform configurations
    if [ -d "${config_dir}/config" ]; then
        if cp -r "${config_dir}/config" "${PLATFORM_DIR}/"; then
            print_status "Platform configurations restored"
        else
            print_warning "Platform configuration restore failed — see errors above"
            RESTORE_PARTIAL_FAILURE="${RESTORE_PARTIAL_FAILURE:+${RESTORE_PARTIAL_FAILURE}, }platform configuration"
        fi
    fi

    # Restore plugin configs + the plugin state journal (mirrors backup_configurations:
    # configs/plugins -> BITOARCH_CONFIG_DIR/plugins, configs/plugins-state -> the
    # journal dir). Without the journal the engine forgets the restored plugins.
    if [ -d "${config_dir}/plugins" ]; then
        local _plugins_root="${BITOARCH_CONFIG_DIR:-/usr/local/etc/bitoarch}/plugins"
        mkdir -p "$_plugins_root"
        cp -r "${config_dir}/plugins/." "$_plugins_root/" 2>/dev/null || true
        rm -f "$_plugins_root"/*.service.log 2>/dev/null || true
        print_status "Plugin configurations restored"
    fi
    if [ -d "${config_dir}/plugins-state" ]; then
        local _plugins_state="${BITOARCH_VAR_DIR:-/usr/local/var/bitoarch}/plugins"
        mkdir -p "$_plugins_state"
        cp -r "${config_dir}/plugins-state/." "$_plugins_state/" 2>/dev/null || true
        print_status "Plugin state journal restored"
    fi
}

# Restore database
restore_database() {
    local extract_dir="$1"
    local db_dir="${extract_dir}/database"
    
    print_info "Starting database restore..."
    
    # Source environment variables
    source "$ENV_FILE"
    
    # Start MySQL container if not running
    print_info "Starting MySQL container..."
    $COMPOSE --env-file "${PLATFORM_DIR}/.env-bitoarch" -f "${PLATFORM_DIR}/docker-compose.yml" up -d ai-architect-mysql
    
    # Wait for MySQL to be ready
    local max_attempts=60
    local attempt=1
    
    while [ $attempt -le $max_attempts ]; do
        if $COMPOSE --env-file "${PLATFORM_DIR}/.env-bitoarch" -f "${PLATFORM_DIR}/docker-compose.yml" exec -T ai-architect-mysql \
           mysqladmin ping -h localhost -u "$MYSQL_USER" -p"$MYSQL_PASSWORD" --silent >/dev/null 2>&1; then
            break
        fi
        
        print_info "Waiting for MySQL to be ready... (attempt $attempt/$max_attempts)"
        sleep 5
        attempt=$((attempt + 1))
    done
    
    if [ $attempt -gt $max_attempts ]; then
        print_error "MySQL failed to start within expected time"
        exit 1
    fi
    
    print_status "MySQL is ready"
    
    # Drop and recreate database for clean restore
    print_info "Preparing database for restore..."
    $COMPOSE --env-file "${PLATFORM_DIR}/.env-bitoarch" -f "${PLATFORM_DIR}/docker-compose.yml" exec -T ai-architect-mysql mysql \
        --user="root" \
        --password="$MYSQL_ROOT_PASSWORD" \
        --execute="DROP DATABASE IF EXISTS ${DB_NAME}; CREATE DATABASE ${DB_NAME} CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"
    
    # Restore full database backup
    print_info "Restoring database data..."
    if [ -f "${db_dir}/full_backup.sql" ]; then
        $COMPOSE --env-file "${PLATFORM_DIR}/.env-bitoarch" -f "${PLATFORM_DIR}/docker-compose.yml" exec -T ai-architect-mysql mysql \
            --user="$DB_USER" \
            --password="$MYSQL_PASSWORD" \
            --database="$DB_NAME" < "${db_dir}/full_backup.sql"
        print_status "Database data restored successfully"
    else
        print_error "Database backup file not found"
        exit 1
    fi
    
    # Restore plugin databases (plugin-db_<name>.sql, written by backup_database).
    # Root creds: plugin DB users are scoped to their own database and may not
    # exist yet on a fresh host — CREATE DATABASE first, then import.
    local _pdump _pdb _root_pw
    _root_pw="$(grep -m1 '^MYSQL_ROOT_PASSWORD=' "${PLATFORM_DIR}/.env-bitoarch" | cut -d= -f2-)"
    for _pdump in "${db_dir}"/plugin-db_*.sql; do
        [ -f "$_pdump" ] || continue
        _pdb="$(basename "$_pdump" .sql)"; _pdb="${_pdb#plugin-db_}"
        if [ -n "$_root_pw" ]; then
            print_info "Restoring plugin database: ${_pdb}"
            $COMPOSE --env-file "${PLATFORM_DIR}/.env-bitoarch" -f "${PLATFORM_DIR}/docker-compose.yml" exec -T ai-architect-mysql mysql \
                --user=root --password="$_root_pw" \
                --execute="CREATE DATABASE IF NOT EXISTS \`${_pdb}\`;" 2>/dev/null || true
            $COMPOSE --env-file "${PLATFORM_DIR}/.env-bitoarch" -f "${PLATFORM_DIR}/docker-compose.yml" exec -T ai-architect-mysql mysql \
                --user=root --password="$_root_pw" \
                --database="$_pdb" < "$_pdump" \
                && print_status "Plugin database restored: ${_pdb}" \
                || print_warning "Plugin database restore failed: ${_pdb}"
        fi
    done

    # Restore binary logs for point-in-time recovery if available
    if [ -f "${db_dir}/binlogs.tar.gz" ]; then
        print_info "Restoring binary logs..."
        $COMPOSE --env-file "${PLATFORM_DIR}/.env-bitoarch" -f "${PLATFORM_DIR}/docker-compose.yml" exec ai-architect-mysql \
            sh -c "cd /var/log/mysql && rm -f mysql-bin.*" 2>/dev/null || true
        
        if cat "${db_dir}/binlogs.tar.gz" | $COMPOSE --env-file "${PLATFORM_DIR}/.env-bitoarch" -f "${PLATFORM_DIR}/docker-compose.yml" exec -T ai-architect-mysql \
            sh -c "cd /var/log/mysql && tar -xzf -"; then
            print_status "Binary logs restored"
        else
            print_warning "Binary log restore failed — point-in-time recovery data was not restored"
            RESTORE_PARTIAL_FAILURE="${RESTORE_PARTIAL_FAILURE:+${RESTORE_PARTIAL_FAILURE}, }binary logs"
        fi
    fi
    
    # Validate restored database
    validate_restored_database
}

# Validate restored database
validate_restored_database() {
    print_info "Validating restored database..."
    
    source "$ENV_FILE"
    
    # Check basic connectivity
    $COMPOSE --env-file "${PLATFORM_DIR}/.env-bitoarch" -f "${PLATFORM_DIR}/docker-compose.yml" exec -T ai-architect-mysql mysql \
        --user="$DB_USER" \
        --password="$DB_PASSWORD" \
        --database="$DB_NAME" \
        --execute="SELECT 1;" >/dev/null
    
    # Check critical tables exist
    local critical_tables=("repositories" "analysis_results" "system_config" "service_health")
    
    for table in "${critical_tables[@]}"; do
        local table_exists=$($COMPOSE --env-file "${PLATFORM_DIR}/.env-bitoarch" -f "${PLATFORM_DIR}/docker-compose.yml" exec -T ai-architect-mysql mysql \
            --user="$DB_USER" \
            --password="$DB_PASSWORD" \
            --database="$DB_NAME" \
            --execute="SELECT COUNT(*) FROM information_schema.tables WHERE table_schema='$DB_NAME' AND table_name='$table';" \
            --batch --raw | tail -1)
        
        if [ "$table_exists" != "1" ]; then
            print_error "Critical table missing after restore: $table"
            exit 1
        fi
    done
    
    # Check system configuration
    local config_count=$($COMPOSE --env-file "${PLATFORM_DIR}/.env-bitoarch" -f "${PLATFORM_DIR}/docker-compose.yml" exec -T ai-architect-mysql mysql \
        --user="$DB_USER" \
        --password="$DB_PASSWORD" \
        --database="$DB_NAME" \
        --execute="SELECT COUNT(*) FROM system_config;" \
        --batch --raw | tail -1)
    
    if [ "$config_count" -lt "1" ]; then
        print_warning "System configuration table is empty"
    fi
    
    print_status "Database validation completed"
}

# Restore Docker volumes
restore_volumes() {
    local extract_dir="$1"
    local volume_dir="${extract_dir}/volumes"
    
    if [ ! -d "$volume_dir" ]; then
    local vol_restore_ok=true
        print_info "No volume backups found, skipping volume restore"
        return
    fi
    
    print_info "Restoring Docker volumes..."
    
    # Get list of volume backups
    for volume_backup in "$volume_dir"/*.tar.gz; do
        if [ -f "$volume_backup" ]; then
            local volume_name=$(basename "$volume_backup" .tar.gz)
            
            print_info "Restoring volume: $volume_name"
            
            # Create volume if it doesn't exist
            docker volume create "$volume_name" >/dev/null 2>>"${LOG_FILE:-/dev/null}" \
                || { print_warning "Failed to create volume $volume_name (reason in ${LOG_FILE})"
                     RESTORE_PARTIAL_FAILURE="${RESTORE_PARTIAL_FAILURE:+${RESTORE_PARTIAL_FAILURE}, }docker volume ${volume_name}"; }
            
            # Restore volume data
            docker run --rm \
                -v "${volume_name}:/target" \
                -v "$volume_dir:/backup" \
                alpine:latest \
                sh -c "cd /target && tar -xzf /backup/${volume_name}.tar.gz" || {
                vol_restore_ok=false
                RESTORE_PARTIAL_FAILURE="${RESTORE_PARTIAL_FAILURE:+${RESTORE_PARTIAL_FAILURE}, }volume ${volume_name}"
                print_warning "Failed to restore volume: $volume_name"
            }
        fi
    done
    
    # A restore that lost a volume must not report completion -- the operator would
    # bring the platform up believing the data is back.
    if [ "$vol_restore_ok" = true ]; then
        print_status "Volume restore completed"
    else
        print_warning "Volume restore completed with errors — see the warnings above"
    fi
}

# Restore service data
restore_service_data() {
    local extract_dir="$1"
    local service_dir="${extract_dir}/services"
    
    if [ ! -d "$service_dir" ]; then
        print_info "No service data backups found, skipping service data restore"
        return
    fi
    
    print_info "Restoring service data..."
    
    # Restore ai-architect-provider metadata if available
    if [ -f "${service_dir}/ai-architect-provider-metadata.tar.gz" ]; then
        print_info "Restoring ai-architect-provider metadata..."
        
        # Start ai-architect-provider temporarily to restore metadata
        $COMPOSE --env-file "${PLATFORM_DIR}/.env-bitoarch" -f "${PLATFORM_DIR}/docker-compose.yml" up -d ai-architect-provider
        sleep 10
        
        # Restore metadata
        local provider_meta_ok=true
        cat "${service_dir}/ai-architect-provider-metadata.tar.gz" | \
        $COMPOSE --env-file "${PLATFORM_DIR}/.env-bitoarch" -f "${PLATFORM_DIR}/docker-compose.yml" exec -T ai-architect-provider \
            sh -c "cd /app && tar -xzf -" || provider_meta_ok=false

        $COMPOSE --env-file "${PLATFORM_DIR}/.env-bitoarch" -f "${PLATFORM_DIR}/docker-compose.yml" stop ai-architect-provider

        if [ "$provider_meta_ok" != "true" ]; then
            # Not fatal (set -e would abort the whole restore), but the final
            # summary must not claim a clean restore.
            RESTORE_PARTIAL_FAILURE="${RESTORE_PARTIAL_FAILURE:+${RESTORE_PARTIAL_FAILURE}, }provider metadata"
            print_warning "Provider metadata restore failed — see errors above"
            return 0
        fi
    fi
    
    print_status "Service data restore completed"
}

# Kubernetes restore functions
restore_kubernetes_database() {
    local extract_dir="$1"
    local db_dir="${extract_dir}/database"
    
    print_info "Restoring database in Kubernetes..."
    
    local namespace="bito-ai-architect"
    
    # Find MySQL pod
    local mysql_pod=$(kubectl get pods -n "$namespace" -l "app.kubernetes.io/component=mysql" -o jsonpath='{.items[0].metadata.name}' 2>/dev/null || echo "")
    
    if [ -z "$mysql_pod" ]; then
        print_error "MySQL pod not found"
        return 1
    fi
    
    # Wait for MySQL to be ready
    print_info "Waiting for MySQL pod to be ready..."
    kubectl wait --for=condition=Ready pod/"$mysql_pod" -n "$namespace" --timeout=300s || {
        print_error "MySQL pod failed to become ready"
        return 1
    }
    
    # Get credentials from secrets
    local db_user=$(kubectl get secret bitoarch-secrets -n "$namespace" -o jsonpath='{.data.mysql-user}' 2>/dev/null | base64 -d)
    local db_password=$(kubectl get secret bitoarch-secrets -n "$namespace" -o jsonpath='{.data.mysql-password}' 2>/dev/null | base64 -d)
    local db_name=$(kubectl get secret bitoarch-secrets -n "$namespace" -o jsonpath='{.data.mysql-database}' 2>/dev/null | base64 -d)
    local root_password=$(kubectl get secret bitoarch-secrets -n "$namespace" -o jsonpath='{.data.mysql-root-password}' 2>/dev/null | base64 -d)
    
    # Drop and recreate database for clean restore
    print_info "Preparing database for restore..."
    kubectl exec -n "$namespace" "$mysql_pod" -- mysql \
        --user="root" \
        --password="$root_password" \
        --execute="DROP DATABASE IF EXISTS ${db_name}; CREATE DATABASE ${db_name} CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;" || {
        print_error "Failed to prepare database"
        return 1
    }
    
    # Restore full database backup
    print_info "Restoring database data..."
    if [ -f "${db_dir}/full_backup.sql" ]; then
        kubectl exec -i -n "$namespace" "$mysql_pod" -- mysql \
            --user="$db_user" \
            --password="$db_password" \
            --database="$db_name" < "${db_dir}/full_backup.sql" || {
            print_error "Database restore failed"
            return 1
        }
        print_status "Database data restored successfully"
    else
        print_error "Database backup file not found"
        return 1
    fi
    
    # Validate restored database
    validate_kubernetes_database "$namespace" "$mysql_pod" "$db_user" "$db_password" "$db_name"
}

restore_kubernetes_pvcs() {
    local extract_dir="$1"
    local pvc_backup_path="${extract_dir}/pvcs"
    
    if [ ! -d "$pvc_backup_path" ]; then
    local pvc_restore_ok=true
        print_info "No PVC backups found, skipping PVC restore"
        return 0
    fi
    
    print_info "Restoring Kubernetes PVCs..."
    
    local namespace="bito-ai-architect"
    
    for pvc_backup in "$pvc_backup_path"/*.tar.gz; do
        if [ -f "$pvc_backup" ]; then
            local pvc_name=$(basename "$pvc_backup" .tar.gz)
            
            print_info "Restoring PVC: $pvc_name"
            
            # Check if PVC exists
            if ! kubectl get pvc "$pvc_name" -n "$namespace" >/dev/null 2>&1; then
                print_warning "PVC $pvc_name does not exist, skipping"
                continue
            fi
            
            # Create a temporary pod to restore PVC
            kubectl run pvc-restore-pod-$$ \
                --namespace="$namespace" \
                --image=busybox:1.36 \
                --restart=Never \
                --overrides="{
                  \"apiVersion\": \"v1\",
                  \"spec\": {
                    \"containers\": [{
                      \"name\": \"restore\",
                      \"image\": \"busybox:1.36\",
                      \"command\": [\"sleep\", \"3600\"],
                      \"volumeMounts\": [{
                        \"name\": \"data\",
                        \"mountPath\": \"/data\"
                      }]
                    }],
                    \"volumes\": [{
                      \"name\": \"data\",
                      \"persistentVolumeClaim\": {
                        \"claimName\": \"$pvc_name\"
                      }
                    }]
                  }
                }" >/dev/null 2>&1
            
            # Wait for pod to be ready
            kubectl wait --for=condition=Ready pod/pvc-restore-pod-$$ -n "$namespace" --timeout=60s >/dev/null 2>&1
            
            # Restore PVC data
            cat "$pvc_backup" | kubectl exec -i -n "$namespace" pvc-restore-pod-$$ -- tar xzf - -C /data || {
                pvc_restore_ok=false
                RESTORE_PARTIAL_FAILURE="${RESTORE_PARTIAL_FAILURE:+${RESTORE_PARTIAL_FAILURE}, }pvc ${pvc_name}"
                print_warning "Failed to restore PVC: $pvc_name"
            }
            
            # Cleanup
            kubectl delete pod pvc-restore-pod-$$ -n "$namespace" --force --grace-period=0 >/dev/null 2>&1
        fi
    done
    
    if [ "$pvc_restore_ok" = true ]; then
        print_status "PVC restore completed"
    else
        print_warning "PVC restore completed with errors — see the warnings above"
    fi
}

restore_kubernetes_resources() {
    local extract_dir="$1"
    local resource_backup_path="${extract_dir}/resources"
    
    if [ ! -d "$resource_backup_path" ]; then
        print_info "No Kubernetes resource backups found, skipping resource restore"
        return 0
    fi
    
    print_info "Restoring Kubernetes resources..."
    
    local namespace="bito-ai-architect"
    
    # Note: ConfigMaps and Secrets should not be restored from backup as they
    # will be regenerated from .env-bitoarch file during helm upgrade
    print_info "ConfigMaps and Secrets will be regenerated from environment file"
    
    print_info "Helm values will be regenerated from environment file"
    
    print_status "Kubernetes resources restore completed"
}

validate_kubernetes_database() {
    local namespace="$1"
    local mysql_pod="$2"
    local db_user="$3"
    local db_password="$4"
    local db_name="$5"
    
    print_info "Validating restored database..."
    
    # Check basic connectivity
    kubectl exec -n "$namespace" "$mysql_pod" -- mysql \
        --user="$db_user" \
        --password="$db_password" \
        --database="$db_name" \
        --execute="SELECT 1;" >/dev/null || {
        print_error "Database connectivity test failed"
        return 1
    }
    
    # Check critical tables exist
    local critical_tables=("repositories" "analysis_results" "system_config" "service_health")
    
    for table in "${critical_tables[@]}"; do
        local table_exists=$(kubectl exec -n "$namespace" "$mysql_pod" -- mysql \
            --user="$db_user" \
            --password="$db_password" \
            --database="$db_name" \
            --execute="SELECT COUNT(*) FROM information_schema.tables WHERE table_schema='$db_name' AND table_name='$table';" \
            --batch --raw 2>/dev/null | tail -1)
        
        if [ "$table_exists" != "1" ]; then
            print_error "Critical table missing after restore: $table"
            return 1
        fi
    done
    
    print_status "Database validation completed"
}

restore_kubernetes() {
    local extract_dir="$1"
    
    print_info "Starting Kubernetes restore..."
    
    local namespace="bito-ai-architect"
    
    # Check if namespace exists
    if ! kubectl get namespace "$namespace" >/dev/null 2>&1; then
        print_error "Kubernetes namespace $namespace not found"
        print_info "Please deploy the platform first using: ./setup.sh --deploy kubernetes"
        return 1
    fi
    
    # Scale down deployments so nothing writes while we restore. An empty
    # namespace is the normal disaster-recovery case — `kubectl scale --all`
    # exits non-zero when it matches nothing, which is not a failure and must
    # not abort the restore. Only a genuine scale failure with deployments
    # present means pods may still be writing.
    print_info "Scaling down application deployments..."
    # Three outcomes, not two. A FAILED list (RBAC denial, unreachable API server)
    # produces the same empty stdout as a genuinely empty namespace, so testing only
    # for emptiness would read "cannot check" as "nothing to scale" and restore over
    # live, writing pods.
    local _deploys _dep_rc
    _deploys="$(kubectl get deployments -n "$namespace" -o name 2>>"${LOG_FILE:-/dev/null}")"; _dep_rc=$?
    if [ "$_dep_rc" -ne 0 ]; then
        print_error "Could not list deployments in ${namespace} — aborting restore (cannot confirm nothing is writing; see ${LOG_FILE})"
        return 1
    fi
    if [ -n "$_deploys" ]; then
        # Route stderr to the log like the `get deployments` above: kubectl's reason
        # (RBAC denial, API server unreachable) is the one line support needs to see
        # for an aborted restore, and it was reaching the terminal only.
        if ! kubectl scale deployment --all --replicas=0 -n "$namespace" 2>>"${LOG_FILE:-/dev/null}"; then
            print_error "Could not scale deployments down — aborting restore (pods may still be writing; see ${LOG_FILE})"
            return 1
        fi
        sleep 10
    else
        print_info "No deployments to scale down (empty namespace) — continuing"
    fi
    
    # Restore components
    restore_kubernetes_database "$extract_dir"
    restore_kubernetes_pvcs "$extract_dir"
    restore_kubernetes_resources "$extract_dir"
    
    # Regenerate ConfigMaps and Secrets from restored .env file
    print_info "Regenerating Kubernetes ConfigMaps and Secrets..."
    "${SCRIPT_DIR}/values-generator.sh" || {
        print_warning "Failed to regenerate values file"
    }
    
    # Apply Helm upgrade with restored configuration
    if [ -f "${PLATFORM_DIR}/.bitoarch-values.yaml" ] && command -v helm >/dev/null 2>&1; then
        print_info "Applying restored configuration with Helm..."
        helm upgrade bitoarch "${PLATFORM_DIR}/helm-bitoarch" \
            --namespace "$namespace" \
            --values "${PLATFORM_DIR}/.bitoarch-values.yaml" \
            --wait \
            --timeout 10m || {
            print_warning "Helm upgrade encountered issues"
        }
    fi
    
    # Scale deployments back up
    print_info "Scaling deployments back up..."
    if kubectl scale deployment -l "app.kubernetes.io/name=bitoarch" --replicas=1 -n "$namespace"; then
        print_status "Kubernetes restore completed"
    else
        print_error "Restore finished but scaling back up FAILED — the platform is still scaled to 0."
        print_info "Run: kubectl scale deployment -l app.kubernetes.io/name=bitoarch --replicas=1 -n $namespace"
    fi
}

validate_kubernetes_post_restore() {
    local namespace="bito-ai-architect"
    
    print_info "Running post-restore validation..."
    
    # Wait for pods to be ready
    print_info "Waiting for pods to be ready..."
    local max_attempts=30
    local attempt=1
    
    while [ $attempt -le $max_attempts ]; do
        local ready_pods=$(kubectl get pods -n "$namespace" -o jsonpath='{.items[?(@.status.conditions[?(@.type=="Ready")].status=="True")].metadata.name}' 2>/dev/null | wc -w)
        local total_pods=$(kubectl get pods -n "$namespace" --no-headers 2>/dev/null | wc -l)
        
        if [ "$ready_pods" -eq "$total_pods" ] && [ "$total_pods" -gt 0 ]; then
            break
        fi
        
        print_info "Waiting for pods to be ready... ($ready_pods/$total_pods ready)"
        sleep 10
        attempt=$((attempt + 1))
    done
    
    # Get service ports from ConfigMap
    local config_port=$(kubectl get configmap bitoarch-env-all -n "$namespace" -o jsonpath='{.data.CIS_CONFIG_PORT}' 2>/dev/null || echo "8080")
    local manager_port=$(kubectl get configmap bitoarch-env-all -n "$namespace" -o jsonpath='{.data.CIS_MANAGER_PORT}' 2>/dev/null || echo "8081")
    
    # Test service endpoints via port-forward (in background)
    print_info "Testing service endpoints..."
    
    # Get pods
    local config_pod=$(kubectl get pods -n "$namespace" -l "app.kubernetes.io/component=config" -o jsonpath='{.items[0].metadata.name}' 2>/dev/null || echo "")
    local manager_pod=$(kubectl get pods -n "$namespace" -l "app.kubernetes.io/component=manager" -o jsonpath='{.items[0].metadata.name}' 2>/dev/null || echo "")
    
    # Test config service
    if [ -n "$config_pod" ]; then
        if kubectl exec -n "$namespace" "$config_pod" -- wget -q -O- http://localhost:${config_port}/health >/dev/null 2>&1; then
            print_status "Config service is responding"
        else
            print_warning "Config service health check failed"
        fi
    fi
    
    # Test manager service
    if [ -n "$manager_pod" ]; then
        if kubectl exec -n "$namespace" "$manager_pod" -- wget -q -O- http://localhost:${manager_port}/health >/dev/null 2>&1; then
            print_status "Manager service is responding"
        else
            print_warning "Manager service health check failed"
        fi
    fi
    
    print_status "Post-restore validation completed"
}

# Post-restore validation
post_restore_validation() {
    print_info "Running post-restore validation..."
    
    # Start all services
    print_info "Starting all services..."
    $COMPOSE --env-file "${PLATFORM_DIR}/.env-bitoarch" -f "${PLATFORM_DIR}/docker-compose.yml" up -d
    
    # Wait for services to be healthy
    local max_attempts=30
    local attempt=1
    
    while [ $attempt -le $max_attempts ]; do
        local healthy_services=$($COMPOSE --env-file "${PLATFORM_DIR}/.env-bitoarch" -f "${PLATFORM_DIR}/docker-compose.yml" ps --format json | \
            jq -r '.[] | select(.Health == "healthy") | .Name' 2>/dev/null | wc -l)
        
        local total_services=$($COMPOSE --env-file "${PLATFORM_DIR}/.env-bitoarch" -f "${PLATFORM_DIR}/docker-compose.yml" ps --format json | \
            jq -r '.[].Name' 2>/dev/null | wc -l)
        
        if [ "$healthy_services" -eq "$total_services" ] && [ "$total_services" -gt 0 ]; then
            break
        fi
        
        print_info "Waiting for services to be healthy... ($healthy_services/$total_services healthy)"
        sleep 10
        attempt=$((attempt + 1))
    done
    
    # Basic functionality tests
    source "$ENV_FILE"
    
    # Test database connectivity
    if $COMPOSE --env-file "${PLATFORM_DIR}/.env-bitoarch" -f "${PLATFORM_DIR}/docker-compose.yml" exec -T ai-architect-mysql \
       mysqladmin ping -h localhost -u "$DB_USER" -p"$DB_PASSWORD" --silent >/dev/null 2>&1; then
        print_status "Database connectivity verified"
    else
        print_error "Database connectivity test failed"
        exit 1
    fi
    
    # Test service endpoints
    local services=("ai-architect-config:${CIS_CONFIG_PORT}" "ai-architect-manager:${CIS_MANAGER_PORT}" "ai-architect-tracker:${CIS_TRACKING_PORT}" "ai-architect-provider:${CIS_PROVIDER_PORT}")
    
    for service in "${services[@]}"; do
        local name=$(echo "$service" | cut -d: -f1)
        local port=$(echo "$service" | cut -d: -f2)
        
        if curl -f -s "http://localhost:$port/health" >/dev/null 2>&1; then
            print_status "$name service is responding"
        else
            print_warning "$name service health check failed"
        fi
    done
    
    print_status "Post-restore validation completed"
}

# Cleanup temporary files
cleanup() {
    if [ -d "$TEMP_RESTORE_DIR" ]; then
        print_info "Cleaning up temporary files..."
        rm -rf "$TEMP_RESTORE_DIR"
        print_status "Cleanup completed"
    fi
}

# Main restore function
main() {
    local backup_name="$1"
    
    # Ensure backup directory exists for logging
    mkdir -p "$BACKUP_DIR"
    
    echo -e "${BLUE}Bito's AI Architect Restore - Zero Data Loss Recovery${NC}"
    echo "========================================================"
    echo ""
    
    if [ -z "$backup_name" ]; then
        echo "Usage: $0 <backup_name>"
        echo ""
        echo "Available backups:"
        find "$BACKUP_DIR" -name "backup_*.tar.gz" -type f -exec basename {} \; 2>/dev/null | sort -r | head -10
        exit 1
    fi
    
    # Determine backup file path
    local backup_file
    if [[ "$backup_name" == /* ]]; then
        backup_file="$backup_name"
    elif [[ "$backup_name" == *.tar.gz ]]; then
        backup_file="${BACKUP_DIR}/$backup_name"
    else
        backup_file="${BACKUP_DIR}/${backup_name}.tar.gz"
    fi
    
    # Create temporary restore directory
    TEMP_RESTORE_DIR="${PLATFORM_DIR}/temp_restore_$(date +%s)"
    local extract_dir="${TEMP_RESTORE_DIR}/$(basename "$backup_name" .tar.gz)"
    
    # Trap for cleanup on exit
    trap cleanup EXIT
    
    # Detect deployment type
    local deployment_type="docker-compose"
    if [ -f "${PLATFORM_DIR}/.deployment-type" ]; then
        deployment_type=$(cat "${PLATFORM_DIR}/.deployment-type")
    fi

    # Pin to the cluster.yaml context so a K8s restore targets the right cluster on
    # a drifted current-context (no-op when inherited from the CLI / no context).
    if [ "$deployment_type" = "kubernetes" ]; then
        command -v _pin_kube_context >/dev/null 2>&1 \
            || source "${SCRIPT_DIR}/lib/cluster-yaml.sh" 2>/dev/null || true
        if command -v _pin_kube_context >/dev/null 2>&1; then
            _pin_kube_context || exit 1
        fi
    fi

    print_info "Detected deployment type: $deployment_type"
    
    # Execute restore process
    validate_backup "$backup_file"
    extract_backup "$backup_file" "$extract_dir"
    read_backup_manifest "$extract_dir"
    
    # Deployment-specific restore
    if [ "$deployment_type" = "kubernetes" ]; then
        # Kubernetes restore flow
        create_pre_restore_backup
        restore_configurations "$extract_dir"
        restore_kubernetes "$extract_dir"
        validate_kubernetes_post_restore
    else
        # Docker Compose restore flow
        pre_restore_validation "$extract_dir"
        create_pre_restore_backup
        restore_configurations "$extract_dir"
        restore_database "$extract_dir"
        restore_volumes "$extract_dir"
        restore_service_data "$extract_dir"
        post_restore_validation
    fi
    
    echo ""
    if [ -n "${RESTORE_PARTIAL_FAILURE:-}" ]; then
        print_warning "Restore completed WITH FAILURES (${RESTORE_PARTIAL_FAILURE}) — review the warnings above"
    else
        print_status "Restore completed successfully!"
    fi
    echo -e "${BLUE}Deployment type:${NC} $deployment_type"
    echo -e "${BLUE}Platform restored from:${NC} $backup_name"
    echo -e "${BLUE}Platform version:${NC} $BACKUP_VERSION"
    echo -e "${BLUE}Backup timestamp:${NC} $BACKUP_TIMESTAMP"
    echo ""
    echo -e "${GREEN}✓ All services are running and healthy${NC}"
    echo ""
}

# Handle command line arguments
case "${1:-}" in
    --help|-h)
        echo "Bito's AI Architect Restore Script"
        echo ""
        echo "Usage: $0 <backup_name>"
        echo ""
        echo "Examples:"
        echo "  $0 backup_20231117_143022"
        echo "  $0 backup_20231117_143022.tar.gz"
        echo "  $0 /path/to/backup.tar.gz"
        echo ""
        echo "Available backups:"
        find "$BACKUP_DIR" -name "backup_*.tar.gz" -type f -exec basename {} \; 2>/dev/null | sort -r | head -10
        ;;
    "")
        echo "Error: Backup name required"
        echo "Use --help for usage information"
        exit 1
        ;;
    *)
        main "$1"
        ;;
esac
