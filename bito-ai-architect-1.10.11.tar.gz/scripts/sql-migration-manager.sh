#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
# SQL Migration Manager - Database schema migration utilities
# Handles extraction and recording of SQL migrations from services

# Set up paths
# Use SQL_MIGRATION_SCRIPT_DIR to avoid conflicting with SCRIPT_DIR from setup.sh
SQL_MIGRATION_SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SQL_MIGRATION_PLATFORM_DIR="$(cd "$SQL_MIGRATION_SCRIPT_DIR/.." && pwd)"

# For backward compatibility when sourced from setup.sh, use its SCRIPT_DIR if available
if [ -n "${SCRIPT_DIR:-}" ]; then
    SQL_MIGRATION_PLATFORM_DIR="$SCRIPT_DIR"
fi

# Source common utilities
source "${SQL_MIGRATION_SCRIPT_DIR}/setup-utils.sh"

# Pin the log target up front; migration helpers redirect stderr to it.
command -v _resolve_log_file >/dev/null 2>&1 && _resolve_log_file

extract_sql_scripts() {
    local service=$1
    local container_name=$2
    local source_path=$3
    local dest_dir=$4
    
    log_technical "Extracting SQL scripts for $service..."
    
    mkdir -p "$dest_dir"
    
    if docker ps -a --format '{{.Names}}' | grep -q "^${container_name}$"; then
        if docker cp "${container_name}:${source_path}" "$dest_dir/" 2>/dev/null; then
            log_technical "SQL scripts extracted for $service"
            return 0
        else
            log_technical "Could not extract SQL scripts from $container_name"
            return 1
        fi
    else
        log_technical "Container $container_name not found, skipping SQL extraction"
        return 1
    fi
}

extract_all_service_sql_scripts() {
    log_technical "Extracting SQL scripts from service containers..."
    
    local extracted_count=0
    
    if extract_sql_scripts "cis-config" "cis-config" \
        "/app/resources/sql" \
        "${PLATFORM_DIR}/services/cis-config/extracted-sql"; then
        extracted_count=$((extracted_count + 1))
    fi
    
    if extract_sql_scripts "cis-manager" "cis-manager" \
        "/app/resources" \
        "${PLATFORM_DIR}/services/cis-manager/extracted-sql"; then
        extracted_count=$((extracted_count + 1))
    fi
    
    if [ $extracted_count -gt 0 ]; then
        log_technical "Extracted SQL scripts from $extracted_count service(s)"
    else
        log_technical "No SQL scripts were extracted"
    fi
}

verify_flyway_tables() {
    log_technical "Verifying Flyway schema history tables..."
    
    local check_script='
    USE cis_platform;
    SELECT COUNT(*) FROM information_schema.tables 
    WHERE table_schema = "cis_platform" 
    AND table_name IN ("flyway_schema_history_config", "flyway_schema_history_manager", "flyway_schema_history_temporal");
    '

    local table_count=$(docker exec -i cis-mysql mysql -u root -p"${MYSQL_ROOT_PASSWORD}" \
        --batch --raw -e "$check_script" 2>/dev/null | tail -1)

    if [ "$table_count" = "3" ]; then
        log_technical "Flyway schema history tables verified (all 3 tables found)"
        return 0
    elif [ "$table_count" = "2" ]; then
        log_technical "Only 2 Flyway tables found (expected 3 — temporal table may be missing)"
        return 1
    elif [ "$table_count" = "1" ]; then
        log_technical "Only 1 Flyway table found (expected 3)"
        return 1
    else
        log_technical "Flyway schema history tables not found"
        return 1
    fi
}

record_migration() {
    local service=$1
    local version=$2
    local description=$3
    local script_name=$4
    local execution_time=$5
    
    # Escape single quotes in user inputs to prevent SQL injection
    version="${version//\'/\'\'}"
    description="${description//\'/\'\'}"
    script_name="${script_name//\'/\'\'}"
    
    local table_name="flyway_schema_history_${service}"
    
    local insert_script="
    USE code_intelligence;
    INSERT INTO ${table_name} 
    (installed_rank, version, description, type, script, checksum, installed_by, execution_time, success)
    SELECT COALESCE(MAX(installed_rank), 0) + 1, '${version}', '${description}', 'SQL', 
           '${script_name}', 0, 'cis_platform', ${execution_time}, TRUE
    FROM ${table_name};
    "
    
    if exec_mysql_cmd "$insert_script"; then
        log_silent "Migration recorded for $service (version $version)"
        return 0
    else
        print_warning "Could not record migration for $service"
        return 1
    fi
}

# ============================================================================
# Upgrade Migration Functions (Docker Compose & Kubernetes)
# ============================================================================

# Execute MySQL command (works for Docker and K8s)
exec_mysql_cmd() {
    local sql_cmd="$1"
    local deployment_type="${DEPLOYMENT_TYPE:-docker-compose}"
    
    if [[ "$deployment_type" == "kubernetes" ]]; then
        kubectl exec -n bito-ai-architect deployment/ai-architect-mysql -- \
            mysql -u root -p"${MYSQL_ROOT_PASSWORD}" -e "$sql_cmd" 2>>"${LOG_FILE:-/dev/null}"
    else
        docker exec ai-architect-mysql \
            mysql -u root -p"${MYSQL_ROOT_PASSWORD}" -e "$sql_cmd" 2>>"${LOG_FILE:-/dev/null}"
    fi
}

# Execute SQL file (works for Docker and K8s)
exec_mysql_file() {
    local sql_file="$1"
    local deployment_type="${DEPLOYMENT_TYPE:-docker-compose}"
    
    if [[ "$deployment_type" == "kubernetes" ]]; then
        kubectl exec -i -n bito-ai-architect deployment/ai-architect-mysql -- \
            mysql -u root -p"${MYSQL_ROOT_PASSWORD}" code_intelligence < "$sql_file" 2>>"${LOG_FILE:-/dev/null}"
    else
        docker exec -i ai-architect-mysql \
            mysql -u root -p"${MYSQL_ROOT_PASSWORD}" code_intelligence < "$sql_file" 2>>"${LOG_FILE:-/dev/null}"
    fi
}

# Get applied migrations from Flyway history.
# A MISSING history table is the bootstrap case, not an error: the table is
# created only by the MySQL init scripts, which run solely on a fresh data
# directory, so installs predating a given init script legitimately have none.
# Treat that as "no migrations applied yet" (the migrations themselves create
# it). Only a genuine query failure is reported to the caller.
get_applied_migrations() {
    local service=$1  # "config" or "manager"
    local table="flyway_schema_history_${service}"
    local rows rc err_snapshot
    err_snapshot=$(mktemp)
    # exec_mysql_cmd sends its stderr to $LOG_FILE, so point that at the snapshot
    # for this one call -- a plain 2>redirect here would capture nothing, and the
    # ER-1146 check below (the fresh-install bootstrap path) could never match.
    rows=$(LOG_FILE="$err_snapshot" exec_mysql_cmd "SELECT script FROM code_intelligence.${table};"); rc=$?
    if [ $rc -ne 0 ]; then
        if grep -qiE "doesn't exist|1146" "$err_snapshot" 2>/dev/null; then
            log_silent "Migration history table ${table} does not exist yet — treating as empty (will be created by migrations)"
            rm -f "$err_snapshot"
            return 0
        fi
        log_silent "Could not read migration history table ${table}: $(head -c 300 "$err_snapshot" 2>/dev/null)"
        cat "$err_snapshot" >> "${LOG_FILE:-/dev/null}" 2>/dev/null || true
        rm -f "$err_snapshot"
        return 1
    fi
    rm -f "$err_snapshot"
    printf '%s\n' "$rows" | tail -n +2
}

# Run pending migrations for a service
run_pending_migrations() {
    local service=$1  # "config" or "manager"
    local sql_dir=""
    
    # cis-config uses resources/sql/, cis-manager uses resources/ directly,
    # temporal uses services/temporal/resources/
    if [[ "$service" == "config" ]]; then
        sql_dir="${SQL_MIGRATION_PLATFORM_DIR}/services/cis-${service}/resources/sql"
    elif [[ "$service" == "temporal" ]]; then
        sql_dir="${SQL_MIGRATION_PLATFORM_DIR}/services/temporal/resources"
    else
        sql_dir="${SQL_MIGRATION_PLATFORM_DIR}/services/cis-${service}/resources"
    fi
    
    # Check if sql directory exists
    if [[ ! -d "$sql_dir" ]]; then
        log_silent "No SQL directory found for $service at $sql_dir"
        return 0
    fi
    
    # Get already applied scripts from Flyway history. A failed query must not
    # look like an empty history — that would re-run every migration.
    local applied
    if ! applied=$(get_applied_migrations "$service"); then
        print_error "Could not read migration history for $service — skipping its migrations (see $LOG_FILE)"
        return 1
    fi
    local pending_count=0
    
    # Execute pending SQL files in order (sorted by filename for 001_, 002_, etc.)
    for sql_file in $(ls "$sql_dir"/*.sql 2>/dev/null | sort); do
        local script_name=$(basename "$sql_file")
        local skip_migration=false
        
        # Check if this script is already applied
        if echo "$applied" | grep -qF "$script_name"; then
            log_silent "Migration $script_name already applied for $service"
            continue
        fi
        
        # Special case for cis-manager: database.sql (old) = 001_*.sql (new)
        # If Flyway has database.sql recorded, skip any 001_*.sql migration
        if [[ "$service" == "manager" ]] && [[ "$script_name" == 001_* ]]; then
            if echo "$applied" | grep -qF "database.sql"; then
                log_silent "Migration $script_name skipped (equivalent database.sql already applied)"
                continue
            fi
        fi
        
        log_silent "Running migration: $script_name for $service"
        
        # Execute the SQL file
        if exec_mysql_file "$sql_file"; then
            # Extract version number from filename (e.g., 001 from 001_CREATE_TABLE.sql)
            local version=$(echo "$script_name" | grep -oE '^[0-9]+' || echo "1")
            # Extract description from filename (remove leading numbers and .sql)
            local description=$(echo "$script_name" | sed 's/^[0-9]*_//' | sed 's/\.sql$//')
            
            # Record in Flyway history
            record_migration "$service" "$version" "$description" "$script_name" 0
            log_silent "Migration $script_name applied successfully"
            pending_count=$((pending_count + 1))
        else
            print_error "Failed to apply migration: $script_name"
            return 1
        fi
    done
    
    if [[ $pending_count -eq 0 ]]; then
        log_silent "No pending migrations for $service"
    else
        print_status "$pending_count migration(s) applied for $service"
    fi
    
    return 0
}

# Main entry point for upgrade migrations
# Called from upgrade.sh after services are healthy
run_upgrade_migrations() {
    log_silent "Checking for pending database migrations..."
    
    # Source environment for MySQL password
    if [[ -f "${SQL_MIGRATION_PLATFORM_DIR}/.env-bitoarch" ]]; then
        source "${SQL_MIGRATION_PLATFORM_DIR}/.env-bitoarch"
    fi
    
    # Detect deployment type if not set
    if [[ -z "$DEPLOYMENT_TYPE" ]]; then
        if [[ -f "${SQL_MIGRATION_PLATFORM_DIR}/.deployment-type" ]]; then
            DEPLOYMENT_TYPE=$(cat "${SQL_MIGRATION_PLATFORM_DIR}/.deployment-type")
        else
            DEPLOYMENT_TYPE="docker-compose"
        fi
    fi
    
    log_silent "Running migrations for deployment type: $DEPLOYMENT_TYPE"
    
    # Run migrations for all services
    if ! run_pending_migrations "config"; then
        print_error "Failed to run config migrations"
        return 1
    fi

    if ! run_pending_migrations "manager"; then
        print_error "Failed to run manager migrations"
        return 1
    fi

    # Ensure temporal user exists before running temporal migrations
    # (env var based, idempotent — parallels Docker MySQL's cis_user creation)
    local temporal_user="${TEMPORAL_MYSQL_USER:-temporal_user}"
    local temporal_pass="${TEMPORAL_MYSQL_PASSWORD}"
    if [ -n "$temporal_pass" ]; then
        log_silent "Ensuring temporal MySQL user '${temporal_user}' exists..."
        # MySQL echoes the offending statement on a syntax error, which would put
        # the password in setup.log. exec_mysql_cmd redirects its own stderr to
        # $LOG_FILE, and that inner redirect beats any 2>/dev/null here — so the
        # only way to suppress it is to override LOG_FILE for this one call.
        LOG_FILE=/dev/null exec_mysql_cmd "CREATE USER IF NOT EXISTS '${temporal_user}'@'%' IDENTIFIED BY '${temporal_pass}';" \
            || log_silent "temporal MySQL user create failed (continuing; temporal migrations may fail)"
    fi

    if ! run_pending_migrations "temporal"; then
        print_error "Failed to run temporal migrations"
        return 1
    fi

    log_silent "Database migrations complete"
    return 0
}
