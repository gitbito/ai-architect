#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai

# BITOARCH_USER_SERVICES + bitoarch_user_service_count live in
# scripts/lib/constants.sh (deployment-neutral: also consumed by K8s/output
# rendering). Defensive source so callers that invoke docker-manager.sh
# directly (e.g. tests) still resolve the array. Load-guarded; re-source is
# a no-op when constants.sh is already present in the caller's env.
#
# Resolve relative to THIS file's on-disk location, NOT $SCRIPT_DIR -- test
# harnesses frequently re-assign $SCRIPT_DIR to the test directory, which
# would make a $SCRIPT_DIR-based lookup fail to find constants.sh.
_DM_OWN_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [ -f "${_DM_OWN_DIR}/lib/constants.sh" ]; then
    # shellcheck disable=SC1091
    source "${_DM_OWN_DIR}/lib/constants.sh"
fi
unset _DM_OWN_DIR

# -----------------------------------------------------------------------------
# get_docker_compose_cmd
# -----------------------------------------------------------------------------
# Detect and echo the Docker Compose command to use ("docker compose" for
# Compose v2 plugin, "docker-compose" for the legacy standalone binary).
#
# Lightweight probe -- no side effects, no installs. Used by scripts that need
# to invoke Compose WITHOUT running the full check_prerequisites flow (e.g.
# `bitoarch start` / `bitoarch logs`). check_prerequisites in
# prerequisites-manager.sh exports DOCKER_COMPOSE_CMD as a side effect; this
# function is the read-only equivalent that can be called anytime.
#
# Returns: echoes the command on success; returns 1 (and echoes nothing) when
# neither form of Compose is available.
# -----------------------------------------------------------------------------
get_docker_compose_cmd() {
    if docker compose version >/dev/null 2>&1; then
        echo "docker compose"
    elif command -v docker-compose >/dev/null 2>&1 && docker-compose version >/dev/null 2>&1; then
        echo "docker-compose"
    else
        return 1
    fi
}

# wait_for_containers_running [timeout_seconds]
# State-based poll (0 = all running, 1 = any exited/dead, 2 = timeout).
# Health-readiness is a separate concern handled by `bitoarch health`.
wait_for_containers_running() {
    local timeout="${1:-60}"
    local start=$SECONDS
    local services=("${BITOARCH_USER_SERVICES[@]}")
    local total=${#services[@]}

    while [ $((SECONDS - start)) -lt "$timeout" ]; do
        local up=0 failed=0
        for svc in "${services[@]}"; do
            local state
            state=$(docker inspect --format='{{.State.Status}}' "$svc" 2>/dev/null || echo "missing")
            case "$state" in
                running)              up=$((up + 1)) ;;
                exited|dead|removing) failed=$((failed + 1)) ;;
                # created|restarting|paused|missing — still resolving, wait
            esac
        done

        if [ "$up" -ge "$total" ]; then
            return 0
        fi
        if [ "$failed" -gt 0 ]; then
            return 1
        fi
        sleep 1
    done
    return 2
}

# Backward-compat alias (older callers + test guards may reference the
# previous name).
wait_for_containers_healthy() {
    wait_for_containers_running "$@"
}

# wait_for_services_healthy [timeout=90] [grace=60] [service ...]
# Health-based poll. Return codes:
#   0  all services ready
#   1  one or more exited / unhealthy after grace window
#   2  soft timeout (still warming up)
#
# Services: optional positional args; defaults to BITOARCH_USER_SERVICES.
#
# Readiness rules:
#   no healthcheck defined  -> state=running is ready
#   healthcheck defined     -> .State.Health.Status=healthy is ready
#     (state=running alone is insufficient: .State.Health.Status can be
#      briefly empty during startup, which would otherwise be misread as
#      "no healthcheck" and return success while services are still in
#      start_period.)
wait_for_services_healthy() {
    local timeout="${1:-90}"
    # Grace window absorbs docker compose restart transients and retry
    # cycles driven by `restart: on-failure` (e.g. cis-manager panics when
    # MySQL isn't ready yet and Docker restarts it -- ~20-25s). Only after
    # grace do genuine failures fast-fail. Default matches the project-wide
    # SERVICE_WAIT_GRACE_SECS convention so a caller that omits grace gets
    # the same transient-absorption window as every explicit caller.
    local grace="${2:-60}"
    # Service tail is read via "${@:3}" rather than `shift 2` because
    # `shift 2` raises "shift count out of range" when fewer than 2 args
    # are passed; suppressing that error would silently skip the shift
    # and leak $1 (e.g. a lone timeout value) into the services array as
    # a bogus container name. The slice form is unconditional and safe.
    local services=("${@:3}")
    [ ${#services[@]} -eq 0 ] && services=("${BITOARCH_USER_SERVICES[@]}")
    local start=$SECONDS
    local total=${#services[@]}

    while [ $((SECONDS - start)) -lt "$timeout" ]; do
        local healthy=0 failed=0
        for svc in "${services[@]}"; do
            local state health has_hc
            state=$(docker inspect --format='{{.State.Status}}' "$svc" 2>/dev/null || echo "missing")
            health=$(docker inspect --format='{{.State.Health.Status}}' "$svc" 2>/dev/null || echo "")
            # Healthcheck defined iff .Config.Healthcheck.Test is non-empty.
            has_hc=$(docker inspect --format='{{if and .Config.Healthcheck (ne (len .Config.Healthcheck.Test) 0)}}yes{{else}}no{{end}}' "$svc" 2>/dev/null || echo "no")

            if [ "$has_hc" = "yes" ]; then
                # Healthcheck defined: strictly require health=healthy.
                if [ "$health" = "healthy" ]; then
                    healthy=$((healthy + 1))
                elif [ "$state" = "exited" ] || [ "$state" = "dead" ] || [ "$health" = "unhealthy" ]; then
                    failed=$((failed + 1))
                fi
                # else (starting / empty / running-not-yet-probed): neither
                # healthy nor failed -- keep waiting.
            else
                # No healthcheck: state=running is the readiness signal.
                if [ "$state" = "running" ]; then
                    healthy=$((healthy + 1))
                elif [ "$state" = "exited" ] || [ "$state" = "dead" ]; then
                    failed=$((failed + 1))
                fi
            fi
        done

        if [ "$healthy" -ge "$total" ]; then
            return 0
        fi
        # Grace window absorbs `docker compose restart` transients.
        if [ "$failed" -gt 0 ] && [ $((SECONDS - start)) -ge "$grace" ]; then
            return 1
        fi
        sleep 2
    done
    return 2
}

export -f wait_for_services_healthy

# -----------------------------------------------------------------------------
# list_failing_services
# -----------------------------------------------------------------------------
# Emit one line per AI Architect service that did NOT reach state=running,
# in the format "  - <short-name>  (<status>)" suitable for dropping straight
# into the failure block. Short-name strips the "ai-architect-" prefix.
# Status is "exited, code <N>" / "restarting" / "missing" / raw docker state.
# -----------------------------------------------------------------------------
list_failing_services() {
    for svc in "${BITOARCH_USER_SERVICES[@]}"; do
        local state code short
        state=$(docker inspect --format='{{.State.Status}}' "$svc" 2>/dev/null || echo "missing")
        code=$(docker inspect --format='{{.State.ExitCode}}' "$svc" 2>/dev/null || echo "")
        short=${svc#ai-architect-}
        case "$state" in
            running) ;;  # healthy, skip
            exited)   printf '    - %-10s (exited, code %s)\n' "$short" "${code:-?}" ;;
            missing)  printf '    - %-10s (not created)\n' "$short" ;;
            *)        printf '    - %-10s (%s)\n' "$short" "$state" ;;
        esac
    done
}

# Export so child shells (e.g. `bash -c "... && wait_for_containers_running 60"`
# from bitoarch.sh::start) see these functions. Without this, the chained
# wait runs in the child as an unknown command -> 127, user sees false ✗.
export -f wait_for_containers_running
export -f wait_for_containers_healthy
export -f list_failing_services

handle_docker_daemon() {
    local SUDO_CMD="$1"
    
    if is_container_environment; then
        print_info "Container environment detected"
        
        if [ -S /var/run/docker.sock ] && docker info >/dev/null 2>&1; then
            print_status "Docker configured (using host daemon)"
            return 0
        fi
        
        if command -v dockerd >/dev/null 2>&1; then
            print_info "Starting Docker daemon in container..."
            # Its own file, not setup.log: a daemon streams for its whole lifetime.
            local dockerd_log="${BITOARCH_LOG_DIR:-${TMPDIR:-/tmp}}/dockerd.log"
            { : >>"$dockerd_log"; } 2>/dev/null || dockerd_log="/dev/null"
            log_silent "starting dockerd; its output goes to ${dockerd_log}"
            dockerd >> "$dockerd_log" 2>&1 &
            
            # Fast retry loop - checks every second for up to 10 seconds
            # Most daemons start in 1-2 seconds, so minimal performance impact
            local wait_time=0
            while [ $wait_time -lt 10 ]; do
                if docker info >/dev/null 2>&1; then
                    print_status "Docker configured (container daemon ready)"
                    return 0
                fi
                sleep 1
                wait_time=$((wait_time + 1))
            done
            
            print_warning "Docker daemon not responding within 10 seconds"
        fi
        
        print_status "Docker Engine installed successfully"
        print_warning "Container environment - Docker daemon requires privileged mode or host socket"
    else
        print_info "Server environment - configuring Docker service..."
        
        if $SUDO_CMD systemctl start docker >> "${LOG_FILE:-/dev/null}" 2>&1 && \
           $SUDO_CMD systemctl enable docker >> "${LOG_FILE:-/dev/null}" 2>&1; then
            local wait_time=0
            while [ $wait_time -lt 30 ]; do
                if docker info >/dev/null 2>&1; then
                    print_status "Docker Engine installed and started successfully"
                    return 0
                fi
                sleep 2
                wait_time=$((wait_time + 2))
            done
            print_error "Docker service started but daemon not responding"
            exit 1
        else
            print_error "Failed to start Docker service"
            exit 1
        fi
    fi
}

install_docker_common() {
    local package_manager="$1"
    local distro_name="$2"
    local SUDO_CMD="$3"
    
    print_info "Installing Docker Engine on $distro_name..."
    
    curl -fsSL https://get.docker.com -o get-docker.sh
    $SUDO_CMD sh get-docker.sh
    
    if [ "$EUID" -ne 0 ]; then
        $SUDO_CMD usermod -aG docker $USER
    fi
    
    if ! is_container_environment; then
        $SUDO_CMD systemctl start docker >> "${LOG_FILE:-/dev/null}" 2>&1
        $SUDO_CMD systemctl enable docker >> "${LOG_FILE:-/dev/null}" 2>&1
    fi
    
    rm -f get-docker.sh
    
    handle_docker_daemon "$SUDO_CMD"
}

install_docker() {
    print_info "Installing Docker Engine for server deployment..."
    
    local SUDO_CMD=""
    if [ "$EUID" -ne 0 ]; then
        SUDO_CMD="sudo"
    fi
    
    if [[ "$OSTYPE" == "linux-gnu"* ]] || \
       [[ -f "/etc/redhat-release" ]] || \
       [[ -f "/etc/debian_version" ]]; then
        if command -v apt-get >/dev/null 2>&1; then
            install_docker_common "apt-get" "Ubuntu/Debian" "$SUDO_CMD"
        elif command -v yum >/dev/null 2>&1; then
            install_docker_common "yum" "CentOS/RHEL/Fedora" "$SUDO_CMD"
        elif command -v dnf >/dev/null 2>&1; then
            install_docker_common "dnf" "Modern Fedora/RHEL" "$SUDO_CMD"
        else
            print_error "Unsupported Linux distribution. Please install Docker manually."
            print_info "Supported: Ubuntu, Debian, CentOS, RHEL, Fedora"
            exit 1
        fi
    elif [[ "$OSTYPE" == "darwin"* ]]; then
        print_info "Docker Engine installation is not automated for macOS"
        print_info "This platform is designed for Linux server deployment"
        echo ""
        print_info "For local development on macOS, please install Docker manually:"
        echo ""
        print_info "OPTION 1: Install Docker + Colima (Recommended):"
        print_command "brew install docker docker-compose colima"
        print_command "colima start --cpu 2 --memory 4 --disk 20"
        echo ""
        print_info "OPTION 2: Install Docker Desktop (Alternative):"
        print_command "Download from: https://www.docker.com/products/docker-desktop"
        echo ""
        print_info "Then run this script again."
        exit 1
    else
        print_error "Unsupported operating system for server deployment: $OSTYPE"
        print_info "This script is designed for Linux server environments"
        print_info "Supported: Ubuntu, Debian, CentOS, RHEL, Fedora"
        print_info "For other systems, please install Docker manually"
        exit 1
    fi
}
