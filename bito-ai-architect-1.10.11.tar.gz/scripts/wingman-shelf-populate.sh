#!/bin/sh
#
# Copyright (c) 2023-2026 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
#
# Populates the shared Wingman shelf (binary + tools + base skills) from the CDN.
# Runs INSIDE a container that mounts the shelf volume/PVC (docker one-shot / k8s
# Job), so it is POSIX sh + busybox-only (wget, unzip, tar, sed, grep, sort -V).
# Best-effort: any failure leaves the current shelf untouched and exits 0 so base
# start is never blocked. Highest-version-wins against the on-shelf `current`
# symlink for the binary and a `.manifest_version` marker for skills; no host state.

SHELF="${WINGMAN_SHELF_DIR:-/opt/bito/ai-architect/wingman}"
SKILLS_DIR="${SHELF}/skills"
BIN_NAME="${WINGMAN_BINARY_NAME:-bito-wingman}"
BASE="${WINGMAN_DOWNLOAD_BASE_URL:-https://wingman.bito.ai/}"; BASE="${BASE%/}"
# Skills live on the mcp-setup host — reuse the existing MCP_INSTALLER_BASE_URL (staging-aware) rather than a separate var.
SKILLS_BASE="${MCP_INSTALLER_BASE_URL:-https://mcp-setup.bito.ai}"; SKILLS_BASE="${SKILLS_BASE%/}"
ARCH="${WINGMAN_HOST_ARCH:-x86_64}"   # container arch; on-prem images are linux-x64

# Log to stderr so lines stream to `docker logs` immediately (stdout is block-buffered
# when not a TTY, which would hide all progress until the script exits).
log() { echo "[wingman-populate] $*" >&2; }

case "$ARCH" in
    x86_64|amd64)  PKEY="linux-x64" ;;
    arm64|aarch64) PKEY="linux-arm64" ;;
    *)             PKEY="linux-${ARCH}" ;;
esac

# First non-empty string value for a top-level "key": "value" pair in a manifest.
# Retention: keep the live `current` version plus WINGMAN_SHELF_KEEP previous
# versions (default 2), newest-first by mtime; prune older version dirs so the
# shared PVC does not grow unbounded. Immutable-versioned-artifact convention:
# the current symlink target and non-version entries (skills/, markers) are never
# touched, and rollback stays possible to the retained previous versions.
_prune_shelf() {
    [ -d "$SHELF" ] || return 0
    prune_err="${tmp:-/tmp}/prune.err"
    keep="${WINGMAN_SHELF_KEEP:-2}"
    case "$keep" in ''|*[!0-9]*) keep=2 ;; esac
    target=""; [ -L "$SHELF/current" ] && target="$(readlink "$SHELF/current" 2>/dev/null)"
    n=0
    for d in $(ls -1t "$SHELF" 2>/dev/null); do
        case "$d" in
            current|skills|.*) continue ;;   # symlink, skills tree, markers/staging
            "$target")         continue ;;   # never the live version
            [0-9]*)            ;;            # version-shaped only
            *)                 continue ;;
        esac
        [ -d "$SHELF/$d" ] || continue
        n=$((n + 1))
        if [ "$n" -gt "$keep" ]; then
            chmod -R u+w "$SHELF/$d" 2>/dev/null || true
            if rm -rf "$SHELF/$d" 2>"$prune_err"; then
                log "pruned old Wingman version ${d} (retention: current + ${keep})"
            else
                log "could not prune ${d}: $(tail -1 "$prune_err" 2>/dev/null); the shelf will keep growing"
            fi
        fi
    done
}

_json_str() { grep -o "\"$1\"[[:space:]]*:[[:space:]]*\"[^\"]*\"" "$2" 2>/dev/null | head -1 | sed 's/.*:[[:space:]]*"\([^"]*\)".*/\1/'; }

# Make the shelf root writable so the manager/worker fallback can create and
# populate <shelf>/current when this CDN populate is skipped/unreachable — that
# offline case is exactly when the fallback runs. Root-owned by default and
# services may run non-root; on k8s the pod fsGroup covers this instead.
mkdir -p "$SHELF" 2>/dev/null || log "could not create ${SHELF}; the publish below will fail"
chmod 0777 "$SHELF" 2>/dev/null || log "could not chmod 0777 ${SHELF}; a non-root service may not be able to populate current/"

# A shelf seeded from the offline bundle is authoritative: the package ships
# Wingman for installs without outbound network access, so the CDN must not
# replace it. Covers every caller that funnels through this script -- the compose
# populate service, the on-demand Job, restart --force and the daily updater.
# BITOARCH_WINGMAN_SYNC_FORCE=1 (`bitoarch wingman update`) is the deliberate
# operator override.
# Outcome tracking. This script is deliberately best-effort and always exits 0 so a
# failed sync can never block a running platform, which means the exit code carries no
# information. These record what actually happened for the caller and for the marker
# decision at the end.
SYNC_PUBLISHED=0
FORCED_FROM_BUNDLE=0

if [ -f "$SHELF/.bundle_seeded" ]; then
    if [ "${BITOARCH_WINGMAN_SYNC_FORCE:-0}" != "1" ]; then
        log "shelf seeded from the offline bundle ($(cat "$SHELF/.bundle_seeded" 2>/dev/null)); skipping CDN sync"
        exit 0
    fi
    # A forced sync replaces the bundled assets with CDN ones, so the shelf stops being
    # bundle-seeded -- but only once something is actually published. Dropping the
    # marker up front breaks the air-gapped case it matters most for: the download
    # fails, the shelf still holds nothing but bundle content, and yet `wingman status`
    # would name a CDN source while every later automatic sync re-arms a download that
    # cannot succeed. The marker is removed at the end instead, on success only.
    log "forced sync requested"
    FORCED_FROM_BUNDLE=1
fi

command -v wget >/dev/null 2>&1 || { log "wget unavailable; skipped"; exit 0; }
tmp="$(mktemp -d 2>/dev/null)" || exit 0
trap 'rm -rf "$tmp"' EXIT

# wget wrapper: quiet on success; on failure logs wget's own last error line
# (DNS vs timeout vs TLS reset) so "CDN unreachable" is diagnosable from the log.
fetch() {   # <timeout> <dest> <url>
    wget -q -T "$1" -O "$2" "$3" 2>"$tmp/wget.err" && return 0
    log "fetch failed: $3 ($(tail -1 "$tmp/wget.err" 2>/dev/null | tr -d '\r'))"
    return 1
}
log "starting shelf populate for ${PKEY} (downloads run quietly; this can take a minute)"

# ---------------------------------------------------------------------------
# Binary + tools
# ---------------------------------------------------------------------------
if fetch 20 "$tmp/manifest.json" "$BASE/manifest.json"; then
    wver="$(_json_str wingman-version "$tmp/manifest.json")"
    tver="$(_json_str tools-version  "$tmp/manifest.json")"
    if [ -z "$wver" ]; then
        log "manifest has no wingman-version; skipping binary"
    else
        cur=""; [ -L "$SHELF/current" ] && cur="$(readlink "$SHELF/current" 2>/dev/null)"
        skip=0
        if [ -n "$cur" ] && [ "${BITOARCH_WINGMAN_SYNC_FORCE:-0}" != "1" ]; then
            if [ "$cur" = "$wver" ]; then skip=1; log "shelf already at ${wver}"; fi
            if [ "$skip" = "0" ] && [ "$(printf '%s\n%s\n' "$wver" "$cur" | sort -V 2>/dev/null | tail -1)" = "$cur" ]; then
                skip=1; log "shelf ${cur} >= manifest ${wver}; no binary sync"
            fi
        fi
        if [ "$skip" = "0" ]; then
            binfile="bitowingman-${wver}-${PKEY}"
            toolsfile="bitowingman-tools-${tver}-${PKEY}.zip"
            if ! grep -q "\"${binfile}\"" "$tmp/manifest.json" 2>/dev/null; then
                log "manifest ${wver} has no binary for ${PKEY}; skipping binary"
            elif log "downloading Wingman ${wver} binary (${PKEY})" && ! fetch 300 "$tmp/$BIN_NAME" "$BASE/$binfile"; then
                log "binary download failed (${binfile}); keeping the current shelf"
            else
                chmod 0755 "$tmp/$BIN_NAME" 2>/dev/null || true
                mkdir -p "$tmp/tools"
                if [ -n "$tver" ] && grep -q "\"${toolsfile}\"" "$tmp/manifest.json" 2>/dev/null \
                   && log "downloading Wingman tools ${tver}" \
                   && fetch 120 "$tmp/tools.zip" "$BASE/$toolsfile"; then
                    unzip -q -o "$tmp/tools.zip" -d "$tmp/tools" 2>/dev/null || { log "tools ${tver} unzip failed; binary only"; rm -rf "$tmp/tools"; mkdir -p "$tmp/tools"; }
                    inner="$(find "$tmp/tools" -mindepth 1 -maxdepth 1 2>/dev/null)"
                    if [ "$(printf '%s\n' "$inner" | grep -c . 2>/dev/null)" = "1" ] && [ -d "$inner" ]; then
                        ( cd "$inner" && tar -cf - . ) | ( cd "$tmp/tools" && tar -xf - ) 2>/dev/null && rm -rf "$inner"
                    fi
                else
                    [ -n "$tver" ] && log "tools ${tver} unavailable; publishing binary only"
                fi
                # Publish atomically: stage <ver>/, then flip current in place.
                mkdir -p "$SHELF"
                stage="$SHELF/.populate.$$"; rm -rf "$stage"
                if ! mkdir -p "$stage/$wver" 2>"$tmp/pub.err"; then
                    log "could not stage ${wver}: $(tail -1 "$tmp/pub.err" 2>/dev/null); keeping the current shelf"
                elif ! cp "$tmp/$BIN_NAME" "$stage/$wver/$BIN_NAME" 2>"$tmp/pub.err" \
                     || ! chmod 0555 "$stage/$wver/$BIN_NAME" 2>"$tmp/pub.err"; then
                    # Publishing now would flip current/ at a version with no binary.
                    log "could not stage the ${wver} binary: $(tail -1 "$tmp/pub.err" 2>/dev/null); keeping the current shelf"
                    rm -rf "$stage"
                else
                    if [ -d "$tmp/tools" ] && [ -n "$(ls -A "$tmp/tools" 2>/dev/null)" ]; then
                        if cp -R "$tmp/tools" "$stage/$wver/tools" 2>"$tmp/pub.err"; then
                            [ -n "$tver" ] && { printf '%s' "$tver" > "$stage/$wver/.tools_version" \
                                || log "could not write the tools version marker for ${wver}"; }
                        else
                            log "could not stage tools ${tver}: $(tail -1 "$tmp/pub.err" 2>/dev/null); publishing binary only"
                            tver=""
                        fi
                    fi
                    chmod -R u+w "$SHELF/$wver" 2>/dev/null || true; rm -rf "$SHELF/$wver"
                    if mv "$stage/$wver" "$SHELF/$wver" 2>"$tmp/pub.err"; then
                        # Point current/ at the new version. current/ is a symlink
                        # when we own it, but a fallback self-download (go-common
                        # MkdirAll) leaves it a REAL dir — drop that so ln can't nest
                        # inside it; ln -sfn (-n) re-points an existing symlink in place.
                        [ -L "$SHELF/current" ] || rm -rf "$SHELF/current"
                        # SYNC_PUBLISHED drops .bundle_seeded, so set it only when the
                        # symlink actually moved: a failed flip leaves current/ on the
                        # previous version, i.e. nothing was published.
                        if ln -sfn "$wver" "$SHELF/current" 2>"$tmp/pub.err"; then
                            log "published binary ${wver} (tools ${tver:-none}) for ${PKEY}"
                            SYNC_PUBLISHED=1
                        else
                            log "staged ${wver} but could not point current/ at it: $(tail -1 "$tmp/pub.err" 2>/dev/null); the shelf still serves the previous version"
                        fi
                    else
                        log "publish move failed: $(tail -1 "$tmp/pub.err" 2>/dev/null); keeping the current shelf"
                    fi
                    rm -rf "$stage"
                fi
            fi
        fi
    fi
else
    log "wingman CDN unreachable (${BASE}); keeping the current shelf"
fi

# ---------------------------------------------------------------------------
# Base skills (mirrors the binary flow: manifest-driven, highest-wins via marker)
# ---------------------------------------------------------------------------
sm="$tmp/skills.json"
if fetch 20 "$sm" "$SKILLS_BASE/skills/manifest.json"; then
    sver="$(_json_str version "$sm")"
    marker="$SKILLS_DIR/.manifest_version"
    cur_sver=""; [ -f "$marker" ] && cur_sver="$(cat "$marker" 2>/dev/null)"
    if [ -n "$sver" ] && [ "$sver" = "$cur_sver" ] && [ "${BITOARCH_WINGMAN_SYNC_FORCE:-0}" != "1" ]; then
        log "base skills already at ${sver}"
    elif [ -z "$sver" ]; then
        log "skills manifest has no version; skipping skills"
    else
        mkdir -p "$SKILLS_DIR"
        log "syncing base skills ${sver}"
        # Each skill: derive name from its SKILL.md path, download every file it references.
        grep -oE '"skills/[^"]*/SKILL\.md"' "$sm" | sed 's#"skills/\([^/]*\)/SKILL.md"#\1#' | sort -u | while IFS= read -r name; do
            [ -z "$name" ] && continue
            dest="$SKILLS_DIR/bito-${name}"
            grep -oE "\"skills/${name}/[^\"]*\"" "$sm" | tr -d '"' | sort -u | while IFS= read -r ref; do
                [ -z "$ref" ] && continue
                rel="${ref#skills/"${name}"/}"
                mkdir -p "$dest/$(dirname "$rel")" 2>/dev/null \
                    || { log "could not create $(dirname "$dest/$rel")"; : > "$tmp/skills.partial"; continue; }
                fetch 30 "$dest/$rel" "$SKILLS_BASE/$ref" || : > "$tmp/skills.partial"
            done
        done
        # Retired base skills leave the shelf. Extract ONLY the removed_skills array
        # (flattened, bounded to its first ']') so active skill names are never captured.
        removed="$(tr -d '\n' < "$sm" | sed -n 's/.*"removed_skills"[[:space:]]*:[[:space:]]*\[\([^]]*\)\].*/\1/p')"
        for rname in $(printf '%s' "$removed" | grep -oE '"[a-zA-Z0-9_-]+"' | tr -d '"'); do
            rm -rf "$SKILLS_DIR/bito-${rname}" 2>/dev/null \
                || log "could not remove retired skill bito-${rname}; it stays on the shelf"
        done
        [ -f "$tmp/skills.partial" ] \
            && log "base skills ${sver} synced with gaps; some skill files are missing from the shelf"
        if printf '%s' "$sver" > "$marker" 2>/dev/null; then
            log "base skills synced to ${sver}"
        else
            log "base skills synced to ${sver} but the ${marker} write failed; every later run will re-download them"
        fi
        # Skill files reached the shelf even on a partial sync, so per the consumer's
        # contract ("any publish counts") this still clears bundle-seeded state.
        SYNC_PUBLISHED=1
    fi
else
    log "skills CDN unreachable (${SKILLS_BASE}); keeping the current skills"
fi

# Enforce binary retention last, whenever `current` is valid — self-heals any
# buildup from before retention existed, independent of whether we published today.
_prune_shelf

# Record the outcome where the caller can read it, since the exit code cannot say.
if [ "$SYNC_PUBLISHED" = "1" ]; then
    printf 'ok' > "$SHELF/.last_sync" 2>/dev/null || true
    # Only now has bundled content actually been replaced, so only now does the shelf
    # stop being bundle-seeded. Any publish counts: a partial sync leaves a shelf that
    # is no longer purely the bundle.
    if [ "$FORCED_FROM_BUNDLE" = "1" ]; then
        log "sync published; the shelf is no longer bundle-seeded"
        rm -f "$SHELF/.bundle_seeded"
    fi
else
    printf 'unreachable' > "$SHELF/.last_sync" 2>/dev/null || true
    [ "$FORCED_FROM_BUNDLE" = "1" ] && log "nothing published; the shelf remains bundle-seeded"
fi

exit 0
