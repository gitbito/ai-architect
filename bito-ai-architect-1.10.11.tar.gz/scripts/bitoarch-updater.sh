#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
#
# Standalone plugin auto-update entrypoint. Invoked by the daily scheduler
# (launchd / systemd-timer / cron / K8s CronJob) and runnable by hand:
#
#   scripts/bitoarch-updater.sh [--scheduled]
#
# Checks every installed plugin against the distribution CDN and stages any
# newer, verified version (SHA-256 + GPG). It NEVER applies an upgrade or
# restarts base. --scheduled adds a randomized startup delay (jitter) so a fleet
# of hosts doesn't hit the CDN at the same second. Always exits 0 (best-effort).

set +e

# Resolve repo root (scripts/ -> ..). Pin SCRIPT_DIR so path-manager's layout
# detection resolves VAR_DIR correctly when run outside the bitoarch CLI.
_SELF_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SCRIPT_DIR="$(cd "${_SELF_DIR}/.." && pwd)"
export SCRIPT_DIR

scheduled=0
for a in "$@"; do
    case "$a" in
        --scheduled) scheduled=1 ;;
        --help|-h)
            sed -n '14,22p' "${BASH_SOURCE[0]}" | sed 's/^# \{0,1\}//'
            exit 0 ;;
    esac
done

# shellcheck source=/dev/null
. "${SCRIPT_DIR}/scripts/lib/path-manager.sh" 2>/dev/null || true
# Route all output to a dedicated log file (terminal stays quiet; the scheduler
# templates point their stdout/stderr at the same file).
if type get_log_dir >/dev/null 2>&1; then
    _pu_logdir="$(get_log_dir 2>/dev/null)"
    if [ -n "$_pu_logdir" ]; then
        if mkdir -p "$_pu_logdir" 2>/dev/null && { : >>"${_pu_logdir}/bitoarch-updater.log"; } 2>/dev/null; then
            export LOG_FILE="${_pu_logdir}/bitoarch-updater.log"
        else
            echo "bitoarch-updater: ${_pu_logdir} is not writable; this run's output stays on stderr only." >&2
            type bitoarch_resolve_log_file >/dev/null 2>&1 && export LOG_FILE="$(bitoarch_resolve_log_file)"
        fi
    fi
fi
# Output helpers (log_silent) when available; harmless if not.
# shellcheck source=/dev/null
. "${SCRIPT_DIR}/scripts/lib/output-blocks.sh" 2>/dev/null \
    || echo "bitoarch-updater: output-blocks.sh failed to load; this run will not write to ${LOG_FILE:-the log}." >&2
for _lib in state-journal.sh manifest-parser.sh plugin-updater.sh; do
    # shellcheck source=/dev/null
    . "${SCRIPT_DIR}/scripts/lib/plugin/${_lib}" 2>/dev/null \
        || echo "bitoarch-updater: ${_lib} failed to load; plugin updates may be skipped." >&2
done
unset _lib
# Shared Wingman shelf refresh reuses the same install/upgrade trigger.
# shellcheck source=/dev/null
. "${SCRIPT_DIR}/scripts/lib/wingman-shelf.sh" 2>/dev/null \
    || echo "bitoarch-updater: wingman-shelf.sh failed to load; the shelf will not be refreshed." >&2

if ! type plugin_update_all >/dev/null 2>&1; then
    echo "bitoarch-updater: plugin updater library not found; nothing to do." >&2
    exit 0
fi

# Jitter (0..30m) only under the scheduler; honors an explicit override and a
# test escape hatch (BITOARCH_PLUGIN_UPDATE_JITTER=0).
if [ "$scheduled" -eq 1 ]; then
    jitter="${BITOARCH_PLUGIN_UPDATE_JITTER:-}"
    if [ -z "$jitter" ]; then jitter=$(( RANDOM % 1800 )); fi
    if [ "$jitter" -gt 0 ] 2>/dev/null; then
        type log_silent >/dev/null 2>&1 && log_silent "plugin update: scheduled run, sleeping ${jitter}s jitter"
        sleep "$jitter"
    fi
fi

plugin_update_all

# Same daily cadence, same CDN-refresh intent: bring the shared Wingman shelf
# (binary + tools + base skills) up to date too. Reuses the install/upgrade
# trigger; highest-version-wins so it no-ops when already current. Best-effort —
# a shelf hiccup never affects the plugin update result.
if type wingman_shelf_populate >/dev/null 2>&1; then
    type log_silent >/dev/null 2>&1 && log_silent "plugin update: refreshing the shared Wingman shelf"
    wingman_shelf_populate wait 2>>"${LOG_FILE:-/dev/stderr}" \
        || { type log_silent >/dev/null 2>&1 && log_silent "plugin update: Wingman shelf refresh failed; the shelf keeps its current version"; }
fi
exit 0
