#!/bin/bash
# ============================================================================
# Copyright (c) 2023-2026 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# @company Bito Inc.
# @website https://bito.ai
# ============================================================================
# k8s-preflight.sh -- validates the target cluster before a Kubernetes deploy.
#
# Blocking checks fail fast with actionable messages (missing RBAC, absent
# storage classes, restricted Pod Security, unmatched node-pool selectors,
# replicas without shared RWX storage). Advisory checks only warn.

# Prevent multiple sourcing
if [ -n "${_BITOARCH_K8S_PREFLIGHT_LOADED:-}" ]; then
    return 0
fi
_BITOARCH_K8S_PREFLIGHT_LOADED=1

# Every preflight result is mirrored to setup.log so a failed run is always
# diagnosable from the log file, not just the terminal (print_* only echo).
_pf_log()  {
    if [ -n "${LOG_FILE:-}" ] && { printf '[preflight] %s\n' "$1" >> "$LOG_FILE"; } 2>/dev/null; then
        return 0
    fi
    # No usable log file: stderr rather than nothing.
    printf '[preflight] %s\n' "$1" >&2
    return 0
}
_pf_pass() { _pf_log "PASS: $1"; }   # log only -- passing checks stay in setup.log, not the console
_pf_warn() { print_warning "preflight: $1"; _pf_log "WARN: $1"; _PF_WARNED=1; }
_pf_fail() { print_error "preflight: $1"; _pf_log "FAIL: $1"; _PF_FAILED=1; }

# A single `kubectl get storageclass` can false-negative on a transient API blip
# (a good class then reads as "not found" -> a scary warning, or a wrongful fail
# on the shared check). Retry a few times before concluding it is absent (F4).
_pf_storageclass_exists() {
    local sc="$1" attempt
    for attempt in 1 2 3; do
        kubectl get storageclass "$sc" >/dev/null 2>&1 && return 0
        [ "$attempt" -lt 3 ] && sleep 2
    done
    return 1
}

# RBAC probe that tells a real denial apart from a transient API blip (F12).
# `kubectl auth can-i create` prints "yes"/"no"; a timeout / 429 / connection
# error must NOT be misread as "denied". Retry on any non-"no" result (with a
# request timeout so a call can't hang), and log the reason. Returns:
#   0 = allowed ("yes"), 1 = denied ("no"), 2 = couldn't verify (API error).
_pf_can_i_create() {   # <resource> [extra kubectl args...]
    local res="$1"; shift
    local scope="${*:+ ${*}}"      # e.g. " -n bito-ai-architect"
    local out ans attempt
    for attempt in 1 2 3 4 5; do
        # Extract the answer LINE rather than matching the whole output. kubectl puts
        # the yes/no on stdout, but for a cluster-scoped resource it also prints
        # "Warning: resource '<x>' is not namespace scoped" on stderr. Comparing the
        # merged output against "yes" therefore never matched, and create/namespace
        # and create/persistentvolumes reported "could not verify" on EVERY run --
        # deterministically, so retrying could never help. Keeping the streams merged
        # (no temp file) means the real error text is still available for the log.
        out=$(kubectl auth can-i create "$res" "$@" --request-timeout=10s 2>&1)
        ans=$(printf '%s\n' "$out" | grep -Ex 'yes|no' | tail -1)
        case "$ans" in
            yes) _pf_log "RBAC create/${res}${scope}: allowed"; return 0 ;;
            no)  _pf_log "RBAC create/${res}${scope}: DENIED (kubectl auth can-i returned 'no')"; return 1 ;;
        esac
        # no yes/no anywhere = API error / timeout / throttle -> log the real reason + retry
        _pf_log "RBAC create/${res}${scope}: attempt ${attempt}/5 could not verify -- ${out}"
        [ "$attempt" -lt 5 ] && sleep 2
    done
    _pf_log "RBAC create/${res}${scope}: UNVERIFIED after 5 attempts (API unreachable/throttled)"
    return 2
}

# Retry a read-only kubectl probe whose EMPTY output is indistinguishable from a
# real answer. The first call of a run is often slow (auth-plugin token refresh,
# connection setup), and preflight fires a dozen calls in a burst, so a single-shot
# probe reports "0 nodes" or "unknown version" on a healthy cluster. Echoes the
# first non-empty result; returns 1 when every attempt came back empty, so callers
# can tell "could not read" from a genuine zero.
_pf_probe_retry() {   # <attempts> <command...>
    local tries="$1"; shift
    local attempt out
    for attempt in $(seq 1 "$tries"); do
        out="$("$@" 2>/dev/null)"
        if [ -n "$out" ]; then printf '%s' "$out"; return 0; fi
        [ "$attempt" -lt "$tries" ] && sleep 2
    done
    return 1
}

# Ready-node count as its own function so _pf_probe_retry can call it.
_pf_ready_node_count() {
    kubectl get nodes --no-headers 2>/dev/null | awk '$2 == "Ready"' | wc -l | tr -d ' ' \
        | grep -vx '0'   # an empty/failed list counts 0 -- suppress it so the retry sees "no answer"
}

_pf_server_minor() {
    kubectl version -o json 2>/dev/null | jq -r '.serverVersion.minor // ""' 2>/dev/null | tr -dc '0-9'
}

# Count the static-NFS PVs, but ONLY when the API actually answered. This keys on
# kubectl's exit status, not on the output: `get pv -l <sel>` exits 0 and prints
# nothing when there are genuinely no matches, and exits non-zero when the read
# failed. Piping straight into `grep -c .` collapses both into "0", which is why a
# transient read used to abort a valid install claiming 0/6 PVs existed. Printing
# nothing on a failed read lets _pf_probe_retry retry and, if it never succeeds,
# lets the caller say "could not read" instead of "none found".
_pf_static_pv_count() {
    local out
    out="$(kubectl get pv -l volume-type=static-nfs -o name 2>/dev/null)" || return 1
    printf '%s' "$out" | grep -c . | tr -d ' '
}

# True when dynamic provisioning is in play for volumes that need to be shared, and no
# class was named to provide them -- the PVCs then request ReadWriteMany from the
# cluster's single-attach default and never bind, while the provisioner check further
# down is skipped for want of a class to inspect.
#
# "Needs to be shared" is either an explicit ReadWriteMany or a cluster.yaml that is
# genuinely configured. Neither signal alone is enough: keying on the provisioning type
# would catch an untouched template, because an unset storage.provisioning_type
# normalizes to "dynamic", and that blocked single-node installs; keying on access_mode
# alone missed a multi-node install spreading single-replica services across nodes with
# access_mode left unset, where the replicas>1 guard is also silent at 1 replica.
_pf_shared_rwx_class_missing() {
    [ "${STORAGE_PROVISIONING_TYPE:-}" = "dynamic" ] || return 1
    [ -z "${SHARED_STORAGE_CLASS:-}" ]               || return 1
    [ "${STORAGE_ACCESS_MODE:-}" = "ReadWriteMany" ] && return 0
    _pf_cluster_has_scheduling
}

# Which of the two signals above triggered, phrased for the failure message. Separate
# from the check so the operator-facing wording is testable on its own: a message
# hardcoded to one branch sends the operator to a key they never set.
_pf_shared_rwx_reason() {
    if [ "${STORAGE_ACCESS_MODE:-}" = "ReadWriteMany" ]; then
        printf 'storage.access_mode is ReadWriteMany'
    else
        printf 'cluster.yaml configures scheduling or replicas, so the volumes are shared across nodes'
    fi
}

# True only for mikefarah yq v4 (supports `yq eval`); python-yq / absent -> false.
_pf_yq_ok() { command -v yq >/dev/null 2>&1 && printf 'a: 1\n' | yq eval '.a' - >/dev/null 2>&1; }

# True when cluster.yaml actually sets scheduling/replica fields (so the yq-only
# overlay matters). Reads via _cluster_yaml_read_value, which uses yq-or-python
# transparently -- and check_cli_tools guarantees one is present on the install
# path -- so this works in exactly the case the yq check must catch (yq absent,
# PyYAML present).
_pf_cluster_has_scheduling() {
    command -v _cluster_yaml_read_value >/dev/null 2>&1 || return 1
    local yaml="${CLUSTER_YAML:-$HOME/.bitoarch/cluster.yaml}"
    command -v _cluster_yaml_file >/dev/null 2>&1 && yaml="$(_cluster_yaml_file)"
    [ -f "$yaml" ] || return 1
    local p v n svc fld
    local paths=(".scheduling.node_selector" ".scheduling.tolerations")
    for svc in worker config manager tracker provider mysql temporal; do
        for fld in replicas spread node_selector tolerations; do
            paths+=(".services.${svc}.${fld}")
        done
    done
    for p in "${paths[@]}"; do
        case "$p" in
            *.node_selector|*.tolerations)
                # Collections are judged by element count, never by rendered text.
                # Text comparison against '{}' / '[]' fails on a reconciled
                # cluster.yaml, which carries the template's trailing comments: a
                # `[] # why` line matches no literal and an untouched template then
                # reads as configured. Counting is structural, so a comment cannot
                # reach the decision. Without yq there is nothing to count, and an
                # unreadable collection must not be reported as configured -- that
                # direction blocks a single-node install -- so it counts as empty.
                command -v yq >/dev/null 2>&1 || continue
                n=$(yq eval "$p // {} | length" "$yaml" 2>/dev/null)
                case "$n" in ''|*[!0-9]*) continue ;; esac
                [ "$n" -gt 0 ] && return 0
                continue ;;
        esac
        v=$(_cluster_yaml_read_value "$yaml" "$p" 2>/dev/null)
        case "$v" in ''|null|'~'|'{}'|'[]') ;; *) return 0 ;; esac
    done
    return 1
}

# Selector map at a yaml path -> "k=v,k2=v2" label selector ("" when unset).
_pf_selector_at() {
    local file="$1" path="$2"
    command -v yq >/dev/null 2>&1 || return 0
    yq eval "${path} // {} | to_entries | map(.key + \"=\" + (.value | tostring)) | join(\",\")" "$file" 2>/dev/null
}

# Highest replicas across the scalable services in cluster.yaml ("" when none).
_pf_max_cluster_replicas() {
    command -v _cluster_yaml_read_value >/dev/null 2>&1 || return 0
    local yaml="${CLUSTER_YAML:-$HOME/.bitoarch/cluster.yaml}"
    command -v _cluster_yaml_file >/dev/null 2>&1 && yaml="$(_cluster_yaml_file)"
    [ -f "$yaml" ] || return 0
    local svc r max=""
    for svc in worker config manager tracker; do
        r=$(_cluster_yaml_read_value "$yaml" ".services.${svc}.replicas" 2>/dev/null)
        case "$r" in ''|null|'~'|*[!0-9]*) continue ;; esac
        { [ -z "$max" ] || [ "$r" -gt "$max" ]; } 2>/dev/null && max="$r"
    done
    [ -n "$max" ] && echo "$max"
    return 0
}

run_k8s_preflight() {
    LOG_FILE="$(bitoarch_resolve_log_file 2>/dev/null || get_setup_log)"
    local ns="${1:-bito-ai-architect}"
    _PF_FAILED=0
    _PF_WARNED=0

    print_info "Running Kubernetes preflight checks (namespace: $ns)..."

    # 1. Server version (advisory below 1.21)
    local minor
    minor=$(_pf_probe_retry 3 _pf_server_minor)
    if [ -n "$minor" ]; then
        if [ "$minor" -lt 21 ] 2>/dev/null; then
            _pf_warn "Kubernetes server 1.${minor} is older than 1.21; not regularly tested"
        else
            _pf_pass "Kubernetes server version 1.${minor}"
        fi
    else
        _pf_warn "could not determine Kubernetes server version"
    fi

    # 1b. yq (mikefarah v4) is required to apply cluster.yaml scheduling/replicas:
    # the overlay generator is yq-only and silently skips without it, dropping
    # those settings. Enforced only when cluster.yaml actually sets them, so
    # python-only single-node deploys are unaffected.
    if _pf_cluster_has_scheduling; then
        if _pf_yq_ok; then
            _pf_pass "yq (mikefarah v4) present for scheduling/replicas overlay"
        else
            _pf_fail "cluster.yaml sets scheduling/replicas but mikefarah yq (v4) is not installed; those settings would be silently dropped. Install: https://github.com/mikefarah/yq"
        fi
    fi

    # 2. RBAC: resources the chart creates in the namespace. Only a definitive
    # "no" counts as missing; a transient API error is tracked separately so we
    # never false-abort on a blip (F12) -- see _pf_can_i_create.
    _pf_log "RBAC check: verifying 'create' permissions in namespace '${ns}'${STORAGE_PROVISIONING_TYPE:+ (provisioning=${STORAGE_PROVISIONING_TYPE})}"
    local missing_verbs="" unverified="" r rc
    for r in deployment service persistentvolumeclaim secret configmap serviceaccount; do
        _pf_can_i_create "$r" -n "$ns"; rc=$?
        [ "$rc" -eq 1 ] && missing_verbs="${missing_verbs} create/${r}"
        [ "$rc" -eq 2 ] && unverified="${unverified} create/${r}"
    done
    if ! kubectl get ns "$ns" >/dev/null 2>&1; then
        _pf_can_i_create namespace; rc=$?
        [ "$rc" -eq 1 ] && missing_verbs="${missing_verbs} create/namespace"
        [ "$rc" -eq 2 ] && unverified="${unverified} create/namespace"
    fi
    # Static NFS provisioning also creates cluster-scoped PVs and a prep Job in
    # the default namespace -- permissions beyond the namespaced verbs above.
    # Dynamic provisioning needs none of these (the CSI driver owns PV creation),
    # so gate on the provisioning type, not on the shared class being set.
    if [ "${STORAGE_PROVISIONING_TYPE:-}" = "static" ]; then
        _pf_can_i_create persistentvolumes; rc=$?
        [ "$rc" -eq 1 ] && missing_verbs="${missing_verbs} create/persistentvolumes(cluster-scoped)"
        [ "$rc" -eq 2 ] && unverified="${unverified} create/persistentvolumes(cluster-scoped)"
        _pf_can_i_create jobs -n default; rc=$?
        [ "$rc" -eq 1 ] && missing_verbs="${missing_verbs} create/jobs(namespace=default)"
        [ "$rc" -eq 2 ] && unverified="${unverified} create/jobs(namespace=default)"
    fi
    if [ -n "$missing_verbs" ]; then
        _pf_fail "missing RBAC permissions:${missing_verbs} (grant these create verbs to the installer's identity)"
    elif [ -n "$unverified" ]; then
        _pf_warn "couldn't verify RBAC for:${unverified} (API error -- see setup log)"
    else
        _pf_pass "RBAC permissions sufficient"
    fi

    # 3. Shared storage: with an explicit provisioning type we check the right
    # thing directly instead of deducing static from a missing StorageClass.
    #   static  -> the pre-created shared PVs must exist (no StorageClass expected)
    #   dynamic -> the shared StorageClass must exist
    local shared_provisioner="" mysql_provisioner=""
    if [ "${STORAGE_PROVISIONING_TYPE:-}" = "static" ]; then
        local static_pvs
        # Three outcomes, not two -- the whole point of the fix. A read that FAILED is
        # not evidence the PVs are missing, and this branch aborts the install, so
        # treating "unreadable" as "none found" blocked valid installs on a blip.
        local static_known=1
        static_pvs="$(_pf_probe_retry 3 _pf_static_pv_count)" || static_known=0
        if [ "$static_known" -eq 0 ]; then
            _pf_warn "could not read the PersistentVolume list after 3 attempts; skipping the static-PV check (the storage prep step above reports its own result)"
        elif [ "$static_pvs" -ge 6 ] 2>/dev/null; then
            _pf_pass "static provisioning: ${static_pvs} shared PV(s) ready"
        else
            _pf_fail "static provisioning selected but only ${static_pvs}/6 shared PVs found; the NFS prep step should have created all six (see setup.log)"
        fi
    elif [ -n "${SHARED_STORAGE_CLASS:-}" ]; then
        if _pf_storageclass_exists "$SHARED_STORAGE_CLASS"; then
            _pf_pass "shared StorageClass exists: $SHARED_STORAGE_CLASS"
            shared_provisioner=$(kubectl get storageclass "$SHARED_STORAGE_CLASS" -o jsonpath='{.provisioner}' 2>/dev/null)
        else
            _pf_fail "shared StorageClass '$SHARED_STORAGE_CLASS' not found (dynamic provisioning needs it); create it, or set storage.provisioning_type: static with an nfs share"
        fi
    elif _pf_shared_rwx_class_missing; then
        _pf_fail "$(_pf_shared_rwx_reason), and provisioning_type is dynamic, but storage.shared_class is not set. Name a ReadWriteMany StorageClass, or set storage.provisioning_type: static with an nfs: share if the volumes are pre-created (shared volumes cannot fall back to the cluster default, which is single-attach)"
    fi

    # MySQL always uses a real (block) StorageClass, regardless of the shared mode.
    if [ -n "${MYSQL_STORAGE_CLASS:-}" ]; then
        if _pf_storageclass_exists "$MYSQL_STORAGE_CLASS"; then
            _pf_pass "MySQL StorageClass exists: $MYSQL_STORAGE_CLASS"
            mysql_provisioner=$(kubectl get storageclass "$MYSQL_STORAGE_CLASS" -o jsonpath='{.provisioner}' 2>/dev/null)
        else
            _pf_warn "MySQL StorageClass '$MYSQL_STORAGE_CLASS' not found; will fall back to the cluster default"
        fi
    fi

    # 4. RWX advisory: shared class provisioner should support multi-node access
    if [ "${STORAGE_ACCESS_MODE:-}" = "ReadWriteMany" ] && [ -n "$shared_provisioner" ]; then
        case "$shared_provisioner" in
            *local-path*|*ebs*|*pd.csi*|*disk.csi.azure*)
                _pf_warn "shared class '$SHARED_STORAGE_CLASS' uses single-node provisioner '$shared_provisioner'; ReadWriteMany volumes will likely fail to bind" ;;
            *)
                _pf_pass "shared class provisioner: $shared_provisioner" ;;
        esac
    fi

    # 5. MySQL-on-NFS guard (databases are unsafe on network filesystems)
    if [ -n "$mysql_provisioner" ]; then
        case "$mysql_provisioner" in
            *efs.csi*|*nfs*|*file.csi.azure*|*cephfs*)
                _pf_warn "MySQL class '$MYSQL_STORAGE_CLASS' uses NFS-family provisioner '$mysql_provisioner'; databases risk corruption on network filesystems — use a block class (gp3/PD/Longhorn)" ;;
        esac
    fi
    if [ "${STORAGE_ACCESS_MODE:-}" = "ReadWriteMany" ] && [ -n "${MYSQL_STORAGE_CLASS:-}" ] \
        && [ "${MYSQL_STORAGE_CLASS}" = "${SHARED_STORAGE_CLASS:-}" ]; then
        _pf_warn "MySQL shares the RWX class '$MYSQL_STORAGE_CLASS' with app data; give MySQL its own block class"
    fi

    # 6. Pod Security posture of the target namespace
    if kubectl get ns "$ns" >/dev/null 2>&1; then
        local psa
        psa=$(kubectl get ns "$ns" -o jsonpath='{.metadata.labels.pod-security\.kubernetes\.io/enforce}' 2>/dev/null)
        if [ "$psa" = "restricted" ]; then
            _pf_fail "namespace '$ns' enforces Pod Security 'restricted'; the chart's init containers need 'baseline'"
        else
            _pf_pass "Pod Security posture: ${psa:-unset (baseline behavior)}"
        fi
    fi

    # 7. Image pull secret must already exist with the right type
    if [ -n "${K8S_IMAGE_PULL_SECRET:-}" ]; then
        if kubectl get ns "$ns" >/dev/null 2>&1; then
            local stype
            stype=$(kubectl get secret "$K8S_IMAGE_PULL_SECRET" -n "$ns" -o jsonpath='{.type}' 2>/dev/null)
            if [ -z "$stype" ]; then
                _pf_fail "pull secret '$K8S_IMAGE_PULL_SECRET' not found in namespace '$ns' (kubectl create secret docker-registry ...)"
            elif [ "$stype" != "kubernetes.io/dockerconfigjson" ]; then
                _pf_fail "pull secret '$K8S_IMAGE_PULL_SECRET' has type '$stype'; expected kubernetes.io/dockerconfigjson"
            else
                _pf_pass "pull secret exists: $K8S_IMAGE_PULL_SECRET"
            fi
        else
            _pf_warn "pull secret '$K8S_IMAGE_PULL_SECRET' will be checked after namespace creation"
        fi
    fi

    # 8. Nodes, replicas and node-pool selectors
    # The node count is recorded for diagnostics only (log, not console). There is no
    # replicas-vs-nodes warning: with maxSkew 1 a pool smaller than the replica count
    # simply co-locates the surplus as evenly as possible -- normal, documented
    # behaviour (see cluster.yaml.default), not something to warn about.
    local ready_nodes
    if ready_nodes="$(_pf_probe_retry 3 _pf_ready_node_count)"; then
        _pf_pass "Ready nodes: ${ready_nodes}"
    else
        # A failed read is not "0 nodes are Ready" -- log it and move on.
        _pf_log "could not read the node list (informational only)"
    fi

    local max_replicas="${CIS_WORKER_REPLICA_COUNT:-1}"
    local cluster_max
    cluster_max=$(_pf_max_cluster_replicas)
    if [ -n "$cluster_max" ] && [ "$cluster_max" -gt "$max_replicas" ] 2>/dev/null; then
        max_replicas="$cluster_max"
    fi
    if [ "$max_replicas" -gt 1 ] 2>/dev/null; then
        if [ "${STORAGE_ACCESS_MODE:-ReadWriteOnce}" != "ReadWriteMany" ]; then
            _pf_fail "replicas > 1 configured but storage access_mode is not ReadWriteMany; shared data volumes cannot follow pods across nodes on ReadWriteOnce. Set storage.access_mode: ReadWriteMany in cluster.yaml"
        fi
    fi

    if [ -n "${CLUSTER_PROVIDER_REPLICAS_IGNORED:-}" ]; then
        _pf_warn "services.provider.replicas in cluster.yaml is ignored; the MCP provider runs a single replica (scaling it is a separate initiative)"
    fi

    local cyaml="${CLUSTER_YAML:-$HOME/.bitoarch/cluster.yaml}"
    command -v _cluster_yaml_file >/dev/null 2>&1 && cyaml="$(_cluster_yaml_file)"
    if [ -f "$cyaml" ] && command -v yq >/dev/null 2>&1; then
        local path sel seen="" gtol
        gtol=$(_cluster_yaml_read_value "$cyaml" ".scheduling.tolerations" 2>/dev/null)
        for path in .scheduling.node_selector \
                    .services.worker.node_selector .services.config.node_selector \
                    .services.manager.node_selector .services.tracker.node_selector \
                    .services.provider.node_selector .services.mysql.node_selector \
                    .services.temporal.node_selector; do
            sel=$(_pf_selector_at "$cyaml" "$path")
            [ -n "$sel" ] || continue
            case " $seen " in *" $sel "*) continue ;; esac
            seen="$seen $sel"
            local matched
            matched=$(kubectl get nodes -l "$sel" --no-headers 2>/dev/null | awk '$2 == "Ready"' | wc -l | tr -d ' ')
            if [ "${matched:-0}" -lt 1 ] 2>/dev/null; then
                _pf_fail "node selector '$sel' matches no Ready node; check the node group/pool label with: kubectl get nodes --show-labels"
            else
                _pf_pass "node selector '$sel' matches ${matched} node(s)"
                local taints
                taints=$(kubectl get nodes -l "$sel" -o jsonpath='{range .items[*]}{.spec.taints[*].key}{" "}{end}' 2>/dev/null | tr -d ' ')
                if [ -n "$taints" ]; then
                    case "$gtol" in ''|null|'~'|'[]') _pf_warn "nodes matching '$sel' are tainted but no tolerations are configured; pods may stay Pending" ;; esac
                fi
            fi
        done
    fi

    if [ "$_PF_FAILED" -ne 0 ]; then
        print_error "Preflight failed; fix the items above and re-run. Nothing was deployed."
        return 1
    fi
    if [ "${_PF_WARNED:-0}" -ne 0 ]; then
        # A warning (e.g. an RBAC check the API couldn't confirm in time) is NOT a
        # failure -- preflight is advisory and the cluster enforces the real rules
        # at create time. Say so plainly instead of a clean "passed", so it's clear
        # WHY we proceeded (couldn't verify != confirmed).
        print_warning "Preflight passed WITH WARNINGS (see above / setup log) -- proceeding. Unverified checks are not denials; a real problem will surface as a Forbidden at deploy time."
        return 0
    fi
    print_status "Preflight checks passed"
    return 0
}

if [[ "${BASH_SOURCE[0]}" != "${0}" ]]; then
    export -f run_k8s_preflight
fi
