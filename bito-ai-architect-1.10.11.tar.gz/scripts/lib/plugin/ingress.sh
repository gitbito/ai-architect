#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
#
# Generic public-endpoint ingress (docker-compose): one shared ai-architect-ingress nginx whose vhost is rebuilt from a route registry.
# The registry = core routes.d/*.route ∪ each plugin manifest's `routes:`. On Kubernetes each plugin's own Ingress inherits the shared class/host (BITOARCH_INGRESS_CLASS/HOST) = one front door.

if [ -n "${_BITOARCH_PLUGIN_INGRESS_LOADED:-}" ]; then
    return 0
fi
_BITOARCH_PLUGIN_INGRESS_LOADED=1

_BITOARCH_PLUGIN_INGRESS_SELF="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if ! type get_plugin_install_dir >/dev/null 2>&1; then
    # shellcheck source=/dev/null
    . "${_BITOARCH_PLUGIN_INGRESS_SELF}/../path-manager.sh" 2>/dev/null || true
fi
if ! type journal_list_plugins >/dev/null 2>&1; then
    # shellcheck source=/dev/null
    . "${_BITOARCH_PLUGIN_INGRESS_SELF}/state-journal.sh" 2>/dev/null || true
fi
if ! type manifest_routes >/dev/null 2>&1; then
    # shellcheck source=/dev/null
    . "${_BITOARCH_PLUGIN_INGRESS_SELF}/manifest-parser.sh" 2>/dev/null || true
fi

_ingress_log()  { type log_silent >/dev/null 2>&1 && log_silent "ingress: $1"; }
_ingress_warn() { if type print_warning >/dev/null 2>&1; then print_warning "$1" >&2; else printf 'WARNING: %s\n' "$1" >&2; fi; type log_silent >/dev/null 2>&1 && log_silent "ingress: $1"; }

# The shared ingress service name + HOST-published port (in sync with compose / .env). Overridable for tests.
INGRESS_SERVICE_NAME="${INGRESS_SERVICE_NAME:-${SERVICE_INGRESS_NAME:-ai-architect-ingress}}"
INGRESS_PORT="${INGRESS_PORT:-5080}"

# Directory of core static *.route files (PATH|HOST|PORT per line), beside the base config so routes can be seeded without code.
_ingress_routes_dir() {
    echo "${BITOARCH_INGRESS_ROUTES_DIR:-${BITOARCH_CONFIG_DIR:-/usr/local/etc/bitoarch}/ingress/routes.d}"
}
# The rendered nginx conf the ai-architect-ingress container serves.
_ingress_conf_path() {
    echo "${BITOARCH_INGRESS_CONF:-${BITOARCH_CONFIG_DIR:-/usr/local/etc/bitoarch}/ingress/conf.d/plugins.conf}"
}

# A route line is "<path>|<host>|<port>"; reject blanks/comments/malformed so a stray file can't inject a broken nginx block.
_ingress_route_ok() {
    # "<path>|<host>|<port>": absolute path, non-empty host, numeric port. A case
    # pattern cannot express this (\| is alternation there), so use a regex.
    printf '%s' "$1" | grep -Eq '^/[^|]*\|[^|]+\|[0-9]+$'
}

# Stricter gate for UNTRUSTED plugin routes: a plugin's plugin.yaml is authored outside the
# platform, and its path/host land verbatim in nginx directives. On top of the shape check,
# restrict path + host to a safe allow-list so no nginx-significant character (whitespace, ; { }
# $ " ' \ #, newlines) can smuggle in arbitrary directives.
_ingress_plugin_route_ok() {
    local line="$1" path rest host port
    _ingress_route_ok "$line" || return 1
    path="${line%%|*}"; rest="${line#*|}"; host="${rest%%|*}"; port="${rest##*|}"
    printf '%s' "$path" | grep -Eq '^/[A-Za-z0-9._~/-]*$' || return 1
    printf '%s' "$host" | grep -Eq '^[A-Za-z0-9._-]+$'     || return 1
    printf '%s' "$port" | grep -Eq '^[0-9]{1,5}$'          || return 1
    return 0
}

# Emit core routes from routes.d/*.route (PATH|HOST|PORT lines), skipping comments/blanks. No-op when the dir is absent.
_ingress_core_routes() {
    local dir f line
    dir="$(_ingress_routes_dir)"
    [ -d "$dir" ] || return 0
    for f in "$dir"/*.route; do
        [ -f "$f" ] || continue
        while IFS= read -r line || [ -n "$line" ]; do
            case "$line" in ''|\#*) continue ;; esac
            _ingress_route_ok "$line" && printf '%s\n' "$line"
        done < "$f"
    done
}

# Emit installed plugins' manifest routes (PATH|HOST|PORT lines); with a name arg, only that plugin's, else walk the journal.
# Each route is gated by the strict allow-list — an untrusted plugin.yaml cannot inject nginx directives.
_ingress_emit_plugin_routes() {   # <plugin-name> <manifest>
    local _pn="$1" _man="$2" line
    manifest_routes "$_man" | while IFS= read -r line; do
        [ -n "$line" ] || continue
        if _ingress_plugin_route_ok "$line"; then
            printf '%s\n' "$line"
        else
            _ingress_warn "ignoring unsafe route from plugin '${_pn}': ${line}"
        fi
    done
}
_ingress_plugin_routes() {
    local only="${1:-}" p man
    if [ -n "$only" ]; then
        man="$(get_plugin_install_dir "$only")/plugin.yaml"
        [ -f "$man" ] && _ingress_emit_plugin_routes "$only" "$man"
        return 0
    fi
    while IFS= read -r p; do
        [ -z "$p" ] && continue
        man="$(get_plugin_install_dir "$p")/plugin.yaml"
        [ -f "$man" ] && _ingress_emit_plugin_routes "$p" "$man"
    done <<EOF
$(journal_list_plugins 2>/dev/null)
EOF
}

# Full registry = core ∪ plugin routes, de-duped on path (first wins), longest-path-first so nginx matches the most specific prefix.
_ingress_collect_routes() {
    local seen=" " path rest
    {
        _ingress_core_routes
        _ingress_plugin_routes
    } | while IFS= read -r line; do
        [ -n "$line" ] || continue
        path="${line%%|*}"
        case "$seen" in *" ${path} "*) continue ;; esac
        seen="${seen}${path} "
        printf '%s\n' "$line"
    done | awk -F'|' '{ print length($1)"\t"$0 }' | sort -rn -k1,1 | cut -f2-
}

# Render the registry as nginx LOCATION blocks only (no server{} wrapper; base bootstrap owns the default server and includes these).
# Each upstream resolves through a variable + resolver, so nginx stays up when a plugin is down (502 at request time, not a boot failure).
# The resolver directive itself lives in 00-ingress-base.conf, written by the base compose ingress service.
_ingress_conf() {
    local path host port idx=0
    while IFS='|' read -r path host port; do
        [ -n "$path" ] || continue
        idx=$((idx + 1))
        printf 'location %s {\n' "$path"
        printf '    set $upstream_%s "http://%s:%s";\n' "$idx" "$host" "${port:-8080}"
        printf '    proxy_pass $upstream_%s$request_uri;\n' "$idx"
        printf '    proxy_set_header Host $host;\n'
        printf '    proxy_set_header X-Real-IP $remote_addr;\n'
        printf '    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;\n'
        printf '    proxy_set_header X-Forwarded-Proto $scheme;\n'
        printf '}\n'
    done <<EOF
$(_ingress_collect_routes)
EOF
}

# Turn a docker start/up error into a clear, actionable warning (never silent).
# Always logs the raw docker error; detects the common host-port bind clash and
# names the single knob (INGRESS_PORT) so the customer can self-serve.
_ingress_report_start_failure() {   # <docker-error-text>
    local err="$1"
    type log_silent >/dev/null 2>&1 && [ -n "$err" ] \
        && log_silent "ingress: docker error: $(printf '%s' "$err" | tr '\n' ' ')"
    if printf '%s' "$err" | grep -qiE 'port is already allocated|address already in use|bind for .* failed'; then
        _ingress_warn "host port ${INGRESS_PORT} is already in use, so the ingress (${INGRESS_SERVICE_NAME}) cannot start — plugin webhooks are unreachable. Fix: set INGRESS_PORT to a free port in the base .env-bitoarch and re-run (point your existing front door at it), or free port ${INGRESS_PORT}."
    else
        _ingress_warn "could not start the shared ingress (${INGRESS_SERVICE_NAME}); plugin public routes are unreachable on host port ${INGRESS_PORT}. See the setup log for the docker error."
    fi
}

# Ensure the shared ingress container is RUNNING, creating/recovering it on-demand
# from the base compose. Docker only; idempotent. Surfaces failures (never silent).
_ingress_ensure_up() {
    command -v docker >/dev/null 2>&1 || return 0
    # Already running -> nothing to do (reload handles conf refresh).
    docker ps --format '{{.Names}}' 2>/dev/null | grep -qx "$INGRESS_SERVICE_NAME" && return 0
    # Exists but not running (Created/Exited) -> a prior start failed, usually a
    # host-port clash. Remove the stale container so we recreate with the current
    # port mapping; the compose up below surfaces the real reason.
    if docker ps -a --format '{{.Names}}' 2>/dev/null | grep -qx "$INGRESS_SERVICE_NAME"; then
        _ingress_log "ingress ${INGRESS_SERVICE_NAME} exists but is not running; recreating to pick up the current port"
        docker rm -f "$INGRESS_SERVICE_NAME" >/dev/null 2>&1 || true
    fi
    local cc cf ef pdir out
    pdir="${PLATFORM_DIR:-$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." 2>/dev/null && pwd)}"
    cf="${pdir}/docker-compose.yml"
    if [ ! -f "$cf" ]; then
        _ingress_warn "shared ingress is not running and the base compose was not found at ${cf}; plugin routes on host port ${INGRESS_PORT} will be unreachable until the platform is started"
        return 0
    fi
    cc="docker compose"; type get_docker_compose_cmd >/dev/null 2>&1 && cc="$(get_docker_compose_cmd 2>/dev/null || echo 'docker compose')"
    ef=""; command -v get_config_file >/dev/null 2>&1 && ef="$(get_config_file 2>/dev/null)"
    if [ -n "$ef" ] && [ -f "$ef" ]; then
        out="$($cc -f "$cf" --env-file "$ef" up -d "$INGRESS_SERVICE_NAME" 2>&1)"
    else
        out="$($cc -f "$cf" up -d "$INGRESS_SERVICE_NAME" 2>&1)"
    fi
    # Judge by the actual running state, not the exit code: a host-port clash can
    # leave the container Created with a non-obvious rc.
    if docker ps --format '{{.Names}}' 2>/dev/null | grep -qx "$INGRESS_SERVICE_NAME"; then
        _ingress_log "started ${INGRESS_SERVICE_NAME} on host port ${INGRESS_PORT}"
    else
        _ingress_report_start_failure "$out"
    fi
    return 0
}

# Reload the ingress nginx so a fresh conf takes effect without dropping connections; revives a stopped container. Best-effort.
_ingress_reload() {
    command -v docker >/dev/null 2>&1 || return 0
    docker ps -a --format '{{.Names}}' 2>/dev/null | grep -qx "$INGRESS_SERVICE_NAME" || return 0
    # Graceful reload when nginx is up with a valid conf, else HARD-RESTART (a bare reload can't recover a container with no live nginx).
    # nginx -t's output is the only diagnostic for a conf this framework just
    # generated, so capture it rather than discard it before the hard restart.
    local _t_out _r_out _restart_out _t_rc
    _t_out="$(docker exec "$INGRESS_SERVICE_NAME" nginx -t 2>&1)"; _t_rc=$?
    if [ "$_t_rc" -eq 0 ] && _r_out="$(docker exec "$INGRESS_SERVICE_NAME" nginx -s reload 2>&1)"; then
        _ingress_log "reloaded ${INGRESS_SERVICE_NAME}"
    else
        # Label each failure with the output that actually belongs to it. Logging
        # $_t_out under a "check/reload failed" heading printed nginx -t's SUCCESS
        # text when it was the reload that failed, and reusing $_r_out for the
        # restart below destroyed the reload error before it was ever recorded.
        if [ "$_t_rc" -ne 0 ]; then
            _ingress_log "nginx config check failed: $(printf '%s' "$_t_out" | tail -c 400)"
        else
            _ingress_log "nginx config check passed but reload failed: $(printf '%s' "${_r_out:-}" | tail -c 400)"
        fi
        if _restart_out="$(docker restart "$INGRESS_SERVICE_NAME" 2>&1)"; then
            _ingress_log "restarted ${INGRESS_SERVICE_NAME}"
        else
            _ingress_warn "could not reload or restart ${INGRESS_SERVICE_NAME}; plugin routes may be unavailable: $(printf '%s' "${_restart_out:-}" | tail -c 300)"
        fi
    fi
    return 0
}

# K8s: adopt the host from a saved PUBLIC_URL as the shared ingress host, so no
# separate BITOARCH_INGRESS_HOST step is needed (docker parity). Persists to the
# base env, exports for this run, and patches the live base Ingress; plugin
# Ingresses pick the host up at their next deploy/recreate.
ingress_set_host_from_public_url() {   # <public-url>
    local url="$1" host base_env ns
    [ -n "$url" ] || return 0
    [ "$(get_deployment_type 2>/dev/null)" = "kubernetes" ] || return 0
    host="${url#*://}"; host="${host#*@}"; host="${host%%/*}"; host="${host%%:*}"
    [ -n "$host" ] || return 0
    # Never adopt a non-hostname: this value is written into the base env, which
    # the CLI sources at startup -- stray words there execute as commands.
    case "$host" in *[!A-Za-z0-9.-]*) return 0 ;; esac
    [ "$host" = "${BITOARCH_INGRESS_HOST:-}" ] && return 0
    export BITOARCH_INGRESS_HOST="$host"
    base_env="$(get_config_file 2>/dev/null)"
    if [ -n "$base_env" ] && [ -f "$base_env" ] && type plugin_env_set >/dev/null 2>&1; then
        plugin_env_set "$base_env" BITOARCH_INGRESS_HOST "$host" >/dev/null 2>&1 \
            || _ingress_warn "could not persist BITOARCH_INGRESS_HOST to ${base_env}; the host will be lost on the next CLI run"
    fi
    ns="${BITOARCH_K8S_NAMESPACE:-bito-ai-architect}"
    # Patch as helm's field manager: the base Ingress is helm-owned (SSA), and a
    # foreign manager on .spec.rules makes every later helm upgrade conflict.
    # The comment above anticipates SSA field-manager conflicts — surface that
    # error instead of claiming the host was adopted when the patch failed.
    if kubectl patch ingress ai-architect-ingress -n "$ns" --type=json --field-manager=helm \
        -p '[{"op":"add","path":"/spec/rules/0/host","value":"'"$host"'"}]' >>"${LOG_FILE:-/dev/null}" 2>&1; then
        _ingress_log "adopted ingress host '${host}' from PUBLIC_URL"
    else
        _ingress_warn "could not set the base Ingress host to '${host}'; the public host will not route"
    fi
    return 0
}

# ingress_sync — rebuild the conf from the registry and reload nginx (docker only).
# On Kubernetes each plugin's own Ingress already routes its paths under the shared
# class/host, so there is no shared conf to rebuild. Returns 0 even if the reload can't run.
ingress_sync() {
    local deploy conf
    deploy="$(get_deployment_type 2>/dev/null || echo docker-compose)"
    if [ "$deploy" = "kubernetes" ]; then
        _ingress_log "kubernetes deployment: per-plugin Ingress inherits the shared class/host at deploy; no shared conf to sync"
        return 0
    fi
    # Render locations to a staging file, then docker cp them into the ingress's conf.d/routes.d (on the shared volume) so nginx serves them.
    conf="$(_ingress_conf_path)"
    mkdir -p "$(dirname "$conf")" 2>/dev/null || true
    if ! _ingress_conf > "$conf" 2>>"${LOG_FILE:-/dev/null}"; then
        _ingress_warn "could not write the ingress conf at ${conf}; plugin routes were not updated"
        return 1
    fi
    _ingress_ensure_up
    if command -v docker >/dev/null 2>&1 \
       && docker ps -a --format '{{.Names}}' 2>/dev/null | grep -qx "$INGRESS_SERVICE_NAME"; then
        docker exec "$INGRESS_SERVICE_NAME" mkdir -p /etc/nginx/conf.d/routes.d >>"${LOG_FILE:-/dev/null}" 2>&1 \
            || _ingress_log "could not create /etc/nginx/conf.d/routes.d in ${INGRESS_SERVICE_NAME}"
        local _cp_out
        if _cp_out="$(docker cp "$conf" "${INGRESS_SERVICE_NAME}:/etc/nginx/conf.d/routes.d/plugins.conf" 2>&1)"; then
            _ingress_log "published ingress routes -> ${INGRESS_SERVICE_NAME}:/etc/nginx/conf.d/routes.d/plugins.conf"
        else
            _ingress_warn "could not publish ingress routes into ${INGRESS_SERVICE_NAME}; plugin paths may be unreachable on port ${INGRESS_PORT}: $(printf '%s' "$_cp_out" | tail -c 300)"
        fi
    fi
    _ingress_reload
    return 0
}

# Public wrapper invoked from install/uninstall to sync after a plugin's routes change.
plugin_ingress_sync() { ingress_sync "$@"; }

export -f ingress_sync plugin_ingress_sync _ingress_ensure_up 2>/dev/null || true
