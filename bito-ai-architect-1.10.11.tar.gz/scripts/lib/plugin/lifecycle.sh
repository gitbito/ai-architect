#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
#
# Lifecycle integration helpers. Each is a no-op when no plugin is installed.

if [ -n "${_BITOARCH_PLUGIN_LIFECYCLE_LOADED:-}" ]; then
    return 0
fi
_BITOARCH_PLUGIN_LIFECYCLE_LOADED=1

_BITOARCH_PLUGIN_LIFECYCLE_SELF="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
for _dep in state-journal.sh manifest-parser.sh deploy.sh uninstall-flow.sh reserved-keys.sh dependency-manager.sh; do
    # These are required: a silent miss leaves journal_list_plugins/_plugin_start
    # undefined, which turns every lifecycle fan-out (start/stop/restart/down/
    # reset) into a no-op that still reports success. Name the module that failed.
    # shellcheck source=/dev/null
    # printf, not _lc_log: the loggers are defined below this loop, so calling one
    # here would be a "command not found" (rc 127) that aborts callers under set -e.
    . "${_BITOARCH_PLUGIN_LIFECYCLE_SELF}/${_dep}" \
        || printf 'plugin lifecycle: could not load required component %s; lifecycle will be degraded\n' "$_dep" >&2
done
unset _dep
# The compose-cmd resolver lives in the base docker-manager (two dirs up), not in
# plugin/. Source it so plugin health checks in the base `status` path resolve the
# host's actual compose command (docker compose vs docker-compose) rather than a
# literal "docker compose" guess that breaks on docker-compose-v1-only hosts.
type get_docker_compose_cmd >/dev/null 2>&1 || \
    . "${_BITOARCH_PLUGIN_LIFECYCLE_SELF}/../../docker-manager.sh" 2>/dev/null || true

_lc_log()  { type log_silent >/dev/null 2>&1 && log_silent "plugin lifecycle: $1"; }
_lc_warn() { if type print_warning >/dev/null 2>&1; then print_warning "$1" >&2; else printf 'WARNING: %s\n' "$1" >&2; fi; }
_lc_subheader() { if type print_subheader >/dev/null 2>&1; then print_subheader "$1"; else echo "$1"; fi; }

plugin_lifecycle_any() { [ -n "$(journal_list_plugins 2>/dev/null)" ]; }

_lc_dir()      { get_plugin_install_dir "$1"; }
_lc_manifest() { echo "$(get_plugin_install_dir "$1")/plugin.yaml"; }

_lc_for_each() {
    local action="$1" p
    while IFS= read -r p; do
        [ -z "$p" ] && continue
        "$action" "$p"
    done <<EOF
$(journal_list_plugins)
EOF
}

_lc_start_one()    {
    if type dep_resolve_requires >/dev/null 2>&1; then
        dep_resolve_requires "$(_lc_manifest "$1")" "$1" >/dev/null 2>&1 \
            || _lc_log "dependency packs could not be provisioned for $1; it may not start"
    fi
    if _plugin_start "$1" "$(_lc_dir "$1")" "$(_lc_manifest "$1")" >/dev/null 2>&1; then
        _lc_log "started plugin $1"
    else
        _lc_log "FAILED to start plugin $1 (rc=$?)"
    fi
}
_lc_stop_one()     { if _plugin_stop     "$1" "$(_lc_dir "$1")" "$(_lc_manifest "$1")" >/dev/null 2>&1; then _lc_log "stopped plugin $1";   else _lc_log "FAILED to stop plugin $1 (rc=$?); its containers may still be running"; fi; }
_lc_restart_one()  { if _plugin_restart  "$1" "$(_lc_dir "$1")" "$(_lc_manifest "$1")" >/dev/null 2>&1; then _lc_log "restarted plugin $1"; else _lc_log "FAILED to restart plugin $1 (rc=$?)"; fi; }
_lc_recreate_one() { if _plugin_recreate "$1" "$(_lc_dir "$1")" "$(_lc_manifest "$1")" >/dev/null 2>&1; then _lc_log "recreated plugin $1"; else _lc_log "FAILED to recreate plugin $1 (rc=$?)"; fi; }
# Upgrade a plugin to its latest CDN version, reusing the exact `plugin upgrade`
# flow, which now resolves <name>-latest.json from the CDN by default (no --source). Same-version = idempotent redeploy; unhealthy = built-in rollback;
# CDN-unreachable / held-on-missing-cred = best-effort no-op. upgrade-flow.sh is
# not in the base dep list, so load it lazily.
_lc_upgrade_one()  {
    type plugin_upgrade >/dev/null 2>&1 \
        || . "${_BITOARCH_PLUGIN_LIFECYCLE_SELF}/upgrade-flow.sh" 2>/dev/null || return 0
    if plugin_upgrade "$1" >/dev/null 2>&1; then
        _lc_log "upgraded plugin $1 to latest (CDN)"
    else
        _lc_log "plugin $1 upgrade FAILED (rc=$?); left at its current version"
    fi
}
_lc_update_one()   { if _plugin_recreate "$1" "$(_lc_dir "$1")" "$(_lc_manifest "$1")" "Always" >/dev/null 2>&1; then _lc_log "updated plugin $1 (pull + recreate, policy Always)"; else _lc_log "FAILED to update plugin $1 (rc=$?)"; fi; }

plugin_lifecycle_start_all()   { plugin_lifecycle_any || return 0; _lc_for_each _lc_start_one; }
plugin_lifecycle_stop_all()    {
    plugin_lifecycle_any || return 0
    _lc_for_each _lc_stop_one
    # Plugins are down; stop their shared dependency packs too (kafka/redis must not keep
    # running on a stopped stack). `bitoarch start` revives them: dep_resolve_requires →
    # dep_pack_provision `up -d` runs before each plugin starts.
    local cap
    while IFS= read -r cap; do
        [ -z "$cap" ] && continue
        if type _dep_stop_pack >/dev/null 2>&1 && _dep_stop_pack "$cap" >/dev/null 2>&1; then
            _lc_log "stopped dependency pack $cap"
        else
            _lc_log "FAILED to stop dependency pack $cap; it may still be running"
        fi
    done <<EOF
$(journal_list_packs 2>/dev/null)
EOF
}
# --force recreates containers so they reload the plugin .env-bitoarch.
plugin_lifecycle_restart_all() {
    plugin_lifecycle_any || return 0
    # Shared dependency packs first (kafka/redis), so plugin services come back
    # against freshly-restarted brokers instead of reconnect-looping.
    local cap
    while IFS= read -r cap; do
        [ -z "$cap" ] && continue
        if type _dep_restart_pack >/dev/null 2>&1 && _dep_restart_pack "$cap" >/dev/null 2>&1; then
            _lc_log "restarted dependency pack $cap"
        else
            _lc_log "FAILED to restart dependency pack $cap; dependent plugins may reconnect-loop"
        fi
    done <<EOF
$(journal_list_packs 2>/dev/null)
EOF
    if [ "${1:-}" = "--force" ]; then
        # Live install.yaml reload for plugins — mirrors the base env re-apply on --force.
        type plugin_preseed_reapply_config >/dev/null 2>&1 \
            || . "${_BITOARCH_PLUGIN_LIFECYCLE_SELF}/preseed.sh" \
            || _lc_log "could not load preseed.sh; install.yaml plugin config will not be reapplied"
        if type plugin_preseed_reapply_config >/dev/null 2>&1; then
            plugin_preseed_reapply_config >/dev/null 2>&1 \
                || _lc_log "reapplying install.yaml to plugin envs FAILED; operator edits were not applied"
        fi
        _lc_for_each _lc_recreate_one
    else
        _lc_for_each _lc_restart_one
    fi
}
plugin_lifecycle_update_all()  { plugin_lifecycle_any || return 0; _lc_for_each _lc_update_one; }
# Generic: upgrades EVERY installed plugin to its latest CDN version (no per-plugin
# code). Best-effort — a per-plugin failure never aborts the batch (base upgrade
# calls this after the platform blue/green completes).
plugin_lifecycle_upgrade_all() { plugin_lifecycle_any || return 0; _lc_for_each _lc_upgrade_one; }

# Returns 1 when <target> is not a plugin, so the caller can fall back to base.
plugin_lifecycle_logs() {
    local target="$1"
    plugin_lifecycle_any || return 1
    journal_plugin_exists "$target" || return 1
    local deploy proj
    deploy="$(get_deployment_type 2>/dev/null || echo docker-compose)"
    local cc; cc="$(_plugin_compose_cmd)"
    if [ "$deploy" = "kubernetes" ]; then
        # Pods are labeled by helm release (instance), not by plugin name.
        local release; release="$(manifest_helm_release "$(_lc_manifest "$target")" 2>/dev/null)"
        [ -n "$release" ] || release="$target"
        kubectl logs -f -n "${BITOARCH_K8S_NAMESPACE:-bito-ai-architect}" \
            -l "app.kubernetes.io/instance=${release}" --all-containers=true --max-log-requests=10
    else
        proj="$(plugin_compose_project "$target")"
        $cc -p "$proj" logs -f
    fi
}

# Health VERDICT for auto-recovery: rc 1 when any KNOWN-GOOD plugin (journal
# health=healthy) has containers stopped, crash-looping, or failing their
# healthcheck — `bitoarch health`'s exit code folds this in, and self-heal keys
# off that rc, so standalone auto-recovery covers plugins too. Skipped states:
# stopped (user intent via `plugin stop`) and unhealthy/unknown (setup pending —
# a restart cannot fix those). k8s: kubelet owns container recovery.
# Journal accuracy for packs: their health field was write-once ("unknown" forever);
# reconcile from the live unit on BOTH runtimes. Verdict untouched — plugin flags
# drive recovery (docker), kubelet owns k8s recovery.
_lc_reconcile_pack_health() {
    local deploy cap pk rel pst cur_h ready want
    deploy="$(get_deployment_type 2>/dev/null || echo docker-compose)"
    for cap in $(journal_list_packs 2>/dev/null); do
        pk="$(journal_pack_get "$cap" 2>/dev/null | jq -r '.pack // empty' 2>/dev/null)" || true
        [ -n "$pk" ] || continue
        cur_h="$(journal_pack_get "$cap" 2>/dev/null | jq -r '.health // empty' 2>/dev/null)" || true
        pst=""
        if [ "$deploy" = "kubernetes" ]; then
            # Pack pods carry no instance label; the Deployment is named after the
            # helm release (see _dep_deploy_pack's kubectl scale), so read it directly.
            rel="$(journal_pack_get "$cap" 2>/dev/null | jq -r '.helm_release // empty' 2>/dev/null)" || true
            [ -n "$rel" ] || continue
            read -r want ready <<<"$(kubectl get deployment "$rel" -n "${BITOARCH_K8S_NAMESPACE:-bito-ai-architect}" -o jsonpath='{.status.replicas} {.status.readyReplicas}' 2>/dev/null)" || true
            [ -n "$want" ] && [ "${want:-0}" -gt 0 ] || continue   # missing/scaled-to-0: no evidence, leave record
            if [ "${ready:-0}" -ge "$want" ]; then pst="healthy"; else pst="unhealthy"; fi
        else
            pst="$(docker inspect -f '{{if .State.Health}}{{.State.Health.Status}}{{else}}{{.State.Status}}{{end}}' "ai-architect-${pk}" 2>/dev/null)" || true
        fi
        case "$pst" in
            healthy|running)                  [ "$cur_h" = "healthy" ]   || journal_set_pack_health "$cap" healthy   >/dev/null 2>&1 || _lc_log "could not record pack ${cap} as healthy; 'deps list' may show a stale value" ;;
            unhealthy|restarting|exited|dead) [ "$cur_h" = "unhealthy" ] || journal_set_pack_health "$cap" unhealthy >/dev/null 2>&1 || _lc_log "could not record pack ${cap} as unhealthy; 'deps list' may show a stale value" ;;
        esac
    done
    return 0
}

plugin_lifecycle_health_ok() {
    plugin_lifecycle_any || return 0
    _lc_reconcile_pack_health
    [ "$(get_deployment_type 2>/dev/null || echo docker-compose)" = "kubernetes" ] && return 0
    local name h proj total running broken bad=0
    for name in $(journal_list_plugins 2>/dev/null); do
        h="$(journal_plugin_field "$name" health 2>/dev/null)"
        case "$h" in healthy|unhealthy) ;; *) continue ;; esac   # stopped = user intent; unknown = never ran
        proj="$(type plugin_compose_project >/dev/null 2>&1 && plugin_compose_project "$name")"
        [ -n "$proj" ] || proj="ai-architect-${name}"
        # Count only long-running containers -- skip one-shot init helpers (restart:"no")
        # that exit after seeding dirs, else running<total would block the heal below.
        total=0
        for _cid in $(docker ps -aq --filter "label=com.docker.compose.project=${proj}" 2>/dev/null); do
            [ "$(docker inspect --format '{{.HostConfig.RestartPolicy.Name}}' "$_cid" 2>/dev/null)" = "no" ] && continue
            total=$((total + 1))
        done
        [ "${total:-0}" -eq 0 ] && continue
        running="$(docker ps -q --filter "label=com.docker.compose.project=${proj}" 2>/dev/null | wc -l | tr -d ' ')"
        broken="$(docker ps -aq --filter "label=com.docker.compose.project=${proj}" --filter "status=restarting" 2>/dev/null | wc -l | tr -d ' ')"
        broken=$((broken + $(docker ps -q --filter "label=com.docker.compose.project=${proj}" --filter "health=unhealthy" 2>/dev/null | wc -l | tr -d ' ') ))
        if [ "${running:-0}" -ge "${total:-0}" ] && [ "${broken:-0}" -eq 0 ]; then
            # Containers fully up. Journal said unhealthy (e.g. creds fixed later via
            # config --set auto-restart, which does not touch the journal)? Heal the record so
            # this plugin re-enters the recovery verdict instead of staying invisible.
            if [ "$h" = "unhealthy" ]; then
                if journal_put_plugin "$name" "$(journal_get_plugin "$name" | jq '.health="healthy"')" >/dev/null 2>&1; then
                    _lc_log "health: journal healed for '${name}' (containers recovered)"
                else
                    _lc_log "health: containers for '${name}' recovered but the journal could not be updated; it stays invisible to the recovery verdict"
                fi
            fi
        elif [ "$h" = "healthy" ]; then
            # Known-good plugin degraded -> flip the verdict (self-heal recovers it).
            _lc_log "health: plugin ${name} degraded (${running}/${total} running, ${broken} broken)"
            bad=1
        fi
    done
    return $bad
}

plugin_lifecycle_status_block() {
    plugin_lifecycle_any || return 0
    echo ""
    _lc_subheader "▶ Plugins"
    if type plugin_list >/dev/null 2>&1; then
        plugin_list --in-status
    else
        # shellcheck source=/dev/null
        . "${_BITOARCH_PLUGIN_LIFECYCLE_SELF}/plugin-status.sh" 2>/dev/null && plugin_list --in-status
    fi
    if type deps_list >/dev/null 2>&1 && [ -n "$(journal_list_packs 2>/dev/null)" ]; then
        echo ""
        _lc_subheader "▶ Shared dependency packs"
        deps_list
    fi
}

# 0 when any installed plugin declares the integration in its manifest
# (config.required[].integration) — callers must not delete/break the shared
# connection record while a plugin still consumes it.
plugin_lifecycle_integration_in_use() {   # <integration>
    local integration="$1"
    [ -n "$integration" ] || return 1
    plugin_lifecycle_any || return 1
    local plugin_name manifest_path
    while IFS= read -r plugin_name; do
        [ -z "$plugin_name" ] && continue
        manifest_path="$(_lc_manifest "$plugin_name")"
        [ -f "$manifest_path" ] || continue
        if manifest_config_required_integrations "$manifest_path" 2>/dev/null | cut -d'|' -f2 | grep -qx "$integration"; then
            printf '%s' "$plugin_name"
            return 0
        fi
    done <<LCIN
$(journal_list_plugins 2>/dev/null)
LCIN
    return 1
}

# Shared-integration update fan-out (fully manifest-driven; the base knows no
# plugin names). For every installed plugin whose manifest declares the updated
# integration (config.required[].integration), run its optional
# hooks.onIntegrationUpdate — sourced with PLUGIN_* + engine helpers in scope,
# same contract as the config hook — which owns the plugin-specific sync
# (refresh env snapshots, recreate, re-register webhooks). Plugins declaring the
# integration but shipping no hook get a plain recreate so the runtime re-reads
# the shared record immediately instead of waiting out its credential cache.
plugin_lifecycle_integration_updated() {   # <integration> [switched]
    local integration="$1"
    # Whether the shared connection SWITCHED to a different instance. The caller passes it
    # explicitly per integration (ticket-tracker: from Insights' _INSIGHTS_JIRA_INSTANCE_CHANGED,
    # set when the Jira URL changed); default 0 so an unspecified integration never falsely
    # resets. Passed to each plugin hook so it can reset config derived from the old instance;
    # plugins ignore it on a same-instance rotation.
    local switched="${2:-0}"
    [ -n "$integration" ] || return 0
    plugin_lifecycle_any || return 0
    local plugin_name manifest_path hook_path synced_list="" _iu_header_shown=0
    while IFS= read -r plugin_name; do
        [ -z "$plugin_name" ] && continue
        # Skip the plugin reconfiguring itself: its own setup steps re-register/recreate it, so
        # the fan-out must not double up (set by the plugin connect flow before it updates the shared connection).
        [ "$plugin_name" = "${BITOARCH_TT_SKIP_PLUGIN:-}" ] && continue
        manifest_path="$(_lc_manifest "$plugin_name")"
        [ -f "$manifest_path" ] || continue
        manifest_config_required_integrations "$manifest_path" 2>/dev/null | cut -d'|' -f2 | grep -qx "$integration" || continue
        hook_path="$(manifest_hook "$manifest_path" onIntegrationUpdate 2>/dev/null)"
        if [ -n "$hook_path" ] && [ -f "$(_lc_dir "$plugin_name")/$hook_path" ]; then
            # On a switch the hooks emit per-plugin "config reset for the new instance" notices —
            # print a grouping header once, right before the first one.
            if [ "$switched" = "1" ] && [ "$_iu_header_shown" != "1" ]; then
                printf '\n   %b🔌 Plugins using this connection%b\n\n' "${BOLD:-}" "${NC:-}" >&2
                _iu_header_shown=1
            fi
            ( PLUGIN_NAME="$plugin_name" PLUGIN_DIR="$(_lc_dir "$plugin_name")" PLUGIN_MANIFEST="$manifest_path" \
              PLUGIN_ENV_FILE="$(get_plugin_env_file "$plugin_name")" \
              BITOARCH_TT_SWITCHED="$switched" \
              BITOARCH_DEPLOY_TYPE="$(get_deployment_type 2>/dev/null || echo docker-compose)"
              # Webhook-registering hooks call plugin_http/plugin_service_base; load those helpers even when
              # the caller (e.g. `insights update-ticket-tracker`) never sourced the plugin engine. Idempotent.
              [ -f "${_BITOARCH_PLUGIN_LIFECYCLE_SELF}/plugin-http.sh" ] && . "${_BITOARCH_PLUGIN_LIFECYCLE_SELF}/plugin-http.sh" 2>/dev/null || true
              # shellcheck source=/dev/null
              . "$(_lc_dir "$plugin_name")/$hook_path" ) \
                || _lc_warn "plugin '${plugin_name}': integration-update sync reported an issue (see log)"
        else
            _lc_recreate_one "$plugin_name"
        fi
        synced_list="${synced_list:+$synced_list, }$plugin_name"
    done <<LCIU
$(journal_list_plugins 2>/dev/null)
LCIU
    [ -n "$synced_list" ] && { type log_silent >/dev/null 2>&1 && log_silent "synced installed plugin(s) using this connection: ${synced_list}"; }
    return 0
}

# Refuse a base upgrade when an installed plugin requires a higher base version.
plugin_lifecycle_upgrade_guard() {
    local target="$1"
    plugin_lifecycle_any || return 0
    [ -z "$target" ] && return 0
    local p man blocked=0
    while IFS= read -r p; do
        [ -z "$p" ] && continue
        man="$(_lc_manifest "$p")"
        [ -f "$man" ] || continue
        if ! BITOARCH_PLATFORM_VERSION="$target" manifest_check_platform "$man" >/dev/null 2>&1; then
            _lc_warn "plugin '${p}' requires a newer base than ${target} ($(manifest_platform_constraint "$man")); base upgrade refused."
            blocked=1
        fi
    done <<EOF
$(journal_list_plugins)
EOF
    [ "$blocked" -eq 0 ]
}

# Restart plugins after a base credential rotation; warn where a plugin shadows it.
plugin_lifecycle_cred_rotation_restart() {
    local rotated_key="$1"
    plugin_lifecycle_any || return 0
    local p env_file
    while IFS= read -r p; do
        [ -z "$p" ] && continue
        env_file="$(get_plugin_env_file "$p")"
        if [ -n "$rotated_key" ] && [ -f "$env_file" ] && grep -q "^${rotated_key}=" "$env_file" 2>/dev/null; then
            _lc_warn "plugin '${p}' overrides '${rotated_key}' in its own config; the rotated base value will NOT take effect there until you update the plugin config."
        fi
        _lc_restart_one "$p"
    done <<EOF
$(journal_list_plugins)
EOF
}

# Wipes runtime state (services, volumes, data, .env) but keeps the install dir.
# Keep-data teardown: remove plugin + dependency-pack containers; volumes, config,
# and the journal stay so `bitoarch start` restores everything.
plugin_lifecycle_down_all() {
    plugin_lifecycle_any || return 0
    local p cap
    while IFS= read -r p; do
        [ -z "$p" ] && continue
        if type _plugin_undeploy >/dev/null 2>&1 && _plugin_undeploy "$p" "$(_lc_dir "$p")" "$(_lc_manifest "$p")" >/dev/null 2>&1; then
            _lc_log "removed plugin $p containers (volumes, config, journal kept)"
        else
            _lc_log "FAILED to remove plugin $p containers; they may still be running"
        fi
    done <<EOF
$(journal_list_plugins)
EOF
    while IFS= read -r cap; do
        [ -z "$cap" ] && continue
        if type _dep_teardown_pack >/dev/null 2>&1 && _dep_teardown_pack "$cap" >/dev/null 2>&1; then
            _lc_log "removed dependency pack $cap containers (volume kept)"
        else
            _lc_log "FAILED to remove dependency pack $cap containers; they may still be running"
        fi
    done <<EOF
$(journal_list_packs 2>/dev/null)
EOF
}

plugin_lifecycle_reset() {
    plugin_lifecycle_any || return 0
    # Hook accessor for the onPurge pass below (lifecycle loads lazily; same sibling idiom).
    type manifest_hook >/dev/null 2>&1 || . "${_BITOARCH_PLUGIN_LIFECYCLE_SELF}/manifest-parser.sh" 2>/dev/null || true
    local p dir man data env_file purge_hook
    while IFS= read -r p; do
        [ -z "$p" ] && continue
        dir="$(_lc_dir "$p")"; man="$(_lc_manifest "$p")"
        data="$(get_plugin_data_dir "$p")"; env_file="$(get_plugin_env_file "$p")"
        # Purge parity with `plugin uninstall --purge`: run the plugin's onPurge hook
        # (e.g. webhook deregistration) while its services are still up. Best-effort.
        purge_hook=""
        type manifest_hook >/dev/null 2>&1 && purge_hook="$(manifest_hook "$man" onPurge 2>/dev/null)"
        if [ -n "$purge_hook" ] && [ -f "$dir/$purge_hook" ]; then
            ( PLUGIN_NAME="$p" PLUGIN_DIR="$dir" PLUGIN_MANIFEST="$man" \
              PLUGIN_ENV_FILE="$env_file" \
              BITOARCH_DEPLOY_TYPE="$(get_deployment_type 2>/dev/null || echo docker-compose)"
              [ -f "${_BITOARCH_PLUGIN_LIFECYCLE_SELF}/plugin-http.sh" ] && . "${_BITOARCH_PLUGIN_LIFECYCLE_SELF}/plugin-http.sh" 2>/dev/null || true
              . "$dir/$purge_hook" ) || _lc_warn "plugin '$p': onPurge hook reported an issue (continuing teardown)"
        fi
        # Track each step: a single "reset" line asserting all three succeeded
        # would hide plugin credentials left on disk by a failed config clear.
        local _lc_reset_failed=""
        type _plugin_undeploy >/dev/null 2>&1 \
            && { _plugin_undeploy "$p" "$dir" "$man" --purge >/dev/null 2>&1 || _lc_reset_failed="${_lc_reset_failed} services"; }
        if [ -n "$data" ] && [ -d "$data" ]; then
            rm -rf "$data" 2>>"${LOG_FILE:-/dev/null}" || _lc_reset_failed="${_lc_reset_failed} data"
        fi
        if [ -f "$env_file" ]; then
            : > "$env_file" 2>>"${LOG_FILE:-/dev/null}" || _lc_reset_failed="${_lc_reset_failed} config"
        fi
        if [ -z "$_lc_reset_failed" ]; then
            _lc_log "reset plugin $p (services + volumes + data removed, config cleared, install dir kept)"
        else
            _lc_log "reset plugin $p INCOMPLETE — could not complete:${_lc_reset_failed}"
            _lc_warn "Plugin '$p' was not fully reset (${_lc_reset_failed# }); see $(type get_setup_log >/dev/null 2>&1 && get_setup_log || echo the setup log)"
        fi
    done <<EOF
$(journal_list_plugins)
EOF
    # Purge is a full wipe: dependency packs (kafka/redis) go too — containers, their
    # fixed-name volumes, and the journal records (down_all keeps volumes; purge must not).
    local cap
    while IFS= read -r cap; do
        [ -z "$cap" ] && continue
        local _lc_pack_failed=""
        type _dep_teardown_pack >/dev/null 2>&1 \
            && { _dep_teardown_pack "$cap" --purge >>"${LOG_FILE:-/dev/null}" 2>&1 || _lc_pack_failed="${_lc_pack_failed} containers"; }
        type journal_pack_remove >/dev/null 2>&1 \
            && { journal_pack_remove "$cap" >>"${LOG_FILE:-/dev/null}" 2>&1 || _lc_pack_failed="${_lc_pack_failed} journal-record"; }
        if [ -z "$_lc_pack_failed" ]; then
            _lc_log "purged dependency pack $cap (containers + volumes + journal record)"
        else
            _lc_log "purge of dependency pack $cap INCOMPLETE — could not remove:${_lc_pack_failed}"
            _lc_warn "Dependency pack '$cap' was not fully purged (${_lc_pack_failed# })"
        fi
    done <<EOF
$(journal_list_packs 2>/dev/null)
EOF
}

