#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
#
# Deployment primitives (a plugin runs as its own compose project / Helm release).

if [ -n "${_BITOARCH_PLUGIN_DEPLOY_LOADED:-}" ]; then
    return 0
fi
_BITOARCH_PLUGIN_DEPLOY_LOADED=1

_BITOARCH_PLUGIN_DEPLOY_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if ! type manifest_compose >/dev/null 2>&1; then
    # shellcheck source=scripts/lib/plugin/manifest-parser.sh
    . "${_BITOARCH_PLUGIN_DEPLOY_DIR}/manifest-parser.sh"
fi
if ! type plugin_env_k8s_values >/dev/null 2>&1; then
    # shellcheck source=scripts/lib/plugin/env-merger.sh
    . "${_BITOARCH_PLUGIN_DEPLOY_DIR}/env-merger.sh" 2>/dev/null || true
fi
# Loaders must render from EVERY entrypoint (CLI dispatch and installer bootstrap).
if ! type progress_run >/dev/null 2>&1; then
    # shellcheck source=scripts/lib/progress-output.sh
    . "${_BITOARCH_PLUGIN_DEPLOY_DIR}/../progress-output.sh" 2>/dev/null || true
fi

_deploy_err() {
    if type print_error >/dev/null 2>&1; then print_error "$1" >&2; else printf 'ERROR: %s\n' "$1" >&2; fi
    type log_silent >/dev/null 2>&1 && log_silent "plugin deploy: $1"
}
_deploy_log() { type log_silent >/dev/null 2>&1 && log_silent "plugin deploy: $1"; }

# Canonical compose-cmd resolver (compose v1 + v2) lives in compose-cmd.sh;
# literal fallback keeps this module usable if the sibling source fails.
if ! type _plugin_compose_cmd >/dev/null 2>&1; then
    # shellcheck source=scripts/lib/plugin/compose-cmd.sh
    . "${_BITOARCH_PLUGIN_DEPLOY_DIR}/compose-cmd.sh" 2>/dev/null || true
fi
if ! type _plugin_compose_cmd >/dev/null 2>&1; then
    _plugin_compose_cmd() { printf 'docker compose'; }
fi

plugin_compose_project() { echo "ai-architect-$1"; }

# One-time migration off the old project prefix: remove containers deployed under
# it so the new project does not collide (their volumes and config are external).
_plugin_cleanup_legacy_project() {   # <name>
    local cc; cc="$(_plugin_compose_cmd)"
    _plugin_run "" $cc -p "bitoarch-$1" down --remove-orphans \
            || _deploy_log "legacy compose project for '$1' could not be removed; a name/port clash may follow"
}

# Regenerate the plugin's Helm values and echo the `-f <file>` arg (empty if none).
_plugin_helm_values() {
    local name="$1" vals
    type plugin_env_k8s_values  >/dev/null 2>&1 || return 0
    type get_plugin_k8s_values_file >/dev/null 2>&1 || return 0
    vals="$(get_plugin_k8s_values_file "$name")"
    # A silent failure here drops the `-f <values>` arg, so helm would deploy the
    # plugin with no configuration at all and report success.
    if plugin_env_k8s_values "$name" "$vals" >>"$(_plugin_log_target)" 2>&1; then
        printf -- '-f %s' "$vals"
        return 0
    fi
    _deploy_err "could not render helm values for '${name}' — its configuration would not be applied"
    return 1
}

# Resolve a writable log target for action-command output. Never /dev/null:
# discarding a mutating command's output is the failure mode this framework's
# logging exists to prevent, so fall back to stderr, which the caller's own log
# (or the operator's terminal) still captures.
_plugin_log_target() {
    # Delegate to the single resolver in path-manager.sh: a local copy drifted on the
    # fallback tier and skipped the writability check, so an unwritable target made
    # bash skip the command it was logging instead of falling back.
    # stderr stays the floor for the case where path-manager was never sourced.
    if command -v bitoarch_resolve_log_file >/dev/null 2>&1; then
        bitoarch_resolve_log_file
        return 0
    fi
    printf '%s' "/dev/stderr"
}

_plugin_run() {
    local label="$1"; shift
    # Empty label = quiet: the caller already announced this action (one action, one announce).
    if [ -n "$label" ] && type progress_run >/dev/null 2>&1; then
        progress_run "$label" -- "$@"
        return $?
    fi
    "$@" >>"$(_plugin_log_target)" 2>&1
}

# Per-plugin data dir on the shared volume: publish the container path to the plugin
# env and create it ahead of first write (777 like the volume root) so any service
# uid can write. Runs in-container via the shared-volume bridge (host cannot write it).
_plugin_provision_data_dir() {   # <name>
    local dd ef
    dd="$(get_plugin_data_dir "$1" 2>/dev/null)"
    [ -z "$dd" ] && return 0
    # The shared-volume write bridge lives in the base wingman-shelf lib.
    type _wingman_fs_apply >/dev/null 2>&1 \
        || . "${_BITOARCH_PLUGIN_DEPLOY_DIR}/../wingman-shelf.sh" 2>/dev/null || true
    ef="$(get_plugin_env_file "$1" 2>/dev/null)"
    if [ -n "$ef" ] && type plugin_env_set >/dev/null 2>&1; then
        plugin_env_set "$ef" PLUGIN_DATA_DIR "$dd" \
            || _deploy_err "could not publish PLUGIN_DATA_DIR to '$1' env; the plugin will not know its data dir"
    fi
    if type _wingman_fs_apply >/dev/null 2>&1; then
        # Without this dir the plugin hits EACCES/ENOENT at runtime, so record the
        # reason here rather than leaving it to be guessed from a crash loop.
        local _fs_out
        _fs_out="$(_wingman_fs_apply "" "mkdir -p '$dd' && chmod 777 '$dd'" 2>&1)" \
            || _deploy_err "could not provision data dir ${dd} for '$1': $(printf '%s' "$_fs_out" | tail -c 300)"
    else
        _deploy_log "shared-volume bridge unavailable; data dir ${dd} for '$1' was not provisioned"
    fi
    return 0
}

_plugin_deploy() {   # <name> <dir> <manifest> [imagePullPolicy override — "Always" on install/upgrade]
    local name="$1" dir="$2" manifest="$3" pull_policy="${4:-}" deploy
    _plugin_cleanup_legacy_project "$name"
    _plugin_provision_data_dir "$name"
    deploy="$(get_deployment_type 2>/dev/null || echo docker-compose)"
    local cc; cc="$(_plugin_compose_cmd)"
    if [ "$deploy" = "kubernetes" ]; then
        local chart release ns
        release="$(manifest_helm_release "$manifest")"
        chart="${dir}/$(manifest_helm_chart "$manifest")"
        ns="${BITOARCH_K8S_NAMESPACE:-bito-ai-architect}"
        if [ -z "$release" ]; then
            _deploy_err "manifest declares no services.helm.release; cannot deploy on kubernetes"
            return 1
        fi
        local valargs
        if ! valargs="$(_plugin_helm_values "$name")"; then
            _deploy_err "refusing to deploy '${name}': its helm values could not be rendered"
            return 1
        fi
        # Same-tag re-pushes (staging channels) only re-pull under Always; the chart
        # default IfNotPresent would keep a node's stale cached image.
        [ -n "$pull_policy" ] && valargs="$valargs --set imagePullPolicy=${pull_policy}"
        # No --wait: services needing required config (collected in the setup step
        # AFTER deploy) cannot go Ready yet — a wait here can only time out and roll
        # the install back. Docker deploy has the same no-block semantics; the
        # post-config recreate still waits and gives the health ack.
        # shellcheck disable=SC2086
        _plugin_run "Deploying plugin ${name} (helm)" helm upgrade --install "$release" "$chart" --namespace "$ns" $valargs
    else
        local frag proj base plug envargs=""
        frag="${dir}/$(manifest_compose "$manifest")"
        proj="$(plugin_compose_project "$name")"
        if [ ! -f "$frag" ]; then
            _deploy_err "plugin compose fragment not found: ${frag}"
            return 1
        fi
        # Base env-file first, then the plugin's own, so the plugin overrides base.
        base="$(get_config_file 2>/dev/null)"
        plug="$(get_plugin_env_file "$name" 2>/dev/null)"
        [ -n "$base" ] && [ -f "$base" ] && envargs="$envargs --env-file $base"
        [ -n "$plug" ] && [ -f "$plug" ] && envargs="$envargs --env-file $plug"
        # Resolve the base network + data volume's real (project-prefixed) names and export them for compose interpolation.
        local net vol wvol
        net="$(type get_ai_architect_network >/dev/null 2>&1 && get_ai_architect_network || echo ai-architect-network)"
        vol="$(type get_ai_architect_data_volume >/dev/null 2>&1 && get_ai_architect_data_volume || echo ai_architect_data)"
        wvol="$(type get_ai_architect_wingman_volume >/dev/null 2>&1 && get_ai_architect_wingman_volume || echo ai_architect_wingman)"
        # Force pull first when requested: `up` only fetches missing tags, so a
        # same-tag re-push would otherwise reuse the cached image. Best-effort --
        # offline, the up below still runs from cache -- but the failure is logged.
        if [ -n "$pull_policy" ] && ! _plugin_pull "$name" "$dir" "$manifest" >/dev/null 2>&1; then
            type log_silent >/dev/null 2>&1 && log_silent "plugin ${name}: forced image pull failed (registry unreachable?); deploying with cached images"
        fi
        # shellcheck disable=SC2086
        ( export AI_ARCHITECT_NETWORK="$net" AI_ARCHITECT_DATA_VOLUME="$vol" AI_ARCHITECT_WINGMAN_VOLUME="$wvol"; \
          _plugin_run "Deploying plugin ${name}" $cc -p "$proj" $envargs -f "$frag" up -d --quiet-pull )
    fi
}

# --purge also removes the plugin's compose-managed volumes.
_plugin_undeploy() {
    local name="$1" dir="$2" manifest="$3" purge="${4:-}" deploy
    deploy="$(get_deployment_type 2>/dev/null || echo docker-compose)"
    local cc; cc="$(_plugin_compose_cmd)"
    if [ "$deploy" = "kubernetes" ]; then
        local release ns
        release="$(manifest_helm_release "$manifest")"
        ns="${BITOARCH_K8S_NAMESPACE:-bito-ai-architect}"
        # helm's "release ... uninstalled" ack is operator noise mid-install; keep it in the log.
        [ -n "$release" ] && helm uninstall "$release" --namespace "$ns" \
            >> "$(bitoarch_resolve_log_file 2>/dev/null || echo /dev/null)" 2>&1
    else
        local frag proj
        frag="${dir}/$(manifest_compose "$manifest" 2>/dev/null)"
        proj="$(plugin_compose_project "$name")"
        if [ -f "$frag" ]; then
            if [ "$purge" = "--purge" ]; then
                _plugin_compose_project_op "$name" "$dir" "$manifest" down -v
            else
                _plugin_compose_project_op "$name" "$dir" "$manifest" down
            fi
        else
            # Fragment gone (install dir removed): best-effort stop by project.
            # Must stay best-effort -- returning non-zero here would leave the
            # plugin permanently uninstallable, which is the case this branch serves.
            _plugin_run "" $cc -p "$proj" down \
                || _deploy_err "could not remove compose project ${proj}; its containers may still be running"
        fi
    fi
}

# One-shot LIVE container health (no waiting); echoes stopped|unhealthy|healthy|starting|running|unknown.
_plugin_current_health() {
    local name="$1" deploy proj cc ids id total running healthy unhealthy restarting starting nohc cstatus st _dir _man _frag expected_n=0
    deploy="$(get_deployment_type 2>/dev/null || echo docker-compose)"
    if [ "$deploy" = "kubernetes" ]; then
        # Live pod probe by helm release (pods are labeled by instance). Vocabulary
        # matches the docker branch: healthy / unhealthy / starting / stopped.
        local ns rel pods line phase cs ready restarts bad=0 warming=0 any=0
        ns="${BITOARCH_K8S_NAMESPACE:-bito-ai-architect}"
        rel="$(manifest_helm_release "$(get_plugin_install_dir "$name" 2>/dev/null)/plugin.yaml" 2>/dev/null)"
        [ -n "$rel" ] || rel="ai-architect-${name}"
        pods="$(kubectl get pods -n "$ns" -l "app.kubernetes.io/instance=${rel}" \
            -o jsonpath='{range .items[*]}{.status.phase}|{range .status.containerStatuses[*]}{.ready}:{.restartCount},{end}{"\n"}{end}' 2>/dev/null)"
        [ -n "$pods" ] || { echo "stopped"; return 0; }
        while IFS= read -r line; do
            [ -n "$line" ] || continue
            phase="${line%%|*}"
            case "$phase" in
                Succeeded) continue ;;                      # completed helper pods don't gate health
                Pending)   any=1; warming=1; continue ;;
                Running)   any=1 ;;
                *)         any=1; bad=1; continue ;;        # Failed / Unknown
            esac
            # Per-container "ready:restarts" pairs: not-ready with few restarts is
            # still starting (startupProbe window); repeated restarts = crash loop.
            for cs in $(printf '%s' "${line#*|}" | tr ',' ' '); do
                ready="${cs%%:*}"; restarts="${cs##*:}"
                if [ "$ready" != "true" ]; then
                    if [ "${restarts:-0}" -ge 3 ]; then bad=1; else warming=1; fi
                fi
            done
        done <<K8SPODS
$pods
K8SPODS
        [ "$any" -eq 1 ] || { echo "stopped"; return 0; }
        if [ "$bad" -eq 1 ]; then echo "unhealthy"
        elif [ "$warming" -eq 1 ]; then echo "starting"
        else echo "healthy"; fi
        return 0
    fi
    cc="$(_plugin_compose_cmd)"
    proj="$(plugin_compose_project "$name")"
    ids="$($cc -p "$proj" ps -q 2>/dev/null)"
    [ -z "$ids" ] && { echo "stopped"; return 0; }
    # Long-running services declared in the plugin's compose fragment. A declared service with
    # no running container means the plugin is only partially up, so it must never read
    # "healthy" — this is what lets `plugin start` bring a stopped service back up.
    if type manifest_compose >/dev/null 2>&1 && type _mp_yq >/dev/null 2>&1; then
        _dir="$(get_plugin_install_dir "$name" 2>/dev/null)"; _man="${_dir}/plugin.yaml"
        if [ -f "$_man" ]; then
            _frag="$(manifest_compose "$_man" 2>/dev/null)" || true
            [ -n "$_frag" ] && [ -f "${_dir}/${_frag}" ] && \
                expected_n="$(_mp_yq "${_dir}/${_frag}" '.services | to_entries | .[] | select(.value.restart != "no") | .value.container_name // .key' 2>/dev/null | grep -c . || true)"
        fi
    fi
    expected_n="${expected_n:-0}"
    total=0; running=0; healthy=0; unhealthy=0; restarting=0; starting=0; nohc=0
    for id in $ids; do
        # One-shot init helpers (restart:"no") seed dirs then exit; they must not gate
        # health (also excluded from expected_n above). Skip whether exited or running.
        [ "$(docker inspect --format '{{.HostConfig.RestartPolicy.Name}}' "$id" 2>/dev/null)" = "no" ] && continue
        total=$((total + 1))
        cstatus="$(docker inspect --format '{{.State.Status}}' "$id" 2>/dev/null)"
        [ "$cstatus" = "restarting" ] && restarting=$((restarting + 1))
        [ "$(docker inspect --format '{{.State.Running}}' "$id" 2>/dev/null)" = "true" ] && running=$((running + 1))
        st="$(docker inspect --format '{{if .State.Health}}{{.State.Health.Status}}{{else}}none{{end}}' "$id" 2>/dev/null)"
        case "$st" in
            healthy)   healthy=$((healthy + 1)) ;;
            unhealthy) unhealthy=$((unhealthy + 1)) ;;
            starting)  starting=$((starting + 1)) ;;
            *)         nohc=$((nohc + 1)) ;;
        esac
    done
    if [ "$unhealthy" -gt 0 ] || [ "$restarting" -gt 0 ]; then echo "unhealthy"; return 0; fi
    # A declared service isn't running (crashed / stopped) -> partially up, never "healthy".
    if [ "$expected_n" -gt 0 ] && [ "$running" -lt "$expected_n" ]; then echo "unhealthy"; return 0; fi
    if [ "$healthy" -eq "$total" ]; then echo "healthy"; return 0; fi
    if [ "$starting" -gt 0 ]; then echo "starting"; return 0; fi
    if [ "$running" -eq "$total" ] && [ "$nohc" -eq "$total" ]; then echo "running"; return 0; fi
    echo "unknown"
}

# Wait for healthchecks to RESOLVE (not treat "starting" as done); sets BITOARCH_PLUGIN_HEALTH and returns non-zero only when genuinely unhealthy.
_plugin_wait_health() {
    local name="$1" deploy timeout="${BITOARCH_PLUGIN_HEALTH_TIMEOUT:-60}"
    BITOARCH_PLUGIN_HEALTH="unknown"
    [ "${BITOARCH_PLUGIN_SKIP_HEALTH:-0}" = "1" ] && return 0
    # Both runtimes poll the same live probe (_plugin_current_health has a real
    # k8s branch now); helm/rollout waits make this converge fast on k8s.
    local elapsed=0 interval=2 h
    while [ "$elapsed" -lt "$timeout" ]; do
        h="$(_plugin_current_health "$name")"
        case "$h" in
            healthy)   BITOARCH_PLUGIN_HEALTH="healthy"; return 0 ;;
            unhealthy)
                BITOARCH_PLUGIN_HEALTH="unhealthy"
                # Quiet: the caller renders the user-facing result, so we don't print a stray ✗.
                _deploy_log "plugin '${name}' has a container that is unhealthy or crash-looping"
                return 1 ;;
            running)   BITOARCH_PLUGIN_HEALTH="unknown"; return 0 ;;  # up, no healthcheck declared
            # starting | stopped | unknown -> keep waiting
        esac
        sleep "$interval"
        elapsed=$((elapsed + interval))
    done
    # Timed out -> classify the final state honestly.
    case "$(_plugin_current_health "$name")" in
        healthy)         BITOARCH_PLUGIN_HEALTH="healthy"; return 0 ;;
        running|unknown) BITOARCH_PLUGIN_HEALTH="unknown"; return 0 ;;
        *)  # starting (never passed) | unhealthy | stopped
            BITOARCH_PLUGIN_HEALTH="unhealthy"
            _deploy_log "plugin '${name}' did not become healthy within ${timeout}s"
            return 1 ;;
    esac
}

# rc 0 = no tools to register; rc 1 = declares tools the provider cannot expose.
_plugin_register_mcp() {
    local name="$1" manifest="$2" tools
    tools="$(manifest_mcp_tools "$manifest" 2>/dev/null)"
    if [ -z "$tools" ]; then
        _deploy_log "plugin '${name}' declares no MCP tools; nothing to register"
        return 0
    fi
    _deploy_log "plugin '${name}' declares MCP tools but cis-provider has no plugin-tool extension point; not registered -- surface capability by writing data into a provider-watched dir, or ship the tool in xmcp"
    return 1
}
_plugin_deregister_mcp() { _deploy_log "deregistering MCP tools for plugin '$1' (no-op: none were registered with the provider)"; return 0; }

# Start (resume) the plugin's units; inverse of _plugin_stop. Docker: `up -d` (no
# --force-recreate — resumes stopped containers, creates missing ones, no-op when already
# running) with the SAME env-files + exports as _plugin_recreate so a started plugin sees
# identical env. K8s: scale the deployment back up (inverse of stop's scale-to-0).
_plugin_start() {
    local name="$1" dir="$2" manifest="$3" deploy
    deploy="$(get_deployment_type 2>/dev/null || echo docker-compose)"
    local cc; cc="$(_plugin_compose_cmd)"
    if [ "$deploy" = "kubernetes" ]; then
        # Select by the helm-standard instance label (release name) — the charts stamp it on
        # every Deployment; the plugin NAME is not a label value, so component=name matches nothing.
        local ns release; ns="${BITOARCH_K8S_NAMESPACE:-bito-ai-architect}"
        release="$(manifest_helm_release "$manifest" 2>/dev/null)"; [ -n "$release" ] || return 0
        _plugin_run "" kubectl scale deployment -n "$ns" -l "app.kubernetes.io/instance=${release}" --replicas=1
    else
        local frag proj base plug envargs=""
        frag="${dir}/$(manifest_compose "$manifest" 2>/dev/null)"
        proj="$(plugin_compose_project "$name")"
        [ -f "$frag" ] || return 0
        base="$(get_config_file 2>/dev/null)"; plug="$(get_plugin_env_file "$name" 2>/dev/null)"
        [ -n "$base" ] && [ -f "$base" ] && envargs="$envargs --env-file $base"
        [ -n "$plug" ] && [ -f "$plug" ] && envargs="$envargs --env-file $plug"
        local net vol wvol
        net="$(type get_ai_architect_network >/dev/null 2>&1 && get_ai_architect_network || echo ai-architect-network)"
        vol="$(type get_ai_architect_data_volume >/dev/null 2>&1 && get_ai_architect_data_volume || echo ai_architect_data)"
        wvol="$(type get_ai_architect_wingman_volume >/dev/null 2>&1 && get_ai_architect_wingman_volume || echo ai_architect_wingman)"
        # shellcheck disable=SC2086
        ( export AI_ARCHITECT_NETWORK="$net" AI_ARCHITECT_DATA_VOLUME="$vol" AI_ARCHITECT_WINGMAN_VOLUME="$wvol"; \
          _plugin_run "" $cc -p "$proj" $envargs -f "$frag" up -d --quiet-pull )
    fi
}

# Run a docker-compose verb (stop/restart/…) against a plugin's project with the
# SAME env-files + resolved network/volume names the up/recreate paths use. Without
# them compose validates the fragment's external network/volume against the bare
# defaults, can't find the project-prefixed ones, and the verb silently no-ops.
_plugin_compose_project_op() {   # <name> <dir> <manifest> <verb...>
    local name="$1" dir="$2" manifest="$3"; shift 3
    local cc frag proj base plug envargs="" net vol wvol
    cc="$(_plugin_compose_cmd)"
    frag="${dir}/$(manifest_compose "$manifest" 2>/dev/null)"
    proj="$(plugin_compose_project "$name")"
    [ -f "$frag" ] || return 0
    base="$(get_config_file 2>/dev/null)"; plug="$(get_plugin_env_file "$name" 2>/dev/null)"
    [ -n "$base" ] && [ -f "$base" ] && envargs="$envargs --env-file $base"
    [ -n "$plug" ] && [ -f "$plug" ] && envargs="$envargs --env-file $plug"
    net="$(type get_ai_architect_network >/dev/null 2>&1 && get_ai_architect_network || echo ai-architect-network)"
    vol="$(type get_ai_architect_data_volume >/dev/null 2>&1 && get_ai_architect_data_volume || echo ai_architect_data)"
    wvol="$(type get_ai_architect_wingman_volume >/dev/null 2>&1 && get_ai_architect_wingman_volume || echo ai_architect_wingman)"
    # shellcheck disable=SC2086
    ( export AI_ARCHITECT_NETWORK="$net" AI_ARCHITECT_DATA_VOLUME="$vol" AI_ARCHITECT_WINGMAN_VOLUME="$wvol"; \
      $cc -p "$proj" $envargs -f "$frag" "$@" 2>/dev/null )
}

# Stop (not remove) the plugin's units.
_plugin_stop() {
    local name="$1" dir="$2" manifest="$3" deploy
    deploy="$(get_deployment_type 2>/dev/null || echo docker-compose)"
    if [ "$deploy" = "kubernetes" ]; then
        local ns release; ns="${BITOARCH_K8S_NAMESPACE:-bito-ai-architect}"
        release="$(manifest_helm_release "$manifest" 2>/dev/null)"; [ -n "$release" ] || return 0
        _plugin_run "" kubectl scale deployment -n "$ns" -l "app.kubernetes.io/instance=${release}" --replicas=0
    else
        _plugin_compose_project_op "$name" "$dir" "$manifest" stop
    fi
}

_plugin_restart() {
    local name="$1" dir="$2" manifest="$3" deploy
    deploy="$(get_deployment_type 2>/dev/null || echo docker-compose)"
    if [ "$deploy" = "kubernetes" ]; then
        local ns release; ns="${BITOARCH_K8S_NAMESPACE:-bito-ai-architect}"
        release="$(manifest_helm_release "$manifest" 2>/dev/null)"; [ -n "$release" ] || return 0
        _plugin_run "" kubectl rollout restart deployment -n "$ns" -l "app.kubernetes.io/instance=${release}"
    else
        _plugin_compose_project_op "$name" "$dir" "$manifest" restart
    fi
}

# Recreate so units reload their .env; on k8s use helm upgrade (not rollout restart, which replays the old spec).
# Runs quietly: every caller announces first (the frame's "Starting..." line), so no second progress label.
_plugin_recreate() {   # <name> <dir> <manifest> [imagePullPolicy override — "Always" on update]
    local name="$1" dir="$2" manifest="$3" pull_policy="${4:-}" deploy rc=0
    deploy="$(get_deployment_type 2>/dev/null || echo docker-compose)"
    local cc; cc="$(_plugin_compose_cmd)"
    if [ "$deploy" = "kubernetes" ]; then
        local ns release chart valargs
        ns="${BITOARCH_K8S_NAMESPACE:-bito-ai-architect}"
        release="$(manifest_helm_release "$manifest" 2>/dev/null)"
        chart="${dir}/$(manifest_helm_chart "$manifest" 2>/dev/null)"
        [ -n "$release" ] || return 0
        if ! valargs="$(_plugin_helm_values "$name")"; then
            # Warn and continue: a restart's job is to bounce what is already
            # running, so refusing here would leave the plugin unrestartable. The
            # deploy path keeps the hard refusal, which is where shipping an
            # unconfigured plugin actually does damage.
            _deploy_err "recreating '${name}' without a values file; its configuration may be stale"
            valargs=""
        fi
        [ -n "$pull_policy" ] && valargs="$valargs --set imagePullPolicy=${pull_policy}"
        # Recreate must MOVE pods (docker parity: containers re-read env-files).
        # helm no-ops when the template is unchanged, so snapshot generations and
        # bounce whatever helm does not roll — same single-roll dedupe as the base.
        local _gen_before="" _d _g
        for _d in $(kubectl get deployment -n "$ns" -l "app.kubernetes.io/instance=${release}" \
                        -o jsonpath='{range .items[*]}{.metadata.name}{"\n"}{end}' 2>/dev/null); do
            _g="$(kubectl get deployment "$_d" -n "$ns" -o jsonpath='{.metadata.generation}' 2>/dev/null)"
            _gen_before="${_gen_before}${_d} ${_g}
"
        done
        # shellcheck disable=SC2086
        _plugin_run "" helm upgrade --install "$release" "$chart" --namespace "$ns" $valargs || rc=$?
        if [ "$rc" -eq 0 ]; then
            local _after _before
            while IFS=' ' read -r _d _g; do
                [ -n "$_d" ] || continue
                _after="$(kubectl get deployment "$_d" -n "$ns" -o jsonpath='{.metadata.generation}' 2>/dev/null)"
                [ -n "$_after" ] && [ "$_after" = "$_g" ] && \
                    _plugin_run "" kubectl rollout restart deployment "$_d" -n "$ns" \
                        || _deploy_log "could not bounce deployment ${_d}; it may still run the previous env"
            done <<PLGGEN
$_gen_before
PLGGEN
            # Bounded readiness wait (same budget as docker's health wait). Soft on
            # timeout: a service still awaiting required config cannot go Ready, and
            # the health ack reports the real state.
            kubectl rollout status deployment -n "$ns" -l "app.kubernetes.io/instance=${release}" \
                --timeout "${BITOARCH_PLUGIN_HEALTH_TIMEOUT:-60}s" >/dev/null 2>&1 || true
        fi
        _plugin_recreate_verdict "$name" "$rc"; return $rc
    else
        local frag proj base plug envargs=""
        frag="${dir}/$(manifest_compose "$manifest" 2>/dev/null)"
        proj="$(plugin_compose_project "$name")"
        [ -f "$frag" ] || return 0
        base="$(get_config_file 2>/dev/null)"; plug="$(get_plugin_env_file "$name" 2>/dev/null)"
        [ -n "$base" ] && [ -f "$base" ] && envargs="$envargs --env-file $base"
        [ -n "$plug" ] && [ -f "$plug" ] && envargs="$envargs --env-file $plug"
        local net vol wvol
        net="$(type get_ai_architect_network >/dev/null 2>&1 && get_ai_architect_network || echo ai-architect-network)"
        vol="$(type get_ai_architect_data_volume >/dev/null 2>&1 && get_ai_architect_data_volume || echo ai_architect_data)"
        wvol="$(type get_ai_architect_wingman_volume >/dev/null 2>&1 && get_ai_architect_wingman_volume || echo ai_architect_wingman)"
        # Same force-pull contract as the k8s branch: the policy arg means "re-fetch
        # same-tag images"; --force-recreate alone reuses whatever is cached.
        if [ -n "$pull_policy" ] && ! _plugin_pull "$name" "$dir" "$manifest" >/dev/null 2>&1; then
            type log_silent >/dev/null 2>&1 && log_silent "plugin ${name}: forced image pull failed (registry unreachable?); recreating with cached images"
        fi
        # shellcheck disable=SC2086
        ( export AI_ARCHITECT_NETWORK="$net" AI_ARCHITECT_DATA_VOLUME="$vol" AI_ARCHITECT_WINGMAN_VOLUME="$wvol"; \
          _plugin_run "" $cc -p "$proj" $envargs -f "$frag" up -d --force-recreate --quiet-pull ) || rc=$?
        _plugin_recreate_verdict "$name" "$rc"; return $rc
    fi
}

# One red line when a quiet recreate fails, pointing at the setup log.
_plugin_recreate_verdict() {   # <name> <rc>
    [ "${2:-0}" -ne 0 ] || return 0
    local slog=""; type get_setup_log >/dev/null 2>&1 && slog="$(get_setup_log 2>/dev/null)"
    printf '   %b✗%b Could not start '"'"'%s'"'"'.%s\n' "${RED:-}" "${NC:-}" "$1" "${slog:+ Details: $slog}" >&2
}

# k8s rollout restart re-pulls only when imagePullPolicy=Always.
_plugin_pull() {
    local name="$1" dir="$2" manifest="$3" deploy
    deploy="$(get_deployment_type 2>/dev/null || echo docker-compose)"
    local cc; cc="$(_plugin_compose_cmd)"
    if [ "$deploy" = "kubernetes" ]; then
        # No-op: the update path recreates with imagePullPolicy=Always, which both
        # rolls the pods and forces the registry re-pull (a bare rollout restart
        # here would double-roll and, under IfNotPresent, never re-pull same tags).
        return 0
    else
        local frag proj base plug envargs=""
        frag="${dir}/$(manifest_compose "$manifest" 2>/dev/null)"
        proj="$(plugin_compose_project "$name")"
        [ -f "$frag" ] || return 0
        # Pass the same env-files as deploy/recreate so image vars resolve to the real tags (else compose pulls the placeholder default).
        base="$(get_config_file 2>/dev/null)"; plug="$(get_plugin_env_file "$name" 2>/dev/null)"
        [ -n "$base" ] && [ -f "$base" ] && envargs="$envargs --env-file $base"
        [ -n "$plug" ] && [ -f "$plug" ] && envargs="$envargs --env-file $plug"
        # shellcheck disable=SC2086
        _plugin_run "" $cc -p "$proj" $envargs -f "$frag" pull
    fi
}
