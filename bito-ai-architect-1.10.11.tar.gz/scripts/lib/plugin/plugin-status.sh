#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
#
# list / status / config views.

if [ -n "${_BITOARCH_PLUGIN_STATUS_LOADED:-}" ]; then
    return 0
fi
_BITOARCH_PLUGIN_STATUS_LOADED=1

_BITOARCH_PLUGIN_STATUS_SELF="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
for _dep in state-journal.sh dependency-manager.sh reserved-keys.sh env-merger.sh deploy.sh manifest-parser.sh plugin-blocks.sh plugin-http.sh observability.sh plugin-messages.sh; do
    # shellcheck source=/dev/null
    . "${_BITOARCH_PLUGIN_STATUS_SELF}/${_dep}" 2>/dev/null || true
done
unset _dep

_ps_err()  { if type print_error >/dev/null 2>&1; then print_error "$1" >&2; else printf 'ERROR: %s\n' "$1" >&2; fi; }
_ps_journal_warn() { type log_silent >/dev/null 2>&1 && log_silent "plugin status: could not reconcile '${name:-?}' to '$1' in the journal; 'plugin list' may show a stale status"; return 0; }
_ps_warn() { if type print_warning >/dev/null 2>&1; then print_warning "$1" >&2; else printf 'WARNING: %s\n' "$1" >&2; fi; }
_ps_info() { if type print_info >/dev/null 2>&1; then print_info "$1"; else printf '%s\n' "$1"; fi; }
_ps_ok()   { if type print_success >/dev/null 2>&1; then print_success "$1"; else printf '%s\n' "$1"; fi; }
_ps_status() { if type print_status >/dev/null 2>&1; then print_status "$1"; else printf '%s\n' "$1"; fi; }

# Section header matching the core `bitoarch status` style (cyan ▶ subheaders).
_ps_subheader() {
    if type print_subheader >/dev/null 2>&1; then print_subheader "$1"
    else printf '%b%s%b\n' "${CYAN:-}" "$1" "${NC:-}"; fi
}
# Color for a status / health value (colors fall back to empty outside the CLI).
_ps_status_color() { case "$1" in installed|running|active) printf '%b' "${GREEN:-}";; failed|error) printf '%b' "${RED:-}";; *) printf '%b' "${YELLOW:-}";; esac; }
_ps_health_color() { case "$1" in healthy|ok) printf '%b' "${GREEN:-}";; unhealthy|error|degraded|stopped) printf '%b' "${RED:-}";; *) printf '%b' "${YELLOW:-}";; esac; }
# Left-aligned cell padded to <width> (from plain text, so color codes don't skew columns), optionally colored; width 0 = no pad.
_ps_cell() {
    local text="$1" width="$2" color="${3:-}" pad
    pad=$(( width - ${#text} )); [ "$pad" -lt 0 ] && pad=0
    if [ -n "$color" ]; then printf '%b%s%b%*s' "$color" "$text" "${NC:-}" "$pad" ""
    else printf '%-*s' "$width" "$text"; fi
}

# Journal self-heal: an interrupted install can leave status=installing behind even
# though the services came up later. Live health is the truth; reconcile the record.
_plugin_reconcile_status() {   # <name> <journal-status> <live-health>
    local name="$1" st="$2" he="$3"
    # "install-incomplete" is the pre-rename slug; normalize records written by
    # an earlier build so every surface shows one vocabulary.
    if [ "$st" = "install-incomplete" ]; then
        st="pending"
        journal_set_plugin_status "$name" "pending" 2>>"${LOG_FILE:-/dev/null}" || _ps_journal_warn "pending"
    fi
    if [ "$st" = "installing" ] && { [ "$he" = "healthy" ] || [ "$he" = "running" ]; }; then
        journal_set_plugin_status "$name" "installed" 2>>"${LOG_FILE:-/dev/null}" || _ps_journal_warn "installed"
        st="installed"
    fi
    # An interrupted install is stuck in the transient "installing" with nothing
    # running (stopped/unhealthy) -> settle it to the terminal, recoverable
    # "pending" so surfaces show it truthfully and `plugin install|config` resumes.
    if [ "$st" = "installing" ] && { [ "$he" = "stopped" ] || [ "$he" = "unhealthy" ]; }; then
        journal_set_plugin_status "$name" "pending" 2>>"${LOG_FILE:-/dev/null}" || _ps_journal_warn "pending"
        st="pending"
    fi
    # An interrupted uninstall leaves the transient "uninstalling": services still up
    # means the removal never took (reconcile to installed); services down means a
    # broken half-removal -> pending (recoverable; re-run uninstall to finish, install to keep).
    if [ "$st" = "uninstalling" ]; then
        if [ "$he" = "healthy" ] || [ "$he" = "running" ]; then
            journal_set_plugin_status "$name" "installed" 2>>"${LOG_FILE:-/dev/null}" || _ps_journal_warn "installed"; st="installed"
        else
            journal_set_plugin_status "$name" "pending" 2>>"${LOG_FILE:-/dev/null}" || _ps_journal_warn "pending"; st="pending"
        fi
    fi
    printf '%s' "$st"
}

plugin_list() {
    journal_ensure || return 1
    # In the base `bitoarch status` block the catalog of not-yet-installed plugins is noise; the
    # status caller passes --in-status to suppress it. `bitoarch plugin list` still shows it.
    local _in_status=0; [ "${1:-}" = "--in-status" ] && _in_status=1
    local plugins; plugins="$(journal_list_plugins)"
    if [ -z "$plugins" ]; then
        _ps_info "No plugins installed."
        [ "$_in_status" = "1" ] || _plugin_list_available
        return 0
    fi
    printf '%b%-20s %-14s %s%b\n' "${BOLD:-}" "NAME" "STATE" "HEALTH" "${NC:-}"
    local p st he _incomplete=()
    while IFS= read -r p; do
        [ -z "$p" ] && continue
        st="$(journal_plugin_field "$p" status)"
        # Prefer LIVE container health over the journal snapshot; fall back to the journal when undetermined.
        he="$(_plugin_current_health "$p" 2>/dev/null)"
        case "$he" in ""|unknown) he="$(journal_plugin_field "$p" health)" ;; esac
        st="$(_plugin_reconcile_status "$p" "$st" "$he")"
        [ "$st" = "pending" ] && _incomplete+=("$p")
        _ps_cell "$p" 20; printf ' '
        _ps_cell "${st//-/ }" 14 "$(_ps_status_color "$st")"; printf ' '
        _ps_cell "${he:-unknown}" 0 "$(_ps_health_color "${he:-unknown}")"; printf '\n'
    done <<EOF
$plugins
EOF
    # ONE hint line however many installs are pending: a single pending plugin
    # gets the concrete command; several get the <name> form (names are already
    # visible in the table as "pending").
    if [ "${#_incomplete[@]}" -gt 0 ] && [ -n "${_incomplete[0]:-}" ]; then
        local _hint_name="<name>"
        [ "${#_incomplete[@]}" -eq 1 ] && _hint_name="${_incomplete[0]}"
        echo ""
        printf '%b💡%b Complete the plugin installation: %bbitoarch plugin install %s%b\n' \
            "${BLUE:-}" "${NC:-}" "${YELLOW:-}" "$_hint_name" "${NC:-}"
    fi
    [ "$_in_status" = "1" ] || _plugin_list_available
}

# Catalog names not yet installed, from the local packages dir and the plugin CDN.
# Quiet by design: offline or empty catalog prints nothing.
_plugin_list_available() {
    # Catalog helpers live in preseed.sh (not loaded on the plain list path).
    type _plugin_catalog_all >/dev/null 2>&1 \
        || . "$(dirname "${BASH_SOURCE[0]}")/preseed.sh" 2>/dev/null || true
    type _plugin_catalog_all >/dev/null 2>&1 || return 0
    local line name disp desc shown=0
    while IFS='|' read -r name disp desc; do
        [ -z "$name" ] && continue
        journal_plugin_exists "$name" 2>/dev/null && continue
        [ "$shown" -eq 0 ] && { printf '\n%bAvailable to install%b\n' "${BOLD:-}" "${NC:-}"; shown=1; }
        printf '  %b%-16s%b %s%s\n' "${YELLOW:-}" "$name" "${NC:-}" "${disp:-}" "${desc:+ — $desc}"
    done <<EOF
$(_plugin_catalog_all 2>/dev/null)
EOF
    [ "$shown" -eq 1 ] && printf '\nInstall: %bbitoarch plugin install <name>%b\n' "${YELLOW:-}" "${NC:-}"
    return 0
}

_plugin_status_holds() {
    local p hold miss
    while IFS= read -r p; do
        [ -z "$p" ] && continue
        hold="$(journal_plugin_field "$p" 'upgrade_hold.version')"
        if [ -n "$hold" ]; then
            miss="$(journal_get_plugin "$p" | jq -r '.upgrade_hold.missing // [] | join(", ")' 2>/dev/null)"
            _ps_warn "Upgrade to v${hold} is on hold for '${p}'."
            printf '   Missing credential(s): %s\n' "$miss" >&2
            printf '   Add them, then run the upgrade again.\n' >&2
        fi
    done <<EOF
$(journal_list_plugins)
EOF
}

# ● color for a per-service state (green up, red down, yellow anything else).
_ps_service_state_color() {
    case "$1" in
        running|healthy)               printf '%b' "${GREEN:-}" ;;
        "not running"|exited|dead|error|crashloopbackoff|failed) printf '%b' "${RED:-}" ;;
        *)                             printf '%b' "${YELLOW:-}" ;;
    esac
}

# Expected-vs-actual service rows for one plugin, as PLUGIN|SERVICE|STATE|UPTIME lines.
# Docker: expected = compose-fragment container_name (or service key), actual = docker ps;
# an expected service with no live container is "not running" — plugin-level state must
# not mask a dead service. K8s: pods of the plugin's helm release (best-effort; a missing
# release/kubectl prints nothing for that plugin).
_plugin_service_rows() {   # <name> <deploy-type>
    local name="$1" dtype="$2" dir man
    dir="$(get_plugin_install_dir "$name" 2>/dev/null)" || true
    man="${dir}/plugin.yaml"
    [ -f "$man" ] || return 0
    if [ "$dtype" = "kubernetes" ]; then
        local rel ns pod ready pstat age _rest
        rel="$(manifest_helm_release "$man" 2>/dev/null)" || true
        [ -n "$rel" ] || return 0
        command -v kubectl >/dev/null 2>&1 || return 0
        ns="${BITOARCH_K8S_NAMESPACE:-bito-ai-architect}"
        kubectl get pods -n "$ns" -l "app.kubernetes.io/instance=${rel}" --no-headers 2>/dev/null |
        while read -r pod ready pstat age _rest; do
            [ -n "$pod" ] || continue
            printf '%s|%s|%s|%s\n' "$name" "$pod" "$(printf '%s' "$pstat" | tr '[:upper:]' '[:lower:]')" "$age"
        done
        return 0
    fi
    local frag expected live svc dline dname dstat state uptime tab
    tab="$(printf '\t')"
    frag="$(manifest_compose "$man" 2>/dev/null)" || true
    [ -n "$frag" ] && [ -f "${dir}/${frag}" ] || return 0
    expected="$(_mp_yq "${dir}/${frag}" '.services | to_entries | .[] | select(.value.restart != "no") | .value.container_name // .key' 2>/dev/null)" || true
    [ -n "$expected" ] || return 0
    # A failed docker query would empty $live and render every service as "not
    # running" -- a fabricated outage. Say so instead.
    live="$(docker ps --format '{{.Names}}\t{{.Status}}' 2>>"${LOG_FILE:-/dev/null}")" \
        || _ps_warn "could not query docker; plugin service states below may be inaccurate"
    while IFS= read -r svc; do
        [ -z "$svc" ] && continue
        state="not running"; uptime=""
        while IFS="$tab" read -r dname dstat; do
            [ -n "$dname" ] || continue
            case "$dname" in
                "$svc"|*"$svc"*)   # compose-generated names embed the service key
                    case "$dstat" in
                        Up*)             state="running"; uptime="${dstat#Up }" ;;
                        Exited*|Dead*)   state="exited" ;;
                        Restarting*)     state="restarting" ;;
                        *)               state="$(printf '%s' "${dstat%% *}" | tr '[:upper:]' '[:lower:]')" ;;
                    esac
                    break ;;
            esac
        done <<LIVE
$live
LIVE
        printf '%s|%s|%s|%s\n' "$name" "$svc" "$state" "$uptime"
    done <<EXP
$expected
EXP
}

# ▶ Services table (all plugins, or scoped to one): grouped by plugin (name on its
# first row only), ● colored by state. Prints nothing when there are no rows.
_plugin_services_section() {   # [name]
    local scope="${1:-}" plugins rows="" p svc state uptime dtype last=""
    plugins="$(journal_list_plugins 2>/dev/null || true)"
    [ -n "$scope" ] && plugins="$scope"
    [ -n "$plugins" ] || return 0
    dtype="$(get_deployment_type 2>/dev/null || echo docker-compose)"
    while IFS= read -r p; do
        [ -z "$p" ] && continue
        rows="${rows}$(_plugin_service_rows "$p" "$dtype" 2>/dev/null || true)
"
    done <<EOF
$plugins
EOF
    rows="$(printf '%s' "$rows" | grep -v '^$' || true)"
    [ -n "$rows" ] || return 0
    local wp=6 ws=7 wst=5   # min = header widths (PLUGIN/SERVICE/STATE)
    while IFS='|' read -r p svc state uptime; do
        [ "${#p}" -gt "$wp" ] && wp="${#p}"
        [ "${#svc}" -gt "$ws" ] && ws="${#svc}"
        [ "$(( ${#state} + 2 ))" -gt "$wst" ] && wst="$(( ${#state} + 2 ))"
    done <<EOF
$rows
EOF
    echo ""
    _ps_subheader "▶ Services"
    printf '%b%-*s   %-*s   %s%b\n' "${BOLD:-}" "$wp" "PLUGIN" "$ws" "SERVICE" "STATE" "${NC:-}"
    while IFS='|' read -r p svc state _uptime; do
        if [ "$p" = "$last" ]; then _ps_cell "" "$wp"; else _ps_cell "$p" "$wp"; last="$p"; fi
        printf '   '
        _ps_cell "$svc" "$ws"; printf '   '
        _ps_cell "● $state" "$wst" "$(_ps_service_state_color "$state")"
        printf '\n'
    done <<EOF
$rows
EOF
}

# Single-plugin view: version, live status/health, deps, skills; internal bookkeeping omitted (`plugin config` shows the full env).
_plugin_status_one() {
    local name="$1"
    if ! journal_plugin_exists "$name"; then
        _pm_not_installed "$name"
        return 1
    fi
    local rec ver st he
    rec="$(journal_get_plugin "$name")"
    ver="$(printf '%s' "$rec" | jq -r '.version // "?"')"
    st="$(printf '%s' "$rec"  | jq -r '.status // "?"')"
    # Live container health first; fall back to the journal snapshot.
    he="$(_plugin_current_health "$name" 2>/dev/null)"
    case "$he" in ""|unknown) he="$(printf '%s' "$rec" | jq -r '.health // "unknown"')" ;; esac
    st="$(_plugin_reconcile_status "$name" "$st" "$he")"

    _ps_subheader "▶ Plugin: ${name}"
    local about; about="$(manifest_description "$(get_plugin_install_dir "$name")/plugin.yaml" 2>/dev/null)" || true
    [ -n "$about" ] && printf '  • %-9s %s\n' "About" "$about"
    printf '  • %-9s %b%s%b\n' "Version" "${BOLD:-}" "$ver" "${NC:-}"
    printf '  • %-9s %b%s%b\n' "Status"  "$(_ps_status_color "$st")" "${st//-/ }" "${NC:-}"
    printf '  • %-9s %b%s%b\n' "Health"  "$(_ps_health_color "$he")" "${he:-unknown}" "${NC:-}"
    [ "$st" = "pending" ] && printf '  • %-9s %bbitoarch plugin install %s%b\n' "Complete" "${YELLOW:-}" "$name" "${NC:-}"

    # Plugin-specific status extras (e.g. task-analyzer's Jira webhook URL) via hooks.status; base stays generic.
    local _sdir _sman _shook
    _sdir="$(get_plugin_install_dir "$name")"; _sman="${_sdir}/plugin.yaml"
    _shook="$(manifest_hook "$_sman" status 2>/dev/null)"
    if [ -n "$_shook" ] && [ -f "$_sdir/$_shook" ]; then
        ( PLUGIN_NAME="$name" PLUGIN_DIR="$_sdir" PLUGIN_MANIFEST="$_sman" PLUGIN_ENV_FILE="$(get_plugin_env_file "$name")"
          # shellcheck source=/dev/null
          . "$_sdir/$_shook" ) || true
    fi

    _plugin_services_section "$name"
    _plugin_observability_section "$name"

    local hold; hold="$(printf '%s' "$rec" | jq -r '.upgrade_hold.version // empty')"
    if [ -n "$hold" ]; then
        echo ""
        _ps_warn "Upgrade to v${hold} is on hold for '${name}'."
        printf '   Missing credential(s): %s\n' "$(printf '%s' "$rec" | jq -r '.upgrade_hold.missing // [] | join(", ")')" >&2
        printf '   Add them, then run the upgrade again.\n' >&2
    fi
}

# Live observability rows for the single-plugin detail view. Rows that carry
# no signal for this plugin (no DLQ topics declared, no janitor state, data dir
# not host-visible) are omitted rather than printed as "n/a" noise.
_plugin_observability_section() {
    local name="$1"
    type plugin_storage_mode >/dev/null 2>&1 || return 0
    local mode dlq disk jan rows=""
    mode="$(plugin_storage_mode "$name" 2>/dev/null)"
    dlq="$(plugin_dlq_depth "$name" 2>/dev/null)"
    disk="$(plugin_disk_usage "$name" 2>/dev/null)"
    jan="$(plugin_janitor_state "$name" 2>/dev/null)"
    echo ""
    _ps_subheader "▶ Observability"
    printf '  • %-9s %s\n' "Storage" "${mode:-local}"
    case "$dlq" in "n/a ("*) ;; *) printf '  • %-9s %s\n' "DLQ" "$dlq" ;; esac
    case "$disk" in "n/a ("*) ;; *) printf '  • %-9s %s\n' "Disk" "$disk" ;; esac
    case "$jan" in "n/a ("*) ;; *) printf '  • %-9s %s\n' "Janitor" "$jan" ;; esac
}

plugin_status() {
    local name="${1:-}"
    journal_ensure || return 1
    if [ -n "$name" ]; then
        _plugin_status_one "$name"
        return $?
    fi
    _ps_subheader "▶ Plugins"
    plugin_list
    echo ""
    _ps_subheader "▶ Shared dependency packs"
    deps_list
    _plugin_status_holds
}

_plugin_mask_value() {
    local key="$1" val="$2"
    # One secret-key definition: reserved-keys.sh's matcher, so the config view
    # and the prompts never diverge on what counts as a secret.
    if type _plugin_key_is_secret >/dev/null 2>&1; then
        if _plugin_key_is_secret "$key"; then [ -n "$val" ] && echo "********" || echo ""; else echo "$val"; fi
        return 0
    fi
    case "$key" in
        *PASSWORD*|*SECRET*|*TOKEN*|*_KEY|*APIKEY*|*API_KEY*)
            [ -n "$val" ] && echo "********" || echo "" ;;
        *) echo "$val" ;;
    esac
}

_plugin_config_view() {   # <env_file> [manifest]
    local env_file="$1" manifest="${2:-}" rows="" key label val max=0 i pname=""
    # Rows come from the manifest's config.display (KEY|LABEL, in order); fallback =
    # prompt entries + required keys (label = key name) — never the whole env.
    if [ -n "$manifest" ] && [ -f "$manifest" ]; then
        pname="$(manifest_name "$manifest" 2>/dev/null)"
        rows="$(manifest_config_display "$manifest" 2>/dev/null)"
        [ -z "$rows" ] && rows="$({ manifest_config_prompt "$manifest" 2>/dev/null | cut -d'|' -f1,2
                                    manifest_required_config_keys "$manifest" 2>/dev/null | sed 's/.*/&|&/'
                                  } | awk -F'|' 'NF && !seen[$1]++')"
    fi
    _ps_subheader "▶ ${pname:+${pname} · }Configuration"
    if [ ! -f "$env_file" ]; then
        _ps_info "No configuration set yet for this plugin."
        return 0
    fi
    local -a ks=() ls=()
    while IFS='|' read -r key label; do
        [ -n "$key" ] || continue
        [ -n "$label" ] || label="$key"
        ks[${#ks[@]}]="$key"; ls[${#ls[@]}]="$label"
        [ "${#label}" -gt "$max" ] && max="${#label}"
    done <<EOF
$rows
EOF
    # Widen the value column to also fit the status-hook's labels (measure pass), so the config.display
    # rows and the hook's extra rows (respond mode, watched projects, webhook…) share ONE aligned column.
    local _cvdir="" _cvhook="" _hookw=0
    if [ -n "$manifest" ] && [ -f "$manifest" ]; then
        _cvdir="$(dirname "$manifest")"; _cvhook="$(manifest_hook "$manifest" status 2>/dev/null)"
        if [ -n "$_cvhook" ] && [ -f "$_cvdir/$_cvhook" ]; then
            _hookw="$( PLUGIN_NAME="${pname:-$(manifest_name "$manifest" 2>/dev/null)}" PLUGIN_DIR="$_cvdir" \
                       PLUGIN_MANIFEST="$manifest" PLUGIN_ENV_FILE="$env_file" PLUGIN_CFG_VIEW=1 PLUGIN_CFG_MEASURE=1
                       . "$_cvdir/$_cvhook" 2>/dev/null )"
            case "$_hookw" in ''|*[!0-9]*) _hookw=0 ;; esac
            [ "$_hookw" -gt "$max" ] && max="$_hookw"
        fi
    fi
    if [ "${#ks[@]}" -eq 0 ]; then
        _ps_info "No user configuration set yet for this plugin."
    else
        for i in "${!ks[@]}"; do
            key="${ks[$i]}"; label="${ls[$i]}"
            val="$(plugin_env_get "$env_file" "$key" 2>/dev/null)"
            if [ -n "$val" ]; then
                printf '  • %-*s %s\n' "$((max + 2))" "$label" "$(_plugin_mask_value "$key" "$val")"
            else
                printf '  • %-*s %b(not set)%b\n' "$((max + 2))" "$label" "${DIM:-}" "${NC:-}"
            fi
        done
    fi
    # Plugin-specific config extras (respond mode, watched projects, Jira webhook URL) render here,
    # BEFORE the tip, via hooks.status — at the SAME width measured above so the columns line up.
    if [ -n "$_cvhook" ] && [ -f "$_cvdir/$_cvhook" ]; then
        ( PLUGIN_NAME="${pname:-$(manifest_name "$manifest" 2>/dev/null)}" PLUGIN_DIR="$_cvdir" \
          PLUGIN_MANIFEST="$manifest" PLUGIN_ENV_FILE="$env_file" PLUGIN_CFG_VIEW=1 PLUGIN_CFG_LABEL_W="$((max + 2))"
          # shellcheck source=/dev/null
          . "$_cvdir/$_cvhook" ) || true
    fi
    echo ""
    echo -e "${BLUE:-}💡 Tip:${NC:-} change with ${YELLOW:-}--set KEY=VALUE${NC:-} or ${YELLOW:-}bitoarch plugin config edit <name>${NC:-} (applies immediately); secrets are shown as ********"
}

# Secret-like keys are prompted with hidden input.
# _plugin_key_is_secret now lives in reserved-keys.sh (sourced above at the top of this
# file), so install-flow and this view share one definition -> identical masking everywhere.

# ── Generic CSV set helpers (used by plugin config hooks) ─────────────────────
# A comma-separated set in one env value (empty = unset); pure string set-ops, portable bash 3.2.

# Add KEYS (comma/space-separated) to a CSV set, de-duplicated, order-preserving.
_csv_add() {   # <csv> <keys...>
    local csv="$1"; shift
    local out="$csv" k existing
    for k in $(printf '%s' "$*" | tr ', ' '  '); do
        [ -z "$k" ] && continue
        existing=",${out},"
        case "$existing" in *",${k},"*) continue ;; esac
        out="${out:+${out},}${k}"
    done
    printf '%s' "$out"
}

# Remove KEYS from a CSV set; preserves the remaining order.
_csv_del() {   # <csv> <keys...>
    local csv="$1"; shift
    local rm=" $(printf '%s' "$*" | tr ', ' '  ') " out="" k
    for k in $(printf '%s' "$csv" | tr ',' ' '); do
        [ -z "$k" ] && continue
        case "$rm" in *" $k "*) continue ;; esac
        out="${out:+${out},}${k}"
    done
    printf '%s' "$out"
}

# Prompt for the plugin's required-but-unset config (manifest flags with an empty default); interactive only, no-op under AUTO_SETUP/no TTY.
# Sets _PLUGIN_COLLECTED_COUNT to the number of values collected.
_plugin_collect_config() {
    local name="$1" manifest="$2" env_file="$3"
    _PLUGIN_COLLECTED_COUNT=0
    if [ "${BITOARCH_PLUGIN_FORCE_PROMPT:-}" != "1" ]; then
        [ -t 0 ] || return 0
        [ "${AUTO_SETUP:-}" = "true" ] && return 0
    fi
    type manifest_flags >/dev/null 2>&1 || return 0

    # Gather required-but-unset keys FIRST so the prompts below read the operator's input, not the heredoc (read-in-while-read trap).
    # Flags marked `prompt: false` are engine-managed: never surfaced here even
    # when their default is intentionally empty.
    local _noprompt=""
    type manifest_flags_noprompt >/dev/null 2>&1 && _noprompt="$(manifest_flags_noprompt "$manifest")"
    local key def owner src desc cur val
    local keys=() dsc=()
    while IFS='|' read -r key def owner src desc; do
        [ -z "$key" ] && continue
        [ -n "$def" ] && continue                       # has a default -> not operator-required
        printf '%s\n' "$_noprompt" | grep -qxF -- "$key" && continue
        cur="$(plugin_env_get "$env_file" "$key" 2>/dev/null)"
        [ -n "$cur" ] && continue                       # already set -> skip
        keys+=("$key"); dsc+=("$desc")
    done <<EOF
$(manifest_flags "$manifest" "$name")
EOF
    [ "${#keys[@]}" -eq 0 ] && return 0

    _ps_info "Setup for '${name}': enter required values."
    _ps_info "Press Enter to set a value later."
    local i
    for i in "${!keys[@]}"; do
        key="${keys[$i]}"; desc="${dsc[$i]}"
        if _plugin_key_is_secret "$key"; then
            read -r -s -p "  ${key}:${desc:+ $desc} (hidden): " val; echo
        else
            read -r -p "  ${key}:${desc:+ $desc}: " val
        fi
        if [ -n "$val" ]; then
            if plugin_env_set "$env_file" "$key" "$val"; then
                _ps_status "set ${key}"
                _PLUGIN_COLLECTED_COUNT=$((_PLUGIN_COLLECTED_COUNT + 1))
            else
                _ps_err "could not write ${key} to ${env_file}"
            fi
        fi
    done
    return 0
}

# Pre-mutation backup of a plugin's .env — same store + retention as base
# config backups (VAR_DIR/backups/configs, CONFIG_BACKUP_RETENTION). Best-effort.
_ps_backup_plugin_env() {
    local name="$1" env_file="$2"
    [ -f "$env_file" ] || return 0
    if ! command -v backup_config_file >/dev/null 2>&1; then
        # shellcheck source=/dev/null
        . "${_BITOARCH_PLUGIN_STATUS_SELF}/../config-backup-manager.sh" 2>/dev/null || true
    fi
    command -v backup_config_file >/dev/null 2>&1 && \
        { backup_config_file "$env_file" "plugins/${name}" >>"${LOG_FILE:-/dev/null}" 2>&1 \
          || _ps_warn "could not back up ${env_file} before changing it (continuing)"; }
}

plugin_config() {
    # `plugin config edit <name>` is the explicit edit form (mirrors the base `config edit <target>`).
    local _edit_sub=0
    if [ "${1:-}" = "edit" ]; then _edit_sub=1; shift 2>/dev/null || true; fi
    local name="$1"; shift 2>/dev/null || true
    [ -z "$name" ] && { _ps_err "usage: bitoarch plugin config <name> [--set k=v ...]   |   bitoarch plugin config edit <name>"; return 1; }
    if ! journal_plugin_exists "$name"; then
        _pm_not_installed "$name"
        return 1
    fi
    local env_file install_dir manifest
    env_file="$(get_plugin_env_file "$name")"
    install_dir="$(get_plugin_install_dir "$name")"
    manifest="$install_dir/plugin.yaml"

    # Changes apply immediately (recreate) — the PaaS convention.
    local do_edit="$_edit_sub" do_restart=0 nset=0
    local sets=() passthru=()
    while [ $# -gt 0 ]; do
        case "$1" in
            --set) shift; sets[$nset]="$1"; nset=$((nset + 1))
                   # `--set k=v ...` (help contract): absorb consecutive KEY=VALUE tokens.
                   while [ $# -gt 1 ] && printf '%s' "$2" | grep -qE '^[A-Za-z_][A-Za-z0-9_]*='; do
                       shift; sets[$nset]="$1"; nset=$((nset + 1))
                   done ;;
            --set=*) sets[$nset]="${1#--set=}"; nset=$((nset + 1)) ;;
            *) passthru+=("$1") ;;   # plugin-specific flag -> dispatched to the plugin's config hook
        esac
        shift
    done

    # Dispatch unrecognised (plugin-owned) flags to the plugin's config hook, sourced with base helpers + env in scope.
    if [ "${#passthru[@]}" -gt 0 ]; then
        local cfg_hook; cfg_hook="$(manifest_hook "$manifest" config 2>/dev/null)"
        if [ -z "$cfg_hook" ] || [ ! -f "$install_dir/$cfg_hook" ]; then
            _ps_err "unknown config option: ${passthru[0]}"; return 1
        fi
        _ps_backup_plugin_env "$name" "$env_file"
        ( PLUGIN_NAME="$name" PLUGIN_DIR="$install_dir" PLUGIN_MANIFEST="$manifest" \
          PLUGIN_ENV_FILE="$env_file" \
          BITOARCH_DEPLOY_TYPE="$(get_deployment_type 2>/dev/null || echo docker-compose)"
          . "$install_dir/$cfg_hook" "${passthru[@]}" )
        return $?
    fi

    if [ "$nset" -gt 0 ]; then
        _ps_backup_plugin_env "$name" "$env_file"
        local kv key val setkeys="" failkeys=""
        for kv in "${sets[@]}"; do
            key="${kv%%=*}"; val="${kv#*=}"
            if [ "$key" = "$kv" ]; then _ps_err "invalid --set '${kv}' (expected KEY=VALUE)"; return 1; fi
            if plugin_key_is_reserved "$key"; then
                _ps_err "refusing to set reserved base key '${key}' in a plugin config"
                return 1
            fi
            # Empty stays allowed (clearing a key); anything else must be URL-shaped.
            if [ "$key" = "PUBLIC_URL" ] && [ -n "$val" ] && type _plugin_public_url_shape_ok >/dev/null 2>&1 \
                && ! _plugin_public_url_shape_ok "$val"; then
                type log_silent >/dev/null 2>&1 && log_silent "plugin config: rejected invalid PUBLIC_URL for '${name}' (shape check)"
                _ps_err "Not a valid URL — must start with http:// or https://"
                return 1
            fi
            if plugin_env_set "$env_file" "$key" "$val"; then
                setkeys="${setkeys:+${setkeys}, }${key}"
                # Only inside the success branch: repointing the shared ingress at a
                # PUBLIC_URL that was never persisted leaves the plugin reachable at
                # neither the old host nor the new one.
                [ "$key" = "PUBLIC_URL" ] && type ingress_set_host_from_public_url >/dev/null 2>&1 \
                    && ingress_set_host_from_public_url "$val"
            else
                # Do not tick a key that was never written.
                failkeys="${failkeys:+${failkeys}, }${key}"
            fi
        done
        [ -n "$setkeys" ] && printf '%b✓%b Updated: %s\n' "${GREEN:-}" "${NC:-}" "$setkeys" >&2
        [ -n "${failkeys:-}" ] && _ps_err "Could not write: ${failkeys} (see the setup log)"
        # An empty value on a required key leaves the service unable to start — say so now, not via a
        # crash loop — and skip the restart it cannot survive.
        local _still_unset; _still_unset="$(_plugin_unset_required_config "$manifest" "$env_file" 2>/dev/null || true)"
        if [ -n "$_still_unset" ]; then
            printf '%b⚠%b Required configuration is empty: %s — '"'"'%s'"'"' cannot start until set.\n' \
                "${YELLOW:-}" "${NC:-}" "$(printf '%s' "$_still_unset" | tr '\n' ' ' | sed 's/ $//;s/ /, /g')" "$name" >&2
        else
            do_restart=1
        fi
    elif [ "$do_edit" -eq 1 ]; then
        # `edit` opens an editor on the plugin env; with no TTY and no editor configured
        # there is nothing to open — point at the non-interactive path instead of failing.
        if [ ! -t 0 ] && [ -z "${VISUAL:-${EDITOR:-}}" ]; then
            _ps_err "config edit needs an interactive terminal; set values non-interactively with: bitoarch plugin config ${name} --set KEY=VALUE"
            return 1
        fi
        # Apply only when the editor actually changed the file.
        _ps_backup_plugin_env "$name" "$env_file"
        local _pre; _pre="$(cksum "$env_file" 2>/dev/null)"
        "${VISUAL:-${EDITOR:-vi}}" "$env_file"
        [ "$(cksum "$env_file" 2>/dev/null)" != "$_pre" ] && do_restart=1
    else
        # First-time: fill required-but-unset keys (no-op if all already set).
        _ps_backup_plugin_env "$name" "$env_file"
        _plugin_collect_config "$name" "$manifest" "$env_file"
        local _changed="${_PLUGIN_COLLECTED_COUNT:-0}"
        # Then offer a full reconfigure of declared values (bare interactive only).
        if [ "${BITOARCH_PLUGIN_FORCE_PROMPT:-}" = "1" ] || { [ -t 0 ] && [ "${AUTO_SETUP:-}" != "true" ]; }; then
            local _rc; read -r -p "Reconfigure '${name}'? (y/N): " _rc
            case "$_rc" in
                [Yy]*) # Re-run the plugin's full setup.steps (same flow as a fresh install),
                       # then print the same closing (✅ banner + hooks.summary) install/start show.
                       local _rc_rcfg
                       BITOARCH_RECONFIGURE=1 _plugin_interactive_setup "$name" "$install_dir" "$manifest" "$env_file"; _rc_rcfg=$?
                       if [ "$_rc_rcfg" -eq 0 ]; then
                           # Same install-state reconciliation as plugin start.
                           if [ "${_BITOARCH_SETUP_WARNED:-}" = "1" ]; then
                               journal_set_plugin_status "$name" "pending" 2>>"${LOG_FILE:-/dev/null}" || _ps_journal_warn pending
                           elif case "$(journal_plugin_field "$name" status)" in pending|install-incomplete) true ;; *) false ;; esac; then
                               journal_set_plugin_status "$name" "installed" 2>>"${LOG_FILE:-/dev/null}" || _ps_journal_warn installed
                           fi
                           type _plugin_sync_scheduler >/dev/null 2>&1 && _plugin_sync_scheduler || true
                           _plugin_setup_closing "$name" "$install_dir" "$manifest" "$env_file"
                       fi
                       return "$_rc_rcfg" ;;
            esac
        fi
        [ "$_changed" -gt 0 ] && do_restart=1
        _plugin_config_view "$env_file" "$manifest"
    fi

    if [ "$do_restart" -eq 1 ]; then
        # Recreate (not `compose restart`) so the container re-reads the env-files and the change takes effect.
        printf '\n' >&2
        _pm_restarting "$name"
        if _plugin_recreate "$name" "$install_dir" "$manifest"; then
            printf '%b✓%b Restarted with the new configuration.\n' "${GREEN:-}" "${NC:-}" >&2
        fi
    fi
    return 0
}
