#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
#
# Rollback engine (idempotent teardown of a failed install).

if [ -n "${_BITOARCH_PLUGIN_ROLLBACK_LOADED:-}" ]; then
    return 0
fi
_BITOARCH_PLUGIN_ROLLBACK_LOADED=1

_rb_log() { type log_silent >/dev/null 2>&1 && log_silent "plugin rollback: $1"; }

plugin_rollback_install() {
    local name="$1" dir="${2:-}" manifest="${3:-}"
    local rec db user
    rec="$(journal_get_plugin "$name" 2>/dev/null)"
    _rb_log "rolling back install of '${name}'"

    # Rollback runs after a FAILED install, so anything it cannot clean up becomes
    # an orphan the platform no longer has a record of (the journal row is dropped
    # at the end). Every step reports what it could not do.
    # Resolve the log target once; never /dev/null, or the rollback is unauditable.
    local _rblog; _rblog="$(get_setup_log 2>/dev/null)"
    [ -n "$_rblog" ] || _rblog="/dev/stderr"
    local _rb_failed=""

    if type _plugin_undeploy >/dev/null 2>&1 && [ -n "$dir" ] && [ -n "$manifest" ]; then
        _plugin_undeploy "$name" "$dir" "$manifest" --purge >>"$_rblog" 2>&1 \
            || { _rb_failed="${_rb_failed} services"; _rb_log "could not tear down '${name}' services; its containers may still be running"; }
    fi

    if [ -n "$rec" ] && type plugin_mysql_deprovision >/dev/null 2>&1; then
        db="$(printf '%s' "$rec" | jq -r '.db.name // ""' 2>/dev/null)"
        user="$(printf '%s' "$rec" | jq -r '.db.user // ""' 2>/dev/null)"
        if [ -n "$db" ] && [ "$db" != "null" ]; then
            plugin_mysql_deprovision "$db" "$user" >>"$_rblog" 2>&1 \
                || { _rb_failed="${_rb_failed} database"; _rb_log "could not drop plugin DB '${db}' / user '${user}' — remove them manually (the journal record is about to go)"; }
        fi
    fi

    # Pack teardown progress goes to the log, not the terminal (spinner prints on stdout).
    type dep_release_requires >/dev/null 2>&1 \
        && { dep_release_requires "$name" >>"$_rblog" 2>&1 \
             || { _rb_failed="${_rb_failed} dependency-packs"; _rb_log "could not release shared dependency packs for '${name}'; pack refcounts may be stale"; }; }

    # purge=1 removes skills this failed install promoted fresh; the binary is forward-only.
    type wingman_skill_teardown >/dev/null 2>&1 \
        && { wingman_skill_teardown "$name" 1 >>"$_rblog" 2>&1 \
             || { _rb_failed="${_rb_failed} wingman-skills"; _rb_log "skill teardown failed for '${name}'; skill refcounts may never reach zero"; }; }

    local install_dir data_dir
    install_dir="$(get_plugin_install_dir "$name" 2>/dev/null)"
    data_dir="$(get_plugin_data_dir "$name" 2>/dev/null)"
    if [ -n "$install_dir" ] && [ -d "$install_dir" ]; then
        rm -rf "$install_dir" 2>>"$_rblog" || { _rb_failed="${_rb_failed} install-dir"; _rb_log "could not remove ${install_dir}"; }
    fi
    # Keep the config dir: operator-entered values (PUBLIC_URL, creds) survive a
    # failed install so the retry reuses them — same contract as non-purge uninstall.
    if [ -n "$data_dir" ] && [ -d "$data_dir" ]; then
        rm -rf "$data_dir" 2>>"$_rblog" || { _rb_failed="${_rb_failed} data-dir"; _rb_log "could not remove ${data_dir}"; }
    fi

    # Drop the journal entry last, so a crash during rollback still has a record.
    if journal_remove_plugin "$name" >>"$_rblog" 2>&1; then
        if [ -z "$_rb_failed" ]; then
            _rb_log "rollback of '${name}' complete"
        else
            _rb_log "rollback of '${name}' INCOMPLETE — left behind:${_rb_failed}"
        fi
    else
        _rb_log "ROLLBACK INCOMPLETE for '${name}': journal entry could not be removed, so it stays recorded as installing"
    fi
}
