#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
#
# Plugin preseed: non-interactively install + configure the plugins declared in install.yaml's `plugins:` block.
# Config is written to the plugin env BEFORE install so the first deploy is healthy. Idempotent; no-op when none declared.

if [ -n "${_BITOARCH_PLUGIN_PRESEED_LOADED:-}" ]; then
    return 0
fi
_BITOARCH_PLUGIN_PRESEED_LOADED=1

_BITOARCH_PLUGIN_PRESEED_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

_pp_info() { if type print_info >/dev/null 2>&1; then print_info "$1"; else printf '%s\n' "$1"; fi; }
_pp_warn() { if type print_warning >/dev/null 2>&1; then print_warning "$1" >&2; else printf 'WARNING: %s\n' "$1" >&2; fi; }
# Amber close for a failed catalog/preseed install: headline + the retry command,
# mirroring the engine's not-complete block so every failure ends with a next step.
_pp_install_failed_block() {   # <name-or-source>
    printf '\n%b⚠️  could not install '"'"'%s'"'"'%b\n' "${YELLOW:-}" "$1" "${NC:-}" >&2
    printf '%b💡%b Install later: %bbitoarch plugin install %s%b\n\n' \
        "${BLUE:-}" "${NC:-}" "${YELLOW:-}" "$1" "${NC:-}" >&2
}

# Source the engine lazily (each module guards against re-sourcing).
_plugin_preseed_load_engine() {
    local d="${_BITOARCH_PLUGIN_PRESEED_DIR}"
    type get_plugin_env_file    >/dev/null 2>&1 || . "${d}/../path-manager.sh"     2>/dev/null || true
    type get_docker_compose_cmd >/dev/null 2>&1 || . "${d}/../../docker-manager.sh" 2>/dev/null || true
    type manifest_name          >/dev/null 2>&1 || . "${d}/manifest-parser.sh"     2>/dev/null || true
    type journal_plugin_exists  >/dev/null 2>&1 || . "${d}/state-journal.sh"       2>/dev/null || true
    type plugin_env_set         >/dev/null 2>&1 || . "${d}/env-merger.sh" || true
    type plugin_install         >/dev/null 2>&1 || . "${d}/install-flow.sh" || true
    # plugin_install alone is not enough: without env-merger every declared
    # config value would be silently dropped while preseed reported success.
    type plugin_env_set >/dev/null 2>&1 \
        || _pp_warn "preseed: env-merger unavailable; declared plugin config cannot be written"
    type plugin_install >/dev/null 2>&1   # success only if the install entry is loaded
}

# The bundled-packages directory: BITOARCH_PLUGIN_PACKAGES_DIR if set, else in-tree samples/plugins.
_plugin_bundled_packages_dir() {
    if [ -n "${BITOARCH_PLUGIN_PACKAGES_DIR:-}" ]; then printf '%s' "$BITOARCH_PLUGIN_PACKAGES_DIR"; return 0; fi
    local d="${_BITOARCH_PLUGIN_PRESEED_DIR}/../../../samples/plugins"
    [ -d "$d" ] && { ( cd "$d" && pwd ); return 0; }
    printf '%s' "$d"
}

# Validate a config key before writing it to a plugin env: shell-safe identifier, single-line, not a reserved base key. rc 0 = OK.
_plugin_preseed_key_ok() {   # <key>
    local k="$1"
    # Reject empty, non-identifier, and multiline keys.
    case "$k" in
        ''|*[!A-Za-z0-9_]*) return 1 ;;
    esac
    case "$k" in *"
"*) return 1 ;; esac
    # Reject reserved base infrastructure keys (a plugin may not shadow them).
    if type plugin_key_is_reserved >/dev/null 2>&1 && plugin_key_is_reserved "$k"; then
        return 1
    fi
    return 0
}

# Respond-mode provenance: an operator-preseeded respond-mode value IS the explicit
# choice. A plugin marks explicit answers via its manifest-declared marker key
# (config.webhook.chosenEnv) so a later
# interactive run doesn't re-ask — template defaults alone never set the marker.
# No-op when the source isn't a local dir or the manifest doesn't declare the keys.
_pp_mark_respond_choice() {   # <resolved-source> <env_file> <written-keys (newline list)>
    local man="$1/plugin.yaml" env_file="$2" keys="$3" mode_env chosen_env
    [ -f "$man" ] || return 0
    mode_env="$(manifest_config_webhook "$man" respondModeEnv 2>/dev/null)"
    chosen_env="$(manifest_config_webhook "$man" chosenEnv 2>/dev/null)"
    { [ -n "$mode_env" ] && [ -n "$chosen_env" ]; } || return 0
    printf '%s\n' "$keys" | grep -qx "$mode_env" || return 0
    plugin_env_set "$env_file" "$chosen_env" "1"
}

# List the bundled plugin catalog as NAME|DISPLAY|DESCRIPTION records (one per package dir with a plugin.yaml).
# Remote catalog: each published plugin exposes <base>/<name>/<name>-latest.json
# (written by the plugins CI). Names come from the catalog var so a new plugin is one
# env change; the base URL points at the channel the install tracks.
_plugin_catalog_remote() {
    command -v curl >/dev/null 2>&1 || return 0
    command -v jq >/dev/null 2>&1 || return 0
    local base="${PLUGINS_CDN_BASE_URL:-${BITOARCH_PLUGIN_DOWNLOAD_URL:-https://aiarch.bito.ai}/ai-architect-plugins}"
    # Plugin names come from the CDN's published index (owned by the plugins repo)
    # or the BITOARCH_PLUGIN_CATALOG override — never hardcoded in the base.
    local names="${BITOARCH_PLUGIN_CATALOG:-}"
    if [ -z "$names" ]; then
        names="$(curl -sfL -m 5 "${base}/catalog.json" 2>>"${LOG_FILE:-/dev/null}" | jq -r '.plugins[]? // empty' 2>/dev/null | tr '\n' ' ')"
        [ -n "$names" ] || { type log_silent >/dev/null 2>&1 && log_silent "preseed: plugin catalog empty or unreachable at ${base}"; }
    fi
    [ -n "${names// /}" ] || return 0
    local n meta disp desc ver
    for n in $names; do
        if type journal_plugin_exists >/dev/null 2>&1 && journal_plugin_exists "$n" 2>/dev/null \
           && [ "$(journal_plugin_field "$n" status 2>/dev/null)" = "installed" ]; then continue; fi
        meta="$(curl -sfL -m 5 "${base}/${n}/${n}-latest.json" 2>/dev/null)" || continue
        [ -n "$meta" ] || continue
        disp="$(printf '%s' "$meta" | jq -r '.displayName // .display_name // empty' 2>/dev/null)"
        desc="$(printf '%s' "$meta" | jq -r '.description // empty' 2>/dev/null)"
        ver="$(printf '%s' "$meta" | jq -r '.version // empty' 2>/dev/null)"
        printf '%s|%s|%s\n' "$n" "${disp:-$n}${ver:+ (v$ver)}" "$desc"
    done
    return 0
}

# Union view: local bundled packages first, then remote entries not already listed.
_plugin_catalog_all() {
    local local_list remote_list line name
    local_list="$(_plugin_catalog_list)"
    [ -n "$local_list" ] && printf '%s\n' "$local_list"
    remote_list="$(_plugin_catalog_remote)"
    while IFS= read -r line; do
        [ -z "$line" ] && continue
        name="${line%%|*}"
        printf '%s\n' "$local_list" | grep -q "^${name}|" || printf '%s\n' "$line"
    done <<EOF
$remote_list
EOF
    return 0
}

_plugin_catalog_list() {
    local d name disp desc man
    d="$(_plugin_bundled_packages_dir)"
    [ -d "$d" ] || return 0
    command -v yq >/dev/null 2>&1 || return 0
    for man in "$d"/*/plugin.yaml; do
        [ -f "$man" ] || continue
        name="$(manifest_name "$man" 2>/dev/null)"
        [ -n "$name" ] || continue
        # Skip a plugin that's already installed -- don't offer to re-install it.
        if type journal_plugin_exists >/dev/null 2>&1 && journal_plugin_exists "$name" 2>/dev/null \
           && [ "$(journal_plugin_field "$name" status 2>/dev/null)" = "installed" ]; then continue; fi
        disp="$(manifest_display_name "$man" 2>/dev/null)"; [ -n "$disp" ] || disp="$name"
        desc="$(manifest_description "$man" 2>/dev/null)"
        printf '%s|%s|%s\n' "$name" "$disp" "$desc"
    done
}

# Resolve a declared source to a plugin DIRECTORY (path as-is, or a bundled name); prints nothing if unresolved.
_plugin_preseed_resolve_source() {
    local src="$1" d
    [ -d "$src" ] && { printf '%s' "$src"; return 0; }
    d="$(_plugin_bundled_packages_dir)"
    [ -n "$d" ] && [ -d "$d/$src" ] && { printf '%s' "$d/$src"; return 0; }
    return 0
}

_plugin_preseed_name() { manifest_name "$1/plugin.yaml" 2>/dev/null; }

# plugin_preseed_apply <install.yaml> -- install + configure declared plugins.
plugin_preseed_apply() {
    local yaml="${1:-}" mode="${2:-}"
    [ -n "$yaml" ] && [ -f "$yaml" ] || return 0
    command -v yq >/dev/null 2>&1 || return 0
    # A yq parse error must not read as "no plugins declared" — that would skip
    # the operator's entire declarative preseed with no message at all.
    local n _yq_err
    if ! n="$(yq eval '.plugins | length' "$yaml" 2>&1)"; then
        _pp_warn "preseed: cannot parse ${yaml}: $(printf '%s' "$n" | tail -c 300)"
        return 1
    fi
    case "$n" in ''|null|0) return 0 ;; esac

    _plugin_preseed_load_engine || { _pp_warn "preseed: plugin engine unavailable; skipping"; return 0; }

    _pp_info "Applying plugin preseed (${n} declared)..."
    local i=0 src resolved name env_file ckey cval _pp_installed _pp_written
    while [ "$i" -lt "$n" ]; do
        src="$(yq eval ".plugins[$i].source" "$yaml" 2>/dev/null)"
        case "$src" in ''|null) i=$((i + 1)); continue ;; esac
        resolved="$(_plugin_preseed_resolve_source "$src")"
        if [ -n "$resolved" ]; then
            name="$(_plugin_preseed_name "$resolved")"
        elif printf '%s' "$src" | grep -Eq '^[a-z][a-z0-9-]*$'; then
            # Not local: a published name — plugin_install resolves it from the CDN.
            resolved="$src"; name="$src"
        else
            _pp_warn "preseed: source '${src}' not found (use a path, a bundled name, or a published plugin name)"
            i=$((i + 1)); continue
        fi
        if [ -z "$name" ]; then _pp_warn "preseed: no plugin name in ${resolved}"; i=$((i + 1)); continue; fi
        _pp_installed=0
        if journal_plugin_exists "$name" 2>/dev/null && [ "$(journal_plugin_field "$name" status 2>/dev/null)" = "installed" ]; then
            # Skip the re-install, but still repopulate the declared config below — the
            # install.yaml stays the source of truth on every installer run.
            _pp_info "preseed: '${name}' already installed; refreshing config only"
            _pp_installed=1
        fi
        # Pre-seed the declared config so the first deploy comes up healthy.
        env_file="$(get_plugin_env_file "$name")"
        _pp_written=""
        while IFS= read -r ckey; do
            [ -z "$ckey" ] && continue
            if ! _plugin_preseed_key_ok "$ckey"; then
                _pp_warn "preseed: ignoring invalid/reserved config key '${ckey}' for '${name}'"
                continue
            fi
            cval="$(yq eval ".plugins[$i].config.\"${ckey}\"" "$yaml" 2>/dev/null)"
            case "$cval" in null) cval="" ;; esac
            [ -n "$cval" ] && { plugin_env_set "$env_file" "$ckey" "$cval"; _pp_written="${_pp_written}${ckey}
"; }
        done <<EOF
$(yq eval ".plugins[$i].config | keys | .[]" "$yaml" 2>/dev/null)
EOF
        _pp_mark_respond_choice "$resolved" "$env_file" "$_pp_written"
        if [ "$_pp_installed" = "1" ]; then
            :   # already installed; declared config refreshed above
        elif [ "$mode" = "manual" ]; then
            # Manual mode: repos aren't configured during base install, so the deploy
            # preflight can't pass yet. The declared config is seeded above; the manual
            # runbook already directs the operator to `bitoarch plugin install <name>`
            # (after add-repos), which reuses this seed. Defer the deploy, don't fail.
            type log_silent >/dev/null 2>&1 && log_silent "preseed: '${name}' config seeded; deploy deferred to the manual runbook step"
        elif [ -t 0 ] && [ "${AUTO_SETUP:-}" != "true" ]; then
            # A terminal is attached: run the plugin's setup interactively so any
            # required value NOT preseeded (e.g. Slack app credentials) is prompted
            # for — same behavior as Insights preseed — instead of silently walking
            # the steps and landing pending. Preseeded values are reused, not re-asked.
            plugin_install "$resolved" || _pp_warn "preseed: install failed for '${name}'"
        else
            # Headless/scripted: non-interactive; anything still missing lands pending.
            BITOARCH_NONINTERACTIVE=1 plugin_install "$resolved" || _pp_warn "preseed: install failed for '${name}'"
        fi
        i=$((i + 1))
    done
    return 0
}
export -f plugin_preseed_apply 2>/dev/null || true

# Re-apply install.yaml preseed config values to ALREADY-INSTALLED plugins' env files —
# no source resolution, no install. Wired into `bitoarch restart --force` so live yaml
# edits reach plugin envs the same way apply_install_yaml_to_env_file refreshes the base env.
plugin_preseed_reapply_config() {
    local yaml="${1:-$(get_install_yaml_file 2>/dev/null)}"
    [ -n "$yaml" ] && [ -f "$yaml" ] || return 0
    command -v yq >/dev/null 2>&1 || return 0
    # Same guard as the base env apply (separate marker: the base apply records
    # ITS marker before this fan-out runs): reapply plugin config only when the
    # operator actually edited the yaml, so interactive `plugin config` changes
    # survive a plain `restart --force`.
    local _ps_hash="" _ps_marker="" _ps_cfg=""
    if type _install_yaml_hash >/dev/null 2>&1; then
        _ps_hash="$(_install_yaml_hash "$yaml")"
        _ps_cfg="$(get_config_file 2>/dev/null)"; [ -n "$_ps_cfg" ] || _ps_cfg="$yaml"
        _ps_marker="$(dirname "$_ps_cfg")/.install-yaml.plugins.last-applied"
        if [ -n "$_ps_hash" ] && [ "$_ps_hash" = "$(cat "$_ps_marker" 2>/dev/null)" ]; then
            type log_silent >/dev/null 2>&1 && log_silent "preseed: install.yaml unchanged since last reapply; keeping plugin envs"
            return 0
        fi
    fi
    # A yq parse error must not read as "no plugins declared" — that would skip
    # the operator's entire declarative preseed with no message at all.
    local n _yq_err
    if ! n="$(yq eval '.plugins | length' "$yaml" 2>&1)"; then
        _pp_warn "preseed: cannot parse ${yaml}: $(printf '%s' "$n" | tail -c 300)"
        return 1
    fi
    case "$n" in ''|null|0) return 0 ;; esac
    _plugin_preseed_load_engine || return 0
    local i=0 src resolved name env_file ckey cval _pp_written
    while [ "$i" -lt "$n" ]; do
        src="$(yq eval ".plugins[$i].source" "$yaml" 2>/dev/null)"
        case "$src" in ''|null) i=$((i + 1)); continue ;; esac
        resolved="$(_plugin_preseed_resolve_source "$src")"
        if [ -n "$resolved" ]; then name="$(_plugin_preseed_name "$resolved")"; else name="$src"; fi
        if [ -n "$name" ] && journal_plugin_exists "$name" 2>/dev/null; then
            env_file="$(get_plugin_env_file "$name")"
            _pp_written=""
            while IFS= read -r ckey; do
                [ -z "$ckey" ] && continue
                _plugin_preseed_key_ok "$ckey" || continue
                cval="$(yq eval ".plugins[$i].config.\"${ckey}\"" "$yaml" 2>/dev/null)"
                case "$cval" in null) cval="" ;; esac
                [ -n "$cval" ] && { plugin_env_set "$env_file" "$ckey" "$cval"; _pp_written="${_pp_written}${ckey}
"; }
            done <<EOF
$(yq eval ".plugins[$i].config | keys | .[]" "$yaml" 2>/dev/null)
EOF
            _pp_mark_respond_choice "$resolved" "$env_file" "$_pp_written"
            type log_silent >/dev/null 2>&1 && log_silent "preseed: refreshed '${name}' config from install.yaml (restart --force)"
        fi
        i=$((i + 1))
    done
    if [ -n "$_ps_hash" ] && [ -n "$_ps_marker" ]; then
        printf '%s\n' "$_ps_hash" > "$_ps_marker" 2>>"${LOG_FILE:-/dev/null}" \
            || { type log_silent >/dev/null 2>&1 && log_silent "preseed: could not write ${_ps_marker}; install.yaml config will be re-applied on every restart --force"; }
    fi
    return 0
}
export -f plugin_preseed_reapply_config 2>/dev/null || true

# Offer to install plugins interactively at the end of a base install, via the normal flow; no-op when not at a TTY / scripted.
plugin_offer_interactive_install() {
    [ "${BITOARCH_PLUGIN_FORCE_PROMPT:-}" = "1" ] || [ -t 0 ] || return 0
    [ "${AUTO_SETUP:-}" = "true" ] && return 0
    [ "${BITOARCH_NONINTERACTIVE:-0}" = "1" ] && return 0
    _plugin_preseed_load_engine || return 0
    local ans src
    read -r -p "$(_pm_add_plugin_prompt)" ans || return 0
    case "$ans" in [Yy]*) ;; *) return 0 ;; esac
    while :; do
        read -r -p "$(_pm_plugin_source_prompt)" src || break
        [ -z "$src" ] && break
        plugin_install "$src" || _pp_install_failed_block "$src"
    done
    return 0
}
export -f plugin_offer_interactive_install 2>/dev/null || true

# Offer the bundled catalog interactively: per-plugin Enable? + ONE shared PUBLIC_URL (pre-seeded). rc 1 when catalog empty.
_plugin_offer_from_catalog() {
    [ "${BITOARCH_PLUGIN_FORCE_PROMPT:-}" = "1" ] || [ -t 0 ] || return 0
    [ "${AUTO_SETUP:-}" = "true" ] && return 0
    [ "${BITOARCH_NONINTERACTIVE:-0}" = "1" ] && return 0
    _plugin_preseed_load_engine || return 0
    local catalog; catalog="$(_plugin_catalog_all)"
    [ -n "$catalog" ] || return 1
    # Read the catalog into arrays FIRST so the per-plugin prompts below read fd 0, not the heredoc (input-eating gate, #18).
    local cnames=() cdisps=() cdescs=() name disp desc
    while IFS='|' read -r name disp desc; do
        [ -n "$name" ] && { cnames+=("$name"); cdisps+=("$disp"); cdescs+=("$desc"); }
    done <<EOF
$catalog
EOF
    [ "${#cnames[@]}" -gt 0 ] || return 1
    # Section header in the standard rule/title/rule block format (matches render_indexing_information_block).
    local rule="━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    printf '\n%b%s%b\n' "${BLUE:-}" "$rule" "${NC:-}" >&2
    printf '%b🔌 AI ARCHITECT: PLUGINS%b\n' "${BLUE:-}${BOLD:-}" "${NC:-}" >&2
    printf '%b%s%b\n\n' "${BLUE:-}" "$rule" "${NC:-}" >&2
    printf '   %bOptional — add these anytime with%b %bbitoarch plugin install <name>%b\n' \
        "${DIM:-}" "${NC:-}" "${YELLOW:-}" "${NC:-}" >&2
    printf '   %brun%b %bbitoarch plugin list%b %bto see available names.%b\n' \
        "${DIM:-}" "${NC:-}" "${YELLOW:-}" "${NC:-}" "${DIM:-}" "${NC:-}" >&2
    local i ans chosen=()
    for i in "${!cnames[@]}"; do
        printf '\n   %b%s%b\n' "${BOLD:-}" "${cdisps[$i]}" "${NC:-}" >&2
        [ -n "${cdescs[$i]}" ] && printf '      %b%s%b\n' "${DIM:-}" "${cdescs[$i]}" "${NC:-}" >&2
        printf '   › Enable? [y/N]: ' >&2
        ans=""; read -r ans || break
        case "$ans" in [Yy]*) chosen+=("${cnames[$i]}") ;; esac
    done
    [ "${#chosen[@]}" -gt 0 ] || return 0
    # One shared public URL for every chosen plugin (each reaches the same ingress). Reuse the
    # PUBLIC_URL hint from a chosen plugin's manifest -- the SAME source, parser and port helper
    # the per-plugin prompt uses -- so the guidance matches it exactly instead of a separate copy.
    local shared_url="" _url_hint="" _url_man
    _url_man="$(_plugin_preseed_resolve_source "${chosen[0]}" 2>/dev/null)/plugin.yaml"
    if [ -f "$_url_man" ] && type manifest_config_prompt >/dev/null 2>&1; then
        _url_hint="$(manifest_config_prompt "$_url_man" 2>/dev/null | awk -F'|' '$1=="PUBLIC_URL"{print $3; exit}')"
        _url_hint="${_url_hint//\$\{INGRESS_PORT\}/$(_plugin_ingress_hint_port)}"
    fi
    # CDN catalog entries have no local manifest yet -- fall back to the same hint the
    # plugin manifests carry for config.prompt PUBLIC_URL (kept in sync with them).
    [ -n "$_url_hint" ] || _url_hint="Enter the public HTTPS address of this server (your nginx or load balancer must forward it to port $(_plugin_ingress_hint_port))."
    printf '\n' >&2
    local _url_hl="your nginx or load balancer must forward it to port $(_plugin_ingress_hint_port)"
    printf '   %b\n' "${DIM:-}${_url_hint/$_url_hl/${NC:-}${YELLOW:-}${_url_hl}${NC:-}${DIM:-}}${NC:-}" >&2
    printf '   › Public HTTPS URL for these plugins %b(blank = set later per-plugin)%b: ' "${DIM:-}" "${NC:-}" >&2
    read -r shared_url || true
    # Same URL-shape rule as the per-plugin prompt: free text must not be persisted
    # (it reaches env files the CLI sources). Blank falls back to per-plugin setup.
    if [ -n "$shared_url" ] && type _plugin_public_url_shape_ok >/dev/null 2>&1 \
        && ! _plugin_public_url_shape_ok "$shared_url"; then
        type log_silent >/dev/null 2>&1 && log_silent "plugin preseed: rejected invalid shared PUBLIC_URL (shape check)"
        printf '   %b⚠%b Not a valid URL — must start with http:// or https://\n' \
            "${YELLOW:-}" "${NC:-}" >&2
        shared_url=""
    fi
    local nm dir env_file
    for nm in "${chosen[@]}"; do
        printf '\n' >&2   # blank line between plugins when several install in one run
        dir="$(_plugin_preseed_resolve_source "$nm")"
        [ -n "$dir" ] || dir="$nm"   # remote catalog entry: plugin_install resolves the name from the CDN
        if [ -n "$shared_url" ]; then
            env_file="$(get_plugin_env_file "$nm" 2>/dev/null)"
            if [ -n "$env_file" ]; then
                plugin_env_set "$env_file" PUBLIC_URL "$shared_url" 2>>"${LOG_FILE:-/dev/null}" \
                    || _pp_warn "preseed: could not write PUBLIC_URL for '${name}'; it will install unreachable"
            fi
            type ingress_set_host_from_public_url >/dev/null 2>&1 \
                && ingress_set_host_from_public_url "$shared_url"
        fi
        BITOARCH_PLUGIN_SHARED_SETUP=1 plugin_install "$dir" || _pp_install_failed_block "$nm"
    done
    return 0
}


# Post-base-install phase (from install_run): apply the install.yaml preseed; if none declared, offer interactively in AUTO mode only.
# <mode> is the base SETUP_MODE (auto|manual|failed|""). The interactive offer belongs to AUTO
# mode: manual-mode operators drive setup step by step and add plugins as a documented step
# (render_manual_config_instructions_block lists the command), not via a mid-setup prompt.
plugin_setup_phase() {
    local yaml="${1:-}" mode="${2:-}" n=0
    # Declared plugins (install.yaml) always seed their config; the deploy runs now in
    # auto mode and defers to the operator's runbook step in manual mode (in plugin_preseed_apply).
    plugin_preseed_apply "$yaml" "$mode"
    if [ -f "$yaml" ] && command -v yq >/dev/null 2>&1; then
        # Report a parse error rather than silently reading it as "no plugins
        # declared"; behaviour is unchanged (n=0 still falls through below).
        if ! n="$(yq eval '.plugins | length' "$yaml" 2>&1)"; then
            _pp_warn "preseed: cannot parse ${yaml}: $(printf '%s' "$n" | tail -c 300)"
            n=0
        fi
        case "$n" in ''|null) n=0 ;; esac
    fi
    [ "$n" -gt 0 ] && return 0
    # No declarative preseed: the interactive offer is AUTO-only (manual lists it as a step).
    [ "$mode" = "auto" ] || return 0
    _plugin_offer_from_catalog || plugin_offer_interactive_install
}
export -f plugin_setup_phase 2>/dev/null || true
