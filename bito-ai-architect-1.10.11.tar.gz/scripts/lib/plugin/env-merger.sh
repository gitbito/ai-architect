#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
#
# Env template validation + additive-only merge.

if [ -n "${_BITOARCH_PLUGIN_ENV_MERGER_LOADED:-}" ]; then
    return 0
fi
_BITOARCH_PLUGIN_ENV_MERGER_LOADED=1

_BITOARCH_PLUGIN_ENVM_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if ! type plugin_key_is_reserved >/dev/null 2>&1; then
    # shellcheck source=scripts/lib/plugin/reserved-keys.sh
    . "${_BITOARCH_PLUGIN_ENVM_DIR}/reserved-keys.sh"
fi

_envm_err() {
    if type print_error >/dev/null 2>&1; then print_error "$1" >&2; else printf 'ERROR: %s\n' "$1" >&2; fi
    type log_silent >/dev/null 2>&1 && log_silent "env merger: $1"
}

plugin_env_validate_template() {
    local tpl="$1" line key bad=0
    if [ ! -f "$tpl" ]; then
        _envm_err "env template not found: $tpl"
        return 1
    fi
    while IFS= read -r line || [ -n "$line" ]; do
        case "$line" in
            ''|\#*) continue ;;
            [A-Za-z_]*=*) key="${line%%=*}"; case "$key" in *[!A-Za-z0-9_]*) continue ;; esac ;;
            *) continue ;;
        esac
        if plugin_key_is_reserved "$key"; then
            _envm_err "env template declares reserved base key '${key}' (${tpl}); a plugin may not override base infrastructure values"
            bad=1
        fi
    done < "$tpl"
    [ "$bad" -eq 0 ]
}

plugin_env_merge() {
    local dst="$1" tpl="$2" line key added=0
    plugin_env_validate_template "$tpl" || return 1

    if [ ! -f "$dst" ]; then
        mkdir -p "$(dirname "$dst")" 2>/dev/null || true
        ( umask 077; : > "$dst" )
    fi
    chmod 600 "$dst" 2>/dev/null || true

    while IFS= read -r line || [ -n "$line" ]; do
        case "$line" in
            ''|\#*) continue ;;
            [A-Za-z_]*=*) key="${line%%=*}"; case "$key" in *[!A-Za-z0-9_]*) continue ;; esac ;;
            *) continue ;;
        esac
        if ! cut -d= -f1 "$dst" 2>/dev/null | grep -qxF -- "$key"; then
            printf '%s\n' "$line" >> "$dst"
            added=$((added + 1))
        fi
    done < "$tpl"

    type log_silent >/dev/null 2>&1 && log_silent "env merger: added ${added} new key(s) into ${dst}"
    return 0
}

# In-network cis-config wiring for plugin services. Docker's compose fragments
# fall back at interpolation time (CIS_CONFIG_TOKEN:-BITO_API_KEY etc.), but the
# k8s chart passes the plugin env verbatim -- so the ENGINE fills the same
# values into the env file and both runtimes see identical wiring. Only keys
# the plugin's env template DECLARES (present and empty) are filled; an
# operator-set value is never overwritten.
plugin_inject_config_env() {   # <plugin-env-file>
    local pf="$1"
    [ -n "$pf" ] && [ -f "$pf" ] || return 0
    local host token cur
    host="http://ai-architect-config:${CIS_CONFIG_PORT:-8081}"
    token="$(plugin_shared_cred "$pf" BITO_API_KEY 2>/dev/null)"
    if grep -q '^CIS_CONFIG_HOST=' "$pf" 2>/dev/null; then
        cur="$(plugin_env_get "$pf" CIS_CONFIG_HOST 2>/dev/null)"
        [ -z "$cur" ] && plugin_env_set "$pf" CIS_CONFIG_HOST "$host"
    fi
    if grep -q '^CIS_CONFIG_TOKEN=' "$pf" 2>/dev/null; then
        cur="$(plugin_env_get "$pf" CIS_CONFIG_TOKEN 2>/dev/null)"
        [ -z "$cur" ] && [ -n "$token" ] && plugin_env_set "$pf" CIS_CONFIG_TOKEN "$token"
    fi
    return 0
}

# PUBLIC_URL must be a URL, not free text: scheme + host, no whitespace. Free text
# would be persisted into env files the CLI sources at startup, where stray words
# execute as commands and kill every later invocation. Shared by every entry point
# (install prompt, preseed shared prompt, headless gate, plugin config --set).
# Shape-only: the reachability probe (_plugin_public_url_ok) is a different check.
_plugin_public_url_shape_ok() {
    case "$1" in
        *[[:space:]]*) return 1 ;;
        http://?*|https://?*) return 0 ;;
        *) return 1 ;;
    esac
}

# Pass key/value via ENVIRON so awk writes them literally (no regex/escape).
# Returns non-zero when the key was NOT written. Every caller that reports
# success to the user must check this: a silent no-op here means the plugin runs
# with missing or stale configuration while the operator is told it was applied.
plugin_env_set() {
    local file="$1" key="$2" value="$3"
    local _log="${LOG_FILE:-/dev/null}"
    if [ ! -f "$file" ]; then
        if ! mkdir -p "$(dirname "$file")" 2>>"$_log"; then
            _envm_err "cannot create $(dirname "$file") to write ${key}"
            return 1
        fi
        if ! ( umask 077; : > "$file" ) 2>>"$_log"; then
            _envm_err "cannot create ${file} to write ${key}"
            return 1
        fi
    fi
    chmod 600 "$file" 2>/dev/null || _envm_err "warning: could not chmod 600 ${file} (it holds plugin credentials)"
    local tmp
    if ! tmp="$(mktemp 2>>"$_log")"; then
        _envm_err "mktemp failed while writing ${key} to ${file}"
        return 1
    fi
    if ! PLUGIN_ENV_KEY="$key" PLUGIN_ENV_VALUE="$value" awk '
        BEGIN { k = ENVIRON["PLUGIN_ENV_KEY"]; v = ENVIRON["PLUGIN_ENV_VALUE"]; replaced = 0 }
        index($0, k "=") == 1 { if (!replaced) { print k "=" v; replaced = 1 } ; next }
        { print }
        END { if (!replaced) print k "=" v }
    ' "$file" > "$tmp" 2>>"$_log"; then
        rm -f "$tmp"
        _envm_err "could not render ${key} into ${file}"
        return 1
    fi
    if ! cat "$tmp" > "$file" 2>>"$_log"; then
        rm -f "$tmp"
        _envm_err "could not write ${key} to ${file}"
        return 1
    fi
    rm -f "$tmp"
    return 0
}

plugin_env_get() {
    local file="$1" key="$2"
    [ -f "$file" ] || return 0
    PLUGIN_ENV_KEY="$key" awk '
        BEGIN { k = ENVIRON["PLUGIN_ENV_KEY"] }
        index($0, k "=") == 1 { print substr($0, length(k) + 2); exit }
    ' "$file" 2>/dev/null
}

# Resolve a base-shared credential for a host-side hook: plugin env first, else the base .env-bitoarch.
plugin_shared_cred() {   # <plugin-env-file> <KEY>
    local v; v="$(plugin_env_get "$1" "$2" 2>/dev/null)"
    if [ -z "$v" ] && type get_config_file >/dev/null 2>&1; then
        local base; base="$(get_config_file 2>/dev/null)"
        [ -n "$base" ] && [ -f "$base" ] && v="$(plugin_env_get "$base" "$2" 2>/dev/null)"
    fi
    printf '%s' "$v"
}

# Copy one key (+ optional url key) from the base LLM file into the plugin env, remapping the name; empty source -> skip.
_pl_llm_map() {   # <plugin-env-file> <llm-file> <srcKey> <dstKey> [<srcUrl> <dstUrl>]
    local pf="$1" lf="$2" sk="$3" dk="$4" su="${5:-}" du="${6:-}" v
    v="$(plugin_env_get "$lf" "$sk" 2>/dev/null)"; [ -n "$v" ] && plugin_env_set "$pf" "$dk" "$v"
    [ -n "$su" ] && { v="$(plugin_env_get "$lf" "$su" 2>/dev/null)"; [ -n "$v" ] && plugin_env_set "$pf" "$du" "$v"; }
}

# Inherit the base LLM choice (.env-llm-bitoarch) into a plugin's env, remapping to the wingman consumer var names.
# Fail-safe + idempotent: no base LLM file -> no-op. BYOK passthrough covers anthropic/openai/portkey only.
plugin_inherit_llm() {   # <plugin-env-file>
    local pf="$1" lf provider
    [ -n "$pf" ] || return 0
    type get_llm_config_file >/dev/null 2>&1 || return 0
    lf="$(get_llm_config_file 2>/dev/null)"
    [ -n "$lf" ] && [ -f "$lf" ] || return 0   # no base LLM config -> leave the plugin default

    provider="$(plugin_env_get "$lf" LLM_DEFAULT_PROVIDER 2>/dev/null)"
    [ -n "$provider" ] || provider="bito"
    plugin_env_set "$pf" WINGMAN_LLM_DEFAULT_PROVIDER "$provider"
    plugin_env_set "$pf" COMPLEXITY_LLM_DEFAULT_PROVIDER "$provider"

    case "$provider" in
        anthropic) _pl_llm_map "$pf" "$lf" ANTHROPIC_API_TOKEN ANTHROPIC_API_KEY ANTHROPIC_API_URL ANTHROPIC_API_URL ;;
        openai)    _pl_llm_map "$pf" "$lf" OPENAI_API_TOKEN    OPENAI_API_KEY    OPENAI_API_URL    OPENAI_API_URL ;;
        portkey)   _pl_llm_map "$pf" "$lf" PORTKEY_API_TOKEN   PORTKEY_API_KEY   PORTKEY_API_URL   PORTKEY_API_URL ;;
    esac
    type log_silent >/dev/null 2>&1 && log_silent "plugin: inherited base LLM provider '${provider}' into $(basename "$pf")"
    return 0
}

# Generate the plugin's Helm values file from its own .env-bitoarch.
plugin_env_k8s_values() {
    local name="$1" out="$2" env_file
    env_file="$(get_plugin_env_file "$name" 2>>"${LOG_FILE:-/dev/null}")"
    # Refuse to render rather than fall through to /dev/null: an unresolved env
    # file would emit `env: {}` and helm would bring the plugin up with ZERO
    # configuration, reported as a successful deploy.
    if [ -z "$env_file" ] || [ ! -f "$env_file" ]; then
        _envm_err "no env file resolved for plugin '${name}'; refusing to render empty helm values"
        return 1
    fi
    mkdir -p "$(dirname "$out")" 2>/dev/null || true
    local tmp; tmp="$(mktemp)" || return 1
    awk '
        BEGIN {
            print "# Generated from the plugin .env-bitoarch by the AI Architect plugin framework."
            print "# Plugin-owned config injected as .Values.env; base config comes from the named base ConfigMap."
            n = 0; buf = ""
        }
        /^[ \t]*#/ { next }
        /^[ \t]*$/ { next }
        /^[A-Za-z_][A-Za-z0-9_]*=/ {
            eq = index($0, "="); k = substr($0, 1, eq - 1); v = substr($0, eq + 1)
            gsub(/\\/, "\\\\", v); gsub(/"/, "\\\"", v)
            buf = buf "  " k ": \"" v "\"\n"; n++
        }
        END {
            if (n == 0) { print "env: {}" } else { print "env:"; printf "%s", buf }
        }
    ' "$env_file" 2>>"${LOG_FILE:-/dev/null}" > "$tmp" || { rm -f "$tmp"; _envm_err "could not render helm values from ${env_file}"; return 1; }
    # Inherit the base ingress class/host (one shared front door). Routes come
    # from the MANIFEST (the same single source the docker ingress reads) so
    # the two runtimes can never drift; a values-file list fully replaces the
    # chart's default list. enabled/tls stay from the chart.
    {
        printf 'ingress:\n'
        printf '  className: "%s"\n' "${BITOARCH_INGRESS_CLASS:-ai-architect-nginx}"
        printf '  host: "%s"\n' "${BITOARCH_INGRESS_HOST:-}"
        local _man _routes
        _man="$(get_plugin_install_dir "$name" 2>/dev/null)/plugin.yaml"
        if type manifest_routes >/dev/null 2>&1 && [ -f "$_man" ]; then
            _routes="$(manifest_routes "$_man" 2>/dev/null)"
            if [ -n "$_routes" ]; then
                printf '  routes:\n'
                local _rp _rh _rport
                while IFS='|' read -r _rp _rh _rport; do
                    [ -n "$_rp" ] || continue
                    printf '    - path: %s\n      service: %s\n      port: %s\n' "$_rp" "$_rh" "$_rport"
                done <<ROUTES
$_routes
ROUTES
            fi
        fi
    } >> "$tmp"
    ( umask 077; cat "$tmp" > "$out" ) || { rm -f "$tmp"; return 1; }
    rm -f "$tmp"
    chmod 600 "$out" 2>/dev/null || true
    type log_silent >/dev/null 2>&1 && log_silent "env merger: generated k8s values for plugin '${name}' -> ${out}"
    return 0
}
