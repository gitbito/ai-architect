#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
#
# Shared dependency-pack manager (ref-counted, keyed by capability).

if [ -n "${_BITOARCH_PLUGIN_DEP_MANAGER_LOADED:-}" ]; then
    return 0
fi
_BITOARCH_PLUGIN_DEP_MANAGER_LOADED=1

_BITOARCH_PLUGIN_DEP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if ! type journal_pack_incref >/dev/null 2>&1; then
    # shellcheck source=/dev/null
    . "${_BITOARCH_PLUGIN_DEP_DIR}/state-journal.sh"
fi
if ! type plugin_version_satisfies >/dev/null 2>&1; then
    # shellcheck source=/dev/null
    . "${_BITOARCH_PLUGIN_DEP_DIR}/manifest-parser.sh"
fi

_dep_err() {
    if type print_error >/dev/null 2>&1; then print_error "$1" >&2; else printf 'ERROR: %s\n' "$1" >&2; fi
    type log_silent >/dev/null 2>&1 && log_silent "dependency manager: $1"
}
_dep_log()  { type log_silent >/dev/null 2>&1 && log_silent "dependency manager: $1"; }
# Redirect target for the kubectl/compose calls below. Never /dev/null: a
# mutation that fails must leave its reason somewhere, so stderr is the floor.
_dep_log_target() {
    # Delegate to the single resolver in path-manager.sh: a local copy drifted on the
    # fallback tier and skipped the writability check, so an unwritable target made
    # bash skip the command it was logging instead of falling back.
    # stderr stays the floor for the case where path-manager was never sourced.
    if command -v bitoarch_resolve_log_file >/dev/null 2>&1; then
        bitoarch_resolve_log_file
        return 0
    fi
    printf '%s' "/dev/stderr"
}
_dep_info() { if type print_info   >/dev/null 2>&1; then print_info "$1";   else printf '%s\n' "$1"; fi; }
_dep_ok()   { if type print_status >/dev/null 2>&1; then print_status "$1"; else printf '%s\n' "$1"; fi; }

# Canonical compose-cmd resolver (compose v1 + v2) lives in compose-cmd.sh;
# literal fallback keeps this module usable if the sibling source fails.
if ! type _plugin_compose_cmd >/dev/null 2>&1; then
    # shellcheck source=scripts/lib/plugin/compose-cmd.sh
    . "${_BITOARCH_PLUGIN_DEP_DIR}/compose-cmd.sh" 2>/dev/null || true
fi
if ! type _plugin_compose_cmd >/dev/null 2>&1; then
    _plugin_compose_cmd() { printf 'docker compose'; }
fi

# --wait is Compose V2.1.1+ (the "docker compose" form has a space); V1
# (docker-compose) rejects it, so echo the flag only for the V2 form.
_dep_compose_wait_flag() { case "$1" in *" "*) printf '%s' "--wait" ;; *) printf '' ;; esac; }

# BITOARCH_PLUGIN_PACKS_DIR overrides the built-in catalogue (air-gap/tests).
_dep_packs_dir() { echo "${BITOARCH_PLUGIN_PACKS_DIR:-${_BITOARCH_PLUGIN_DEP_DIR}/packs}"; }

# Read KEY=value from a descriptor file (literal; not sourced).
_dep_desc_read() { sed -n "s/^$2=//p" "$1" 2>/dev/null | head -1; }

_dep_descriptor() {
    local cap="$1" d
    for d in "$(_dep_packs_dir)"/*/pack.descriptor; do
        [ -f "$d" ] || continue
        [ "$(_dep_desc_read "$d" PACK_CAPABILITY)" = "$cap" ] && { printf '%s' "$d"; return 0; }
    done
    return 1
}

_dep_field() {
    local d; d="$(_dep_descriptor "$1")" || return 1
    _dep_desc_read "$d" "$2"
}

_dep_capabilities() {
    local d caps=""
    for d in "$(_dep_packs_dir)"/*/pack.descriptor; do
        [ -f "$d" ] || continue
        caps="${caps} $(_dep_desc_read "$d" PACK_CAPABILITY)"
    done
    printf '%s' "${caps# }"
}

_dep_valid_cap() { _dep_descriptor "$1" >/dev/null 2>&1; }

# Operator env override, else descriptor default.
_dep_port() {
    local cap="$1" penv pdef val=""
    penv="$(_dep_field "$cap" PACK_PORT_ENV)"
    pdef="$(_dep_field "$cap" PACK_PORT_DEFAULT)"
    [ -n "$penv" ] && val="$(printenv "$penv" 2>/dev/null)"
    [ -n "$val" ] && printf '%s' "$val" || printf '%s' "$pdef"
}

dep_pack_installed() {
    [ "$(journal_pack_get "$1" 2>/dev/null | jq -r '.status // ""' 2>/dev/null)" = "installed" ]
}

_dep_run() {
    local label="$1"; shift
    if type progress_run >/dev/null 2>&1; then
        progress_run "$label" -- "$@"
        return $?
    fi
    "$@" >>"$(_dep_log_target)" 2>&1
}

_dep_deploy_pack() {
    local cap="$1" deploy impl image release port penv ns chart frag
    deploy="$(get_deployment_type 2>/dev/null || echo docker-compose)"
    local cc; cc="$(_plugin_compose_cmd)"
    impl="$(_dep_field "$cap" PACK_IMPL)"
    image="$(_dep_field "$cap" PACK_IMAGE)"
    release="$(_dep_field "$cap" PACK_RELEASE)"
    penv="$(_dep_field "$cap" PACK_PORT_ENV)"
    port="$(_dep_port "$cap")"
    if [ "$deploy" = "kubernetes" ]; then
        ns="${BITOARCH_K8S_NAMESPACE:-bito-ai-architect}"
        chart="$(_dep_packs_dir)/${impl}/chart"
        _dep_run "Provisioning ${impl} pack (${cap})" \
            helm upgrade --install "$release" "$chart" --namespace "$ns" \
            --set image="$image" --set port="$port" --wait
        # helm's three-way merge won't revert a kubectl-scale drift when the chart is
        # unchanged — a pack stopped via `bitoarch stop` (scaled to 0) must come back.
        kubectl scale deployment "$release" -n "$ns" --replicas=1 >>"$(_dep_log_target)" 2>&1 \
            || _dep_log "could not scale pack ${release} back to 1 replica; dependent plugins may not connect"
    else
        frag="$(_dep_packs_dir)/${impl}/compose.yml"
        local wait_flag; wait_flag="$(_dep_compose_wait_flag "$cc")"
        local net; net="$(type get_ai_architect_network >/dev/null 2>&1 && get_ai_architect_network || echo ai-architect-network)"
        # Subshell-scope the env compose.yml interpolates, so it doesn't leak.
        ( export PACK_IMAGE="$image"; export "${penv}=${port}"; export AI_ARCHITECT_NETWORK="$net"; \
          _dep_run "Provisioning ${impl} pack (${cap})" $cc -p "$release" -f "$frag" up -d $wait_flag --quiet-pull )
    fi
}

# Stop (not remove) a pack's containers; `bitoarch start` revives them via
# dep_pack_provision's idempotent `up -d` (dep_resolve_requires runs per plugin start).
_dep_stop_pack() {
    local cap="$1" deploy impl release ns frag
    deploy="$(get_deployment_type 2>/dev/null || echo docker-compose)"
    local cc; cc="$(_plugin_compose_cmd)"
    impl="$(_dep_field "$cap" PACK_IMPL)"
    release="$(_dep_field "$cap" PACK_RELEASE)"
    if [ "$deploy" = "kubernetes" ]; then
        # Pack charts don't stamp the instance label; the Deployment NAME equals the release.
        ns="${BITOARCH_K8S_NAMESPACE:-bito-ai-architect}"
        kubectl scale deployment "$release" -n "$ns" --replicas=0 2>>"$(_dep_log_target)"
    else
        local image penv port
        image="$(_dep_field "$cap" PACK_IMAGE)"
        penv="$(_dep_field "$cap" PACK_PORT_ENV)"
        port="$(_dep_port "$cap")"
        frag="$(_dep_packs_dir)/${impl}/compose.yml"
        local net; net="$(type get_ai_architect_network >/dev/null 2>&1 && get_ai_architect_network || echo ai-architect-network)"
        ( export PACK_IMAGE="$image"; export "${penv}=${port}"; export AI_ARCHITECT_NETWORK="$net"; \
          _dep_run "Stopping ${impl} pack (${cap})" $cc -p "$release" -f "$frag" stop )
    fi
}

# Restart a pack's runtime in place (bitoarch restart fan-out). k8s: rollout
# restart is a template patch, so a pack scaled to 0 by `bitoarch stop` stays stopped.
_dep_restart_pack() {
    local cap="$1" deploy impl release ns frag
    deploy="$(get_deployment_type 2>/dev/null || echo docker-compose)"
    local cc; cc="$(_plugin_compose_cmd)"
    impl="$(_dep_field "$cap" PACK_IMPL)"
    release="$(_dep_field "$cap" PACK_RELEASE)"
    if [ "$deploy" = "kubernetes" ]; then
        ns="${BITOARCH_K8S_NAMESPACE:-bito-ai-architect}"
        kubectl rollout restart deployment "$release" -n "$ns" >>"$(_dep_log_target)" 2>&1
    else
        local image penv port
        image="$(_dep_field "$cap" PACK_IMAGE)"
        penv="$(_dep_field "$cap" PACK_PORT_ENV)"
        port="$(_dep_port "$cap")"
        frag="$(_dep_packs_dir)/${impl}/compose.yml"
        local net; net="$(type get_ai_architect_network >/dev/null 2>&1 && get_ai_architect_network || echo ai-architect-network)"
        ( export PACK_IMAGE="$image"; export "${penv}=${port}"; export AI_ARCHITECT_NETWORK="$net"; \
          _dep_run "Restarting ${impl} pack (${cap})" $cc -p "$release" -f "$frag" restart )
    fi
}

_dep_teardown_pack() {   # <cap> [--purge]  (--purge also removes the pack's fixed-name data volume)
    local cap="$1" purge="${2:-}" deploy impl release ns frag
    deploy="$(get_deployment_type 2>/dev/null || echo docker-compose)"
    local cc; cc="$(_plugin_compose_cmd)"
    impl="$(_dep_field "$cap" PACK_IMPL)"
    release="$(_dep_field "$cap" PACK_RELEASE)"
    if [ "$deploy" = "kubernetes" ]; then
        ns="${BITOARCH_K8S_NAMESPACE:-bito-ai-architect}"
        # Callers gate on this rc (lifecycle.sh logs "removed" vs "FAILED to remove",
        # and sets _lc_pack_failed only on non-zero), so a hard `return 0` here made
        # every k8s teardown report a clean removal even when helm failed.
        local _td_rc=0
        _dep_run "Removing ${impl} pack (${cap})" helm uninstall "$release" --namespace "$ns" || _td_rc=$?
        # helm uninstall leaves PVCs by design; a purge must also drop the pack's data
        # claim (named after the release in the pack chart).
        if [ "$purge" = "--purge" ]; then
            kubectl delete pvc "$release" -n "$ns" --ignore-not-found >>"$(_dep_log_target)" 2>&1 \
                || { _td_rc=1; _dep_log "could not delete pvc ${release}; the pack's data claim remains"; }
        fi
        return "$_td_rc"
    else
        local image penv port vflag=""
        [ "$purge" = "--purge" ] && vflag="-v"
        image="$(_dep_field "$cap" PACK_IMAGE)"
        penv="$(_dep_field "$cap" PACK_PORT_ENV)"
        port="$(_dep_port "$cap")"
        frag="$(_dep_packs_dir)/${impl}/compose.yml"
        local net; net="$(type get_ai_architect_network >/dev/null 2>&1 && get_ai_architect_network || echo ai-architect-network)"
        # PACK_IMAGE must be set or `down` errors and orphans the pack container.
        ( export PACK_IMAGE="$image"; export "${penv}=${port}"; export AI_ARCHITECT_NETWORK="$net"; \
          _dep_run "Removing ${impl} pack (${cap})" $cc -p "$release" -f "$frag" down $vflag )
    fi
}

dep_pack_provision() {
    local cap="$1" impl ver release
    if ! _dep_valid_cap "$cap"; then
        _dep_err "unknown capability '${cap}' (supported: $(_dep_capabilities))"
        return 1
    fi
    impl="$(_dep_field "$cap" PACK_IMPL)"
    ver="$(_dep_field "$cap" PACK_VERSION)"
    release="$(_dep_field "$cap" PACK_RELEASE)"
    # Reconcile runtime state every call: compose `up -d` is idempotent and restarts a
    # lost container; journal state alone isn't proof the pack is running.
    _dep_log "ensuring capability '${cap}' (pack ${impl} ${ver})"
    if ! _dep_deploy_pack "$cap"; then
        _dep_err "failed to deploy the ${impl} pack for capability '${cap}'"
        return 1
    fi
    # Record it the first time; afterwards refresh the descriptor-derived fields so
    # the journal tracks reality (release/impl/version can change across builds).
    if ! dep_pack_installed "$cap"; then
        journal_pack_put "$cap" "$(jq -n \
            --arg cap "$cap" --arg impl "$impl" --arg v "$ver" --arg r "$release" \
            '{capability:$cap, pack:$impl, version:$v, status:"installed", helm_release:$r, required_by:[], health:"unknown"}')"
    else
        _journal_mutate '.dependency_packs[$c].pack=$i | .dependency_packs[$c].version=$v | .dependency_packs[$c].helm_release=$r' \
            --arg c "$cap" --arg i "$impl" --arg v "$ver" --arg r "$release"
    fi
}

# Prints the space-separated capabilities it incref'd, for rollback.
dep_resolve_requires() {
    local manifest="$1" plugin="$2" cap constraint installed_ver resolved=""
    while IFS= read -r cap; do
        [ -z "$cap" ] && continue
        if ! _dep_valid_cap "$cap"; then
            _dep_err "plugin requires unknown capability '${cap}' (supported: $(_dep_capabilities))"
            printf '%s' "${resolved# }"; return 1
        fi
        constraint="$(manifest_pack_version "$manifest" "$cap")"
        if [ -n "$constraint" ] && dep_pack_installed "$cap"; then
            installed_ver="$(journal_pack_get "$cap" | jq -r '.version // ""' 2>/dev/null)"
            if ! plugin_version_satisfies "$installed_ver" "$constraint"; then
                _dep_err "plugin requires ${cap} ${constraint}, but the installed pack ($(_dep_field "$cap" PACK_IMPL)) is ${installed_ver}. Upgrade the shared pack first, then retry."
                printf '%s' "${resolved# }"; return 1
            fi
        fi
        if ! dep_pack_provision "$cap"; then printf '%s' "${resolved# }"; return 1; fi
        if ! journal_pack_incref "$cap" "$plugin"; then printf '%s' "${resolved# }"; return 1; fi
        resolved="${resolved} ${cap}"
    done <<EOF
$(manifest_capabilities "$manifest")
EOF
    printf '%s' "${resolved# }"
}

# Drops this plugin's pack refs; tears down any pack left unreferenced (best-effort).
dep_release_requires() {
    local plugin="$1" cap
    while IFS= read -r cap; do
        [ -z "$cap" ] && continue
        if journal_pack_required_by "$cap" | grep -qx "$plugin"; then
            journal_pack_decref "$cap" "$plugin"
            _dep_log "released capability '${cap}' for plugin '${plugin}'"
            # Orphaned pack (refcount 0) -> best-effort teardown; non-fatal, re-provisioned on next need.
            if [ "$(journal_pack_refcount "$cap" 2>/dev/null || echo 0)" = "0" ]; then
                if _dep_teardown_pack "$cap" 2>/dev/null; then
                    journal_pack_remove "$cap" 2>/dev/null || true
                    _dep_log "removed orphaned shared pack '${cap}' (no plugin requires it)"
                else
                    _dep_log "could not tear down orphaned pack '${cap}'; left running"
                fi
            fi
        fi
    done <<EOF
$(journal_list_packs)
EOF
}

deps_list() {
    local caps c impl ver refs reqby
    caps="$(journal_list_packs)"
    if [ -z "$caps" ]; then
        _dep_info "No shared dependency packs provisioned."
        return 0
    fi
    printf '%b%-14s %-18s %-10s %-10s %s%b\n' "${BOLD:-}" "CAPABILITY" "PACK" "VERSION" "REF-COUNT" "REQUIRED BY" "${NC:-}"
    while IFS= read -r c; do
        [ -z "$c" ] && continue
        impl="$(journal_pack_get "$c" | jq -r '.pack // "?"' 2>/dev/null)"
        ver="$(journal_pack_get "$c" | jq -r '.version // "?"' 2>/dev/null)"
        refs="$(journal_pack_refcount "$c")"
        reqby="$(journal_pack_required_by "$c" | tr '\n' ',' | sed 's/,$//; s/,/, /g')"
        printf '%-14s %-18s %-10s %-10s %s\n' "$c" "$impl" "$ver" "${refs:-0}" "${reqby:--}"
    done <<EOF
$caps
EOF
}

deps_install() {
    local cap="$1"
    if ! _dep_valid_cap "$cap"; then
        _dep_err "unknown capability '${cap}' (supported: $(_dep_capabilities))"
        return 1
    fi
    dep_pack_provision "$cap"
}

deps_uninstall_if_unused() {
    local cap="$1" refs
    if ! _dep_valid_cap "$cap"; then
        _dep_err "unknown capability '${cap}' (supported: $(_dep_capabilities))"
        return 1
    fi
    if ! dep_pack_installed "$cap"; then
        _dep_info "Capability '${cap}' is not provisioned."
        return 0
    fi
    refs="$(journal_pack_refcount "$cap")"
    if [ "${refs:-0}" -gt 0 ]; then
        _dep_err "refusing to remove '${cap}': still required by $(journal_pack_required_by "$cap" | tr '\n' ' ')(ref-count ${refs}). Uninstall those plugins first."
        return 1
    fi
    if ! _dep_teardown_pack "$cap"; then
        _dep_err "failed to tear down the pack for capability '${cap}'"
        return 1
    fi
    journal_pack_remove "$cap"
    _dep_ok "Removed the shared pack backing capability '${cap}'."
}
