#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
# scripts/lib/worker-memory.sh
# cis-worker memory sizing shared by env-generator (compose env) and
# values-generator (Helm values): the shipped defaults, unit parsing, and the
# consistency checks behind operator warnings.
#
# The platform never rewrites an operator's memory or heap values — it warns
# when they can't work together and names the keys to change. Enforcement
# lives in cis-worker itself, which clamps an over-sized Node heap at runtime
# against the live cgroup.

# Prevent multiple sourcing
if [ -n "${_BITOARCH_WORKER_MEMORY_LOADED:-}" ]; then
    return 0
fi
_BITOARCH_WORKER_MEMORY_LOADED=1

# One flat default, deliberately not host-scaled: it covers the large majority
# of deployments, and bigger installs raise it explicitly (install.yaml
# resources or .env-bitoarch). Must match the docker-compose.yml fallback and
# .env-bitoarch.default.
#
# Sized so the shipped Node heap (CIS_MODULE_BASIC_INDEX_NODE_HEAP_MB=5120) fits
# under the runtime ceiling (limit - headroom) without being trimmed: at 7g the
# ceiling is 5376MB >= 5120. Anything smaller (5g/6g) would clamp the default
# heap on every run, so 7g is the floor for a self-consistent default pairing.
WORKER_MEMORY_DEFAULT_LIMIT="7g"
# Kubernetes pod request (not operator-facing): fixed and small so a default
# install stays schedulable on the documented minimum cluster. The limit is
# the single operator knob.
WORKER_MEMORY_K8S_REQUEST="1g"

# mem_to_mb VALUE
# Compose ("2g", "512m", "1024k", bare bytes) or Kubernetes ("2Gi", "512Mi")
# memory string -> integer MB on stdout. Unparseable input prints nothing and
# returns 1 so callers can fall back to their own default.
mem_to_mb() {
    local raw="$1" num unit
    num=$(printf '%s' "$raw" | sed -n 's/^[[:space:]]*\([0-9][0-9]*\)[[:space:]]*\([A-Za-z]*\)[[:space:]]*$/\1/p')
    unit=$(printf '%s' "$raw" | sed -n 's/^[[:space:]]*\([0-9][0-9]*\)[[:space:]]*\([A-Za-z]*\)[[:space:]]*$/\2/p' | tr '[:upper:]' '[:lower:]')
    [ -z "$num" ] && return 1
    local mb
    # Sub-MB units are rejected unless they divide exactly: integer division
    # would round 1536k down to 1MB and hand a caller a container limit three
    # orders of magnitude below what was written. Rejecting sends the caller to
    # its documented default instead, which the misfit warnings then surface.
    case "$unit" in
        g|gb|gi) mb=$((num * 1024)) ;;
        m|mb|mi) mb=$num ;;
        k|kb|ki) [ $((num % 1024)) -eq 0 ] || return 1
                 mb=$((num / 1024)) ;;
        # Bare numbers are bytes in both compose and Kubernetes.
        ''|b)    [ $((num % (1024 * 1024))) -eq 0 ] || return 1
                 mb=$((num / 1024 / 1024)) ;;
        *)       return 1 ;;
    esac
    # A sub-1MB result can only come from a nonsense value; treat as unparseable.
    [ "$mb" -lt 1 ] && return 1
    echo "$mb"
}

# mem_mb_to_k8s_quantity MB -> "NGi" when it divides evenly, else "NMi".
mem_mb_to_k8s_quantity() {
    local mb="$1"
    if [ $((mb % 1024)) -eq 0 ]; then
        echo "$((mb / 1024))Gi"
    else
        echo "${mb}Mi"
    fi
}

# resolve_worker_k8s_memory LIMIT_VALUE
# Resolves the pod resource pair from the single operator-facing limit.
# Prints "<limit-quantity> <request-quantity>" (e.g. "12Gi 1Gi"). An
# unparseable limit falls back to the shipped default; the fixed request is
# lowered to the limit when the limit is smaller, since Kubernetes rejects
# request > limit.
resolve_worker_k8s_memory() {
    local limit_raw="$1" limit_mb request_mb
    limit_mb=$(mem_to_mb "${limit_raw:-$WORKER_MEMORY_DEFAULT_LIMIT}") \
        || limit_mb=$(mem_to_mb "$WORKER_MEMORY_DEFAULT_LIMIT")
    request_mb=$(mem_to_mb "$WORKER_MEMORY_K8S_REQUEST")
    if [ "$request_mb" -gt "$limit_mb" ]; then
        request_mb="$limit_mb"
    fi
    echo "$(mem_mb_to_k8s_quantity "$limit_mb") $(mem_mb_to_k8s_quantity "$request_mb")"
}

# worker_heap_exceeds_limit LIMIT_VALUE HEAP_MB
# True (0) when the declared Node heap is larger than the whole worker
# container — a pairing that can never work and deserves a warning. The
# shipped default (heap equal to the limit) is fine: the worker reserves its
# own headroom at runtime.
worker_heap_exceeds_limit() {
    local limit_raw="$1" heap_mb="$2" limit_mb
    case "$heap_mb" in ''|*[!0-9]*) return 1 ;; esac
    limit_mb=$(mem_to_mb "$limit_raw") || return 1
    [ "$heap_mb" -gt "$limit_mb" ]
}

# Headroom the worker container keeps for everything that is not the Node heap:
# the Go worker process (all task queues), the zoekt/ctags/git subprocesses, and
# Node's own non-heap memory. MUST stay in lockstep with cis-manager
# internal/services/xmcp_indexer.go (heapHeadroomFloorMB / heapHeadroomPercent),
# which does the actual runtime clamp; these values only decide when to warn.
WORKER_HEAP_HEADROOM_FLOOR_MB=1024
WORKER_HEAP_HEADROOM_PERCENT=25

# worker_heap_ceiling_mb LIMIT_VALUE
# The largest Node heap the container can back: limit - max(percent, floor).
# Prints the ceiling in MB; returns 1 on an unparseable limit or a non-positive
# ceiling (a limit at/below the floor).
worker_heap_ceiling_mb() {
    local limit_raw="$1" limit_mb headroom_mb ceiling_mb
    limit_mb=$(mem_to_mb "$limit_raw") || return 1
    headroom_mb=$(( limit_mb * WORKER_HEAP_HEADROOM_PERCENT / 100 ))
    [ "$headroom_mb" -lt "$WORKER_HEAP_HEADROOM_FLOOR_MB" ] && headroom_mb=$WORKER_HEAP_HEADROOM_FLOOR_MB
    ceiling_mb=$(( limit_mb - headroom_mb ))
    [ "$ceiling_mb" -le 0 ] && return 1
    echo "$ceiling_mb"
}

# worker_heap_exceeds_ceiling LIMIT_VALUE HEAP_MB
# True (0) when the heap is larger than what the container can back once
# headroom is reserved — the worker trims it at runtime, so this is the pairing
# to warn about. A heap at or below the ceiling is honoured as configured. This
# is the case worker_heap_exceeds_limit misses: a heap between the ceiling and
# the full limit (e.g. heap == limit) still gets trimmed.
worker_heap_exceeds_ceiling() {
    local limit_raw="$1" heap_mb="$2" ceiling_mb
    case "$heap_mb" in ''|*[!0-9]*) return 1 ;; esac
    ceiling_mb=$(worker_heap_ceiling_mb "$limit_raw") || return 1
    [ "$heap_mb" -gt "$ceiling_mb" ]
}

# worker_mem_exceeds_host TOTAL_MEM_GB LIMIT_VALUE
# True (0) when the worker limit takes more than half the host's memory —
# the rest of the stack (MySQL, Temporal, provider, ...) shares the same
# machine, so this is the point where the operator should size deliberately.
worker_mem_exceeds_host() {
    local total_gb="$1" limit_raw="$2" limit_mb
    case "$total_gb" in ''|*[!0-9]*) return 1 ;; esac
    limit_mb=$(mem_to_mb "$limit_raw") || return 1
    [ $((limit_mb * 2)) -gt $((total_gb * 1024)) ]
}
