#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# scripts/lib/insights-cli.sh — `bitoarch insights …` CLI subcommands.

if [ -n "${_BITOARCH_INSIGHTS_CLI_LOADED:-}" ]; then return 0 2>/dev/null || true; fi
_BITOARCH_INSIGHTS_CLI_LOADED=1

# Source the shared interactive prompts. SCRIPT_DIR is <repo>/scripts when
# entered via bitoarch.sh, but <repo> when entered via bitoarch-install.sh;
# try both so prompts load in either path.
if [ -f "${SCRIPT_DIR}/lib/insights-prompts.sh" ]; then
    source "${SCRIPT_DIR}/lib/insights-prompts.sh"
elif [ -f "${SCRIPT_DIR}/scripts/lib/insights-prompts.sh" ]; then
    source "${SCRIPT_DIR}/scripts/lib/insights-prompts.sh"
fi

# Mask the middle portion of a token-like string for status display.
_insights_mask() {
    local v="${1:-}"
    [ -z "$v" ] && { echo ""; return; }
    local n=${#v}
    if [ "$n" -le 4 ]; then
        echo "****"
    elif [ "$n" -le 8 ]; then
        printf '%s****\n' "${v:0:2}"
    else
        printf '%s****%s\n' "${v:0:3}" "${v: -2}"
    fi
}

_is_any_insights_enabled() {
    [ "${INSIGHTS_GIT_ENABLED:-}" = "true" ] || \
    [ "${INSIGHTS_TICKET_TRACKER_ENABLED:-}" = "true" ] || \
    [ "${INSIGHTS_DOCS_ENABLED:-}" = "true" ]
}

_insights_analysis_running() {
    command -v jq >/dev/null 2>&1 || return 1
    local _mgr_url="${CIS_MANAGER_URL:-http://localhost:${CIS_MANAGER_EXTERNAL_PORT:-5002}}"

    local _ins_resp
    _ins_resp=$(curl -s --connect-timeout 3 --max-time 5 \
        -H "Authorization: Bearer ${BITO_API_KEY:-}" \
        "${_mgr_url}/api/v3/insights/status" 2>/dev/null) || return 1
    local _state
    _state=$(echo "$_ins_resp" | jq -r '.status // empty' 2>/dev/null)
    [ "$_state" = "running" ] && return 0
    return 1
}

_insights_post_enable_hint() {
    if [ -n "${_INSIGHTS_SUPPRESS_RUN_HINT:-}" ]; then return 0; fi
    if _insights_analysis_running 2>/dev/null; then
        echo -e "  Insights analysis is already in progress."
        return 0
    fi
    local _mgr_url="${CIS_MANAGER_URL:-http://localhost:${CIS_MANAGER_EXTERNAL_PORT:-5002}}"
    local _idx_resp _idx_completed
    _idx_resp=$(curl -s --max-time 5 \
        -H "Authorization: Bearer ${BITO_API_KEY:-}" \
        "${_mgr_url}/api/v3/indexing-status" 2>/dev/null) || true
    _idx_completed=$(echo "$_idx_resp" | jq -r '.completed_repos // 0' 2>/dev/null) || true
    if [ "${_idx_completed:-0}" != "0" ] && [ "${_idx_completed:-0}" -gt 0 ] 2>/dev/null; then
        echo -e "  Run insights with: ${YELLOW}bitoarch insights run${NC}"
    else
        echo -e "  Run insights (after indexing completes) with: ${YELLOW}bitoarch insights run${NC}"
    fi
}

insights_status() {
    command -v jq >/dev/null 2>&1 || { print_error "jq is required"; return 1; }
    local _mgr_url="${CIS_MANAGER_URL:-http://localhost:${CIS_MANAGER_EXTERNAL_PORT:-5002}}"
    local _auth="Authorization: Bearer ${BITO_API_KEY:-}"
    # k8s: localhost:5002 needs the on-demand tunnel (docker publishes the port).
    type ensure_manager_service_accessible >/dev/null 2>&1 && ensure_manager_service_accessible >/dev/null 2>&1

    # Fetch workflow status from cis-manager.
    local _raw_resp _http_code
    _raw_resp=$(curl -s --connect-timeout 3 --max-time 10 -w '\n%{http_code}' \
        -H "$_auth" \
        "${_mgr_url}/api/v3/insights/status" 2>/dev/null) || true
    _http_code=$(echo "$_raw_resp" | tail -1)
    _raw_resp=$(echo "$_raw_resp" | sed '$d')

    # -- Workflow status section --
    echo ""
    echo -e "${BOLD}Insights Status${NC}"
    echo ""

    if [ -z "$_raw_resp" ] || [[ ! "$_http_code" =~ ^2 ]]; then
        if [ "$_http_code" = "404" ]; then
            echo -e "  Overall: ${BLUE}• not started${NC}"
            echo ""
            return 0
        fi
        echo -e "${RED}✗ Failed to retrieve insights status${NC}"
        echo ""
        echo -e "${BLUE}Troubleshooting:${NC}"
        echo -e "  • Check if services are running: ${YELLOW}bitoarch status${NC}"
        echo -e "  • Check logs: ${YELLOW}bitoarch logs${NC}"
        echo ""
        return 1
    fi

    local _status _phase _run_active
    _status=$(echo "$_raw_resp" | jq -r '.status // empty' 2>/dev/null)
    _phase=$(echo "$_raw_resp" | jq -r '.phase // empty' 2>/dev/null)
    _run_active=$(echo "$_raw_resp" | jq -r '.run_active // false' 2>/dev/null)
    [ "$_status" = "completed" ] && _status="success"

    if [ -z "$_status" ] || [ "$_status" = "not_started" ]; then
        echo -e "  Overall: ${BLUE}• not started${NC}"
        echo ""
        echo -e "  Run insights (after indexing completes) with: ${YELLOW}bitoarch insights run${NC}"
        echo ""
        return 0
    fi

    local _overall_icon _overall_color
    case "$_status" in
        running)     _overall_icon="⏳"; _overall_color="${YELLOW}" ;;
        success)     _overall_icon="✓";  _overall_color="${GREEN}" ;;
        failed)      _overall_icon="✗";  _overall_color="${RED}" ;;
        cancelled)   _overall_icon="⏹️";  _overall_color="${YELLOW}" ;;
        *)           _overall_icon="•";  _overall_color="${NC}" ;;
    esac
    echo -e "  Overall: ${_overall_color}${_overall_icon} ${_status}${NC} (phase: ${_phase})"
    echo ""

    # Insights status now reports cumulative per-feature counts (total / done /
    # in progress / failed) sourced from the insights ledger, so the interim
    # staleness warning that compared configured repos against the last run is no
    # longer needed. The counts already reflect newly-added repos.
    _render_insights_feature "Git Insights" "git" "$_raw_resp" "repos" "$_run_active"
    _render_insights_feature "Jira Insights" "jira" "$_raw_resp" "projects" "$_run_active"
    _render_insights_feature "Docs Insights" "docs" "$_raw_resp" "spaces" "$_run_active"

    echo ""
    return 0
}

_render_insights_feature() {
    local label="$1" key="$2" json="$3" unit="$4" run_active="${5:-false}"

    local _feat _feat_status _triggered _skip_reason
    _feat=$(echo "$json" | jq -r ".$key // empty" 2>/dev/null)
    [ -z "$_feat" ] && return 0

    _feat_status=$(echo "$json" | jq -r ".$key.status // empty" 2>/dev/null)
    [ "$_feat_status" = "completed" ] && _feat_status="success"
    _triggered=$(echo "$json" | jq -r ".$key.triggered // false" 2>/dev/null)
    _skip_reason=$(echo "$json" | jq -r ".$key.skip_reason // empty" 2>/dev/null)

    # Cumulative counts. `done` is the cumulative field; fall back to
    # `success` for the legacy / un-upgraded manager shape (and the docs feature,
    # which carries no cumulative fields). `in_progress` exists only in the new
    # shape. Counts are read up front so a status can be derived when absent.
    local _total _done _in_progress _skipped _failed
    _total=$(echo "$json" | jq -r ".$key.total // 0" 2>/dev/null)
    _done=$(echo "$json" | jq -r ".$key.done // .$key.success // 0" 2>/dev/null)
    _in_progress=$(echo "$json" | jq -r ".$key.in_progress // 0" 2>/dev/null)
    _skipped=$(echo "$json" | jq -r ".$key.skipped // 0" 2>/dev/null)
    _failed=$(echo "$json" | jq -r ".$key.failed // 0" 2>/dev/null)

    # The cumulative (running) shape carries counts but no per-feature status
    # string — derive one from the counts so the row still shows a sensible icon.
    if [ -z "$_feat_status" ]; then
        if [ "${_in_progress:-0}" -gt 0 ] 2>/dev/null; then
            _feat_status="running"
        elif [ "${_total:-0}" -gt 0 ] 2>/dev/null; then
            if [ "${_failed:-0}" -gt 0 ] && [ "${_done:-0}" -eq 0 ] 2>/dev/null; then
                _feat_status="failed"
            else
                _feat_status="success"
            fi
        fi
    fi

    # A terminally-successful feature with no failures implies all units are done.
    # Some legacy/partial manager shapes report status:"success" with a total but
    # neither done nor success count, which would otherwise render "(0/N done)". Treat
    # success-with-zero-count as fully done — but ONLY when nothing failed, so a
    # run with failures is never inflated to a clean "N/N done".
    if [ "$_feat_status" = "success" ] && [ "${_done:-0}" -eq 0 ] 2>/dev/null \
       && [ "${_total:-0}" -gt 0 ] 2>/dev/null && [ "${_failed:-0}" -eq 0 ] 2>/dev/null; then
        _done="$_total"
    fi

    # Never render a green "✓ success" when repos failed: the manager can report a
    # per-feature status of "success"/"completed" with failed>0 (it overlays the
    # ledger's failed count onto a hardcoded-success status). Downgrade to "failed"
    # so the row shows ✗ with the "N failed" detail instead of a misleading green tick.
    if [ "$_feat_status" = "success" ] && [ "${_failed:-0}" -gt 0 ] 2>/dev/null; then
        _feat_status="failed"
    fi

    # While the overall run is still active, a feature whose ledger entities are
    # all done is NOT terminally complete — the workspace-level synthesis/merge
    # step still runs afterward. Show "finalizing" instead of a premature
    # "success", which also avoids contradicting the running Overall line.
    #
    # Gate this on a PER-FEATURE active flag, not just the global run_active: the
    # cumulative counts persist across runs, so a feature done in a prior run (e.g.
    # Jira during a git-only run) would otherwise be mislabeled "finalizing" while no
    # Jira work is happening. The manager sets `.active` (cumulative shape) /
    # `.triggered` (live workflow shape) true only for features working THIS run.
    local _feat_active
    _feat_active=$(echo "$json" | jq -r ".$key.active // .$key.triggered // false" 2>/dev/null)
    if [ "$run_active" = "true" ] && [ "$_feat_active" = "true" ] && [ "$_feat_status" = "success" ]; then
        _feat_status="finalizing"
    fi

    local _icon _color
    case "$_feat_status" in
        running)                     _icon="⏳"; _color="${YELLOW}" ;;
        finalizing)                  _icon="⏳"; _color="${YELLOW}" ;;
        analysis_complete)           _icon="⏳"; _color="${YELLOW}" ;;
        success)                     _icon="✓";  _color="${GREEN}" ;;
        analysis_failed|failed)      _icon="✗";  _color="${RED}" ;;
        skipped)                     _icon="⊘";  _color="${BLUE}" ;;
        pending)                     _icon="•";  _color="${BLUE}" ;;
        *)                           _icon="•";  _color="${NC}" ;;
    esac

    local _detail=""
    if [ "$_feat_status" = "skipped" ] && [ -n "$_skip_reason" ]; then
        _detail=" (${_skip_reason})"
    fi

    # Build the cumulative detail: "<done>/<total> <unit> done, <n> in progress,
    # <n> skipped, <n> failed" — including only the parts that are non-zero.
    local _inner=""
    if [ "${_total:-0}" -gt 0 ] 2>/dev/null; then
        _inner="${_done}/${_total} ${unit} done"
    fi
    if [ "${_in_progress:-0}" -gt 0 ] 2>/dev/null; then
        [ -n "$_inner" ] && _inner="${_inner}, "
        _inner="${_inner}${_in_progress} in progress"
    fi
    if [ "${_skipped:-0}" -gt 0 ] 2>/dev/null; then
        [ -n "$_inner" ] && _inner="${_inner}, "
        _inner="${_inner}${_skipped} skipped"
    fi
    if [ "${_failed:-0}" -gt 0 ] 2>/dev/null; then
        [ -n "$_inner" ] && _inner="${_inner}, "
        _inner="${_inner}${_failed} failed"
    fi
    [ -n "$_inner" ] && _detail=" (${_inner})"

    printf "    %-18s ${_color}${_icon} %s${NC}%s\n" "${label}:" "$_feat_status" "$_detail"

    # When there are failures, list the failed repo/project names by name
    # (from .<key>.failed_items), similar to how index-status surfaces failures.
    if [ "${_failed:-0}" -gt 0 ] 2>/dev/null; then
        local _failed_block
        _failed_block=$(echo "$json" | jq -r "(.${key}.failed_items // [])[] | \"      - \" + (. | tostring)" 2>/dev/null) || true
        if [ -n "$_failed_block" ]; then
            echo -e "${RED}${_failed_block}${NC}"
        fi
    fi
}

# _insights_tuning_body emits the apply_tuning request body for a feature: the
# base {"enabled":<bool>} plus an optional integer lookback_days. Centralizes the
# JSON shape and the integer-validation rule that was otherwise copy-pasted at
# every enable/run/set-lookback site.
#   $1 = lookback days (optional; included only if a non-negative integer)
#   $2 = enabled value ("true" default, or "false")
_insights_tuning_body() {
    local _lb="${1:-}" _en="${2:-true}"
    if [ -n "$_lb" ] && [[ "$_lb" =~ ^[0-9]+$ ]]; then
        printf '{"enabled":%s,"lookback_days":%s}' "$_en" "$_lb"
    else
        printf '{"enabled":%s}' "$_en"
    fi
}

insights_run() {
    local force_flag=""
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --force) force_flag="--force"; shift ;;
            *) shift ;;
        esac
    done
    if ! _is_any_insights_enabled; then
        if [ -t 0 ]; then
            echo ""
            print_warning "No insights features are enabled."
            local _setup=""
            read -r -p "Set up insights now? [Y/n]: " _setup
            if [[ "$_setup" =~ ^[Nn]$ ]]; then
                echo -e "Enable features later with: ${YELLOW}bitoarch insights enable [git|ticket-tracker|docs]${NC}"
                return 0
            fi
            local env_file
            env_file=$(get_config_file 2>/dev/null)
            [ -z "$env_file" ] && env_file="${ENV_FILE:-}"
            unset INSIGHTS_GIT_ENABLED
            unset INSIGHTS_TICKET_TRACKER_ENABLED
            unset INSIGHTS_DOCS_ENABLED
            unset INSIGHTS_TICKET_TRACKER_PROJECT_KEYS
            unset INSIGHTS_GIT_LOOKBACK_DAYS
            unset INSIGHTS_JIRA_LOOKBACK_DAYS
            ask_git_insights_enabled
            unset _INSIGHTS_JIRA_INSTANCE_CHANGED  # fresh run: clear any stale instance-switch flag
            ask_ticket_tracker_config
            # Clear the re-entry flag a ticket-tracker credential retry may have left
            # set, so it can't suppress the docs "Enable Confluence?" consent prompt.
            unset _INSIGHTS_SKIP_ENABLE_PROMPT
            ask_docs_config
            _INSIGHTS_SUPPRESS_RUN_HINT=1 ask_insights_lookback_days
            export INSIGHTS_SETUP_COMPLETE=true
            insights_persist_env "$env_file"
            if _config_base_row_exists 2>/dev/null; then
                _INSIGHTS_SUPPRESS_RUN_HINT=1 _config_push_insights_after_add_repos
            fi
            if ! _is_any_insights_enabled; then
                print_info "No features were enabled. Nothing to run."
                return 0
            fi
        else
            print_error "No insights features are enabled."
            echo -e "Enable features with: ${YELLOW}bitoarch insights enable [git|ticket-tracker|docs]${NC}"
            return 1
        fi
    fi

    # Pre-check indexing status only on the interactive first-run setup path. The
    # completed-repos count is consumed solely inside this guard, so fetching it
    # unconditionally made every non-interactive/cron `insights run` pay an unused
    # network round-trip that could stall up to 5s.
    if [ -t 0 ] && [ "${INSIGHTS_SETUP_COMPLETE:-}" != "true" ]; then
        local _pre_mgr_url="${CIS_MANAGER_URL:-http://localhost:${CIS_MANAGER_EXTERNAL_PORT:-5002}}"
        local _pre_idx_resp _pre_idx_completed
        _pre_idx_resp=$(curl -s --connect-timeout 3 --max-time 5 \
            -H "Authorization: Bearer ${BITO_API_KEY:-}" \
            "${_pre_mgr_url}/api/v3/indexing-status" 2>/dev/null) || true
        _pre_idx_completed=$(echo "$_pre_idx_resp" | jq -r '.completed_repos // 0' 2>/dev/null) || true

        if [ "${_pre_idx_completed:-0}" != "0" ] && [ "${_pre_idx_completed:-0}" -gt 0 ] 2>/dev/null; then
            local _env_file
            _env_file=$(get_config_file 2>/dev/null)
            [ -z "$_env_file" ] && _env_file="${ENV_FILE:-}"
            local _has_pk=""
            local _pk_cfg
            _pk_cfg=$(_insights_tp_repo_config_path 2>/dev/null)
            if [ -n "$_pk_cfg" ] && [ -f "$_pk_cfg" ]; then
                _has_pk=$(_insights_tp_read_keys "$_pk_cfg" 2>/dev/null | head -1)
            fi
            [ -z "$_has_pk" ] && _has_pk="${INSIGHTS_TICKET_TRACKER_PROJECT_KEYS:-}"
            if [ "${INSIGHTS_TICKET_TRACKER_ENABLED:-}" = "true" ] \
               && [ -z "$_has_pk" ]; then
                unset _INSIGHTS_JIRA_INSTANCE_CHANGED  # fresh run: clear any stale instance-switch flag
                _INSIGHTS_SUPPRESS_RUN_HINT=1 ask_ticket_tracker_config
            fi
            _INSIGHTS_SUPPRESS_RUN_HINT=1 ask_insights_lookback_days
            export INSIGHTS_SETUP_COMPLETE=true
            insights_persist_env "$_env_file"
        fi
    fi

    local _run_list="" _skip_list=""
    local _tt_no_keys=false
    if [ "${INSIGHTS_GIT_ENABLED:-}" = "true" ]; then
        _run_list="git"
    fi
    if [ "${INSIGHTS_TICKET_TRACKER_ENABLED:-}" = "true" ]; then
        if [ -z "${JIRA_DOMAIN:-}" ] || [ -z "${JIRA_API_TOKEN:-}" ]; then
            _skip_list="ticket-tracker (credentials incomplete)"
        else
            local _pk=""
            local _pk_cfg
            _pk_cfg=$(_insights_tp_repo_config_path 2>/dev/null)
            if [ -n "$_pk_cfg" ] && [ -f "$_pk_cfg" ]; then
                _pk=$(_insights_tp_read_keys "$_pk_cfg" 2>/dev/null | head -1)
            fi
            [ -z "$_pk" ] && _pk="${INSIGHTS_TICKET_TRACKER_PROJECT_KEYS:-}"
            if [ -n "$_pk" ]; then
                _run_list="${_run_list:+${_run_list}, }ticket-tracker"
            else
                _tt_no_keys=true
                _skip_list="ticket-tracker (no project keys)"
            fi
        fi
    fi
    if [ "${INSIGHTS_DOCS_ENABLED:-}" = "true" ]; then
        # Per-provider readiness: Confluence reuses Jira creds (toggle alone is enough),
        # Google needs its own OAuth triple.
        local _docs_ready=false
        if [ "${INSIGHTS_DOCS_CONFLUENCE_ENABLED:-}" = "true" ]; then
            _docs_ready=true
        elif [ "${INSIGHTS_DOCS_GOOGLE_ENABLED:-}" = "true" ] \
             && [ -n "${INSIGHTS_DOCS_CLIENT_ID:-}" ] && [ -n "${INSIGHTS_DOCS_CLIENT_SECRET:-}" ] \
             && [ -n "${INSIGHTS_DOCS_REFRESH_TOKEN:-}" ]; then
            _docs_ready=true
        fi
        if [ "$_docs_ready" != "true" ]; then
            _skip_list="${_skip_list:+${_skip_list}, }docs (credentials incomplete)"
        elif [ "${INSIGHTS_TICKET_TRACKER_ENABLED:-}" != "true" ]; then
            _skip_list="${_skip_list:+${_skip_list}, }docs (requires ticket-tracker to be enabled)"
        elif [ "$_tt_no_keys" = "true" ]; then
            _skip_list="${_skip_list:+${_skip_list}, }docs (requires ticket-tracker project keys)"
        else
            _run_list="${_run_list:+${_run_list}, }docs"
        fi
    fi
    if [ -z "$_run_list" ]; then
        print_error "Cannot run insights: no features are ready."
        if [ -n "$_skip_list" ]; then
            echo -e "  Skipping: ${_skip_list}"
        fi
        if [ "$_tt_no_keys" = "true" ]; then
            echo -e "  Add project keys with: ${YELLOW}bitoarch insights tracker-projects add KEY1 [KEY2 ...]${NC}"
        fi
        echo ""
        echo -e "  Enable features with: ${YELLOW}bitoarch insights enable [git|ticket-tracker|docs]${NC}"
        return 1
    fi
    echo ""
    print_info "Will run: ${_run_list}"
    if [ -n "$_skip_list" ]; then
        print_warning "Skipping: ${_skip_list}"
        echo -e "  Add project keys with: ${YELLOW}bitoarch insights tracker-projects add KEY1 [KEY2 ...]${NC}"
    fi

    if [ "${INSIGHTS_GIT_ENABLED:-}" = "true" ]; then
        apply_tuning git "$(_insights_tuning_body "${INSIGHTS_GIT_LOOKBACK_DAYS:-}")" >/dev/null 2>&1 || log_silent "insights: git tuning apply failed"
    fi
    if [ "${INSIGHTS_TICKET_TRACKER_ENABLED:-}" = "true" ] && [ "$_tt_no_keys" != "true" ]; then
        apply_tuning jira "$(_insights_tuning_body "${INSIGHTS_JIRA_LOOKBACK_DAYS:-}")" >/dev/null 2>&1 || log_silent "insights: jira tuning apply failed"
        config_apply_ticket_tracker >/dev/null 2>&1 || log_silent "insights: ticket tracker config apply failed"
    fi
    if [ "${INSIGHTS_DOCS_ENABLED:-}" = "true" ]; then
        apply_tuning docs '{"enabled":true}' >/dev/null 2>&1 || log_silent "insights: docs tuning apply failed"
        config_apply_docs >/dev/null 2>&1 || log_silent "insights: docs config apply failed"
    fi
    manager_trigger_insights $force_flag
}

handle_insights() {
    local sub="${1:-}"
    shift || true

    case "$sub" in
        config)
            insights_config "$@"
            ;;
        status)
            insights_status "$@"
            ;;
        enable)
            insights_enable "$@"
            ;;
        disable)
            insights_disable "$@"
            ;;
        run)
            insights_run "$@"
            ;;
        tracker-projects)
            insights_tracker_projects "$@"
            ;;
        discover-tracker-projects)
            _insights_discover_tracker_projects "$@"
            ;;
        set-lookback)
            insights_set_lookback "$@"
            ;;
        update-ticket-tracker|update-ticket-tracker-config)
            insights_update_ticket_tracker "$@"
            ;;
        update-doc-config|update-docs)
            insights_update_docs "$@"
            ;;
        --help|-h|"")
            cat <<'EOF'
USAGE:
  bitoarch insights [subcommand]

SUBCOMMANDS:
  config                                   Show insights configuration
  status                                   Show detailed insights workflow status
  run [--force]                            Run insights analysis (--force re-analyzes all)
  enable [git|ticket-tracker|docs]         Enable a feature (interactive for creds)
  disable [git|ticket-tracker|docs]        Disable a feature
  set-lookback [git|ticket-tracker] [DAYS] Set lookback days for a feature
  tracker-projects [action] [KEY …]        Manage ticket-tracker project keys (list|add|remove|set)
  discover-tracker-projects                List accessible ticket-tracker projects
  update-ticket-tracker-config             Update ticket-tracker credentials
  update-doc-config                        Update doc integration credentials
EOF
            return 0
            ;;
        *)
            print_error "Unknown insights subcommand: $sub"
            echo -e "Run ${YELLOW}bitoarch insights --help${NC} for usage."
            return 1
            ;;
    esac
}

_print_insights_row() {
    local label="$1" status="$2" color="$3" lb="$4" provider="$5" url="$6"
    printf "  %-26s ${color}%-12s${NC} %-14s %-14s %s\n" \
        "$label" "$status" "$lb" "$provider" "$url"
}

insights_config() {
    local _cfg_url="${CONFIG_URL:-http://localhost:${CIS_CONFIG_EXTERNAL_PORT:-5003}}"
    local _auth="Authorization: Bearer ${BITO_API_KEY}"
    local _from_server=true

    # k8s: localhost:5003 needs the on-demand tunnel (docker publishes the port).
    type ensure_config_service_accessible >/dev/null 2>&1 && ensure_config_service_accessible >/dev/null 2>&1

    # Fetch server state from cis-config endpoints.
    local _git_tuning _jira_tuning _tt_resp _docs_resp _probe_http
    _git_tuning=$(curl -s --connect-timeout 3 --max-time 5 -w '\n%{http_code}' -H "$_auth" \
        "${_cfg_url}/api/v1/config/tuning?key=git" 2>/dev/null) || _from_server=false
    _probe_http=$(echo "$_git_tuning" | tail -1)
    _git_tuning=$(echo "$_git_tuning" | sed '$d')

    if [ "$_from_server" = "false" ] || [ "$_probe_http" = "000" ] || [ -z "$_probe_http" ]; then
        echo ""
        echo -e "${RED}✗ Failed to retrieve insights configuration${NC}"
        echo ""
        echo -e "${BLUE}Troubleshooting:${NC}"
        echo -e "  • Check if services are running: ${YELLOW}bitoarch status${NC}"
        echo -e "  • Check logs: ${YELLOW}bitoarch logs${NC}"
        echo ""
        return 1
    fi

    if echo "$_git_tuning" | jq -e '.error' >/dev/null 2>&1; then
        echo ""
        echo -e "${YELLOW}Workspace not configured yet.${NC}"
        echo ""
        echo -e "  Run ${YELLOW}bitoarch add-repos${NC} first to configure the workspace."
        echo ""
        return 1
    fi

    _jira_tuning=$(curl -s --max-time 5 -H "$_auth" \
        "${_cfg_url}/api/v1/config/tuning?key=jira" 2>/dev/null) || _from_server=false
    _tt_resp=$(curl -s --max-time 5 -H "$_auth" \
        "${_cfg_url}/api/v1/config/ticket-tracker" 2>/dev/null) || _from_server=false
    _docs_resp=$(curl -s --max-time 5 -H "$_auth" \
        "${_cfg_url}/api/v1/config/docs" 2>/dev/null) || _from_server=false

    if [ "$_from_server" = "false" ]; then
        echo ""
        echo -e "${RED}✗ Failed to retrieve insights configuration${NC}"
        echo ""
        echo -e "${BLUE}Troubleshooting:${NC}"
        echo -e "  • Check if services are running: ${YELLOW}bitoarch status${NC}"
        echo -e "  • Check logs: ${YELLOW}bitoarch logs${NC}"
        echo ""
        return 1
    fi

    echo ""
    echo -e "  ${BOLD}Source: server (cis-config)${NC}"
    echo ""
    printf "  %-26s %-12s %-14s %-14s %s\n" "Feature" "Status" "Lookback" "Provider" "URL"
    printf "  %-26s %-12s %-14s %-14s %s\n" "--------------------------" "------------" "--------------" "--------------" "------------------------------"

    # Git insights
    local g_status="disabled" g_color="${RED}" g_provider="-" g_url="-" g_lb="-"
    local _git_enabled
    _git_enabled=$(echo "$_git_tuning" | jq -r '.enabled // false' 2>/dev/null) || true
    if [ "$_git_enabled" = "true" ]; then
        g_status="enabled"; g_color="${GREEN}"
        g_lb=$(echo "$_git_tuning" | jq -r '.lookback_days // "-"' 2>/dev/null) || true
    fi
    [ -n "${GIT_PROVIDER:-}" ] && g_provider="${GIT_PROVIDER}"
    [ -n "${GIT_DOMAIN_URL:-}" ] && g_url="${GIT_DOMAIN_URL}"
    _print_insights_row "Git Insights" "$g_status" "$g_color" "$g_lb" "$g_provider" "$g_url"

    # Ticket tracker insights. The FEATURE state is the env flag + jira tuning:
    # the shared connection record ($_tt_resp) is deliberately KEPT on disable
    # while an installed plugin still consumes it, so its .enabled must not be
    # read as "Insights enabled".
    local _tt_configured=false
    local tt_status="disabled" tt_color="${RED}" tt_provider="-" tt_url="-" tt_lb="-"
    local _tt_enabled _tt_provider_val _tt_base_url
    _tt_enabled=$(echo "$_tt_resp" | jq -r '.enabled // false' 2>/dev/null) || true
    if [ "${INSIGHTS_TICKET_TRACKER_ENABLED:-}" != "true" ]; then
        _tt_enabled="false"
    fi
    if [ "$_tt_enabled" = "true" ]; then
        _tt_configured=true
        tt_status="enabled"; tt_color="${GREEN}"
        _tt_provider_val=$(echo "$_tt_resp" | jq -r '.provider // "-"' 2>/dev/null) || true
        _tt_base_url=$(echo "$_tt_resp" | jq -r '.config.base_url // "-"' 2>/dev/null) || true
        tt_provider="$_tt_provider_val"
        tt_url="$_tt_base_url"
        tt_lb=$(echo "$_jira_tuning" | jq -r '.lookback_days // "-"' 2>/dev/null) || true
    fi
    _print_insights_row "Ticket Tracker Insights" "$tt_status" "$tt_color" "$tt_lb" "$tt_provider" "$tt_url"

    # Docs insights — docs is a COLLECTION (array of per-provider entries); normalize
    # a single-object response too, then aggregate the enabled providers.
    local _docs_configured=false
    local d_status="disabled" d_color="${RED}" d_provider="-" d_url="-"
    local _docs_enabled=false _docs_norm _docs_provs
    _docs_norm=$(echo "$_docs_resp" | jq -c 'if type=="array" then . else [.] end' 2>/dev/null) || _docs_norm="[]"
    _docs_provs=$(echo "$_docs_norm" | jq -r '[.[] | select(.enabled==true and (.provider=="confluence" or .provider=="google_docs")) | .provider] | join("+")' 2>/dev/null) || true
    if [ -n "$_docs_provs" ]; then
        _docs_enabled=true
        _docs_configured=true
        d_status="enabled"; d_color="${GREEN}"
        d_provider="$_docs_provs"
        d_url=$(echo "$_docs_norm" | jq -r '[.[] | select(.enabled==true and .provider=="confluence") | .config.url] | .[0] // "-"' 2>/dev/null) || d_url="-"
        [ -z "$d_url" ] && d_url="-"
    fi
    _print_insights_row "Docs" "$d_status" "$d_color" "-" "$d_provider" "$d_url"

    if [ "$_tt_configured" = "true" ]; then
        echo ""
        echo -e "  ${BOLD}Ticket Tracker (Jira)${NC}"
        local _tt_email _tt_host_type _tt_token
        _tt_email=$(echo "$_tt_resp" | jq -r '.config.email // "-"' 2>/dev/null) || true
        _tt_host_type=$(echo "$_tt_resp" | jq -r '.config.host_type // "-"' 2>/dev/null) || true
        _tt_token=$(echo "$_tt_resp" | jq -r '.config.access_token // ""' 2>/dev/null) || true
        echo "    Email:            $_tt_email"
        echo "    Host type:        $_tt_host_type"
        echo "    Token:            $(_insights_mask "$_tt_token")"
        local _tt_keys
        _tt_keys=$(echo "$_tt_resp" | jq -r '.config.project_keys // [] | join(",")' 2>/dev/null) || true
        echo "    Project keys:     ${_tt_keys:-(none)}"
    fi
    if [ "$_docs_configured" = "true" ]; then
        local _d_conf
        _d_conf=$(echo "$_docs_norm" | jq -c '[.[] | select(.enabled==true and .provider=="confluence")] | .[0] // empty' 2>/dev/null) || true
        if [ -n "$_d_conf" ]; then
            echo ""
            echo -e "  ${BOLD}Docs (Confluence)${NC}"
            local _d_email _d_token
            _d_email=$(echo "$_d_conf" | jq -r '.config.email // "-"' 2>/dev/null) || true
            _d_token=$(echo "$_d_conf" | jq -r '.config.token // ""' 2>/dev/null) || true
            echo "    Email:            $_d_email"
            echo "    Token:            $(_insights_mask "$_d_token")"
        fi
    fi

    # Warn when local env says enabled but server says disabled (config out of sync).
    local _mismatches=""
    if [ "${INSIGHTS_GIT_ENABLED:-}" = "true" ] && [ "$_git_enabled" != "true" ]; then
        _mismatches="${_mismatches}    Git Insights:            env=enabled  server=disabled\n"
    fi
    local _jira_enabled
    _jira_enabled=$(echo "$_jira_tuning" | jq -r '.enabled // false' 2>/dev/null) || true
    if [ "${INSIGHTS_TICKET_TRACKER_ENABLED:-}" = "true" ] && [ "$_jira_enabled" != "true" ]; then
        _mismatches="${_mismatches}    Ticket Tracker Insights:  env=enabled  server=disabled\n"
    fi
    if [ "${INSIGHTS_DOCS_ENABLED:-}" = "true" ] && [ "$_docs_enabled" != "true" ]; then
        _mismatches="${_mismatches}    Docs:                    env=enabled  server=disabled\n"
    fi
    if [ -n "$_mismatches" ]; then
        echo ""
        echo -e "  ${YELLOW}⚠  Local environment and server config are out of sync:${NC}"
        echo -e "$_mismatches"
        echo -e "  Run ${YELLOW}bitoarch insights run${NC} or ${YELLOW}bitoarch add-repos${NC} to re-sync."
    fi

    echo ""
}

# Fallback: show config from environment variables when cis-config is unreachable.
_insights_config_from_env() {
    echo ""
    echo -e "  ${YELLOW}Source: local environment (server unreachable)${NC}"
    echo ""
    printf "  %-26s %-12s %-14s %-14s %s\n" "Feature" "Status" "Lookback" "Provider" "URL"
    printf "  %-26s %-12s %-14s %-14s %s\n" "--------------------------" "------------" "--------------" "--------------" "------------------------------"

    local g_status="disabled" g_color="${RED}" g_provider="-" g_url="-" g_lb="-"
    if [ "${INSIGHTS_GIT_ENABLED:-}" = "true" ]; then
        g_status="enabled"; g_color="${GREEN}"
        g_lb="${INSIGHTS_GIT_LOOKBACK_DAYS:-"-"}"
    fi
    [ -n "${GIT_PROVIDER:-}" ] && g_provider="${GIT_PROVIDER}"
    [ -n "${GIT_DOMAIN_URL:-}" ] && g_url="${GIT_DOMAIN_URL}"
    _print_insights_row "Git Insights" "$g_status" "$g_color" "$g_lb" "$g_provider" "$g_url"

    local _tt_configured=false
    local tt_status="disabled" tt_color="${RED}" tt_provider="-" tt_url="-" tt_lb="-"
    if [ "${INSIGHTS_TICKET_TRACKER_ENABLED:-}" = "true" ] \
       && [ -n "${JIRA_DOMAIN:-}" ] \
       && [ -n "${JIRA_API_TOKEN:-}" ]; then
        _tt_configured=true
        tt_status="enabled"; tt_color="${GREEN}"
        tt_provider="${INSIGHTS_TICKET_TRACKER_PROVIDER:-jira}"
        tt_url="${JIRA_DOMAIN:-}"
        tt_lb="${INSIGHTS_JIRA_LOOKBACK_DAYS:-"-"}"
    fi
    _print_insights_row "Ticket Tracker Insights" "$tt_status" "$tt_color" "$tt_lb" "$tt_provider" "$tt_url"

    local _docs_configured=false
    local _docs_conf=false _docs_goog=false
    local d_status="disabled" d_color="${RED}" d_provider="-" d_url="-"
    if [ "${INSIGHTS_DOCS_ENABLED:-}" = "true" ]; then
        if [ "${INSIGHTS_DOCS_CONFLUENCE_ENABLED:-}" = "true" ] \
           || { [ "${INSIGHTS_DOCS_GOOGLE_ENABLED:-}" != "true" ] && [ -n "${INSIGHTS_DOCS_URL:-}" ] && [ -n "${INSIGHTS_DOCS_EMAIL:-}" ] && [ -n "${INSIGHTS_DOCS_API_TOKEN:-}" ]; }; then
            _docs_conf=true
        fi
        if [ "${INSIGHTS_DOCS_GOOGLE_ENABLED:-}" = "true" ] \
           && [ -n "${INSIGHTS_DOCS_CLIENT_ID:-}" ] && [ -n "${INSIGHTS_DOCS_CLIENT_SECRET:-}" ] && [ -n "${INSIGHTS_DOCS_REFRESH_TOKEN:-}" ]; then
            _docs_goog=true
        fi
    fi
    if [ "$_docs_conf" = "true" ] || [ "$_docs_goog" = "true" ]; then
        _docs_configured=true
        d_status="enabled"; d_color="${GREEN}"
        local _provs=""
        [ "$_docs_conf" = "true" ] && _provs="confluence"
        [ "$_docs_goog" = "true" ] && _provs="${_provs:+${_provs}+}google_docs"
        d_provider="$_provs"
        if [ "$_docs_conf" = "true" ]; then
            d_url="${INSIGHTS_DOCS_URL:-${JIRA_DOMAIN:-}}"
        elif [ "$_docs_goog" = "true" ]; then
            d_url="drive.google.com"
        fi
    fi
    _print_insights_row "Docs" "$d_status" "$d_color" "-" "$d_provider" "$d_url"

    if [ "$_tt_configured" = "true" ]; then
        echo ""
        echo -e "  ${BOLD}Ticket Tracker (Jira)${NC}"
        echo "    Email:            ${JIRA_EMAIL:-}"
        echo "    Host type:        ${JIRA_HOST_TYPE:-}"
        echo "    Token:            $(_insights_mask "${JIRA_API_TOKEN:-}")"
        local _proj_keys=""
        local _cfg
        _cfg=$(_insights_tp_repo_config_path 2>/dev/null)
        if [ -n "$_cfg" ] && [ -f "$_cfg" ]; then
            _proj_keys=$(_insights_tp_read_keys "$_cfg" 2>/dev/null | paste -sd, -)
        fi
        [ -z "$_proj_keys" ] && _proj_keys="${INSIGHTS_TICKET_TRACKER_PROJECT_KEYS:-}"
        echo "    Project keys:     ${_proj_keys:-(none)}"
    fi
    if [ "$_docs_configured" = "true" ]; then
        if [ "$_docs_conf" = "true" ]; then
            echo ""
            echo -e "  ${BOLD}Docs (Confluence)${NC}"
            echo "    Email:            ${INSIGHTS_DOCS_EMAIL:-${JIRA_EMAIL:-}}"
            echo "    Token:            $(_insights_mask "${INSIGHTS_DOCS_API_TOKEN:-${JIRA_API_TOKEN:-}}")"
        fi
        if [ "$_docs_goog" = "true" ]; then
            echo ""
            echo -e "  ${BOLD}Docs (Google Docs)${NC}"
            echo "    Client ID:        ${INSIGHTS_DOCS_CLIENT_ID:-}"
            echo "    Client secret:    $(_insights_mask "${INSIGHTS_DOCS_CLIENT_SECRET:-}")"
            echo "    Refresh token:    $(_insights_mask "${INSIGHTS_DOCS_REFRESH_TOKEN:-}")"
        fi
    fi

    echo ""
}

insights_enable() {
    local feature="${1:-}"
    if [ -z "$feature" ]; then
        echo -e "Usage: ${YELLOW}bitoarch insights enable [git|ticket-tracker|docs]${NC}"
        return 1
    fi

    if [ "$feature" != "git" ]; then
        if ! _config_base_row_exists 2>/dev/null; then
            print_error "No workspace configured yet."
            echo -e "  Run ${YELLOW}bitoarch add-repos${NC} first, then re-run this command."
            return 1
        fi
    fi

    local env_file
    env_file=$(get_config_file 2>/dev/null)
    [ -z "$env_file" ] && env_file="${ENV_FILE:-}"

    case "$feature" in
        git)
            if [ "${INSIGHTS_GIT_ENABLED:-}" = "true" ]; then
                print_info "Git Insights is already enabled."
                return 0
            fi
            INSIGHTS_GIT_ENABLED="true"
            export INSIGHTS_GIT_ENABLED
            _ask_lookback_for_feature "Git" "INSIGHTS_GIT_LOOKBACK_DAYS"
            insights_persist_env "$env_file"
            apply_tuning git "$(_insights_tuning_body "${INSIGHTS_GIT_LOOKBACK_DAYS:-}")" >/dev/null 2>&1 \
                || log_silent "insights: apply_tuning git failed (non-fatal)"
            print_success "Git Insights enabled"
            echo -e "  Uses Git provider credentials configured via ${YELLOW}bitoarch update-git-creds${NC}."
            _insights_post_enable_hint
            ;;
        ticket-tracker)
            if [ "${INSIGHTS_TICKET_TRACKER_ENABLED:-}" = "true" ] \
               && [ -n "${JIRA_DOMAIN:-}" ] \
               && [ -n "${JIRA_API_TOKEN:-}" ]; then
                print_info "Ticket Tracker Insights is already enabled."
                return 0
            fi
            if [ "${INSIGHTS_TICKET_TRACKER_ENABLED:-}" = "true" ]; then
                print_warning "Ticket tracker credentials are incomplete — re-entering setup."
            fi
            # Clear flags so the prompt and project discovery actually run.
            unset INSIGHTS_TICKET_TRACKER_ENABLED
            unset INSIGHTS_TICKET_TRACKER_PROJECT_KEYS
            # A shared Jira connection may already exist (set by Insights or an installed plugin). Show
            # the SAME reuse/reconfigure ack the plugin flow uses (one shared helper). On keep, enable
            # on the existing connection and just (re)select the Insights project keys; on 'n' / none,
            # capture fresh via ask_ticket_tracker_config.
            local _tt_base_url="" _tt_email="" _tt_token="" _tt_host_type=""
            if _insights_tt_confirm_reuse "Jira"; then
                JIRA_DOMAIN="$_tt_base_url"; JIRA_EMAIL="$_tt_email"; JIRA_API_TOKEN="$_tt_token"
                JIRA_HOST_TYPE="${_tt_host_type:-cloud}"
                export JIRA_DOMAIN JIRA_EMAIL JIRA_API_TOKEN JIRA_HOST_TYPE
                INSIGHTS_TICKET_TRACKER_ENABLED="true"
                INSIGHTS_TICKET_TRACKER_PROVIDER="${INSIGHTS_TICKET_TRACKER_PROVIDER:-jira}"
                INSIGHTS_TICKET_TRACKER_AUTH_TYPE="${INSIGHTS_TICKET_TRACKER_AUTH_TYPE:-api-token}"
                export INSIGHTS_TICKET_TRACKER_ENABLED INSIGHTS_TICKET_TRACKER_PROVIDER INSIGHTS_TICKET_TRACKER_AUTH_TYPE
                _ask_ticket_tracker_project_keys
            else
                _INSIGHTS_SKIP_ENABLE_PROMPT=1 ask_ticket_tracker_config
            fi
            if [ "${INSIGHTS_TICKET_TRACKER_ENABLED:-}" != "true" ]; then
                print_info "Ticket Tracker Insights not enabled."
                return 0
            fi
            _ask_lookback_for_feature "Jira" "INSIGHTS_JIRA_LOOKBACK_DAYS"
            insights_persist_env "$env_file"
            # Sync project keys to .bitoarch-config.yaml
            if [ -n "${INSIGHTS_TICKET_TRACKER_PROJECT_KEYS:-}" ] \
               && _insights_tp_has_yaml_tool 2>/dev/null; then
                local _sync_cfg
                _sync_cfg=$(_insights_tp_repo_config_path 2>/dev/null)
                if [ -n "$_sync_cfg" ] && [ -f "$_sync_cfg" ]; then
                    echo "${INSIGHTS_TICKET_TRACKER_PROJECT_KEYS}" | tr ',' '\n' \
                        | _insights_tp_write_keys "$_sync_cfg" 2>/dev/null || true
                fi
            fi
            config_apply_ticket_tracker || return 1
            apply_tuning jira "$(_insights_tuning_body "${INSIGHTS_JIRA_LOOKBACK_DAYS:-}")" >/dev/null 2>&1 \
                || log_silent "insights: apply_tuning jira failed (non-fatal)"
            print_success "Ticket Tracker Insights enabled"
            # Enable can capture FRESH credentials into the shared record — fan the
            # change out to plugins declaring this integration (same as update-ticket-tracker).
            if type _bitoarch_plugin_lifecycle >/dev/null 2>&1; then
                { _bitoarch_plugin_lifecycle && plugin_lifecycle_integration_updated ticket-tracker "${_INSIGHTS_JIRA_INSTANCE_CHANGED:-0}"; } || true
            fi
            if [ "${INSIGHTS_DOCS_ENABLED:-}" != "true" ] && [ -t 0 ]; then
                echo ""
                unset INSIGHTS_DOCS_ENABLED
                # Clear the re-entry flag a ticket-tracker credential retry / host-type
                # mismatch may have left set, so it can't suppress the docs
                # "Enable Confluence?" consent prompt below.
                unset _INSIGHTS_SKIP_ENABLE_PROMPT
                ask_docs_config
                if [ "${INSIGHTS_DOCS_ENABLED:-}" = "true" ]; then
                    insights_persist_env "$env_file"
                    local _docs_ok=true
                    apply_tuning docs '{"enabled":true}' >/dev/null 2>&1 \
                        || { _docs_ok=false; log_silent "insights: docs tuning apply failed"; }
                    config_apply_docs \
                        || { _docs_ok=false; log_silent "insights: docs config apply failed"; }
                    if [ "$_docs_ok" = "true" ]; then
                        print_success "Docs integration enabled"
                    else
                        print_warning "Docs settings saved, but applying them failed — run ${YELLOW}bitoarch insights enable docs${NC} again (see $LOG_FILE)"
                    fi
                fi
            fi
            _insights_post_enable_hint
            ;;
        docs)
            local _docs_conf_ok=false _docs_goog_ok=false
            if [ "${INSIGHTS_DOCS_CONFLUENCE_ENABLED:-}" = "true" ] \
               || { [ -n "${INSIGHTS_DOCS_URL:-}" ] && [ -n "${INSIGHTS_DOCS_EMAIL:-}" ] && [ -n "${INSIGHTS_DOCS_API_TOKEN:-}" ]; }; then
                _docs_conf_ok=true
            fi
            if [ "${INSIGHTS_DOCS_GOOGLE_ENABLED:-}" = "true" ] \
               && [ -n "${INSIGHTS_DOCS_CLIENT_ID:-}" ] && [ -n "${INSIGHTS_DOCS_CLIENT_SECRET:-}" ] \
               && [ -n "${INSIGHTS_DOCS_REFRESH_TOKEN:-}" ]; then
                _docs_goog_ok=true
            fi
            # Only short-circuit when BOTH providers are configured; if either is
            # missing, fall through to the prompt so the user can add it.
            if [ "${INSIGHTS_DOCS_ENABLED:-}" = "true" ] \
               && [ "$_docs_conf_ok" = "true" ] && [ "$_docs_goog_ok" = "true" ]; then
                print_info "Docs integration is already enabled (both providers configured)."
                return 0
            fi
            if [ "${INSIGHTS_TICKET_TRACKER_ENABLED:-}" != "true" ]; then
                print_error "Enable ticket-tracker first; docs depends on it."
                return 1
            fi
            if [ "${INSIGHTS_DOCS_ENABLED:-}" = "true" ]; then
                print_warning "Docs credentials are incomplete — re-entering setup."
            fi
            unset INSIGHTS_DOCS_ENABLED
            _INSIGHTS_SKIP_ENABLE_PROMPT=1 ask_docs_config
            if [ "${INSIGHTS_DOCS_ENABLED:-}" != "true" ]; then
                print_info "Docs integration not enabled."
                return 0
            fi
            insights_persist_env "$env_file"
            apply_tuning docs '{"enabled":true}' >/dev/null 2>&1 || log_silent "insights: docs tuning apply failed"
            config_apply_docs || return 1
            print_success "Docs integration enabled"
            _insights_post_enable_hint
            ;;
        *)
            print_error "Unknown feature: $feature (valid: git, ticket-tracker, docs)"
            return 1
            ;;
    esac
}

insights_disable() {
    local feature="${1:-}"
    if [ -z "$feature" ]; then
        echo -e "Usage: ${YELLOW}bitoarch insights disable [git|ticket-tracker|docs]${NC}"
        return 1
    fi

    local env_file
    env_file=$(get_config_file 2>/dev/null)
    [ -z "$env_file" ] && env_file="${ENV_FILE:-}"

    case "$feature" in
        git)
            if [ "${INSIGHTS_GIT_ENABLED:-}" != "true" ]; then
                print_info "Git Insights is already disabled."
                return 0
            fi
            INSIGHTS_GIT_ENABLED="false"
            export INSIGHTS_GIT_ENABLED
            insights_persist_env "$env_file"
            apply_tuning git "$(_insights_tuning_body "${INSIGHTS_GIT_LOOKBACK_DAYS:-}" false)" \
                || log_silent "insights: apply_tuning git failed (non-fatal)"
            print_success "Git Insights disabled"
            ;;
        ticket-tracker)
            if [ "${INSIGHTS_TICKET_TRACKER_ENABLED:-}" != "true" ]; then
                print_info "Ticket Tracker Insights is already disabled."
                return 0
            fi
            INSIGHTS_TICKET_TRACKER_ENABLED="false"
            export INSIGHTS_TICKET_TRACKER_ENABLED
            local _was_docs_enabled="false"
            if [ "${INSIGHTS_DOCS_ENABLED:-}" = "true" ]; then
                _was_docs_enabled="true"
                INSIGHTS_DOCS_ENABLED="false"
                INSIGHTS_DOCS_CONFLUENCE_ENABLED="false"
                INSIGHTS_DOCS_GOOGLE_ENABLED="false"
                export INSIGHTS_DOCS_ENABLED INSIGHTS_DOCS_CONFLUENCE_ENABLED INSIGHTS_DOCS_GOOGLE_ENABLED
            fi
            insights_persist_env "$env_file"
            # Disabling Insights must NOT delete the shared connection record while an
            # installed plugin still declares (and consumes) it — only the Insights
            # feature flag turns off; the plugin keeps working. Manifest-driven check.
            local _tt_consumer=""
            if type _bitoarch_plugin_lifecycle >/dev/null 2>&1 && { _bitoarch_plugin_lifecycle; } 2>/dev/null; then
                _tt_consumer="$(plugin_lifecycle_integration_in_use ticket-tracker 2>/dev/null)" || _tt_consumer=""
            fi
            if [ -n "$_tt_consumer" ]; then
                print_info "Keeping the stored ticket-tracker connection: plugin '${_tt_consumer}' still uses it."
            else
                config_apply_ticket_tracker
            fi
            if [ "$_was_docs_enabled" = "true" ]; then
                config_apply_docs
                apply_tuning docs '{"enabled":false}' >/dev/null 2>&1 \
                    || log_silent "insights: apply_tuning docs disable failed (non-fatal)"
            fi
            apply_tuning jira '{"enabled":false}' >/dev/null 2>&1 \
                || log_silent "insights: apply_tuning jira disable failed (non-fatal)"
            print_success "Ticket Tracker Insights disabled"
            if [ "$_was_docs_enabled" = "true" ]; then
                print_info "Docs integration also disabled (depends on ticket-tracker)"
            fi
            ;;
        docs)
            if [ "${INSIGHTS_DOCS_ENABLED:-}" != "true" ]; then
                print_info "Docs integration is already disabled."
                return 0
            fi
            INSIGHTS_DOCS_ENABLED="false"
            INSIGHTS_DOCS_CONFLUENCE_ENABLED="false"
            INSIGHTS_DOCS_GOOGLE_ENABLED="false"
            export INSIGHTS_DOCS_ENABLED INSIGHTS_DOCS_CONFLUENCE_ENABLED INSIGHTS_DOCS_GOOGLE_ENABLED
            insights_persist_env "$env_file"
            config_apply_docs
            apply_tuning docs '{"enabled":false}' >/dev/null 2>&1 \
                || log_silent "insights: apply_tuning docs disable failed (non-fatal)"
            print_success "Docs integration disabled"
            ;;
        *)
            print_error "Unknown feature: $feature (valid: git, ticket-tracker, docs)"
            return 1
            ;;
    esac
}

insights_set_lookback() {
    local feature="${1:-}" days="${2:-}"
    if [ -z "$feature" ]; then
        echo -e "Usage: ${YELLOW}bitoarch insights set-lookback [git|ticket-tracker] [DAYS]${NC}"
        echo ""
        echo "  Current values:"
        echo "    Git:              ${INSIGHTS_GIT_LOOKBACK_DAYS:-180}"
        echo "    Ticket Tracker:   ${INSIGHTS_JIRA_LOOKBACK_DAYS:-180}"
        return 1
    fi

    local _var _tuning_key _enabled_var _label
    case "$feature" in
        git)
            _var="INSIGHTS_GIT_LOOKBACK_DAYS"; _tuning_key="git"
            _enabled_var="INSIGHTS_GIT_ENABLED"; _label="Git"
            ;;
        ticket-tracker)
            _var="INSIGHTS_JIRA_LOOKBACK_DAYS"; _tuning_key="jira"
            _enabled_var="INSIGHTS_TICKET_TRACKER_ENABLED"; _label="Ticket Tracker"
            ;;
        *)
            print_error "Unknown feature: $feature (valid: git, ticket-tracker)"
            return 1
            ;;
    esac

    if [ "${!_enabled_var:-}" != "true" ]; then
        print_error "${_label} insights is not enabled."
        echo -e "  Enable it first with: ${YELLOW}bitoarch insights enable ${feature}${NC}"
        return 1
    fi

    if [ -z "$days" ]; then
        _ask_lookback_for_feature "$_label" "$_var"
    else
        if [[ "$days" =~ ^[0-9]+$ ]] && [ "$days" -ge 1 ] && [ "$days" -le 730 ]; then
            eval "$_var=\"$days\""
            export "$_var"
        else
            print_error "Invalid value: $days (must be 1-730)"
            return 1
        fi
    fi

    local env_file
    env_file=$(get_config_file 2>/dev/null)
    [ -z "$env_file" ] && env_file="${ENV_FILE:-}"
    insights_persist_env "$env_file"

    local _lb="${!_var}"
    apply_tuning "$_tuning_key" "$(_insights_tuning_body "$_lb")" >/dev/null 2>&1 || log_silent "insights: ${_tuning_key} tuning apply failed"
    print_success "${_label} lookback days set to ${_lb}"
    echo -e "  Run ${YELLOW}bitoarch insights run --force${NC} to re-analyze with the new window."
}

# update-ticket-tracker / update-doc-config: re-prompt for creds, then PUT.
# Only unset the ENABLED flag so the prompt runs, but keep existing values
# as defaults the user can accept by pressing Enter.
insights_update_ticket_tracker() {
    local env_file
    env_file=$(get_config_file 2>/dev/null)
    [ -z "$env_file" ] && env_file="${ENV_FILE:-}"

    if ! _config_base_row_exists 2>/dev/null; then
        print_error "No workspace configured yet."
        echo -e "  Run ${YELLOW}bitoarch add-repos${NC} first, then re-run this command."
        return 1
    fi

    # One shared record — make the blast radius explicit before re-capturing. Skip when a plugin
    # flow already showed it (BITOARCH_TT_SKIP_PLUGIN set) to avoid repeating the same line.
    [ -z "${BITOARCH_TT_SKIP_PLUGIN:-}" ] && type _insights_tt_shared_notice >/dev/null 2>&1 && _insights_tt_shared_notice

    # Snapshot the base env so an aborted re-capture (e.g. repeated invalid input) restores
    # the prior connection instead of persisting a half-updated one. Reuses the shared
    # config backup/restore that `config edit` and reset already use.
    local _tt_bak=""
    command -v backup_config_file >/dev/null 2>&1 && _tt_bak="$(backup_config_file "$env_file" env 2>/dev/null || true)"

    if [ "${INSIGHTS_TICKET_TRACKER_ENABLED:-}" = "true" ]; then
        export _INSIGHTS_SKIP_ENABLE_PROMPT=1
    fi
    unset INSIGHTS_TICKET_TRACKER_ENABLED
    unset _INSIGHTS_JIRA_INSTANCE_CHANGED  # fresh run: clear any stale instance-switch flag
    if ! ask_ticket_tracker_config; then
        unset _INSIGHTS_SKIP_ENABLE_PROMPT
        if [ -n "$_tt_bak" ] && [ -f "$_tt_bak" ] && command -v restore_config_file >/dev/null 2>&1; then
            restore_config_file "$_tt_bak" "$env_file" >/dev/null 2>&1 || true
        fi
        print_warning "Update cancelled — connection left unchanged."
        return 1
    fi
    unset _INSIGHTS_SKIP_ENABLE_PROMPT

    if [ "${INSIGHTS_TICKET_TRACKER_ENABLED:-}" = "true" ]; then
        _ask_lookback_for_feature "Jira" "INSIGHTS_JIRA_LOOKBACK_DAYS"
    fi

    insights_persist_env "$env_file"

    # Sync project keys to .bitoarch-config.yaml so tracker-projects list
    # and discover-tracker-projects stay consistent with .env-bitoarch.
    if [ -n "${INSIGHTS_TICKET_TRACKER_PROJECT_KEYS:-}" ]; then
        local cfg
        cfg=$(_insights_tp_repo_config_path 2>/dev/null)
        if [ -n "$cfg" ] && [ -f "$cfg" ] && _insights_tp_has_yaml_tool 2>/dev/null; then
            echo "${INSIGHTS_TICKET_TRACKER_PROJECT_KEYS}" | tr ',' '\n' \
                | _insights_tp_write_keys "$cfg" 2>/dev/null || true
        fi
    fi

    config_apply_ticket_tracker
    if [ "${INSIGHTS_TICKET_TRACKER_ENABLED:-}" = "true" ]; then
        apply_tuning jira "$(_insights_tuning_body "${INSIGHTS_JIRA_LOOKBACK_DAYS:-}")" >/dev/null 2>&1 || log_silent "insights: jira tuning apply failed"
    else
        apply_tuning jira "$(_insights_tuning_body "" false)" >/dev/null 2>&1 || log_silent "insights: jira tuning apply failed"
    fi
    print_success "Ticket Tracker credentials updated"
    # The connection is ONE shared cis-config record. Fan the update out to
    # installed plugins that DECLARE this integration in their manifest — each
    # plugin's own onIntegrationUpdate hook does its sync (no plugin specifics here).
    if type _bitoarch_plugin_lifecycle >/dev/null 2>&1; then
        { _bitoarch_plugin_lifecycle && plugin_lifecycle_integration_updated ticket-tracker "${_INSIGHTS_JIRA_INSTANCE_CHANGED:-0}"; } || true
    fi
}

insights_update_docs() {
    local env_file
    env_file=$(get_config_file 2>/dev/null)
    [ -z "$env_file" ] && env_file="${ENV_FILE:-}"

    if ! _config_base_row_exists 2>/dev/null; then
        print_error "No workspace configured yet."
        echo -e "  Run ${YELLOW}bitoarch add-repos${NC} first, then re-run this command."
        return 1
    fi
    if [ "${INSIGHTS_TICKET_TRACKER_ENABLED:-}" != "true" ]; then
        print_error "Enable ticket-tracker first; docs depends on it."
        return 1
    fi
    if [ "${INSIGHTS_DOCS_ENABLED:-}" = "true" ]; then
        export _INSIGHTS_SKIP_ENABLE_PROMPT=1
    fi
    unset INSIGHTS_DOCS_ENABLED
    ask_docs_config
    unset _INSIGHTS_SKIP_ENABLE_PROMPT
    insights_persist_env "$env_file"
    if [ "${INSIGHTS_DOCS_ENABLED:-}" = "true" ]; then
        apply_tuning docs '{"enabled":true}' >/dev/null 2>&1 || log_silent "insights: docs tuning apply failed"
    else
        apply_tuning docs '{"enabled":false}' >/dev/null 2>&1 || log_silent "insights: docs tuning apply failed"
    fi
    config_apply_docs
    print_success "Docs credentials updated"
    # Same shared-record fan-out as ticket-tracker: plugins declaring the docs
    # integration in their manifest sync themselves via onIntegrationUpdate.
    if type _bitoarch_plugin_lifecycle >/dev/null 2>&1; then
        { _bitoarch_plugin_lifecycle && plugin_lifecycle_integration_updated docs; } || true
    fi
}

# ---------------------------------------------------------------------------
# tracker-projects subcommand: list / add / remove / set Jira project keys.
# Mutations land in .bitoarch-config.yaml (the customer-editable file alongside
# their repo namespaces) AND auto-push to cis-config so the user never touches
# yaml directly. Writes are yq-based; falls back to python3+PyYAML when yq is
# absent (matches the rest of the platform's yaml handling).
# ---------------------------------------------------------------------------

_insights_tp_validate_key() {
    [[ "$1" =~ ^[A-Z][A-Z0-9_]+$ ]]
}

_insights_tp_has_yaml_tool() {
    command -v yq >/dev/null 2>&1 && return 0
    command -v python3 >/dev/null 2>&1 && python3 -c "import yaml" 2>/dev/null && return 0
    return 1
}

_insights_tp_require_yaml_tool() {
    if ! _insights_tp_has_yaml_tool; then
        print_error "Need yq or python3+PyYAML to manage project keys; install one and retry."
        return 1
    fi
}

_insights_tp_repo_config_path() {
    if type get_repo_config_file >/dev/null 2>&1; then
        get_repo_config_file 2>/dev/null
    else
        echo ""
    fi
}

# Read current keys from yaml as a newline-separated list. Empty if none.
_insights_tp_read_keys() {
    local f="$1"
    [ -f "$f" ] || return 0
    if command -v yq >/dev/null 2>&1; then
        yq eval '.ticket_tracker.project_keys[]?' "$f" 2>/dev/null
    elif command -v python3 >/dev/null 2>&1 && python3 -c "import yaml" 2>/dev/null; then
        python3 -c "
import yaml, sys
d = yaml.safe_load(open(sys.argv[1])) or {}
for k in (d.get('ticket_tracker') or {}).get('project_keys') or []:
    print(k)
" "$f" 2>/dev/null
    fi
}

# Replace the entire ticket_tracker.project_keys list with the given keys
# (newline-separated on stdin). Creates the block if missing.
_insights_tp_write_keys_impl() {
    local f="$1"
    local keys_csv="$2"

    if command -v yq >/dev/null 2>&1; then
        local arr
        if [ -z "$keys_csv" ]; then
            arr="[]"
        else
            arr=$(echo "$keys_csv" | tr ',' '\n' | jq -R . | jq -s -c .)
        fi
        yq eval -i ".ticket_tracker.project_keys = ${arr}" "$f"
        return $?
    elif command -v python3 >/dev/null 2>&1 && python3 -c "import yaml" 2>/dev/null; then
        python3 - "$f" "$keys_csv" <<'PY'
import sys, yaml
path, csv = sys.argv[1], sys.argv[2]
keys = [k for k in csv.split(',') if k.strip()]
with open(path) as fh:
    data = yaml.safe_load(fh) or {}
tt = data.setdefault('ticket_tracker', {}) or {}
tt['project_keys'] = keys
data['ticket_tracker'] = tt
with open(path, 'w') as fh:
    yaml.safe_dump(data, fh, default_flow_style=False, sort_keys=False)
PY
        return $?
    else
        print_error "Need yq or python3+PyYAML to edit repo config; install one and retry."
        return 1
    fi
}

_insights_tp_write_keys() {
    local f="$1"
    [ -f "$f" ] || { print_error "Repo config not found at $f."; echo -e "  Run ${YELLOW}bitoarch add-repos${NC} first."; return 1; }

    local keys_csv
    keys_csv=$(cat | awk 'NF{gsub(/^ +| +$/,""); print}' | paste -sd, -)

    if type _bitoarch_flock >/dev/null 2>&1; then
        _bitoarch_flock "$f" _insights_tp_write_keys_impl "$f" "$keys_csv"
    else
        _insights_tp_write_keys_impl "$f" "$keys_csv"
    fi
}

# Resolve ticket-tracker credentials: try cis-config, fall back to env vars.
# Sets: _tt_base_url, _tt_email, _tt_token, _tt_host_type in the caller.
_insights_resolve_tt_creds() {
    _tt_base_url="" _tt_email="" _tt_token="" _tt_host_type=""
    if ensure_config_service_accessible 2>/dev/null; then
        local _cfg_url="${CONFIG_URL:-http://localhost:${CIS_CONFIG_EXTERNAL_PORT:-5003}}"
        local _tt
        _tt=$(curl -s -H "Authorization: Bearer $BITO_API_KEY" \
            "${_cfg_url}/api/v1/config/ticket-tracker" 2>/dev/null)
        if [ -n "$_tt" ] && [ "$_tt" != "null" ]; then
            _tt_base_url=$(echo "$_tt" | jq -r '.config.base_url // empty')
            _tt_email=$(echo "$_tt" | jq -r '.config.email // empty')
            # No jq-level default: a record without host_type (older builds) must fall
            # through to the env/file fallbacks below, not silently become "cloud" --
            # the reuse sync would then downgrade a self-hosted connection in the base env.
            _tt_host_type=$(echo "$_tt" | jq -r '.config.host_type // empty')
            local _tok
            _tok=$(curl -s -H "Authorization: Bearer $BITO_API_KEY" \
                "${_cfg_url}/api/v1/config/ticket-tracker/token" 2>/dev/null)
            _tt_token=$(echo "$_tok" | jq -r '.access_token // empty')
        fi
    fi
    [ -z "$_tt_base_url" ] && _tt_base_url="${JIRA_DOMAIN:-}"
    [ -z "$_tt_email" ]    && _tt_email="${JIRA_EMAIL:-}"
    [ -z "$_tt_token" ]    && _tt_token="${JIRA_API_TOKEN:-}"
    [ -z "$_tt_host_type" ] && _tt_host_type="${JIRA_HOST_TYPE:-cloud}"
    # Freshly-captured creds (the plugin connect hook writes the base env from a subshell
    # mid-install) aren't in this process env yet -- read the base .env-bitoarch file last.
    if [ -z "$_tt_base_url" ] && type get_config_file >/dev/null 2>&1; then
        local _benv; _benv="$(get_config_file 2>/dev/null)"
        if [ -n "$_benv" ] && [ -f "$_benv" ]; then
            _tt_base_url="$(sed -n 's/^JIRA_DOMAIN=//p' "$_benv" 2>/dev/null | head -1 | sed 's/^"//;s/"$//')"
            [ -z "$_tt_email" ] && _tt_email="$(sed -n 's/^JIRA_EMAIL=//p' "$_benv" 2>/dev/null | head -1 | sed 's/^"//;s/"$//')"
            [ -z "$_tt_token" ] && _tt_token="$(sed -n 's/^JIRA_API_TOKEN=//p' "$_benv" 2>/dev/null | head -1 | sed 's/^"//;s/"$//')"
            local _ht; _ht="$(sed -n 's/^JIRA_HOST_TYPE=//p' "$_benv" 2>/dev/null | head -1 | sed 's/^"//;s/"$//')"
            [ -n "$_ht" ] && _tt_host_type="$_ht"
        fi
    fi
    return 0
}

# Best-effort: warn if any of the given keys don't exist in Jira.
# Args: KEY [KEY …]. Prints warnings; always returns 0 (never blocks).
_insights_tp_warn_unknown_keys() {
    command -v _insights_fetch_jira_projects >/dev/null 2>&1 || return 0

    local _tt_base_url _tt_email _tt_token _tt_host_type
    _insights_resolve_tt_creds

    [ -z "$_tt_base_url" ] || [ -z "$_tt_email" ] || [ -z "$_tt_token" ] && return 0

    local _valid_keys
    _valid_keys=$(_insights_fetch_jira_projects "$_tt_base_url" "$_tt_email" "$_tt_token" "$_tt_host_type" 2>/dev/null \
        | cut -d'|' -f1)
    [ -z "$_valid_keys" ] && return 0

    local _bad="" _k
    for _k in "$@"; do
        if ! echo "$_valid_keys" | grep -qx "$_k"; then
            _bad="${_bad:+$_bad, }$_k"
        fi
    done
    if [ -n "$_bad" ]; then
        print_error "Not found in ticket tracker: ${_bad}"
        echo -e "  Verify with: ${YELLOW}bitoarch insights discover-tracker-projects${NC}"
        return 1
    fi
}

_insights_tp_list() {
    local cfg="$1"
    local current=""
    if [ -f "$cfg" ]; then
        current=$(_insights_tp_read_keys "$cfg")
    fi
    if [ -z "$current" ] && [ -n "${INSIGHTS_TICKET_TRACKER_PROJECT_KEYS:-}" ]; then
        current=$(echo "${INSIGHTS_TICKET_TRACKER_PROJECT_KEYS}" | tr ',' '\n')
    fi
    if [ -z "$current" ]; then
        print_info "(no project keys configured)"
        echo ""
        echo -e "Add some with: ${YELLOW}bitoarch insights tracker-projects add KEY1 [KEY2 …]${NC}"
    else
        echo "$current"
    fi
}

_insights_tp_add() {
    local cfg="$1"; shift
    if [ "$#" -eq 0 ]; then
        echo -e "Usage: ${YELLOW}bitoarch insights tracker-projects add KEY1 [KEY2 …]${NC}"
        return 1
    fi
    _insights_tp_require_yaml_tool || return 1
    if ! _config_base_row_exists 2>/dev/null; then
        print_error "No workspace configured yet."
        echo -e "  Run ${YELLOW}bitoarch add-repos${NC} first, then re-run this command."
        return 1
    fi
    local k
    for k in "$@"; do
        if ! _insights_tp_validate_key "$k"; then
            print_error "\"$k\" is not a valid project key (uppercase letters, digits, underscores; min 2 chars)"
            return 1
        fi
    done
    _insights_tp_warn_unknown_keys "$@" || return 1
    local current new merged
    current=$(_insights_tp_read_keys "$cfg")
    new=$(printf '%s\n' "$@")
    local _dupes=""
    local _k
    for _k in "$@"; do
        if [ -n "$current" ] && echo "$current" | grep -qx "$_k"; then
            _dupes="${_dupes:+$_dupes,}$_k"
        fi
    done
    merged=$( { printf '%s\n' "$current"; printf '%s\n' "$new"; } \
        | awk 'NF && !seen[$0]++')
    if [ "$merged" = "$current" ]; then
        print_info "All specified keys are already configured — no changes made."
        print_info "Project keys: $(echo "$merged" | paste -sd, -)"
        return 0
    fi
    if [ -n "$_dupes" ]; then
        print_info "Already present (skipped): $_dupes"
    fi
    echo "$merged" | _insights_tp_write_keys "$cfg" || return 1
    INSIGHTS_TICKET_TRACKER_PROJECT_KEYS="$(echo "$merged" | paste -sd, -)"
    export INSIGHTS_TICKET_TRACKER_PROJECT_KEYS
    print_success "Project keys now: ${INSIGHTS_TICKET_TRACKER_PROJECT_KEYS}"
    local env_file
    env_file=$(get_config_file 2>/dev/null)
    [ -z "$env_file" ] && env_file="${ENV_FILE:-}"
    insights_persist_env "$env_file"
    config_apply_ticket_tracker
}

_insights_tp_remove() {
    local cfg="$1"; shift
    if [ "$#" -eq 0 ]; then
        echo -e "Usage: ${YELLOW}bitoarch insights tracker-projects remove KEY1 [KEY2 …]${NC}"
        return 1
    fi
    _insights_tp_require_yaml_tool || return 1
    if ! _config_base_row_exists 2>/dev/null; then
        print_error "No workspace configured yet."
        echo -e "  Run ${YELLOW}bitoarch add-repos${NC} first, then re-run this command."
        return 1
    fi
    local current remaining
    current=$(_insights_tp_read_keys "$cfg")
    if [ -z "$current" ]; then
        print_info "No project keys to remove."
        return 0
    fi
    remaining="$current"
    local _missing=""
    local k
    for k in "$@"; do
        if ! echo "$current" | grep -qx "$k"; then
            _missing="${_missing:+$_missing,}$k"
        fi
        remaining=$(echo "$remaining" | awk -v k="$k" 'NF && $0 != k')
    done
    if [ -n "$_missing" ]; then
        print_info "Not found (skipped): $_missing"
    fi
    echo "$remaining" | _insights_tp_write_keys "$cfg" || return 1
    INSIGHTS_TICKET_TRACKER_PROJECT_KEYS="$(echo "$remaining" | paste -sd, -)"
    export INSIGHTS_TICKET_TRACKER_PROJECT_KEYS
    if [ -z "$remaining" ]; then
        INSIGHTS_TICKET_TRACKER_PROJECT_KEYS=""
        print_success "Project keys now: (none)"
    else
        print_success "Project keys now: ${INSIGHTS_TICKET_TRACKER_PROJECT_KEYS}"
    fi
    local env_file
    env_file=$(get_config_file 2>/dev/null)
    [ -z "$env_file" ] && env_file="${ENV_FILE:-}"
    insights_persist_env "$env_file"
    config_apply_ticket_tracker
}

_insights_tp_set() {
    local cfg="$1"; shift
    if [ "$#" -eq 0 ]; then
        echo -e "Usage: ${YELLOW}bitoarch insights tracker-projects set KEY1 [KEY2 …]${NC}"
        return 1
    fi
    _insights_tp_require_yaml_tool || return 1
    if ! _config_base_row_exists 2>/dev/null; then
        print_error "No workspace configured yet."
        echo -e "  Run ${YELLOW}bitoarch add-repos${NC} first, then re-run this command."
        return 1
    fi
    local k
    for k in "$@"; do
        if ! _insights_tp_validate_key "$k"; then
            print_error "\"$k\" is not a valid project key (uppercase letters, digits, underscores; min 2 chars)"
            return 1
        fi
    done
    _insights_tp_warn_unknown_keys "$@" || return 1
    printf '%s\n' "$@" | _insights_tp_write_keys "$cfg" || return 1
    INSIGHTS_TICKET_TRACKER_PROJECT_KEYS="$(printf '%s\n' "$@" | paste -sd, -)"
    export INSIGHTS_TICKET_TRACKER_PROJECT_KEYS
    print_success "Project keys now: ${INSIGHTS_TICKET_TRACKER_PROJECT_KEYS}"
    local env_file
    env_file=$(get_config_file 2>/dev/null)
    [ -z "$env_file" ] && env_file="${ENV_FILE:-}"
    insights_persist_env "$env_file"
    config_apply_ticket_tracker
}

insights_tracker_projects() {
    local action="${1:-list}"
    shift || true
    local cfg
    cfg=$(_insights_tp_repo_config_path)
    if [ -z "$cfg" ]; then
        print_error "Could not resolve repo config path (path-manager not loaded)."
        return 1
    fi

    case "$action" in
        list|ls)        _insights_tp_list "$cfg" ;;
        add)            _insights_tp_add "$cfg" "$@" ;;
        remove|rm)      _insights_tp_remove "$cfg" "$@" ;;
        set)            _insights_tp_set "$cfg" "$@" ;;
        --help|-h|"")
            cat <<'EOF'
USAGE:
  bitoarch insights tracker-projects [action] [KEY …]

ACTIONS:
  list                 Show currently configured project keys
  add KEY [KEY …]      Add one or more keys (idempotent; preserves existing)
  remove KEY [KEY …]   Remove one or more keys
  set KEY [KEY …]      Replace the entire list with these keys

NOTES:
  - Keys must match project-key format (letters, digits, underscores).
  - Mutations are persisted to .bitoarch-config.yaml and auto-pushed to
    the config service — no separate `apply-tracker-config` needed.
  - Run `bitoarch insights config` to see if ticket-tracker is enabled.
EOF
            ;;
        *)
            print_error "Unknown tracker-projects action: $action"
            echo -e "Run ${YELLOW}bitoarch insights tracker-projects --help${NC} for usage."
            return 1
            ;;
    esac
}

_insights_discover_tracker_projects() {
    _insights_tp_require_yaml_tool || return 1

    local _tt_base_url _tt_email _tt_token _tt_host_type
    _insights_resolve_tt_creds

    if [ -z "$_tt_base_url" ] || [ -z "$_tt_email" ] || [ -z "$_tt_token" ]; then
        print_error "Ticket tracker not configured (missing URL, email, or token)."
        echo -e "  Run ${YELLOW}bitoarch insights enable ticket-tracker${NC} first."
        return 1
    fi

    print_info "Fetching project list... (this may take a few seconds)"
    local project_list
    project_list=$(_insights_fetch_jira_projects "$_tt_base_url" "$_tt_email" "$_tt_token" "$_tt_host_type")
    if [ -z "$project_list" ]; then
        print_error "Could not fetch projects from ticket tracker."
        echo -e "  Check credentials with: ${YELLOW}bitoarch insights config${NC}"
        return 1
    fi

    local project_count
    project_count=$(echo "$project_list" | wc -l | tr -d ' ')
    print_info "Found ${project_count} projects accessible with your credentials."

    echo ""
    local current_keys=""
    local cfg
    cfg=$(_insights_tp_repo_config_path 2>/dev/null)
    if [ -n "$cfg" ] && [ -f "$cfg" ]; then
        current_keys=$(_insights_tp_read_keys "$cfg" 2>/dev/null | paste -sd, -)
    fi

    echo "$project_list" | while IFS='|' read -r key name; do
        [ -z "$key" ] && continue
        local _marker="  "
        if [ -n "$current_keys" ] && echo ",$current_keys," | grep -q ",$key,"; then
            _marker="* "
        fi
        printf "  %s%-12s %s\n" "$_marker" "$key" "$name"
    done
    [ -n "$current_keys" ] && echo "  (* = currently selected)"
}

# ---------------------------------------------------------------------------
# Env persistence — shared by both setup.sh (install-time) and CLI subcommands.
# ---------------------------------------------------------------------------

_insights_persist_env_impl() {
    local env_file="$1"
    local tmpfile="${env_file}.tmp.$$"

    export INSIGHTS_TICKET_TRACKER_AUTH_TYPE="${INSIGHTS_TICKET_TRACKER_AUTH_TYPE:-api-token}"
    export INSIGHTS_DOCS_AUTH_TYPE="${INSIGHTS_DOCS_AUTH_TYPE:-api-token}"
    # Plugins consume the connection as jira.is.self.hosted (true|false); derive it from the
    # canonical JIRA_HOST_TYPE (cloud|self) so the shared base env carries both forms.
    case "${JIRA_HOST_TYPE:-}" in self|self-hosted|server) export JIRA_IS_SELF_HOSTED=true ;; *) export JIRA_IS_SELF_HOSTED=false ;; esac
    # cis-manager's Google Docs ingestion kill-switch follows the CLI toggle.
    export GOOGLE_DOCS_INGESTION_ENABLED="${INSIGHTS_DOCS_GOOGLE_ENABLED:-}"

    awk 'BEGIN { n = split("INSIGHTS_GIT_ENABLED INSIGHTS_TICKET_TRACKER_ENABLED INSIGHTS_TICKET_TRACKER_PROVIDER JIRA_DOMAIN JIRA_EMAIL JIRA_API_TOKEN JIRA_HOST_TYPE JIRA_IS_SELF_HOSTED INSIGHTS_TICKET_TRACKER_AUTH_TYPE INSIGHTS_TICKET_TRACKER_PROJECT_KEYS INSIGHTS_DOCS_ENABLED INSIGHTS_DOCS_PROVIDER INSIGHTS_DOCS_URL INSIGHTS_DOCS_EMAIL INSIGHTS_DOCS_API_TOKEN INSIGHTS_DOCS_AUTH_TYPE INSIGHTS_GIT_LOOKBACK_DAYS INSIGHTS_JIRA_LOOKBACK_DAYS INSIGHTS_SETUP_COMPLETE", keys)
            for (i=1; i<=n; i++) { lookup[keys[i]]=1; found[keys[i]]=0 }
            # Provider-specific fields: update if already present, but never auto-append
            # when empty (keeps confluence installs free of blank google_docs lines
            # and vice versa; per-provider toggles + google_docs secrets persist only when actually set).
            cn = split("JIRA_CLOUD_ID INSIGHTS_DOCS_CONFLUENCE_ENABLED INSIGHTS_DOCS_GOOGLE_ENABLED GOOGLE_DOCS_INGESTION_ENABLED INSIGHTS_DOCS_CLOUD_ID INSIGHTS_DOCS_CLIENT_ID INSIGHTS_DOCS_CLIENT_SECRET INSIGHTS_DOCS_REFRESH_TOKEN", ckeys)
            for (i=1; i<=cn; i++) { conditional[ckeys[i]]=1; cfound[ckeys[i]]=0 } }
        { for (k in conditional) { if ($0 ~ "^"k"=") { cfound[k]=1; if (ENVIRON[k] != "") { print k"="ENVIRON[k] } next } }
          for (k in lookup) { if ($0 ~ "^"k"=") { print k"="ENVIRON[k]; found[k]=1; next } }; print }
        END { for (i=1; i<=n; i++) { if (!found[keys[i]]) print keys[i]"="ENVIRON[keys[i]] }
              for (i=1; i<=cn; i++) { if (!cfound[ckeys[i]] && ENVIRON[ckeys[i]] != "") print ckeys[i]"="ENVIRON[ckeys[i]] } }' \
        "$env_file" > "$tmpfile" || { rm -f "$tmpfile"; return 1; }
    mv "$tmpfile" "$env_file"
}

insights_persist_env() {
    local env_file="$1"
    [ -z "$env_file" ] || [ ! -f "$env_file" ] && return 1

    if type _bitoarch_flock >/dev/null 2>&1; then
        _bitoarch_flock "$env_file" _insights_persist_env_impl "$env_file"
    else
        _insights_persist_env_impl "$env_file"
    fi
}

export -f _insights_config_from_env
export -f _insights_persist_env_impl
export -f insights_persist_env
export -f handle_insights
export -f insights_run
export -f insights_config
export -f _print_insights_row
export -f insights_status
export -f _render_insights_feature
export -f insights_enable
export -f insights_disable
export -f insights_set_lookback
export -f insights_update_ticket_tracker
export -f insights_update_docs
export -f _insights_mask
export -f _is_any_insights_enabled
export -f _insights_analysis_running
export -f _insights_post_enable_hint
export -f insights_tracker_projects
export -f _insights_tp_list
export -f _insights_tp_add
export -f _insights_tp_remove
export -f _insights_tp_set
export -f _insights_discover_tracker_projects
export -f _insights_tp_validate_key
export -f _insights_tp_has_yaml_tool
export -f _insights_tp_require_yaml_tool
export -f _insights_tp_repo_config_path
export -f _insights_tp_read_keys
export -f _insights_tp_write_keys_impl
export -f _insights_tp_write_keys
export -f _insights_tp_warn_unknown_keys
export -f _insights_resolve_tt_creds
