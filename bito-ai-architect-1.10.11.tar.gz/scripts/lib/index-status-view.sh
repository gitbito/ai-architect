#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
#
# Bito's AI Architect CLI - index-status presentation layer
#
# Turns the CIS Manager indexing-status payload into what an operator reads:
# the per-repo table, the --failures and --in-progress views, the session list,
# and the CSV export used above INDEX_STATUS_TABLE_MAX_ROWS rows.
#
# Kept out of manager-adapter.sh so that file stays the HTTP layer: rendering
# is where this feature grows, and the adapter is already large.

if [ -n "${_BITOARCH_INDEX_STATUS_VIEW_LOADED:-}" ]; then
    return 0
fi
_BITOARCH_INDEX_STATUS_VIEW_LOADED=1

_INDEX_STATUS_VIEW_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Canonical redactor. Error messages carry git and indexer stderr, which embeds
# the authenticated clone URL. The producer redacts too, but the CLI prints to a
# terminal and writes CSV files to disk, so it must not depend on that.
if ! type mask_stream >/dev/null 2>&1; then
    # shellcheck source=/dev/null
    . "${_INDEX_STATUS_VIEW_DIR}/diagnose/mask-secrets.sh" 2>/dev/null || true
fi

# _index_status_redact filters a TSV stream through the canonical redactor.
# Every row-producing function below pipes through it, so the table, the
# --failures view and the CSV export are covered at one choke point rather than
# each render path remembering.
#
# Falls back to an inline pattern set when the diagnose helpers are unavailable
# (a trimmed install): failing closed and printing nothing would be worse than
# printing redacted text, but silently printing raw tokens is not acceptable.
_index_status_redact() {
    # The URL rule runs unconditionally: the canonical redactor matches known
    # token *prefixes*, so a provider credential with no recognisable shape
    # (a Bitbucket app password, a generic PAT) would otherwise stay in the
    # "scheme://user:secret@host" form git prints. Stripping the whole userinfo
    # segment does not depend on recognising the token.
    if type mask_stream >/dev/null 2>&1; then
        sed -E 's#(https?://)[^/[:space:]@]+@#\1***REDACTED***@#g' | mask_stream
        return 0
    fi
    sed -E \
        -e 's#(https?://)[^/[:space:]@]+@#\1***REDACTED***@#g' \
        -e 's/(glpat-|gh[pousr]_|github_pat_|xox[abprs]-)[A-Za-z0-9_-]{8,}/\1***REDACTED***/g' \
        -e 's/(AKIA|ASIA)[A-Z0-9]{16}/\1***REDACTED***/g' \
        -e 's/(Bearer[[:space:]]+)[A-Za-z0-9._-]{8,}/\1***REDACTED***/gI'
}

# Column width caps. Repo names and error messages are unbounded; without caps
# one long value pushes every other column off screen.
_INDEX_STATUS_MAX_REPO_WIDTH=44
_INDEX_STATUS_MAX_MSG_WIDTH=60

# ─── Row extraction ──────────────────────────────────────────────────────

# Emit one TSV row per repository: repo, outcome, stage, failed_count,
# error_code, message. Used by the default and --in-progress views.
#
# Args: response JSON, filter (all|failures|in-progress)
index_status_repo_rows() {
    local response="$1" filter="${2:-all}"

    echo "$response" | jq -r --arg filter "$filter" '
        def keep(d):
            if $filter == "failures" then
                (d.outcome == "failure") or ((d.failed_event_details // []) | length > 0)
            elif $filter == "in-progress" then
                d.outcome == "in_progress"
            else true end;

        (.repositories // [])
        | map(select(.repo_name != null and .repo_name != ""))
        | map(. as $r | ($r.details // {}) as $d | select(keep($d))
            | [ $r.repo_name,
                ($d.outcome // "unknown"),
                ($d.stage // ""),
                (($d.failed_event_details // []) | length | tostring),
                ((($d.failed_event_details // [])[0].error_code) // ""),
                ((($d.failed_event_details // [])[0].message) // "")
              ])
        | .[] | @tsv
    ' 2>/dev/null | _index_status_redact
}

# Emit one TSV row per errored event:
#   repo, outcome, stage, event, error_code, message
#
# This is the --failures view: the requirement is the failing repos AND the
# events that errored, each with its reason, not one headline error per repo.
#
# outcome is the server's own classification, carried through rather than
# assumed: an event can record a coded failure (an INSUFFICIENT_DISK skip, say)
# on a repository the server still classifies success, and the CLI must not
# reclassify it.
index_status_failure_rows() {
    local response="$1"

    echo "$response" | jq -r '
        (.repositories // [])
        | map(select(.repo_name != null and .repo_name != ""))
        | map(. as $r | ($r.details // {}) as $d
            | (($d.failed_event_details // []) | map([
                  $r.repo_name,
                  ($d.outcome // "unknown"),
                  (.stage // $d.stage // ""),
                  (.event // ""),
                  (.error_code // ""),
                  ((.message // "") | gsub("[\n\r\t]+"; " "))
              ])))
        | add // []
        | .[] | @tsv
    ' 2>/dev/null | _index_status_redact
}

# Workspace-level failures (linking, clustering, tfidf) are reported separately
# from repos because they are not attributable to one repository.
index_status_workspace_failure_rows() {
    local response="$1"

    echo "$response" | jq -r '
        ((.workspace_level_index // {}) | .failed_event_details // [])
        | map([ (.event // ""), (.error_code // ""),
                ((.message // "") | gsub("[\n\r\t]+"; " ")) ])
        | .[] | @tsv
    ' 2>/dev/null | _index_status_redact
}

# ─── Rendering ───────────────────────────────────────────────────────────

# Truncate a value to a width, marking the cut so a clipped repo name is not
# mistaken for a different repo.
_index_status_clip() {
    local value="$1" width="$2"
    if [ "${#value}" -le "$width" ]; then
        printf '%s' "$value"
        return 0
    fi
    printf '%s...' "${value:0:$((width - 3))}"
}

# Widest value in a TSV column (1-based), floored at the header's own width.
_index_status_col_width() {
    local rows="$1" col="$2" min="$3" cap="$4"
    local width="$min" value
    while IFS= read -r line; do
        [ -n "$line" ] || continue
        value=$(printf '%s' "$line" | cut -f"$col")
        [ "${#value}" -gt "$width" ] && width="${#value}"
    done <<EOF
$rows
EOF
    [ "$width" -gt "$cap" ] && width="$cap"
    echo "$width"
}

# Colour an outcome consistently with the rest of the CLI's state wording.
_index_status_outcome_label() {
    case "$1" in
        success)     printf '%b' "${GREEN}success${NC}" ;;
        failure)     printf '%b' "${RED}failure${NC}" ;;
        in_progress) printf '%b' "${YELLOW}in progress${NC}" ;;
        *)           printf '%s' "$1" ;;
    esac
}

# Render the per-repo table: repo, outcome, stage, failed-event count.
render_index_status_repo_table() {
    local rows="$1"
    local repo_w stage_w
    repo_w=$(_index_status_col_width "$rows" 1 12 "$_INDEX_STATUS_MAX_REPO_WIDTH")
    stage_w=$(_index_status_col_width "$rows" 3 10 24)

    printf "  ${BOLD}%-${repo_w}s  %-13s  %-${stage_w}s  %s${NC}\n" "REPOSITORY" "OUTCOME" "STAGE" "ERRORS"

    local repo outcome stage failed
    while IFS=$'\t' read -r repo outcome stage failed _code _message; do
        [ -n "$repo" ] || continue
        printf "  %-${repo_w}s  %-22b  %-${stage_w}s  %s\n" \
            "$(_index_status_clip "$repo" "$repo_w")" \
            "$(_index_status_outcome_label "$outcome")" \
            "$(_index_status_clip "$stage" "$stage_w")" \
            "$failed"
    done <<EOF
$rows
EOF
}

# Render the --failures view: one line per repo, then one indented line per
# errored event with its code and reason.
render_index_status_failures() {
    local rows="$1"
    local current_repo="" repo outcome stage event code message

    while IFS=$'\t' read -r repo outcome stage event code message; do
        [ -n "$repo" ] || continue
        if [ "$repo" != "$current_repo" ]; then
            [ -n "$current_repo" ] && echo ""
            current_repo="$repo"
            printf "  ${RED}%s${NC}" "$repo"
            [ -n "$stage" ] && printf "  ${BLUE}(stopped at: %s)${NC}" "$stage"
            printf "\n"
        fi
        printf "      %-28s %-26s %s\n" \
            "$(_index_status_clip "$event" 28)" \
            "${code:-—}" \
            "$(_index_status_clip "$message" "$_INDEX_STATUS_MAX_MSG_WIDTH")"
    done <<EOF
$rows
EOF
}

# Render the --in-progress view: which stage each unfinished repo is executing.
render_index_status_in_progress() {
    local rows="$1"
    local repo_w
    repo_w=$(_index_status_col_width "$rows" 1 12 "$_INDEX_STATUS_MAX_REPO_WIDTH")

    printf "  ${BOLD}%-${repo_w}s  %s${NC}\n" "REPOSITORY" "CURRENT STAGE"

    local repo stage
    while IFS=$'\t' read -r repo _outcome stage _failed _code _message; do
        [ -n "$repo" ] || continue
        printf "  %-${repo_w}s  %s\n" \
            "$(_index_status_clip "$repo" "$repo_w")" \
            "${stage:-unknown}"
    done <<EOF
$rows
EOF
}

# ─── CSV export ──────────────────────────────────────────────────────────

# Quote a CSV field per RFC 4180: wrap in quotes and double any embedded quote.
# Error messages routinely contain commas and quotes.
#
# A leading =, +, - or @ is also prefixed with an apostrophe: these fields carry
# git and zoekt stderr and provider-supplied repository names, so the content is
# attacker-influenceable, and a spreadsheet evaluates such a value as a formula
# when the export is opened.
_index_status_csv_field() {
    local value="$1"
    case "$value" in
        [=+@-]*) value="'${value}" ;;
    esac
    value="${value//\"/\"\"}"
    printf '"%s"' "$value"
}

# Write the repo-level CSV.
#
# One row per repository, plus one row per errored event so a repo with three
# failures contributes three rows. A single schema covers both the clean and
# the failing case: the event columns are simply empty when a repo has no
# errors, which keeps the file pivotable in a spreadsheet.
#
# Written atomically (temp + mv) so an interrupted run never leaves a partial
# CSV that looks complete.
write_index_status_csv() {
    local repo_rows="$1" failure_rows="$2" target="$3"
    local tmp="${target}.tmp.$$"

    local dir
    dir="$(dirname "$target")"
    if ! mkdir -p "$dir" 2>/dev/null; then
        print_error "Cannot create report directory: $dir"
        return 1
    fi

    {
        echo "repo,outcome,stage,event,error_code,error_message"

        local repo outcome stage failed
        while IFS=$'\t' read -r repo outcome stage failed _code _message; do
            [ -n "$repo" ] || continue
            if [ "${failed:-0}" -eq 0 ] 2>/dev/null; then
                printf '%s,%s,%s,,,\n' \
                    "$(_index_status_csv_field "$repo")" \
                    "$(_index_status_csv_field "$outcome")" \
                    "$(_index_status_csv_field "$stage")"
            fi
        done <<REPOROWS
$repo_rows
REPOROWS

        local f_repo f_outcome f_stage f_event f_code f_message
        while IFS=$'\t' read -r f_repo f_outcome f_stage f_event f_code f_message; do
            [ -n "$f_repo" ] || continue
            printf '%s,%s,%s,%s,%s,%s\n' \
                "$(_index_status_csv_field "$f_repo")" \
                "$(_index_status_csv_field "$f_outcome")" \
                "$(_index_status_csv_field "$f_stage")" \
                "$(_index_status_csv_field "$f_event")" \
                "$(_index_status_csv_field "$f_code")" \
                "$(_index_status_csv_field "$f_message")"
        done <<FAILROWS
$failure_rows
FAILROWS
    } > "$tmp" 2>/dev/null || {
        rm -f "$tmp" 2>/dev/null
        print_error "Failed to write CSV: $target"
        return 1
    }

    if ! mv "$tmp" "$target" 2>/dev/null; then
        rm -f "$tmp" 2>/dev/null
        print_error "Failed to finalize CSV: $target"
        return 1
    fi
    return 0
}

# Default CSV path for a session, timestamped so repeated runs do not overwrite
# each other.
index_status_csv_path() {
    local session_id="$1"
    local short="${session_id:0:8}"
    [ -n "$short" ] || short="latest"
    echo "$(get_reports_dir)/index-status-${short}-$(date +%Y%m%d-%H%M%S).csv"
}

# Count non-empty TSV rows.
index_status_row_count() {
    local rows="$1"
    [ -n "$rows" ] || { echo 0; return 0; }
    printf '%s\n' "$rows" | grep -c '[^[:space:]]'
}

# ─── Session views ───────────────────────────────────────────────────────

# Render the session header shown above every repo view.
render_index_session_header() {
    local response="$1"
    local session_id is_latest started ended

    session_id=$(echo "$response" | jq -r '.session_id // ""')
    [ -n "$session_id" ] || return 0

    is_latest=$(echo "$response" | jq -r '.is_latest_session // false')
    started=$(echo "$response" | jq -r '.session_started_at // ""')
    ended=$(echo "$response" | jq -r '.session_ended_at // ""')

    echo -e "${BLUE}Index Session${NC}"
    echo ""
    if [ "$is_latest" = "true" ]; then
        echo "  Session:  ${session_id} (latest)"
    else
        echo "  Session:  ${session_id}"
    fi
    [ -n "$started" ] && echo "  Started:  ${started}"
    if [ -n "$ended" ]; then
        echo "  Ended:    ${ended}"
    else
        echo "  Ended:    —  (not recorded; run may still be in progress)"
    fi
    echo ""
}

# Render the session list from GET /api/v3/index-sessions.
render_index_sessions() {
    local response="$1"
    local rows
    rows=$(echo "$response" | jq -r '
        (.sessions // [])
        | map([ .session_id, (.started_at // ""), (.ended_at // "—"),
                (.status // "unknown"), ((.repo_count // 0) | tostring) ])
        | .[] | @tsv
    ' 2>/dev/null)

    if [ -z "$rows" ]; then
        print_info "No index sessions recorded for this workspace yet."
        return 0
    fi

    echo ""
    echo -e "${BLUE}Recent Index Sessions${NC}"
    echo ""
    printf "  ${BOLD}%-38s  %-22s  %-22s  %-12s  %s${NC}\n" \
        "SESSION" "STARTED" "ENDED" "STATUS" "REPOS"

    local session_id started ended status repos
    while IFS=$'\t' read -r session_id started ended status repos; do
        [ -n "$session_id" ] || continue
        printf "  %-38s  %-22s  %-22s  %-12s  %s\n" \
            "$session_id" "$started" "$ended" "$status" "$repos"
    done <<EOF
$rows
EOF
    echo ""
}

# Render the audit entries from GET /api/v3/index-sessions/{id}/events.
render_index_session_events() {
    local response="$1"
    local rows
    rows=$(echo "$response" | jq -r '
        (.events // [])
        | map([ (.created_at // ""), (.repo // "—"), (.event // ""),
                (.status // ""), (.error_code // ""),
                ((.message // "") | gsub("[\n\r\t]+"; " ")) ])
        | .[] | @tsv
    ' 2>/dev/null | _index_status_redact)

    if [ -z "$rows" ]; then
        print_info "No audit entries for this session."
        return 0
    fi

    echo ""
    echo -e "${BLUE}Session Events${NC}"
    echo ""
    printf "  ${BOLD}%-22s  %-30s  %-26s  %-10s  %s${NC}\n" \
        "TIME" "REPOSITORY" "EVENT" "STATUS" "REASON"

    local at repo event status code message detail
    while IFS=$'\t' read -r at repo event status code message; do
        [ -n "$at" ] || continue
        detail="$message"
        [ -n "$code" ] && detail="${code}: ${message}"
        printf "  %-22s  %-30s  %-26s  %-10s  %s\n" \
            "$at" \
            "$(_index_status_clip "$repo" 30)" \
            "$(_index_status_clip "$event" 26)" \
            "$status" \
            "$(_index_status_clip "$detail" "$_INDEX_STATUS_MAX_MSG_WIDTH")"
    done <<EOF
$rows
EOF
    echo ""
}

export -f index_status_repo_rows index_status_failure_rows
export -f index_status_workspace_failure_rows
export -f render_index_status_repo_table render_index_status_failures
export -f render_index_status_in_progress
export -f write_index_status_csv index_status_csv_path index_status_row_count
export -f render_index_session_header render_index_sessions render_index_session_events

# ─── Composite views ─────────────────────────────────────────────────────

# Decide between terminal table and CSV file for a set of rows, then emit it.
#
# force_table wins over the threshold, and an explicit --csv target forces CSV
# at any row count. Otherwise rows above INDEX_STATUS_TABLE_MAX_ROWS go to a
# file so the summary stays readable.
#
# Args: renderer fn, repo_rows, failure_rows, rows_to_count, session_id,
#       csv_target, force_csv, force_table
index_status_emit() {
    local renderer="$1" repo_rows="$2" failure_rows="$3" counted_rows="$4"
    local session_id="$5" csv_target="$6" force_csv="$7" force_table="$8"

    local count
    count=$(index_status_row_count "$counted_rows")

    if [ "$count" -eq 0 ]; then
        return 0
    fi

    local use_csv=false
    if [ "$force_csv" = "true" ] || [ -n "$csv_target" ]; then
        use_csv=true
    elif [ "$force_table" != "true" ] && [ "$count" -gt "${INDEX_STATUS_TABLE_MAX_ROWS:-25}" ]; then
        use_csv=true
    fi

    if [ "$use_csv" != "true" ]; then
        "$renderer" "$counted_rows"
        return 0
    fi

    [ -n "$csv_target" ] || csv_target="$(index_status_csv_path "$session_id")"
    if ! write_index_status_csv "$repo_rows" "$failure_rows" "$csv_target"; then
        return 1
    fi

    echo ""
    print_success "${count} rows exported to CSV"
    echo "  File: ${csv_target}"
    echo ""
    echo -e "  ${BLUE}Note:${NC} more than ${INDEX_STATUS_TABLE_MAX_ROWS:-25} rows to show."
    echo -e "  Use ${YELLOW}--all${NC} to print the full table instead."
}

# Render the filtered --failures / --in-progress view: session header, a
# one-line count, then only the rows asked for. The full state blocks are
# deliberately skipped -- these flags exist to cut the output down.
render_index_status_filtered() {
    local response="$1" filter="$2" csv_target="$3" force_csv="$4" force_table="$5"
    local session_id rows failure_rows

    session_id=$(echo "$response" | jq -r '.session_id // ""' 2>/dev/null)
    render_index_session_header "$response"

    rows=$(index_status_repo_rows "$response" "$filter")
    failure_rows=$(index_status_failure_rows "$response")

    if [ "$filter" = "failures" ]; then
        local repo_count
        repo_count=$(index_status_row_count "$rows")
        if [ "$repo_count" -eq 0 ]; then
            print_success "No repository failures in this session."
            _render_workspace_failures "$response"
            return 0
        fi
        echo -e "${BLUE}Failed Repositories${NC} (${repo_count})"
        echo ""
        # Counted and exported on the per-event rows: that is what is shown.
        # Passing no repo-level rows keeps the CSV to the filtered set instead
        # of re-adding a row per repository.
        index_status_emit render_index_status_failures \
            "" "$failure_rows" "$failure_rows" \
            "$session_id" "$csv_target" "$force_csv" "$force_table"
        _render_workspace_failures "$response"
        return 0
    fi

    local in_progress_count
    in_progress_count=$(index_status_row_count "$rows")
    if [ "$in_progress_count" -eq 0 ]; then
        print_info "No repositories are currently indexing in this session."
        return 0
    fi
    echo -e "${BLUE}Indexing In Progress${NC} (${in_progress_count})"
    echo ""
    # No failure rows: exporting them here would put back exactly the
    # repositories --in-progress filtered out, credentials and all.
    index_status_emit render_index_status_in_progress \
        "$rows" "" "$rows" \
        "$session_id" "$csv_target" "$force_csv" "$force_table"
}

# Workspace-level failures are shown after the repo list: linking or clustering
# failing is a workspace fault, not one repository's.
_render_workspace_failures() {
    local response="$1"
    local ws_rows
    ws_rows=$(index_status_workspace_failure_rows "$response")
    [ -n "$ws_rows" ] || return 0

    echo ""
    echo -e "${BLUE}Workspace-Level Failures${NC}"
    echo ""
    local event code message
    while IFS=$'\t' read -r event code message; do
        [ -n "$event" ] || continue
        printf "      %-28s %-26s %s\n" \
            "$(_index_status_clip "$event" 28)" \
            "${code:-—}" \
            "$(_index_status_clip "$message" "$_INDEX_STATUS_MAX_MSG_WIDTH")"
    done <<WSROWS
$ws_rows
WSROWS
    echo ""
}

# Repo table embedded in the default status output.
_render_index_status_repo_block() {
    local response="$1"
    local rows failure_rows session_id

    command -v jq >/dev/null 2>&1 || return 0

    rows=$(index_status_repo_rows "$response" "all")
    [ -n "$rows" ] || return 0
    failure_rows=$(index_status_failure_rows "$response")
    session_id=$(echo "$response" | jq -r '.session_id // ""' 2>/dev/null)

    echo ""
    echo -e "${BLUE}Repositories${NC}"
    echo ""
    index_status_emit render_index_status_repo_table \
        "$rows" "$failure_rows" "$rows" \
        "$session_id" "${_INDEX_STATUS_CSV_TARGET:-}" \
        "${_INDEX_STATUS_FORCE_CSV:-false}" "${_INDEX_STATUS_FORCE_TABLE:-false}"
    echo ""
}

export -f index_status_emit render_index_status_filtered
export -f _render_workspace_failures _render_index_status_repo_block
