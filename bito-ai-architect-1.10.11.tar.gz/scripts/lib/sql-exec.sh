#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
# Bito's AI Architect CLI - Shared MySQL query execution
# Read-only SQL access to the platform MySQL for CLI commands, working in
# both Docker Compose (docker exec) and Kubernetes (kubectl exec) deployments.

# Include guard
if [ -n "${_BITOARCH_SQL_EXEC_LOADED:-}" ]; then
    return 0
fi
_BITOARCH_SQL_EXEC_LOADED=1

# Cheap pre-flight so callers can degrade gracefully (skip a verification
# step, ask for explicit input) instead of failing mid-flow: credentials
# present and the MySQL container/CLI is reachable for this deployment type.
sql_exec_ready() {
    [ -n "${MYSQL_ROOT_PASSWORD:-}" ] || return 1
    if type is_kubernetes_deployment >/dev/null 2>&1 && is_kubernetes_deployment; then
        command -v kubectl >/dev/null 2>&1 || return 1
    else
        command -v docker >/dev/null 2>&1 || return 1
        docker inspect "${SERVICE_MYSQL_NAME:-ai-architect-mysql}" >/dev/null 2>&1 || return 1
    fi
    return 0
}

# Run one SQL statement and print raw rows (tab-separated, no header).
# Empty output with rc 0 means "no rows"; a non-zero rc means the query could
# not be executed — callers must not treat the two the same.
# Usage: sql_exec_query <database> <sql>
sql_exec_query() {
    local db="$1" sql="$2"
    local pass="${MYSQL_ROOT_PASSWORD:-}"
    if [ -z "$db" ] || [ -z "$sql" ] || [ -z "$pass" ]; then
        return 1
    fi
    if type is_kubernetes_deployment >/dev/null 2>&1 && is_kubernetes_deployment; then
        _sql_exec_k8s "$pass" "$db" "$sql"
    else
        _sql_exec_docker "$pass" "$db" "$sql"
    fi
}

# MYSQL_PWD suppresses the password-on-command-line warning; -N -B yields
# bare tab-separated rows for machine consumption.
_sql_exec_docker() {
    local pass="$1" db="$2" sql="$3"
    docker exec -i -e MYSQL_PWD="$pass" "${SERVICE_MYSQL_NAME:-ai-architect-mysql}" \
        mysql -u root -N -B -e "$sql" "$db" 2>/dev/null
}

_sql_exec_k8s() {
    local pass="$1" db="$2" sql="$3"
    local ns="${BITOARCH_K8S_NAMESPACE:-bito-ai-architect}"
    local pod
    pod=$(kubectl get pods -n "$ns" \
        -l "app.kubernetes.io/component=mysql" \
        -o jsonpath='{.items[0].metadata.name}' 2>/dev/null)
    [ -z "$pod" ] && return 1
    # kubectl exec has no --env flag; pass MYSQL_PWD via in-container env prefix.
    kubectl exec -n "$ns" "$pod" -- \
        env MYSQL_PWD="$pass" mysql -u root -N -B -e "$sql" "$db" 2>/dev/null
}

export -f sql_exec_ready
export -f sql_exec_query
export -f _sql_exec_docker
export -f _sql_exec_k8s
