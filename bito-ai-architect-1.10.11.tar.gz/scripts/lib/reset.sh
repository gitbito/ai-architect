#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
#
# Shared reset: stop services, remove volumes, clear data dirs, delete
# configs, reset install.yaml to the blank template. Called by setup.sh
# --clean and scripts/lib/uninstall.sh. Dependencies are guarded so the
# lib works whether or not setup.sh's environment is loaded.

if [ -n "${_BITOARCH_RESET_LIB_LOADED:-}" ]; then
    return 0
fi
_BITOARCH_RESET_LIB_LOADED=1

# Derive PLATFORM_DIR from this file's location if caller didn't set it.
if [ -z "${PLATFORM_DIR:-}" ]; then
    PLATFORM_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
fi

# Ensure path-manager is available (get_config_file et al.).
if ! command -v get_config_file >/dev/null 2>&1; then
    if [ -f "${PLATFORM_DIR}/scripts/lib/path-manager.sh" ]; then
        # shellcheck disable=SC1091
        source "${PLATFORM_DIR}/scripts/lib/path-manager.sh"
    fi
fi

# Fallback log helpers when cli-core.sh hasn't been sourced (CDN uninstall).
if ! command -v print_info >/dev/null 2>&1; then
    print_info()    { echo "[INFO] $*"    >&2; }
    print_warning() { echo "[WARN] $*"    >&2; }
    print_error()   { echo "[ERROR] $*"   >&2; }
fi
if ! command -v log_silent >/dev/null 2>&1; then
    log_silent()    { :; }
fi

# v2 plugin preferred; respects already-exported DOCKER_COMPOSE_CMD.
_reset_detect_compose_cmd() {
    if [ -n "${DOCKER_COMPOSE_CMD:-}" ]; then
        echo "$DOCKER_COMPOSE_CMD"
        return 0
    fi
    if command -v docker >/dev/null 2>&1 && docker compose version >/dev/null 2>&1; then
        echo "docker compose"
        return 0
    fi
    if command -v docker-compose >/dev/null 2>&1; then
        echo "docker-compose"
        return 0
    fi
    return 1
}

# Runtimes to tear down: the marker's answer PLUS whatever is actually live.
# The marker file is itself deleted by a purge, so a missing or stale marker
# must never leave a running deployment behind (an orphaned k8s namespace
# survives a docker-mode purge otherwise). One runtime per line.
_reset_detect_runtimes() {
    local marked=""
    command -v get_deployment_type >/dev/null 2>&1 && marked="$(get_deployment_type 2>/dev/null)"

    local k8s=0 dkr=0
    [ "$marked" = "kubernetes" ] && k8s=1
    if command -v kubectl >/dev/null 2>&1 \
       && kubectl get namespace "${BITOARCH_K8S_NAMESPACE:-bito-ai-architect}" >/dev/null 2>&1; then
        k8s=1
    fi
    if command -v docker >/dev/null 2>&1 && docker info >/dev/null 2>&1; then
        # Containers, the network, or named volumes: any of them means docker
        # artifacts exist (a keep-uninstall leaves volumes with nothing running).
        if [ -n "$(docker ps -aq -f name='^ai-architect-' 2>/dev/null)" ] \
           || docker network inspect ai-architect-network >/dev/null 2>&1 \
           || [ -n "$(docker volume ls -q 2>/dev/null | grep -E '(^|_)ai_architect_')" ]; then
            dkr=1
        fi
    fi
    # Nothing live and nothing marked kubernetes: keep the historical docker
    # default so the name-based container/volume sweep still runs.
    if [ "$k8s" -eq 0 ] && [ "$dkr" -eq 0 ]; then
        case "$marked" in kubernetes) k8s=1 ;; *) dkr=1 ;; esac
    fi
    [ "$k8s" -eq 1 ] && echo "kubernetes"
    [ "$dkr" -eq 1 ] && echo "docker"
    return 0
}

_reset_stop_services() {
    local deployment="${1:-docker}"

    if [ "$deployment" = "kubernetes" ]; then
        local ns="${BITOARCH_K8S_NAMESPACE:-bito-ai-architect}"
        if ! command -v uninstall_helm_release >/dev/null 2>&1; then
            [ -f "${PLATFORM_DIR}/scripts/kubernetes-manager.sh" ] && \
                source "${PLATFORM_DIR}/scripts/kubernetes-manager.sh" 2>/dev/null || true
        fi
        if command -v uninstall_helm_release >/dev/null 2>&1; then
            uninstall_helm_release "$ns" "bitoarch" "true"
        else
            print_warning "Kubernetes deployment detected but helm helper not loaded; skipping."
        fi
        # A reset is a blank slate: sweep any release still in the namespace
        # (the journal-based plugin pass can't run once a prior purge removed
        # the journal), then drop the namespace itself so non-helm resources
        # (jobs, cronjobs, patched ingress, PVCs) go with it. The installer
        # recreates it (helm --create-namespace).
        if command -v helm >/dev/null 2>&1; then
            local rel
            for rel in $(helm list -q -n "$ns" 2>/dev/null); do
                log_silent "Removing leftover helm release: ${rel}"
                helm uninstall "$rel" -n "$ns" >/dev/null 2>&1 || true
            done
        fi
        if command -v kubectl >/dev/null 2>&1 \
           && kubectl get namespace "$ns" >/dev/null 2>&1; then
            print_info "Removing Kubernetes namespace '${ns}' (releases, jobs, PVCs)..."
            kubectl delete pvc --all -n "$ns" --ignore-not-found >/dev/null 2>&1 || true
            kubectl delete namespace "$ns" --ignore-not-found --timeout=120s >/dev/null 2>&1 \
                || print_warning "Namespace '${ns}' is still terminating; wait for it before re-installing"
        fi
        # The bundled controller's IngressClass and ClusterRole are
        # cluster-scoped -- namespace deletion does not remove them.
        if command -v kubectl >/dev/null 2>&1; then
            kubectl delete ingressclass ai-architect-nginx --ignore-not-found >/dev/null 2>&1 || true
            kubectl delete clusterrole ai-architect-ingress-controller --ignore-not-found >/dev/null 2>&1 || true
            kubectl delete clusterrolebinding ai-architect-ingress-controller --ignore-not-found >/dev/null 2>&1 || true
        fi
        return 0
    fi

    local compose_cmd
    if ! compose_cmd=$(_reset_detect_compose_cmd); then
        print_warning "Neither 'docker compose' nor 'docker-compose' found; skipping service shutdown."
        return 0
    fi

    local compose_file="${PLATFORM_DIR}/docker-compose.yml"
    local env_file="${ENV_FILE:-}"
    if [ -z "$env_file" ] && command -v get_config_file >/dev/null 2>&1; then
        env_file="$(get_config_file 2>/dev/null)"
    fi

    print_info "Stopping services and removing volumes..."
    if [ -f "$compose_file" ]; then
        if [ -n "$env_file" ] && [ -f "$env_file" ]; then
            $compose_cmd -f "$compose_file" --env-file "$env_file" down --remove-orphans --volumes >> "${LOG_FILE:-/dev/null}" 2>&1 \
                || $compose_cmd -f "$compose_file" down --remove-orphans --volumes >> "${LOG_FILE:-/dev/null}" 2>&1 \
                || log_silent "compose down failed during reset — containers/volumes may remain"
        else
            $compose_cmd -f "$compose_file" down --remove-orphans --volumes >> "${LOG_FILE:-/dev/null}" 2>&1 \
                || log_silent "compose down failed during reset — containers/volumes may remain"
        fi
    fi

    # Name-based cleanup: compose may miss stragglers if project name drifted.
    local c v
    for c in ai-architect-mysql ai-architect-config ai-architect-manager \
             ai-architect-provider ai-architect-tracker ai-architect-backup-scheduler \
             ai-architect-temporal ai-architect-worker \
             ai-architect-init-dirs ai-architect-provider-config-init; do
        docker rm -f "$c" >/dev/null 2>&1 || true
    done
    # Compose namespaces volumes as <project>_<name>, and every install dir is
    # a different project — sweep by the ai_architect_* family suffix so
    # orphans from earlier install directories are removed too, not just the
    # current project's volumes.
    local v
    for v in $(docker volume ls -q 2>/dev/null \
               | grep -E '(^|_)ai_architect_(mysql_data|data|backups|temp|insights|wingman|kafka_data|redis_data)$'); do
        docker volume rm "$v" >/dev/null 2>&1 || true
    done
    docker network rm ai-architect-network >/dev/null 2>&1 || true
}

# Escalates to sudo when docker created bind-mount targets as root.
_reset_clear_data_dirs() {
    local d
    local failed=false
    for d in "${PLATFORM_DIR}/var/logs/" \
             "${PLATFORM_DIR}/services/cis-provider/data/" \
             "${PLATFORM_DIR}/services/cis-provider/metadata/"; do
        [ -d "$d" ] || continue
        if rm -rf "${d}"* 2>/dev/null; then
            log_silent "Cleaned: $d"
            continue
        fi
        if command -v sudo >/dev/null 2>&1; then
            if sudo rm -rf "${d}"* 2>/dev/null; then
                log_silent "Cleaned with sudo: $d"
            else
                print_warning "Failed to clean: $d"
                failed=true
            fi
        else
            print_warning "Could not clean $d (root-owned; no sudo available)"
            failed=true
        fi
    done

    if $failed; then
        print_info "Manual cleanup: sudo rm -rf ${PLATFORM_DIR}/var/logs/* ${PLATFORM_DIR}/services/cis-provider/{data,metadata}/*"
    fi
}

_reset_remove_sql_init() {
    rm -f "${PLATFORM_DIR}/services/mysql/init/02-cis-config-"*.sql 2>/dev/null || true
    rm -f "${PLATFORM_DIR}/services/mysql/init/03-cis-manager-"*.sql 2>/dev/null || true
    rm -f "${PLATFORM_DIR}/services/mysql/init/04-"*.sql 2>/dev/null || true
}

_reset_remove_config_files() {
    if ! command -v get_config_file >/dev/null 2>&1; then
        print_warning "path-manager not loaded; skipping config file cleanup."
        return 0
    fi

    local env_file llm_file deployment_file repo_config repo_list
    env_file=$(get_config_file 2>/dev/null)
    llm_file=$(get_llm_config_file 2>/dev/null)
    deployment_file=$(get_deployment_type_file 2>/dev/null)
    repo_config=$(get_repo_config_file 2>/dev/null)
    repo_list=""
    if command -v get_repo_list_file >/dev/null 2>&1; then
        repo_list=$(get_repo_list_file 2>/dev/null)
    fi

    # Backup preserves api key / git token against accidental reset.
    if [ -f "$env_file" ] && command -v backup_config_file >/dev/null 2>&1; then
        backup_config_file "$env_file" "env" >/dev/null 2>&1 || log_silent "Warning: env backup failed before reset"
    fi

    rm -f "$llm_file"        2>/dev/null || true
    rm -f "$env_file"        2>/dev/null || true
    rm -f "$deployment_file" 2>/dev/null || true
    rm -f "$repo_config"     2>/dev/null || true
    [ -n "$repo_list" ] && rm -f "$repo_list" 2>/dev/null || true

    # A purge keeps ONLY backups. Sweep the generated/derived artifacts in BOTH
    # layout roots (a machine that flipped layouts holds stale twins, which is
    # also what makes detect_layout flap on the next install): the k8s values
    # file (holds secrets), env .bak siblings, the rendered docker-ingress
    # vhosts, template scratch, rendered scheduler manifests, and logs.
    local _pair _etc _var
    for _pair in \
        "${BITOARCH_SYSTEM_CONFIG_DIR:-/usr/local/etc/bitoarch}:${BITOARCH_SYSTEM_VAR_DIR:-/usr/local/var/bitoarch}" \
        "${BITOARCH_USER_CONFIG_DIR:-${HOME}/.local/bitoarch/etc}:${BITOARCH_USER_VAR_DIR:-${HOME}/.local/bitoarch/var}"; do
        _etc="${_pair%%:*}"; _var="${_pair##*:}"
        if [ -d "$_etc" ]; then
            rm -f  "$_etc"/.env-bitoarch "$_etc"/.env-llm-bitoarch "$_etc"/.deployment-type \
                   "$_etc"/.bitoarch-config.yaml "$_etc"/.bitoarch-values.yaml "$_etc"/*.bak \
                   "$_etc"/.install-yaml.last-applied "$_etc"/.install-yaml.plugins.last-applied 2>/dev/null || true
            rm -rf "$_etc/ingress" "$_etc/templates" "$_etc/plugins" 2>/dev/null || true
            rmdir "$_etc" 2>/dev/null || true
        fi
        if [ -d "$_var" ]; then
            rm -rf "$_var/plugins" "$_var/logs" 2>/dev/null || true
            rmdir "$_var" 2>/dev/null || true   # only removes when backups/ is gone too
        fi
    done

    # Legacy copies / symlinks at the platform root.
    rm -f "${PLATFORM_DIR}/.env-bitoarch"         2>/dev/null || true
    rm -f "${PLATFORM_DIR}/.env-llm-bitoarch"     2>/dev/null || true
    rm -f "${PLATFORM_DIR}/.deployment-type"      2>/dev/null || true
    rm -f "${PLATFORM_DIR}/.bitoarch-config.yaml" 2>/dev/null || true
    rm -f "${PLATFORM_DIR}/.bitoarch-values.yaml" 2>/dev/null || true
    rm -f "${PLATFORM_DIR}/bitoarch-install.yaml" 2>/dev/null || true
    rm -f "${PLATFORM_DIR}/setup.log"             2>/dev/null || true

    # The bitoarch CLI symlink: a full teardown removes it so the command is gone
    # afterwards (mirrors scripts/bitoarch-uninstall.sh).
    local _cli
    for _cli in "${HOME}/.local/bin/bitoarch" "/usr/local/bin/bitoarch"; do
        if [ -L "$_cli" ] || [ -f "$_cli" ]; then
            rm -f "$_cli" 2>/dev/null || sudo rm -f "$_cli" 2>/dev/null || true
        fi
    done
}

# Back up then restore from blank template so secrets are wiped but the
# file remains editable. Uninstall removes it entirely afterwards.
_reset_install_yaml() {
    local home_yaml="${HOME}/.bitoarch/install.yaml"
    local template="${PLATFORM_DIR}/install.yaml.default"

    if [ -f "$home_yaml" ] && [ -f "$template" ]; then
        if command -v backup_config_file >/dev/null 2>&1; then
            backup_config_file "$home_yaml" "install-yaml" >/dev/null 2>&1 || log_silent "Warning: install.yaml backup failed before reset"
        fi
        cp "$template" "$home_yaml" 2>/dev/null || true
        log_silent "Reset install yaml at $home_yaml"
    fi

    # cluster.yaml has no blank-template form (absent = single-node defaults),
    # so reset removes it outright; a fresh multi-node setup re-seeds it. The
    # upgrade reconcile's timestamped cluster.yaml.backup.<ts> copies go too --
    # they hold the same operator profile and a reset is a blank slate.
    rm -f "${HOME}/.bitoarch/cluster.yaml" 2>/dev/null || true
    find "${HOME}/.bitoarch" -maxdepth 1 -name 'cluster.yaml.backup*' -delete 2>/dev/null || true
}

# Plugins and shared dependency packs run as their own compose projects
# (ai-architect-*) / helm releases, so the base teardown never touches them. A reset
# is a blank slate, so tear them all down (with their volumes) and drop plugin
# state, configs, and install dirs -- otherwise they linger as orphans pointing
# at the wiped base.
_reset_remove_plugins() {
    local deployment="${1:-docker}"

    if [ "$deployment" = "kubernetes" ]; then
        # Uninstall each plugin/pack helm release recorded in the journal
        # (best-effort) before the journal itself is removed below.
        if ! command -v uninstall_helm_release >/dev/null 2>&1; then
            [ -f "${PLATFORM_DIR}/scripts/kubernetes-manager.sh" ] && \
                source "${PLATFORM_DIR}/scripts/kubernetes-manager.sh" 2>/dev/null || true
        fi
        if command -v uninstall_helm_release >/dev/null 2>&1 \
           && command -v get_plugin_state_file >/dev/null 2>&1 \
           && command -v jq >/dev/null 2>&1; then
            local sf rel ns="${BITOARCH_K8S_NAMESPACE:-bito-ai-architect}"
            sf="$(get_plugin_state_file 2>/dev/null)"
            if [ -f "$sf" ]; then
                for rel in $(jq -r '(.plugins // {}, .dependency_packs // {}) | .[].helm_release // empty' "$sf" 2>/dev/null | sort -u); do
                    [ -n "$rel" ] && uninstall_helm_release "$ns" "$rel" "true" 2>/dev/null || true
                done
            fi
        fi
    else
        local compose_cmd proj
        compose_cmd=$(_reset_detect_compose_cmd 2>/dev/null) || compose_cmd=""
        if [ -n "$compose_cmd" ] && command -v docker >/dev/null 2>&1; then
            for proj in $(docker ps -a --format '{{.Label "com.docker.compose.project"}}' 2>/dev/null \
                          | grep -E '^(ai-architect|bitoarch)-' | sort -u); do
                log_silent "Removing plugin/pack project: ${proj}"
                $compose_cmd -p "$proj" down --remove-orphans --volumes >/dev/null 2>&1 || true
            done
        fi
    fi

    # Plugin state journal, configs, and install dirs (plugin data lives on the
    # shared base data volume, already removed with it).
    command -v get_plugin_state_file >/dev/null 2>&1 && rm -f  "$(get_plugin_state_file 2>/dev/null)" 2>/dev/null || true
    command -v get_plugins_root      >/dev/null 2>&1 && rm -rf "$(get_plugins_root 2>/dev/null)"      2>/dev/null || true
    [ -n "${BITOARCH_CONFIG_DIR:-}" ] && rm -rf "${BITOARCH_CONFIG_DIR}/plugins" 2>/dev/null || true
}

# Archive logs before cleaning (Enterprise has unified-log-manager).
_reset_archive_logs() {
    local archiver="${PLATFORM_DIR}/scripts/unified-log-manager.sh"
    [ -x "$archiver" ] || return 0
    "$archiver" clean-archive 2>/dev/null || true
}

# Full teardown body (everything between the confirm and the closing block).
# A machine can hold artifacts of BOTH runtimes (deployment switches, a purge
# interrupted mid-way) — tear down every runtime detected.
_reset_teardown_all() {
    local deployment
    for deployment in $(_reset_detect_runtimes); do
        _reset_remove_plugins "$deployment"
        _reset_stop_services  "$deployment"
    done
    _reset_clear_data_dirs
    _reset_remove_sql_init
    _reset_remove_config_files
    _reset_install_yaml
    return 0
}

# AUTO_SETUP=true (uninstall orchestrator / CI) skips the confirmation prompt.
reset_run() {
    if [ "${AUTO_SETUP:-}" != "true" ] && [ "${BITOARCH_RESET_CONFIRMED:-}" != "1" ]; then
        print_warning "This will remove ALL data related to AI Architect including databases and configurations!"
        local reply
        read -r -p "Are you sure you want to continue? Type 'yes' to confirm: " reply
        echo ""
        if [ "$reply" != "yes" ]; then
            print_info "Reset cancelled."
            return 0
        fi
    fi

    _reset_archive_logs

    # Long-running teardown (helm uninstalls, namespace deletion, volume removal)
    # runs under one loader so the terminal never looks stuck; plain fallback when
    # progress-output isn't available (CDN uninstall).
    if ! command -v progress_run >/dev/null 2>&1; then
        # shellcheck disable=SC1091
        [ -f "${PLATFORM_DIR}/scripts/lib/progress-output.sh" ] && source "${PLATFORM_DIR}/scripts/lib/progress-output.sh" 2>/dev/null || true
    fi
    if command -v progress_run >/dev/null 2>&1; then
        progress_run "Removing AI Architect (services, data, configuration)" -- _reset_teardown_all
    else
        _reset_teardown_all
    fi

    if command -v render_clean_complete_block >/dev/null 2>&1; then
        render_clean_complete_block "All containers" "All volumes"
    else
        print_info "Reset complete."
    fi
}

export -f reset_run
