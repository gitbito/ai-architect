#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
# Bito's AI Architect CLI - Diagnose / collect-plugins
#
# Bundles installed-plugin state into the diagnose tarball. For each plugin in
# the state journal it collects: manifest, journal record, MASKED .env, recent
# logs, DB schema (no data), docker/k8s inspect, and an observability rollup
# (resolved STORAGE_MODE, live health, Kafka DLQ depth, data-dir disk usage,
# janitor state, inherited-vs-override env keys). It then runs the plugin's own
# diagnose/collect.sh (if shipped) under a timeout and a 50 MB per-plugin cap.
#
# Every artifact is passed through the central deny-by-default masker
# (mask-secrets.sh -> common.sh redactors) so the bundle never leaks secrets.
# Output: <out>/plugins/<name>/* and <out>/plugins/plugins-overview.txt.

if [ -n "${_DIAGNOSE_COLLECT_PLUGINS_LOADED:-}" ]; then
    return 0
fi
_DIAGNOSE_COLLECT_PLUGINS_LOADED=1

_CP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# A lib that fails to load makes every artifact below read as "not found" or
# "n/a"; say which one is missing instead.
_cp_source() {   # <file> <probe-symbol>
    type "$2" >/dev/null 2>&1 && return 0
    # shellcheck source=/dev/null
    . "$1" && return 0
    if type log_silent >/dev/null 2>&1; then
        log_silent "collect-plugins: could not load ${1##*/}; artifacts needing ${2} will be incomplete"
    fi
    return 1
}

# Masking entry points (canonical impl in common.sh; mask-secrets.sh wraps it).
_cp_source "${_CP_DIR}/mask-secrets.sh" mask_env_file || true
# Plugin engine libs (journal / manifest / packs / observability / paths).
_CP_PLUGIN_LIB="${_CP_DIR}/../plugin"
_cp_source "${_CP_PLUGIN_LIB}/state-journal.sh"       journal_list_plugins   || true
_cp_source "${_CP_PLUGIN_LIB}/manifest-parser.sh"     manifest_name          || true
_cp_source "${_CP_PLUGIN_LIB}/dependency-manager.sh"  dep_pack_installed     || true
_cp_source "${_CP_PLUGIN_LIB}/observability.sh"       plugin_storage_mode    || true
_cp_source "${_CP_DIR}/../path-manager.sh"            get_plugin_install_dir || true

# Per-plugin runaway bundle guard + collector timeout. Resolved at CALL time
# (not source time) so operators/tests can override via the env vars.
CP_PLUGIN_MAX_MB_DEFAULT=50
CP_PLUGIN_TIMEOUT_DEFAULT=60
_cp_max_mb()   { echo "${BITOARCH_DIAG_PLUGIN_MAX_MB:-$CP_PLUGIN_MAX_MB_DEFAULT}"; }
_cp_timeout()  { echo "${BITOARCH_DIAG_PLUGIN_TIMEOUT:-$CP_PLUGIN_TIMEOUT_DEFAULT}"; }

# Canonical compose project name comes from deploy.sh (via observability.sh
# fallback when deploy.sh is not loaded in the diagnose context).
_cp_compose_project() {
    if type plugin_compose_project >/dev/null 2>&1; then
        plugin_compose_project "$1"
    else
        printf 'ai-architect-%s' "$1"
    fi
}

# Container IDs for a plugin's compose project, resolved by the compose project
# LABEL via plain `docker ps` — robust even where the `docker compose` CLI plugin
# is missing/misconfigured (a bare `docker compose -p … ps` fails there). Includes
# stopped/exited containers (-a) so a crashed container is still captured for debugging.
_cp_project_container_ids() {   # <plugin-name>
    command -v docker >/dev/null 2>&1 || return 0
    docker ps -aq --filter "label=com.docker.compose.project=$(_cp_compose_project "$1")" 2>/dev/null
}

# Helm release for a plugin: k8s pods are labeled instance=release, not name.
_cp_helm_release() {
    local name="$1" rel
    rel="$(manifest_helm_release "$(get_plugin_install_dir "$name" 2>/dev/null)/plugin.yaml" 2>/dev/null)"
    printf '%s' "${rel:-$name}"
}

_cp_k8s_ns() { printf '%s' "${BUNDLE_K8S_NAMESPACE:-${BITOARCH_K8S_NAMESPACE:-bito-ai-architect}}"; }

# ─── Top-level collector (safe_step contract: rc 0 ok, rc 2 soft-skip) ─────
collect_plugins() {
    local deployment_type="$1" out_dir="$2"
    local base="${out_dir}/plugins"
    local overview="${base}/plugins-overview.txt"

    if ! type journal_list_plugins >/dev/null 2>&1; then
        mkdir -p "$base" 2>/dev/null || true
        echo "Plugin framework not present in this build -- nothing to collect." > "${base}/README.txt"
        _bundle_step_warn "plugins" "plugin framework libs unavailable"
        return 2
    fi

    local plugins; plugins="$(journal_list_plugins 2>/dev/null)"
    if [ -z "$plugins" ]; then
        mkdir -p "$base" 2>/dev/null || true
        echo "No plugins installed (state journal empty)." > "${base}/README.txt"
        return 2
    fi

    mkdir -p "$base" 2>/dev/null || true
    bundle_init_file "$overview" "Installed Plugins -- Overview"
    {
        echo ""
        echo "Deployment: ${deployment_type}"
        echo "Journal: $(_journal_path 2>/dev/null || echo '?') (integrity: $(journal_verify >/dev/null 2>&1 && echo OK || echo 'CHECK FAILED'))"
        echo ""
        printf '  %-20s %-10s %-12s %s\n' "NAME" "VERSION" "HEALTH(live)" "STORAGE_MODE"
    } >> "$overview"

    local p
    while IFS= read -r p; do
        [ -z "$p" ] && continue
        _cp_one_plugin "$p" "$base" "$deployment_type" "$overview"
    done <<EOF
$plugins
EOF

    # Deny-by-default backstop: scan the whole plugin bundle for token-shaped
    # leaks. Individual artifacts are masked at write time; this catches
    # anything a plugin's own collector emitted that slipped masking.
    if type mask_scan_for_leaks >/dev/null 2>&1; then
        local leaks leaks_rc
        leaks="$(mask_scan_for_leaks "$base" 2>/dev/null)"; leaks_rc=$?
        if [ -n "$leaks" ]; then
            _bundle_step_warn "plugins" "post-mask leak scan flagged content; re-masking"
            while IFS= read -r lf; do
                [ -f "$lf" ] || continue
                mask_file_inplace "$lf" || _cp_withhold_unmasked "$lf" "${lf#"${base}/"}"
            done < <(printf '%s\n' "$leaks" | cut -d: -f1 | sort -u)
        elif [ "$leaks_rc" -ne 0 ]; then
            # Scan could not read the tree: no findings does not mean clean.
            _bundle_step_warn "plugins" "post-mask leak scan could not read the plugin bundle; its contents are NOT verified as leak-free"
        fi
    fi
    return 0
}

# ─── One plugin ────────────────────────────────────────────────────────────
_cp_one_plugin() {
    local name="$1" base="$2" deployment_type="$3" overview="$4"
    local pdir="${base}/${name}"
    mkdir -p "$pdir" 2>/dev/null || true

    _cp_manifest      "$name" "$pdir"
    _cp_state         "$name" "$pdir"
    _cp_env           "$name" "$pdir"
    _cp_status        "$name" "$pdir" "$deployment_type"
    _cp_logs          "$name" "$pdir" "$deployment_type"
    _cp_db_schema     "$name" "$pdir" "$deployment_type"
    _cp_inspect       "$name" "$pdir" "$deployment_type"
    _cp_observability "$name" "$pdir" "$overview"
    _cp_run_collector "$name" "$pdir"
}

_cp_manifest() {
    local name="$1" pdir="$2" man
    man="$(get_plugin_install_dir "$name" 2>/dev/null)/plugin.yaml"
    if [ -f "$man" ]; then
        # Manifests carry env-var NAMES, not values, but mask defensively.
        if ! redact_stream < "$man" 2>>"${LOG_FILE:-/dev/null}" > "${pdir}/manifest.yaml"; then
            echo "# masking failed for ${man}; manifest withheld" > "${pdir}/manifest.yaml"
            _bundle_step_warn "plugins/${name}" "manifest could not be masked; withheld from the bundle"
        fi
    else
        echo "# manifest not found: ${man}" > "${pdir}/manifest.yaml"
    fi
}

_cp_state() {
    local name="$1" pdir="$2" rec diag ids
    type journal_get_plugin >/dev/null 2>&1 || { echo '{"note":"journal unavailable"}' > "${pdir}/state.json"; return 0; }
    rec="$(journal_get_plugin "$name" 2>/dev/null)"; [ -n "$rec" ] || rec='{"note":"no journal record"}'
    # Augment the persisted journal record with a LIVE per-container summary
    # (state / health / restart count / exit code) — the quickest "why is it
    # unhealthy right now" signal (full detail is in docker-inspect.json). Docker
    # only; best-effort — on any gap, fall back to the journal record alone.
    diag=""
    if command -v docker >/dev/null 2>&1 && command -v jq >/dev/null 2>&1; then
        ids="$(_cp_project_container_ids "$name")"
        if [ -n "$ids" ]; then
            # shellcheck disable=SC2086
            diag="$(docker inspect $ids 2>/dev/null | jq -c '[.[] | {name:(.Name|ltrimstr("/")), state:.State.Status, health:(.State.Health.Status // "n/a"), restarts:.RestartCount, exit_code:.State.ExitCode}]' 2>/dev/null)"
        fi
    fi
    local merged=""
    if [ -n "$diag" ]; then
        merged="$(printf '%s' "$rec" | jq --argjson c "$diag" --arg t "$(date -u +%Y-%m-%dT%H:%M:%SZ)" \
            '. + {_diagnostics: {collected_at: $t, containers: $c}}' 2>>"${LOG_FILE:-/dev/null}")"
        [ -n "$merged" ] || _bundle_step_warn "plugins/${name}" "could not merge live container state into state.json; journal record only"
    fi
    [ -n "$merged" ] || merged="$rec"
    # Same reason as the env file: never stream a redactor into the artifact itself.
    local _mst; _mst="$(mktemp)"
    if printf '%s' "$merged" | redact_stream > "$_mst"; then
        mv "$_mst" "${pdir}/state.json"
    else
        rm -f "$_mst" 2>/dev/null
        echo '{"note":"state.json withheld — masking failed"}' > "${pdir}/state.json"
        _bundle_step_warn "plugins/${name}" "state.json could not be masked; content withheld"
    fi
}

_cp_env() {
    local name="$1" pdir="$2" env_file
    env_file="$(get_plugin_env_file "$name" 2>/dev/null)"
    local target="${pdir}/env-masked.txt"
    {
        echo "# Plugin .env (sensitive values masked deny-by-default). Source: ${env_file:-<unset>}"
        echo ""
    } > "$target"
    if [ -n "$env_file" ] && [ -f "$env_file" ]; then
        # Mask into a temp file first: streaming straight into the bundle would leave
        # already-emitted plaintext there if the redactor failed mid-stream, under a
        # note claiming the file was withheld.
        local _menv; _menv="$(mktemp)"
        if mask_env_file "$env_file" 2>>"${LOG_FILE:-/dev/null}" > "$_menv"; then
            cat "$_menv" >> "$target"
        else
            echo "# masking FAILED for ${env_file} -- withheld (the file is NOT empty)" >> "$target"
            _bundle_step_warn "plugins/${name}" "env file could not be masked; withheld from the bundle"
        fi
        rm -f "$_menv" 2>/dev/null
    else
        echo "# no plugin .env present" >> "$target"
    fi
}

# At-a-glance service status, mirroring the base services section (the same
# detail exists in inspect output but buried; support reads this table first).
_cp_status() {
    local name="$1" pdir="$2" deployment_type="$3"
    local target="${pdir}/service-status.txt"
    : > "$target"
    if [ "$deployment_type" = "kubernetes" ]; then
        if command -v kubectl >/dev/null 2>&1; then
            local ns rel; ns="$(_cp_k8s_ns)"; rel="$(_cp_helm_release "$name")"
            bundle_log_section "$target" "Deployments"
            kubectl get deployments -n "$ns" -l "app.kubernetes.io/instance=${rel}" -o wide 2>&1 | sed 's/^/  /' >> "$target"
            bundle_log_section "$target" "Pods (status, restarts, age)"
            kubectl get pods -n "$ns" -l "app.kubernetes.io/instance=${rel}" -o wide 2>&1 | sed 's/^/  /' >> "$target"
        else
            echo "# kubectl unavailable -- skipped" >> "$target"
        fi
        return 0
    fi
    if command -v docker >/dev/null 2>&1; then
        bundle_log_section "$target" "Containers (status, restarts, uptime, health)"
        {
            printf "%-32s %-10s %-10s %-25s %-15s\n" "NAME" "STATUS" "RESTARTS" "STARTED" "HEALTH"
            local ids id cname status restarts started health
            ids="$(_cp_project_container_ids "$name")"
            [ -n "$ids" ] || echo "# no containers found for project $(_cp_compose_project "$name")"
            for id in $ids; do
                cname="$(docker inspect -f '{{.Name}}' "$id" 2>/dev/null | sed 's#^/##')"
                status=$(docker inspect --format='{{.State.Status}}'        "$id" 2>/dev/null || echo "missing")
                restarts=$(docker inspect --format='{{.RestartCount}}'      "$id" 2>/dev/null || echo "-")
                started=$(docker inspect --format='{{.State.StartedAt}}'    "$id" 2>/dev/null || echo "-")
                health=$(docker inspect --format='{{.State.Health.Status}}' "$id" 2>/dev/null || echo "-")
                { [ -z "$health" ] || [ "$health" = "<no value>" ]; } && health="none"
                printf "%-32s %-10s %-10s %-25s %-15s\n" \
                    "${cname:-$id}" "$status" "$restarts" "${started:0:24}" "$health"
            done
        } >> "$target"
    else
        echo "# docker unavailable -- skipped" >> "$target"
    fi
    return 0
}

_cp_logs() {
    local name="$1" pdir="$2" deployment_type="$3"
    local target="${pdir}/recent-logs.txt"
    local tail_lines="${BUNDLE_LOG_TAIL_LINES:-1000}"
    local max_bytes="${BUNDLE_LOG_MAX_BYTES:-5242880}"
    {
        echo "Recent plugin logs (masked, last ${tail_lines} lines, capped at ${max_bytes} bytes)"
        echo ""
    } > "$target"
    if [ "$deployment_type" = "kubernetes" ]; then
        if command -v kubectl >/dev/null 2>&1; then
            kubectl logs -n "$(_cp_k8s_ns)" \
                -l "app.kubernetes.io/instance=$(_cp_helm_release "$name")" \
                --tail="$tail_lines" --all-containers=true --max-log-requests=10 2>/dev/null \
                | redact_stream | head -c "$max_bytes" >> "$target"
        else
            echo "# kubectl unavailable -- skipped" >> "$target"
        fi
        return 0
    fi
    if command -v docker >/dev/null 2>&1; then
        local ids id cname; ids="$(_cp_project_container_ids "$name")"
        if [ -n "$ids" ]; then
            # Per-container tail (docker logs takes one id), labelled by container
            # name; combined output masked and capped. Merges stderr (2>&1) so a
            # crashed container's error output is captured.
            {
                for id in $ids; do
                    cname="$(docker inspect -f '{{.Name}}' "$id" 2>/dev/null | sed 's#^/##')"
                    echo "=== ${cname:-$id} ==="
                    docker logs --tail "$tail_lines" "$id" 2>&1
                    echo ""
                done
            } | redact_stream | head -c "$max_bytes" >> "$target"
        else
            echo "# no containers found for project $(_cp_compose_project "$name")" >> "$target"
        fi
    else
        echo "# docker unavailable -- skipped" >> "$target"
    fi
}

# mysqldump's own reason (access denied / connection refused / unknown database)
# instead of a guess. Masked: it lands in a shipped bundle.
_cp_dump_failed() {   # <plugin> <stderr-file> <target>
    local name="$1" err="$2" target="$3"
    echo "-- mysqldump failed; reason:" >> "$target"
    if [ -s "$err" ]; then
        redact_stream < "$err" | sed 's/^/--   /' >> "$target"
    else
        echo "--   (no output on stderr)" >> "$target"
    fi
    _bundle_step_warn "plugins/${name}/db" "mysqldump failed; reason recorded in db-schema.sql"
}

_cp_db_schema() {
    local name="$1" pdir="$2" deployment_type="$3"
    local target="${pdir}/db-schema.sql"
    local db user pass
    db="$(journal_plugin_field "$name" 'db.name' 2>/dev/null)"
    [ -z "$db" ] && db="$(manifest_db_name "$(get_plugin_install_dir "$name")/plugin.yaml" 2>/dev/null)"
    {
        echo "-- Plugin DB schema (structure only, no data). DB: ${db:-<unknown>}"
        echo ""
    } > "$target"
    if [ -z "$db" ]; then
        echo "-- no DB declared for this plugin" >> "$target"; return 0
    fi
    if [ -n "${MYSQL_ROOT_PASSWORD:-}" ]; then user="root"; pass="$MYSQL_ROOT_PASSWORD"
    elif [ -n "${MYSQL_USER:-}" ] && [ -n "${MYSQL_PASSWORD:-}" ]; then user="$MYSQL_USER"; pass="$MYSQL_PASSWORD"
    else echo "-- MySQL creds not in env -- skipped" >> "$target"; _bundle_step_warn "plugins/${name}/db" "no mysql creds"; return 0; fi

    if [ "$deployment_type" = "kubernetes" ]; then
        if command -v kubectl >/dev/null 2>&1; then
            local pod
            pod="$(kubectl get pods -n "$(_cp_k8s_ns)" -l "app.kubernetes.io/component=mysql" \
                   -o jsonpath='{.items[0].metadata.name}' 2>/dev/null)"
            if [ -n "$pod" ]; then
                # Pass the password via STDIN (read into $P in-container) so it never lands in
                # the pod/host process argv; $user/$db go as positional args, not shell-interpolated.
                local raw err
                raw="$(mktemp)"; err="$(mktemp)"
                if printf '%s' "$pass" | kubectl exec -i -n "$(_cp_k8s_ns)" "$pod" -- \
                        sh -c 'IFS= read -r P; MYSQL_PWD="$P" mysqldump -u "$1" --no-data --skip-comments --skip-dump-date "$2"' _ "$user" "$db" >"$raw" 2>"$err"; then
                    redact_stream < "$raw" >> "$target"
                else
                    _cp_dump_failed "$name" "$err" "$target"
                fi
                rm -f "$raw" "$err" 2>/dev/null
            else
                echo "-- mysql pod not found in namespace $(_cp_k8s_ns) -- skipped" >> "$target"
            fi
        else
            echo "-- kubectl unavailable -- skipped" >> "$target"
        fi
        return 0
    fi
    if command -v docker >/dev/null 2>&1; then
        local raw err
        raw="$(mktemp)"; err="$(mktemp)"
        if docker exec -e MYSQL_PWD="$pass" "${SERVICE_MYSQL_NAME:-ai-architect-mysql}" \
                mysqldump -u "$user" --no-data --skip-comments --skip-dump-date "$db" >"$raw" 2>"$err"; then
            redact_stream < "$raw" >> "$target"
        else
            _cp_dump_failed "$name" "$err" "$target"
        fi
        rm -f "$raw" "$err" 2>/dev/null
    else
        echo "-- docker unavailable -- skipped" >> "$target"
    fi
}

_cp_inspect() {
    local name="$1" pdir="$2" deployment_type="$3"
    if [ "$deployment_type" = "kubernetes" ]; then
        local target="${pdir}/k8s-resources.yaml"
        if command -v kubectl >/dev/null 2>&1; then
            local raw err
            raw="$(mktemp)"; err="$(mktemp)"
            if kubectl get all -n "$(_cp_k8s_ns)" \
                    -l "app.kubernetes.io/instance=$(_cp_helm_release "$name")" -o yaml >"$raw" 2>"$err"; then
                redact_stream < "$raw" > "$target"
            else
                { echo "# kubectl get all failed; reason:"; redact_stream < "$err" | sed 's/^/#   /'; } > "$target"
                _bundle_step_warn "plugins/${name}" "kubectl get all failed; reason recorded in k8s-resources.yaml"
            fi
            rm -f "$raw" "$err" 2>/dev/null
        else
            echo "# kubectl unavailable -- skipped" > "$target"
        fi
        return 0
    fi
    local target="${pdir}/docker-inspect.json"
    if command -v docker >/dev/null 2>&1; then
        local ids; ids="$(_cp_project_container_ids "$name")"
        if [ -n "$ids" ] && command -v jq >/dev/null 2>&1; then
            # JSON-AWARE pass (jq): keep the file valid JSON while (a) trimming the
            # repetitive successful healthcheck probes — keep failures, whose Output
            # is the useful signal — and (b) masking secret-keyed/-shaped Config.Env
            # values in place. The text redactor CANNOT be used here: it wraps values
            # in quotes, which breaks the docker Env "KEY=VALUE" JSON strings.
            # shellcheck disable=SC2086
            docker inspect $ids 2>/dev/null | jq '
                map(
                  (if (.State?.Health?.Log) then .State.Health.Log |= map(select(.ExitCode != 0)) else . end)
                  | (if .Config.Env then .Config.Env |= map(
                       if (test("(?i)(secret|token|password|passwd|api[_-]?key|access[_-]?key|auth|credential|signing|oauth|webhook|encryption|private[_-]?key|[a-z0-9]+[_-]key)[^=]*=")
                           or test("=(xox[abprs]-|gh[pousr]_|github_pat_|glpat-|AKIA[A-Z0-9]|sk-[A-Za-z0-9]|eyJ[A-Za-z0-9_-]+[.])"))
                       then sub("=.*"; "=***REDACTED***") else . end)
                     else . end)
                )' 2>/dev/null > "$target" || echo "[]" > "$target"
        elif [ -n "$ids" ]; then
            # No jq: text-redact (masks secrets; may not be strict JSON).
            # shellcheck disable=SC2086
            docker inspect $ids 2>/dev/null | redact_stream > "$target" || echo "[]" > "$target"
        else
            echo "// no containers found for project $(_cp_compose_project "$name")" > "$target"
        fi
    else
        echo "// docker unavailable -- skipped" > "$target"
    fi
}

_cp_observability() {
    local name="$1" pdir="$2" overview="$3"
    local health mode dlq disk jan
    mode="$(plugin_storage_mode "$name" 2>/dev/null)"
    health="$(plugin_health_now "$name" 2>/dev/null)"
    dlq="$(plugin_dlq_depth "$name" 2>/dev/null)"
    disk="$(plugin_disk_usage "$name" 2>/dev/null)"
    jan="$(plugin_janitor_state "$name" 2>/dev/null)"

    # One compact row in the overview table.
    printf '  %-20s %-10s %-12s %s\n' \
        "$name" \
        "$(journal_plugin_field "$name" version 2>/dev/null)" \
        "${health:-unknown}" \
        "${mode:-?}" >> "$overview"

    # Full per-plugin observability detail.
    local target="${pdir}/observability.txt"
    {
        echo "Plugin observability: ${name}"
        echo "------------------------------------------"
        printf '  %-18s %s\n' "storage_mode"  "${mode:-?}"
        printf '  %-18s %s\n' "health (live)" "${health:-unknown}"
        printf '  %-18s %s\n' "dlq_depth"     "${dlq:-n/a}"
        printf '  %-18s %s\n' "disk_usage"    "${disk:-n/a}"
        printf '  %-18s %s\n' "janitor"       "${jan:-n/a}"
        echo ""
        echo "  env provenance (inherited vs override):"
        plugin_env_provenance "$name" 2>/dev/null | sed 's/^/    /'
    } > "$target"
}

# ─── Per-plugin diagnose/collect.sh runner (timeout + size cap) ────────────
_cp_timeout_bin() {
    if command -v timeout >/dev/null 2>&1; then printf 'timeout'
    elif command -v gtimeout >/dev/null 2>&1; then printf 'gtimeout'
    else printf ''; fi
}

# Run "$@" with a hard wall-clock limit. Uses coreutils timeout when present;
# falls back to a background-process watchdog otherwise. rc 124 ~= timed out.
_cp_run_with_timeout() {
    local secs="$1"; shift
    local tb; tb="$(_cp_timeout_bin)"
    if [ -n "$tb" ]; then
        "$tb" -k 5 "${secs}" "$@"
        return $?
    fi
    "$@" &
    local pid=$!
    ( sleep "$secs"; kill -TERM "$pid" 2>/dev/null; sleep 3; kill -KILL "$pid" 2>/dev/null ) &
    local watcher=$!
    wait "$pid" 2>/dev/null; local rc=$?
    kill "$watcher" 2>/dev/null; wait "$watcher" 2>/dev/null
    return "$rc"
}

# Drop largest files until the dir is under the cap; record a truncation line.
_cp_enforce_cap() {
    local dir="$1" cap_mb="$2" name="$3"
    local cap_kb=$((cap_mb * 1024)) used big bigkb
    used="$(du -sk "$dir" 2>/dev/null | awk '{print $1}')"; used="${used:-0}"
    [ "$used" -le "$cap_kb" ] && return 0

    local warn="${dir}/TRUNCATED.txt"
    {
        echo "TRUNCATED -- plugin diagnose output exceeded the ${cap_mb} MB cap (was ~$((used / 1024)) MB)."
        echo "Largest files dropped to keep the support bundle bounded. $(date '+%Y-%m-%d %H:%M:%S %Z')"
        echo ""
    } > "$warn"
    while [ "$used" -gt "$cap_kb" ]; do
        big="$(find "$dir" -type f ! -name 'TRUNCATED.txt' -exec du -k {} + 2>/dev/null | sort -rn | head -1 | cut -f2-)"
        [ -z "$big" ] && break
        bigkb="$(du -k "$big" 2>/dev/null | awk '{print $1}')"
        echo "  dropped: ${big#"$dir"/} (${bigkb:-?} KB)" >> "$warn"
        rm -f "$big" 2>/dev/null || break
        used="$(du -sk "$dir" 2>/dev/null | awk '{print $1}')"; used="${used:-0}"
    done
    _bundle_step_warn "plugins/${name}" "collector output truncated at ${cap_mb} MB"
}

# A file mask_file_inplace could not mask is still UNMASKED on disk, so it must
# not travel in the bundle: replace it with a note naming what happened.
_cp_withhold_unmasked() {   # <file> <plugin>
    printf '# WITHHELD -- masking failed for this file; content removed rather than shipped unmasked.\n' > "$1" \
        || rm -f "$1" 2>/dev/null
    _bundle_step_warn "plugins/${2}" "could not mask ${1##*/}; withheld from the bundle"
}

# Mask every text file under a dir in place (binary files left untouched).
_cp_mask_tree() {
    local dir="$1" name="$2" f
    # Process substitution, not a pipe: a `find | while` body runs in a subshell, so
    # _bundle_step_warn's counter increment would be lost and the bundle would still
    # report "0 warnings" for files it withheld.
    while IFS= read -r f; do
        # grep -I => skip files grep considers binary.
        grep -Iq . "$f" 2>/dev/null || continue
        mask_file_inplace "$f" || _cp_withhold_unmasked "$f" "$name"
    done < <(find "$dir" -type f 2>/dev/null)
}

_cp_run_collector() {
    local name="$1" pdir="$2"
    local install_dir collector out tmo cap
    install_dir="$(get_plugin_install_dir "$name" 2>/dev/null)"
    collector="${install_dir}/diagnose/collect.sh"
    out="${pdir}/plugin-collect"
    tmo="$(_cp_timeout)"; cap="$(_cp_max_mb)"

    if [ ! -f "$collector" ]; then
        return 0   # plugin ships no diagnose collector; nothing to run.
    fi
    mkdir -p "$out" 2>/dev/null || true

    # Helpers dir + masking are exported so a plugin's collect.sh can source
    # BITOARCH_HELPERS and reuse mask_stream rather than rolling its own.
    local rc
    DIAGNOSE_OUT_DIR="$out" \
    BITOARCH_HELPERS="${_CP_PLUGIN_LIB}" \
    BITOARCH_DIAGNOSE_HELPERS="${_CP_DIR}" \
    PLUGIN_NAME="$name" \
    PLUGIN_INSTALL_DIR="$install_dir" \
    PLUGIN_DATA_DIR="$(get_plugin_data_dir "$name" 2>/dev/null)" \
    PLUGIN_ENV_FILE="$(get_plugin_env_file "$name" 2>/dev/null)" \
        _cp_run_with_timeout "$tmo" bash "$collector" >"${out}/collector-stdout.log" 2>"${out}/collector-stderr.log"
    rc=$?
    if [ "$rc" -eq 124 ] || [ "$rc" -eq 137 ] || [ "$rc" -eq 143 ]; then
        echo "TIMEOUT -- plugin collector exceeded ${tmo}s and was killed (rc ${rc})." > "${out}/TIMEOUT.txt"
        _bundle_step_warn "plugins/${name}" "collector timed out after ${tmo}s"
    elif [ "$rc" -ne 0 ]; then
        echo "Plugin collector exited non-zero (rc ${rc}). See collector-stderr.log." > "${out}/COLLECTOR-FAILED.txt"
        _bundle_step_warn "plugins/${name}" "collector exited rc ${rc}"
    fi

    # Enforce the per-plugin MB cap BEFORE masking (don't waste work on bytes we
    # drop), then mask everything the plugin emitted (deny-by-default).
    _cp_enforce_cap "$out" "$cap" "$name"
    _cp_mask_tree "$out" "$name"
}
