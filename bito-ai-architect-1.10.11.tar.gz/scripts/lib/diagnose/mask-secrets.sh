#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
#
# Bito's AI Architect CLI - Diagnose / Central secret-masking pass
#
# Deny-by-default masking for the diagnose bundle. The CANONICAL masking
# implementation lives in common.sh (redact_env_file / redact_stream) and is
# shared with the base collectors -- this module is the single entry point the
# plugin collector (collect-plugins.sh) uses, so there is ONE masking pass for
# base AND plugin artifacts, never two divergent ones.
#
# Coverage (key- and value-based): OAuth / signing / AES, Jira/Linear/LLM
# provider keys, BITO_API_KEY, MySQL passwords, the *_SECRET / *_TOKEN / *_KEY /
# *_PASSWORD fallbacks, and full webhook URLs (Slack/Discord + any ?token= query).

if [ -n "${_DIAGNOSE_MASK_SECRETS_LOADED:-}" ]; then
    return 0
fi
_DIAGNOSE_MASK_SECRETS_LOADED=1

# Canonical redactors live in common.sh; source it if a caller pulled this in
# standalone (tests, a plugin's own collect.sh sourcing BITOARCH_HELPERS).
_MASK_SECRETS_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# This file has no logger of its own; borrow the bundle's, then the platform's,
# then stderr. A masking failure must never be silent.
_mask_warn() {
    if type _bundle_step_warn >/dev/null 2>&1; then
        _bundle_step_warn "mask" "$1"
    elif type log_silent >/dev/null 2>&1; then
        log_silent "mask-secrets: $1"
    else
        printf 'mask-secrets: %s\n' "$1" >&2
    fi
}

if ! type redact_env_file >/dev/null 2>&1; then
    # shellcheck source=/dev/null
    . "${_MASK_SECRETS_DIR}/common.sh" || true
fi
# Fail closed: without the redactors, masking cannot happen, so make every entry
# point return non-zero rather than let a caller ship raw customer data.
if ! type redact_env_file >/dev/null 2>&1; then
    _mask_warn "common.sh unavailable — redactors missing; masking will refuse rather than pass data through"
    redact_env_file() { return 1; }
    redact_stream()   { return 1; }
fi

# Mask a .env-style file (key=value). Reads file, writes masked text to stdout.
mask_env_file() { redact_env_file "$@"; }

# Mask arbitrary text on stdin (logs, docker inspect, SQL, JSON).
mask_stream() { redact_stream; }

# Mask a file in place (used for docker-inspect.json, db-schema.sql, log copies).
# Atomic via temp + mv so a failure never leaves a half-masked file in the bundle.
# Returns non-zero when the file could NOT be masked — the caller must then drop
# the artifact rather than ship it, because the original is still unmasked.
mask_file_inplace() {
    local file="$1"
    [ -f "$file" ] || return 0
    local tmp; tmp="${file}.mask.$$"
    if ! redact_stream < "$file" > "$tmp" 2>>"${LOG_FILE:-/dev/null}"; then
        rm -f "$tmp" 2>/dev/null
        _mask_warn "redaction FAILED for ${file} — left UNMASKED; do not ship it"
        return 1
    fi
    if ! mv "$tmp" "$file" 2>>"${LOG_FILE:-/dev/null}"; then
        rm -f "$tmp" 2>/dev/null
        _mask_warn "could not replace ${file} with its masked copy — left UNMASKED; do not ship it"
        return 1
    fi
}

# Deny-by-default leak scanner. Greps a file or directory tree for
# token-SHAPED values that must never appear unmasked in a bundle. Prints each
# offending "file:line" to stdout. Returns 0 when clean, 1 when a leak is found.
#
# Patterns are intentionally narrow (real credential shapes) so the masked
# placeholder ***REDACTED*** and ordinary prose never trip it.
mask_scan_for_leaks() {
    local target="$1"
    [ -e "$target" ] || return 0
    local pattern='xox[abprs]-[A-Za-z0-9-]{8,}|gh[pousr]_[A-Za-z0-9]{16,}|github_pat_[A-Za-z0-9_]{20,}|glpat-[A-Za-z0-9_-]{16,}|AKIA[A-Z0-9]{16}|eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+|sk-[A-Za-z0-9]{20,}|https?://hooks\.slack\.com/services/[A-Za-z0-9]'
    local hits rc
    if [ -d "$target" ]; then
        hits="$(grep -rEnI "$pattern" "$target" 2>>"${LOG_FILE:-/dev/null}")"; rc=$?
    else
        hits="$(grep -EnI "$pattern" "$target" 2>>"${LOG_FILE:-/dev/null}")"; rc=$?
    fi
    # grep: 0 = match, 1 = no match, >1 = error. An unreadable target must not
    # be reported as clean.
    if [ "$rc" -gt 1 ]; then
        _mask_warn "leak scan could not read ${target} (grep rc=${rc}); treating as NOT verified"
        return 1
    fi
    if [ -n "$hits" ]; then
        printf '%s\n' "$hits"
        return 1
    fi
    return 0
}

# Some callers run under `set -f`/exported-function contexts (a plugin's own
# collect.sh); export the masking entry points so they resolve there too.
export -f mask_env_file mask_stream mask_file_inplace mask_scan_for_leaks 2>/dev/null || true
