#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
# Bito's AI Architect CLI - Diagnose / Bundler
# Top-level orchestrator for `bitoarch diagnose --bundle`.
#
# Sequence:
#   1. Pick output base dir (--output flag overrides default $HOME/.bitoarch/diagnostics)
#   2. Create timestamped workdir
#   3. Invoke each collect_* in fail-safe mode (safe_step)
#   4. Run the live diagnose sweep into the workdir as live-checks.txt
#   5. Write diagnostics-summary.txt with detected issues
#   6. Tar workdir → diagnostics-<timestamp>.tar.gz
#   7. Remove workdir, print the final .tar.gz path
#
# The bundle does NOT include the workdir after tarring -- support shares
# only the .tar.gz. To keep the workdir around (e.g. for live debugging),
# pass --keep-workdir.

if [ -n "${_DIAGNOSE_BUNDLER_LOADED:-}" ]; then
    return 0
fi
_DIAGNOSE_BUNDLER_LOADED=1

# Strip ANSI escape sequences -- bash printf can't emit a literal ESC in a
# regex portably, so we use printf-substitution for the control char.
# Two arms:
#   1. CSI : ESC '[' ... letter       — SGR (m), erase-line (K), cursor moves
#   2. OSC : ESC ']' ... BEL or ESC\  — title-setters, hyperlink wrappers
#                                        (terminator: BEL=0x07 or ESC \\ )
_strip_ansi() {
    local esc bel
    esc=$(printf '\033')
    bel=$(printf '\007')
    sed -E -e "s/${esc}\\[[0-9;]*[a-zA-Z]//g" \
           -e "s/${esc}\\][^${bel}${esc}]*(${bel}|${esc}\\\\)//g"
}

# Top-level entry. Runs all collectors, writes summary, produces .tar.gz.
# Args: deployment_type, verbose, output_base, keep_workdir.
# Returns 0 on success, 2 if workdir/archive cannot be written.
bundle_diagnostics() {
    local deployment_type="$1" verbose="$2" output_base="$3" keep_workdir="$4"

    local timestamp work_dir archive_path
    timestamp=$(date +%Y%m%d-%H%M%S)
    if ! mkdir -p "$output_base" 2>/dev/null; then
        print_error "Cannot create output directory: $output_base"
        return 2
    fi
    work_dir="${output_base}/diagnostics-${timestamp}"
    archive_path="${output_base}/diagnostics-${timestamp}.tar.gz"
    if ! mkdir -p "$work_dir" 2>/dev/null; then
        print_error "Cannot create workdir: $work_dir"
        return 2
    fi

    print_header "Bito's AI Architect Diagnostic Bundle"
    echo ""

    _BUNDLE_STEPS_OK=0
    _BUNDLE_WARNED=0
    _BUNDLE_FAILED=0
    _BUNDLE_FAILED_STEPS=""

    # Pin the canonical host log up front: the diagnose lifecycle path never
    # sets LOG_FILE, so without this _bundle_log -> log_silent falls back to
    # setup-utils.sh's repo-local scripts/var/logs/setup.log instead of the
    # support-visible log that `bitoarch logs` reads.
    command -v get_setup_log >/dev/null 2>&1 && export LOG_FILE="$(bitoarch_resolve_log_file 2>/dev/null || get_setup_log)"

    # Per-step progress goes to this run log (and the host log), not the
    # terminal; it's tarred into the bundle so support sees the full trace.
    _BUNDLE_RUN_LOG="${work_dir}/diagnostics-run.log"
    bundle_init_file "$_BUNDLE_RUN_LOG" "Bito's AI Architect -- Diagnostics Run Log"
    _bundle_log "deployment type: ${deployment_type} (verbose=${verbose})"
    _bundle_log "workdir:  ${work_dir}"
    _bundle_log "archive:  ${archive_path}"

    # The whole collection sweep runs behind a single animated loader (the
    # shared show_loader from scripts/lib/loader.sh). The trap tears the
    # spinner down, drops the partial workdir, and re-raises so Ctrl-C aborts
    # the run (exit ~130) instead of letting it finish and falsely print
    # "Bundle created". (loader.sh's kill-based spinner carries a documented,
    # accepted macOS-143 race -- intentional.)
    trap 'stop_loader 1; rm -rf "$work_dir" 2>/dev/null; trap - INT TERM; kill -INT "$$"' INT TERM
    show_loader "Diagnosing your deployment"

    safe_step "system"         collect_system         "$deployment_type" "$work_dir"
    safe_step "services"       collect_services       "$deployment_type" "$work_dir"
    safe_step "logs"           collect_logs           "$deployment_type" "$work_dir"
    safe_step "config"         collect_config         "$deployment_type" "$work_dir"
    safe_step "database"       collect_database       "$deployment_type" "$work_dir"
    safe_step "network"        collect_network        "$deployment_type" "$work_dir"
    safe_step "indexing"       collect_indexing       "$deployment_type" "$work_dir"
    safe_step "workflow"       collect_temporal       "$deployment_type" "$work_dir"
    safe_step "mcp"            collect_mcp            "$deployment_type" "$work_dir"
    safe_step "mcp-validation" collect_mcp_validation "$deployment_type" "$work_dir"
    safe_step "tracking"       collect_tracking       "$deployment_type" "$work_dir"
    safe_step "plugins"        collect_plugins        "$deployment_type" "$work_dir"

    # Capture the live diagnose sweep alongside raw data; the summary parses
    # it for detected issues. BITOARCH_DIAG_INTERNAL_SKIP_BUNDLE breaks the
    # recursion back into bundle mode. Output is piped through a stripper
    # because print_success/print_error emit ANSI color escapes that look
    # like garbage in a text file.
    _bundle_step_start "live diagnostic sweep"
    {
        echo "=== bitoarch diagnose (live sweep at $(date '+%Y-%m-%d %H:%M:%S %Z')) ==="
        echo ""
        BITOARCH_DIAG_INTERNAL_SKIP_BUNDLE=1 _DIAG_SUPPRESS_HEADER=1 \
            platform_diagnose 2>&1 | _strip_ansi || true
    } > "${work_dir}/live-checks.txt"
    _bundle_step_ok

    # ── Write summary ─────────────────────────────────────────────────
    _bundle_write_summary "$work_dir" "$deployment_type"

    # ── Tar it up ─────────────────────────────────────────────────────
    _bundle_log "Packaging archive..."
    if ! ( cd "$(dirname "$work_dir")" && tar -czf "$archive_path" "$(basename "$work_dir")" ) 2>/dev/null; then
        stop_loader 1
        trap - INT TERM
        print_error "Failed to create archive: $archive_path"
        return 2
    fi
    chmod 644 "$archive_path" 2>/dev/null || true

    if [ "$keep_workdir" != "true" ]; then
        rm -rf "$work_dir" 2>/dev/null || true
    fi

    stop_loader 0
    trap - INT TERM

    # ── Final report ──────────────────────────────────────────────────
    echo ""
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo "Bundle summary: ${_BUNDLE_STEPS_OK} ok, ${_BUNDLE_WARNED} warnings, ${_BUNDLE_FAILED} failed"
    if [ -n "${BITOARCH_DIAG_LIB_FAILED:-}" ]; then
        # Collectors missing => the counters above measured nothing. Say so rather
        # than hand support an archive that looks complete.
        print_error "Bundle is INCOMPLETE — these collectors failed to load:${BITOARCH_DIAG_LIB_FAILED}"
        print_error "Do not rely on ${archive_path}; fix the load errors above and re-run."
    else
        print_success "Bundle created: ${archive_path}"
        print_info "Share this file with Bito support: ${YELLOW}support@bito.ai${NC}"
    fi
    if [ $((_BUNDLE_WARNED + _BUNDLE_FAILED)) -gt 0 ]; then
        print_info "Per-step details: diagnostics-run.log inside the bundle"
    fi
    if [ "$keep_workdir" = "true" ]; then
        print_info "Workdir kept at: ${work_dir}"
    fi
    return 0
}

# Write diagnostics-summary.txt -- metadata, file inventory, parsed issues,
# step counters, support next-steps.
_bundle_write_summary() {
    local work_dir="$1" deployment_type="$2"
    local summary="${work_dir}/diagnostics-summary.txt"

    {
        echo "Bito's AI Architect -- Diagnostics Bundle Summary"
        echo "================================================="
        echo "Generated:        $(date '+%Y-%m-%d %H:%M:%S %Z')"
        echo "Host:             $(hostname 2>/dev/null || echo unknown)"
        echo "User:             $(whoami 2>/dev/null || echo unknown)"
        echo "Deployment type:  ${deployment_type}"
        echo ""

        echo "── Files in this bundle ─────────────────────────"
        # List the full tree (no depth cap): app logs live at
        # logs/app-logs/<component>/<file> (depth 3-4) and event dumps at
        # logs/events/ (depth 3), so a maxdepth cap would silently omit the
        # very files this bundle is collected to ship.
        (cd "$work_dir" && find . -type f 2>/dev/null | sort) \
            | sed 's|^\./|  |'
        echo ""

        echo "── Detected issues (from live diagnose sweep) ───"
        if [ -f "${work_dir}/live-checks.txt" ]; then
            local issues
            # No \b boundaries -- BSD grep's word boundaries don't fire
            # around the multi-byte ✗ character, which would silently drop
            # lines like "✗ Cert directory missing" from the summary.
            issues=$(grep -E '(FAIL|ERROR|✗|not (found|healthy|reachable|ready))' \
                        "${work_dir}/live-checks.txt" 2>/dev/null \
                        | head -50)
            if [ -n "$issues" ]; then
                echo "$issues" | sed 's/^/  /'
            else
                echo "  No issues flagged by the live sweep."
            fi
        else
            echo "  (live-checks.txt missing -- live sweep failed?)"
        fi
        echo ""

        echo "── Collection steps ─────────────────────────────"
        echo "  Succeeded: ${_BUNDLE_STEPS_OK}"
        echo "  Warned:    ${_BUNDLE_WARNED}"
        echo "  Failed:    ${_BUNDLE_FAILED}"
        if [ -n "$_BUNDLE_FAILED_STEPS" ]; then
            echo "  Failed steps:${_BUNDLE_FAILED_STEPS}"
        fi
        echo ""

        echo "── Next steps for support ───────────────────────"
        echo "  1. Open diagnostics-summary.txt (this file) first."
        echo "  2. Check live-checks.txt for the live health sweep."
        echo "  3. Drill into per-section files (service-status, logs/, ..)."
        echo "  4. Sensitive values are masked as ***REDACTED***."
    } > "$summary"
}
