#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
# Diagnose / collect-indexing: workspace + repo status via manager API.
# Output: <out>/indexing-status.txt (human summary + raw verbose=true JSON).

if [ -n "${_DIAGNOSE_COLLECT_INDEXING_LOADED:-}" ]; then
    return 0
fi
_DIAGNOSE_COLLECT_INDEXING_LOADED=1

# Writes indexing-status.txt -- human summary + extracted fields + raw JSON
# as an appended section (no separate .json file).
collect_indexing() {
    local deployment_type="$1" out_dir="$2"
    local txt_target="${out_dir}/indexing-status.txt"

    bundle_init_file "$txt_target" "Indexing status"

    _collect_indexing_api "$txt_target"
    local api_rc=$?
    # Session history is a separate, best-effort probe: it must never turn a
    # successful status capture into a warning.
    _collect_index_sessions "$txt_target" || true
    # Propagate the inner soft-skip code so safe_step counts it as warned
    # rather than ok (consistent with collect-database / collect-mcp / etc).
    return $api_rc
}

# List recent index sessions, so a bundle shows the run history and not only
# the latest run. API-driven, so it works where direct DB access does not.
_collect_index_sessions() {
    local txt_target="$1"

    [ -n "${MANAGER_URL:-}" ] || return 0
    [ -n "${BITO_API_KEY:-}" ] || return 0
    command -v jq >/dev/null 2>&1 || return 0

    bundle_log_section "$txt_target" "Recent index sessions"

    local endpoint="${MANAGER_URL}/api/v3/index-sessions?limit=20"
    local response http_code body
    response=$(curl -s -w '\n%{http_code}' --max-time 15 \
        -H "Authorization: Bearer ${BITO_API_KEY}" \
        "$endpoint" 2>&1)
    http_code=$(echo "$response" | tail -1)
    body=$(echo "$response" | sed '$d')

    if [ "$http_code" != "200" ] || [ -z "$body" ]; then
        echo "  Endpoint returned ${http_code} -- session history unavailable." >> "$txt_target"
        echo "  (manager may predate the index-sessions endpoint)" >> "$txt_target"
        return 0
    fi

    # jq's status has to be captured before the pipe: a pipeline reports the
    # last command's status, and redact_stream is a sed that succeeds even when
    # jq failed -- so piping directly would swallow a parse failure and write
    # nothing instead of the diagnostic.
    local parsed
    if parsed=$(echo "$body" | jq -r '
        (.sessions // [])[]
        | "  - " + (.session_id // "?")
          + "  started=" + (.started_at // "?")
          + "  ended=" + (.ended_at // "-")
          + "  status=" + (.status // "?")
          + "  repos=" + ((.repo_count // 0) | tostring)
    ' 2>/dev/null); then
        printf '%s\n' "$parsed" | redact_stream >> "$txt_target"
    else
        echo "  (could not parse session list)" >> "$txt_target"
    fi
}

# Query GET /api/v3/indexing-status?verbose=true with Bearer ${BITO_API_KEY}.
# verbose=true asks the manager for the full per-repo breakdown.
_collect_indexing_api() {
    local txt_target="$1"

    bundle_log_section "$txt_target" "Source: manager API"

    if [ -z "${MANAGER_URL:-}" ]; then
        echo "  MANAGER_URL not set -- skipping API probe." >> "$txt_target"
        _bundle_step_warn "indexing" "MANAGER_URL not set"
        return 2
    fi
    if [ -z "${BITO_API_KEY:-}" ]; then
        echo "  BITO_API_KEY not set -- API probe would 401, skipping." >> "$txt_target"
        _bundle_step_warn "indexing" "BITO_API_KEY not set"
        return 2
    fi

    local endpoint="${MANAGER_URL}/api/v3/indexing-status?verbose=true"
    local response http_code body
    # --retry survives a single manager flap during bundle capture without
    # forcing the entire run to re-execute. Total worst-case wall time:
    # 15s + 2*15s (retries) + 2*2s (backoff) = ~49s.
    response=$(curl -s -w '\n%{http_code}' --max-time 15 \
        --retry 2 --retry-delay 2 --retry-connrefused \
        -H "Authorization: Bearer ${BITO_API_KEY}" \
        "$endpoint" 2>&1)
    http_code=$(echo "$response" | tail -1)
    body=$(echo "$response" | sed '$d')

    {
        echo "  Endpoint:    ${endpoint}"
        echo "  HTTP status: ${http_code}"
    } >> "$txt_target"

    # Schema: workspace_id, configured_repos, total_repos, completed_repos,
    # in_progress_repos, failed_repos, percentage_completion,
    # workspace_level_index{total,success,failure,in_progress,ws_status},
    # status, plus per-repo details when verbose=true.
    if [ "$http_code" = "200" ] && [ -n "$body" ] && command -v jq >/dev/null 2>&1; then
        bundle_log_section "$txt_target" "Summary (extracted)"
        # Best-effort timestamp extraction: different manager-API revisions
        # surface the "last run" field under different keys; try the known
        # candidates in order and fall back to n/a if none are present.
        echo "$body" | jq -r '
            "  workspace_id:        " + (.workspace_id // "n/a" | tostring) + "\n" +
            "  repos configured:    " + (.configured_repos // "n/a" | tostring) + "\n" +
            "  repos total:         " + (.total_repos // "n/a" | tostring) + "\n" +
            "  repos completed:     " + (.completed_repos // "n/a" | tostring) + "\n" +
            "  repos in progress:   " + (.in_progress_repos // "n/a" | tostring) + "\n" +
            "  repos failed:        " + (.failed_repos // "n/a" | tostring) + "\n" +
            "  completion:          " + (.percentage_completion // "n/a" | tostring) + "%\n" +
            "  overall status:      " + (.status // "n/a" | tostring) + "\n" +
            "  session id:          " + (.session_id // "n/a" | tostring) + "\n" +
            "  session started:     " + (.session_started_at // "n/a" | tostring) + "\n" +
            "  session ended:       " + (.session_ended_at // "n/a" | tostring) + "\n" +
            "  last indexing run:   " + ((.last_run_at // .last_completed_at // .updated_at //
                                          .workspace_level_index.last_completed_at //
                                          .workspace_level_index.updated_at // "n/a") | tostring) + "\n" +
            "  workspace-level idx: total=" + (.workspace_level_index.total // "n/a" | tostring) +
                                  " success=" + (.workspace_level_index.success // "n/a" | tostring) +
                                  " failure=" + (.workspace_level_index.failure // "n/a" | tostring) +
                                  " in_progress=" + (.workspace_level_index.in_progress // "n/a" | tostring) +
                                  " status=" + (.workspace_level_index.ws_status // "n/a" | tostring)
        ' 2>/dev/null >> "$txt_target" \
            || echo "  (could not extract summary)" >> "$txt_target"

        bundle_log_section "$txt_target" "Failed repos (top 10)"
        local failed_count
        failed_count=$(echo "$body" | jq -r '.failed_repos // 0' 2>/dev/null)
        if [ "${failed_count:-0}" = "0" ]; then
            echo "  No failed repos reported." >> "$txt_target"
        else
            # Per-repo reasons live under repositories[].details.failed_event_details
            # (BITO-15348): one entry per errored event, each with a stable
            # error_code. Failure messages routinely carry tokenised git URLs
            # and bearer headers echoed back by the provider -- stream through
            # redact_stream before writing.
            local failure_lines
            failure_lines=$(echo "$body" | jq -r '
                [ (.repositories // [])[]
                  | . as $r
                  | (($r.details.failed_event_details) // [])[]
                  | "  - " + ($r.repo_name // "<unknown>")
                    + " [" + ($r.details.stage // "?") + "]"
                    + " " + (.event // "?")
                    + ": " + (.error_code // "NO_CODE")
                    + " -- " + (.message // "<no error message>")
                ] | .[0:10] | .[]
            ' 2>/dev/null)

            if [ -n "$failure_lines" ]; then
                printf '%s\n' "$failure_lines" | redact_stream >> "$txt_target"
            else
                echo "  ${failed_count} failures reported (aggregate); no per-event details." >> "$txt_target"
                echo "  (manager may predate the error-taxonomy build; check its logs)" >> "$txt_target"
            fi

            # Workspace-level failures belong to the run, not to one repo.
            echo "$body" | jq -r '
                ((.workspace_level_index.failed_event_details) // [])[]
                | "  - <workspace> " + (.event // "?")
                  + ": " + (.error_code // "NO_CODE")
                  + " -- " + (.message // "<no error message>")
            ' 2>/dev/null | redact_stream >> "$txt_target"
        fi

        # Embed the raw JSON inline rather than a separate file. Failed-repo
        # entries can carry tokenised git URLs (x-access-token:ghp_...) and
        # bearer headers echoed in provider error bodies -- redact before
        # writing.
        bundle_log_section "$txt_target" "Raw API response (verbose=true)"
        echo "$body" | jq '.' 2>/dev/null | redact_stream | sed 's/^/  /' >> "$txt_target" \
            || echo "$body" | redact_stream | sed 's/^/  /' >> "$txt_target"
    else
        bundle_log_section "$txt_target" "Raw response (first 500 chars)"
        echo "$body" | head -c 500 | redact_stream | sed 's/^/    /' >> "$txt_target"
        echo "" >> "$txt_target"
    fi
}

