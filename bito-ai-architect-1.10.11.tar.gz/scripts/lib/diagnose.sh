#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
# Bito's AI Architect CLI - Diagnose
# Self-contained diagnostic command (`bitoarch diagnose`). Two-layer design:
#
#   1. Atomic predicates (`is_*`, `probe_*`)        -- reusable, side-effect-free,
#                                                       return 0/1, optional echo
#   2. Section orchestrators (`diag_section_*`)     -- compose atomic predicates,
#                                                       emit pass/warn/fail lines
#
# `platform_diagnose` is the entry point invoked by bitoarch.sh's dispatcher.
# Nothing in this file mutates other adapters; sections and predicates can be
# called individually by other tooling (e.g. install-time pre-flight, support
# scripts) without going through the full sweep.
#
# Two run modes:
#   - default            : live in-terminal health check (pass/warn/fail per section)
#   - --bundle           : collect a shareable diagnostics .tar.gz for support
#                           (delegates to scripts/lib/diagnose/bundler.sh)

# Source bundle collectors. Side-effect-free at load time; safe to source
# even when only the live mode runs.
_DIAGNOSE_LIB_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/diagnose"
if [ -d "$_DIAGNOSE_LIB_DIR" ]; then
    # shellcheck disable=SC1090
    source "${_DIAGNOSE_LIB_DIR}/common.sh"
    source "${_DIAGNOSE_LIB_DIR}/collect-system.sh"
    source "${_DIAGNOSE_LIB_DIR}/collect-services.sh"
    source "${_DIAGNOSE_LIB_DIR}/collect-logs.sh"
    source "${_DIAGNOSE_LIB_DIR}/collect-config.sh"
    source "${_DIAGNOSE_LIB_DIR}/collect-database.sh"
    source "${_DIAGNOSE_LIB_DIR}/collect-network.sh"
    source "${_DIAGNOSE_LIB_DIR}/collect-indexing.sh"
    source "${_DIAGNOSE_LIB_DIR}/collect-temporal.sh"
    source "${_DIAGNOSE_LIB_DIR}/collect-mcp.sh"
    source "${_DIAGNOSE_LIB_DIR}/collect-tracking.sh"
    source "${_DIAGNOSE_LIB_DIR}/collect-plugins.sh"
    source "${_DIAGNOSE_LIB_DIR}/validate-mcp.sh"

    # A lib that failed to load leaves its functions undefined; bash prints the
    # error and carries on, so the bundle would count 0 steps and read as success.
    # common.sh owns the step accounting and the redactors, so its absence is what
    # turns the summary into a false success -- record it so the summary can't.
    BITOARCH_DIAG_LIB_FAILED=""
    if ! type _bundle_step_ok >/dev/null 2>&1 || ! type redact_stream >/dev/null 2>&1; then
        BITOARCH_DIAG_LIB_FAILED=" common.sh"
        printf 'ERROR: diagnose: common.sh did not load — the bundle will be incomplete\n' >&2
    fi
    source "${_DIAGNOSE_LIB_DIR}/bundler.sh"
fi

# ─── Atomic predicates ────────────────────────────────────────────────────

is_tool_present() {
    command -v "$1" >/dev/null 2>&1
}

# Returns 0 if env var named $1 is set and non-empty (indirect expansion).
is_env_var_set() {
    local name="$1"
    [ -n "${!name:-}" ]
}

is_path_writable() {
    [ -d "$1" ] && [ -w "$1" ]
}

# Returns 0 if free disk on $1 is >= $2 GB. df -k for mac/linux portability.
has_disk_space_gb() {
    local path="$1" min_gb="$2"
    [ -d "$path" ] || return 1
    command -v df >/dev/null 2>&1 || return 1
    local avail_kb avail_gb
    avail_kb=$(df -k "$path" 2>/dev/null | awk 'NR==2 {print $4}')
    [ -n "$avail_kb" ] && [ "$avail_kb" -gt 0 ] 2>/dev/null || return 1
    avail_gb=$((avail_kb / 1024 / 1024))
    [ "$avail_gb" -ge "$min_gb" ]
}

# Echoes free disk-space in whole GB on $1.
disk_space_gb() {
    local path="$1"
    [ -d "$path" ] || return 1
    command -v df >/dev/null 2>&1 || return 1
    local avail_kb
    avail_kb=$(df -k "$path" 2>/dev/null | awk 'NR==2 {print $4}')
    [ -n "$avail_kb" ] && [ "$avail_kb" -gt 0 ] 2>/dev/null || return 1
    echo $((avail_kb / 1024 / 1024))
}

# YAML syntax check. Tries yq, then python3+pyyaml.
# Returns: 0 valid, 1 invalid, 2 no validator available.
is_yaml_valid() {
    local file="$1"
    [ -f "$file" ] || return 1
    if command -v yq >/dev/null 2>&1; then
        yq eval '.' "$file" >/dev/null 2>&1
        return $?
    fi
    if command -v python3 >/dev/null 2>&1 && python3 -c 'import yaml' >/dev/null 2>&1; then
        python3 -c "import yaml; yaml.safe_load(open('$file'))" >/dev/null 2>&1
        return $?
    fi
    return 2
}

# TCP port reachable -- nc preferred, /dev/tcp fallback.
is_port_reachable() {
    local host="$1" port="$2"
    nc -z "$host" "$port" 2>/dev/null \
        || timeout 1 bash -c "cat < /dev/null > /dev/tcp/${host}/${port}" 2>/dev/null
}

# MySQL reachability -- HTTP /health if exposed, else raw port probe.
is_mysql_reachable() {
    local host="$1" port="$2"
    curl -sf "http://${host}:${port}/health" >/dev/null 2>&1 \
        || is_port_reachable "$host" "$port"
}

# HTTP service health probe -- delegates to http-client.sh's health_check.
is_http_healthy() {
    local url="$1"
    health_check "$url"
}

# Echoes "<status>:<health>" and returns 0 when container is healthy (or
# running with no healthcheck declared).
probe_container_health() {
    local name="$1"
    local status health
    status=$(docker inspect --format='{{.State.Status}}' "$name" 2>/dev/null)
    health=$(docker inspect --format='{{.State.Health.Status}}' "$name" 2>/dev/null)
    echo "${status:-missing}:${health:-none}"
    if [ "$status" = "running" ] \
       && { [ "$health" = "healthy" ] \
            || [ -z "$health" ] \
            || [ "$health" = "<no value>" ]; }; then
        return 0
    fi
    return 1
}

# Echoes "<readyReplicas>/<specReplicas>" and returns 0 when ready==spec.
probe_k8s_deployment() {
    local name="$1" namespace="$2"
    local ready spec
    ready=$(kubectl get deployment "$name" -n "$namespace" \
            -o jsonpath='{.status.readyReplicas}' 2>/dev/null)
    spec=$(kubectl get deployment "$name" -n "$namespace" \
            -o jsonpath='{.spec.replicas}' 2>/dev/null)
    echo "${ready:-0}/${spec:-0}"
    [ -n "$spec" ] && [ "$spec" != "0" ] \
        && [ -n "$ready" ] && [ "$ready" = "$spec" ]
}

# Echoes one of: ok | timeout | unreachable | error.
# Returns 0 on "ok".
probe_mcp_endpoint() {
    local url="$1" token="$2"
    local tls=""
    case "$url" in https://*) tls="-k" ;; esac

    local response rc
    response=$(curl -s --max-time 10 --connect-timeout 5 $tls \
        -X POST "${url}/mcp" \
        -H "Authorization: Bearer ${token}" \
        -H "Content-Type: application/json" \
        -d '{"jsonrpc": "2.0", "method": "tools/list", "id": 1}' 2>&1)
    rc=$?

    if [ "$rc" -eq 0 ] && echo "$response" | grep -q '"result"'; then
        echo "ok"; return 0
    fi
    case "$rc" in
        28) echo "timeout";     return 1 ;;
        7)  echo "unreachable"; return 1 ;;
        *)  echo "error";       return 1 ;;
    esac
}

# Echoes count of .pem/.crt/.key files in $1; returns 0 if any present.
cert_file_count() {
    local dir="$1"
    [ -d "$dir" ] || { echo 0; return 1; }
    local n
    n=$(find "$dir" -maxdepth 1 -type f \
        \( -name '*.pem' -o -name '*.crt' -o -name '*.key' \) 2>/dev/null \
        | wc -l | tr -d ' ')
    echo "${n:-0}"
    [ "${n:-0}" -gt 0 ]
}

# ─── Accumulator helpers ──────────────────────────────────────────────────

_diag_pass() {
    print_success "$1"
    _DIAG_PASSED=$((_DIAG_PASSED + 1))
}

_diag_warn() {
    print_warning "$1"
    _DIAG_WARNED=$((_DIAG_WARNED + 1))
}

_diag_fail() {
    local msg="$1" section="$2"
    print_error "$msg"
    _DIAG_FAILED=$((_DIAG_FAILED + 1))
    case " $_DIAG_FAILED_SECTIONS " in
        *" $section "*) ;;
        *) _DIAG_FAILED_SECTIONS="$_DIAG_FAILED_SECTIONS $section" ;;
    esac
}

# ─── Section orchestrators ────────────────────────────────────────────────
# Each diag_section_<name> is independently callable. Args:
#   $1 verbose ("true"/"false"), $2 deployment_type.

diag_section_prereqs() {
    local verbose="$1" deployment_type="$2"
    print_subheader "▶ Prerequisites"

    local tool
    for tool in curl jq nc; do
        if is_tool_present "$tool"; then
            _diag_pass "$tool present"
        else
            _diag_fail "$tool not found" prereqs
        fi
    done

    if [ "$deployment_type" = "kubernetes" ]; then
        for tool in kubectl helm; do
            if is_tool_present "$tool"; then
                _diag_pass "$tool present"
            else
                _diag_fail "$tool not found (required for kubernetes deployment)" prereqs
            fi
        done
    else
        if is_tool_present docker; then
            _diag_pass "docker present"
        else
            _diag_fail "docker not found (required for docker-compose deployment)" prereqs
        fi
        if docker compose version >/dev/null 2>&1; then
            _diag_pass "docker compose plugin available"
        elif is_tool_present docker-compose; then
            _diag_pass "docker-compose binary present"
        else
            _diag_fail "docker compose not found" prereqs
        fi
    fi
}

diag_section_install_state() {
    local verbose="$1" deployment_type="$2"
    print_subheader "▶ Installation state"

    local cfg_file
    cfg_file=$(get_config_file)
    if [ -f "$cfg_file" ] && [ -r "$cfg_file" ]; then
        _diag_pass "Config file present"
        [ "$verbose" = "true" ] && echo "    $cfg_file"
    else
        _diag_fail "Config file missing or unreadable: $cfg_file" install
        # Bail early -- env-key checks below would all noisily fail without it.
        return 0
    fi

    local dt_file
    dt_file=$(get_deployment_type_file 2>/dev/null)
    if [ -n "$dt_file" ] && [ -f "$dt_file" ]; then
        _diag_pass "Deployment type recorded: $deployment_type"
    else
        _diag_warn "Deployment type file not found"
    fi

    local versions_file="${SCRIPT_DIR}/../versions/service-versions.json"
    if [ -f "$versions_file" ]; then
        _diag_pass "Versions manifest present"
    else
        _diag_warn "Versions manifest not found: $versions_file"
    fi

    local key val
    for key in BITO_API_KEY PROVIDER_URL CONFIG_URL MANAGER_URL MYSQL_PORT STORAGE_PATH INDEX_DATA_DIR; do
        if is_env_var_set "$key"; then
            val="${!key}"
            if [ "$verbose" = "true" ] && [ "$key" = "BITO_API_KEY" ]; then
                _diag_pass "${key} set (***${val: -4})"
            elif [ "$verbose" = "true" ]; then
                _diag_pass "${key}=${val}"
            else
                _diag_pass "${key} set"
            fi
        else
            _diag_fail "${key} missing or empty" install
        fi
    done
}

# Kubernetes filesystem check: confirm the chart's storage
# PersistentVolumeClaims are Bound. On K8s the storage paths (STORAGE_PATH,
# INDEX_DATA_DIR, ...) are PVC mounts inside the pods, not directories on the
# diagnose host, so PVC bind state is the signal that storage is provisioned.
#
#   $1  verbose  -- when "true", append the phase to each PVC line.
#
# Per bitoarch PVC in namespace "bito-ai-architect":
#   Bound           -> pass   (e.g. "PVC bound: bitoarch-data")
#   Pending / Lost  -> fail   (storage not usable)
# Warns and skips when the namespace is missing or no PVCs are found.
# Always returns 0; results are recorded in the _DIAG_* counters.
_diag_filesystem_k8s() {
    local verbose="$1"
    local namespace="bito-ai-architect"

    # Unpinned: querying would hit the ambient context, and reporting the namespace
    # as missing would be false. Name the context as the reason instead.
    if [ -n "${BITOARCH_KUBE_UNREACHABLE:-}" ]; then
        _diag_warn "cluster.yaml context '${BITOARCH_KUBE_UNREACHABLE}' is not in your kubeconfig; skipping PVC checks (cluster unreachable)"
        return 0
    fi

    if ! kubectl get namespace "$namespace" >/dev/null 2>&1; then
        _diag_warn "Namespace '$namespace' not found; skipping PVC checks"
        return 0
    fi

    # One "<name> <phase>" line per bitoarch PVC.
    local pvc_lines
    pvc_lines=$(kubectl get pvc -n "$namespace" \
        -l app.kubernetes.io/name=bitoarch \
        -o jsonpath='{range .items[*]}{.metadata.name}{" "}{.status.phase}{"\n"}{end}' 2>/dev/null)

    if [ -z "$pvc_lines" ]; then
        _diag_warn "No AI Architect PersistentVolumeClaims found in namespace '$namespace'"
        return 0
    fi

    local name phase
    while read -r name phase; do
        [ -z "$name" ] && continue
        if [ "$phase" = "Bound" ]; then
            if [ "$verbose" = "true" ]; then
                _diag_pass "PVC bound: $name ($phase)"
            else
                _diag_pass "PVC bound: $name"
            fi
        else
            _diag_fail "PVC not bound: $name (${phase:-unknown})" filesystem
        fi
    done <<< "$pvc_lines"
}


_diag_filesystem_compose() {
    local verbose="$1"

    # Pick a running container that mounts data, temp and backups at the
    # canonical /opt/bito/ai-architect paths: the manager, else the worker.
    local container="" candidate
    for candidate in "$SERVICE_MANAGER_NAME" "$SERVICE_WORKER_NAME"; do
        if [ "$(docker inspect --format='{{.State.Status}}' "$candidate" 2>/dev/null)" = "running" ]; then
            container="$candidate"
            break
        fi
    done

    if [ -z "$container" ]; then
        _diag_warn "No running service container to verify storage paths (see Services); skipping filesystem checks"
        return 0
    fi

    local var path rc
    for var in STORAGE_PATH INDEX_DATA_DIR CIS_CLONE_DIR ANALYTICS_LOG_PATH METADATA_PATH TEMP_PATH BACKUP_PATH; do
        path="${!var:-}"
        [ -z "$path" ] && continue

        docker exec -e BITO_DIAG_PATH="$path" "$container" \
            sh -c 'test -d "$BITO_DIAG_PATH" || exit 2; test -w "$BITO_DIAG_PATH" || exit 3' \
            >/dev/null 2>&1
        rc=$?
        case "$rc" in
            0)
                if [ "$verbose" = "true" ]; then
                    _diag_pass "${var} writable in ${container}: $path"
                else
                    _diag_pass "${var} writable"
                fi
                ;;
            2) _diag_fail "${var} missing in ${container}: $path" filesystem ;;
            3) _diag_fail "${var} not writable in ${container}: $path" filesystem ;;
            *) _diag_warn "${var} could not be verified in ${container} (rc=${rc}): $path" ;;
        esac
    done
}

diag_section_filesystem() {
    local verbose="$1" deployment_type="$2"
    print_subheader "▶ Filesystem"

    # umask governs the permissions of everything the installer shell creates.
    local cur_umask; cur_umask="$(umask)"
    _diag_pass "umask: ${cur_umask}"
    [ "$verbose" = "true" ] && echo "    governs permissions of files created during install/upgrade"

    # Storage is orchestrator-managed, not host directories: on Kubernetes the
    # paths are PVC mounts inside the pods; on docker-compose they are Docker
    # named volumes mounted inside the service containers. Validate each where
    # it actually lives -- stat-ing the diagnose host would always fail.
    if [ "$deployment_type" = "kubernetes" ]; then
        _diag_filesystem_k8s "$verbose"
    else
        _diag_filesystem_compose "$verbose"
    fi
}

# User-facing YAML configs in ~/.bitoarch. All optional -- "none present" passes.
diag_section_config_files() {
    local verbose="$1"
    print_subheader "▶ Config files"

    local files=()
    local f
    f=$(get_repo_config_file 2>/dev/null);  [ -n "$f" ] && files+=("$f")
    f=$(get_repo_list_file 2>/dev/null);    [ -n "$f" ] && files+=("$f")
    f=$(get_install_yaml_file 2>/dev/null); [ -n "$f" ] && files+=("$f")

    local any=0
    for f in "${files[@]}"; do
        [ -f "$f" ] || continue
        any=1
        local label="${f##*/}"
        is_yaml_valid "$f"
        case $? in
            0) _diag_pass "$label parses"
               [ "$verbose" = "true" ] && echo "    $f" ;;
            1) _diag_warn "$label has YAML errors ($f)" ;;
            2) _diag_warn "$label present but no YAML validator (install yq or python3+pyyaml)" ;;
        esac
    done

    [ "$any" -eq 0 ] && _diag_pass "No optional YAML configs present (none required)"
}

# Service health per deployment type. Tracker excluded for parity with
# `bitoarch health`.
diag_section_services() {
    local verbose="$1" deployment_type="$2"
    print_subheader "▶ Services"

    if [ "$deployment_type" = "kubernetes" ]; then
        local namespace="bito-ai-architect"
        # Not pinned to the target cluster: name that as the finding. Querying
        # unpinned would hit the ambient context and report "not deployed" for
        # services that are running -- and a wrong root cause is the one thing a
        # diagnostic must not produce.
        if [ -n "${BITOARCH_KUBE_UNREACHABLE:-}" ]; then
            _diag_fail "cluster.yaml context '${BITOARCH_KUBE_UNREACHABLE}' is not in your kubeconfig -- cannot reach the cluster, so service state is unknown (fix the context in ~/.bitoarch/cluster.yaml or add it to your kubeconfig)" services
            return 0
        fi
        if ! kubectl get namespace "$namespace" >/dev/null 2>&1; then
            _diag_fail "Kubernetes namespace '$namespace' not found (services not deployed)" services
            return 0
        fi

        local deployments=(
            "ai-architect-provider|AI Architect Provider (MCP)"
            "ai-architect-config|AI Architect Config"
            "ai-architect-manager|AI Architect Manager"
            "ai-architect-mysql|MySQL Database"
            "ai-architect-worker|AI Architect Worker"
        )
        local entry name display info
        for entry in "${deployments[@]}"; do
            IFS='|' read -r name display <<< "$entry"
            if info=$(probe_k8s_deployment "$name" "$namespace"); then
                if [ "$verbose" = "true" ]; then
                    _diag_pass "$display ready ($info)"
                else
                    _diag_pass "$display ready"
                fi
            else
                _diag_fail "$display not ready ($info)" services
            fi
        done
        return 0
    fi

    # docker-compose path. `kind` selects which atomic probe runs.
    local services=(
        "provider|http|${PROVIDER_URL}|AI Architect Provider (MCP)"
        "config|http|${CONFIG_URL}|AI Architect Config"
        "manager|http|${MANAGER_URL}|AI Architect Manager"
        "mysql|mysql|${MYSQL_PORT}|MySQL Database"
        "worker|container|ai-architect-worker|AI Architect Worker"
    )
    local entry name kind target display info
    for entry in "${services[@]}"; do
        IFS='|' read -r name kind target display <<< "$entry"
        case "$kind" in
            http)
                if is_http_healthy "$target"; then
                    _diag_pass "$display healthy"
                    [ "$verbose" = "true" ] && echo "    URL: $target"
                else
                    _diag_fail "$display not healthy ($target)" services
                fi
                ;;
            mysql)
                if is_mysql_reachable localhost "$target"; then
                    _diag_pass "$display reachable"
                    [ "$verbose" = "true" ] && echo "    Port: $target"
                else
                    _diag_fail "$display not reachable (port $target)" services
                fi
                ;;
            container)
                if info=$(probe_container_health "$target"); then
                    _diag_pass "$display running"
                    [ "$verbose" = "true" ] && echo "    Container: $target ($info)"
                else
                    _diag_fail "$display container not healthy ($info)" services
                fi
                ;;
        esac
    done
}

diag_section_connectivity() {
    local verbose="$1"
    print_subheader "▶ Connectivity"

    # On k8s the CLI reaches services over on-demand port-forwards; open the ones
    # this section probes so connectivity reflects real reachability, not a missing tunnel.
    if command -v is_kubernetes_deployment >/dev/null 2>&1 && is_kubernetes_deployment \
       && command -v ensure_service_accessible >/dev/null 2>&1; then
        [ -n "${MYSQL_PORT:-}" ] && ensure_service_accessible "ai-architect-mysql" "$MYSQL_PORT" 2>/dev/null || true
        ensure_service_accessible "ai-architect-provider" "${CIS_PROVIDER_EXTERNAL_PORT:-5001}" 2>/dev/null || true
    fi

    if is_env_var_set MYSQL_PORT; then
        # A just-opened forward binds the local port a beat before it carries
        # traffic; retry briefly so a cold probe doesn't false-negative.
        local _mysql_ok=0 _mp
        for _mp in 1 2 3 4 5; do
            if is_port_reachable localhost "$MYSQL_PORT"; then _mysql_ok=1; break; fi
            sleep 1
        done
        if [ "$_mysql_ok" = 1 ]; then
            if [ "$verbose" = "true" ]; then
                _diag_pass "MySQL port reachable (localhost:${MYSQL_PORT})"
            else
                _diag_pass "MySQL port reachable"
            fi
        else
            _diag_fail "MySQL port not reachable (localhost:${MYSQL_PORT})" connectivity
        fi
    else
        _diag_warn "MYSQL_PORT not set; skipping MySQL port probe"
    fi

    if is_env_var_set PROVIDER_URL && is_env_var_set PROVIDER_TOKEN; then
        local result
        result=$(probe_mcp_endpoint "$PROVIDER_URL" "$PROVIDER_TOKEN")
        case "$result" in
            ok)
                _diag_pass "MCP endpoint responsive (tools/list OK)"
                # Deeper, compact MCP tool validation (listRepositories anchor
                # + chain). Per-tier detail is captured in the --bundle file.
                mcp_validate_live "$verbose"
                ;;
            timeout)     _diag_fail "MCP endpoint timed out (${PROVIDER_URL}/mcp)" connectivity ;;
            unreachable) _diag_fail "MCP endpoint unreachable (${PROVIDER_URL}/mcp)" connectivity ;;
            *)           _diag_fail "MCP endpoint test failed ($result)" connectivity ;;
        esac
    else
        _diag_warn "PROVIDER_URL or PROVIDER_TOKEN not set; skipping MCP probe"
    fi

    # Presence-only -- deep API-key validation runs only at install time.
    if is_env_var_set BITO_API_KEY; then
        _diag_pass "BITO_API_KEY present"
    fi
}

# HTTPS cert state. No-op unless MCP_TRANSPORT=https.
# ▶ Wingman: the shared runtime (binary + tools + base skills) plugins execute.
# Customer-facing: reports presence + versions only, never internal shelf paths /
# volume names. Reads the shelf via the engine's own version helpers (one
# in-container read); best-effort — degrades cleanly when the shelf isn't synced.
diag_section_wingman() {
    local verbose="$1" deployment_type="$2"
    print_subheader "▶ Wingman"

    local _self; _self="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    type wingman_shelf_versions >/dev/null 2>&1 || . "${_self}/wingman-shelf.sh" 2>/dev/null || true
    if ! type wingman_shelf_versions >/dev/null 2>&1; then
        _diag_pass "Wingman runtime not present in this build"
        return 0
    fi

    local trio bver tver sver
    trio="$(wingman_shelf_versions 2>/dev/null)"
    bver="${trio%%|*}"; tver="$(printf '%s' "$trio" | cut -d'|' -f2)"; sver="$(printf '%s' "$trio" | cut -d'|' -f3)"

    if [ -n "$bver" ]; then
        _diag_pass "Wingman runtime: v${bver}"
    else
        _diag_warn "Wingman runtime not synced yet (checks daily; runs on plugin install/upgrade)"
        return 0
    fi
    if [ -n "$tver" ]; then _diag_pass "Tools bundle: v${tver}"
    else                    _diag_warn "Tools bundle not present"; fi
    if [ -n "$sver" ]; then _diag_pass "Base skills: v${sver}"
    else                    [ "$verbose" = "true" ] && echo "    no base skills on the shelf yet"; fi
    return 0
}

# ▶ Ingress: the front door that publishes the MCP endpoint + plugin webhooks.
# Bundled NGINX controller on k8s (class ai-architect-nginx) / the ai-architect-ingress
# container on docker, unless the operator brought their own (BITOARCH_INGRESS_CLASS).
diag_section_ingress() {
    local verbose="$1" deployment_type="$2"
    print_subheader "▶ Ingress"

    local host="${BITOARCH_INGRESS_HOST:-}" class="${BITOARCH_INGRESS_CLASS:-}"

    if [ "$deployment_type" = "kubernetes" ]; then
        local ns="bito-ai-architect"
        if [ -n "$class" ]; then
            _diag_pass "Using your own ingress controller (class: ${class}) — route your public host to it (usually 80/443)"
        else
            local info
            if info=$(probe_k8s_deployment ai-architect-ingress-controller "$ns" 2>/dev/null); then
                _diag_pass "Built-in ingress controller ready (${info})"
            else
                _diag_fail "Built-in ingress controller not ready (${info:-absent})" ingress
                # Surface the likely cause: a node hostPort 80/443 clash keeps the pod Pending.
                local why
                why="$(kubectl get pods -n "$ns" -l app.kubernetes.io/name=ai-architect-ingress-controller \
                       -o jsonpath='{range .items[*]}{.status.conditions[?(@.type=="PodScheduled")].message}{end}' 2>/dev/null)"
                [ -n "$why" ] && echo "    reason: ${why}"
                echo "    If a node port 80/443 is in use: set BITOARCH_INGRESS_EXPOSURE=nodeport (front door -> 30080/30443), or reuse your controller via BITOARCH_INGRESS_CLASS."
            fi
            if kubectl get ingressclass ai-architect-nginx >/dev/null 2>&1; then
                _diag_pass "IngressClass ai-architect-nginx present"
            else
                _diag_warn "IngressClass ai-architect-nginx not found"
            fi
            # Report how the front door is actually reachable (read the live Service).
            local svc_type nph nps
            svc_type="$(kubectl get svc ai-architect-ingress-controller -n "$ns" -o jsonpath='{.spec.type}' 2>/dev/null)"
            case "$svc_type" in
                NodePort)
                    nph="$(kubectl get svc ai-architect-ingress-controller -n "$ns" -o jsonpath='{.spec.ports[?(@.name=="http")].nodePort}' 2>/dev/null)"
                    nps="$(kubectl get svc ai-architect-ingress-controller -n "$ns" -o jsonpath='{.spec.ports[?(@.name=="https")].nodePort}' 2>/dev/null)"
                    _diag_pass "Front door: NodePort http=${nph:-30080} https=${nps:-30443} — expose <nodeIP>:${nph:-30080} to the internet" ;;
                LoadBalancer)
                    _diag_pass "Front door: LoadBalancer service (use its external address)" ;;
                *)
                    _diag_pass "Front door: hostPort 80/443 on the node (kind/single-node mode)" ;;
            esac
        fi
        local ings; ings="$(kubectl get ingress -n "$ns" -o jsonpath='{range .items[*]}{.metadata.name}{" "}{end}' 2>/dev/null)"
        if [ -n "${ings// /}" ]; then
            local _n; _n=$(printf '%s' "$ings" | wc -w | tr -d ' ')
            _diag_pass "${_n} Ingress route(s) defined"
            if [ "$verbose" = "true" ]; then
                local i
                for i in $ings; do
                    echo "    ${i} -> host: $(kubectl get ingress "$i" -n "$ns" -o jsonpath='{.spec.rules[*].host}' 2>/dev/null)"
                done
            fi
        else
            _diag_warn "No Ingress routes defined yet"
        fi
    else
        local st port="${INGRESS_PORT:-5080}"
        if st=$(probe_container_health ai-architect-ingress 2>/dev/null); then
            _diag_pass "Ingress container running (${st})"
            [ "$verbose" = "true" ] && echo "    front-door host port: ${port}"
        elif docker ps -a --format '{{.Names}}' 2>/dev/null | grep -qx "ai-architect-ingress"; then
            # Exists but not running (Created/Exited) -> report WHY. A host-port
            # clash is by far the most common cause and leaves it stuck "Created".
            local state err
            state="$(docker inspect ai-architect-ingress --format '{{.State.Status}}' 2>/dev/null)"
            err="$(docker inspect ai-architect-ingress --format '{{.State.Error}}' 2>/dev/null)"
            if printf '%s' "$err" | grep -qiE 'port is already allocated|address already in use|bind for'; then
                _diag_fail "Ingress not running (${state:-created}) — host port ${port} is already in use" ingress
                echo "    Fix: set INGRESS_PORT to a free port in .env-bitoarch and re-run, or free port ${port}."
            elif [ -n "$err" ]; then
                _diag_fail "Ingress not running (${state:-created}): ${err}" ingress
            else
                _diag_fail "Ingress not running (${state:-created}) — see: docker logs ai-architect-ingress" ingress
            fi
        else
            _diag_warn "Ingress container not created yet — expected only until a plugin with public endpoints is installed"
            [ "$verbose" = "true" ] && echo "    front-door host port: ${port}"
        fi
    fi

    # Public endpoint: the operator-facing field is each plugin's PUBLIC_URL (the
    # external HTTPS address that forwards to the ingress; mandatory for plugins
    # with webhooks). BITOARCH_INGRESS_HOST is only the k8s Ingress host rule
    # (auto-adopted from PUBLIC_URL); docker never sets it — the ingress serves all
    # hosts. So report the configured PUBLIC_URL, not the host var.
    local _self2; _self2="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    type journal_list_plugins >/dev/null 2>&1 || . "${_self2}/plugin/state-journal.sh" 2>/dev/null || true
    type get_plugin_env_file  >/dev/null 2>&1 || . "${_self2}/path-manager.sh"          2>/dev/null || true
    local _pu="" _pp _pef
    if type journal_list_plugins >/dev/null 2>&1 && type get_plugin_env_file >/dev/null 2>&1; then
        while IFS= read -r _pp; do
            [ -n "$_pp" ] || continue
            _pef="$(get_plugin_env_file "$_pp" 2>/dev/null)"
            [ -f "$_pef" ] || continue
            _pu="$(grep -E '^PUBLIC_URL=' "$_pef" 2>/dev/null | head -1 | cut -d= -f2- | tr -d '"')"
            [ -n "$_pu" ] && break
        done <<PUBURL
$(journal_list_plugins 2>/dev/null)
PUBURL
    fi
    if [ -n "$_pu" ]; then
        _diag_pass "Public URL configured: ${_pu}"
    elif [ -n "$host" ]; then
        _diag_pass "Ingress host: ${host}"
    else
        _diag_pass "No public URL configured yet — a plugin that exposes webhooks will prompt for one"
    fi
    return 0
}

# Per-plugin service listing for the Plugins section: each installed plugin's OWN
# containers (docker) / pods (k8s) with name, state/status, health and ports.
# Reuses collect-plugins.sh's container/release resolution so the listing matches
# the support bundle. Best-effort: a "skipping" line when docker/kubectl is
# unreachable, "none found" on empty -- never errors.
_diag_plugin_services() {
    local name="$1" deployment_type="$2"

    if [ "$deployment_type" = "kubernetes" ]; then
        if ! bundle_have_kubectl; then
            echo "    services: kubectl/cluster unreachable -- skipping"
            return 0
        fi
        local ns rel pods pn ps
        ns="$(_cp_k8s_ns 2>/dev/null)"; rel="$(_cp_helm_release "$name" 2>/dev/null)"
        pods="$(kubectl get pods -n "$ns" -l "app.kubernetes.io/instance=${rel}" \
                --no-headers -o custom-columns='N:.metadata.name,S:.status.phase' 2>/dev/null)"
        if [ -z "$pods" ]; then
            echo "    services: none found"
            return 0
        fi
        local _pg
        while read -r pn ps; do
            [ -z "$pn" ] && continue
            _pg="${GREEN:-}✓${NC:-}"; [ "$ps" = "Running" ] || _pg="${YELLOW:-}⚠${NC:-}"
            printf '    %b %s %s\n' "$_pg" "$pn" "${ps:-unknown}"
        done <<PODS
$pods
PODS
        return 0
    fi

    if ! bundle_have_docker; then
        echo "    services: docker daemon not reachable -- skipping"
        return 0
    fi
    local ids id cname status health ports
    ids="$(_cp_project_container_ids "$name" 2>/dev/null)"
    if [ -z "$ids" ]; then
        echo "    services: none found"
        return 0
    fi
    local _cg
    for id in $ids; do
        cname="$(docker inspect --format='{{.Name}}'         "$id" 2>/dev/null | sed 's#^/##')"
        status="$(docker inspect --format='{{.State.Status}}' "$id" 2>/dev/null)"
        health="$(docker inspect --format='{{.State.Health.Status}}' "$id" 2>/dev/null)"
        [ -z "$health" ] || [ "$health" = "<no value>" ] && health="none"
        _cg="${GREEN:-}✓${NC:-}"
        { [ "$status" = "running" ] && { [ "$health" = "healthy" ] || [ "$health" = "none" ]; }; } || _cg="${YELLOW:-}⚠${NC:-}"
        if [ "$health" = "none" ]; then
            printf '    %b %s %s\n' "$_cg" "${cname:-$id}" "${status:-missing}"
        else
            printf '    %b %s %s (%s)\n' "$_cg" "${cname:-$id}" "${status:-missing}" "$health"
        fi
    done
    return 0
}

# ▶ Plugins: installed plugins + shared dependency packs, per-record state/health.
# Reuses the plugin engine's own journal + live health probe (same source as
# `bitoarch plugin list`), so docker + k8s are covered by that layer. No-op-clean
# when the framework isn't present or nothing is installed.
diag_section_plugins() {
    local verbose="$1" deployment_type="$2"
    print_subheader "▶ Plugins"

    local _self; _self="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    type journal_list_plugins >/dev/null 2>&1 || . "${_self}/plugin/state-journal.sh" 2>/dev/null || true
    type _plugin_current_health >/dev/null 2>&1 || . "${_self}/plugin/deploy.sh" 2>/dev/null || true
    # Container/pod + release resolution for the per-plugin service listing.
    type _cp_project_container_ids >/dev/null 2>&1 || . "${_self}/diagnose/collect-plugins.sh" 2>/dev/null || true
    # Reconcile live state into the journal first (same helpers `plugin list` uses),
    # so a stale "installing"/"unknown" snapshot never misleads the diagnostic.
    type _plugin_reconcile_status  >/dev/null 2>&1 || . "${_self}/plugin/plugin-status.sh" 2>/dev/null || true
    type _lc_reconcile_pack_health >/dev/null 2>&1 || . "${_self}/plugin/lifecycle.sh"     2>/dev/null || true
    type _lc_reconcile_pack_health >/dev/null 2>&1 && _lc_reconcile_pack_health >/dev/null 2>&1 || true
    if ! type journal_list_plugins >/dev/null 2>&1; then
        _diag_pass "Plugin framework not present in this build"
        return 0
    fi

    local plugins; plugins="$(journal_list_plugins 2>/dev/null)"
    if [ -z "$plugins" ]; then
        _diag_pass "No plugins installed"
    else
        local p st he
        while IFS= read -r p; do
            [ -z "$p" ] && continue
            st="$(journal_plugin_field "$p" status 2>/dev/null)"
            he="$(_plugin_current_health "$p" 2>/dev/null)"
            case "$he" in ""|unknown) he="$(journal_plugin_field "$p" health 2>/dev/null)" ;; esac
            # Live-reconcile the displayed status (installing→running/pending, etc.).
            type _plugin_reconcile_status >/dev/null 2>&1 && st="$(_plugin_reconcile_status "$p" "$st" "$he" 2>/dev/null || echo "$st")"
            case "${he:-unknown}" in
                healthy|ok|running) _diag_pass "${p}: ${st:-installed} (${he})" ;;
                stopped|starting)   _diag_warn "${p}: ${st:-installed} (${he})" ;;
                *)                  if [ "$st" = "pending" ]; then
                                        _diag_warn "${p}: pending setup (run: bitoarch plugin config ${p})"
                                    else
                                        _diag_fail "${p}: ${st:-installed} (${he:-unknown})" plugins
                                    fi ;;
            esac
            # The plugin's OWN services (containers/pods): name, status, health, ports.
            _diag_plugin_services "$p" "$deployment_type"
            # Verbose: version + deployment surface on an indented detail line.
            [ "$verbose" = "true" ] && echo "    v$(journal_plugin_field "$p" version 2>/dev/null) · ${deployment_type}"
            # A staged upgrade held on a missing credential is an actionable finding.
            local _hold
            _hold="$(journal_get_plugin "$p" 2>/dev/null | jq -r '.upgrade_hold.version // empty' 2>/dev/null)"
            [ -n "$_hold" ] && _diag_warn "${p}: upgrade to v${_hold} on hold (missing config; run: bitoarch plugin config ${p})"
        done <<PLG
$plugins
PLG
    fi

    # Shared dependency packs (kafka/redis), if any.
    if type journal_list_packs >/dev/null 2>&1; then
        local cap pk ph
        for cap in $(journal_list_packs 2>/dev/null); do
            pk="$(journal_pack_get "$cap" 2>/dev/null | jq -r '.pack // empty' 2>/dev/null)"
            ph="$(journal_pack_get "$cap" 2>/dev/null | jq -r '.health // "unknown"' 2>/dev/null)"
            [ -n "$pk" ] || continue
            case "$ph" in
                healthy) _diag_pass "pack ${pk} (${cap}): healthy" ;;
                unhealthy) _diag_fail "pack ${pk} (${cap}): unhealthy" plugins ;;
                *) _diag_warn "pack ${pk} (${cap}): ${ph}" ;;
            esac
        done
    fi
    return 0
}

diag_section_cert() {
    local verbose="$1"
    print_subheader "▶ Certificates"

    if [ "${MCP_TRANSPORT:-}" != "https" ]; then
        if [ "$verbose" = "true" ]; then
            _diag_pass "HTTPS not enabled (MCP_TRANSPORT=${MCP_TRANSPORT:-unset}); cert checks skipped"
        else
            _diag_pass "HTTPS not enabled; cert checks skipped"
        fi
        return 0
    fi

    if ! is_env_var_set HOST_MCP_CERT_DIR; then
        _diag_fail "HOST_MCP_CERT_DIR not set (MCP_TRANSPORT=https)" cert
        return 0
    fi

    if [ ! -d "$HOST_MCP_CERT_DIR" ]; then
        _diag_fail "Cert directory missing: $HOST_MCP_CERT_DIR" cert
        return 0
    fi

    local count
    if count=$(cert_file_count "$HOST_MCP_CERT_DIR"); then
        if [ "$verbose" = "true" ]; then
            _diag_pass "Cert files present in $HOST_MCP_CERT_DIR (count: $count)"
        else
            _diag_pass "Cert files present"
        fi
    else
        _diag_fail "No cert files in $HOST_MCP_CERT_DIR" cert
    fi
}

# ─── Entry point and its helpers ──────────────────────────────────────────
# Exit codes: 0 all-green, 1 warnings only, 2 any failure.
#
# platform_diagnose is a thin dispatcher. The pieces it composes:
#   _platform_diagnose_help     -- prints the heredoc help text and returns 0.
#   _platform_diagnose_parse    -- parses argv into _DIAG_OPT_* globals;
#                                  returns 2 on missing required values.
#   _platform_diagnose_resolve_deployment
#                               -- auto-detects deployment type from the
#                                  .deployment-type marker into
#                                  _DIAG_OPT_DEPLOYMENT_TYPE.
#   _platform_diagnose_live     -- runs the live pass/warn/fail sweep and
#                                  prints the per-section summary.
# Each helper is one concern; platform_diagnose just sequences them.

_platform_diagnose_help() {
    cat << 'EOF'
USAGE:
  bitoarch diagnose [OPTIONS]

DESCRIPTION:
  Comprehensive diagnostic of the AI Architect setup. Two modes:
    - live (default) : print pass/warn/fail per section to the terminal
    - --bundle       : collect all debug info into a shareable .tar.gz
                       (for sharing with Bito support)

OPTIONS:
  Live mode:
    --verbose, -v             Show URLs, ports, and detail on failures
    --section <name>          Run a single section. Valid: prereqs, install,
                              filesystem, config, services, connectivity, ingress, plugins, wingman, cert
                              (connectivity also runs deterministic MCP tool
                              validation: listRepositories anchor + chain;
                              0 indexed repos warns, never fails)

  Bundle mode:
    --bundle                  Produce diagnostics-<timestamp>.tar.gz instead
                              of the live terminal sweep. Collects system info,
                              service status + resource usage, last 1000 lines
                              of logs (container + app), redacted .env,
                              DB health, connectivity probes, indexing status,
                              and temporal status (task queues, workflows,
                              worker deployments). Secrets auto-redacted.
    --output <path>           Output directory for the .tar.gz
                              (default: $HOME/.bitoarch/diagnostics)
    --keep-workdir            Keep the unpacked workdir alongside the archive
                              (useful for live debugging on the host)

  --help, -h                  Show this help

EXAMPLES:
  bitoarch diagnose                              # live sweep
  bitoarch diagnose --verbose
  bitoarch diagnose --section services
  bitoarch diagnose --section connectivity       # incl. live MCP tool validation
  bitoarch diagnose --bundle                     # produce .tar.gz for support
  bitoarch diagnose --bundle --output /tmp/debug
EOF
}

# Populates _DIAG_OPT_* globals. Returns 2 on a missing required value.
# Unknown *flags* (leading dash) warn-and-continue so a typo in a support-chat
# copy-paste surfaces as an explicit warning instead of a silently-mis-parsed
# run. A bare positional token (no dash) is almost always an unquoted path with
# spaces that the shell already word-split, so it aborts with a quote-the-path
# error instead of proceeding with a silently-truncated --output.
_platform_diagnose_parse() {
    _DIAG_OPT_VERBOSE=false
    _DIAG_OPT_SECTION=""
    _DIAG_OPT_BUNDLE=false
    _DIAG_OPT_KEEP_WORKDIR=false
    _DIAG_OPT_OUTPUT_BASE="${HOME}/.bitoarch/diagnostics"

    while [[ $# -gt 0 ]]; do
        case "$1" in
            --verbose|-v) _DIAG_OPT_VERBOSE=true; shift ;;
            --section)
                if [ -z "${2:-}" ]; then
                    print_error "--section requires a name"
                    return 2
                fi
                _DIAG_OPT_SECTION="$2"; shift 2 ;;
            --section=*) _DIAG_OPT_SECTION="${1#--section=}"; shift ;;
            --bundle) _DIAG_OPT_BUNDLE=true; shift ;;
            --output)
                if [ -z "${2:-}" ]; then
                    print_error "--output requires a path"
                    return 2
                fi
                _DIAG_OPT_OUTPUT_BASE="$2"; shift 2 ;;
            --output=*) _DIAG_OPT_OUTPUT_BASE="${1#--output=}"; shift ;;
            --keep-workdir) _DIAG_OPT_KEEP_WORKDIR=true; shift ;;
            -*) print_warning "Ignoring unknown flag: $1"; shift ;;
            *)
                print_error "Unexpected argument: '$1'"
                print_error "diagnose takes no positional arguments. If a path contains spaces, quote it, e.g. --output \"/path/with spaces\""
                return 2 ;;
        esac
    done
    return 0
}

# Auto-detects the deployment type via get_deployment_type -- the canonical
# reader every other bitoarch command uses, so diagnose resolves the same value
# for a given install. Diagnose intentionally has no manual override: a type
# that disagreed with the actual environment would make every collector silently
# run the wrong code path. When the marker is missing or unreadable the reader
# yields "unknown"; we warn (a bundle on a Kubernetes host would otherwise run
# docker-compose checks with no signal) and fall back to the documented
# docker-compose default, since collectors only branch docker-vs-kubernetes.
_platform_diagnose_resolve_deployment() {
    _DIAG_OPT_DEPLOYMENT_TYPE=$(get_deployment_type 2>/dev/null)
    case "$_DIAG_OPT_DEPLOYMENT_TYPE" in
        docker-compose|kubernetes) ;;
        *)
            print_warning "Deployment type marker not found or unreadable; assuming docker-compose. If this host runs Kubernetes, the report may target the wrong runtime -- restore $(get_deployment_type_file 2>/dev/null) to fix."
            _DIAG_OPT_DEPLOYMENT_TYPE="docker-compose"
            ;;
    esac
    return 0
}

# Runs the live diagnose sweep -- header, section loop, summary, rc.
# Args: verbose, single_section, deployment_type. Returns 0/1/2 per the
# documented exit codes (all-green / warnings / failed).
_platform_diagnose_live() {
    local verbose="$1" single_section="$2" deployment_type="$3"

    _DIAG_PASSED=0
    _DIAG_WARNED=0
    _DIAG_FAILED=0
    _DIAG_FAILED_SECTIONS=""

    # _DIAG_SUPPRESS_HEADER is set by the bundler so the captured live-sweep
    # output doesn't double the bundle header.
    [ -z "${_DIAG_SUPPRESS_HEADER:-}" ] && print_header "Bito's AI Architect Diagnostic"
    echo ""
    if [ "$verbose" = "true" ]; then
        echo "Deployment: $deployment_type"
        echo ""
    fi

    local sections="prereqs install filesystem config services connectivity ingress plugins wingman cert"
    if [ -n "$single_section" ]; then
        case " $sections " in
            *" $single_section "*) sections="$single_section" ;;
            *)
                print_error "Unknown section: $single_section"
                echo "Valid: prereqs, install, filesystem, config, services, connectivity, ingress, plugins, wingman, cert"
                return 2 ;;
        esac
    fi

    local section
    for section in $sections; do
        case "$section" in
            prereqs)      diag_section_prereqs       "$verbose" "$deployment_type" ;;
            install)      diag_section_install_state "$verbose" "$deployment_type" ;;
            filesystem)   diag_section_filesystem    "$verbose" "$deployment_type" ;;
            config)       diag_section_config_files  "$verbose" ;;
            services)     diag_section_services      "$verbose" "$deployment_type" ;;
            connectivity) diag_section_connectivity  "$verbose" ;;
            ingress)      diag_section_ingress       "$verbose" "$deployment_type" ;;
            plugins)      diag_section_plugins       "$verbose" "$deployment_type" ;;
            wingman)      diag_section_wingman       "$verbose" "$deployment_type" ;;
            cert)         diag_section_cert          "$verbose" ;;
        esac
        echo ""
    done

    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    log_silent "Diagnostic summary: $_DIAG_PASSED passed, $_DIAG_WARNED warnings, $_DIAG_FAILED failed"
    echo "Diagnostic summary: ${_DIAG_PASSED} passed, ${_DIAG_WARNED} warnings, ${_DIAG_FAILED} failed"
    echo ""

    if [ "$_DIAG_FAILED" -gt 0 ]; then
        print_error "Issues found${_DIAG_FAILED_SECTIONS:+ in:${_DIAG_FAILED_SECTIONS}}"
        [ "$verbose" = "true" ] || print_info "Run with --verbose for details"
        print_info "Logs: ${YELLOW}bitoarch logs <service>${NC}"
        return 2
    elif [ "$_DIAG_WARNED" -gt 0 ]; then
        print_warning "Setup OK with warnings"
        [ "$verbose" = "true" ] || print_info "Run with --verbose for details"
        return 1
    else
        print_success "All diagnostic checks passed"
        return 0
    fi
}

platform_diagnose() {
    if [ "$1" = "--help" ] || [ "$1" = "-h" ]; then
        _platform_diagnose_help
        return 0
    fi

    # Guard against errexit leaked by sourced helpers -- atomic predicates
    # return non-zero by design and that must not abort the sweep.
    set +e

    _platform_diagnose_parse "$@" || return $?
    _platform_diagnose_resolve_deployment || return $?

    # Bundle mode delegates to bundler.sh. BITOARCH_DIAG_INTERNAL_SKIP_BUNDLE
    # is set by the bundler when it re-enters us to capture the live sweep;
    # that env var short-circuits this branch to avoid infinite recursion.
    if [ "$_DIAG_OPT_BUNDLE" = "true" ] && [ -z "${BITOARCH_DIAG_INTERNAL_SKIP_BUNDLE:-}" ]; then
        if ! type bundle_diagnostics >/dev/null 2>&1; then
            print_error "Bundle modules not loaded (scripts/lib/diagnose/ missing?)"
            return 2
        fi
        bundle_diagnostics "$_DIAG_OPT_DEPLOYMENT_TYPE" "$_DIAG_OPT_VERBOSE" \
            "$_DIAG_OPT_OUTPUT_BASE" "$_DIAG_OPT_KEEP_WORKDIR"
        return $?
    fi

    _platform_diagnose_live "$_DIAG_OPT_VERBOSE" "$_DIAG_OPT_SECTION" "$_DIAG_OPT_DEPLOYMENT_TYPE"
}
