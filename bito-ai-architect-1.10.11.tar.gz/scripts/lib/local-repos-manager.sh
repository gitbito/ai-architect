#!/bin/bash
#
# Copyright (c) 2023-2026 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
#
# Local repos manager -- 'bitoarch import-repos' for the credential-less
# "local" git provider. Copies the operator's pre-cloned repositories from a
# host directory onto the shared data volume (the worker's clone directory)
# and registers each with cis-config, so indexing runs without any git
# credentials. The copy is streamed as a tar pipe into the RUNNING manager
# container/pod (which mounts the data volume and ships git) -- a bind mount
# is not visible on VM-backed docker daemons, and on Kubernetes the exec
# stream works regardless of node topology (no hostPath / RWX needed).

if [ -n "${_BITOARCH_LOCAL_REPOS_LOADED:-}" ]; then return 0; fi
_BITOARCH_LOCAL_REPOS_LOADED=1

# Service names come from constants.sh, which bitoarch.sh does not source on
# every dispatch path (it is lazy-loaded by other adapters) -- load it here so
# this lib never depends on another module's side effect.
if [ -z "${SERVICE_MANAGER_NAME:-}" ]; then
    # shellcheck disable=SC1091
    source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/constants.sh" 2>/dev/null || true
fi

# Marker dropped inside every imported repo. cis-manager reads it to keep the
# copy on repo removal; content "synthetic" additionally forces full (never
# incremental) indexing. Must match cis-manager models.LocalImportMarkerFile.
LOCAL_IMPORT_MARKER_FILE=".bito-local-import"
# Namespaces are registered as "local/<dir>" -- two segments, so the existing
# namespace validation and repo-dir derivation (last segment) work unchanged.
LOCAL_IMPORT_NAMESPACE_PREFIX="local"
# Staging older than this is assumed orphaned by an interrupted run. Well above
# the time a multi-GB repository takes to stream, so a run still in flight --
# including one driven from another host, which a local lock cannot serialize
# -- is never swept.
LOCAL_IMPORT_STALE_MINUTES="${LOCAL_IMPORT_STALE_MINUTES:-240}"

# Manager pod/container coordinates on Kubernetes (docker uses the compose
# service name from constants.sh). Overridable for tests.
LOCAL_REPOS_K8S_DEPLOY="${LOCAL_REPOS_K8S_DEPLOY:-ai-architect-manager}"
LOCAL_REPOS_K8S_CONTAINER="${LOCAL_REPOS_K8S_CONTAINER:-manager}"

_lrm_log() { type log_silent >/dev/null 2>&1 && log_silent "import-repos: $1"; }

# _local_repos_exec [--stdin] <script> [ENV=val ...] -- run <script> with sh -c
# inside the running manager, where the shared clone volume is mounted and git
# is available. --stdin forwards the caller's stdin (the tar stream).
_local_repos_exec() {
    local use_stdin=0
    if [ "$1" = "--stdin" ]; then use_stdin=1; shift; fi
    local script="$1"; shift
    local deploy
    deploy="$(get_deployment_type 2>/dev/null || echo docker)"
    case "$deploy" in
        kubernetes)
            local ns pod
            ns="${BITOARCH_K8S_NAMESPACE:-bito-ai-architect}"
            pod="$(kubectl get pods -n "$ns" -o name 2>/dev/null | grep -m1 "$LOCAL_REPOS_K8S_DEPLOY" | sed 's@^pod/@@')"
            if [ -z "$pod" ]; then
                print_error "No running ${LOCAL_REPOS_K8S_DEPLOY} pod found -- is the platform running?"
                return 1
            fi
            if [ "$use_stdin" = "1" ]; then
                kubectl exec -i -n "$ns" "$pod" -c "$LOCAL_REPOS_K8S_CONTAINER" -- env "$@" sh -c "$script"
            else
                kubectl exec -n "$ns" "$pod" -c "$LOCAL_REPOS_K8S_CONTAINER" -- env "$@" sh -c "$script"
            fi
            ;;
        *)
            local envargs=()
            local kv
            for kv in "$@"; do envargs+=( -e "$kv" ); done
            if [ "$use_stdin" = "1" ]; then
                docker exec -i "${envargs[@]}" "${SERVICE_MANAGER_NAME:-ai-architect-manager}" sh -c "$script"
            else
                docker exec "${envargs[@]}" "${SERVICE_MANAGER_NAME:-ai-architect-manager}" sh -c "$script"
            fi
            ;;
    esac
}

# HEAD of an already-imported repo on the shared volume ("" when absent).
_local_repos_imported_head() {
    local dest="$1"
    _local_repos_exec "git -C \"\$DEST\" rev-parse HEAD 2>/dev/null || true" "DEST=$dest" 2>/dev/null | tr -d '[:space:]'
}

# Stream one repository into the clone dir and normalize it in-container.
#
# Two phases on purpose. A file the host cannot read is skipped by tar with a
# non-zero exit, but the archive it emits is still structurally valid -- so a
# single-phase script would extract that partial content and swap it into place
# before the writer's exit status is ever known, leaving an incomplete copy
# that shares the source HEAD and is therefore skipped by every later run.
# Phase 1 only extracts into a staging directory; phase 2 normalizes and swaps,
# and runs solely when both pipe stages were clean.
#
# Normalization: neutralize 'origin' (nothing may ever try the customer's
# remote from inside CIS), drop the import marker, and for plain trees
# synthesize git history -- preserving the previous synthetic .git across
# re-imports so an unchanged tree keeps its HEAD (and is skipped by the
# indexer). The stage sits next to the destination (same filesystem) so the
# final swap is a rename.
_local_repos_stage_one() {
    local src="$1" name="$2" kind="$3" clone_dir="$4"
    # The two phases run in different container shells, so the stage name comes
    # from the host: an in-container $$ would not resolve to the same directory
    # twice. PID alone is not unique -- two workstations driving the same pod
    # can share one.
    local stage_id
    stage_id="$$-$(date +%s)-${RANDOM:-0}"
    local script_extract script_commit
    # shellcheck disable=SC2016  # single-quoted on purpose: $VARs resolve in-container
    script_extract='set -e
stage="$CLONE_DIR/.import-stage-$REPO_NAME.$STAGE_ID"
rm -rf "$stage"
mkdir -p "$stage"
# Pinned rather than inherited: as root, tar would otherwise restore the host
# uid/gid onto the shared volume and lock the services out of their own clones.
tar -C "$stage" --no-same-owner --no-same-permissions -xf -'
    # shellcheck disable=SC2016  # single-quoted on purpose: $VARs resolve in-container
    script_commit='set -e
stage="$CLONE_DIR/.import-stage-$REPO_NAME.$STAGE_ID"
dest="$CLONE_DIR/$REPO_NAME"
[ -d "$stage" ] || exit 1
if [ "$KIND" = "synthetic" ]; then
    if [ -d "$dest/.git" ]; then
        # Copy (not move): until the final swap the destination must keep a
        # valid .git -- a mid-flight failure plus stage cleanup would otherwise
        # destroy the only copy of the synthesized history.
        cp -a "$dest/.git" "$stage/.git"
    else
        git -C "$stage" init -q
    fi
    printf "synthetic\n" > "$stage/$MARKER"
    git -C "$stage" add -A
    if ! git -C "$stage" diff --cached --quiet 2>/dev/null; then
        git -C "$stage" -c user.email=import@bito.local -c user.name=bitoarch-import commit -qm "bitoarch import-repos"
    fi
else
    # Strip every remote, not just origin: a secondary remote can carry an
    # embedded credential in its URL, and nothing inside CIS may ever contact
    # the customer'"'"'s remotes anyway.
    for r in $(git -C "$stage" remote); do
        git -C "$stage" remote remove "$r" >/dev/null 2>&1 || true
    done
    printf "git\n" > "$stage/$MARKER"
fi
# Owner-side only: the extract already made the service user the owner, and
# the volume is shared with every other container, so nothing here should be
# group- or world-writable. "X" adds execute only where it already exists, so
# git records no mode changes for synthesized history.
chmod -R u+rwX "$stage" 2>/dev/null || true
# Replace by rename, never by deleting in place: rm -rf is not atomic, so a
# failure partway through would leave the destination a stump with the stage
# already consumed. The old copy is only unlinked once the new one is live.
trash="$CLONE_DIR/.import-trash-$REPO_NAME.$STAGE_ID"
rm -rf "$trash" 2>/dev/null || true
if [ -e "$dest" ]; then
    mv "$dest" "$trash"
fi
if ! mv "$stage" "$dest"; then
    # Until this rename lands, trash holds the only copy -- put it back rather
    # than leaving the destination missing.
    if [ -d "$trash" ]; then
        mv "$trash" "$dest"
    fi
    exit 1
fi
# Garbage from here on, so repairing modes to delete it cannot cost data.
rm -rf "$trash" 2>/dev/null || { chmod -R u+rwX "$trash" 2>/dev/null || true; rm -rf "$trash" 2>/dev/null || true; }'
    # --no-xattrs: macOS provenance xattrs otherwise emit harmless-but-noisy
    # "unknown extended header" warnings from the in-container tar.
    COPYFILE_DISABLE=1 tar --no-xattrs -C "$src" -cf - . 2>>"${LOG_FILE:-/dev/null}" | \
        _local_repos_exec --stdin "$script_extract" \
            "CLONE_DIR=$clone_dir" "REPO_NAME=$name" "STAGE_ID=$stage_id"
    # Both pipe stages must be clean before anything replaces the destination.
    local pipe_status=("${PIPESTATUS[@]}")
    local rc="${pipe_status[1]:-1}"
    if [ "${pipe_status[0]:-1}" -ne 0 ]; then
        rc=1
    fi
    if [ "$rc" -eq 0 ]; then
        _local_repos_exec "$script_commit" \
            "CLONE_DIR=$clone_dir" "REPO_NAME=$name" "STAGE_ID=$stage_id" \
            "KIND=$kind" "MARKER=$LOCAL_IMPORT_MARKER_FILE"
        rc=$?
    fi
    if [ "$rc" -ne 0 ]; then
        # Best-effort stage cleanup; the swap only happens on full success.
        _local_repos_exec 'rm -rf "$CLONE_DIR/.import-stage-$REPO_NAME.$STAGE_ID" "$CLONE_DIR/.import-trash-$REPO_NAME.$STAGE_ID" 2>/dev/null || true' \
            "CLONE_DIR=$clone_dir" "REPO_NAME=$name" "STAGE_ID=$stage_id" >/dev/null 2>&1
    fi
    return "$rc"
}

# bitoarch import-repos <source-path> [--allow-non-git]
#
# Scans <source-path> for repositories (immediate subdirectories), copies each
# onto the shared clone volume, and registers it as namespace local/<dir>.
# Requires the platform to be running and the git integration to use
# provider=local. Re-running is the update flow: a git repo whose HEAD already
# matches the imported copy is skipped; anything else is re-synced and picked
# up by the next indexing run.
local_repos_import() {
    # One import at a time on this host: the reclaim below removes staging on
    # the shared volume, and two runs would otherwise delete each other's
    # mid-flight. Unlocked when cli-core was not loaded (tests drive the impl
    # directly).
    # Prefer the resolved log directory: the CLI already proved it writable by
    # opening it. An unwritable lock path would make flock's redirect fail and
    # take the whole import with it, so fall back rather than gate on it.
    local lock_base=""
    # /dev/null is the log's own last resort; its directory is not a lock home
    # (and is writable when running as root).
    if [ -n "${LOG_FILE:-}" ] && [ "$LOG_FILE" != "/dev/null" ]; then
        lock_base="$(dirname "$LOG_FILE" 2>/dev/null)"
    fi
    if [ ! -w "${lock_base:-/nonexistent}" ]; then
        lock_base="${BITOARCH_LOG_DIR:-}"
    fi
    if [ ! -w "${lock_base:-/nonexistent}" ]; then
        lock_base="${TMPDIR:-/tmp}"
    fi
    if type _bitoarch_flock >/dev/null 2>&1 && [ -w "$lock_base" ]; then
        _bitoarch_flock "${lock_base%/}/bitoarch-import-repos" _local_repos_import_impl "$@"
        return $?
    fi
    _local_repos_import_impl "$@"
}

_local_repos_import_impl() {
    local source_path="" allow_non_git=0 arg source_abs
    for arg in "$@"; do
        case "$arg" in
            --allow-non-git) allow_non_git=1 ;;
            -*)
                print_error "Unknown option: $arg"
                print_info "Usage: bitoarch import-repos <source-path> [--allow-non-git]"
                return 1
                ;;
            *) source_path="$arg" ;;
        esac
    done

    if [ -z "$source_path" ]; then
        print_error "Source path is required"
        print_info "Usage: bitoarch import-repos <source-path> [--allow-non-git]"
        return 1
    fi
    if [ ! -d "$source_path" ]; then
        print_error "Source path not found or not a directory: $source_path"
        return 1
    fi
    # The host tar's stderr is the only diagnostic for an unreadable source
    # file; pin the log in case this lib was sourced without the CLI's own
    # resolution (or with LOG_FILE emptied).
    if [ -z "${LOG_FILE:-}" ] && command -v get_setup_log >/dev/null 2>&1; then
        LOG_FILE="$(get_setup_log 2>/dev/null)"
    fi
    # Absolute from here on: git rejects a relative safe.directory value, which
    # would silently defeat the same-HEAD skip below.
    source_abs="$(cd "$source_path" 2>/dev/null && pwd -P)"
    if [ -z "$source_abs" ]; then
        print_error "Source path is not accessible: $source_path"
        return 1
    fi
    source_path="$source_abs"

    if [ "${GIT_PROVIDER:-}" != "local" ]; then
        print_error "import-repos requires the local git provider (current: ${GIT_PROVIDER:-unset})"
        print_info "Select provider 'Local (pre-cloned repos)' during setup, or run: bitoarch update-git-creds"
        return 1
    fi

    local clone_dir="${CIS_CLONE_DIR:-/opt/bito/ai-architect/data/clone-dir}"
    local size_limit="${CIS_REPO_SIZE_LIMIT:-5368709120}"

    local imported=0 skipped=0 failed=0 registered_new=0
    local dir name kind src_head dest_head size_kb size_bytes du_out du_rc du_msg

    # Reclaim staging orphaned by an interrupted earlier run. Age-scoped, not a
    # blanket wipe: staging that is still being written belongs to a live run,
    # whose destination may exist only there while its two renames complete.
    # shellcheck disable=SC2016  # single-quoted on purpose: $VARs resolve in-container
    _local_repos_exec 'find "$CLONE_DIR" -maxdepth 1 \( -name ".import-stage-*" -o -name ".import-trash-*" \) -mmin +"$STALE_MIN" -exec rm -rf {} + 2>/dev/null || true' \
        "CLONE_DIR=$clone_dir" "STALE_MIN=$LOCAL_IMPORT_STALE_MINUTES" >/dev/null 2>&1

    for dir in "$source_path"/*/; do
        [ -d "$dir" ] || continue
        name="$(basename "$dir")"
        # The glob leaves a trailing slash, which doubles up in every path the
        # operator is shown.
        dir="${dir%/}"

        # Namespace-safe directory names only (matches the add-repo validation).
        if ! printf '%s' "$name" | grep -Eq '^[a-zA-Z0-9_.-]+$'; then
            print_warning "Skipping '$name': directory name has characters not allowed in a repo namespace"
            skipped=$((skipped + 1))
            continue
        fi

        # Must precede kind detection: .git is invisible through a root that
        # cannot be traversed, so the directory would be misread as a plain
        # tree (and imported as one under --allow-non-git).
        if [ ! -r "$dir" ] || [ ! -x "$dir" ]; then
            print_error "Cannot import '$name': not readable by $(id -un 2>/dev/null || echo "the current user")"
            failed=$((failed + 1))
            continue
        fi

        if [ -d "$dir/.git" ]; then
            kind="git"
        elif [ "$allow_non_git" = "1" ]; then
            kind="synthetic"
        else
            print_warning "Skipping '$name': not a git clone (use --allow-non-git to import plain source trees)"
            skipped=$((skipped + 1))
            continue
        fi

        # One walk for two checks, after the kind decision so a directory that
        # was never an import candidate is still just skipped. stdout carries
        # the size (pre-checked so an over-limit repo is not copied only to be
        # marked "Repo Limit" by the indexer); a non-zero exit means part of
        # the tree could not be traversed, which tar would omit silently and
        # the size would under-count.
        du_out="$(du -sk "$dir" 2>&1)"
        du_rc=$?
        if [ "$du_rc" -ne 0 ]; then
            print_error "Cannot import '$name': not fully readable by $(id -un 2>/dev/null || echo "the current user")"
            du_msg="$(printf '%s\n' "$du_out" | grep -v '^[0-9]' | head -1)"
            if [ -n "$du_msg" ]; then
                print_info "$du_msg"
            fi
            print_info "Fix the source permissions, or re-run as a user that can read every file"
            failed=$((failed + 1))
            continue
        fi
        size_kb="$(printf '%s\n' "$du_out" | awk '/^[0-9]/{print $1; exit}')"
        size_bytes=$(( ${size_kb:-0} * 1024 ))
        if [ "$size_bytes" -gt "$size_limit" ]; then
            print_warning "Skipping '$name': size ${size_bytes} bytes exceeds CIS_REPO_SIZE_LIMIT (${size_limit})"
            skipped=$((skipped + 1))
            continue
        fi

        # Register BEFORE the same-HEAD skip: the add API and the local mirror
        # both dedupe, so re-registering every run is free -- and doing it here
        # means a run that copied but failed to register (cis-config briefly
        # down) is healed by the next run instead of being skipped forever.
        if config_repo_add_namespace "${LOCAL_IMPORT_NAMESPACE_PREFIX}/${name}" >/dev/null 2>&1; then
            registered_new=$((registered_new + 1))
        else
            print_error "Could not register ${LOCAL_IMPORT_NAMESPACE_PREFIX}/${name} -- is cis-config reachable? See ${LOG_FILE:-setup.log}"
            failed=$((failed + 1))
            continue
        fi

        # Unchanged git clone (same HEAD as the imported copy) -> nothing to do.
        if [ "$kind" = "git" ]; then
            # -c safe.directory: the operator need not own the clone (a
            # root- or CI-created tree is common). Without it git refuses with
            # "dubious ownership", the HEAD comes back empty, and the skip
            # below never fires -- every run re-copies every repository.
            src_head="$(git -c safe.directory="$dir" -C "$dir" rev-parse HEAD 2>/dev/null || true)"
            dest_head="$(_local_repos_imported_head "$clone_dir/$name")"
            if [ -n "$src_head" ] && [ "$src_head" = "$dest_head" ]; then
                print_info "'$name' is already imported at $src_head (skipped)"
                skipped=$((skipped + 1))
                continue
            fi
        fi

        print_info "Importing '$name' (${kind})..."
        if ! _local_repos_stage_one "$dir" "$name" "$kind" "$clone_dir"; then
            print_error "Failed to import '$name' -- see ${LOG_FILE:-setup.log}"
            failed=$((failed + 1))
            continue
        fi
        imported=$((imported + 1))
        _lrm_log "imported $name kind=$kind"
    done

    echo ""
    print_success "Import complete: ${imported} imported, ${skipped} skipped, ${failed} failed (${registered_new} registered)"
    if [ "$imported" -gt 0 ]; then
        print_info "Run ${YELLOW}bitoarch index-repos${NC} to index the imported repositories"
    fi
    [ "$failed" -eq 0 ]
}
