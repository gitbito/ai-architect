#!/bin/bash
#
# Copyright (c) 2023-2026 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
#
# Offline Wingman bundle -- INSTALL side. Places the packaged bundle onto the
# shared shelf so an install with no outbound network never reaches the CDN.
#
# The host cannot write a docker volume or a PVC directly, so the payload is
# streamed into a short-lived busybox container that mounts the shelf:
#   docker            -- `docker run -v` with the payload over stdin
#   k8s, static NFS   -- a pod mounting the NFS share root inline, BEFORE helm
#                        (the share exists independently of Kubernetes)
#   k8s, dynamic      -- the claim is pre-created and adopted by helm, then a pod
#                        mounts it, BEFORE the apply (see wingman_bundle_seed_before_helm)
#
# Everything here is a no-op unless a validated bundle is present, so a package
# built without --with-wingman behaves exactly as it does today.

if [ -n "${_BITOARCH_WINGMAN_BUNDLE_LOADED:-}" ]; then return 0; fi
_BITOARCH_WINGMAN_BUNDLE_LOADED=1

_BITOARCH_WINGMAN_BUNDLE_LIBDIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Shelf location knobs, matching wingman-shelf.sh so both libs agree when only
# one of them is sourced.
WINGMAN_SHELF_MOUNT="${WINGMAN_SHELF_MOUNT:-/opt/bito/ai-architect/wingman}"

# The shelf volume, resolved LAZILY at call time rather than at source time.
# get_ai_architect_wingman_volume returns the compose-project-prefixed volume only
# once that volume exists; before compose has created it the lookup falls back to
# the bare name, and seeding that would fill a volume no service mounts. Callers
# must therefore materialize the volume first (see service-manager.sh).
# An explicit WINGMAN_SHELF_VOLUME always wins, which is how the tests target a
# throwaway volume.
_wingman_bundle_volume() {
    if [ -n "${WINGMAN_SHELF_VOLUME:-}" ]; then printf '%s' "$WINGMAN_SHELF_VOLUME"; return 0; fi
    if type get_ai_architect_wingman_volume >/dev/null 2>&1; then get_ai_architect_wingman_volume; return 0; fi
    printf '%s' ai_architect_wingman
}
WINGMAN_BUNDLE_IMAGE="${WINGMAN_BUNDLE_IMAGE:-busybox:1.36}"
WINGMAN_BUNDLE_K8S_PVC="${WINGMAN_BUNDLE_K8S_PVC:-bitoarch-wingman}"
WINGMAN_BUNDLE_SEED_TIMEOUT="${WINGMAN_BUNDLE_SEED_TIMEOUT:-600}"

_wb_err()  { if type print_error >/dev/null 2>&1; then print_error "$1" >&2; else printf 'ERROR: %s\n' "$1" >&2; fi; type log_silent >/dev/null 2>&1 && log_silent "wingman bundle: $1"; }
_wb_log()  { type log_silent >/dev/null 2>&1 && log_silent "wingman bundle: $1"; }

# The packaged bundle directory: a sibling of scripts/ at the package root.
wingman_bundle_dir() {
    if [ -n "${BITOARCH_WINGMAN_BUNDLE_DIR:-}" ]; then printf '%s' "$BITOARCH_WINGMAN_BUNDLE_DIR"; return 0; fi
    local d="${_BITOARCH_WINGMAN_BUNDLE_LIBDIR}/../../wingman-bundle"
    [ -d "$d" ] && { ( cd "$d" && pwd ); return 0; }
    printf ''
}

# The seed payload script, shipped alongside the other scripts.
_wingman_bundle_seed_script() {
    printf '%s' "${_BITOARCH_WINGMAN_BUNDLE_LIBDIR}/../wingman-bundle-seed.sh"
}

# True when a bundle exists AND validates. Only two items are checked, because
# only two are bundled: the binary is what stops the services downloading, and
# tools/ is what Wingman needs at exec time. A truncated or hand-edited bundle
# must fall through to the CDN path rather than seed a broken shelf.
wingman_bundle_present() {
    local d; d="$(wingman_bundle_dir)"
    [ -n "$d" ] || return 1

    local bin="${d}/current/${WINGMAN_BINARY_NAME:-bito-wingman}"
    if [ ! -s "$bin" ]; then
        _wb_log "bundle rejected: ${bin} is missing or empty"
        return 1
    fi
    if [ ! -x "$bin" ]; then
        _wb_log "bundle rejected: ${bin} is not executable"
        return 1
    fi
    if [ ! -d "${d}/current/tools" ] || [ -z "$(ls -A "${d}/current/tools" 2>/dev/null)" ]; then
        _wb_log "bundle rejected: ${d}/current/tools is missing or empty"
        return 1
    fi
    return 0
}

# The bundled version, from the bundle's provenance manifest.
wingman_bundle_version() {
    local d; d="$(wingman_bundle_dir)"
    [ -n "$d" ] || return 1
    grep -o '"wingman-version"[[:space:]]*:[[:space:]]*"[^"]*"' "${d}/manifest.json" 2>/dev/null \
        | head -1 | sed 's/.*:[[:space:]]*"\([^"]*\)".*/\1/'
}

# True when the shelf already carries the seed marker. Read in-container because
# the host cannot see the volume/PVC.
wingman_bundle_seeded() {
    local out
    if type _wingman_fs_apply >/dev/null 2>&1; then
        out="$(_wingman_fs_apply "" "[ -f '${WINGMAN_SHELF_MOUNT}/.bundle_seeded' ] && echo yes" 2>/dev/null | tr -d '[:space:]')"
        [ "$out" = "yes" ]
        return $?
    fi
    return 1
}

# Stream the bundle plus the seed script as a SINGLE tar on stdout. The seed
# script rides along so the container needs nothing mounted.
#
# One archive, not two concatenated ones: busybox tar stops at the first
# end-of-archive marker, so a second appended archive is silently dropped. The
# repeated -C puts both trees in the same archive instead. COPYFILE_DISABLE stops
# macOS from adding ._* AppleDouble entries.
_wingman_bundle_tar() {
    local d script
    d="$(wingman_bundle_dir)"
    script="$(_wingman_bundle_seed_script)"
    COPYFILE_DISABLE=1 tar -cf - \
        -C "$d" . \
        -C "$(cd "$(dirname "$script")" && pwd)" "$(basename "$script")" 2>/dev/null
}

# ---------------------------------------------------------------------------
# Docker
# ---------------------------------------------------------------------------
# The named volume lives on the same daemon the host CLI talks to, so a one-shot
# busybox container can write it. The payload goes over stdin rather than a bind
# mount, which is not reliably visible on VM-backed daemons.
_wingman_bundle_seed_docker() {
    command -v docker >/dev/null 2>&1 || { _wb_err "docker is not available to seed the Wingman shelf"; return 1; }

    local rc vol
    vol="$(_wingman_bundle_volume)"
    _wb_log "seeding docker volume ${vol}"
    _wingman_bundle_tar | docker run --rm -i \
        -v "${vol}:${WINGMAN_SHELF_MOUNT}" \
        -e "SHELF=${WINGMAN_SHELF_MOUNT}" \
        -e "SRC=/payload" \
        -e "WINGMAN_BINARY_NAME=${WINGMAN_BINARY_NAME:-bito-wingman}" \
        "$WINGMAN_BUNDLE_IMAGE" \
        sh -c 'mkdir -p /payload && tar -C /payload -xf - && sh /payload/wingman-bundle-seed.sh' \
        >>"${LOG_FILE:-/dev/null}" 2>&1
    rc="${PIPESTATUS[1]}"
    return "${rc:-1}"
}

# ---------------------------------------------------------------------------
# Kubernetes
# ---------------------------------------------------------------------------
# One pod template; the volume stanza is the only difference between the static
# and dynamic paths. A bare pod rather than a Job because the payload arrives via
# `kubectl exec`, so the lifecycle is driven from here.
#
# The scheduling block is mandatory: without it the pod sits Pending forever on a
# tainted node pool and the shelf is never seeded.
_wingman_bundle_seed_k8s() {   # <namespace> <volume-yaml>
    local ns="$1" volume_yaml="$2" pod sched rc
    command -v kubectl >/dev/null 2>&1 || { _wb_err "kubectl is not available to seed the Wingman shelf"; return 1; }

    pod="ai-architect-wingman-seed"
    sched=""
    if type _cluster_pod_scheduling_yaml >/dev/null 2>&1; then
        sched="$(_cluster_pod_scheduling_yaml "$(type _cluster_yaml_file >/dev/null 2>&1 && _cluster_yaml_file || echo "")" "  ")"
    fi

    kubectl delete pod "$pod" -n "$ns" --ignore-not-found --wait=true >/dev/null 2>&1 || true

    local manifest
    manifest=$(cat <<YAML
apiVersion: v1
kind: Pod
metadata:
  name: ${pod}
  namespace: ${ns}
  labels:
    app.kubernetes.io/name: bitoarch
    app.kubernetes.io/component: wingman-seed
spec:
  restartPolicy: Never
${sched}
  containers:
  - name: seed
    image: ${WINGMAN_BUNDLE_IMAGE}
    command: ["sh", "-c", "sleep 900"]
    volumeMounts:
    - name: wingman
      mountPath: ${WINGMAN_SHELF_MOUNT}
  volumes:
${volume_yaml}
YAML
)

    if type _cluster_kubectl_apply_retry >/dev/null 2>&1; then
        printf '%s\n' "$manifest" | _cluster_kubectl_apply_retry >>"${LOG_FILE:-/dev/null}" 2>&1 || {
            _wb_err "could not create the Wingman seed pod in namespace ${ns}"; return 1; }
    else
        printf '%s\n' "$manifest" | kubectl apply -f - >>"${LOG_FILE:-/dev/null}" 2>&1 || {
            _wb_err "could not create the Wingman seed pod in namespace ${ns}"; return 1; }
    fi

    if ! kubectl wait --for=condition=Ready "pod/${pod}" -n "$ns" \
            --timeout="${WINGMAN_BUNDLE_SEED_TIMEOUT}s" >>"${LOG_FILE:-/dev/null}" 2>&1; then
        # Distinguish the cause rather than always blaming storage: an image pull
        # failure and an unschedulable pod look identical from the timeout alone.
        local reason
        reason=$(kubectl get pod "$pod" -n "$ns" \
            -o jsonpath='{.status.containerStatuses[*].state.waiting.reason}{" "}{.status.conditions[?(@.type=="PodScheduled")].reason}' 2>/dev/null)
        kubectl describe pod "$pod" -n "$ns" >>"${LOG_FILE:-/dev/null}" 2>&1 || true
        case "$reason" in
            *ImagePull*|*ErrImage*|*RegistryUnavailable*)
                _wb_err "Wingman seed pod could not pull ${WINGMAN_BUNDLE_IMAGE} -- the nodes likely lack registry egress. Mirror the image or make it pullable. See ${LOG_FILE:-the setup log}." ;;
            *Unschedulable*)
                _wb_err "Wingman seed pod is unschedulable -- check node selectors and taints in cluster.yaml. See ${LOG_FILE:-the setup log}." ;;
            *)
                _wb_err "Wingman seed pod did not become ready within ${WINGMAN_BUNDLE_SEED_TIMEOUT}s. See ${LOG_FILE:-the setup log}." ;;
        esac
        kubectl delete pod "$pod" -n "$ns" --ignore-not-found >/dev/null 2>&1 || true
        return 1
    fi

    _wingman_bundle_tar | kubectl exec -i "$pod" -n "$ns" -- sh -c \
        "mkdir -p /payload && tar -C /payload -xf - && SRC=/payload SHELF='${WINGMAN_SHELF_MOUNT}' WINGMAN_BINARY_NAME='${WINGMAN_BINARY_NAME:-bito-wingman}' sh /payload/wingman-bundle-seed.sh" \
        >>"${LOG_FILE:-/dev/null}" 2>&1
    rc="${PIPESTATUS[1]}"

    kubectl delete pod "$pod" -n "$ns" --ignore-not-found >/dev/null 2>&1 || true
    return "${rc:-1}"
}

# Static NFS: mount the share root directly, no PVC. Callable before helm.
wingman_bundle_seed_static_nfs() {   # <server> <share>
    local server="$1" share="$2"
    [ -n "$server" ] && [ -n "$share" ] || { _wb_err "static seed needs an NFS server and share"; return 1; }
    wingman_bundle_present || return 0

    LOG_FILE="${LOG_FILE:-$(type get_setup_log >/dev/null 2>&1 && get_setup_log || echo /dev/null)}"
    _wb_log "seeding Wingman from the offline bundle"

    # The share's wingman/ subdirectory is the shelf; mount the root and point the
    # shelf mount at that subpath.
    local volume_yaml
    volume_yaml=$(cat <<YAML
  - name: wingman
    nfs:
      server: ${server}
      path: ${share%/}/wingman
YAML
)
    if _wingman_bundle_seed_k8s "default" "$volume_yaml"; then
        _wb_log "static NFS shelf seeded from the bundle"
        return 0
    fi
    return 1
}


# Dynamic provisioning: create the shelf claim and seed it BEFORE the main helm
# apply. Seeding afterwards cannot work on a first install -- helm waits for its
# post-install hook, that hook waits up to six minutes for the worker to attach as a
# Temporal poller, and the worker's wait-for-wingman init blocks until the shelf holds
# a binary. Nothing breaks that cycle unless the shelf is filled before the apply.
# The chart's own populate Job used to fill it mid-apply; a bundled install disables
# that Job, so the installer fills it here instead.
#
# The claim is taken from the manifests the caller already rendered (its server
# dry-run), so its spec cannot drift from what the apply creates and the chart is not
# rendered twice. It is then stamped with helm's ownership metadata so the apply adopts
# it rather than failing on "invalid ownership metadata". Binding is left to the seed
# pod: the shared class is often WaitForFirstConsumer, so the claim stays Pending until
# a pod mounts it.
#
# <rendered> carries the whole release manifest, which includes the platform Secret in
# cleartext. Only the claim document is ever extracted from it, and neither the input
# nor the extract is written to the log.
wingman_bundle_seed_before_helm() {   # <namespace> <rendered> [release]
    local ns="$1" rendered="$2" release="${3:-bitoarch}"
    wingman_bundle_present || return 0
    if [ "${STORAGE_PROVISIONING_TYPE:-}" = "static" ]; then
        _wb_log "static provisioning: the share is seeded before helm already, skipping the PVC pre-seed"
        return 0
    fi
    command -v kubectl >/dev/null 2>&1 || { _wb_err "kubectl is not available to seed the Wingman shelf"; return 1; }

    LOG_FILE="${LOG_FILE:-$(type get_setup_log >/dev/null 2>&1 && get_setup_log || echo /dev/null)}"

    # Pre-create only when the claim is actually missing. On a recreate the release
    # already owns it, so there is nothing to create or adopt and no rendered manifest
    # is needed -- which is why <rendered> may be empty on that path.
    if kubectl get pvc "$WINGMAN_BUNDLE_K8S_PVC" -n "$ns" >/dev/null 2>&1; then
        _wb_log "${WINGMAN_BUNDLE_K8S_PVC} already exists; seeding it directly"
    else
        local pvc
        pvc="$(printf '%s\n' "$rendered" \
               | awk -v want="name: ${WINGMAN_BUNDLE_K8S_PVC}" \
                     'BEGIN{RS="\n---\n"} index($0, want) && /kind: PersistentVolumeClaim/ {print; exit}')"
        if [ -z "$pvc" ]; then
            _wb_err "could not find the ${WINGMAN_BUNDLE_K8S_PVC} claim in the rendered chart; the shelf cannot be seeded before helm."
            return 1
        fi

        printf '%s\n' "$pvc" | kubectl apply -f - >>"${LOG_FILE:-/dev/null}" 2>&1 || {
            _wb_err "could not create the ${WINGMAN_BUNDLE_K8S_PVC} claim ahead of the helm apply"; return 1; }

        kubectl annotate pvc "$WINGMAN_BUNDLE_K8S_PVC" -n "$ns" \
            "meta.helm.sh/release-name=${release}" "meta.helm.sh/release-namespace=${ns}" \
            --overwrite >>"${LOG_FILE:-/dev/null}" 2>&1 || true
        kubectl label pvc "$WINGMAN_BUNDLE_K8S_PVC" -n "$ns" \
            app.kubernetes.io/managed-by=Helm --overwrite >>"${LOG_FILE:-/dev/null}" 2>&1 || true
    fi

    # Already-seeded shelves are the common recreate case; skip rather than re-stream
    # the payload and republish over a shelf that services are reading.
    if wingman_bundle_seeded; then
        _wb_log "shelf already carries the seed marker, skipping"
        return 0
    fi

    _wb_log "seeding Wingman from the offline bundle before the helm apply"
    local volume_yaml
    volume_yaml=$(cat <<YAML
  - name: wingman
    persistentVolumeClaim:
      claimName: ${WINGMAN_BUNDLE_K8S_PVC}
YAML
)
    if _wingman_bundle_seed_k8s "$ns" "$volume_yaml"; then
        _wb_log "shelf seeded from the bundle before helm"
        return 0
    fi
    return 1
}

# Docker entry point. No-op without a validated bundle.
wingman_bundle_seed_docker() {
    wingman_bundle_present || return 0

    LOG_FILE="${LOG_FILE:-$(type get_setup_log >/dev/null 2>&1 && get_setup_log || echo /dev/null)}"
    _wb_log "seeding Wingman from the offline bundle"
    if _wingman_bundle_seed_docker; then
        _wb_log "docker shelf seeded from the bundle"
        return 0
    fi
    return 1
}


# A failed seed is fatal: with no outbound network there is no CDN to fall back
# on, so continuing would leave a platform that cannot index. Callers use this to
# render one consistent failure message.
wingman_bundle_seed_failed() {
    _wb_err "Could not place the bundled Wingman assets on the shared shelf."
    _wb_err "This package ships Wingman for installs without outbound network access, so there is no download to fall back on."
    _wb_err "Re-run the install after resolving the cause above; see ${LOG_FILE:-the setup log} for detail."
}
