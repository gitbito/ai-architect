#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai

# Source centralized output rendering system
SETUP_UTILS_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [ -f "${SETUP_UTILS_DIR}/lib/output-blocks.sh" ]; then
    source "${SETUP_UTILS_DIR}/lib/output-blocks.sh"
elif [ -f "$(dirname "$SETUP_UTILS_DIR")/scripts/lib/output-blocks.sh" ]; then
    source "$(dirname "$SETUP_UTILS_DIR")/scripts/lib/output-blocks.sh"
fi

# GitHub App setup-time credential validation (mints a JWT and checks it against
# the GitHub API directly, since cis-config isn't up yet while we're prompting).
if [ -f "${SETUP_UTILS_DIR}/lib/github-app-validate.sh" ]; then
    source "${SETUP_UTILS_DIR}/lib/github-app-validate.sh"
elif [ -f "$(dirname "$SETUP_UTILS_DIR")/scripts/lib/github-app-validate.sh" ]; then
    source "$(dirname "$SETUP_UTILS_DIR")/scripts/lib/github-app-validate.sh"
fi

# Resolve LOG_FILE lazily, at first log call — never eagerly at source time.
# setup-utils.sh is sourced by path-manager.sh BEFORE init_paths runs, so an
# eager default here would pin the repo-local path for the whole process. By
# call time bitoarch_resolve_log_file returns the layout-correct setup.log; the
# repo-local fallback remains only for true standalone use (no path-manager).
# Only resolves when LOG_FILE is unset, so it never recreates a log directory
# that a purge has already removed.
_resolve_log_file() {
    # An inherited value is honored only if it can actually be appended to. Trusting
    # it unchecked left the writability guarantee not covering the commonest case:
    # a parent exports LOG_FILE, the path later becomes unwritable, and every
    # redirect to it then skips its command instead of logging.
    if [ -n "${LOG_FILE:-}" ]; then
        { : >> "$LOG_FILE"; } 2>/dev/null && return 0
        command -v bitoarch_resolve_log_file >/dev/null 2>&1 \
            && { LOG_FILE="$(bitoarch_resolve_log_file)"; return 0; }
        LOG_FILE="/dev/null"
        return 0
    fi
    if command -v bitoarch_resolve_log_file >/dev/null 2>&1; then
        LOG_FILE="$(bitoarch_resolve_log_file)"
    else
        # path-manager.sh sources this file and then calls init_paths, whose
        # layout detection logs — so we can land here before the canonical
        # resolver exists, and before the layout (hence the real log path) is
        # known. Buffer to a temp file rather than the source tree: path-manager
        # flushes it into the canonical log and removes it, so no line is lost
        # and no second setup.log is ever created under scripts/.
        local _tmpdir _buf _bufpid
        _tmpdir="${TMPDIR:-/tmp}"; _tmpdir="${_tmpdir%/}"
        # Sweep buffers left by dead processes. The flush happens only when
        # path-manager.sh runs later in the SAME process, so anything that sources
        # this file alone leaves its buffer behind. Sweep on stale PID rather than
        # an EXIT trap, which would clobber a caller's own trap.
        for _buf in "$_tmpdir"/bitoarch-early-*.log; do
            [ -e "$_buf" ] || continue
            _bufpid="${_buf##*-}"; _bufpid="${_bufpid%.log}"
            case "$_bufpid" in
                ''|*[!0-9]*) continue ;;
            esac
            kill -0 "$_bufpid" 2>/dev/null || rm -f "$_buf" 2>/dev/null
        done
        LOG_FILE="${_tmpdir}/bitoarch-early-$$.log"
        BITOARCH_LOG_FILE_PROVISIONAL="$LOG_FILE"
    fi
}

# log()/log_silent() are exported with `export -f` (output-blocks.sh), and bash does
# NOT carry a helper across that boundary -- so export this one too, or every child
# shell calling log_silent hits "_resolve_log_file: command not found".
export -f _resolve_log_file 2>/dev/null || true

# Logging function - always log to file, customer-friendly output to console
# Both tolerate a missing log directory (a purge removes it mid-run) — never
# recreate it and never leak a redirect error onto the terminal.
#
# Resolve ONLY when LOG_FILE is unset. Resolving an already-set value re-enters
# bitoarch_resolve_log_file, which mkdir -p's the tree back, so the guard below
# could never fire and `reset.sh` resurrected the logs dir it had just removed.
# Revalidating an inherited path still happens at the command-redirect sites,
# where a failed redirect would SKIP the command; here the braces below already
# swallow the failure, so the worst case is one lost line.
log() {
    [ -n "${LOG_FILE:-}" ] || { command -v _resolve_log_file >/dev/null 2>&1 && _resolve_log_file; }
    [ -d "${LOG_FILE%/*}" ] || return 0
    { echo "[$(date +'%Y-%m-%d %H:%M:%S')] $1" >> "$LOG_FILE"; } 2>/dev/null || true
}

# Silent log - only to file, not to console (for technical details)
log_silent() {
    [ -n "${LOG_FILE:-}" ] || { command -v _resolve_log_file >/dev/null 2>&1 && _resolve_log_file; }
    [ -d "${LOG_FILE%/*}" ] || return 0
    { echo "[$(date +'%Y-%m-%d %H:%M:%S')] $1" >> "$LOG_FILE"; } 2>/dev/null || true
}

print_command() {
    echo -e "${YELLOW}  →${NC} ${BLUE}$1${NC}"
    log "COMMAND: $1"
}

generate_secret() {
    # Ensure consistent output format - remove trailing newlines from both paths
    (openssl rand -base64 32 2>/dev/null || head -c 32 /dev/urandom | base64) | tr -d '\n'
}

generate_encryption_key() {
    # Generate 32 random bytes and encode as URL-safe base64 without padding
    # This follows the same logic as the Go implementation:
    # - 32 bytes (256-bit key)
    # - RawURLEncoding: URL-safe characters, no padding
    #
    # Pipe binary straight into base64 — never via a shell variable. Bash
    # command substitution strips NUL bytes (and Bash >=4.4 warns), which
    # would silently corrupt the key.
    if command -v openssl >/dev/null 2>&1; then
        openssl rand 32 2>/dev/null | base64 | tr '+/' '-_' | tr -d '=\n'
    else
        head -c 32 /dev/urandom | base64 | tr '+/' '-_' | tr -d '=\n'
    fi
}

encrypt_secret() {
    local plaintext="$1"
    local encryption_key="$2"
    
    # Check if openssl is available
    if ! command -v openssl >/dev/null 2>&1; then
        echo "Error: openssl is required for encryption" >&2
        return 1
    fi
    
    # Decode the URL-safe base64 encryption key (convert back from RawURLEncoding)
    # Add padding if needed, convert URL-safe chars back to standard base64
    local key_b64=$(echo -n "$encryption_key" | tr '_-' '/+')
    local padding_length=$((4 - ${#key_b64} % 4))
    if [ $padding_length -ne 4 ]; then
        key_b64="${key_b64}$(printf '=%.0s' $(seq 1 $padding_length))"
    fi

    # Create temp files for key and IV.
    # Binary key/IV bytes are written directly into these files — never into a
    # shell variable. Bash command substitution strips NUL bytes (and Bash
    # >=4.4 warns), which would silently corrupt key/IV material.
    local key_file=$(mktemp)
    local iv_file=$(mktemp)

    # Decode the key directly into the temp file
    echo -n "$key_b64" | base64 -d 2>/dev/null > "$key_file"
    if [ ! -s "$key_file" ]; then
        rm -f "$key_file" "$iv_file"
        echo "Error: Failed to decode encryption key" >&2
        return 1
    fi

    # Generate a 16-byte random IV for AES-256-CBC directly into the temp file
    openssl rand 16 2>>"${LOG_FILE:-/dev/null}" > "$iv_file"
    if [ ! -s "$iv_file" ]; then
        rm -f "$key_file" "$iv_file"
        echo "Error: Failed to generate IV" >&2
        return 1
    fi

    # Encrypt using AES-256-CBC (supported on both macOS and Linux)
    local ciphertext=$(echo -n "$plaintext" | openssl enc -aes-256-cbc -K "$(xxd -p -c 256 "$key_file" | tr -d '\n')" -iv "$(xxd -p -c 256 "$iv_file" | tr -d '\n')" 2>>"${LOG_FILE:-/dev/null}" | base64 | tr -d '\n')

    # Encode IV as base64 (use as nonce) — read from the file, not from a variable
    local iv_b64=$(base64 < "$iv_file" | tr -d '\n')

    # Clean up temp files
    rm -f "$key_file" "$iv_file"

    if [ -z "$ciphertext" ]; then
        echo "Error: Encryption failed" >&2
        return 1
    fi

    # Return in the format: enc:v1:<iv_base64>:<ciphertext_base64>
    echo "enc:v1:${iv_b64}:${ciphertext}"
}

# Decrypt a secret encrypted by encrypt_secret()
# Format: enc:v1:<iv_base64>:<ciphertext_base64>
# Returns plaintext on stdout; returns input as-is if not encrypted
decrypt_secret() {
    local encrypted="$1"
    local encryption_key="$2"

    # If not in encrypted format, return as-is
    case "$encrypted" in
        enc:v1:*) ;;
        *) echo "$encrypted"; return 0 ;;
    esac

    # Parse IV and ciphertext
    local iv_b64=$(echo "$encrypted" | cut -d: -f3)
    local ciphertext_b64=$(echo "$encrypted" | cut -d: -f4)

    # Decode encryption key (URL-safe base64 → standard base64)
    local key_b64=$(echo -n "$encryption_key" | tr '_-' '/+')
    local padding_length=$((4 - ${#key_b64} % 4))
    if [ $padding_length -ne 4 ]; then
        key_b64="${key_b64}$(printf '=%.0s' $(seq 1 $padding_length))"
    fi

    # Create temp files for key and IV
    local key_file=$(mktemp)
    local iv_file=$(mktemp)
    echo -n "$key_b64" | base64 -d 2>/dev/null > "$key_file"
    echo -n "$iv_b64" | base64 -d 2>/dev/null > "$iv_file"

    # Convert to hex for openssl
    local key_hex=$(xxd -p -c 256 "$key_file" | tr -d '\n')
    local iv_hex=$(xxd -p -c 256 "$iv_file" | tr -d '\n')

    # Clean up temp files
    rm -f "$key_file" "$iv_file"

    # Decrypt using AES-256-CBC
    local plaintext=$(echo -n "$ciphertext_b64" | base64 -d 2>/dev/null | \
        openssl enc -d -aes-256-cbc -K "$key_hex" -iv "$iv_hex" 2>/dev/null)

    if [ -n "$plaintext" ]; then
        echo "$plaintext"
    else
        echo "Warning: Failed to decrypt secret, passing through as-is" >&2
        echo "$encrypted"
    fi
}

# Decrypt encrypted env vars and export them so docker-compose picks up plaintext values
# Call this on the HOST before docker compose up
# Env vars override env_file values in docker-compose
decrypt_env_secrets() {
    local env_file="$1"

    if [ -z "$env_file" ] || [ ! -f "$env_file" ]; then
        return 0
    fi

    local enc_key=$(grep '^SECRETS_ENCRYPTION_KEY=' "$env_file" | cut -d= -f2-)
    if [ -z "$enc_key" ]; then
        return 0
    fi

    # Decrypt XMCP_SSO_TENANT_KEY if encrypted
    local tenant_key=$(grep '^XMCP_SSO_TENANT_KEY=' "$env_file" | cut -d= -f2-)
    if [ -n "$tenant_key" ]; then
        case "$tenant_key" in
            enc:v1:*)
                local decrypted=$(decrypt_secret "$tenant_key" "$enc_key")
                if [ -n "$decrypted" ] && [ "$decrypted" != "$tenant_key" ]; then
                    export XMCP_SSO_TENANT_KEY="$decrypted"
                fi
                ;;
        esac
    fi
}

is_container_environment() {
    [ -f /.dockerenv ] || grep -q -E 'docker|lxc|containerd' /proc/1/cgroup 2>/dev/null
}

is_arm64_mac() {
    [[ "$OSTYPE" == "darwin"* ]] && [[ "$(uname -m)" == "arm64" ]]
}

# Shared async loader (show_loader / stop_loader). Single source of truth in
# scripts/lib/loader.sh so consumers that aren't downstream of setup-utils
# (e.g. the diagnose bundler) can reuse the same spinner.
if [ -f "${SETUP_UTILS_DIR}/lib/loader.sh" ]; then
    source "${SETUP_UTILS_DIR}/lib/loader.sh"
elif [ -f "$(dirname "$SETUP_UTILS_DIR")/scripts/lib/loader.sh" ]; then
    source "$(dirname "$SETUP_UTILS_DIR")/scripts/lib/loader.sh"
fi

safe_call() {
    set +e
    "$@"
    local exit_code=$?
    set -e
    return $exit_code
}

################################################################################
# Git Credentials Collection (Shared between setup.sh and CLI)
################################################################################
# Report whether the Azure DevOps organization still needs to be collected.
# True only for azure-devops with no organization yet. The access token is
# deliberately not an input: Azure cloud requires the organization (it forms the
# clone/API URL root), so it is required even when a token was already supplied
# (github/gitlab tolerate an empty domain, Azure does not).
azure_org_needed() {
    [[ "$1" == "azure-devops" && -z "$2" ]]
}

# Collect the Azure DevOps organization into GIT_AZURE_ORG when it is not already
# set. Azure cloud requires the organization (it forms the clone/API URL root),
# so it is required even when a token was supplied — unlike github/gitlab where
# an empty domain is fine. Normalizes a pasted scheme/host/path down to the org.
# GIT_DOMAIN_URL stays empty for Azure cloud (the org is carried separately).
collect_azure_org() {
    while [ -z "$GIT_AZURE_ORG" ]; do
        read -r -p "Enter your Azure DevOps organization (e.g. myorg): " azure_org
        azure_org="${azure_org#http://}"; azure_org="${azure_org#https://}"
        azure_org="${azure_org#dev.azure.com/}"; azure_org="${azure_org%%/*}"
        if [ -z "$azure_org" ]; then
            echo -e "${RED}✗${NC} Azure DevOps organization is required"
        else
            GIT_AZURE_ORG="${azure_org}"
        fi
    done
    GIT_DOMAIN_URL=""
    echo -e "✅ Azure DevOps organization set: ${GIT_AZURE_ORG}"
}

# ─── GitHub App credential collection (shared: fresh install + update-git-creds) ──
# GitHub App is an additive auth method; PAT stays the default. These helpers are
# reused by setup.sh (fresh install) and collect_git_credentials (rotation) so the
# App prompt flow is defined once. The multi-line PEM is taken as a FILE PATH and
# base64-encoded into GIT_APP_PRIVATE_KEY_B64 (the Vertex service-account precedent);
# the key material is NEVER echoed -- only a fingerprint + byte count is shown.

# Print a non-sensitive fingerprint of a .pem: sha256 (first 16 hex) + byte count.
# NEVER prints key material. Best-effort: falls back to size-only if no sha tool.
_git_app_pem_fingerprint() {
    local pem_file="$1" sum bytes
    bytes=$(wc -c < "$pem_file" 2>/dev/null | tr -d ' ')
    if command -v shasum >/dev/null 2>&1; then
        sum=$(shasum -a 256 "$pem_file" 2>/dev/null | awk '{print $1}')
    elif command -v sha256sum >/dev/null 2>&1; then
        sum=$(sha256sum "$pem_file" 2>/dev/null | awk '{print $1}')
    fi
    if [ -n "$sum" ]; then
        echo -e "   ${GREEN:-}✓${NC:-} key loaded (sha256 ${sum:0:16}..., ${bytes} bytes)"
    else
        echo -e "   ${GREEN:-}✓${NC:-} key loaded (${bytes} bytes)"
    fi
}

# Read a GitHub App private-key .pem path, validate it, and base64-encode it
# (single line) into GIT_APP_PRIVATE_KEY_B64. Expands a leading ~. On success prints
# only a fingerprint (never the key) and returns 0; on any failure prints an error to
# stderr, leaves GIT_APP_PRIVATE_KEY_B64 unchanged, and returns 1.
_git_app_read_pem_to_b64() {
    local pem_path="$1"
    # shellcheck disable=SC2088  # literal tilde patterns in a case match
    case "$pem_path" in
        "~")   pem_path="$HOME" ;;
        "~/"*) pem_path="$HOME/${pem_path#\~/}" ;;
    esac
    if [ ! -f "$pem_path" ]; then
        echo -e "${RED:-}✗${NC:-} File not found: $pem_path" >&2
        return 1
    fi
    if ! grep -q "BEGIN.*PRIVATE KEY" "$pem_path" 2>/dev/null; then
        echo -e "${RED:-}✗${NC:-} Not a PEM private key: $pem_path" >&2
        return 1
    fi
    GIT_APP_PRIVATE_KEY_B64=$(base64 < "$pem_path" | tr -d '\n')
    export GIT_APP_PRIVATE_KEY_B64
    _git_app_pem_fingerprint "$pem_path"
    return 0
}

# Choose the GitHub auth method and set GIT_AUTH_TYPE. Only GitHub offers App auth;
# every other provider is forced to personal_access_token. Empty/unknown defaults to
# personal_access_token. Never fails.
#
# mode "fresh" (default; fresh install): a choice already supplied via install.yaml/env
#   (or a pre-filled PAT) is honored WITHOUT prompting, so a pre-configured / SA install
#   never blocks on this question.
# mode "rotate" (update-git-creds): always offer the PAT/App choice so an operator can
#   switch methods, defaulting to the method the install currently uses (Enter keeps it).
prompt_git_auth_method() {
    local mode="${1:-fresh}"
    # Local provider is credential-less: auth_type "none", never a PAT/App prompt.
    if [ "${GIT_PROVIDER:-}" = "local" ]; then
        GIT_AUTH_TYPE="none"
        export GIT_AUTH_TYPE
        return 0
    fi
    if [ "${GIT_PROVIDER:-}" != "github" ]; then
        GIT_AUTH_TYPE="personal_access_token"
        export GIT_AUTH_TYPE
        return 0
    fi
    if [ "$mode" != "rotate" ]; then
        # Fresh install: an explicit choice (install.yaml/env) wins without prompting.
        case "${GIT_AUTH_TYPE:-}" in
            app|personal_access_token) export GIT_AUTH_TYPE; return 0 ;;
        esac
        # A pre-supplied PAT implies personal_access_token -- keep the existing (byte
        # identical) PAT flow and don't introduce a new prompt.
        if [ -n "${GIT_ACCESS_TOKEN:-}" ]; then
            GIT_AUTH_TYPE="personal_access_token"
            export GIT_AUTH_TYPE
            return 0
        fi
    fi
    # No terminal (auto / non-interactive): keep the current method when known,
    # otherwise default to PAT -- never block on a closed stdin.
    if [ ! -t 0 ]; then
        case "${GIT_AUTH_TYPE:-}" in
            app|personal_access_token) ;;
            *) GIT_AUTH_TYPE="personal_access_token" ;;
        esac
        export GIT_AUTH_TYPE
        return 0
    fi
    # Interactive choice. On a rotation the install's current method is the default
    # (Enter keeps it); on a fresh install PAT (1) is the default. The leading blank
    # line lives here (not in the caller) so it only prints when we actually prompt.
    local choice default_choice=1
    if [ "$mode" = "rotate" ] && [ "${GIT_AUTH_TYPE:-}" = "app" ]; then
        default_choice=2
    fi
    echo ""
    while true; do
        read -r -p "Select GitHub auth method (1) Personal Access Token  (2) GitHub App  [1-2] (default ${default_choice}): " choice
        [ -z "$choice" ] && choice="$default_choice"
        case "$choice" in
            1) GIT_AUTH_TYPE="personal_access_token"; break ;;
            2) GIT_AUTH_TYPE="app"; break ;;
            *) echo -e "${RED:-}✗${NC:-} Please select 1 or 2" ;;
        esac
    done
    export GIT_AUTH_TYPE
}

# Collect GitHub App credentials (App ID, Installation ID, private-key .pem).
# mode: "fresh" (default) -- a .pem is required; "rotate" -- pressing Enter keeps the
# current key (empty GIT_APP_PRIVATE_KEY_B64 later tells the config builder to omit
# private_key so cis-config preserves the stored one). App ID / Installation ID show
# the current value as a default when present and are always left non-empty. The key
# is never echoed.
# Prompt for a REQUIRED, numeric (digits-only) value into the named variable, showing
# the current value as [default] when set. Re-prompts on empty / non-numeric input;
# on a closed stdin / non-TTY it fails fast (returns 1) instead of looping. GitHub App
# IDs and Installation IDs are integers, so this rejects a mistyped id early -- before
# the API check -- with a clear message. Args: <var_name> <prompt_label>
_prompt_numeric() {
    local __var="$1" __label="$2" __cur __in
    __cur="${!__var:-}"
    while :; do
        __in=""
        if [ -n "$__cur" ]; then
            read -r -p "Enter ${__label} [${__cur}]: " __in || __in=""
            [ -z "$__in" ] && __in="$__cur"
        else
            read -r -p "Enter ${__label}: " __in || __in=""
        fi
        case "$__in" in
            "")
                [ -t 0 ] && { echo -e "${RED:-}✗${NC:-} ${__label} is required"; continue; }
                print_error "${__label} is required."; return 1 ;;
            *[!0-9]*)
                [ -t 0 ] && { echo -e "${RED:-}✗${NC:-} ${__label} must be a number (digits only)"; continue; }
                print_error "${__label} must be a number."; return 1 ;;
        esac
        printf -v "$__var" '%s' "$__in"
        return 0
    done
}

collect_github_app_credentials() {
    local mode="${1:-fresh}" _pem_path attempt max=3 rc
    # 'mode' is accepted for call-site compatibility; the prompts key off whether a
    # value is already present (rotate/re-attempt) rather than the mode itself.
    : "${mode:=fresh}"

    # Collect all three inputs in GitHub's own order (App ID, Installation ID, then the
    # private key), THEN verify them together: api-1 (GET /app) checks the App ID +
    # private key and api-2 (GET /app/installations/{id}) checks the installation. One
    # success line is printed once both pass. On an invalid-credential failure the whole
    # set is re-prompted (current values shown as defaults, so a correct field is kept
    # with Enter); a check that can't run (offline / no tools) proceeds without blocking
    # (cis-config re-validates with a real token mint when the config is saved).
    attempt=1
    while :; do
        # App ID (numeric; current value shown as a default when present).
        _prompt_numeric GIT_APP_ID "GitHub App ID" || return 1

        # Installation ID (numeric; current value shown as a default when present).
        _prompt_numeric GIT_INSTALLATION_ID "GitHub App Installation ID" || return 1

        # Private key .pem. A key already present (rotation or a prior attempt) can be
        # kept with Enter; otherwise a path is required. Never echoed (fingerprint only).
        if [ -n "${GIT_APP_PRIVATE_KEY_B64:-}" ]; then
            read -r -p "Path to a NEW private key .pem (press Enter to keep the current key): " _pem_path || _pem_path=""
            if [ -n "$_pem_path" ]; then
                _git_app_read_pem_to_b64 "$_pem_path" \
                    || print_warning "Could not read the new key; keeping the current key."
            else
                print_info "Keeping the current GitHub App private key."
            fi
        else
            while [ -z "${GIT_APP_PRIVATE_KEY_B64:-}" ]; do
                read -r -p "Enter path to the GitHub App private key (.pem): " _pem_path || break
                [ -z "$_pem_path" ] && { echo -e "${RED:-}✗${NC:-} Private key path is required"; continue; }
                _git_app_read_pem_to_b64 "$_pem_path" || continue
            done
            [ -z "${GIT_APP_PRIVATE_KEY_B64:-}" ] && { print_error "A GitHub App private key (.pem) is required."; return 1; }
        fi

        # Verify App ID + key (api-1), then the installation (api-2). Each helper returns
        # 0 valid / 1 invalid / 2 can't-check; a can't-check on api-1 skips api-2 (GitHub
        # is unreachable either way).
        echo ""
        print_info "Verifying GitHub App credentials with GitHub..."
        validate_github_app_key "${GIT_APP_ID}" "${GIT_APP_PRIVATE_KEY_B64}" "${GIT_DOMAIN_URL:-}"
        rc=$?
        if [ "$rc" -eq 0 ]; then
            validate_github_app_installation "${GIT_APP_ID}" "${GIT_INSTALLATION_ID}" "${GIT_APP_PRIVATE_KEY_B64}" "${GIT_DOMAIN_URL:-}"
            rc=$?
        fi
        if [ "$rc" -eq 0 ]; then
            print_success "GitHub App credentials verified (App ID, installation, and private key)."
            break
        fi
        [ "$rc" -eq 2 ] && break   # can't verify now (offline / no tools) -> proceed
        # rc 1 -> invalid: re-prompt the whole set (bounded; can't re-prompt non-interactively).
        if [ "$attempt" -ge "$max" ] || [ ! -t 0 ]; then
            print_error "GitHub App credentials could not be verified. Aborting."
            return 1
        fi
        attempt=$((attempt + 1))
        echo ""
        print_warning "Re-enter the GitHub App credentials (attempt ${attempt} of ${max})."
    done

    unset _pem_path
    export GIT_AUTH_TYPE GIT_APP_ID GIT_INSTALLATION_ID GIT_APP_PRIVATE_KEY_B64
}

collect_git_credentials() {
    # This function collects Git credentials matching setup.sh flow exactly
    # Returns: Sets global variables GIT_PROVIDER, GIT_DOMAIN_URL, GIT_USER, GIT_ACCESS_TOKEN
    
    # Note: NOT using 'local' so variables are exported to parent scope.
    # GIT_AUTH_TYPE and GIT_APP_ID/INSTALLATION_ID/PRIVATE_KEY_B64 are intentionally
    # NOT reset here: the caller seeds them from the current .env so a rotation keeps
    # the current auth method (no silent PAT downgrade) and offers the current App
    # values as defaults (Enter preserves the stored key). An empty seeded auth_type
    # with github still triggers the interactive PAT/App choice below.
    GIT_PROVIDER=""
    GIT_ACCESS_TOKEN=""
    GIT_DOMAIN_URL=""
    GIT_USER=""
    GIT_AZURE_ORG=""

    # Git Provider selection
    while [ -z "$GIT_PROVIDER" ]; do
        read -p "Select Git provider (1) GitLab  (2) GitHub  (3) Bitbucket  (4) Azure DevOps  (5) Local (pre-cloned repos)  [1-5]: " git_choice

        case $git_choice in
            1) GIT_PROVIDER="gitlab" ;;
            2) GIT_PROVIDER="github" ;;
            3) GIT_PROVIDER="bitbucket" ;;
            4) GIT_PROVIDER="azure-devops" ;;
            5) GIT_PROVIDER="local" ;;
            *)
                echo -e "${RED}✗${NC} Invalid choice. Please select 1-5"
                ;;
        esac
    done

    # Enterprise / domain FIRST (before the auth-method choice) so a GitHub App
    # validation on GitHub Enterprise targets the right API base. Azure DevOps cloud
    # carries its organization instead of the generic enterprise domain; the local
    # provider has neither (no remote at all).
    echo ""
    if [[ "$GIT_PROVIDER" == "azure-devops" ]]; then
        collect_azure_org
    elif [[ "$GIT_PROVIDER" == "local" ]]; then
        : # credential-less: no domain, no organization
    else
        read -r -p "Is this an enterprise version of $GIT_PROVIDER (e.g., https://my.company.com)? (y/N):" is_enterprise
        if [[ "$is_enterprise" =~ ^[Yy]$ ]]; then
            while [ -z "$GIT_DOMAIN_URL" ]; do
                read -r -p "Enter domain for enterprise $GIT_PROVIDER: " GIT_DOMAIN_URL
                if [ -z "$GIT_DOMAIN_URL" ]; then
                    echo -e "${RED}✗${NC} Git domain is required for enterprise"
                fi
            done
        fi
    fi

    # GitHub App vs Personal Access Token (github only; other providers -> PAT). This
    # is the rotation path, so an operator may switch methods (defaults to current);
    # emits its own leading blank line only when it actually prompts.
    prompt_git_auth_method rotate

    # Bitbucket user configuration 
    if [[ "$GIT_PROVIDER" == "bitbucket" ]]; then
        echo ""
        echo -e "🛠 Configuring user authentication..."

        if [[ -z "$GIT_DOMAIN_URL" ]]; then
            # No domain → ask for email
            while [[ -z "$GIT_USER" ]]; do
                read -r -p "Enter your Bitbucket account email: " GIT_USER
                [[ -z "$GIT_USER" ]] && echo "⚠ Email is required. Please try again."
            done
        else
            # Domain exists → ask for username
            while [[ -z "$GIT_USER" ]]; do
                read -r -p "Enter your Bitbucket username: " GIT_USER
                [[ -z "$GIT_USER" ]] && echo "⚠ Username is required. Please try again."
            done
        fi

        echo -e "✅ Bitbucket user set: $GIT_USER"
    fi

    if [ "${GIT_AUTH_TYPE:-}" = "app" ]; then
        # GitHub App: collect App ID / Installation ID / .pem path (rotation-aware,
        # Enter keeps the current key). No PAT token in App mode. Validate before
        # returning so callers never persist unusable credentials.
        echo ""
        echo -e "🛠 Configuring GitHub App authentication..."
        collect_github_app_credentials rotate || return 1
        # GIT_ACCESS_TOKEN already reset to "" at the top of this function (App mode
        # carries no PAT).
    elif [ "$GIT_PROVIDER" = "local" ]; then
        # Local provider: credential-less. Clear any prior method's fields so a
        # switch to local never leaves a stale PAT or App key in the env file.
        GIT_APP_ID=""
        GIT_INSTALLATION_ID=""
        GIT_APP_PRIVATE_KEY_B64=""
        # GIT_ACCESS_TOKEN already reset to "" at the top of this function.
    else
        # Personal Access Token. Clear any GitHub App fields so switching app->PAT
        # never leaves a stale App private key behind in the env file.
        GIT_APP_ID=""
        GIT_INSTALLATION_ID=""
        GIT_APP_PRIVATE_KEY_B64=""
        # Git Access Token input
        while [ -z "$GIT_ACCESS_TOKEN" ]; do
            echo ""
            read -s -p "Enter Git access token (input hidden): " GIT_ACCESS_TOKEN
            if [ -z "$GIT_ACCESS_TOKEN" ]; then
                echo ""  # Newline after hidden input
                echo -e "${RED}✗${NC} Git access token is required"
                echo ""
            fi
        done
        echo ""  # Newline after hidden input
    fi

    # Print status message
    print_info "Git provider configured (${GIT_PROVIDER})"


    # Export the collected values
    export GIT_PROVIDER
    export GIT_ACCESS_TOKEN
    export GIT_DOMAIN_URL
    export GIT_USER
    export GIT_AZURE_ORG
    export GIT_AUTH_TYPE
    export GIT_APP_ID
    export GIT_INSTALLATION_ID
    export GIT_APP_PRIVATE_KEY_B64

    return 0
}

# Export the functions
export -f collect_git_credentials
export -f collect_azure_org
export -f azure_org_needed
export -f prompt_git_auth_method
export -f collect_github_app_credentials
export -f _git_app_read_pem_to_b64
export -f _git_app_pem_fingerprint

################################################################################
# Update Git Credentials in .env file (Complete flow)
# This function is used by platform-adapter update-git-creds and update-api-key
################################################################################
# Read a single env value from a file (first match, quotes/newlines not expected on
# these keys). Empty when absent. Used to seed rotation defaults for the App fields.
_git_env_get() {
    grep -E "^$1=" "$2" 2>/dev/null | head -1 | cut -d= -f2-
}

# Set KEY=VALUE in an env file: replace the line in place, or append it when the key
# isn't present yet (older env files predate the GitHub App keys). '#' is the sed
# delimiter -- safe because base64 / numeric ids / auth_type contain no '#'.
_git_env_upsert() {
    local key="$1" val="$2" file="$3"
    if grep -q "^${key}=" "$file" 2>/dev/null; then
        sed -i.bak "s#^${key}=.*#${key}=${val}#" "$file" && rm -f "${file}.bak"
    else
        echo "${key}=${val}" >> "$file"
    fi
}

update_git_credentials_in_env() {
    local env_file="$1"

    if [ -z "$env_file" ]; then
        echo "Error: ENV_FILE path required"
        return 1
    fi

    # Seed the current auth method + GitHub App fields so a rotation keeps the current
    # auth method (no silent PAT downgrade), offers "keep current" defaults (App ID /
    # Installation ID), and preserves the stored key on Enter.
    if [ -f "$env_file" ]; then
        GIT_AUTH_TYPE=$(_git_env_get "GIT_AUTH_TYPE" "$env_file")
        GIT_APP_ID=$(_git_env_get "GIT_APP_ID" "$env_file")
        GIT_INSTALLATION_ID=$(_git_env_get "GIT_INSTALLATION_ID" "$env_file")
        GIT_APP_PRIVATE_KEY_B64=$(_git_env_get "GIT_APP_PRIVATE_KEY_B64" "$env_file")
        export GIT_AUTH_TYPE GIT_APP_ID GIT_INSTALLATION_ID GIT_APP_PRIVATE_KEY_B64
    fi

    # Collect Git credentials using shared function. A GitHub App validation failure
    # aborts before we persist anything (never write unusable credentials).
    if ! collect_git_credentials; then
        return 1
    fi

    # Update Git credentials in .env file (using # as delimiter to handle @ in emails/tokens)
    sed -i.bak "s#^GIT_PROVIDER=.*#GIT_PROVIDER=$GIT_PROVIDER#" "$env_file" && rm -f "${env_file}.bak"
    sed -i.bak "s#^GIT_ACCESS_TOKEN=.*#GIT_ACCESS_TOKEN=$GIT_ACCESS_TOKEN#" "$env_file" && rm -f "${env_file}.bak"

    # Always update domain and user (blank them out for non-enterprise)
    sed -i.bak "s#^GIT_DOMAIN_URL=.*#GIT_DOMAIN_URL=$GIT_DOMAIN_URL#" "$env_file" && rm -f "${env_file}.bak"
    sed -i.bak "s#^GIT_USER=.*#GIT_USER=$GIT_USER#" "$env_file" && rm -f "${env_file}.bak"

    # Azure DevOps organization (empty for non-Azure). Append the key if an older
    # env file predates it, so update-git-creds persists it on upgrade.
    if grep -q "^GIT_AZURE_ORG=" "$env_file"; then
        sed -i.bak "s#^GIT_AZURE_ORG=.*#GIT_AZURE_ORG=$GIT_AZURE_ORG#" "$env_file" && rm -f "${env_file}.bak"
    else
        echo "GIT_AZURE_ORG=$GIT_AZURE_ORG" >> "$env_file"
    fi

    # GitHub App fields. Each upsert writes whatever the variable currently holds:
    # the rotation-kept base64 (pressing Enter left GIT_APP_PRIVATE_KEY_B64 at the
    # seeded value, so the same key is re-sent and re-encrypted server-side), a new
    # rotated key, or "" for a PAT install / cleared App fields. Appended when an
    # older env file predates the keys.
    _git_env_upsert "GIT_AUTH_TYPE" "${GIT_AUTH_TYPE:-}" "$env_file"
    _git_env_upsert "GIT_APP_ID" "${GIT_APP_ID:-}" "$env_file"
    _git_env_upsert "GIT_INSTALLATION_ID" "${GIT_INSTALLATION_ID:-}" "$env_file"
    _git_env_upsert "GIT_APP_PRIVATE_KEY_B64" "${GIT_APP_PRIVATE_KEY_B64:-}" "$env_file"

    # Cleanup backup files created by sed
    rm -f "${env_file}.bak"
    return 0
}

# Export the function
export -f update_git_credentials_in_env
export -f _git_env_get
export -f _git_env_upsert

################################################################################
# Validate Bito API Key with output (Shared between setup.sh and CLI)
################################################################################
validate_and_print_bito_api_key_status() {
    local api_key="$1"
    local event_type="$2"              # "architect_install_started" or "architect_api_key_update"
    local tracking_url="$3"            # TRACKING_SERVICE_BASE_URL
    local success_message="$4"         # Custom success message
    local strict_mode="${5:-false}"    # true = fail on any non-200/201, false = warn on errors
    
    if [ -z "$api_key" ] || [ -z "$event_type" ] || [ -z "$tracking_url" ]; then
        return 1
    fi
    
    print_info "Validating API key..."

    # Build tracking data
    local tracking_data=$(cat <<TRACKING_EOF
{
    "deployment_mode": "self_hosted"
}
TRACKING_EOF
    )

    # Call tracking endpoint (suppress output to prevent HTTP status leakage)
    local tracking_http_status
    tracking_http_status=$(call_tracking_endpoint_event "$tracking_url" "$api_key" "$event_type" "$tracking_data" 2>/dev/null) || true

    # Handle validation result with messages
    if [ "$tracking_http_status" = "403" ]; then
        # Invalid API Key
        echo "❌ Invalid Bito API Key. Please verify your key and try again."
        echo "   Get your key at: https://alpha.bito.ai/home/advanced"
        return 1
    elif [ "$tracking_http_status" = "200" ] || [ "$tracking_http_status" = "201" ]; then
        # Valid API Key
        print_status "${success_message:-API key validated successfully}"
        return 0
    else
        # Tracking service unavailable or other error
        if [ "$strict_mode" = "true" ]; then
            print_error "Could not validate API key"
            echo "API key validation is required before updating. Please try again later."
            return 1
        else
            print_warning "Could not validate API key (tracking service unavailable)"
            return 0  # Non-blocking
        fi
    fi
}

# Export the function
export -f validate_and_print_bito_api_key_status
