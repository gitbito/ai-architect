-- Session-scoped reads of index_log.
--
-- The status API looks rows up by (workspace_id, request_id): the workspace is
-- the tenant guard and the request_id is the session. Only idx_workspace_id
-- existed, so every session lookup scanned the workspace's whole history.
-- The composite index also serves the session listing, which filters on
-- workspace_id and groups by request_id.
--
-- Guarded so re-running the migration on an already-migrated database is a
-- no-op: MySQL has no CREATE INDEX IF NOT EXISTS.
SET @index_exists := (
    SELECT COUNT(*)
    FROM information_schema.statistics
    WHERE table_schema = DATABASE()
      AND table_name = 'index_log'
      AND index_name = 'idx_index_log_ws_request'
);

SET @stmt := IF(@index_exists = 0,
    'CREATE INDEX idx_index_log_ws_request ON index_log (workspace_id, request_id)',
    'SELECT 1');

PREPARE create_index FROM @stmt;
EXECUTE create_index;
DEALLOCATE PREPARE create_index;
