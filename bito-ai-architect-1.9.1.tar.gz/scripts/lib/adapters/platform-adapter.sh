#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
# Bito's AI Architect CLI - Platform Adapter
# Handles platform-wide operations (health, status)

# Source tracker adapter for tracking functions (in same directory)
ADAPTER_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [ -f "${ADAPTER_DIR}/tracker-adapter.sh" ]; then
    source "${ADAPTER_DIR}/tracker-adapter.sh"
elif [ -n "${SCRIPT_DIR:-}" ] && [ -f "${SCRIPT_DIR}/lib/adapters/tracker-adapter.sh" ]; then
    # Fallback: use SCRIPT_DIR if set by parent (bitoarch.sh)
    source "${SCRIPT_DIR}/lib/adapters/tracker-adapter.sh"
fi

# Source setup-utils for shared Git credentials function
if [ -n "${SCRIPT_DIR:-}" ] && [ -f "${SCRIPT_DIR}/setup-utils.sh" ]; then
    source "${SCRIPT_DIR}/setup-utils.sh"
elif [ -f "${ADAPTER_DIR}/../../setup-utils.sh" ]; then
    source "${ADAPTER_DIR}/../../setup-utils.sh"
fi

# Source config-backup-manager for centralized backup utility
if [ -n "${SCRIPT_DIR:-}" ] && [ -f "${SCRIPT_DIR}/lib/config-backup-manager.sh" ]; then
    source "${SCRIPT_DIR}/lib/config-backup-manager.sh"
elif [ -f "${ADAPTER_DIR}/../config-backup-manager.sh" ]; then
    source "${ADAPTER_DIR}/../config-backup-manager.sh"
fi

# Platform command handler
handle_platform() {
    local command="$1"
    shift
    
    # Check for help
    if [ "$command" = "--help" ] || [ "$command" = "-h" ] || [ -z "$command" ]; then
        show_platform_help
        return 0
    fi
    
    # Route to command
    case "$command" in
        health)
            platform_health "$@"
            ;;
        status)
            platform_status "$@"
            ;;
        info)
            platform_info "$@"
            ;;
        rotate-token)
            platform_rotate_token "$@"
            ;;
        update-api-key)
            platform_update_api_key "$@"
            ;;
        update-git-creds)
            platform_update_git_creds "$@"
            ;;
        mcp)
            platform_mcp "$@"
            ;;
        *)
            print_error "Unknown platform command: $command"
            echo ""
            echo "Available commands: health, status, info, rotate-token, update-api-key, update-git-creds, mcp"
            echo -e "Use ${YELLOW}bitoarch --help${NC} for more information"
            return 1
            ;;
    esac
}

# Health check for the K8s deployment. Queries each deployment's
# readyReplicas vs spec.replicas -- the same signal K8s uses to decide
# whether a pod is eligible to receive traffic (reflects readinessProbe).
# Avoids the localhost HTTP probes used by the Docker path, which depend
# on `kubectl port-forward` processes that may not outlive the install
# session.
_platform_health_k8s() {
    local verbose="$1"
    local namespace="bito-ai-architect"

    print_header "Bito's AI Architect Health Check"
    echo ""

    if ! kubectl get namespace "$namespace" >/dev/null 2>&1; then
        print_warning "Kubernetes namespace '$namespace' not found"
        echo ""
        print_info "Services may not be deployed yet"
        return 1
    fi

    # Deployment name -> display name. Matches the Docker path's user-facing
    # labels. Tracker excluded (background service; parity with Docker list).
    local deployments=(
        "ai-architect-provider|AI Architect Provider (MCP)"
        "ai-architect-config|AI Architect Config"
        "ai-architect-manager|AI Architect Manager"
        "ai-architect-mysql|MySQL Database"
        "ai-architect-worker|AI Architect Worker"
    )

    local healthy_count=0
    local total_count=${#deployments[@]}
    local d name display ready spec

    for d in "${deployments[@]}"; do
        IFS='|' read -r name display <<< "$d"
        printf "%-30s " "$display"

        ready=$(kubectl get deployment "$name" -n "$namespace" \
                -o jsonpath='{.status.readyReplicas}' 2>/dev/null)
        spec=$(kubectl get deployment "$name" -n "$namespace" \
                -o jsonpath='{.spec.replicas}' 2>/dev/null)

        # Healthy iff spec>=1 AND ready==spec. Empty ready means no pods have
        # reported ready yet (return "" from jsonpath, not "0").
        if [ -n "$spec" ] && [ "$spec" != "0" ] \
           && [ -n "$ready" ] && [ "$ready" = "$spec" ]; then
            echo -e "$(format_status "healthy")"
            healthy_count=$((healthy_count + 1))
            if [ "$verbose" = "true" ]; then
                echo "    Deployment: $name  (ready ${ready}/${spec})"
            fi
        else
            echo -e "$(format_status "down")"
            if [ "$verbose" = "true" ]; then
                echo "    Deployment: $name  (ready ${ready:-0}/${spec:-0})"
            fi
        fi
        echo ""
    done

    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    log_silent "Health summary: $healthy_count/$total_count healthy"
    if [ "$healthy_count" -eq "$total_count" ]; then
        print_success "All services healthy"
        return 0
    elif [ "$healthy_count" -gt 0 ]; then
        print_warning "Some services unhealthy"
        print_info "Details: ${YELLOW}bitoarch status${NC}"
        return 1
    else
        print_error "All services down"
        print_info "Restart with: ${YELLOW}bitoarch start${NC}"
        return 1
    fi
}

# Check health of all services
platform_health() {
    # Check for help first
    if [ "$1" = "--help" ] || [ "$1" = "-h" ]; then
        cat << 'EOF'
USAGE:
  bitoarch health

DESCRIPTION:
  Check health status of all AI Architect services

OPTIONS:
  --help, -h       Show this help

EXAMPLES:
  bitoarch health
EOF
        return 0
    fi

    local verbose=false

    # Parse options
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --verbose|-v)
                verbose=true
                shift
                ;;
            *)
                shift
                ;;
        esac
    done

    # On K8s, probe the cluster directly -- localhost HTTP probes break when
    # port-forwards die. See _platform_health_k8s for the rationale.
    local deployment_type="docker-compose"
    local deployment_file
    deployment_file=$(get_deployment_type_file 2>/dev/null)
    [ -n "$deployment_file" ] && [ -f "$deployment_file" ] \
        && deployment_type=$(cat "$deployment_file")

    if [ "$deployment_type" = "kubernetes" ]; then
        _platform_health_k8s "$verbose"
        return $?
    fi

    print_header "Bito's AI Architect Health Check"
    echo ""

    # Worker has no HTTP server but declares a docker healthcheck (proc-liveness),
    # same probe style as platform_status. Read .State.Health via `docker inspect`
    # for the container:// scheme below.
    local services=(
        "provider|${PROVIDER_URL}|AI Architect Provider (MCP)"
        "config|${CONFIG_URL}|AI Architect Config"
        "manager|${MANAGER_URL}|AI Architect Manager"
        "mysql|mysql://localhost:${MYSQL_PORT}|MySQL Database"
        "worker|container://ai-architect-worker|AI Architect Worker"
    )

    local healthy_count=0
    local total_count=${#services[@]}

    for service_info in "${services[@]}"; do
        IFS='|' read -r name url display <<< "$service_info"

        printf "%-30s " "$display"

        if [[ "$url" == container://* ]]; then
            # Docker-native health: use the container's own healthcheck result.
            local container_name="${url#container://}"
            local docker_status docker_health
            docker_status=$(docker inspect --format='{{.State.Status}}' "$container_name" 2>/dev/null)
            docker_health=$(docker inspect --format='{{.State.Health.Status}}' "$container_name" 2>/dev/null)

            # Healthy when: container running AND (healthcheck reports healthy
            # OR no healthcheck declared, in which case Docker emits "" / "<no value>").
            if [ "$docker_status" = "running" ] \
               && { [ "$docker_health" = "healthy" ] \
                    || [ -z "$docker_health" ] \
                    || [ "$docker_health" = "<no value>" ]; }; then
                echo -e "$(format_status "healthy")"
                healthy_count=$((healthy_count + 1))
            else
                echo -e "$(format_status "down")"
            fi

            if [ "$verbose" = "true" ]; then
                echo "    Container: $container_name (status: ${docker_status:-missing}, health: ${docker_health:-none})"
            fi
        elif [ "$name" = "mysql" ]; then
            # Check MySQL - try HTTP health endpoint first (works for both Docker and K8s)
            local mysql_port=$(echo "$url" | sed -n 's/.*:\([0-9]*\)$/\1/p')
            if curl -sf "http://localhost:${mysql_port}/health" >/dev/null 2>&1; then
                echo -e "$(format_status "healthy")"
                healthy_count=$((healthy_count + 1))
            else
                # Fallback: check if MySQL port is listening
                if nc -z localhost "${mysql_port}" 2>/dev/null || timeout 1 bash -c "cat < /dev/null > /dev/tcp/localhost/${mysql_port}" 2>/dev/null; then
                    echo -e "$(format_status "healthy")"
                    healthy_count=$((healthy_count + 1))
                else
                    echo -e "$(format_status "down")"
                fi
            fi
            
            if [ "$verbose" = "true" ]; then
                echo "    Port: ${mysql_port}"
            fi
        else
            # Check HTTP services
            if health_check "$url"; then
                echo -e "$(format_status "healthy")"
                healthy_count=$((healthy_count + 1))
                
                if [ "$verbose" = "true" ]; then
                    local port=$(echo "$url" | sed -n 's/.*:\([0-9]*\)$/\1/p')
                    echo "    URL: $url"
                    echo "    Port: $port"
                    
                    # Get additional info from health endpoint
                    local health_info=$(http_request "GET" "${url}/health" "" "" "" 2>/dev/null)
                    if require_command jq && [ -n "$health_info" ]; then
                        local uptime=$(echo "$health_info" | jq -r '.uptime // "N/A"')
                        echo "    Uptime: ${uptime}s"
                    fi
                fi
            else
                echo -e "$(format_status "down")"
            fi
        fi
        echo ""
    done
    
    # Summary
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    
    # Service counts go to log only; terminal shows verdict without numeric ratio.
    log_silent "Health summary: $healthy_count/$total_count healthy"
    if [ $healthy_count -eq $total_count ]; then
        print_success "All services healthy"
        return 0
    elif [ $healthy_count -gt 0 ]; then
        print_warning "Some services unhealthy"
        print_info "Details: ${YELLOW}bitoarch status${NC}"
        return 1
    else
        print_error "All services down"
        print_info "Restart with: ${YELLOW}bitoarch start${NC}"
        return 1
    fi
}

# Get platform status
platform_status() {
    # Check for help first
    if [ "$1" = "--help" ] || [ "$1" = "-h" ]; then
        cat << 'EOF'
USAGE:
  bitoarch status

DESCRIPTION:
  Show the current status of all AI Architect services including containers,
  health status, uptime, and port mappings.

OPTIONS:
  --help    Show this help

EXAMPLES:
  # Check service status
  bitoarch status

NOTES:
  - Automatically detects Docker Compose or Kubernetes deployment
  - Displays service health and uptime
  - Lists port mappings for each service
EOF
        return 0
    fi
    
    # Banner matches setup.sh::show_status exactly for prod parity.
    echo -e "${BLUE}AI Architect - Service Status${NC}"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo ""

    # Detect deployment type using path-manager
    local deployment_type="docker-compose"
    local deployment_file=$(get_deployment_type_file)
    if [ -f "$deployment_file" ]; then
        deployment_type=$(cat "$deployment_file")
    fi
    
    if [ "$deployment_type" = "kubernetes" ]; then
        # Kubernetes deployment
        local namespace="bito-ai-architect"
        
        # Check if namespace exists
        if ! kubectl get namespace "$namespace" >/dev/null 2>&1; then
            print_warning "Kubernetes namespace '$namespace' not found"
            echo ""
            print_info "Services may not be deployed yet"
            return 1
        fi
        
        # Check if any deployments exist and are running (not scaled to 0)
        deployment_count=$(kubectl get deployment -n "$namespace" -l "app.kubernetes.io/name=bitoarch" 2>/dev/null | wc -l | xargs)
        
        if [ "$deployment_count" -le 1 ]; then
            # No deployments found (only header line or namespace doesn't exist)
            echo ""
            print_warning "No AI Architect services are currently running"
            echo ""
            print_info "To start services, run: ${YELLOW}bitoarch start${NC}"
            return 1
        fi
        
        # Sum replicas across Deployments and StatefulSets to detect a
        # stopped install. Pure bash — bc isn't always installed.
        local replicas_raw replicas_sum=0 r
        replicas_raw=$(kubectl get deployment,statefulset -n "$namespace" \
                       -l "app.kubernetes.io/name=bitoarch" \
                       -o jsonpath='{.items[*].spec.replicas}' 2>/dev/null)

        for r in $replicas_raw; do
            case "$r" in
                ''|*[!0-9]*) ;;
                *) replicas_sum=$((replicas_sum + r)) ;;
            esac
        done

        if [ "$replicas_sum" -eq 0 ]; then
            # Workloads exist but are scaled to 0 (stopped)
            echo ""
            print_warning "No AI Architect services are currently running"
            echo ""
            print_info "To start services, run: ${YELLOW}bitoarch start${NC}"
            return 1
        fi
        
        # Get pod status
        local pods=$(kubectl get pods -n "$namespace" -o json 2>/dev/null)
        
        if [ -z "$pods" ] || [ "$pods" = "null" ]; then
            print_warning "No pods found in namespace: $namespace"
            return 1
        fi
        
        # Parse and display pod status
        echo "$pods" | jq -r '.items[] | 
            "\(.metadata.labels."app.kubernetes.io/component" // "unknown")|\(.status.phase)|\([.status.conditions[]? | select(.type=="Ready")] | if length > 0 then .[0].status else "Unknown" end)|\(.status.startTime)"' | \
        while IFS='|' read -r component phase ready start_time; do
            # Hide internal-only services from user-facing status display
            [ "$component" = "temporal" ] && continue
            [ "$component" = "cis-tracker" ] || [ "$component" = "tracker" ] && continue
            # Skip Helm hook Jobs
            [[ "$component" == *-job* || "$component" == "temporal-post-deploy" || "$component" == "temporal-bootstrap" ]] && continue
            local display_name=$(echo "$component" | awk '{print toupper(substr($0,1,1)) tolower(substr($0,2))}')

            printf "%-15s " "$display_name"
            
            if [ "$phase" = "Running" ] && [ "$ready" = "True" ]; then
                echo -e "$(format_status "running")"
            elif [ "$phase" = "Running" ] && [ "$ready" = "False" ]; then
                echo -e "$(format_status "starting")"
            elif [ "$phase" = "Pending" ]; then
                echo -e "$(format_status "pending")"
            else
                echo -e "$(format_status "$phase")"
            fi
            
            if [ -n "$start_time" ] && [ "$start_time" != "null" ]; then
                echo "  Started: $start_time"
            fi
            echo ""
        done
        
        echo ""
        print_info "Deployment: Kubernetes (namespace: $namespace)"
        print_info "View logs: ${YELLOW}bitoarch logs${NC}"
        
    else
        # Docker Compose deployment
        
        # Check if any services are running. Match setup.sh::show_status
        # byte-for-byte (banner + "no services" hint + exit 0) for prod parity.
        running_services=$(docker ps -q --filter "name=ai-architect-" 2>/dev/null | wc -l)
        if [ "$running_services" -eq 0 ]; then
            print_warning "No AI Architect services are currently running"
            echo ""
            print_info "To start services, run: ${YELLOW}bitoarch start${NC}"
            return 0
        fi
        
        local services=("ai-architect-mysql" "ai-architect-provider" "ai-architect-config" "ai-architect-manager" "ai-architect-worker")
        # Track running/stopped state across services for partial-state detection
        local running_count=0
        local stopped_count=0

        for container in "${services[@]}"; do

            local display_name=$(echo "$container" | sed 's/ai-architect-//' | tr '[:lower:]' '[:upper:]')

            if docker ps --format '{{.Names}}' | grep -q "^${container}$"; then
                local status=$(docker inspect --format='{{.State.Status}}' "$container" 2>/dev/null)
                local health=$(docker inspect --format='{{.State.Health.Status}}' "$container" 2>/dev/null)
                local uptime=$(docker inspect --format='{{.State.StartedAt}}' "$container" 2>/dev/null)

                printf "%-15s " "$display_name"

                if [ "$status" = "running" ]; then
                    running_count=$((running_count + 1))
                    if [ "$health" = "healthy" ] || [ "$health" = "" ]; then
                        echo -e "$(format_status "running")"
                    elif [ "$health" = "starting" ]; then
                        # During start_period, check actual health endpoint
                        local port=$(docker inspect --format='{{range $p, $conf := .NetworkSettings.Ports}}{{if eq $p "8080/tcp"}}8080{{else if eq $p "8081/tcp"}}8081{{else if eq $p "9090/tcp"}}9090{{end}}{{end}}' "$container" 2>/dev/null)
                        if [ -n "$port" ] && curl -sf "http://localhost:$port/health" >/dev/null 2>&1; then
                            echo -e "$(format_status "running")"
                        else
                            echo -e "$(format_status "$health")"
                        fi
                    else
                        echo -e "$(format_status "$health")"
                    fi

                    echo "  Started: $uptime"

                    # Get port mapping
                    local ports=$(docker port "$container" 2>/dev/null | head -1)
                    if [ -n "$ports" ]; then
                        echo "  Ports: $ports"
                    fi
                else
                    stopped_count=$((stopped_count + 1))
                    echo -e "$(format_status "$status")"
                fi
                echo ""
            else
                stopped_count=$((stopped_count + 1))
                printf "%-15s " "$display_name"
                echo -e "$(format_status "stopped")"
                echo ""
            fi
        done

        echo ""
        print_info "Deployment: Docker Compose"
        print_info "View logs: ${YELLOW}bitoarch logs${NC}"

        # Partial-state detection: warn + suggest recovery when some services are down
        if [ "$running_count" -gt 0 ] && [ "$stopped_count" -gt 0 ]; then
            echo ""
            print_warning "Some services are not running (${stopped_count} stopped, ${running_count} running)."
            print_info "Run ${YELLOW}bitoarch start${NC} to restore stopped services (idempotent; safe to re-run)."
        fi
    fi
}

# Get platform information
platform_info() {
    if [ "$1" = "--help" ] || [ "$1" = "-h" ]; then
        cat << 'EOF'
USAGE:
  bitoarch info

DESCRIPTION:
  Show platform identity and pointers: version, edition, deployment type,
  MCP endpoint, config file locations, and documentation links.
  For live service state use 'bitoarch status' or 'bitoarch health'.

OPTIONS:
  --help, -h    Show this help
EOF
        return 0
    fi

    # URL constants live in scripts/lib/constants.sh (not sourced at top).
    if [ -z "${AI_ARCHITECT_DOCS_HOME_URL:-}" ]; then
        local _const_lib
        _const_lib="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
        [ -f "${_const_lib}/constants.sh" ] && \
            source "${_const_lib}/constants.sh" 2>/dev/null || true
    fi

    print_header "Bito's AI Architect Information"
    echo ""

    local platform_version="unknown"
    local versions_file="$SCRIPT_DIR/../versions/service-versions.json"
    if [ -f "$versions_file" ] && require_command jq; then
        platform_version=$(jq -r '.platform_info.version // "unknown"' "$versions_file")
    fi
    format_key_value "Platform Version" "$platform_version"

    # SKIP_SSO_PROMPT (via sso_ui_suppressed) gates both edition label + SSO UI.
    local edition="Enterprise"
    if command -v sso_ui_suppressed >/dev/null 2>&1 && sso_ui_suppressed; then
        edition="Standalone"
    fi
    format_key_value "Edition" "$edition"

    local deployment_type="docker-compose"
    local deployment_file
    deployment_file=$(get_deployment_type_file)
    [ -f "$deployment_file" ] && deployment_type=$(cat "$deployment_file")
    format_key_value "Deployment Type" "$deployment_type"

    local mcp_port="${CIS_PROVIDER_EXTERNAL_PORT:-5001}"
    format_key_value "MCP Endpoint" "${MCP_TRANSPORT:-http}://localhost:${mcp_port}/mcp"

    echo ""
    print_subheader "Config Files:"
    format_key_value "  env"   "$(get_config_file)"
    format_key_value "  repos" "$(get_repo_config_file)"
    format_key_value "  llm"   "$(get_llm_config_file)"
    echo ""
    echo "  View:  bitoarch config path [env|repos|llm]"
    echo "  Edit:  bitoarch config edit [env|repos|llm]"

    echo ""
    print_subheader "Links:"
    format_key_value "  Docs"      "${AI_ARCHITECT_DOCS_HOME_URL:-https://docs.bito.ai/ai-architect}"
    format_key_value "  MCP Setup" "${MCP_SETUP_DOCS_URL:-https://docs.bito.ai/ai-architect/install-ai-architect-self-hosted#setting-up-ai-architect-mcp-in-coding-agents}"

    echo ""
    echo "See also: 'bitoarch status' (live state) · 'bitoarch health' (health checks)"
    echo ""
}

# Re-register the local MCP with installed coding agents after a token
# rotation. Standalone-only; gated on MCP_AUTO_INSTALL.
_platform_reregister_mcp_with_agents() {
    if [ -f "${SCRIPT_DIR:-}/lib/bitoarch-config.sh" ]; then
        # shellcheck disable=SC1091
        source "${SCRIPT_DIR:-}/lib/bitoarch-config.sh"
    fi
    if ! { command -v mcp_auto_install_enabled >/dev/null 2>&1 && mcp_auto_install_enabled; }; then
        log_silent "rotate-mcp-token: skipping IDE re-registration (MCP_AUTO_INSTALL!=true)"
        return 0
    fi
    if [ -f "${SCRIPT_DIR:-}/lib/mcp-installer.sh" ]; then
        # shellcheck disable=SC1091
        source "${SCRIPT_DIR:-}/lib/mcp-installer.sh"
    fi
    command -v mcp_installer_run >/dev/null 2>&1 || return 0
    print_info "Re-registering coding agents with new MCP token..."
    mcp_installer_run || true
}

_mcp_hot_refresh_config() {
    local token="$1" restart_hint="$2"
    if [ -z "${BITO_API_KEY:-}" ]; then
        print_warning "BITO_API_KEY not set; skipping config service hot-refresh."
        return 0
    fi
    local _cfg_url="${CONFIG_URL:-http://localhost:${CIS_CONFIG_EXTERNAL_PORT:-5003}}"
    if curl -sf --max-time 5 \
           -X PUT \
           -H "Authorization: Bearer ${BITO_API_KEY}" \
           -H "Content-Type: application/json" \
           -d "{\"token\":\"${token}\"}" \
           "${_cfg_url}/api/v1/config/mcp" >/dev/null 2>&1; then
        log_silent "MCP token refreshed in config service"
    else
        print_warning "Could not hot-refresh config service. Restart it when convenient:"
        echo -e "    ${YELLOW}${restart_hint}${NC}"
    fi
}

platform_rotate_token() {
    local new_token="$1"
    
    if [ "$1" = "--help" ] || [ "$1" = "-h" ] || [ -z "$new_token" ]; then
        cat << 'EOF'
USAGE:
  bitoarch rotate-mcp-token <new-token>

DESCRIPTION:
  Rotate the Bito MCP access token and restart cis-provider service

ARGUMENTS:
  <new-token>    New MCP access token (required)

EXAMPLES:
  # Rotate to a new token
  bitoarch rotate-mcp-token "new-secure-token-abc123"
  
  # This will:
  # 1. Update token in .env file
  # 2. Update MCP server configuration
  # 3. Restart cis-provider service only
  # 4. Display new MCP connection details

NOTE:
  - Only cis-provider is restarted (minimal downtime ~2 seconds)
  - Other services remain running
  - Token takes effect immediately

EOF
        return 0
    fi
    
    print_info "Rotating MCP access token..."
    
    # Validate token is provided
    if [ -z "$new_token" ]; then
        print_error "Token cannot be empty"
        return 1
    fi
    
    if [ -f "$ENV_FILE" ]; then
        sed -i.bak "s/^BITO_MCP_ACCESS_TOKEN=.*/BITO_MCP_ACCESS_TOKEN=${new_token}/" "$ENV_FILE"
        rm -f "${ENV_FILE}.bak"
        print_success "Updated token in .env"
    else
        print_error ".env file not found: $ENV_FILE"
        return 1
    fi

    load_env_config
    export BITO_MCP_ACCESS_TOKEN="$new_token"

    # Provider containers rewrite /opt/bito/xmcp/config/default.json from
    # BITO_MCP_ACCESS_TOKEN on startup (scripts/provider-startup.sh and
    # helm-bitoarch/provider-startup.sh), so no host-side MCP config edit is
    # needed -- env propagation + restart is sufficient.

    print_info "Restarting ai-architect-provider service..."

    local deployment_type="docker-compose"
    if type get_deployment_type >/dev/null 2>&1; then
        deployment_type=$(get_deployment_type 2>/dev/null)
        [ "$deployment_type" = "unknown" ] && deployment_type="docker-compose"
    else
        local dep_file
        dep_file=$(get_deployment_type_file 2>/dev/null)
        if [ -n "$dep_file" ] && [ -f "$dep_file" ]; then
            deployment_type=$(cat "$dep_file")
        fi
    fi

    if [ "$deployment_type" = "kubernetes" ]; then
        local namespace="bito-ai-architect"

        if ! command -v generate_k8s_values_from_env >/dev/null 2>&1; then
            source "${SCRIPT_DIR:-}/values-generator.sh" 2>/dev/null \
                || source "${PROJECT_ROOT}/scripts/values-generator.sh" 2>/dev/null \
                || true
        fi
        if command -v generate_k8s_values_from_env >/dev/null 2>&1; then
            if generate_k8s_values_from_env >/dev/null 2>&1; then
                print_success "Regenerated Helm values file"
            else
                print_warning "Failed to regenerate values file; a later 'helm upgrade' may revert the token"
            fi
        else
            print_warning "values-generator.sh not found; skipping values file regeneration"
        fi

        if kubectl patch secret bitoarch-secrets -n "$namespace" \
               --field-manager=helm \
               --type merge \
               -p "{\"stringData\":{\"mcp-access-token\":\"${new_token}\"}}" >/dev/null 2>&1; then
            print_success "Patched Kubernetes secret bitoarch-secrets"
        else
            print_error "Failed to patch secret bitoarch-secrets in namespace $namespace"
            print_warning "Try manually: kubectl patch secret bitoarch-secrets -n $namespace --type merge -p '{\"stringData\":{\"mcp-access-token\":\"<new-token>\"}}'"
            return 1
        fi

        if kubectl rollout restart deployment -n "$namespace" -l "app.kubernetes.io/component=provider" >/dev/null 2>&1; then
            print_info "Waiting for provider rollout to finish..."
            local rollout_timeout="${K8S_ROLLOUT_TIMEOUT:-5m}"
            if ! kubectl rollout status deployment -n "$namespace" -l "app.kubernetes.io/component=provider" --timeout="$rollout_timeout" >/dev/null 2>&1; then
                print_warning "Provider rollout not confirmed within ${rollout_timeout}. MCP tools may be temporarily unavailable."
            fi

            ensure_provider_service_accessible 2>/dev/null || true

            ensure_config_service_accessible 2>/dev/null || true
            _mcp_hot_refresh_config "$new_token" "kubectl rollout restart deployment -n $namespace -l app.kubernetes.io/component=config"

            echo ""
            print_success "MCP token rotated successfully"
            _platform_reregister_mcp_with_agents
            echo ""
            print_info "New MCP URL: ${PROVIDER_URL}/mcp"
            print_info "New Token: ${new_token}"
            echo ""
            return 0
        else
            print_error "Failed to restart ai-architect-provider"
            print_warning "Try manually: kubectl rollout restart deployment -n $namespace -l app.kubernetes.io/component=provider"
            return 1
        fi
    else
        # Sets HOST_MCP_CERT_DIR + XMCP_INTERNAL_PORT for HTTPS Standalone;
        # no-op on Enterprise/HTTP.
        if [ -f "${SCRIPT_DIR:-}/lib/mcp-cert.sh" ]; then
            # shellcheck disable=SC1091
            source "${SCRIPT_DIR:-}/lib/mcp-cert.sh"
            mcp_cert_prepare_for_compose >/dev/null 2>&1 || true
        fi

        local orig_dir
        orig_dir=$(pwd)
        cd "$PROJECT_ROOT" 2>/dev/null || {
            print_error "Failed to change to project directory: $PROJECT_ROOT"
            return 1
        }

        # `docker compose restart` does NOT re-read --env-file; use
        # `up -d --force-recreate` so the new BITO_MCP_ACCESS_TOKEN reaches
        # the provider container. Config service is NOT restarted — the new
        # token is pushed via PUT /api/v1/config/mcp to avoid disrupting
        # in-flight indexing that reads Jira/Confluence credentials from config.
        print_info "Restarting ai-architect-provider with new token..."
        if docker compose --env-file "$ENV_FILE" up -d --force-recreate ai-architect-provider 2>/dev/null \
           || docker-compose --env-file "$ENV_FILE" up -d --force-recreate ai-architect-provider 2>/dev/null; then
            cd "$orig_dir"

            print_info "Waiting for provider to become ready..."
            local _rw=0
            while [ $_rw -lt 30 ]; do
                if curl -sf --max-time 2 "${PROVIDER_URL}/health" >/dev/null 2>&1 \
                   || curl -sf --max-time 2 -k "${PROVIDER_URL}/health" >/dev/null 2>&1; then
                    break
                fi
                sleep 1
                _rw=$((_rw + 1))
            done
            [ $_rw -ge 30 ] && print_warning "Provider may still be starting. MCP tools might be temporarily unavailable."

            _mcp_hot_refresh_config "$new_token" "docker compose restart ai-architect-config"

            echo ""
            print_success "MCP token rotated successfully"
            _platform_reregister_mcp_with_agents
            echo ""
            print_info "New MCP URL: ${PROVIDER_URL}/mcp"
            print_info "New Token: ${new_token}"
            echo ""
            return 0
        else
            cd "$orig_dir"
            print_error "Failed to recreate ai-architect-provider"
            print_warning "Try manually: cd $PROJECT_ROOT && docker compose --env-file $ENV_FILE up -d --force-recreate ai-architect-provider"
            return 1
        fi
    fi
}

# Update Bito API key
platform_update_api_key() {
    local new_api_key=""
    local restart_services=false

    # Route this command's silent logs to the canonical setup log; setup-utils
    # defaults LOG_FILE to a repo-local path that operators never see.
    command -v get_setup_log >/dev/null 2>&1 && LOG_FILE="$(get_setup_log)"

    # Parse options
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --help|-h)
                cat << 'EOF'
USAGE:
  bitoarch update-api-key [OPTIONS]

DESCRIPTION:
  Update the Bito API key in the .env-bitoarch file.
  Optionally update Git credentials in the same session.

OPTIONS:
  --api-key <key>    The new Bito API key
  --restart          Restart services after updating
  --help, -h         Show this help

NOTES:
  - Interactive mode will prompt for API key and optionally Git credentials
  - Services must be restarted for changes to take effect
  - Use --restart flag to automatically restart services
EOF
                return 0
                ;;
            --api-key)
                new_api_key="$2"
                shift 2
                ;;
            --restart)
                restart_services=true
                shift
                ;;
            *)
                print_error "Unknown option: $1"
                return 1
                ;;
        esac
    done
    
    # If no API key provided, prompt securely
    if [ -z "$new_api_key" ]; then
        echo ""
        echo -e "${BLUE}${BOLD}Update Bito API Key${NC}"
        echo ""
        echo "Enter new Bito API key (input hidden):"
        read -s new_api_key
        echo ""
        if [ -z "$new_api_key" ]; then
            print_error "API key cannot be empty"
            return 1
        fi
        echo ""  # Newline after hidden input
    fi
    
    # Load current .env-bitoarch to get TRACKING_SERVICE_BASE_URL
    if [ -f "$ENV_FILE" ]; then
        source "$ENV_FILE"
    fi
    
    # Validate API key using shared function (strict mode for CLI)
    if [[ -n "$TRACKING_SERVICE_BASE_URL" ]]; then
        if ! validate_and_print_bito_api_key_status "$new_api_key" "architect_api_key_update" "$TRACKING_SERVICE_BASE_URL" "API key validated successfully" "true"; then
            return 1
        fi
    fi
    
    echo ""

    # Workspace-ownership guard + cis-config sync, BEFORE the .env rewrite/restart
    # (cis-config validates a caller against the key the service is currently
    # running with, so we authenticate with the current/old key).
    #
    # 1) Resolve the NEW key's workspace via the same project-info/context check
    #    install uses. check_indexing_enabled sets RESOLVED_WORKSPACE_ID and
    #    RESOLVED_EMAIL (returned via globals, like TRACKING_HTTP_STATUS); its
    #    return code (indexing-enabled) is intentionally ignored — BYOK /
    #    indexing-disabled is still a valid key.
    # 2) Read the current workspace from cis-config using the current/old key.
    #    - No config row yet (404): nothing to compare or patch; add-repos creates
    #      the row later — skip the cis-config sync.
    #    - Config present: sync ONLY on a positive same-workspace match. Fail closed
    #      otherwise — a different workspace, OR one we can't resolve, is blocked;
    #      syncing it would orphan the stored config (the BITO-14358 duplicate-row
    #      state) since the PATCH writes into the current row under the old key.
    # Both resolvers return non-zero on valid paths (check_indexing_enabled returns
    # 1 for BYOK/indexing-disabled; config_fetch_workspace_id returns 2 when no
    # config row exists). Guard each so the installer's `set -e` cannot abort the
    # command here — that would skip the git-creds / restart prompts below.
    local new_ws new_email current_ws cfg_rc
    check_indexing_enabled "$TRACKING_SERVICE_BASE_URL" "$new_api_key" >/dev/null 2>&1 || true
    new_ws="$RESOLVED_WORKSPACE_ID"
    new_email="$RESOLVED_EMAIL"
    if current_ws=$(config_fetch_workspace_id "$BITO_API_KEY"); then cfg_rc=0; else cfg_rc=$?; fi

    if [ "$cfg_rc" -eq 0 ] && [ -n "$current_ws" ]; then
        if [[ "$new_ws" =~ ^[0-9]+$ ]] && [ "$new_ws" = "$current_ws" ]; then
            # Positive same-workspace match — safe to sync the rotated key.
            if config_sync_bito_access_key "$new_api_key" "$BITO_API_KEY"; then
                log_silent "Synced new API key to cis-config (workspace ${current_ws})"
            else
                print_warning "Could not sync the new key to cis-config; stored config may keep the old key until next add-repos/update-repos"
            fi
        elif [[ "$new_ws" =~ ^[0-9]+$ ]]; then
            # Resolved to a DIFFERENT workspace — block; switching would orphan the
            # existing config. Log both workspaces + owners for support; the
            # configured workspace's owner needs its own lookup with the current key
            # (this overwrites RESOLVED_*, but new_ws/new_email are captured above).
            # User-facing message stays generic — on-prem customers don't deal in
            # workspace IDs and never enter one.
            local current_email=""
            check_indexing_enabled "$TRACKING_SERVICE_BASE_URL" "$BITO_API_KEY" >/dev/null 2>&1 || true
            current_email="$RESOLVED_EMAIL"
            log_silent "update-api-key blocked: key belongs to workspace ${new_ws} (owner ${new_email:-unknown}); this instance is configured for workspace ${current_ws} (owner ${current_email:-unknown})"
            print_error "This API key belongs to a different workspace."
            print_error "Switching workspaces is not supported. No changes were made."
            print_info  "Generate an API key for this workspace at: ${BITO_API_KEY_URL:-https://alpha.bito.ai/home/advanced}"
            print_info  "Need help? Contact Bito support at support@bito.ai"
            return 1
        else
            # New key's workspace could not be resolved while a config row exists —
            # fail closed rather than risk syncing a possibly-foreign key into this
            # row (e.g. tracking unreachable or TRACKING_SERVICE_BASE_URL unset).
            log_silent "update-api-key blocked: could not resolve the new key's workspace; this instance is configured for workspace ${current_ws}"
            print_error "Could not verify the new API key's workspace, so no changes were made."
            print_info  "Check that the tracking service is reachable, then retry — or contact Bito support at support@bito.ai"
            return 1
        fi
    else
        log_silent "No existing cis-config row (config fetch rc=${cfg_rc}); skipping cis-config sync"
    fi

    # Create backup using centralized utility
    local backup_file=$(backup_config_file "$ENV_FILE" "env")
    
    # Update .env file using # as delimiter to avoid conflicts with @ in values
    sed -i.bak "s#^BITO_API_KEY=.*#BITO_API_KEY=$new_api_key#" "$ENV_FILE"
    rm -f "${ENV_FILE}.bak"
    
    # XMCP_SSO_DEFAULT_WORKSPACE_ID is intentionally left untouched: the workspace
    # guard above keeps the workspace unchanged, and that field is owned by
    # add-repos / update-repos / SSO.
    
    log_silent "Bito API key updated successfully"
    if [ -n "$backup_file" ]; then
        log_silent "Backup created: $(basename "$backup_file")"
    fi
    
    # Ask if they want to update Git credentials too
    read -r -p "Do you want to update Git credentials as well? (y/N): " update_git
    
    if [[ "$update_git" =~ ^[Yy]$ ]]; then
        echo ""
        # Use shared utility function 
        update_git_credentials_in_env "$ENV_FILE"
        
        # Add CLI-specific success message
        print_success "Git credentials updated successfully"
        echo ""
    fi
    
    # Ask about restarting services if not explicitly set
    if [ "$restart_services" != true ]; then
        read -r -p "Restart services to apply changes? (y/N): " restart_choice
        if [[ "$restart_choice" =~ ^[Yy]$ ]]; then
            restart_services=true
        fi
    fi
    
    # Restart services
    if [ "$restart_services" = true ]; then
        echo ""
        print_info "Restarting services to apply changes..."
        
        # Delegate to the shared force-recreate path so the new key propagates
        # on every deployment: Docker recreates containers; K8s regenerates
        # values + helm upgrade so the ConfigMap and pods pick up the new key.
        # `bitoarch restart --force` prints its own success/failure block.
        #
        # NOTE (existing behavior, not introduced here): on Docker,
        # `restart --force` re-applies install.yaml's .bito_api_key onto .env.
        # This command updates .env (and cis-config) but not install.yaml, so a
        # Docker install whose install.yaml still holds the previous key reverts
        # to it on restart — install.yaml remains the operator's source of truth
        # and must be rotated alongside. K8s regenerates values from .env and is
        # unaffected.
        "$PROJECT_ROOT/scripts/bitoarch.sh" restart --force || return 1
    else
        echo ""
        print_warning "Services not restarted. Changes will take effect after restart."
        echo ""
        print_info "To restart services, run:"
        echo -e "  ${YELLOW}bitoarch restart --force${NC}"
        echo ""
    fi
}

# Update Git credentials
platform_update_git_creds() {
    local restart_services=false
    
    # Parse options
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --help|-h)
                cat << 'EOF'
USAGE:
  bitoarch update-git-creds

DESCRIPTION:
  Update Git provider credentials in the .env-bitoarch file.
  Supported providers: GitLab, GitHub, Bitbucket, Azure DevOps
  
  After updating credentials, use bitoarch add-repos or update-repos to configure repositories.

OPTIONS:
  --help, -h         Show this help

TOKEN TYPES:
  GitHub: Personal Access Token (ghp_xxx or github_pat_xxx)
  GitLab: Personal/Project Access Token (glpat-xxx)
  Bitbucket: App Password
  Azure DevOps: Personal Access Token (sent as Basic auth with an empty username)

NOTES:
  - Use 'bitoarch add-repos <file>' or 'bitoarch update-repos <file>' after updating credentials
  - Ensure token has appropriate repository access permissions
  - For Bitbucket, username/email will be collected based on enterprise status
  - For Azure DevOps, the organization name (e.g. myorg) will be collected
EOF
                return 0
                ;;
            *)
                print_error "Unknown option: $1"
                return 1
                ;;
        esac
    done
    
    # Create backup using centralized utility
    local backup_file=$(backup_config_file "$ENV_FILE" "env")
    if [ -n "$backup_file" ]; then
        log_silent "Backup created: $(basename "$backup_file")"
    fi
    echo ""
    
    # Use shared utility function
    update_git_credentials_in_env "$ENV_FILE"

    # Add CLI-specific success message
    print_success "Git credentials updated successfully"
    echo ""

    # Direct user to apply changes
    print_info "To apply changes, run:"
    echo -e "  ${YELLOW}bitoarch add-repos${NC}    (if config not added yet)"
    echo -e "  ${YELLOW}bitoarch update-repos${NC} (if config already exists)"
    echo ""

    if [ "${INSIGHTS_GIT_ENABLED:-}" = "true" ] && type apply_tuning >/dev/null 2>&1; then
        local _glb="${INSIGHTS_GIT_LOOKBACK_DAYS:-}"
        local _git_body='{"enabled":true}'
        [[ "$_glb" =~ ^[0-9]+$ ]] && _git_body="{\"enabled\":true,\"lookback_days\":${_glb}}"
        apply_tuning git "$_git_body" >/dev/null 2>&1 \
            || log_silent "git-creds update: apply_tuning failed (non-fatal)"
        print_info "Git Insights will use the new token on next run."
        echo -e "  Force re-analysis: ${YELLOW}bitoarch insights run --force${NC}"
        echo ""
    fi
}

# Update LLM configuration
platform_update_llm_config() {
    local llm_backup_file=""
    local llm_config_file=""
    local config_completed=0  # Success flag: 0=incomplete, 1=completed
    
    # Cleanup function for trap - restores backup if configuration incomplete
    cleanup_llm_update() {
        local exit_code=$?
        
        # Restore backup if configuration was NOT completed successfully
        # This catches: Ctrl+C, errors, script exits, and any incomplete runs
        if [ "$config_completed" -ne 1 ] && [ -n "$llm_backup_file" ] && [ -f "$llm_backup_file" ]; then
            echo ""
            print_warning "Configuration incomplete. Restoring previous values..."
            if [ -n "$llm_config_file" ] && [ -f "$llm_backup_file" ]; then
                cp "$llm_backup_file" "$llm_config_file" 2>/dev/null && \
                    print_success "Previous configuration restored" || \
                    print_error "Failed to restore backup from: $llm_backup_file"
            fi
            echo ""
            
            # Remove trap and exit immediately after restore
            trap - INT TERM ERR EXIT
            exit 1
        fi
        
        # Remove trap
        trap - INT TERM ERR EXIT
    }
    
    # Set comprehensive trap for interrupt/error handling
    # Catches: Ctrl+C (INT), kill (TERM), script errors (ERR), normal exits (EXIT)
    trap cleanup_llm_update INT TERM ERR EXIT
    
    # Parse options
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --help|-h)
                cat << 'EOF'
USAGE:
  bitoarch update-llm-config

DESCRIPTION:
  Update custom LLM provider configurations interactively.
  Supports Anthropic, OpenAI, Portkey, Google Vertex AI, Azure AI, Novita,
  AWS Bedrock, and Google Gemini providers.

  After updating, the configuration is automatically synced to the Config API.

SUPPORTED PROVIDERS:
  1. Anthropic (Claude)
  2. OpenAI (GPT)
  3. Portkey (Gateway)
  4. Google Vertex AI
  5. Azure AI
  6. Novita
  7. AWS Bedrock
  8. Google Gemini

EXAMPLES:
  # Interactive update
  bitoarch update-llm-config

NOTES:
  - Uses the same interactive prompts as initial setup
  - Configuration is stored in .env-llm-bitoarch
  - Automatically syncs config to API 
  - Changes take effect immediately
  - Backups are created automatically before changes
EOF
                return 0
                ;;
            *)
                print_error "Unknown option: $1"
                return 1
                ;;
        esac
    done
    
    # Get LLM config file location
    local llm_config_file
    if type get_llm_config_file >/dev/null 2>&1; then
        llm_config_file=$(get_llm_config_file)
    else
        llm_config_file="${PROJECT_ROOT}/.env-llm-bitoarch"
    fi
    
    # Create backup using centralized utility
    if [ -f "$llm_config_file" ]; then
        llm_backup_file=$(backup_config_file "$llm_config_file" "llm-config")
        if [ -n "$llm_backup_file" ]; then
            log_silent "Backup created: $(basename "$llm_backup_file")"
        fi
    fi
    
    echo ""
    echo -e "${BLUE}${BOLD}Update LLM Configuration${NC}"
    echo ""
    
    # Source env-generator for set_env_key_value function (required by llm-config.sh)
    if [ -f "${SCRIPT_DIR}/env-generator.sh" ]; then
        source "${SCRIPT_DIR}/env-generator.sh"
    elif [ -f "${ADAPTER_DIR}/../../env-generator.sh" ]; then
        source "${ADAPTER_DIR}/../../env-generator.sh"
    else
        print_error "Cannot find env-generator.sh (required dependency)"
        return 1
    fi
    
    # Source the LLM configuration functions from shared library
    if [ -f "${SCRIPT_DIR}/lib/llm-config.sh" ]; then
        source "${SCRIPT_DIR}/lib/llm-config.sh"
    elif [ -f "${ADAPTER_DIR}/../llm-config.sh" ]; then
        source "${ADAPTER_DIR}/../llm-config.sh"
    else
        print_error "Cannot find llm-config.sh to load LLM configuration functions"
        return 1
    fi
    
    # Call configure_llm_provider in force_interactive mode -- load_env_config
    # has already exported the existing LLM tokens into this shell, so the
    # default preset-token detection would silently bypass the prompt.
    if type configure_llm_provider >/dev/null 2>&1; then
        configure_llm_provider "force_interactive"
    else
        print_error "configure_llm_provider function not found"
        return 1
    fi

    echo ""
    print_info "Syncing LLM configuration to Config API..."
    echo ""

    # Reload LLM env vars in current shell before API call
    # (create_llm_integration_json reads from shell environment, not from services)
    if [ -f "$llm_config_file" ]; then
        source "$llm_config_file"
        log_silent "Reloaded LLM config in shell environment"
    fi

    # Get repo config file location
    local repo_config_file
    if type get_repo_config_file >/dev/null 2>&1; then
        repo_config_file=$(get_repo_config_file)
    else
        repo_config_file="${PROJECT_ROOT}/.bitoarch-config.yaml"
    fi

    if [ -f "$repo_config_file" ]; then
        # Call config_repo_update_from_file which will read .env-llm-bitoarch and sync to API
        # Completely suppress output including HTTP status codes
        if type config_repo_update_from_file >/dev/null 2>&1; then
            config_repo_update_from_file "$repo_config_file" >/dev/null 2>&1 || true
        fi
    fi

    # Mark configuration as completed successfully
    # This prevents rollback on normal exit
    config_completed=1
    
    # Remove trap after successful completion
    trap - INT TERM ERR EXIT
    
    print_success "LLM configuration updated successfully"
    echo ""
}

# Show MCP configuration
platform_mcp() {
    # Check for help
    if [ "$1" = "--help" ] || [ "$1" = "-h" ]; then
        cat << 'EOF'
USAGE:
  bitoarch mcp-info

DESCRIPTION:
  Display MCP server configuration details including URL, authentication mode,
  and access token (when applicable).

NOTES:
  - Test connection with: bitoarch mcp-test
  - When SSO is enabled, no static access token is required
EOF
        return 0
    fi
    
    # Get MCP URL and token from environment
    local mcp_url="${PROVIDER_URL:-http://localhost:${CIS_PROVIDER_EXTERNAL_PORT:-5001}}/mcp"
    local mcp_token="${BITO_MCP_ACCESS_TOKEN:-not-set}"
    local oauth_enabled="${MCP_OAUTH_ENABLED:-false}"
    local sso_enabled="${XMCP_SSO_ENABLED:-false}"
    local sso_provider="${XMCP_SSO_DEFAULT_PROVIDER:-}"
    
    if mcp_env_drift_check; then
        render_mcp_drift_block "$DRIFTED_KEYS"
    fi

    # Use render function for consistent auth-aware output
    render_mcp_config_block "$mcp_url" "$mcp_token" "$oauth_enabled" "$sso_enabled" "$sso_provider"
}

# Export functions
export -f handle_platform
export -f platform_health
export -f platform_status
export -f platform_info
export -f platform_update_api_key
export -f platform_update_git_creds
export -f platform_update_llm_config
export -f _mcp_hot_refresh_config
export -f platform_rotate_token
export -f platform_mcp
