#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
# Bito's AI Architect CLI
# Command-line interface for managing Bito's AI Architect services

# Get script directory (resolve symlinks)
SOURCE="${BASH_SOURCE[0]}"
while [ -h "$SOURCE" ]; do
    DIR="$( cd -P "$( dirname "$SOURCE" )" && pwd )"
    SOURCE="$(readlink "$SOURCE")"
    [[ $SOURCE != /* ]] && SOURCE="$DIR/$SOURCE"
done
DIR="$( cd -P "$( dirname "$SOURCE" )" && pwd )"

# SCRIPT_DIR should always point to the scripts directory
SCRIPT_DIR="$DIR"

# Source path manager first (for standard paths)
source "${SCRIPT_DIR}/lib/path-manager.sh"

# Source core libraries
source "${SCRIPT_DIR}/lib/cli-core.sh"
source "${SCRIPT_DIR}/lib/http-client.sh"
source "${SCRIPT_DIR}/lib/output-formatter.sh"

# Version — read from versions/service-versions.json (single source of truth)
_versions_file="${SCRIPT_DIR}/../versions/service-versions.json"
if [ -f "$_versions_file" ] && command -v jq >/dev/null 2>&1; then
    CLI_VERSION=$(jq -r '.platform_info.version // "1.0.0"' "$_versions_file" 2>/dev/null)
elif [ -f "$_versions_file" ]; then
    CLI_VERSION=$(grep -A2 '"platform_info"' "$_versions_file" | grep '"version"' | head -1 | cut -d'"' -f4 || echo "1.0.0")
else
    CLI_VERSION="1.0.0"
fi

# Show main help
show_main_help() {
    cat << EOF
╔═══════════════════════════════════════════════════════════════╗
║          Bito's AI Architect - Command Line Interface         ║
╚═══════════════════════════════════════════════════════════════╝

USAGE:
  bitoarch <command> [options]

CORE OPERATIONS:
  index-repos [options]     Trigger workspace repository indexing
    --only-new-repos        Index only new repositories (skip incremental updates)
  index-status              Check indexing status
  pause-indexing            Pause ongoing indexing process
  resume-indexing           Resume paused indexing process
  stop-indexing             Stop indexing process completely
  create-index-scheduler    Create scheduler tasks for the workspace
  update-index-scheduler    Update existing scheduler tasks
  index-repo-list           List all indexed repositories
  show-config               Show current configuration

REPOSITORY MANAGEMENT:
  add-repo <ns>             Add single repository by namespace
  remove-repo <ns>          Remove repository by namespace
  add-repos [file]          Load configuration from YAML file (uses default path if not specified)
  update-repos [file]       Update configuration from YAML file (uses default path if not specified)
  repo-info <name>          Get detailed repository information
  fetch-repo-list [options] Incrementally fetch and update repo list from git provider
    --force-load            Force full reload of all repos from git provider

SERVICE OPERATIONS:
  status              Show all services status (docker ps-like)
  health              Check health of all services
  info                Get platform information

CONFIGURATION:
  update-api-key      Update Bito API key
  update-git-creds    Update Git provider credentials
  update-llm-config   Update custom LLM provider configurations
  rotate-mcp-token    Rotate MCP access token

SSO MANAGEMENT:
  sso setup           Configure SSO (Enterprise IdP or Bito)
  sso status          Check SSO configuration and verification status
  sso enable          Re-enable previously disabled SSO
  sso disable         Disable SSO configuration
  sso rotate-key      Rotate SSO keys

MCP OPERATIONS:
  mcp-test             Test MCP connection
  mcp-tools            List available MCP tools
  mcp-tool-info <name> Get detailed information about a specific MCP tool
  mcp-capabilities     Show MCP server capabilities
  mcp-resources        List MCP resources
  mcp-info             Show MCP configuration

GLOBAL OPTIONS:
  --help, -h          Show help

EXAMPLES:
  # Check service status
  bitoarch status

  # Trigger repository indexing
  bitoarch index-repos

  # Index only newly added repositories
  bitoarch index-repos --only-new-repos

  # Add a repository
  bitoarch add-repo myorg/myrepo

  # List all indexed repositories
  bitoarch index-repo-list

  # Check indexing status
  bitoarch index-status

USE 'bitoarch <command> --help' for command-specific help

VERSION: ${CLI_VERSION}
EOF
}

# Source output modules (needed by adapters)
source "${SCRIPT_DIR}/lib/output-blocks.sh"
source "${SCRIPT_DIR}/lib/output-fields.sh"

# Source adapters
source "${SCRIPT_DIR}/lib/adapters/provider-adapter.sh"
source "${SCRIPT_DIR}/lib/adapters/config-adapter.sh"
source "${SCRIPT_DIR}/lib/adapters/platform-adapter.sh"
source "${SCRIPT_DIR}/lib/adapters/manager-adapter.sh"
source "${SCRIPT_DIR}/lib/adapters/xmcp-adapter.sh"

# Main command dispatcher
main() {
    # Check if no arguments
    if [ $# -eq 0 ]; then
        show_main_help
        exit 0
    fi
    
    # Load configuration
    load_env_config || exit 1
    
    # Get command
    local command="$1"
    shift
    
    # Check for help
    if [ "$command" = "--help" ] || [ "$command" = "-h" ]; then
        show_main_help
        exit 0
    fi
    
    if [ "$command" = "--version" ] || [ "$command" = "-v" ]; then
        echo "Bito AI Architect CLI v${CLI_VERSION}"
        exit 0
    fi
    
    # Route to direct commands or legacy service handlers
    case "$command" in
        # Core Operations
        index-repos)
            manager_sync_simple "$@"
            ;;
        index-status)
            manager_status "$@"
            ;;
        pause-indexing)
            manager_pause_indexing "$@"
            ;;
        resume-indexing)
            manager_resume_indexing "$@"
            ;;
        stop-indexing)
            manager_stop_indexing "$@"
            ;;
        create-index-scheduler)
            manager_scheduler_create "$@"
            ;;
        update-index-scheduler)
            manager_scheduler_update "$@"
            ;;
        index-repo-list)
            provider_repo_list "$@"
            ;;
        show-config)
            config_repo_get "$@"
            ;;
        
        # Repository Management
        add-repo)
            if [ -f "$1" ]; then
                print_error "Use 'bitoarch add-repos <file>' for YAML files"
                exit 1
            fi
            config_repo_add_namespace "$@"
            ;;
        remove-repo)
            config_repo_remove_namespace "$@"
            ;;
        add-repos)
            config_repo_add_from_file "$@"
            ;;
        update-repos)
            config_repo_update_from_file "$@"
            ;;
        repo-info)
            provider_repo_info "$@"
            ;;
        fetch-repo-list)
          fetch_repo_config_from_api "$@"
          ;;
        
        # Service Operations
        status)
            platform_status "$@"
            ;;
        health)
            platform_health "$@"
            ;;
        info)
            platform_info "$@"
            ;;
        logs)
            # Get deployment type and show logs accordingly
            local deployment_type=$(get_deployment_type)
            if [ "$deployment_type" = "kubernetes" ]; then
                local namespace="bito-ai-architect"
                get_k8s_logs "$namespace" "" "true"
            else
                print_error "Use './setup.sh --logs' for Docker Compose deployments"
            fi
            ;;
        restart)
            # Get deployment type and restart accordingly  
            local deployment_type=$(get_deployment_type)
            if [ "$deployment_type" = "kubernetes" ]; then
                local namespace="bito-ai-architect"
                restart_k8s_deployment "$namespace" ""
                print_status "All Kubernetes deployments restarted"
            else
                print_error "Use './setup.sh --restart' for Docker Compose deployments"
            fi
            ;;
        
        # Configuration
        update-api-key)
            platform_update_api_key "$@"
            ;;
        update-git-creds)
            platform_update_git_creds "$@"
            ;;
        update-llm-config)
            platform_update_llm_config "$@"
            ;;
        rotate-mcp-token)
            platform_rotate_token "$@"
            ;;
        
        # MCP Operations
        mcp-test)
            provider_mcp_test "$@"
            ;;
        mcp-tools)
            provider_mcp_tools "$@"
            ;;
        mcp-tool-info)
            provider_mcp_tool_info "$@"
            ;;
        mcp-capabilities)
            provider_mcp_capabilities "$@"
            ;;
        mcp-resources)
            provider_mcp_resources "$@"
            ;;
        mcp-info)
            platform_mcp "$@"
            ;;
        
        # SSO Management
        sso)
            handle_sso "$@"
            ;;
        
        *)
            print_error "Unknown command: $command"
            echo ""
            echo "Use 'bitoarch --help' to see available commands"
            exit 1
            ;;
    esac
}

# Execute main function and exit with its return code
main "$@"
exit $?
