-- ============================================================================
-- Table: insights_entity_state
-- Purpose: Persistent per-entity insights ledger, scoped per workspace.
--          Records the insights processing status of each git repo and jira
--          project so `insights status` can report a cumulative, live picture
--          across runs (decoupled from the last Temporal workflow result).
--          Mirrors how indexing-status persists per-repo state.
--
--          entity_type: git_repo | jira_project
--          entity_key : repo namespace (git) or jira project key (jira)
--          status     : pending | in_progress | done | failed | skipped
--                       - already-current / has-prior repos -> done
--                       - invalid / too-big / dormant repos -> skipped
--                         (skipped is excluded from done/total by the reader)
-- ============================================================================
CREATE TABLE IF NOT EXISTS insights_entity_state (
    id            BIGINT        NOT NULL AUTO_INCREMENT,
    workspace_id  BIGINT        NOT NULL,
    entity_type   VARCHAR(32)   NOT NULL COMMENT 'git_repo | jira_project',
    entity_key    VARCHAR(512)  NOT NULL COMMENT 'repo namespace or jira project key',
    status        VARCHAR(32)   NOT NULL DEFAULT 'pending'
                  COMMENT 'pending|in_progress|done|failed|skipped',
    session_id    VARCHAR(64)   NULL COMMENT 'run (session) that last wrote this row',
    commit_id     VARCHAR(64)   NULL COMMENT 'git only; last analyzed commit',
    updated_at    DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    PRIMARY KEY (id),
    UNIQUE KEY uk_ws_entity (workspace_id, entity_type, entity_key),
    INDEX idx_ws (workspace_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
