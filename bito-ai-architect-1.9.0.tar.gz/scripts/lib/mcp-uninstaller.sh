#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
#
# scripts/lib/mcp-uninstaller.sh
# -----------------------------------------------------------------------------
# Deregister the local MCP endpoint from installed coding agents. Single path
# for both `bitoarch uninstall` (embedded) and `bitoarch mcp-uninstall` (CLI):
# the hosted BitoMCPinstall uninstall.sh bootstrap, invoked with
# --non-interactive. Keeping just one path means the supported-IDE list lives
# entirely upstream — no cis-platform-side hardcoded paths to keep in sync.
#
# Public API (load guard prevents double-source):
#   mcp_uninstaller_run     CDN-bootstrap deregistration; logs + summarizes.
#   mcp_uninstaller_cli     `bitoarch mcp-uninstall` dispatch handler.
# -----------------------------------------------------------------------------

if [ -n "${_BITOARCH_MCP_UNINSTALLER_LIB_LOADED:-}" ]; then
    return 0
fi
_BITOARCH_MCP_UNINSTALLER_LIB_LOADED=1

if [ -z "${PLATFORM_DIR:-}" ]; then
    PLATFORM_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
fi
if [ -z "${SCRIPT_DIR:-}" ]; then
    SCRIPT_DIR="$PLATFORM_DIR"
fi

if [ -f "${PLATFORM_DIR}/scripts/lib/path-manager.sh" ]; then
    # shellcheck disable=SC1091
    source "${PLATFORM_DIR}/scripts/lib/path-manager.sh"
fi
if [ -f "${PLATFORM_DIR}/scripts/lib/output-blocks.sh" ]; then
    # shellcheck disable=SC1091
    source "${PLATFORM_DIR}/scripts/lib/output-blocks.sh"
fi
if [ -f "${PLATFORM_DIR}/scripts/lib/constants.sh" ]; then
    # shellcheck disable=SC1091
    source "${PLATFORM_DIR}/scripts/lib/constants.sh"
fi

# Last-resort log fallbacks when sourced from CDN / ad-hoc shell.
if ! command -v msg_info    >/dev/null 2>&1; then msg_info()    { echo "[INFO] $*"  >&2; }; fi
if ! command -v msg_warn    >/dev/null 2>&1; then msg_warn()    { echo "[WARN] $*"  >&2; }; fi
if ! command -v msg_error   >/dev/null 2>&1; then msg_error()   { echo "[ERROR] $*" >&2; }; fi
if ! command -v msg_success >/dev/null 2>&1; then msg_success() { echo "[OK] $*"    >&2; }; fi
if ! command -v log_silent  >/dev/null 2>&1; then log_silent()  { :; }; fi

# -----------------------------------------------------------------------------
# Helpers
# -----------------------------------------------------------------------------

_mcp_uninstaller_log_path() {
    local log_dir
    if command -v get_log_dir >/dev/null 2>&1; then
        log_dir="$(get_log_dir)"
    else
        log_dir="${HOME}/.local/bitoarch/var/log"
    fi
    mkdir -p "$log_dir" 2>/dev/null || true
    echo "${log_dir}/mcp-uninstall.log"
}

# Build a BitoMCPinstall CDN URL from the configured base + a relative path
# (uninstall.sh). Honors MCP_INSTALLER_BASE_URL the same way mcp_installer_run
# does so install and uninstall hit the same environment by default.
_mcp_uninstaller_cdn_url() {
    local path="$1"
    local base="${MCP_INSTALLER_BASE_URL:-https://mcp-setup-staging.bito.ai}"
    echo "${base%/}/${path#/}"
}

_mcp_uninstaller_emit_manual_fallback() {
    local reason="${1:-unknown}"
    local url="${BITO_STANDALONE_MCP_DOCS_URL:-https://docs.bito.ai/ai-architect/standalone-mcp-coding-agents}"
    local log
    log="$(_mcp_uninstaller_log_path)"

    : "${YELLOW:=$'\033[1;33m'}"
    : "${BLUE:=$'\033[1;34m'}"
    : "${BOLD:=$'\033[1m'}"
    : "${NC:=$'\033[0m'}"

    echo ""
    echo -e "${BOLD}${YELLOW}MCP auto-deregistration could not complete${NC} (${reason})."
    echo -e "Deregister your coding agents manually: ${BLUE}${url}${NC}"
    echo -e "Detailed log: ${log}"
    echo ""
}

# Reads the latest "mcp-uninstaller run" section from the log and prints one
# verdict line per coding agent. Phrases match the bootstrap's literal output:
#   "✓ Removed from <IDE>"                  → ✓ <IDE>
#   "ℹ <IDE> ... not found. Skipping."      → ⚠ <IDE> (not configured)
#   "ℹ <IDE> requires manual ..."           → ℹ <IDE> (manual removal required)
#   "✗ ..."                                 → ✗ <message>
# ANSI codes from upstream output are stripped before matching.
_mcp_uninstaller_summarize() {
    local log="$1"
    [ -f "$log" ] || return 0

    local section
    section=$(awk '
        /^--- [0-9TZ:.+-]+ mcp-uninstaller run ---$/ { buf=""; next }
        { buf = buf $0 ORS }
        END { printf "%s", buf }
    ' "$log" 2>/dev/null)
    [ -n "$section" ] || return 0

    local g="\033[0;32m" y="\033[1;33m" b="\033[1;34m" r="\033[0;31m" n="\033[0m"

    local rendered
    rendered=$(printf "%s" "$section" | awk -v g="$g" -v y="$y" -v b="$b" -v r="$r" -v n="$n" '
        BEGIN { ESC = sprintf("%c", 27) }
        function emit(sym, color, name, suffix) {
            if (name == "" || seen[name]++) return
            printf "  %s%s%s %s%s\n", color, sym, n, name, suffix
        }
        {
            line = $0
            gsub(ESC "\\[[0-9;]*[a-zA-Z]", "", line)
        }
        line ~ /^✓ Removed from / {
            name = line
            sub(/^✓ Removed from /, "", name)
            sub(/[[:space:]]+$/, "", name)
            emit("✓", g, name, "")
            next
        }
        line ~ /not found\. Skipping/ {
            name = line
            sub(/^ℹ /, "", name)
            sub(/ (CLI |MCP configuration |configuration )?not found\. Skipping.*$/, "", name)
            emit("⚠", y, name, " (not configured)")
            next
        }
        line ~ /requires manual/ {
            name = line
            sub(/^ℹ /, "", name)
            sub(/ requires manual.*$/, "", name)
            emit("ℹ", b, name, " (manual removal required)")
            next
        }
        line ~ /^✗ / {
            msg = line
            sub(/^✗ /, "", msg)
            emit("✗", r, msg, "")
            next
        }
    ')
    [ -n "$rendered" ] || return 0

    # Leading + trailing blank lines bracket the section so it reads as a
    # distinct block after the prompt and before the next shell prompt.
    # Header at 0-indent, items at 2-indent (set in emit() above).
    printf '\n%bCoding agent MCP removal:%b\n%s\n' "$b" "$n" "$rendered"
}

# -----------------------------------------------------------------------------
# Public API
# -----------------------------------------------------------------------------

# Standalone uninstall hook. Downloads the hosted BitoMCPinstall uninstall
# bootstrap, neutralizes any /dev/tty reads that aren't gated by
# --non-interactive, then executes with --non-interactive. Output captured
# to mcp-uninstall.log; the summarizer renders a per-agent verdict.
mcp_uninstaller_run() {
    if ! command -v curl >/dev/null 2>&1; then
        log_silent "mcp-uninstaller: curl not installed; cannot run CDN uninstall."
        _mcp_uninstaller_emit_manual_fallback "curl not installed"
        return 1
    fi

    local uninstall_url log script_tmp
    uninstall_url="$(_mcp_uninstaller_cdn_url uninstall.sh)"
    log="$(_mcp_uninstaller_log_path)"
    script_tmp="$(mktemp 2>/dev/null)" || {
        _mcp_uninstaller_emit_manual_fallback "mktemp failed"
        return 1
    }

    log_silent "mcp-uninstaller: bootstrap=${uninstall_url}"

    echo "--- $(date -u +%FT%TZ) mcp-uninstaller run ---" >> "$log" 2>/dev/null || true

    if ! curl -fsSL "$uninstall_url" -o "$script_tmp" 2>>"$log"; then
        rm -f "$script_tmp"
        log_silent "mcp-uninstaller: download failed; see ${log}"
        _mcp_uninstaller_emit_manual_fallback "download failed"
        return 1
    fi

    # TODO(upstream-fix): upstream uninstall.sh has a `read -p "..." -r REPLY
    # < /dev/tty` (auto-update state cleanup) that is NOT gated by
    # --non-interactive, hanging the terminal even when the flag is passed.
    # Neutralize every /dev/tty read by replacing it with `VAR=""` so the
    # script proceeds with the safe default ("no" for (y/N) prompts). Drop
    # this sed once the upstream `if [[ "$NON_INTERACTIVE" != "true" ]]`
    # guard lands on every prompt.
    sed -E 's|read -p ".*" -r ([A-Za-z_]+) < /dev/tty|\1=""|g' "$script_tmp" \
        > "${script_tmp}.p" 2>>"$log" \
        && mv "${script_tmp}.p" "$script_tmp"

    # `--non-interactive` is the upstream flag that skips its gated (y/N)
    # prompts. `</dev/null` is belt-and-braces for any future stdin read
    # (the sed-patch handles /dev/tty reads).
    local rc=0
    bash "$script_tmp" --non-interactive </dev/null >> "$log" 2>&1
    rc=$?
    rm -f "$script_tmp"

    _mcp_uninstaller_summarize "$log"

    if [ $rc -ne 0 ]; then
        log_silent "mcp-uninstaller: bootstrap exit ${rc}; see ${log}"
        _mcp_uninstaller_emit_manual_fallback "auto-uninstall exit ${rc}"
        return 1
    fi

    log_silent "mcp-uninstaller: uninstall completed → ${log}"
    return 0
}

# Confirmation prompt. AUTO_SETUP=true skips (matches _uninstall_confirm).
# Per-IDE breakdown lives in the post-run summary, so the prompt itself stays
# tight — just the action + the inverse-command hint.
_mcp_uninstaller_confirm() {
    if [ "${AUTO_SETUP:-}" = "true" ]; then
        return 0
    fi

    : "${YELLOW:=$'\033[1;33m'}"
    : "${NC:=$'\033[0m'}"

    echo ""
    if command -v print_warning >/dev/null 2>&1; then
        print_warning "Deregister BitoAIArchitect MCP from your installed coding agents."
    else
        echo -e "${YELLOW}⚠ Deregister BitoAIArchitect MCP from your installed coding agents.${NC}"
    fi
    echo -e "  Re-register anytime with: ${YELLOW}bitoarch mcp-install${NC}"
    echo ""
    local reply
    read -r -p "Type 'yes' to confirm: " reply
    [ "$reply" = "yes" ]
}

# `bitoarch mcp-uninstall` dispatch.
mcp_uninstaller_cli() {
    local non_interactive=false
    while [ $# -gt 0 ]; do
        case "$1" in
            --non-interactive|-y)
                non_interactive=true
                shift
                ;;
            --help|-h)
                cat <<EOF
USAGE:
  bitoarch mcp-uninstall [--non-interactive]

Deregisters the local MCP server from your installed coding agents.
AI Architect services keep running -- re-register anytime with
\`bitoarch mcp-install\`.

Supported coding agents: ${BITO_STANDALONE_MCP_DOCS_URL:-https://docs.bito.ai/ai-architect/standalone-mcp-coding-agents}

OPTIONS:
  --non-interactive, -y    Skip the confirmation prompt.
  --help, -h               Show this help.
EOF
                return 0
                ;;
            *)
                msg_error "Unknown argument: $1"
                return 1
                ;;
        esac
    done

    if [ "$non_interactive" = "false" ]; then
        if ! _mcp_uninstaller_confirm; then
            if command -v print_info >/dev/null 2>&1; then
                print_info "Uninstall cancelled."
            else
                msg_info "Uninstall cancelled."
            fi
            return 0
        fi
    fi

    mcp_uninstaller_run
}

# Embedded deregistration gated on MCP auto-install (the CLI gates at the
# dispatcher instead). Shared entry point for callers that run inside a larger
# flow, e.g. `bitoarch uninstall`.
mcp_uninstaller_run_if_enabled() {
    if command -v mcp_auto_install_enabled >/dev/null 2>&1 && mcp_auto_install_enabled; then
        mcp_uninstaller_run
    else
        log_silent "mcp-uninstaller: deregistration skipped (MCP_AUTO_INSTALL!=true)"
    fi
}

export -f mcp_uninstaller_run
export -f mcp_uninstaller_run_if_enabled
export -f mcp_uninstaller_cli
