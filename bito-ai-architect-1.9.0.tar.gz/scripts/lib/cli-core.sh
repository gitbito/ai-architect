#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
# CIS Platform CLI - Core Functions
# Handles configuration loading, environment setup, and shared utilities

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[1;34m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m' # No Color

# Project root directory (scripts/../ = project root)
if [ -z "$SCRIPT_DIR" ]; then
    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && cd ../.. && pwd)"
fi
PROJECT_ROOT="$(cd "$SCRIPT_DIR" && cd .. && pwd)"

# Use path-manager to get config files (already sourced in bitoarch.sh)
# These functions check system-wide, user-local, and legacy paths in order
if type get_config_file >/dev/null 2>&1; then
    ENV_FILE=$(get_config_file)
    ENV_LLM_FILE=$(get_llm_config_file)
else
    # Fallback to legacy paths if path-manager not available
    ENV_FILE="${PROJECT_ROOT}/.env-bitoarch"
    ENV_LLM_FILE="${PROJECT_ROOT}/.env-llm-bitoarch"
fi


# Global configuration variables
PROVIDER_URL=""
CONFIG_URL=""
MANAGER_URL=""
MYSQL_HOST=""
MYSQL_PORT=""
PROVIDER_TOKEN=""
CONFIG_API_KEY=""
MANAGER_API_KEY=""

# Load environment configuration
load_env_config() {
    if [ ! -f "$ENV_FILE" ]; then
        echo -e "${RED}Error: Configuration file not found: $ENV_FILE${NC}" >&2
        echo -e "${YELLOW}Bito AI Architect is not installed on this host. Run your install command to configure it.${NC}" >&2
        return 1
    fi
    
    # Source environment variables
    set -a
    source "$ENV_FILE"
    if [ -f "$ENV_LLM_FILE" ]; then
       source "$ENV_LLM_FILE"
    fi
    set +a
    
    # Set service endpoints using external ports.
    # Provider runs HTTPS in Standalone (MCP_TRANSPORT=https); Config/Manager
    # are always HTTP (internal services, not exposed to coding agents).
    local mcp_scheme="http"
    [ "${MCP_TRANSPORT:-http}" = "https" ] && mcp_scheme="https"
    PROVIDER_URL="${mcp_scheme}://localhost:${CIS_PROVIDER_EXTERNAL_PORT:-5001}"
    CONFIG_URL="http://localhost:${CIS_CONFIG_EXTERNAL_PORT:-5003}"
    MANAGER_URL="http://localhost:${CIS_MANAGER_EXTERNAL_PORT:-5002}"
    MYSQL_HOST="localhost"
    MYSQL_PORT="${MYSQL_EXTERNAL_PORT:-5004}"
    
    # Set auth tokens
    PROVIDER_TOKEN="${BITO_MCP_ACCESS_TOKEN}"
    CONFIG_API_KEY="${CIS_CONFIG_API_KEY}"
    MANAGER_API_KEY="${CIS_MANAGER_API_KEY}"
    
    return 0
}

# Print colored output
print_error() {
    echo -e "${RED}✗${NC} $1" >&2
}

print_success() {
    echo -e "${GREEN}✓${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}⚠${NC} $1"
}

print_info() {
    echo -e "${BLUE}ℹ${NC} $1"
}

print_header() {
    echo -e "${BOLD}${BLUE}$1${NC}"
}

print_subheader() {
    echo -e "${CYAN}$1${NC}"
}

# Check if required command exists
require_command() {
    local cmd="$1"
    if ! command -v "$cmd" >/dev/null 2>&1; then
        print_error "Required command not found: $cmd"
        echo "Please install $cmd to use this feature."
        return 1
    fi
    return 0
}

# Check if services are running
check_service_running() {
    local service_name="$1"
    
    if ! command -v docker >/dev/null 2>&1; then
        print_error "Docker not found"
        return 1
    fi
    
    if docker ps --format '{{.Names}}' | grep -q "^${service_name}$"; then
        return 0
    else
        return 1
    fi
}

# Echo the running provider container's env (KEY=VALUE lines); non-zero when
# docker / the container is unavailable.
_mcp_env_drift_docker_env() {
    local container="ai-architect-provider"
    check_service_running "$container" >/dev/null 2>&1 || return 2
    local container_env
    container_env=$(docker inspect --format='{{range .Config.Env}}{{println .}}{{end}}' "$container" 2>/dev/null) || return 2
    [ -z "$container_env" ] && return 2
    printf '%s\n' "$container_env"
}

# Echo the running provider pod's live env (KEY=VALUE lines); non-zero when
# kubectl / the pod / exec is unavailable.
_mcp_env_drift_k8s_pod_env() {
    command -v kubectl >/dev/null 2>&1 || return 2
    local namespace="bito-ai-architect"
    local pod
    pod=$(kubectl get pods -n "$namespace" -l app.kubernetes.io/component=provider \
            --field-selector=status.phase=Running \
            -o jsonpath='{.items[0].metadata.name}' 2>/dev/null) || return 2
    [ -z "$pod" ] && return 2
    local pod_env
    pod_env=$(kubectl exec -n "$namespace" "$pod" -- printenv 2>/dev/null) || return 2
    [ -z "$pod_env" ] && return 2
    printf '%s\n' "$pod_env"
}

# Compare host env against the running provider's frozen env for MCP-facing
# keys; a hand-edited .env-bitoarch diverges until `bitoarch restart --force`
# re-applies it. Returns 0 + $DRIFTED_KEYS on drift, 1 in sync, 2 inconclusive.
mcp_env_drift_check() {
    DRIFTED_KEYS=""
    local keys=(BITO_MCP_ACCESS_TOKEN MCP_OAUTH_ENABLED XMCP_SSO_ENABLED XMCP_SSO_DEFAULT_PROVIDER MCP_TRANSPORT)

    local container_env="" on_k8s=false
    if command -v is_kubernetes_deployment >/dev/null 2>&1 && is_kubernetes_deployment; then
        on_k8s=true
        container_env=$(_mcp_env_drift_k8s_pod_env) || return 2
    else
        container_env=$(_mcp_env_drift_docker_env) || return 2
    fi

    local drifted=()
    local key host_val cont_val present
    for key in "${keys[@]}"; do
        host_val="${!key:-}"
        present=$(printf '%s\n' "$container_env" | awk -F= -v k="$key" '$1==k {print "1"; exit}')
        # On K8s a key absent from pod env is delivered out-of-band (ConfigMap/
        # file), not drift; Docker injects all keys so this never trips there.
        if [ "$on_k8s" = "true" ] && [ -z "$present" ]; then
            continue
        fi
        cont_val=$(printf '%s\n' "$container_env" | awk -F= -v k="$key" '$1==k {sub("^"k"=",""); print; exit}')
        [ "$host_val" != "$cont_val" ] && drifted+=("$key")
    done

    if [ ${#drifted[@]} -eq 0 ]; then
        log_silent "mcp_env_drift_check: no drift"
        return 1
    fi
    DRIFTED_KEYS="${drifted[*]}"
    log_silent "mcp_env_drift_check: drift detected for ${DRIFTED_KEYS}"
    return 0
}

# Check if all required services are running
check_platform_services() {
    local required_services=("cis-mysql" "cis-provider")
    local missing_services=()
    
    for service in "${required_services[@]}"; do
        if ! check_service_running "$service"; then
            missing_services+=("$service")
        fi
    done
    
    if [ ${#missing_services[@]} -gt 0 ]; then
        print_error "Required services not running: ${missing_services[*]}"
        echo ""
        echo -e "Start services with: ${YELLOW}bitoarch start${NC}"
        return 1
    fi
    
    return 0
}


# Acquire an exclusive lock on <file>.lock, run a command, release on exit.
# Uses flock when available; falls back to mkdir-based spinlock on macOS.
_bitoarch_flock() {
    local target="$1"; shift
    local lockfile="${target}.lock"

    if command -v flock >/dev/null 2>&1; then
        (
            flock -x 200
            "$@"
        ) 200>"$lockfile"
    else
        local _tries=0
        while ! mkdir "$lockfile" 2>/dev/null; do
            _tries=$((_tries+1))
            if [ "$_tries" -ge 50 ]; then
                local _holder_pid=""
                [ -f "$lockfile/pid" ] && _holder_pid=$(cat "$lockfile/pid" 2>/dev/null)
                if [ -n "$_holder_pid" ] && kill -0 "$_holder_pid" 2>/dev/null; then
                    sleep 0.1
                    continue
                fi
                rm -rf "$lockfile"
                mkdir "$lockfile" 2>/dev/null || true
                break
            fi
            sleep 0.1
        done
        echo $$ > "$lockfile/pid" 2>/dev/null || true
        "$@"
        local _rc=$?
        rm -rf "$lockfile"
        return $_rc
    fi
}

# Export functions for use in other modules
export -f _bitoarch_flock
export -f load_env_config
export -f _mcp_env_drift_docker_env
export -f _mcp_env_drift_k8s_pod_env
export -f mcp_env_drift_check
export -f print_error
export -f print_success
export -f print_warning
export -f print_info
export -f print_header
export -f print_subheader
export -f require_command
export -f check_service_running
export -f check_platform_services
