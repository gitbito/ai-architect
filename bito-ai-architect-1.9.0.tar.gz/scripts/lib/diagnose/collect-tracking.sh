#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
# Diagnose / collect-tracking: redacted local analytics (tracking) events.
#
# cis-tracking always writes events to ${ANALYTICS_LOG_PATH}/analytics.log
# (JSON-lines, lumberjack-rotated as analytics-*.log.gz), independent of
# ENABLE_EXTERNAL_ANALYTICS -- so the local file exists whether events are
# also forwarded to Bito or kept purely on-prem (covers both tracking
# configurations). That path lives on the shared ai_architect_data volume,
# mounted by the manager, worker AND tracker containers -- NOT the host log
# bind-mount that collect-logs walks. So we read it by exec'ing into a
# running service container, mirroring the MySQL error-log capture in
# collect-logs.sh and the live filesystem check in diagnose.sh.
#
# Output: <out>/tracking/
#   README.txt      source + redaction note + summary (event count, event_type breakdown)
#   analytics.log   the newest BUNDLE_LOG_MAX_BYTES of the event stream, redacted --
#                   the live file, backfilled from the rotated .gz history ONLY when
#                   the live file is smaller than the cap. That keeps the captured
#                   window a single CONTIGUOUS timeline (rotated events sit directly
#                   before the live ones); a high-volume live file that already fills
#                   the cap stays recent-only rather than producing a gapped window.
#
# Every byte is piped through redact_stream (common.sh), which masks embedded
# tokens / JWTs / provider keys and secret-bearing kv-pairs in BOTH env form
# (api_key=...) and JSON form ("api_key":"...") -- so a stray secret in an
# event's free-form data map or tracking_meta is scrubbed. Analytics fields
# such as email and ip_address are intentionally kept intact for support triage.

if [ -n "${_DIAGNOSE_COLLECT_TRACKING_LOADED:-}" ]; then
    return 0
fi
_DIAGNOSE_COLLECT_TRACKING_LOADED=1

# Default mirrors .env-bitoarch.default; ANALYTICS_LOG_PATH is normally
# exported from the loaded env (the live filesystem check reads it too).
_TRACKING_DEFAULT_PATH="/opt/bito/ai-architect/data/analytics"

# Writes <out>/tracking/ -- a single contiguous, redacted analytics.log.
# Soft-skips (return 2) when no container exposes the log, so safe_step counts
# it as a warning and the rest of the bundle still ships.
collect_tracking() {
    local deployment_type="$1" out_dir="$2"
    local tdir="${out_dir}/tracking"
    local ap="${ANALYTICS_LOG_PATH:-$_TRACKING_DEFAULT_PATH}"

    bundle_init_file "${tdir}/README.txt" "Local tracking events (redacted)"
    {
        echo "Source (in container): ${ap}/analytics.log (+ rotated analytics-*.log.gz)"
        echo "Capture: newest ${BUNDLE_LOG_MAX_BYTES} bytes of the event stream from a running"
        echo "         service container (manager / worker / tracker) on the shared"
        echo "         ai_architect_data volume; rotated .gz history is backfilled only when"
        echo "         it stays contiguous with the live file (never a gapped window)."
        echo "Redaction: redact_stream -- embedded tokens / JWTs / secrets masked as"
        echo "           ***REDACTED***; event fields (email, ip_address, ...) kept intact."
    } >> "${tdir}/README.txt"

    if [ "$deployment_type" = "kubernetes" ]; then
        _collect_tracking_k8s "$tdir" "$ap"
    else
        _collect_tracking_docker "$tdir" "$ap"
    fi
    # Propagate the inner soft-skip / ok code for safe_step accounting.
    return $?
}

# Assemble the captured pieces into <tdir>/analytics.log and append the summary.
# back_tmp holds the older rotated backfill (may be empty), live_tmp the newest
# live tail; concatenated oldest-first they form one contiguous stream, then
# redacted in a single pass.
_tracking_write() {
    local live_tmp="$1" back_tmp="$2" source="$3" tdir="$4" ap="$5"
    local live="${tdir}/analytics.log"
    {
        echo "=== ${ap}/analytics.log (from ${source}; newest ${BUNDLE_LOG_MAX_BYTES} bytes of the"
        echo "=== event stream, rotated history backfilled when contiguous) ==="
        echo "=== captured at $(date '+%Y-%m-%d %H:%M:%S %Z') ==="
        echo ""
        cat "$back_tmp" "$live_tmp"
    } | redact_stream > "$live"
    _tracking_summary "$live" "$source" "${tdir}/README.txt"
}

# Compute the older-history backfill budget. Echoes the byte count to pull from
# the rotated history (0 when the live tail already fills the cap). Reading the
# captured live file's real size avoids the trailing-newline skew of $(...).
_tracking_backfill_bytes() {
    local live_tmp="$1" lbytes
    lbytes=$(wc -c < "$live_tmp" 2>/dev/null | tr -d ' ')
    [ -n "$lbytes" ] || lbytes=0
    if [ "$lbytes" -lt "$BUNDLE_LOG_MAX_BYTES" ]; then
        echo $(( BUNDLE_LOG_MAX_BYTES - lbytes ))
    else
        echo 0
    fi
}

# ─── Docker ──────────────────────────────────────────────────────────────
# Candidate order mirrors diagnose.sh's filesystem check (manager, worker):
# those containers are known to ship a shell and mount the shared volume.
# The tracker (minimal Go image) is the canonical writer but may be
# distroless, so it is tried last.
_collect_tracking_docker() {
    local tdir="$1" ap="$2"
    local container="" c live_tmp back_tmp remaining

    if ! bundle_have_docker; then
        echo "  docker daemon not reachable -- skipping tracking events." >> "${tdir}/README.txt"
        _bundle_step_warn "tracking" "docker unreachable"
        return 2
    fi

    live_tmp=$(mktemp); back_tmp=$(mktemp); : > "$back_tmp"

    # Select the first container exposing a non-empty live analytics.log,
    # capturing its newest-cap bytes straight into live_tmp. The redirection
    # truncates per attempt, so a failed/empty exec just leaves live_tmp empty
    # (-s) -- no separate $? check needed.
    for c in "$SERVICE_MANAGER_NAME" "$SERVICE_WORKER_NAME" "$SERVICE_TRACKER_NAME"; do
        [ -n "$c" ] || continue
        docker exec -e P="$ap" "$c" \
            sh -c 'tail -c '"$BUNDLE_LOG_MAX_BYTES"' "$P/analytics.log" 2>/dev/null' \
            > "$live_tmp" 2>/dev/null
        if [ -s "$live_tmp" ]; then container="$c"; break; fi
    done

    if [ -z "$container" ]; then
        rm -f "$live_tmp" "$back_tmp"
        echo "  analytics.log not reachable in any running service container --" >> "${tdir}/README.txt"
        echo "  the deployment may have no tracking events yet, or services are down." >> "${tdir}/README.txt"
        _bundle_step_warn "tracking" "analytics.log not reachable"
        return 2
    fi

    # Backfill from rotated history only while the window stays contiguous (live
    # file under the cap). gzip is decoded host-side -- guaranteed there, not in
    # a minimal service image; the glob expands oldest->newest so `tail -c` keeps
    # the rotated events immediately preceding the live file.
    remaining=$(_tracking_backfill_bytes "$live_tmp")
    if [ "$remaining" -gt 0 ]; then
        docker exec -e P="$ap" "$container" \
            sh -c 'cat "$P"/analytics-*.log.gz 2>/dev/null' 2>/dev/null \
            | gzip -dc 2>/dev/null | tail -c "$remaining" > "$back_tmp"
    fi

    _tracking_write "$live_tmp" "$back_tmp" "$container" "$tdir" "$ap"
    rm -f "$live_tmp" "$back_tmp"
    return 0
}

# ─── Kubernetes ──────────────────────────────────────────────────────────
# Same shared-volume logic as docker: resolve a pod by component label
# (manager, worker, tracker order) and exec the read. Path is inlined into
# the sh -c string because kubectl exec has no --env flag.
_collect_tracking_k8s() {
    local tdir="$1" ap="$2"
    local ns="$BUNDLE_K8S_NAMESPACE"
    local comp pod container="" live_tmp back_tmp remaining

    if ! bundle_have_kubectl; then
        echo "  kubectl/cluster not reachable -- skipping tracking events." >> "${tdir}/README.txt"
        _bundle_step_warn "tracking" "kubectl unreachable"
        return 2
    fi
    if ! kubectl get namespace "$ns" >/dev/null 2>&1; then
        echo "  namespace '${ns}' not found -- skipping tracking events." >> "${tdir}/README.txt"
        _bundle_step_warn "tracking" "namespace missing"
        return 2
    fi

    live_tmp=$(mktemp); back_tmp=$(mktemp); : > "$back_tmp"

    for comp in manager worker tracker; do
        pod=$(kubectl get pods -n "$ns" \
                -l "app.kubernetes.io/component=${comp}" \
                -o jsonpath='{.items[0].metadata.name}' 2>/dev/null)
        [ -z "$pod" ] && continue
        kubectl exec -n "$ns" "$pod" -- \
            sh -c "tail -c ${BUNDLE_LOG_MAX_BYTES} '${ap}/analytics.log' 2>/dev/null" \
            > "$live_tmp" 2>/dev/null
        if [ -s "$live_tmp" ]; then container="$pod"; break; fi
    done

    if [ -z "$container" ]; then
        rm -f "$live_tmp" "$back_tmp"
        echo "  analytics.log not reachable in any service pod --" >> "${tdir}/README.txt"
        echo "  the deployment may have no tracking events yet, or pods are down." >> "${tdir}/README.txt"
        _bundle_step_warn "tracking" "analytics.log not reachable"
        return 2
    fi

    remaining=$(_tracking_backfill_bytes "$live_tmp")
    if [ "$remaining" -gt 0 ]; then
        kubectl exec -n "$ns" "$container" -- \
            sh -c "cat '${ap}'/analytics-*.log.gz 2>/dev/null" 2>/dev/null \
            | gzip -dc 2>/dev/null | tail -c "$remaining" > "$back_tmp"
    fi

    _tracking_write "$live_tmp" "$back_tmp" "$container" "$tdir" "$ap"
    rm -f "$live_tmp" "$back_tmp"
    return 0
}

# Append a best-effort summary to README.txt: which container the events came
# from, the captured event-line count, and (when jq is available) an event_type
# breakdown. Reads the already-redacted analytics.log.
_tracking_summary() {
    local live="$1" source="$2" readme="$3"
    bundle_log_section "$readme" "Summary"
    echo "  Captured from: ${source}" >> "$readme"

    local lines
    lines=$(grep -c '^{' "$live" 2>/dev/null) || true
    [ -n "$lines" ] || lines=0
    echo "  Event lines captured: ${lines}" >> "$readme"

    if command -v jq >/dev/null 2>&1; then
        echo "  event_type breakdown (top 20):" >> "$readme"
        grep '^{' "$live" 2>/dev/null \
            | jq -r '.event_type // "unknown"' 2>/dev/null \
            | sort | uniq -c | sort -rn | head -20 \
            | sed 's/^/    /' >> "$readme" || true
    fi
}
