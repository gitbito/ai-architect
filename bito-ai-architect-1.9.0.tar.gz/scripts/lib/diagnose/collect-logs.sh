#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
# Bito's AI Architect CLI - Diagnose / collect-logs
# Per-service log capture, two sources:
#
#   1. Container runtime logs   -- `docker logs --tail N` / `kubectl logs --tail=N`
#                                   captured as logs/<service>.container.log
#   2. Application log files    -- on-disk logs under $BITOARCH_LOG_DIR (set by
#                                   path-manager.sh), walked into
#                                   logs/app-logs/<component>/<file> (<= N newest
#                                   per component, .gz decompressed, redacted)
#
# Both are size-capped to BUNDLE_LOG_MAX_BYTES (default 5 MB). MySQL is
# treated specially -- error log is fetched from the running container.
#
# Related: scripts/unified-log-manager.sh ships capture_docker_logs_to_gz
# (and capture_k8s_logs_to_gz) which wrap the same `docker logs --tail` /
# `kubectl logs --tail` shape but write rotated .gz archives for runtime
# log retention. We intentionally don't reuse them here -- the bundle wants
# uncompressed text inline so support can read it without an extra unzip
# step, and the size cap differs (5 MB vs unbounded). Keep the two paths
# aware of each other when changing log-capture invariants.

if [ -n "${_DIAGNOSE_COLLECT_LOGS_LOADED:-}" ]; then
    return 0
fi
_DIAGNOSE_COLLECT_LOGS_LOADED=1

# Writes <out>/logs/ with last N lines per service plus the mysql error log.
# Each file is capped to BUNDLE_LOG_MAX_BYTES.
collect_logs() {
    local deployment_type="$1" out_dir="$2"
    local logs_dir="${out_dir}/logs"

    mkdir -p "$logs_dir" 2>/dev/null || true
    {
        echo "Per-service logs (last ${BUNDLE_LOG_TAIL_LINES} lines, max ${BUNDLE_LOG_MAX_BYTES} bytes/file)"
        echo "Generated: $(date '+%Y-%m-%d %H:%M:%S %Z')"
    } > "${logs_dir}/README.txt"

    if [ "$deployment_type" = "kubernetes" ]; then
        _collect_logs_k8s "$logs_dir"
    else
        _collect_logs_docker "$logs_dir"
    fi
    _collect_app_logs    "$logs_dir"
    _collect_events "$logs_dir" "$deployment_type"
    return 0
}

# In-place tail-truncate to BUNDLE_LOG_MAX_BYTES. Tail (not head) so recent
# activity is preserved.
_cap_file_size() {
    local file="$1"
    [ -f "$file" ] || return 0
    local size
    size=$(wc -c < "$file" 2>/dev/null | tr -d ' ')
    [ -n "$size" ] && [ "$size" -le "$BUNDLE_LOG_MAX_BYTES" ] && return 0
    tail -c "$BUNDLE_LOG_MAX_BYTES" "$file" > "${file}.tmp" 2>/dev/null && \
        mv -f "${file}.tmp" "$file"
    echo "[truncated to last ${BUNDLE_LOG_MAX_BYTES} bytes]" >> "$file"
}

# ─── Docker container logs ───────────────────────────────────────────────
_collect_logs_docker() {
    local logs_dir="$1"

    if ! bundle_have_docker; then
        echo "docker daemon not reachable -- skipping container logs." >> "${logs_dir}/README.txt"
        return 0
    fi

    # Container logs routinely include `Authorization: Bearer ...`, provider
    # tokens echoed in failed HTTP traces, and request bodies in stack traces.
    # Pipe through redact_stream so the bundle stays safe to share externally.
    local svc target_file
    for svc in "${BITOARCH_LIFECYCLE_SERVICES[@]}"; do
        target_file="${logs_dir}/${svc}.container.log"
        {
            echo "=== docker logs --tail ${BUNDLE_LOG_TAIL_LINES} ${svc} ==="
            echo "=== captured at $(date '+%Y-%m-%d %H:%M:%S %Z') ==="
            echo ""
            { docker logs --tail "$BUNDLE_LOG_TAIL_LINES" "$svc" 2>&1 \
                || echo "[docker logs failed for ${svc} -- container may not exist]"; } \
                | redact_stream
        } > "$target_file"
        _cap_file_size "$target_file"
    done

    # MySQL error log -- fetched from inside the container; default path
    # varies across image variants so we try both. Redacted in case mysqld
    # logged a connection string or env-derived password on startup failure.
    local mysql_err="${logs_dir}/mysql.error.log"
    {
        echo "=== MySQL error log (from inside ${SERVICE_MYSQL_NAME}) ==="
        echo ""
        { docker exec "$SERVICE_MYSQL_NAME" sh -c \
            'tail -c '"$BUNDLE_LOG_MAX_BYTES"' /var/log/mysql/error.log 2>/dev/null \
             || tail -c '"$BUNDLE_LOG_MAX_BYTES"' /var/lib/mysql/*.err 2>/dev/null \
             || echo "[no mysql error log found in known paths]"' 2>&1 \
            || echo "[docker exec into ${SERVICE_MYSQL_NAME} failed]"; } \
            | redact_stream
    } > "$mysql_err"
    _cap_file_size "$mysql_err"
}

# ─── Kubernetes pod logs ─────────────────────────────────────────────────
_collect_logs_k8s() {
    local logs_dir="$1"
    local ns="$BUNDLE_K8S_NAMESPACE"

    if ! bundle_have_kubectl; then
        echo "kubectl/cluster unreachable -- skipping pod logs." >> "${logs_dir}/README.txt"
        return 0
    fi
    if ! kubectl get namespace "$ns" >/dev/null 2>&1; then
        echo "Namespace '$ns' not found -- skipping pod logs." >> "${logs_dir}/README.txt"
        return 0
    fi

    # See _collect_logs_docker for the redaction rationale -- same threat
    # model applies to kubectl-sourced container logs.
    local svc short_name pod target_file
    for svc in "${BITOARCH_LIFECYCLE_SERVICES[@]}"; do
        # K8s selects by short label component; deployment-name selector is
        # the fallback for single-replica deployments.
        short_name="${svc#ai-architect-}"
        pod=$(kubectl get pods -n "$ns" \
                -l "app.kubernetes.io/component=${short_name}" \
                -o jsonpath='{.items[0].metadata.name}' 2>/dev/null)
        [ -z "$pod" ] && pod=$(kubectl get pods -n "$ns" \
                -l "app=${svc}" \
                -o jsonpath='{.items[0].metadata.name}' 2>/dev/null)

        target_file="${logs_dir}/${svc}.container.log"
        {
            echo "=== kubectl logs ${pod:-<not-found>} -n ${ns} --tail=${BUNDLE_LOG_TAIL_LINES} ==="
            echo "=== captured at $(date '+%Y-%m-%d %H:%M:%S %Z') ==="
            echo ""
            if [ -n "$pod" ]; then
                {
                    kubectl logs "$pod" -n "$ns" --tail="$BUNDLE_LOG_TAIL_LINES" 2>&1
                    # Also grab pre-restart logs -- often the most diagnostic.
                    echo ""
                    echo "=== previous container instance (if any) ==="
                    kubectl logs "$pod" -n "$ns" --previous --tail="$BUNDLE_LOG_TAIL_LINES" 2>&1 \
                        || echo "[no previous instance]"
                } | redact_stream
            else
                echo "[no pod found for service ${svc}]"
            fi
        } > "$target_file"
        _cap_file_size "$target_file"
    done

    local mysql_err="${logs_dir}/mysql.error.log"
    local mysql_pod
    mysql_pod=$(kubectl get pods -n "$ns" \
        -l "app.kubernetes.io/component=mysql" \
        -o jsonpath='{.items[0].metadata.name}' 2>/dev/null)
    {
        echo "=== MySQL error log (from inside ${mysql_pod:-<not-found>}) ==="
        echo ""
        if [ -n "$mysql_pod" ]; then
            kubectl exec -n "$ns" "$mysql_pod" -- sh -c \
                'tail -c '"$BUNDLE_LOG_MAX_BYTES"' /var/log/mysql/error.log 2>/dev/null \
                 || tail -c '"$BUNDLE_LOG_MAX_BYTES"' /var/lib/mysql/*.err 2>/dev/null \
                 || echo "[no mysql error log found in known paths]"' 2>&1 \
                | redact_stream
        else
            echo "[mysql pod not found]"
        fi
    } > "$mysql_err"
    _cap_file_size "$mysql_err"
}

# ─── App log files from BITOARCH_LOG_DIR ─────────────────────────────────
# Walks the on-disk log tree under $BITOARCH_LOG_DIR and copies what's there
# into the bundle:
#   logs/app-logs/<file>             flat root logs (setup.log, ...)
#   logs/app-logs/<component>/<file> per service dir (mysql/, temporal/, cis-*/)
# Every file is tail-capped (BUNDLE_LOG_MAX_BYTES) and redacted; .gz rotations
# are decompressed first so they can be scrubbed (never copied raw). At most
# BUNDLE_APP_LOG_MAX_FILES (newest) per component; setup.log and upgrade.log are
# pinned at the root.
_collect_app_logs() {
    local logs_dir="$1"
    local base_dir="${BITOARCH_LOG_DIR:-}"

    if [ -z "$base_dir" ] || [ ! -d "$base_dir" ]; then
        echo "BITOARCH_LOG_DIR not set or missing; skipping app log file copy." \
            >> "${logs_dir}/README.txt"
        return 0
    fi
    base_dir="${base_dir%/}"

    local app_out="${logs_dir}/app-logs"
    local readme="${logs_dir}/README.txt"
    bundle_log_section "$readme" \
        "App log files (from ${base_dir}; <= ${BUNDLE_APP_LOG_MAX_FILES:-3} newest per component)"

    # 1) Flat root logs. setup.log and upgrade.log are pinned so they're always
    #    exported, even when newer rotated logs (e.g. mcp-*.log) would otherwise
    #    push them out of the newest-N window. upgrade.log carries high
    #    diagnostic value for the upgrade-failure cases bundles are run for.
    _collect_component_logs "$base_dir" "$app_out" "setup.log upgrade.log" "$readme" "(root)"

    # 2) Each immediate subdirectory is a component, captured by its real
    #    on-disk name (mysql/, temporal/, cis-*/).
    local sub comp
    for sub in "$base_dir"/*/; do
        [ -d "$sub" ] || continue
        comp="$(basename "$sub")"
        _collect_component_logs "$sub" "${app_out}/${comp}" "" "$readme" "$comp"
    done
    return 0
}

# Copy the newest <= BUNDLE_APP_LOG_MAX_FILES log files (*.log*/*.err*/*.gz) from
# the top level of src_dir into out_dir, each tail-capped and redacted. .gz files
# are decompressed and stored as text (suffix dropped), never copied raw.
# `pins` is a space-separated list of basenames always kept (each occupies a
# slot) -- guarantees setup.log / upgrade.log survive newer-log eviction.
_collect_component_logs() {
    local src_dir="$1" out_dir="$2" pins="$3" readme="$4" label="$5"
    local max="${BUNDLE_APP_LOG_MAX_FILES:-3}"
    src_dir="${src_dir%/}"

    # Ordered candidates: pinned files first (each kept, occupying a slot), then
    # the rest newest-first. `pinned` is kept as a space-delimited set for the
    # membership test below. ls -1t is the portable mtime sort (find -printf is
    # GNU-only); it lists basenames within src_dir, never recursing.
    local ordered=() pinned=" " p
    for p in $pins; do
        [ -f "${src_dir}/${p}" ] || continue
        ordered+=("$p"); pinned="${pinned}${p} "
    done
    local f
    while IFS= read -r f; do
        [ -n "$f" ] || continue
        case "$f" in
            # Real installs rotate service logs as <svc>.<timestamp>.gz (no
            # ".log" token), so plain *.gz must match too -- not only *.log*.
            *.log|*.log.*|*.err|*.err.*|*.gz) ;;
            *) continue ;;
        esac
        [ -f "${src_dir}/${f}" ] || continue
        case "$pinned" in *" $f "*) continue ;; esac
        ordered+=("$f")
    # shellcheck disable=SC2012  # ls -1t is the portable mtime sort; find -printf is GNU-only
    done < <(cd "$src_dir" 2>/dev/null && ls -1t 2>/dev/null)

    [ "${#ordered[@]}" -gt 0 ] || return 0
    mkdir -p "$out_dir" 2>/dev/null || true

    local count=0 src dst note
    for f in "${ordered[@]}"; do
        [ "$count" -lt "$max" ] || break
        count=$((count + 1))
        src="${src_dir}/${f}"
        case "$f" in
            *.gz)
                dst="${out_dir}/${f}.txt"; note="${f}.txt (gunzipped)"
                {
                    echo "=== source: ${src} (gunzipped) ==="
                    echo "=== captured at $(date '+%Y-%m-%d %H:%M:%S %Z') ==="
                    echo ""
                    gzip -dc "$src" 2>/dev/null \
                        | tail -c "$BUNDLE_LOG_MAX_BYTES" | redact_stream
                } > "$dst"
                ;;
            *)
                dst="${out_dir}/${f}"; note="${f}"
                {
                    echo "=== source: ${src} ==="
                    echo "=== captured at $(date '+%Y-%m-%d %H:%M:%S %Z') ==="
                    echo ""
                    # App logs commonly include request payloads with bearer
                    # tokens, stack traces with credentials, env-var dumps on
                    # startup. Redact before writing to the bundle.
                    tail -c "$BUNDLE_LOG_MAX_BYTES" "$src" 2>/dev/null \
                        | redact_stream
                } > "$dst"
                ;;
        esac
        echo "  ${label}/${note}" >> "$readme"
    done
    return 0
}

# ─── Event SQL dumps ─────────────────────────────────────────────────────
# Writes index_log + repo_metadata + counts as .tsv under logs/events/.
# Read-only; skipped silently when MYSQL_ROOT_PASSWORD is not set.
_collect_events() {
    local logs_dir="$1" deployment_type="$2"
    local out_dir="${logs_dir}/events"
    local pass="${MYSQL_ROOT_PASSWORD:-}"

    # Mark explicitly that events were skipped, not "this install had no
    # events". Without this, support sees no logs/events/ directory and
    # has no signal whether creds were absent, mysql was down, or the
    # install genuinely has zero events.
    if [ -z "$pass" ]; then
        {
            echo ""
            echo "── Event SQL dumps (logs/events/) ──"
            echo "  Skipped: MYSQL_ROOT_PASSWORD not set in env."
        } >> "${logs_dir}/README.txt"
        return 0
    fi

    mkdir -p "$out_dir" 2>/dev/null || true
    local db="${MYSQL_DATABASE:-code_intelligence}"
    local row_limit="${BITOARCH_DIAG_SQL_ROW_LIMIT:-100000}"
    local exec_fn
    if [ "$deployment_type" = "kubernetes" ]; then
        bundle_have_kubectl || return 0
        exec_fn=_events_sql_k8s
    else
        bundle_have_docker || return 0
        docker inspect "$SERVICE_MYSQL_NAME" >/dev/null 2>&1 || return 0
        exec_fn=_events_sql_docker
    fi

    {
        echo "Event SQL dumps"
        echo "Generated: $(date '+%Y-%m-%d %H:%M:%S %Z')"
        echo "Database:  ${db}"
        echo "Row limit: ${row_limit}"
        echo ""
        echo "Files:"
        echo "  index-log.tsv       raw index_log rows (newest first)"
        echo "  counts.txt          event_type/status row counts"
        echo "  repo-metadata.tsv   configured repos"
    } > "${out_dir}/README.txt"

    # All SQL output streams through redact_stream because index_log.event_data
    # is JSON that may embed bito_access_key and other credentials.
    #
    # Each pipeline runs under pipefail with stderr captured separately to a
    # .err sibling. Without pipefail the shell's $? is redact_stream's exit
    # code (always 0), so a failed mysql query would silently land its error
    # text in the .tsv as if it were data. On failure the .tsv is renamed to
    # .tsv.partial so support can tell at-a-glance which dumps completed.
    local prev_pipefail=$(shopt -po pipefail || echo "")
    set -o pipefail

    # 1) Full index_log dump, newest first.
    if ! "$exec_fn" "$pass" "$db" "
        SELECT id, workspace_id, repo_id, request_id, event_type, status, created_at, event_data
        FROM index_log
        ORDER BY id DESC
        LIMIT ${row_limit};
    " 2>"${out_dir}/index-log.err" \
        | redact_stream > "${out_dir}/index-log.tsv"; then
        mv "${out_dir}/index-log.tsv" "${out_dir}/index-log.tsv.partial" 2>/dev/null || true
    else
        # Drop the .err file when empty so support doesn't chase a non-issue.
        [ -s "${out_dir}/index-log.err" ] || rm -f "${out_dir}/index-log.err"
    fi

    # 2) Aggregate counts.
    if ! {
        echo "── counts by event_type ──"
        "$exec_fn" "$pass" "$db" "
            SELECT event_type, status, COUNT(*) AS cnt
            FROM index_log GROUP BY event_type, status ORDER BY cnt DESC;
        "
        echo ""
        echo "── counts by status ──"
        "$exec_fn" "$pass" "$db" "
            SELECT status, COUNT(*) AS cnt FROM index_log GROUP BY status;
        "
        echo ""
        echo "── distinct repo_ids in index_log ──"
        "$exec_fn" "$pass" "$db" "
            SELECT COUNT(DISTINCT repo_id) AS distinct_repos_with_events FROM index_log;
        "
        echo ""
        echo "── latest request_id per workspace ──"
        "$exec_fn" "$pass" "$db" "
            SELECT workspace_id, request_id, MAX(created_at) AS last_event
            FROM index_log GROUP BY workspace_id, request_id
            ORDER BY last_event DESC LIMIT 20;
        "
    } 2>"${out_dir}/counts.err" \
        | redact_stream > "${out_dir}/counts.txt"; then
        mv "${out_dir}/counts.txt" "${out_dir}/counts.txt.partial" 2>/dev/null || true
    else
        [ -s "${out_dir}/counts.err" ] || rm -f "${out_dir}/counts.err"
    fi

    # 3) repo_metadata: source of truth for "configured repos".
    if ! "$exec_fn" "$pass" "$db" "
        SELECT id, repo_name, project_id, provider, workspace_id, index_state,
               last_commit_id, repo_size, created, updated, last_sync
        FROM repo_metadata
        ORDER BY workspace_id, repo_name;
    " 2>"${out_dir}/repo-metadata.err" \
        | redact_stream > "${out_dir}/repo-metadata.tsv"; then
        mv "${out_dir}/repo-metadata.tsv" "${out_dir}/repo-metadata.tsv.partial" 2>/dev/null || true
    else
        [ -s "${out_dir}/repo-metadata.err" ] || rm -f "${out_dir}/repo-metadata.err"
    fi

    # Restore the caller's pipefail state.
    eval "$prev_pipefail"

    echo "" >> "${logs_dir}/README.txt"
    echo "── Event SQL dumps (logs/events/) ──" >> "${logs_dir}/README.txt"
    echo "  See logs/events/README.txt for file index." >> "${logs_dir}/README.txt"
}

# -B keeps tab-separated header (useful for .tsv); MYSQL_PWD suppresses
# stderr warning. Reads root only -- cross-table access.
_events_sql_docker() {
    local pass="$1" db="$2" sql="$3"
    docker exec -i -e MYSQL_PWD="$pass" "$SERVICE_MYSQL_NAME" \
        mysql -u root -B -e "$sql" "$db" 2>/dev/null
}

_events_sql_k8s() {
    local pass="$1" db="$2" sql="$3"
    local pod
    pod=$(kubectl get pods -n "$BUNDLE_K8S_NAMESPACE" \
        -l "app.kubernetes.io/component=mysql" \
        -o jsonpath='{.items[0].metadata.name}' 2>/dev/null)
    [ -z "$pod" ] && return 1
    # kubectl exec has no --env flag; pass MYSQL_PWD via in-container env prefix.
    kubectl exec -n "$BUNDLE_K8S_NAMESPACE" "$pod" -- \
        env MYSQL_PWD="$pass" mysql -u root -B -e "$sql" "$db" 2>/dev/null
}
