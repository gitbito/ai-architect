#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
# Diagnose / collect-network: appends connectivity sections (health endpoints,
# svc-to-svc, MCP, DNS) to the merged services-overview.txt.

if [ -n "${_DIAGNOSE_COLLECT_NETWORK_LOADED:-}" ]; then
    return 0
fi
_DIAGNOSE_COLLECT_NETWORK_LOADED=1

# Appends four connectivity sections to services-overview.txt. Creates the
# file with a header if collect_services was skipped.
collect_network() {
    local deployment_type="$1" out_dir="$2"
    local target="${out_dir}/services-overview.txt"

    if [ ! -f "$target" ]; then
        bundle_init_file "$target" "Services Overview"
    fi

    _collect_net_health      "$target"
    _collect_net_svc_to_svc  "$target" "$deployment_type"
    _collect_net_mcp         "$target"
    _collect_net_dns         "$target"
    return 0
}

# Per-service /health probe from the host.
_collect_net_health() {
    local target="$1"
    bundle_log_section "$target" "Health endpoints (from host)"

    local pairs=(
        "Provider|${PROVIDER_URL:-}"
        "Config|${CONFIG_URL:-}"
        "Manager|${MANAGER_URL:-}"
    )
    local entry name url body
    for entry in "${pairs[@]}"; do
        IFS='|' read -r name url <<< "$entry"
        if [ -z "$url" ]; then
            printf "  %-10s %s\n" "$name:" "URL env not set" >> "$target"
            continue
        fi
        body=$(curl -sS --max-time 5 --connect-timeout 3 -w '\n[HTTP %{http_code}, %{time_total}s]' "${url}/health" 2>&1 | head -c 400)
        printf "  %-10s URL=%s\n" "$name:" "${url}/health" >> "$target"
        echo "$body" | sed 's/^/    /' >> "$target"
    done
}

# Service-to-service probes. Internal ports come from CIS_*_PORT env (set by
# env-generator.sh); defaults match the canonical docker-compose deployment.
_collect_net_svc_to_svc() {
    local target="$1" deployment_type="$2"
    bundle_log_section "$target" "Service-to-service reachability"

    local cfg_port="${CIS_CONFIG_PORT:-8081}"
    local mgr_port="${CIS_MANAGER_PORT:-9090}"

    {
        echo "  Probes from each service container/pod to its peers."
        echo "  Internal ports: config=${cfg_port}, manager=${mgr_port}"
        echo "  Probe tool falls back: curl -> wget -> nc"
    } >> "$target"

    # Edges: "<from>|<to-label>|<host>|<port>|<is_http>"
    local edges=(
        "${SERVICE_MANAGER_NAME}|config|${SERVICE_CONFIG_NAME}|${cfg_port}|1"
        "${SERVICE_WORKER_NAME}|manager|${SERVICE_MANAGER_NAME}|${mgr_port}|1"
    )

    local edge from to_label host port is_http result
    for edge in "${edges[@]}"; do
        IFS='|' read -r from to_label host port is_http <<< "$edge"
        result=$(_net_probe_edge "$deployment_type" "$from" "$host" "$port" "$is_http")
        printf "  %-25s -> %-10s %s\n" "$from" "$to_label" "$result" >> "$target"
    done
}

# Probe one edge from inside a container. Tries curl -> wget -> nc.
_net_probe_edge() {
    local deployment_type="$1" from="$2" host="$3" port="$4" is_http="$5"
    local url="http://${host}:${port}/health"
    local probe
    if [ "$is_http" = "1" ]; then
        probe="if which curl >/dev/null 2>&1; then \
                 curl -sS --max-time 3 -o /dev/null -w 'HTTP %{http_code} (curl, %{time_total}s)' '${url}'; \
               elif which wget >/dev/null 2>&1; then \
                 wget -qO- --tries=1 --timeout=3 '${url}' >/dev/null \
                   && echo 'HTTP OK (wget)' || echo 'HTTP FAIL (wget)'; \
               elif which nc >/dev/null 2>&1; then \
                 nc -z -w3 ${host} ${port} >/dev/null 2>&1 \
                   && echo 'TCP_OK (nc, no HTTP probe)' || echo 'TCP_FAIL (nc)'; \
               else echo '<no probe tool>'; fi"
    else
        probe="if which nc >/dev/null 2>&1; then \
                 nc -z -w3 ${host} ${port} >/dev/null 2>&1 \
                   && echo 'TCP_OK (nc)' || echo 'TCP_FAIL (nc)'; \
               else echo '<no nc, cannot probe TCP>'; fi"
    fi
    _net_exec "$deployment_type" "$from" "$probe" 2>&1 | tr -d '\r' | head -1
}

# Run a command inside a service container/pod.
_net_exec() {
    local deployment_type="$1" svc="$2" cmd="$3"
    if [ "$deployment_type" = "kubernetes" ]; then
        local short_name podinfo pod container
        short_name="${svc#ai-architect-}"
        podinfo=$(kubectl get pods -n "$BUNDLE_K8S_NAMESPACE" \
            -l "app.kubernetes.io/component=${short_name}" \
            -o jsonpath='{.items[0].metadata.name} {.items[0].spec.containers[0].name}' 2>/dev/null)
        read -r pod container <<< "$podinfo"
        [ -z "$pod" ] && { echo "[no pod for ${svc}]"; return 1; }
        if [ -n "$container" ]; then
            kubectl exec -n "$BUNDLE_K8S_NAMESPACE" "$pod" -c "$container" -- sh -c "$cmd" 2>&1
        else
            kubectl exec -n "$BUNDLE_K8S_NAMESPACE" "$pod" -- sh -c "$cmd" 2>&1
        fi
    else
        docker exec "$svc" sh -c "$cmd" 2>&1 \
            || echo "[exec into ${svc} failed]"
    fi
}

# MCP endpoint probe -- reuses probe_mcp_endpoint from diagnose.sh.
_collect_net_mcp() {
    local target="$1"
    bundle_log_section "$target" "MCP endpoint probe"
    if [ -z "${PROVIDER_URL:-}" ] || [ -z "${PROVIDER_TOKEN:-}" ]; then
        echo "  PROVIDER_URL or PROVIDER_TOKEN not set -- skipped." >> "$target"
        return 0
    fi
    local result
    result=$(probe_mcp_endpoint "$PROVIDER_URL" "$PROVIDER_TOKEN")
    {
        echo "  URL:     ${PROVIDER_URL}/mcp"
        echo "  Result:  ${result}"
    } >> "$target"
}

# DNS resolution -- explicit <unresolved> on NXDOMAIN rather than blank.
_collect_net_dns() {
    local target="$1"
    bundle_log_section "$target" "DNS resolution"
    {
        echo "  Resolving names from host. NXDOMAIN / timeout reported as <unresolved>."
        local names=("alpha.bito.ai" "docker.io")
        local n ip
        for n in "${names[@]}"; do
            ip=$(_resolve_one "$n")
            printf "  %-30s -> %s\n" "$n" "${ip:-<unresolved>}"
        done
    } >> "$target"
}

# Resolve one name. Falls back: host -> getent -> dscacheutil -> nslookup.
_resolve_one() {
    local n="$1" out=""
    if command -v host >/dev/null 2>&1; then
        out=$(host -W 2 "$n" 2>/dev/null | awk '/has address|has IPv6 address/{print $NF; exit}')
    fi
    if [ -z "$out" ] && command -v getent >/dev/null 2>&1; then
        out=$(getent hosts "$n" 2>/dev/null | awk 'NR==1{print $1}')
    fi
    if [ -z "$out" ] && command -v dscacheutil >/dev/null 2>&1; then
        out=$(dscacheutil -q host -a name "$n" 2>/dev/null | awk '/^ip_address:/{print $2; exit}')
    fi
    if [ -z "$out" ] && command -v nslookup >/dev/null 2>&1; then
        out=$(nslookup "$n" 2>/dev/null | awk '/^Address: /{print $2; exit}')
    fi
    echo "$out"
}
