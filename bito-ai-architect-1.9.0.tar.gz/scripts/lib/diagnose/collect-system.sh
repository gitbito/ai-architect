#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
# Bito's AI Architect CLI - Diagnose / collect-system
# Captures host system info: OS, kernel, CPU, memory, disk, runtime versions.
# Output: <out>/system-info.txt
#
# Cross-platform (macOS/Linux). Each probe is fail-soft -- a missing tool
# writes "<n/a>" and the function continues to the next section.

if [ -n "${_DIAGNOSE_COLLECT_SYSTEM_LOADED:-}" ]; then
    return 0
fi
_DIAGNOSE_COLLECT_SYSTEM_LOADED=1

# Writes <out>/system-info.txt. K8s + Helm sections only in kubernetes mode.
collect_system() {
    local deployment_type="$1" out_dir="$2"
    local file="${out_dir}/system-info.txt"

    bundle_init_file "$file" "System Info"

    # ── OS / kernel ─────────────────────────────────────────────────────
    bundle_log_section "$file" "OS"
    {
        echo "Uname:    $(uname -a 2>/dev/null || echo n/a)"
        if [ -f /etc/os-release ]; then
            echo "Distro:"
            sed -n 's/^/  /p' /etc/os-release
        elif command -v sw_vers >/dev/null 2>&1; then
            echo "macOS:    $(sw_vers -productVersion 2>/dev/null)"
            echo "Build:    $(sw_vers -buildVersion 2>/dev/null)"
        else
            echo "Distro:   n/a"
        fi
        echo "Uptime:   $(uptime 2>/dev/null || echo n/a)"
    } >> "$file"

    # ── CPU ─────────────────────────────────────────────────────────────
    bundle_log_section "$file" "CPU"
    {
        if [ -r /proc/cpuinfo ]; then
            local cores model
            cores=$(grep -c '^processor' /proc/cpuinfo 2>/dev/null)
            model=$(grep -m1 'model name' /proc/cpuinfo 2>/dev/null | cut -d: -f2- | sed 's/^ *//')
            echo "Cores:    ${cores:-n/a}"
            echo "Model:    ${model:-n/a}"
        elif command -v sysctl >/dev/null 2>&1; then
            echo "Cores:    $(sysctl -n hw.ncpu 2>/dev/null || echo n/a)"
            echo "Model:    $(sysctl -n machdep.cpu.brand_string 2>/dev/null || echo n/a)"
        else
            echo "CPU info unavailable on this host."
        fi
    } >> "$file"

    # ── Memory ──────────────────────────────────────────────────────────
    bundle_log_section "$file" "Memory"
    {
        if command -v free >/dev/null 2>&1; then
            free -h 2>/dev/null
        elif command -v vm_stat >/dev/null 2>&1; then
            # macOS: convert vm_stat page counts to GB.
            local page_size pages_free pages_active pages_inactive pages_wired total_gb free_gb
            page_size=$(sysctl -n hw.pagesize 2>/dev/null || echo 4096)
            pages_free=$(vm_stat | awk '/Pages free/ {gsub("\\.","",$3); print $3}')
            pages_active=$(vm_stat | awk '/Pages active/ {gsub("\\.","",$3); print $3}')
            pages_inactive=$(vm_stat | awk '/Pages inactive/ {gsub("\\.","",$3); print $3}')
            pages_wired=$(vm_stat | awk '/Pages wired down/ {gsub("\\.","",$4); print $4}')
            total_gb=$(sysctl -n hw.memsize 2>/dev/null | awk '{printf "%.1f", $1/1024/1024/1024}')
            free_gb=$(awk -v p="${pages_free:-0}" -v sz="$page_size" 'BEGIN{printf "%.1f", p*sz/1024/1024/1024}')
            echo "Total:    ${total_gb} GB"
            echo "Free:     ${free_gb} GB"
            echo "(macOS vm_stat: free=${pages_free:-?} active=${pages_active:-?} inactive=${pages_inactive:-?} wired=${pages_wired:-?})"
        else
            echo "Memory info unavailable on this host."
        fi
    } >> "$file"

    # ── Disk ────────────────────────────────────────────────────────────
    bundle_log_section "$file" "Disk"
    {
        if command -v df >/dev/null 2>&1; then
            df -h 2>/dev/null | head -30
        else
            echo "df not available."
        fi
        if [ -n "${STORAGE_PATH:-}" ] && [ -d "$STORAGE_PATH" ]; then
            echo ""
            echo "STORAGE_PATH (${STORAGE_PATH}):"
            df -h "$STORAGE_PATH" 2>/dev/null || echo "  df failed on STORAGE_PATH"
            if command -v du >/dev/null 2>&1; then
                du -sh "$STORAGE_PATH" 2>/dev/null | sed 's/^/  total: /'
            fi
        fi
    } >> "$file"

    # ── Docker runtime ──────────────────────────────────────────────────
    bundle_log_section "$file" "Docker runtime"
    {
        if command -v docker >/dev/null 2>&1; then
            echo "Client/server version:"
            docker version --format '  Client: {{.Client.Version}} ({{.Client.Os}}/{{.Client.Arch}})
  Server: {{.Server.Version}} ({{.Server.Os}}/{{.Server.Arch}})' 2>/dev/null \
                || docker --version 2>/dev/null \
                || echo "  docker present but `docker version` failed (daemon down?)"
            echo ""
            if docker compose version >/dev/null 2>&1; then
                echo "Compose:  $(docker compose version --short 2>/dev/null) (plugin)"
            elif command -v docker-compose >/dev/null 2>&1; then
                echo "Compose:  $(docker-compose --version 2>/dev/null) (standalone)"
            else
                echo "Compose:  not found"
            fi
            echo ""
            echo "Engine info (summary):"
            docker info --format '  Containers:      {{.Containers}} ({{.ContainersRunning}} running, {{.ContainersStopped}} stopped)
  Images:          {{.Images}}
  Storage driver:  {{.Driver}}
  Cgroup driver:   {{.CgroupDriver}}
  Kernel version:  {{.KernelVersion}}
  Operating system:{{.OperatingSystem}}
  Total memory:    {{.MemTotal}} bytes' 2>/dev/null || echo "  docker info unavailable"
        else
            echo "docker not installed."
        fi
    } >> "$file"

    # ── Kubernetes + Helm (k8s only) ────────────────────────────────────
    if [ "$deployment_type" = "kubernetes" ]; then
        bundle_log_section "$file" "Kubernetes"
        {
            if command -v kubectl >/dev/null 2>&1; then
                echo "Client/server version:"
                kubectl version -o yaml 2>/dev/null | sed 's/^/  /' \
                    || echo "  kubectl version failed"
                echo ""
                echo "Current context:"
                kubectl config current-context 2>/dev/null | sed 's/^/  /' \
                    || echo "  no current context"
                echo ""
                echo "Nodes:"
                kubectl get nodes -o wide 2>/dev/null | sed 's/^/  /' \
                    || echo "  kubectl get nodes failed"
            else
                echo "kubectl not installed."
            fi
        } >> "$file"

        bundle_log_section "$file" "Helm"
        {
            if command -v helm >/dev/null 2>&1; then
                echo "Version:  $(helm version --short 2>/dev/null || echo n/a)"
                echo ""
                echo "Releases in namespace ${BUNDLE_K8S_NAMESPACE}:"
                helm list -n "$BUNDLE_K8S_NAMESPACE" 2>/dev/null | sed 's/^/  /' \
                    || echo "  helm list failed"
            else
                echo "helm not installed."
            fi
        } >> "$file"
    fi

    return 0
}
