#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
# Diagnose / collect-indexing: workspace + repo status via manager API.
# Output: <out>/indexing-status.txt (human summary + raw verbose=true JSON).

if [ -n "${_DIAGNOSE_COLLECT_INDEXING_LOADED:-}" ]; then
    return 0
fi
_DIAGNOSE_COLLECT_INDEXING_LOADED=1

# Writes indexing-status.txt -- human summary + extracted fields + raw JSON
# as an appended section (no separate .json file).
collect_indexing() {
    local deployment_type="$1" out_dir="$2"
    local txt_target="${out_dir}/indexing-status.txt"

    bundle_init_file "$txt_target" "Indexing status"

    _collect_indexing_api "$txt_target"
    # Propagate the inner soft-skip code so safe_step counts it as warned
    # rather than ok (consistent with collect-database / collect-mcp / etc).
    return $?
}

# Query GET /api/v3/indexing-status?verbose=true with Bearer ${BITO_API_KEY}.
# verbose=true asks the manager for the full per-repo breakdown.
_collect_indexing_api() {
    local txt_target="$1"

    bundle_log_section "$txt_target" "Source: manager API"

    if [ -z "${MANAGER_URL:-}" ]; then
        echo "  MANAGER_URL not set -- skipping API probe." >> "$txt_target"
        _bundle_step_warn "indexing" "MANAGER_URL not set"
        return 2
    fi
    if [ -z "${BITO_API_KEY:-}" ]; then
        echo "  BITO_API_KEY not set -- API probe would 401, skipping." >> "$txt_target"
        _bundle_step_warn "indexing" "BITO_API_KEY not set"
        return 2
    fi

    local endpoint="${MANAGER_URL}/api/v3/indexing-status?verbose=true"
    local response http_code body
    # --retry survives a single manager flap during bundle capture without
    # forcing the entire run to re-execute. Total worst-case wall time:
    # 15s + 2*15s (retries) + 2*2s (backoff) = ~49s.
    response=$(curl -s -w '\n%{http_code}' --max-time 15 \
        --retry 2 --retry-delay 2 --retry-connrefused \
        -H "Authorization: Bearer ${BITO_API_KEY}" \
        "$endpoint" 2>&1)
    http_code=$(echo "$response" | tail -1)
    body=$(echo "$response" | sed '$d')

    {
        echo "  Endpoint:    ${endpoint}"
        echo "  HTTP status: ${http_code}"
    } >> "$txt_target"

    # Schema: workspace_id, configured_repos, total_repos, completed_repos,
    # in_progress_repos, failed_repos, percentage_completion,
    # workspace_level_index{total,success,failure,in_progress,ws_status},
    # status, plus per-repo details when verbose=true.
    if [ "$http_code" = "200" ] && [ -n "$body" ] && command -v jq >/dev/null 2>&1; then
        bundle_log_section "$txt_target" "Summary (extracted)"
        # Best-effort timestamp extraction: different manager-API revisions
        # surface the "last run" field under different keys; try the known
        # candidates in order and fall back to n/a if none are present.
        echo "$body" | jq -r '
            "  workspace_id:        " + (.workspace_id // "n/a" | tostring) + "\n" +
            "  repos configured:    " + (.configured_repos // "n/a" | tostring) + "\n" +
            "  repos total:         " + (.total_repos // "n/a" | tostring) + "\n" +
            "  repos completed:     " + (.completed_repos // "n/a" | tostring) + "\n" +
            "  repos in progress:   " + (.in_progress_repos // "n/a" | tostring) + "\n" +
            "  repos failed:        " + (.failed_repos // "n/a" | tostring) + "\n" +
            "  completion:          " + (.percentage_completion // "n/a" | tostring) + "%\n" +
            "  overall status:      " + (.status // "n/a" | tostring) + "\n" +
            "  last indexing run:   " + ((.last_run_at // .last_completed_at // .updated_at //
                                          .workspace_level_index.last_completed_at //
                                          .workspace_level_index.updated_at // "n/a") | tostring) + "\n" +
            "  workspace-level idx: total=" + (.workspace_level_index.total // "n/a" | tostring) +
                                  " success=" + (.workspace_level_index.success // "n/a" | tostring) +
                                  " failure=" + (.workspace_level_index.failure // "n/a" | tostring) +
                                  " in_progress=" + (.workspace_level_index.in_progress // "n/a" | tostring) +
                                  " status=" + (.workspace_level_index.ws_status // "n/a" | tostring)
        ' 2>/dev/null >> "$txt_target" \
            || echo "  (could not extract summary)" >> "$txt_target"

        bundle_log_section "$txt_target" "Failed repos (top 10)"
        local failed_count
        failed_count=$(echo "$body" | jq -r '.failed_repos // 0' 2>/dev/null)
        if [ "${failed_count:-0}" = "0" ]; then
            echo "  No failed repos reported." >> "$txt_target"
        else
            # Failure messages routinely carry tokenised git URLs and bearer
            # headers echoed back by the provider -- stream through
            # redact_stream before writing.
            echo "$body" | jq -r '
                (.failures // .failed_repo_details // []) | .[0:10] | .[] |
                "  - " + (.name // .repo // "<unknown>") + ": " + (.error // .message // "<no error message>")
            ' 2>/dev/null | redact_stream >> "$txt_target"
            if ! echo "$body" | jq -e '(.failures // .failed_repo_details // []) | length > 0' >/dev/null 2>&1; then
                echo "  ${failed_count} failures reported (aggregate); no per-repo details." >> "$txt_target"
                echo "  (drill into manager logs for individual repo errors)" >> "$txt_target"
            fi
        fi

        # Embed the raw JSON inline rather than a separate file. Failed-repo
        # entries can carry tokenised git URLs (x-access-token:ghp_...) and
        # bearer headers echoed in provider error bodies -- redact before
        # writing.
        bundle_log_section "$txt_target" "Raw API response (verbose=true)"
        echo "$body" | jq '.' 2>/dev/null | redact_stream | sed 's/^/  /' >> "$txt_target" \
            || echo "$body" | redact_stream | sed 's/^/  /' >> "$txt_target"
    else
        bundle_log_section "$txt_target" "Raw response (first 500 chars)"
        echo "$body" | head -c 500 | redact_stream | sed 's/^/    /' >> "$txt_target"
        echo "" >> "$txt_target"
    fi
}

