#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
# Bito's AI Architect CLI - Diagnose / collect-temporal
# Read-only Temporal diagnostics. Captures cluster health, namespace meta,
# per-task-queue worker poll state, registered worker deployments, and
# samples of in-flight + failed workflows.
#
# Output: <out>/workflow-status.txt
#
# Read-only by design: diagnostics must never change cluster state.
# Mutating commands such as `temporal worker deployment set-current-version`
# are intentionally NOT included here. Use scripts/temporal-deploy-*.sh for
# any operations that mutate the cluster.
#
# The temporal CLI ships inside the temporal server container itself, so all
# probes are run via `docker exec ai-architect-temporal temporal ...` (or
# `kubectl exec <pod> -- temporal ...` for k8s). No client-side install needed.

if [ -n "${_DIAGNOSE_COLLECT_TEMPORAL_LOADED:-}" ]; then
    return 0
fi
_DIAGNOSE_COLLECT_TEMPORAL_LOADED=1

# Writes workflow-status.txt: cluster health, namespace meta, per-task-queue
# poll state, worker deployments, workflow samples. Returns 2 if container
# is unreachable.
collect_temporal() {
    local deployment_type="$1" out_dir="$2"
    local target="${out_dir}/workflow-status.txt"

    bundle_init_file "$target" "Workflow Status (Temporal)"

    local namespace="${TEMPORAL_NAMESPACE:-cis-onprem}"
    local port="${TEMPORAL_PORT:-7233}"
    local address="${SERVICE_TEMPORAL_NAME}:${port}"
    local task_queues_csv="${TEMPORAL_WORKER_TASK_QUEUES:-cis-workflow-queue,cis-git-queue,cis-indexing-queue,cis-llm-api-queue,cis-tracking-queue,cis-cleanup-queue}"

    {
        echo "Container:    ${SERVICE_TEMPORAL_NAME}"
        echo "Address:      ${address}"
        echo "Namespace:    ${namespace}"
        echo "Task queues:  ${task_queues_csv}"
    } >> "$target"

    if ! _temporal_reachable "$deployment_type"; then
        bundle_log_section "$target" "Skipped"
        echo "  Temporal container/pod not reachable -- skipping probes." >> "$target"
        _bundle_step_warn "workflow" "temporal container/pod unreachable"
        return 2
    fi

    _temporal_cli_version       "$target" "$deployment_type"
    _temporal_cluster_health    "$target" "$deployment_type" "$address"
    _temporal_namespace_describe "$target" "$deployment_type" "$address" "$namespace"
    _temporal_task_queues       "$target" "$deployment_type" "$address" "$namespace" "$task_queues_csv"
    _temporal_worker_deployments "$target" "$deployment_type" "$address" "$namespace"
    _temporal_workflows         "$target" "$deployment_type" "$address" "$namespace"
    return 0
}

# Run `temporal ...` inside the temporal container/pod. Args are passed as
# one string and re-parsed by the in-container `sh -c` -- naive outer-shell
# word-splitting would destroy the embedded quotes in --query filters.
_temporal_exec() {
    local deployment_type="$1"; shift
    local args="$*"
    if [ "$deployment_type" = "kubernetes" ]; then
        local pod
        pod=$(kubectl get pods -n "$BUNDLE_K8S_NAMESPACE" \
            -l "app.kubernetes.io/component=temporal" \
            -o jsonpath='{.items[0].metadata.name}' 2>/dev/null)
        [ -z "$pod" ] && { echo "[no temporal pod found]"; return 1; }
        kubectl exec -n "$BUNDLE_K8S_NAMESPACE" "$pod" -- sh -c "temporal $args" 2>&1
    else
        docker exec "$SERVICE_TEMPORAL_NAME" sh -c "temporal $args" 2>&1
    fi
}

_temporal_reachable() {
    local deployment_type="$1"
    if [ "$deployment_type" = "kubernetes" ]; then
        bundle_have_kubectl || return 1
        kubectl get pod -n "$BUNDLE_K8S_NAMESPACE" \
            -l "app.kubernetes.io/component=temporal" 2>/dev/null \
            | grep -q Running
    else
        bundle_have_docker || return 1
        docker inspect "$SERVICE_TEMPORAL_NAME" >/dev/null 2>&1 || return 1
        [ "$(docker inspect -f '{{.State.Running}}' "$SERVICE_TEMPORAL_NAME" 2>/dev/null)" = "true" ]
    fi
}

# ─── Section bodies ──────────────────────────────────────────────────────

_temporal_cli_version() {
    local target="$1" dt="$2"
    bundle_log_section "$target" "CLI version"
    _temporal_exec "$dt" "--version" | sed 's/^/  /' >> "$target"
}

# Cluster health, with graceful fallback for older temporal builds that
# don't expose `operator cluster health`.
_temporal_cluster_health() {
    local target="$1" dt="$2" address="$3"
    bundle_log_section "$target" "Cluster health"
    local out
    out=$(_temporal_exec "$dt" "operator cluster health --address ${address}")
    if echo "$out" | grep -qE 'unknown command|invalid subcommand'; then
        out=$(_temporal_exec "$dt" "operator cluster system --address ${address}")
    fi
    echo "$out" | sed 's/^/  /' >> "$target"
}

# `-n <ns>` flag form (positional was deprecated in temporal CLI 1.x).
_temporal_namespace_describe() {
    local target="$1" dt="$2" address="$3" ns="$4"
    bundle_log_section "$target" "Namespace: ${ns}"
    _temporal_exec "$dt" "operator namespace describe --address ${address} -n ${ns}" \
        | sed 's/^/  /' >> "$target"
}

# Iterate every queue from TEMPORAL_WORKER_TASK_QUEUES, capped at 3s/queue.
_temporal_task_queues() {
    local target="$1" dt="$2" address="$3" ns="$4" queues_csv="$5"

    bundle_log_section "$target" "Task queues (per-queue describe)"
    local IFS_OLD="$IFS"
    IFS=','
    # shellcheck disable=SC2206
    local queues=($queues_csv)
    IFS="$IFS_OLD"

    local q
    for q in "${queues[@]}"; do
        q="${q#"${q%%[![:space:]]*}"}"
        q="${q%"${q##*[![:space:]]}"}"
        [ -z "$q" ] && continue
        echo "" >> "$target"
        echo "  ── ${q} ─────────────────────────────────────" >> "$target"
        _temporal_exec "$dt" "task-queue describe --address ${address} --namespace ${ns} --task-queue ${q} --command-timeout 3s" \
            | sed 's/^/    /' >> "$target"
    done
}

# Worker deployment list -- only on newer temporal builds; degrade gracefully.
_temporal_worker_deployments() {
    local target="$1" dt="$2" address="$3" ns="$4"
    bundle_log_section "$target" "Worker deployments"
    local out
    out=$(_temporal_exec "$dt" "worker deployment list --address ${address} --namespace ${ns}")
    if echo "$out" | grep -qE 'unknown command|invalid subcommand'; then
        echo "  worker deployment subcommand not available on this temporal version." >> "$target"
        echo "  Server version: $(_temporal_exec "$dt" "operator cluster system --address ${address}" | grep -i version | head -1 | tr -d '\r' | sed 's/^[[:space:]]*//')" >> "$target"
    else
        echo "$out" | sed 's/^/  /' >> "$target"
    fi
}

# Workflow samples by status + schedules.
_temporal_workflows() {
    local target="$1" dt="$2" address="$3" ns="$4"

    bundle_log_section "$target" "Running workflows (up to 20)"
    _temporal_exec "$dt" \
        "workflow list --address ${address} --namespace ${ns} --query 'ExecutionStatus=\"Running\"' --limit 20" \
        | sed 's/^/  /' >> "$target"

    bundle_log_section "$target" "Recently failed workflows (up to 20)"
    _temporal_exec "$dt" \
        "workflow list --address ${address} --namespace ${ns} --query 'ExecutionStatus=\"Failed\"' --limit 20" \
        | sed 's/^/  /' >> "$target"

    bundle_log_section "$target" "Terminated workflows (up to 10)"
    _temporal_exec "$dt" \
        "workflow list --address ${address} --namespace ${ns} --query 'ExecutionStatus=\"Terminated\"' --limit 10" \
        | sed 's/^/  /' >> "$target"

    bundle_log_section "$target" "Schedules (if any)"
    local out
    out=$(_temporal_exec "$dt" "schedule list --address ${address} --namespace ${ns}")
    if echo "$out" | grep -qE 'unknown command|invalid subcommand'; then
        echo "  schedule list subcommand not available on this temporal version." >> "$target"
    else
        echo "$out" | sed 's/^/  /' >> "$target"
    fi
}
