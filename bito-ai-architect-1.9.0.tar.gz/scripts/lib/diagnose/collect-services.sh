#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
# Diagnose / collect-services: per-service status, restarts, uptime, CPU/mem.
# Writes to the merged services-overview.txt (initializes the file).

if [ -n "${_DIAGNOSE_COLLECT_SERVICES_LOADED:-}" ]; then
    return 0
fi
_DIAGNOSE_COLLECT_SERVICES_LOADED=1

# First collector that touches services-overview.txt -- creates the file with
# its header. Subsequent contributors (deployment meta, network) only append.
collect_services() {
    local deployment_type="$1" out_dir="$2"
    local target="${out_dir}/services-overview.txt"

    bundle_init_file "$target" "Services Overview"

    if [ "$deployment_type" = "kubernetes" ]; then
        _collect_services_k8s "$target"
        _collect_k8s_events "$out_dir"
    else
        _collect_services_docker "$target"
    fi
    return 0
}

# ─── Docker Compose ───────────────────────────────────────────────────────
_collect_services_docker() {
    local target="$1"

    if ! bundle_have_docker; then
        echo "docker daemon not reachable -- skipping container/resource probes." >> "$target"
        return 0
    fi

    bundle_log_section "$target" "Containers (status, restarts, uptime, health)"
    {
        printf "%-26s %-10s %-10s %-25s %-15s\n" "NAME" "STATUS" "RESTARTS" "STARTED" "HEALTH"
        printf "%-26s %-10s %-10s %-25s %-15s\n" \
            "--------------------------" "---------" "---------" "------------------------" "--------------"

        local svc
        for svc in "${BITOARCH_LIFECYCLE_SERVICES[@]}"; do
            local status restarts started health
            status=$(docker inspect --format='{{.State.Status}}'        "$svc" 2>/dev/null || echo "missing")
            restarts=$(docker inspect --format='{{.RestartCount}}'      "$svc" 2>/dev/null || echo "-")
            started=$(docker inspect --format='{{.State.StartedAt}}'    "$svc" 2>/dev/null || echo "-")
            health=$(docker inspect --format='{{.State.Health.Status}}' "$svc" 2>/dev/null || echo "-")
            [ -z "$health" ] || [ "$health" = "<no value>" ] && health="none"
            printf "%-26s %-10s %-10s %-25s %-15s\n" \
                "$svc" "$status" "$restarts" "${started:0:24}" "$health"
        done
    } >> "$target"

    # `docker ps --filter` instead of `docker compose ps` -- the latter needs
    # the compose project context (env-file) which isn't guaranteed at runtime.
    bundle_log_section "$target" "docker ps (ai-architect-* containers)"
    docker ps --all --filter 'name=ai-architect-' \
        --format 'table {{.Names}}\t{{.Status}}\t{{.Ports}}' 2>&1 | sed 's/^/  /' >> "$target"

    bundle_log_section "$target" "Resource usage (docker stats, one-shot)"
    docker stats --no-stream --format \
        'table {{.Name}}\t{{.CPUPerc}}\t{{.MemUsage}}\t{{.MemPerc}}\t{{.NetIO}}\t{{.BlockIO}}' \
        $(printf '%s ' "${BITOARCH_LIFECYCLE_SERVICES[@]}") 2>&1 | sed 's/^/  /' >> "$target"

    return 0
}

# ─── Kubernetes ───────────────────────────────────────────────────────────
_collect_services_k8s() {
    local target="$1"
    local ns="$BUNDLE_K8S_NAMESPACE"

    if ! bundle_have_kubectl; then
        echo "kubectl/cluster unreachable -- skipping pod/resource probes." >> "$target"
        return 0
    fi
    if ! kubectl get namespace "$ns" >/dev/null 2>&1; then
        echo "Namespace '$ns' not found." >> "$target"
        return 0
    fi

    bundle_log_section "$target" "Deployments"
    kubectl get deployments -n "$ns" -o wide 2>&1 | sed 's/^/  /' >> "$target"

    bundle_log_section "$target" "Pods (status, restarts, age)"
    kubectl get pods -n "$ns" -o wide 2>&1 | sed 's/^/  /' >> "$target"

    bundle_log_section "$target" "Pod events (recent)"
    kubectl get events -n "$ns" --sort-by='.lastTimestamp' 2>&1 \
        | tail -50 | sed 's/^/  /' >> "$target"

    # Capture `kubectl top` exit status directly: piping it straight into
    # head/sed would mask a non-zero rc (the pipeline's status is sed's), so a
    # cluster with no metrics-server produced an empty section + a raw error
    # instead of a clear message.
    bundle_log_section "$target" "Resource usage (kubectl top pods)"
    local top_pods_out top_pods_rc=0
    top_pods_out=$(kubectl top pod -n "$ns" --containers 2>/dev/null) || top_pods_rc=$?
    if [ "$top_pods_rc" -eq 0 ] && [ -n "$top_pods_out" ]; then
        printf '%s\n' "$top_pods_out" | head -100 | sed 's/^/  /' >> "$target"
    else
        echo "  Live pod usage unavailable (metrics-server not installed?)." >> "$target"
        echo "  Falling back to requests/limits from pod spec:" >> "$target"
        kubectl get pods -n "$ns" -o custom-columns=\
'NAME:.metadata.name,'\
'CPU_REQ:.spec.containers[*].resources.requests.cpu,'\
'MEM_REQ:.spec.containers[*].resources.requests.memory,'\
'CPU_LIM:.spec.containers[*].resources.limits.cpu,'\
'MEM_LIM:.spec.containers[*].resources.limits.memory' 2>&1 | sed 's/^/    /' >> "$target"
    fi

    bundle_log_section "$target" "Node resource pressure"
    local top_nodes_out top_nodes_rc=0
    top_nodes_out=$(kubectl top nodes 2>/dev/null) || top_nodes_rc=$?
    if [ "$top_nodes_rc" -eq 0 ] && [ -n "$top_nodes_out" ]; then
        printf '%s\n' "$top_nodes_out" | sed 's/^/  /' >> "$target"
    else
        echo "  Node metrics unavailable -- metrics-server not installed in this cluster." >> "$target"
    fi

    return 0
}

# ─── Dedicated Kubernetes events capture ─────────────────────────────────
# Writes <out>/k8s-events.txt: Warning events first (the high-signal ones --
# OOMKilled, ImagePullBackOff, CrashLoopBackOff, FailedScheduling), then the
# full event list. Both use -o wide and --sort-by=.lastTimestamp. The shorter
# "Pod events (recent)" summary in services-overview.txt is left in place.
# Streamed through redact_stream -- event messages can echo tokens or paths.
_collect_k8s_events() {
    local out_dir="$1"
    local ns="$BUNDLE_K8S_NAMESPACE"
    local target="${out_dir}/k8s-events.txt"

    {
        echo "Kubernetes events -- namespace: ${ns}"
        echo "Generated: $(date '+%Y-%m-%d %H:%M:%S %Z')"
    } > "$target"

    if ! bundle_have_kubectl; then
        echo "kubectl/cluster unreachable -- skipping events." >> "$target"
        return 0
    fi
    if ! kubectl get namespace "$ns" >/dev/null 2>&1; then
        echo "Namespace '${ns}' not found -- skipping events." >> "$target"
        return 0
    fi

    bundle_log_section "$target" "Warning events (high signal)"
    { kubectl get events -n "$ns" --field-selector type=Warning \
        -o wide --sort-by='.lastTimestamp' 2>&1 \
        || echo "[kubectl get events (Warning) failed]"; } \
        | redact_stream >> "$target"

    bundle_log_section "$target" "All events (oldest first)"
    { kubectl get events -n "$ns" -o wide --sort-by='.lastTimestamp' 2>&1 \
        || echo "[kubectl get events failed]"; } \
        | redact_stream >> "$target"

    return 0
}
