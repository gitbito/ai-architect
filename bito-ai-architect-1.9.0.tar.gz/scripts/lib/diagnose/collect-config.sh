#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
# Diagnose / collect-config: sanitized .env, versions, deployment meta,
# YAML configs, helm values (k8s only). Deployment meta is appended to the
# merged services-overview.txt (created by collect_services).

if [ -n "${_DIAGNOSE_COLLECT_CONFIG_LOADED:-}" ]; then
    return 0
fi
_DIAGNOSE_COLLECT_CONFIG_LOADED=1

collect_config() {
    local deployment_type="$1" out_dir="$2"

    _collect_env_file        "$out_dir"
    _collect_cis_config_api  "$out_dir"
    _collect_deployment_meta "$out_dir" "$deployment_type"
    _collect_yaml_configs    "$out_dir"
    _collect_image_details   "$out_dir" "$deployment_type"

    if [ "$deployment_type" = "kubernetes" ]; then
        _collect_helm_values "$out_dir"
    fi
    return 0
}

# Writes config-sanitized.txt with secrets replaced by ***REDACTED***.
_collect_env_file() {
    local out_dir="$1"
    local target="${out_dir}/config-sanitized.txt"
    local cfg_file
    cfg_file=$(get_config_file 2>/dev/null)

    bundle_init_file "$target" "Configuration (sanitized .env)"

    if [ -z "$cfg_file" ] || [ ! -f "$cfg_file" ]; then
        echo "Config file not found." >> "$target"
        echo "Tried: ${cfg_file:-<unset>}" >> "$target"
        return 0
    fi

    bundle_log_section "$target" "Source: ${cfg_file}"
    {
        echo "Sensitive values are replaced with ***REDACTED***."
        echo "Sensitive key matchers: API_KEY, TOKEN, SECRET, PASSWORD,"
        echo "PRIVATE_KEY, ACCESS_KEY, CLIENT_SECRET, ENCRYPTION, CREDENTIAL."
        echo ""
        redact_env_file "$cfg_file"
    } >> "$target"
}

# Appends GET ${CONFIG_URL}/api/v1/config response (stream-redacted) to
# config-sanitized.txt. Soft-skip if URL/api-key missing.
_collect_cis_config_api() {
    local out_dir="$1"
    local target="${out_dir}/config-sanitized.txt"
    [ ! -f "$target" ] && bundle_init_file "$target" "Configuration (sanitized .env)"

    bundle_log_section "$target" "cis-config API: GET /api/v1/config"

    # collect_config runs several sub-collectors; bump the warn counter so the
    # bundle summary reflects each silent sub-skip without aborting the rest
    # of the config collection (which still produces useful env/yaml/image data).
    if [ -z "${CONFIG_URL:-}" ]; then
        echo "  CONFIG_URL not set -- skipped." >> "$target"
        _bundle_step_warn "config/cis-api" "CONFIG_URL not set"
        return 0
    fi
    if [ -z "${BITO_API_KEY:-}" ]; then
        echo "  BITO_API_KEY not set -- API probe would 401, skipped." >> "$target"
        _bundle_step_warn "config/cis-api" "BITO_API_KEY not set"
        return 0
    fi

    local endpoint="${CONFIG_URL}/api/v1/config"
    local response http_code body
    response=$(curl -s -w '\n%{http_code}' --max-time 15 \
        -H "Authorization: Bearer ${BITO_API_KEY}" \
        "$endpoint" 2>&1)
    http_code=$(echo "$response" | tail -1)
    body=$(echo "$response" | sed '$d')

    {
        echo "  Endpoint:    ${endpoint}"
        echo "  HTTP status: ${http_code}"
        echo ""
    } >> "$target"

    if [ "$http_code" = "200" ] && [ -n "$body" ] && command -v jq >/dev/null 2>&1; then
        # Pretty-print + stream-redact (catches embedded tokens/passwords).
        echo "$body" | jq '.' 2>/dev/null | redact_stream | sed 's/^/  /' >> "$target" \
            || echo "$body" | redact_stream | sed 's/^/  /' >> "$target"
    else
        echo "  (raw, first 1000 chars)" >> "$target"
        echo "$body" | head -c 1000 | redact_stream | sed 's/^/  /' >> "$target"
        echo "" >> "$target"
    fi
}

# Appends an "Image details" section to config-sanitized.txt with each
# container's image name, ID, and creation date. The ticket spec also lists
# service-versions.json as a top-level bundle artifact -- we copy the
# platform-shipped manifest verbatim so support tooling that parses the
# bundle by filename keeps working. The inline section is the more accurate
# runtime view; the file is the "intended-to-ship" manifest.
_collect_image_details() {
    local out_dir="$1" deployment_type="$2"
    local target="${out_dir}/config-sanitized.txt"
    [ ! -f "$target" ] && bundle_init_file "$target" "Configuration (sanitized .env)"

    bundle_log_section "$target" "Image details (running containers)"

    if [ "$deployment_type" = "kubernetes" ]; then
        _image_details_k8s "$target"
    else
        _image_details_docker "$target"
    fi

    # Also include the platform-shipped manifest if present -- useful when
    # the running image's tag doesn't match what was *intended* to be shipped.
    local versions_file="${SCRIPT_DIR}/../versions/service-versions.json"
    if [ -f "$versions_file" ]; then
        bundle_log_section "$target" "Intended versions (service-versions.json)"
        sed 's/^/  /' "$versions_file" >> "$target"
        # Copy the manifest as a standalone top-level file too, matching the
        # ticket's bundle-layout spec for support tooling that parses by name.
        cp "$versions_file" "${out_dir}/service-versions.json" 2>/dev/null || true
    fi
}

_image_details_docker() {
    local target="$1"
    if ! bundle_have_docker; then
        echo "  docker daemon unreachable -- skipping image details." >> "$target"
        _bundle_step_warn "config/image-details" "docker daemon unreachable"
        return 0
    fi
    {
        printf "  %-30s %-50s %s\n" "CONTAINER" "IMAGE" "CREATED"
        printf "  %-30s %-50s %s\n" "------------------------------" "--------------------------------------------------" "----------------------"
        local svc image created
        for svc in "${BITOARCH_LIFECYCLE_SERVICES[@]}"; do
            image=$(docker inspect --format='{{.Config.Image}}' "$svc" 2>/dev/null || echo "-")
            created=$(docker inspect --format='{{.Created}}' "$svc" 2>/dev/null || echo "-")
            printf "  %-30s %-50s %s\n" "$svc" "$image" "${created:0:19}"
        done
    } >> "$target"
}

_image_details_k8s() {
    local target="$1"
    if ! bundle_have_kubectl; then
        echo "  kubectl unreachable -- skipping image details." >> "$target"
        _bundle_step_warn "config/image-details" "kubectl unreachable"
        return 0
    fi
    kubectl get pods -n "$BUNDLE_K8S_NAMESPACE" \
        -o custom-columns='POD:.metadata.name,IMAGE:.spec.containers[*].image,STARTED:.status.startTime' \
        2>&1 | sed 's/^/  /' >> "$target"
}

# Appends "Deployment metadata" section to the merged services-overview.txt.
# Falls back to creating its own file if services-overview.txt wasn't created
# (collect_services skipped).
_collect_deployment_meta() {
    local out_dir="$1" deployment_type="$2"
    local target="${out_dir}/services-overview.txt"

    if [ ! -f "$target" ]; then
        bundle_init_file "$target" "Services Overview"
    fi

    bundle_log_section "$target" "Deployment metadata"
    {
        echo "  Deployment type:  $deployment_type"
        echo "  Install dir:      ${SCRIPT_DIR:-unset}"
        echo "  Config file:      $(get_config_file 2>/dev/null || echo n/a)"
        echo "  Log directory:    ${BITOARCH_LOG_DIR:-n/a}"
        echo "  Storage path:     ${STORAGE_PATH:-n/a}"
        echo "  Index data dir:   ${INDEX_DATA_DIR:-n/a}"
        echo "  MCP transport:    ${MCP_TRANSPORT:-unset}"
        if [ "$deployment_type" = "kubernetes" ]; then
            echo "  K8s namespace:    $BUNDLE_K8S_NAMESPACE"
        fi
        echo ""
        echo "  Service constants:"
        echo "    USER:        ${BITOARCH_USER_SERVICES[*]:-n/a}"
        echo "    LIFECYCLE:   ${BITOARCH_LIFECYCLE_SERVICES[*]:-n/a}"
    } >> "$target"
}

# Copies optional user YAMLs through redact_stream (defensive on git tokens).
_collect_yaml_configs() {
    local out_dir="$1"
    local yaml_dir="${out_dir}/yaml-configs"
    mkdir -p "$yaml_dir" 2>/dev/null || true

    local f label
    for getter in get_repo_config_file get_repo_list_file get_install_yaml_file; do
        f=$("$getter" 2>/dev/null)
        if [ -z "$f" ] || [ ! -f "$f" ]; then
            continue
        fi
        label="${f##*/}"
        redact_stream < "$f" > "${yaml_dir}/${label}" 2>/dev/null
    done

    if [ -z "$(ls -A "$yaml_dir" 2>/dev/null)" ]; then
        echo "No optional YAML configs found in ~/.bitoarch." > "${yaml_dir}/README.txt"
    fi
}

# Writes helm-values.yaml with stream-redacted `helm get values --all`.
_collect_helm_values() {
    local out_dir="$1"
    local target="${out_dir}/helm-values.yaml"

    if ! command -v helm >/dev/null 2>&1; then
        echo "# helm not installed" > "$target"
        _bundle_step_warn "config/helm-values" "helm not installed"
        return 0
    fi

    # The installer deploys the chart as release `bitoarch` (setup.sh ->
    # kubernetes-manager.sh deploy_helm_chart; also upgrade/restore/backup).
    # `bito-ai-architect` is kept as a fallback for the manual
    # `helm-bitoarch/*.sh` deploy scripts, which still use that release name.
    local release_name
    release_name=$(helm list -n "$BUNDLE_K8S_NAMESPACE" -q 2>/dev/null \
        | grep -E '^(bitoarch|bito-ai-architect)$' \
        | head -1)
    if [ -z "$release_name" ]; then
        echo "# no bitoarch/bito-ai-architect helm release found in namespace ${BUNDLE_K8S_NAMESPACE}" > "$target"
        _bundle_step_warn "config/helm-values" "release not found in namespace"
        return 0
    fi

    {
        echo "# helm get values ${release_name} -n ${BUNDLE_K8S_NAMESPACE} --all"
        echo "# captured at $(date '+%Y-%m-%d %H:%M:%S %Z')"
        echo "# sensitive values stream-redacted"
        echo "---"
        helm get values "$release_name" -n "$BUNDLE_K8S_NAMESPACE" --all 2>&1 | redact_stream
    } > "$target"
}
