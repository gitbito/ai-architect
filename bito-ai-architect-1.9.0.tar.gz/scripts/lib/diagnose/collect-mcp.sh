#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
# Diagnose / collect-mcp: connection probe, tools/list, listRepositories.

if [ -n "${_DIAGNOSE_COLLECT_MCP_LOADED:-}" ]; then
    return 0
fi
_DIAGNOSE_COLLECT_MCP_LOADED=1

# Writes mcp-status.txt: endpoint reachability, available tools, and the
# canonical "what repos does MCP know about" via listRepositories.
collect_mcp() {
    local deployment_type="$1" out_dir="$2"
    local target="${out_dir}/mcp-status.txt"

    bundle_init_file "$target" "MCP Status"

    local url="${PROVIDER_URL:-}"
    # BITO_MCP_ACCESS_TOKEN is the canonical MCP token. Older deployments
    # used PROVIDER_TOKEN; BITO_API_KEY is the last-resort fallback (will
    # 401 on most MCP endpoints since it's a JWT, not the MCP access token).
    local token="${BITO_MCP_ACCESS_TOKEN:-${PROVIDER_TOKEN:-${BITO_API_KEY:-}}}"

    {
        echo "Provider URL:    ${url:-<unset>}"
        echo "Token source:    $(_mcp_token_source)"
    } >> "$target"

    if [ -z "$url" ]; then
        bundle_log_section "$target" "Skipped"
        echo "  PROVIDER_URL not set -- cannot probe MCP." >> "$target"
        _bundle_step_warn "mcp" "PROVIDER_URL not set"
        return 2
    fi
    if [ -z "$token" ]; then
        bundle_log_section "$target" "Skipped"
        echo "  No MCP token available (PROVIDER_TOKEN / BITO_API_KEY)." >> "$target"
        _bundle_step_warn "mcp" "no auth token"
        return 2
    fi

    _mcp_connection_probe "$target" "$url" "$token"
    _mcp_tools_list       "$target" "$url" "$token"
    _mcp_list_repos       "$target" "$url" "$token"
    return 0
}

# Echoes which env var the token came from -- useful when MCP auth fails.
_mcp_token_source() {
    if [ -n "${BITO_MCP_ACCESS_TOKEN:-}" ]; then
        echo "BITO_MCP_ACCESS_TOKEN"
    elif [ -n "${PROVIDER_TOKEN:-}" ]; then
        echo "PROVIDER_TOKEN"
    elif [ -n "${BITO_API_KEY:-}" ]; then
        echo "BITO_API_KEY (fallback -- may 401)"
    else
        echo "<none>"
    fi
}

# Reuses probe_mcp_endpoint from diagnose.sh -- same liveness check that the
# live sweep runs, so support sees identical signals from both paths.
_mcp_connection_probe() {
    local target="$1" url="$2" token="$3"
    bundle_log_section "$target" "Connection (tools/list ping)"
    local result
    result=$(probe_mcp_endpoint "$url" "$token")
    {
        echo "  Endpoint: ${url}/mcp"
        echo "  Result:   ${result}"
    } >> "$target"
}

# Full tools/list response -- shows every tool the MCP server exposes plus
# its schema. Helpful when "tool not found" errors surface elsewhere.
_mcp_tools_list() {
    local target="$1" url="$2" token="$3"
    bundle_log_section "$target" "Available tools (tools/list)"

    local tls=""
    case "$url" in https://*) tls="-k" ;; esac

    local body http_code response
    response=$(curl -s -w '\n%{http_code}' --max-time 15 $tls \
        -X POST "${url}/mcp" \
        -H "Authorization: Bearer ${token}" \
        -H "Content-Type: application/json" \
        -d '{"jsonrpc":"2.0","method":"tools/list","id":1}' 2>&1)
    http_code=$(echo "$response" | tail -1)
    body=$(echo "$response" | sed '$d')
    echo "  HTTP status: ${http_code}" >> "$target"

    if [ "$http_code" = "200" ] && [ -n "$body" ] && command -v jq >/dev/null 2>&1; then
        # Compact list -- name + first line of description.
        echo "" >> "$target"
        echo "$body" | jq -r '
            .result.tools[]? |
            "  - " + .name + (if .description then "  -- " + (.description | split("\n") | .[0]) else "" end)
        ' 2>/dev/null >> "$target" \
            || echo "  (could not extract tool list)" >> "$target"

        echo "" >> "$target"
        echo "  Total tools: $(echo "$body" | jq -r '.result.tools | length' 2>/dev/null)" >> "$target"
    else
        echo "  (raw, first 1000 chars)" >> "$target"
        # Error bodies on MCP failures can echo the bearer header back --
        # redact before persisting.
        echo "$body" | head -c 1000 | redact_stream | sed 's/^/    /' >> "$target"
        echo "" >> "$target"
    fi
}

# Calls the listRepositories tool -- "what does MCP see". Paginates because
# the MCP server caps pageSize at 100; we walk pages until has_next=false
# (or BITOARCH_DIAG_MCP_MAX_PAGES is hit, default 50 = up to 5000 repos).
#
# Response shape (verified live):
#   .result.content[0].text  -- JSON string with:
#     { items: [{name}, ...],
#       pagination: { current_page, page_size, total_items, total_pages,
#                     has_next, has_previous } }
#   On error: .result.isError=true and .result.content[0].text is a plain
#   string with the validation/auth error message (not JSON).
_mcp_list_repos() {
    local target="$1" url="$2" token="$3"
    bundle_log_section "$target" "Repositories indexed in MCP (listRepositories)"

    local tls=""
    case "$url" in https://*) tls="-k" ;; esac
    local page_size="${BITOARCH_DIAG_MCP_PAGE_SIZE:-100}"
    local max_pages="${BITOARCH_DIAG_MCP_MAX_PAGES:-50}"

    if ! command -v jq >/dev/null 2>&1; then
        echo "  jq not installed -- fetching only page 1 raw." >> "$target"
        _mcp_list_repos_one_page "$target" "$url" "$token" "$tls" "$page_size" 1 raw
        return 0
    fi

    # Page 1 probe -- gives us totals + lets us bail out cleanly on auth
    # errors before looping.
    local page1
    page1=$(_mcp_fetch_repos_page "$url" "$token" "$tls" "$page_size" 1)
    local http_code
    http_code=$(echo "$page1" | tail -1)
    local body
    body=$(echo "$page1" | sed '$d')
    echo "  HTTP status (page 1): ${http_code}" >> "$target"

    if [ "$http_code" != "200" ] || [ -z "$body" ]; then
        echo "  (raw, first 1000 chars)" >> "$target"
        echo "$body" | head -c 1000 | redact_stream | sed 's/^/    /' >> "$target"
        echo "" >> "$target"
        return 0
    fi

    # Detect error wrapper: .result.isError=true means the text is a plain
    # error message, not JSON. Surface it instead of silently showing 0 repos.
    local is_error
    is_error=$(echo "$body" | jq -r '.result.isError // false' 2>/dev/null)
    if [ "$is_error" = "true" ]; then
        echo "  ✗ MCP returned isError=true:" >> "$target"
        echo "$body" | jq -r '.result.content[0].text // "<no text>"' 2>/dev/null \
            | sed 's/^/    /' >> "$target"
        return 0
    fi

    local inner
    inner=$(echo "$body" | jq -r '.result.content[0].text // empty' 2>/dev/null)
    if [ -z "$inner" ]; then
        echo "" >> "$target"
        echo "$body" | jq '.' 2>/dev/null | sed 's/^/  /' >> "$target"
        return 0
    fi

    local total total_pages has_next
    total=$(echo "$inner"       | jq -r '.pagination.total_items // 0' 2>/dev/null)
    total_pages=$(echo "$inner" | jq -r '.pagination.total_pages // 1' 2>/dev/null)
    has_next=$(echo "$inner"    | jq -r '.pagination.has_next   // false' 2>/dev/null)

    {
        echo "  Total indexed repositories: ${total}"
        echo "  Pagination: ${total_pages} page(s), pageSize=${page_size}"
    } >> "$target"

    if [ "${total}" = "0" ]; then
        echo "  (no repositories returned)" >> "$target"
        return 0
    fi

    # Emit page-1 repos, then loop through remaining pages.
    echo "" >> "$target"
    echo "  Indexed repositories:" >> "$target"
    _mcp_format_items "$inner" >> "$target"

    local page=2
    while [ "$has_next" = "true" ] && [ "$page" -le "$max_pages" ]; do
        local page_n inner_n
        page_n=$(_mcp_fetch_repos_page "$url" "$token" "$tls" "$page_size" "$page" | sed '$d')
        inner_n=$(echo "$page_n" | jq -r '.result.content[0].text // empty' 2>/dev/null)
        [ -z "$inner_n" ] && break
        _mcp_format_items "$inner_n" >> "$target"
        has_next=$(echo "$inner_n" | jq -r '.pagination.has_next // false' 2>/dev/null)
        page=$((page + 1))
    done

    # Bail-out hint when we hit the safety cap.
    if [ "$has_next" = "true" ]; then
        {
            echo ""
            echo "  ⚠ Stopped at page ${max_pages} (BITOARCH_DIAG_MCP_MAX_PAGES)."
            echo "    Increase the cap or raise BITOARCH_DIAG_MCP_PAGE_SIZE to fetch the rest."
        } >> "$target"
    fi
}

# Single page fetch. Emits curl body + \n + http_code (caller splits with sed).
_mcp_fetch_repos_page() {
    local url="$1" token="$2" tls="$3" page_size="$4" page_num="$5"
    curl -s -w '\n%{http_code}' --max-time 30 $tls \
        -X POST "${url}/mcp" \
        -H "Authorization: Bearer ${token}" \
        -H "Content-Type: application/json" \
        -d "{
              \"jsonrpc\":\"2.0\",\"method\":\"tools/call\",\"id\":${page_num},
              \"params\":{\"name\":\"listRepositories\",\"arguments\":{
                \"purposeType\":\"codebase_understanding\",
                \"purpose\":\"Listing indexed repositories via bitoarch diagnose --bundle\",
                \"callerPlatform\":\"${MCP_CALLER_PLATFORM:-BITOARCH_CLI}\",
                \"pageNumber\":${page_num},
                \"pageSize\":${page_size}
              }}
            }" 2>&1
}

# Format inner JSON (.items[]) as bullet lines. Output to stdout.
_mcp_format_items() {
    local inner="$1"
    echo "$inner" | jq -r '
        (.items // []) | .[] |
        "    - " + (.name // .repositoryName // "<unknown>") +
        (if .description then "  -- " + .description else "" end) +
        (if .lastIndexed then "  last_indexed=" + .lastIndexed else "" end) +
        (if .branch      then "  branch=" + .branch          else "" end)
    ' 2>/dev/null
}

# Fallback when jq is missing -- just dump the raw response.
_mcp_list_repos_one_page() {
    local target="$1" url="$2" token="$3" tls="$4" page_size="$5" page_num="$6"
    _mcp_fetch_repos_page "$url" "$token" "$tls" "$page_size" "$page_num" \
        | sed '$d' | sed 's/^/    /' >> "$target"
}
