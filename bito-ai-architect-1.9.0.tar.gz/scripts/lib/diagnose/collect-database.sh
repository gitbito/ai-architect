#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
# Bito's AI Architect CLI - Diagnose / collect-database
# Read-only MySQL diagnostics. Uses docker exec / kubectl exec to run
# SELECTs inside the mysql container, so we never expose credentials on
# the host shell history.
#
# Output: <out>/database-health.txt
#
# Sections:
#   - Connection status (SELECT 1)
#   - Server version
#   - Database size (information_schema)
#   - Table list with row counts (top 50 by size)
#   - Replication status (best-effort; n/a for single-node)

if [ -n "${_DIAGNOSE_COLLECT_DATABASE_LOADED:-}" ]; then
    return 0
fi
_DIAGNOSE_COLLECT_DATABASE_LOADED=1

# Writes database-health.txt: connection, server, db size, tables, replication.
# Returns 2 (soft-skip) when no MySQL creds are available.
collect_database() {
    local deployment_type="$1" out_dir="$2"
    local target="${out_dir}/database-health.txt"

    bundle_init_file "$target" "Database Health"

    # Default matches .env-bitoarch.default and collect-logs.sh's _collect_events.
    local db_name="${MYSQL_DATABASE:-code_intelligence}"
    # Prefer root (information_schema requires it). User pair is fallback.
    local user pass
    if [ -n "${MYSQL_ROOT_PASSWORD:-}" ]; then
        user="root"; pass="${MYSQL_ROOT_PASSWORD}"
    elif [ -n "${MYSQL_USER:-}" ] && [ -n "${MYSQL_PASSWORD:-}" ]; then
        user="${MYSQL_USER}"; pass="${MYSQL_PASSWORD}"
    else
        user="${MYSQL_USER:-root}"; pass=""
    fi

    {
        echo "Target database: ${db_name}"
        echo "Connection user: ${user}"
    } >> "$target"

    if [ -z "$pass" ]; then
        bundle_log_section "$target" "Skipped"
        echo "MYSQL_ROOT_PASSWORD / MYSQL_PASSWORD not set in env -- cannot run SQL probes." >> "$target"
        echo "Connectivity (port) is still checked by collect_network." >> "$target"
        _bundle_step_warn "database" "no creds; skipped SQL probes"
        return 2
    fi

    if [ "$deployment_type" = "kubernetes" ]; then
        _collect_db_k8s "$target" "$db_name" "$user" "$pass"
    else
        _collect_db_docker "$target" "$db_name" "$user" "$pass"
    fi
    return 0
}

# ─── Exec wrappers ───────────────────────────────────────────────────────
# MYSQL_PWD env var avoids the "Using a password" stderr warning that would
# otherwise interleave with awk-formatted output. -B = batch, -N = no headers.

_mysql_exec_docker() {
    local user="$1" pass="$2" db="$3" sql="$4"
    docker exec -i -e MYSQL_PWD="$pass" "$SERVICE_MYSQL_NAME" \
        mysql -u "$user" -B -N -e "$sql" "$db" 2>/dev/null
}

_mysql_exec_k8s() {
    local user="$1" pass="$2" db="$3" sql="$4"
    local pod
    pod=$(kubectl get pods -n "$BUNDLE_K8S_NAMESPACE" \
        -l "app.kubernetes.io/component=mysql" \
        -o jsonpath='{.items[0].metadata.name}' 2>/dev/null)
    if [ -z "$pod" ]; then
        echo "[mysql pod not found in namespace ${BUNDLE_K8S_NAMESPACE}]"
        return 1
    fi
    # `kubectl exec` has no --env flag (unlike `docker exec -e`); pass MYSQL_PWD
    # via an in-container `env VAR=val` prefix so the mysql client reads it.
    kubectl exec -n "$BUNDLE_K8S_NAMESPACE" "$pod" -- \
        env MYSQL_PWD="$pass" mysql -u "$user" -B -N -e "$sql" "$db" 2>/dev/null
}

# Section runner -- deployment-agnostic; receives the exec wrapper by name.
_collect_db_sections() {
    local target="$1" db_name="$2" exec_fn="$3" user="$4" pass="$5"

    bundle_log_section "$target" "Connection"
    local ping
    ping=$("$exec_fn" "$user" "$pass" "$db_name" 'SELECT 1' 2>&1)
    if echo "$ping" | grep -q '^1$'; then
        echo "  status:  OK (SELECT 1 returned 1)" >> "$target"
    else
        echo "  status:  FAILED" >> "$target"
        echo "  output:  $ping" >> "$target"
        return 0
    fi

    bundle_log_section "$target" "Server"
    {
        echo "  version:    $("$exec_fn" "$user" "$pass" "$db_name" 'SELECT VERSION()' 2>/dev/null)"
        echo "  uptime (s): $("$exec_fn" "$user" "$pass" "$db_name" 'SHOW STATUS LIKE "Uptime"' 2>/dev/null | awk '{print $2}')"
        echo "  threads:    $("$exec_fn" "$user" "$pass" "$db_name" 'SHOW STATUS LIKE "Threads_connected"' 2>/dev/null | awk '{print $2}')"
    } >> "$target"

    bundle_log_section "$target" "Database size"
    "$exec_fn" "$user" "$pass" "$db_name" \
        "SELECT
           table_schema AS db,
           ROUND(SUM(data_length + index_length) / 1024 / 1024, 2) AS size_mb,
           COUNT(*) AS tables
         FROM information_schema.tables
         WHERE table_schema NOT IN ('mysql','information_schema','performance_schema','sys')
         GROUP BY table_schema
         ORDER BY size_mb DESC;" 2>&1 \
        | awk 'BEGIN{printf "  %-30s %-12s %s\n  %-30s %-12s %s\n", "DB", "SIZE_MB", "TABLES", "------------------------------", "------------", "------"}
               { printf "  %-30s %-12s %s\n", $1, $2, $3 }' \
        >> "$target"

    bundle_log_section "$target" "Tables in ${db_name} (top 50 by size)"
    "$exec_fn" "$user" "$pass" "$db_name" \
        "SELECT
           table_name,
           table_rows,
           ROUND(data_length / 1024 / 1024, 2) AS data_mb,
           ROUND(index_length / 1024 / 1024, 2) AS index_mb,
           engine
         FROM information_schema.tables
         WHERE table_schema = '${db_name}'
         ORDER BY (data_length + index_length) DESC
         LIMIT 50;" 2>&1 \
        | awk 'BEGIN{printf "  %-40s %-12s %-10s %-10s %s\n  %-40s %-12s %-10s %-10s %s\n",
                            "TABLE", "ROWS", "DATA_MB", "IDX_MB", "ENGINE",
                            "----------------------------------------", "------------", "----------", "----------", "------"}
               { printf "  %-40s %-12s %-10s %-10s %s\n", $1, $2, $3, $4, $5 }' \
        >> "$target"

    bundle_log_section "$target" "Replication (best-effort)"
    local repl
    repl=$("$exec_fn" "$user" "$pass" "$db_name" 'SHOW SLAVE STATUS' 2>&1)
    if [ -z "$repl" ] || echo "$repl" | grep -qi 'Empty set'; then
        echo "  Not a replica (no slave status)." >> "$target"
    else
        echo "$repl" | redact_stream | head -40 | sed 's/^/  /' >> "$target"
    fi
}

_collect_db_docker() {
    local target="$1" db_name="$2" user="$3" pass="$4"
    if ! bundle_have_docker; then
        echo "docker daemon unreachable -- skipping DB exec." >> "$target"
        return 0
    fi
    if ! docker inspect "$SERVICE_MYSQL_NAME" >/dev/null 2>&1; then
        echo "Container ${SERVICE_MYSQL_NAME} not present -- skipping." >> "$target"
        return 0
    fi
    _collect_db_sections "$target" "$db_name" _mysql_exec_docker "$user" "$pass"
}

_collect_db_k8s() {
    local target="$1" db_name="$2" user="$3" pass="$4"
    if ! bundle_have_kubectl; then
        echo "kubectl unreachable -- skipping DB exec." >> "$target"
        return 0
    fi
    _collect_db_sections "$target" "$db_name" _mysql_exec_k8s "$user" "$pass"
}
