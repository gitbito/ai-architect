#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
#
# scripts/lib/progress-output.sh
# -----------------------------------------------------------------------------
# Compact, consistent progress output for lifecycle commands.
#
# Public API:
#   progress_run <label> -- <cmd args...>     Single-step: label, timing, ✓/✗
#   progress_start_multi <total>              Init N-of-M step counter
#   progress_step <label> -- <cmd args...>    [N/M] step inside a multi block
#   progress_end_multi <success_label>        Close the multi block with total
#   progress_fail <label> [log_path]          Shared failure formatter
#
# Output destination: all wrapped commands' stdout/stderr is appended to
# $LOG_FILE -- which defaults to $(get_setup_log) (the canonical setup
# log under $BITOARCH_LOG_DIR). Each invocation is bracketed by
#   [<ts>] === START: <label> ===
#   [<ts>] === END:   <label> rc=<rc> ===
# so individual runs are findable. On failure, the prompt points the
# user at $LOG_FILE with a yellow-wrapped `bitoarch logs` hint.
#
# Design: NO backgrounded spinner subshell. A backgrounded `(while true) &`
# + `kill $!` pattern has a non-deterministic race (macOS in particular)
# where the TERM signal can land on the parent bash itself, killing the
# caller with exit 143 mid-output. We use an in-place line-rewrite pattern
# (terraform/helm-style) instead:
#   write  "[+] <label> ..."      (no newline)
#   run    wrapped cmd silenced to log
#   write  " ✓ done (Ns)\n"       (completes the line)
# On a TTY the final write appends; off-TTY it appends too. Either way the
# user sees exactly one line per step with no risk of signal races.
#
# Reuses RED/GREEN/NC from cli-core.sh (with fallbacks so this lib is safe
# to source from the CDN uninstall bootstrap recovery path).
# -----------------------------------------------------------------------------

if [ -n "${_BITOARCH_PROGRESS_OUTPUT_LOADED:-}" ]; then
    return 0
fi
_BITOARCH_PROGRESS_OUTPUT_LOADED=1

: "${RED:=$'\033[0;31m'}"
: "${GREEN:=$'\033[0;32m'}"
: "${YELLOW:=$'\033[1;33m'}"
: "${NC:=$'\033[0m'}"

# Multi-step state (reset by progress_start_multi).
PROGRESS_STEP=0
PROGRESS_TOTAL=0
PROGRESS_MULTI_START=0

# -----------------------------------------------------------------------------
# Internal: resolve $LOG_FILE. Honors a caller-set value, else asks
# path-manager.sh for the canonical setup log, else falls back to a
# tmp-dir path so progress_run still works in degraded environments
# (CDN uninstall bootstrap recovery). Ensures the parent directory
# exists and the file is writable; on any failure, returns the tmp-dir
# fallback rather than letting the wrapped command's redirect explode.
# -----------------------------------------------------------------------------
_progress_resolve_log_file() {
    # Prefer the canonical setup.log from path-manager.sh over any inherited
    # LOG_FILE -- setup-utils.sh's self-bootstrap default points LOG_FILE at
    # a repo-local path when it's sourced before path-manager.sh has set the
    # canonical one, which would otherwise win and split logs into two files.
    local log_file=""
    if command -v get_setup_log >/dev/null 2>&1; then
        log_file="$(get_setup_log)"
    fi
    if [ -z "$log_file" ]; then
        log_file="${LOG_FILE:-}"
    fi
    if [ -z "$log_file" ]; then
        local tmp_dir="${TMPDIR:-/tmp}"
        log_file="${tmp_dir%/}/bitoarch-setup.log"
    fi
    local log_dir
    log_dir="$(dirname "$log_file")"
    if [ ! -d "$log_dir" ] && ! mkdir -p "$log_dir" 2>/dev/null; then
        local tmp_dir="${TMPDIR:-/tmp}"
        log_file="${tmp_dir%/}/bitoarch-setup.log"
    fi
    if ! touch "$log_file" 2>/dev/null; then
        local tmp_dir="${TMPDIR:-/tmp}"
        log_file="${tmp_dir%/}/bitoarch-setup.log"
        touch "$log_file" 2>/dev/null || true
    fi
    printf '%s' "$log_file"
}

# -----------------------------------------------------------------------------
# Internal: append a timestamped marker line to $LOG_FILE. Uses log_silent
# from setup-utils.sh when available -- which is the canonical case,
# since path-manager.sh transitively sources setup-utils.sh and is
# sourced first by bitoarch.sh. Inline fallback covers the CDN uninstall
# bootstrap recovery path where setup-utils.sh may not be present.
# -----------------------------------------------------------------------------
_progress_log_marker() {
    if command -v log_silent >/dev/null 2>&1; then
        log_silent "$1"
    elif [ -n "${LOG_FILE:-}" ]; then
        echo "[$(date +'%Y-%m-%d %H:%M:%S')] $1" >> "$LOG_FILE" 2>&1
    fi
}

# -----------------------------------------------------------------------------
# Internal: write a start-of-line prefix (no newline). Flushes via printf.
# -----------------------------------------------------------------------------
_progress_emit_start() {
    local label="$1"
    printf '[+] %s ... ' "$label"
}

# -----------------------------------------------------------------------------
# Internal: write the line-completion suffix (with newline).
# Args: rc, elapsed. Reads $LOG_FILE for the failure-prompt path.
# -----------------------------------------------------------------------------
_progress_emit_end() {
    local rc="$1" elapsed="$2"
    case "$rc" in
        0)
            printf '%b✓%b done (%ds)\n' "$GREEN" "$NC" "$elapsed"
            ;;
        2)
            # rc=2 means "soft-timeout / warming up" -- not a failure,
            # not a full success. Caller inspects rc downstream and
            # decides what to print in the body.
            printf '%b⏳%b done (%ds)\n' "$YELLOW" "$NC" "$elapsed"
            ;;
        *)
            printf '%b✗%b failed (%ds) → log: %s (view: %bbitoarch logs%b)\n' \
                "$RED" "$NC" "$elapsed" "${LOG_FILE:-<no-log>}" \
                "$YELLOW" "$NC" >&2
            ;;
    esac
}

# -----------------------------------------------------------------------------
# Public: progress_run <label> -- <cmd args...>
# Pattern: write "[+] label ... " (no \n), run cmd silenced, write "✓/✗ ..."
# Same line. No backgrounded spinner, no signal races.
# -----------------------------------------------------------------------------
progress_run() {
    local label="$1"; shift
    [ "${1:-}" = "--" ] && shift

    if [ -z "$label" ] || [ $# -eq 0 ]; then
        echo "progress_run: usage: progress_run <label> -- <cmd args...>" >&2
        return 2
    fi

    # Resolve and export LOG_FILE so any wrapped function that respects
    # it writes to the same canonical setup log.
    local log_file
    log_file=$(_progress_resolve_log_file)
    export LOG_FILE="$log_file"

    _progress_log_marker "=== START: $label ==="

    local start=$SECONDS
    local rc=0
    if [ -t 1 ] && [ "${BITOARCH_NO_SPINNER:-}" != "1" ]; then
        # Start child in background, silenced.
        (
            COMPOSE_PROGRESS=plain BUILDKIT_PROGRESS=plain \
                "$@" >>"$log_file" 2>&1
        ) &
        local child=$!
        local spinner='⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏'
        local i=0
        # Poll until child exits. `kill -0` only checks for existence.
        while kill -0 "$child" 2>/dev/null; do
            local c=${spinner:$i:1}
            printf '\r[+] %s %s' "$label" "$c"
            i=$(( (i + 1) % ${#spinner} ))
            sleep 0.1
        done
        wait "$child" 2>/dev/null
        rc=$?
        # Clear the spinner line before emitting the final status.
        printf '\r\033[K'
    else
        _progress_emit_start "$label"
        COMPOSE_PROGRESS=plain BUILDKIT_PROGRESS=plain \
            "$@" >>"$log_file" 2>&1 || rc=$?
    fi

    local elapsed=$((SECONDS - start))

    _progress_log_marker "=== END: $label rc=$rc ==="

    # On TTY we already cleared the line; re-emit the full "[+] label ... "
    # prefix so _progress_emit_end can append the ✓/✗ suffix on the same
    # visual line.
    [ -t 1 ] && [ "${BITOARCH_NO_SPINNER:-}" != "1" ] && _progress_emit_start "$label"
    _progress_emit_end "$rc" "$elapsed"
    return "$rc"
}

# -----------------------------------------------------------------------------
# Public: progress_start_multi <total>
# -----------------------------------------------------------------------------
progress_start_multi() {
    PROGRESS_TOTAL="${1:-0}"
    PROGRESS_STEP=0
    PROGRESS_MULTI_START=$SECONDS
}

# -----------------------------------------------------------------------------
# Public: progress_step <label> -- <cmd args...>
# -----------------------------------------------------------------------------
progress_step() {
    local label="$1"; shift
    [ "${1:-}" = "--" ] && shift

    if [ -z "$label" ] || [ $# -eq 0 ]; then
        echo "progress_step: usage: progress_step <label> -- <cmd args...>" >&2
        return 2
    fi

    PROGRESS_STEP=$((PROGRESS_STEP + 1))

    local log_file
    log_file=$(_progress_resolve_log_file)
    export LOG_FILE="$log_file"

    _progress_log_marker "=== START: $label ==="

    local start=$SECONDS

    # Write step prefix (no newline); run silenced; complete the line.
    printf '[%d/%d] %-40s ' "$PROGRESS_STEP" "$PROGRESS_TOTAL" "$label"

    local rc=0
    COMPOSE_PROGRESS=plain BUILDKIT_PROGRESS=plain \
        "$@" >>"$log_file" 2>&1 || rc=$?

    local elapsed=$((SECONDS - start))

    _progress_log_marker "=== END: $label rc=$rc ==="

    if [ "$rc" -eq 0 ]; then
        printf '%b✓%b %4ds\n' "$GREEN" "$NC" "$elapsed"
    else
        printf '%b✗%b %4ds → log: %s (view: %bbitoarch logs%b)\n' \
            "$RED" "$NC" "$elapsed" "$log_file" "$YELLOW" "$NC" >&2
    fi
    return "$rc"
}

# -----------------------------------------------------------------------------
# Public: progress_end_multi <success_label>
# -----------------------------------------------------------------------------
progress_end_multi() {
    local label="${1:-Done}"
    local total=$((SECONDS - PROGRESS_MULTI_START))
    printf '\n%b✓%b %s (%ds total)\n' "$GREEN" "$NC" "$label" "$total"
}

# -----------------------------------------------------------------------------
# Public: progress_fail <label> [log_path]
# Used by callers that report a failure without having run the command
# through progress_run (e.g., a precondition failed). If log_path is
# omitted, falls back to $LOG_FILE (the canonical setup log).
# -----------------------------------------------------------------------------
progress_fail() {
    local label="$1"
    local log_path="${2:-${LOG_FILE:-}}"
    if [ -n "$log_path" ]; then
        printf '[+] %s ... %b✗%b failed → log: %s (view: %bbitoarch logs%b)\n' \
            "$label" "$RED" "$NC" "$log_path" "$YELLOW" "$NC" >&2
    else
        printf '[+] %s ... %b✗%b failed\n' "$label" "$RED" "$NC" >&2
    fi
}
