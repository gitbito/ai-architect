#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
#
# scripts/lib/auto-recovery/runners/daily-runner.sh
# Cert-cron scheduler entrypoint: cert renewal check + self-heal pass.
# Always exits 0 (non-zero marks the scheduler unit as failed).

# The cert-renew unit invokes us with `mcp-cert renew --check` args (so the
# bitoarch-CLI fallback in _cert_cron_invocation_target keeps working). This
# runner ignores its own $@, but sourced libs run at file scope with our $@
# visible — clear positional params first so they can't leak.
set --

# Scheduler contexts (LaunchAgent / systemd-user / cron) ship a minimal PATH.
export PATH="/usr/local/bin:/opt/homebrew/bin:${HOME}/.local/bin:/usr/bin:/bin:${PATH:-}"

# path-manager.sh references SCRIPT_DIR at file-scope; anchor from here.
_self_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
_module_dir="$(cd "${_self_dir}/.." && pwd)"
_lib_dir="$(cd "${_module_dir}/.." && pwd)"
_install_root="$(cd "${_lib_dir}/../.." && pwd)"
SCRIPT_DIR="${SCRIPT_DIR:-${_install_root}}"
PLATFORM_DIR="${PLATFORM_DIR:-${_install_root}}"
export SCRIPT_DIR PLATFORM_DIR

# shellcheck disable=SC1091
[ -f "${_install_root}/scripts/lib/path-manager.sh" ] && \
    source "${_install_root}/scripts/lib/path-manager.sh"
# shellcheck disable=SC1091
[ -f "${_lib_dir}/bitoarch-config.sh" ] && \
    source "${_lib_dir}/bitoarch-config.sh" 2>/dev/null || true
# shellcheck disable=SC1091
[ -f "${_module_dir}/self-heal.sh" ] && \
    source "${_module_dir}/self-heal.sh" 2>/dev/null || true

LOG_DIR="$(command -v get_log_dir >/dev/null 2>&1 && get_log_dir \
          || echo "${HOME}/.local/bitoarch/var/logs")"
mkdir -p "$LOG_DIR" 2>/dev/null || true
# Align log_silent's $LOG_FILE (set by setup-utils.sh to scripts/var/logs/…)
# with the canonical setup.log under get_log_dir so all output converges.
export LOG_FILE="$LOG_DIR/setup.log"
exec >> "$LOG_FILE" 2>&1

echo "[$(date -u +%FT%TZ)] auto-recovery/daily-runner: starting"

BITOARCH="$(command -v bitoarch || echo "${HOME}/.local/bin/bitoarch")"
if [ ! -x "$BITOARCH" ]; then
    echo "[$(date -u +%FT%TZ)] auto-recovery/daily-runner: bitoarch CLI missing; exiting"
    exit 0
fi

if "$BITOARCH" mcp-cert renew --check; then
    echo "[$(date -u +%FT%TZ)] auto-recovery/daily-runner: cert renew check completed (rc=0)"
else
    echo "[$(date -u +%FT%TZ)] auto-recovery/daily-runner: cert renew check non-zero exit (rc=$?, continuing)"
fi

if command -v self_heal_run >/dev/null 2>&1; then
    self_heal_run "$BITOARCH"
else
    echo "[$(date -u +%FT%TZ)] auto-recovery/daily-runner: self_heal_run unavailable; skipping"
fi

echo "[$(date -u +%FT%TZ)] auto-recovery/daily-runner: complete"
exit 0
