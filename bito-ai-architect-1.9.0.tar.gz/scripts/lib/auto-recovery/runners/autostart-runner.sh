#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
#
# scripts/lib/auto-recovery/runners/autostart-runner.sh
# Login-scheduler entrypoint. Always exits 0 (non-zero re-triggers the unit).

# Defensive: clear positional params so sourced libs at file scope can't see
# any args the scheduler unit may have been configured to pass.
set --

# Scheduler contexts (LaunchAgent / systemd-user / cron) ship a minimal PATH.
export PATH="/usr/local/bin:/opt/homebrew/bin:${HOME}/.local/bin:/usr/bin:/bin:${PATH:-}"

# path-manager.sh references SCRIPT_DIR at file-scope; scheduler context
# doesn't set it, so anchor from this file's own location.
_self_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
_install_root="$(cd "${_self_dir}/../../../.." && pwd)"
SCRIPT_DIR="${SCRIPT_DIR:-${_install_root}}"
PLATFORM_DIR="${PLATFORM_DIR:-${_install_root}}"
export SCRIPT_DIR PLATFORM_DIR

# shellcheck disable=SC1091
[ -f "${_install_root}/scripts/lib/path-manager.sh" ] && \
    source "${_install_root}/scripts/lib/path-manager.sh"
# shellcheck disable=SC1091
[ -f "${_install_root}/scripts/lib/bitoarch-config.sh" ] && \
    source "${_install_root}/scripts/lib/bitoarch-config.sh" 2>/dev/null || true
# shellcheck disable=SC1091
[ -f "${_install_root}/scripts/prerequisites-manager.sh" ] && \
    source "${_install_root}/scripts/prerequisites-manager.sh"
# shellcheck disable=SC1091
[ -f "${_install_root}/scripts/lib/auto-recovery/self-heal.sh" ] && \
    source "${_install_root}/scripts/lib/auto-recovery/self-heal.sh"

LOG_DIR="$(command -v get_log_dir >/dev/null 2>&1 && get_log_dir \
          || echo "${HOME}/.local/bitoarch/var/logs")"
mkdir -p "$LOG_DIR" 2>/dev/null || true
# Align log_silent's $LOG_FILE (set by setup-utils.sh to scripts/var/logs/…)
# with the canonical setup.log under get_log_dir so all output converges.
export LOG_FILE="$LOG_DIR/setup.log"
exec >> "$LOG_FILE" 2>&1

echo "[$(date -u +%FT%TZ)] auto-recovery/autostart-runner: starting"

# Run-time opt-out: respect BITOARCH_AUTORECOVERY=false even after install.
if command -v auto_recovery_enabled >/dev/null 2>&1 && ! auto_recovery_enabled; then
    echo "[$(date -u +%FT%TZ)] auto-recovery/autostart-runner: auto-recovery disabled; skipping"
    exit 0
fi

if command -v ensure_docker_running >/dev/null 2>&1; then
    if ! ensure_docker_running 180; then
        echo "[$(date -u +%FT%TZ)] auto-recovery/autostart-runner: Docker not ready after 180s; exiting"
        exit 0
    fi
else
    for _ in $(seq 1 60); do
        docker info >/dev/null 2>&1 && break
        sleep 2
    done
    if ! docker info >/dev/null 2>&1; then
        echo "[$(date -u +%FT%TZ)] auto-recovery/autostart-runner: Docker not ready after 120s; exiting"
        exit 0
    fi
fi

BITOARCH="$(command -v bitoarch || echo "${HOME}/.local/bin/bitoarch")"
if [ ! -x "$BITOARCH" ]; then
    echo "[$(date -u +%FT%TZ)] auto-recovery/autostart-runner: bitoarch CLI not found; exiting"
    exit 0
fi

# Engine's restart=unless-stopped does cold-start; runner's only job here
# is partial-failure recovery once the engine has reconciled.
if command -v self_heal_after_boot >/dev/null 2>&1; then
    self_heal_after_boot "$BITOARCH"
    echo "[$(date -u +%FT%TZ)] auto-recovery/autostart-runner: self_heal_after_boot completed (rc=$?)"
else
    echo "[$(date -u +%FT%TZ)] auto-recovery/autostart-runner: self_heal_after_boot unavailable; skipping recovery"
fi
exit 0
