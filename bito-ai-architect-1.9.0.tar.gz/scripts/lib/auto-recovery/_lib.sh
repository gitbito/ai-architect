#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
#
# scripts/lib/auto-recovery/_lib.sh
# Internal helpers for the auto-recovery module.

if [ -n "${_BITOARCH_AUTO_RECOVERY_LIB_LOADED:-}" ]; then
    return 0
fi
_BITOARCH_AUTO_RECOVERY_LIB_LOADED=1

if ! command -v log_silent >/dev/null 2>&1; then log_silent() { :; }; fi

_ar_platform() {
    case "$(uname -s)" in
        Darwin) echo "macos" ;;
        Linux)
            if grep -qiE 'microsoft|wsl' /proc/version 2>/dev/null; then
                echo "wsl"
            else
                echo "linux"
            fi
            ;;
        *) echo "unknown" ;;
    esac
}

_ar_bitoarch_bin() {
    local candidate
    for candidate in "${HOME}/.local/bin/bitoarch" "/usr/local/bin/bitoarch"; do
        [ -x "$candidate" ] && { echo "$candidate"; return 0; }
    done
    if [ -n "${PLATFORM_DIR:-}" ] && [ -x "${PLATFORM_DIR}/scripts/bitoarch.sh" ]; then
        echo "${PLATFORM_DIR}/scripts/bitoarch.sh"
        return 0
    fi
    if [ -n "${SCRIPT_DIR:-}" ] && [ -x "${SCRIPT_DIR}/scripts/bitoarch.sh" ]; then
        echo "${SCRIPT_DIR}/scripts/bitoarch.sh"
        return 0
    fi
    echo ""
    return 1
}

_ar_log_dir() {
    if command -v get_log_dir >/dev/null 2>&1; then
        get_log_dir
    else
        echo "${HOME}/.local/bitoarch/var/logs"
    fi
}

_ar_systemd_available() {
    command -v systemctl >/dev/null 2>&1 && \
        systemctl --user list-units --no-pager >/dev/null 2>&1
}

# Caller passes pairs: KEY value KEY value...
_ar_render() {
    local template="$1"; shift
    local sed_args=()
    while [ $# -ge 2 ]; do
        sed_args+=(-e "s|{{$1}}|$2|g")
        shift 2
    done
    sed "${sed_args[@]}" "$template"
}
