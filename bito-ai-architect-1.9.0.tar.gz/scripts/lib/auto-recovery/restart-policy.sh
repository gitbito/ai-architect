#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
#
# scripts/lib/auto-recovery/restart-policy.sh
# Tier 1: silent in-place migration of the legacy RESTART_POLICY default.

if [ -n "${_BITOARCH_RESTART_POLICY_LIB_LOADED:-}" ]; then
    return 0
fi
_BITOARCH_RESTART_POLICY_LIB_LOADED=1

if ! command -v log_silent >/dev/null 2>&1; then log_silent() { :; }; fi

restart_policy_migrate() {
    local env_file
    if command -v get_config_file >/dev/null 2>&1; then
        env_file="$(get_config_file 2>/dev/null)"
    fi
    [ -n "${env_file:-}" ] && [ -f "$env_file" ] || return 0

    if grep -qE '^RESTART_POLICY_MIGRATION_DONE=1$' "$env_file" 2>/dev/null; then
        log_silent "auto-recovery: RESTART_POLICY migration already applied; skipping"
        return 0
    fi

    if grep -qE '^RESTART_POLICY=on-failure:3$' "$env_file" 2>/dev/null; then
        if sed -i.bak -E 's|^RESTART_POLICY=on-failure:3$|RESTART_POLICY=unless-stopped|' "$env_file" 2>/dev/null; then
            rm -f "${env_file}.bak" 2>/dev/null
            log_silent "auto-recovery: migrated RESTART_POLICY: on-failure:3 -> unless-stopped"
        else
            rm -f "${env_file}.bak" 2>/dev/null
            log_silent "auto-recovery: RESTART_POLICY migration sed failed; leaving env unchanged"
            return 0
        fi
    fi

    {
        echo ""
        echo "# Internal marker -- set by install_run; do not edit"
        echo "RESTART_POLICY_MIGRATION_DONE=1"
    } >> "$env_file" 2>/dev/null
    log_silent "auto-recovery: RESTART_POLICY migration marker written"
}

export -f restart_policy_migrate
