#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
#
# scripts/lib/auto-recovery/autostart.sh
# Tier 2: register a login-time scheduler unit that runs `bitoarch start`.

if [ -n "${_BITOARCH_AUTOSTART_LIB_LOADED:-}" ]; then
    return 0
fi
_BITOARCH_AUTOSTART_LIB_LOADED=1

# Private anchor for this file -- used internally so we never clobber the
# caller's SCRIPT_DIR (which is set to scripts/ in some call paths and to
# the project root in others).
_AUTOSTART_ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
PLATFORM_DIR="${PLATFORM_DIR:-${_AUTOSTART_ROOT_DIR}}"

if [ -f "${_AUTOSTART_ROOT_DIR}/scripts/lib/path-manager.sh" ]; then
    # shellcheck disable=SC1091
    source "${_AUTOSTART_ROOT_DIR}/scripts/lib/path-manager.sh"
fi
if [ -f "$(dirname "${BASH_SOURCE[0]}")/_lib.sh" ]; then
    # shellcheck disable=SC1091
    source "$(dirname "${BASH_SOURCE[0]}")/_lib.sh"
fi

if ! command -v log_silent >/dev/null 2>&1; then log_silent() { :; }; fi

_AUTOSTART_LABEL="ai.bito.bitoarch-start"
_AUTOSTART_UNIT="bitoarch-start"
_AUTOSTART_SENTINEL="# BITOARCH_AUTOSTART"
_AUTOSTART_RUNNER="${PLATFORM_DIR}/scripts/lib/auto-recovery/runners/autostart-runner.sh"

_autostart_template_dir() {
    echo "${_AUTOSTART_ROOT_DIR}/scripts/lib/scheduler"
}

_autostart_install_macos() {
    local template plist_dest log_dir
    template="$(_autostart_template_dir)/${_AUTOSTART_LABEL}.plist.template"
    plist_dest="${HOME}/Library/LaunchAgents/${_AUTOSTART_LABEL}.plist"
    log_dir="$(_ar_log_dir)"

    [ -f "$template" ] || {
        log_silent "autostart: launchd template missing at $template"
        return 1
    }

    mkdir -p "$(dirname "$plist_dest")" "$log_dir" 2>/dev/null || true
    chmod +x "$_AUTOSTART_RUNNER" 2>/dev/null || true

    # unload before rewriting so launchd picks up the new plist
    launchctl unload "$plist_dest" 2>/dev/null || true

    if ! _ar_render "$template" \
            BITOARCH_BIN "$_AUTOSTART_RUNNER" \
            LOG_DIR      "$log_dir" \
            > "$plist_dest" 2>/dev/null; then
        log_silent "autostart: failed to render launchd plist"
        return 1
    fi

    if launchctl load "$plist_dest" 2>/dev/null; then
        log_silent "autostart: scheduled via launchd (${_AUTOSTART_LABEL})"
    else
        log_silent "autostart: launchctl load failed; plist in place at ${plist_dest}"
    fi
    return 0
}

_autostart_uninstall_macos() {
    local plist_dest="${HOME}/Library/LaunchAgents/${_AUTOSTART_LABEL}.plist"
    [ -f "$plist_dest" ] || return 0
    launchctl unload "$plist_dest" 2>/dev/null || true
    rm -f "$plist_dest" 2>/dev/null
    log_silent "autostart: removed launchd agent ${_AUTOSTART_LABEL}"
    return 0
}

_autostart_install_systemd() {
    local svc_t sysd_dir svc_dest log_dir
    svc_t="$(_autostart_template_dir)/${_AUTOSTART_UNIT}.service.template"
    [ -f "$svc_t" ] || return 1
    sysd_dir="${XDG_CONFIG_HOME:-${HOME}/.config}/systemd/user"
    log_dir="$(_ar_log_dir)"

    mkdir -p "$sysd_dir" "$log_dir" 2>/dev/null || true
    chmod +x "$_AUTOSTART_RUNNER" 2>/dev/null || true
    svc_dest="${sysd_dir}/${_AUTOSTART_UNIT}.service"

    _ar_render "$svc_t" \
        BITOARCH_BIN "$_AUTOSTART_RUNNER" \
        LOG_DIR      "$log_dir" \
        > "$svc_dest" 2>/dev/null || return 1

    systemctl --user daemon-reload 2>/dev/null || return 1
    systemctl --user enable "${_AUTOSTART_UNIT}.service" >/dev/null 2>&1 || return 1
    log_silent "autostart: scheduled via systemd-user (${_AUTOSTART_UNIT}.service)"
    return 0
}

_autostart_install_cron() {
    command -v crontab >/dev/null 2>&1 || return 1
    chmod +x "$_AUTOSTART_RUNNER" 2>/dev/null || true
    local line tmp
    line="@reboot ${_AUTOSTART_RUNNER} ${_AUTOSTART_SENTINEL}"
    tmp="$(mktemp)" || return 1
    crontab -l 2>/dev/null | grep -v "${_AUTOSTART_SENTINEL}" > "$tmp" || true
    echo "$line" >> "$tmp"
    if crontab "$tmp" 2>/dev/null; then
        rm -f "$tmp"
        log_silent "autostart: scheduled via crontab @reboot"
        return 0
    fi
    rm -f "$tmp"
    return 1
}

_autostart_install_linux() {
    if _ar_systemd_available && _autostart_install_systemd; then
        return 0
    fi
    log_silent "autostart: systemd-user unavailable; trying crontab"
    if _autostart_install_cron; then
        return 0
    fi
    log_silent "autostart: neither systemd-user nor crontab available; skipped"
    return 0
}

_autostart_uninstall_linux() {
    local sysd_dir tmp
    sysd_dir="${XDG_CONFIG_HOME:-${HOME}/.config}/systemd/user"
    if [ -f "${sysd_dir}/${_AUTOSTART_UNIT}.service" ]; then
        if command -v systemctl >/dev/null 2>&1; then
            systemctl --user disable --now "${_AUTOSTART_UNIT}.service" 2>/dev/null || true
        fi
        rm -f "${sysd_dir}/${_AUTOSTART_UNIT}.service" 2>/dev/null
        if command -v systemctl >/dev/null 2>&1; then
            systemctl --user daemon-reload 2>/dev/null || true
        fi
        log_silent "autostart: removed systemd-user unit ${_AUTOSTART_UNIT}.service"
    fi
    if command -v crontab >/dev/null 2>&1 && \
       crontab -l 2>/dev/null | grep -q "${_AUTOSTART_SENTINEL}"; then
        tmp="$(mktemp)" || return 0
        crontab -l 2>/dev/null | grep -v "${_AUTOSTART_SENTINEL}" > "$tmp" || true
        if [ -s "$tmp" ]; then
            crontab "$tmp" 2>/dev/null || true
        else
            crontab -r 2>/dev/null || true
        fi
        rm -f "$tmp"
        log_silent "autostart: removed crontab @reboot entry"
    fi
    return 0
}

# Standalone-only via auto_recovery_enabled gate.
autostart_install() {
    if ! command -v auto_recovery_enabled >/dev/null 2>&1; then
        log_silent "autostart: auto_recovery_enabled predicate not loaded; skipping install"
        return 0
    fi
    if ! auto_recovery_enabled; then
        log_silent "autostart: auto-recovery disabled (BITOARCH_AUTORECOVERY != true); skipping install"
        return 0
    fi

    case "$(_ar_platform)" in
        macos)     _autostart_install_macos ;;
        linux|wsl) _autostart_install_linux ;;
        *)
            log_silent "autostart: unsupported platform ($(uname -s)); skipping"
            return 0
            ;;
    esac
    return 0
}

# Unconditional + idempotent; no-op-safe on absent units.
autostart_uninstall() {
    case "$(_ar_platform)" in
        macos)     _autostart_uninstall_macos ;;
        linux|wsl) _autostart_uninstall_linux ;;
    esac
    return 0
}

export -f autostart_install
export -f autostart_uninstall
