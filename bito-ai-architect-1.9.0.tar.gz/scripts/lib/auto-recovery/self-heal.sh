#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
#
# scripts/lib/auto-recovery/self-heal.sh
# Partial-failure detection + recovery for the AI Architect container set.
# Recovery action is `bitoarch restart` (compose stop + up -d) -- the only
# CLI path that re-fires depends_on. `bitoarch start` (= `up -d`) no-ops
# against existing-but-crashing containers and leaves the loop intact.

if [ -n "${_BITOARCH_SELF_HEAL_LIB_LOADED:-}" ]; then
    return 0
fi
_BITOARCH_SELF_HEAL_LIB_LOADED=1

if ! command -v log_silent >/dev/null 2>&1; then log_silent() { :; }; fi

# ----- internals -------------------------------------------------------------

_self_heal_preflight() {
    local bin="$1" tag="$2"

    if [ ! -x "${bin:-}" ]; then
        log_silent "${tag}: bitoarch CLI missing; skipping"
        return 1
    fi
    if ! command -v auto_recovery_enabled >/dev/null 2>&1 || ! auto_recovery_enabled; then
        log_silent "${tag}: auto-recovery disabled; skipping"
        return 1
    fi
    if ! docker info >/dev/null 2>&1; then
        log_silent "${tag}: Docker not running; skipping"
        return 1
    fi
    return 0
}

# $1 ∈ {running (default), any}. "any" passes -a to include non-running states.
_self_heal_container_count() {
    if [ "${1:-running}" = "any" ]; then
        docker ps -a --filter "name=ai-architect-" -q 2>/dev/null | wc -l | tr -d ' '
    else
        docker ps    --filter "name=ai-architect-" -q 2>/dev/null | wc -l | tr -d ' '
    fi
}

# Budget tunable via BITOARCH_AUTOSTART_SETTLE_SECS for slower hardware.
_self_heal_wait_for_engine_settle() {
    local budget="${BITOARCH_AUTOSTART_SETTLE_SECS:-180}"
    local elapsed=0
    while [ "$elapsed" -lt "$budget" ]; do
        [ "$(_self_heal_container_count running)" -gt 0 ] && return 0
        sleep 3
        elapsed=$((elapsed + 3))
    done
    return 1
}

_self_heal_act_on_health() {
    local bin="$1" running="$2"
    if "$bin" health >/dev/null 2>&1; then
        log_silent "self-heal: services healthy"
        return 0
    fi
    log_silent "self-heal: partial failure detected (${running} containers up); running bitoarch restart"
    "$bin" restart
    local rc=$?
    log_silent "self-heal: bitoarch restart completed (rc=${rc})"
    return "$rc"
}

# ----- public API ------------------------------------------------------------

# Zero running is treated as deliberate `bitoarch stop` -- not a failure.
self_heal_run() {
    local bin="$1"

    _self_heal_preflight "$bin" "self-heal" || return 0

    local running
    running=$(_self_heal_container_count running)
    if [ "${running:-0}" = "0" ]; then
        log_silent "self-heal: zero containers running (likely user intent); skipping"
        return 0
    fi

    _self_heal_act_on_health "$bin" "$running"
    return 0
}

# Engine reconciliation is async after `docker info` returns; wait for at
# least one container to come up before letting self_heal_run decide.
self_heal_after_boot() {
    local bin="$1"

    _self_heal_preflight "$bin" "self-heal-after-boot" || return 0

    # Zero known = fresh install / post-reset; nothing to recover.
    if [ "$(_self_heal_container_count any)" -eq 0 ]; then
        log_silent "self-heal-after-boot: no ai-architect-* containers known; nothing to recover"
        return 0
    fi

    if ! _self_heal_wait_for_engine_settle; then
        log_silent "self-heal-after-boot: settle budget exhausted; deferring to self_heal_run guard"
    fi

    # Crash-loop manifest window: cis-manager nil-derefs within ~2s of
    # the first Temporal namespace lookup; without this pause `bitoarch
    # health` sees "starting" and misses the partial-failure signal.
    sleep 15

    self_heal_run "$bin"
}

export -f self_heal_run self_heal_after_boot
