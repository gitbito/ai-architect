#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
# Bito's AI Architect CLI - Shared async terminal loader.
#
# Single source of truth for show_loader / stop_loader, extracted from
# setup-utils.sh so consumers that aren't downstream of setup-utils (e.g. the
# diagnose bundler) can reuse the same spinner instead of duplicating it.
# Both setup-utils.sh and scripts/lib/diagnose/common.sh source this file.
#
# Output matches progress_run's format:
#   [+] <label> ⠙                   (animated while running, on a TTY)
#   [+] <label> ... ✓ done (Ns)     (final line on stop_loader)
# Off a TTY (CI / pipes) it degrades to a single static line.

if [ -n "${_BITOARCH_LOADER_LOADED:-}" ]; then
    return 0
fi
_BITOARCH_LOADER_LOADED=1

# Global state for the async loader.
LOADER_PID=""
LOADER_LABEL=""
LOADER_START=0
# "tty"  when we spawned an animated spinner (need to reprint prefix on stop)
# "nontty" when we pre-printed the prefix statically (only append suffix on stop)
LOADER_MODE=""

# Echoes spinner frames for the current locale, one per line: braille on a
# UTF-8 terminal, ASCII fallback on LANG=C / POSIX so it doesn't render as
# `?` / mojibake on minimal servers, busybox, or bastion shells.
_loader_frames() {
    case "${LC_ALL:-}${LC_CTYPE:-}${LANG:-}" in
        *UTF-8*|*UTF8*|*utf-8*|*utf8*) printf '%s\n' '⠋' '⠙' '⠹' '⠸' '⠼' '⠴' '⠦' '⠧' '⠇' '⠏' ;;
        *)                             printf '%s\n' '|' '/' '-' '\' ;;
    esac
}

show_loader() {
    local message="$1"
    LOADER_LABEL="$message"
    LOADER_START=$SECONDS
    # Off a TTY (CI / pipes): print a single static start line, no spinner.
    # Pre-printing the prefix here means stop_loader only appends the suffix
    # ("✓ done (Ns)\n") to the same line.
    if [ ! -t 1 ] || [ "${BITOARCH_NO_SPINNER:-}" = "1" ]; then
        printf '[+] %s ... ' "$message"
        LOADER_PID=""
        LOADER_MODE="nontty"
        return
    fi
    LOADER_MODE="tty"
    local _frames=() _f
    while IFS= read -r _f; do _frames+=("$_f"); done < <(_loader_frames)
    (
        while true; do
            for s in "${_frames[@]}"; do
                printf '\r[+] %s %s' "$message" "$s"
                sleep 0.1
            done
        done
    ) &
    LOADER_PID=$!
}

# stop_loader [rc]
#   Stops the async spinner started by show_loader and emits a final line
#   in the progress_run format:  "[+] <label> ... ✓ done (Ns)" on rc=0,
#   "[+] <label> ... ✗ failed (Ns)" otherwise. No final line is emitted
#   when show_loader wasn't called (safe no-op). Idempotent across calls.
stop_loader() {
    local rc="${1:-0}"
    if [[ -n "$LOADER_PID" ]]; then
        kill "$LOADER_PID" >/dev/null 2>&1
        wait "$LOADER_PID" 2>/dev/null
        LOADER_PID=""
        # Clear the spinner line before printing the final status.
        printf '\r\033[K'
    fi
    if [ -n "$LOADER_LABEL" ]; then
        local elapsed=$((SECONDS - LOADER_START))
        if [ "$LOADER_MODE" = "nontty" ]; then
            # Prefix was already printed by show_loader; only append suffix.
            if [ "$rc" -eq 0 ]; then
                printf '%b✓%b done (%ds)\n' "${GREEN:-}" "${NC:-}" "$elapsed"
            else
                printf '%b✗%b failed (%ds)\n' "${RED:-}" "${NC:-}" "$elapsed" >&2
            fi
        else
            # TTY: spinner line was cleared above; re-emit the full line.
            if [ "$rc" -eq 0 ]; then
                printf '[+] %s ... %b✓%b done (%ds)\n' \
                    "$LOADER_LABEL" "${GREEN:-}" "${NC:-}" "$elapsed"
            else
                printf '[+] %s ... %b✗%b failed (%ds)\n' \
                    "$LOADER_LABEL" "${RED:-}" "${NC:-}" "$elapsed" >&2
            fi
        fi
        LOADER_LABEL=""
        LOADER_START=0
        LOADER_MODE=""
    fi
}
