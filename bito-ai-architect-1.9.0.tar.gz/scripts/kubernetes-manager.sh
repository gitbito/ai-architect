#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# Kubernetes Manager - Helper functions for K8s operations
# Used by setup.sh and upgrade.sh for Kubernetes deployments

# Detect OS
detect_os() {
    if [[ "$OSTYPE" == "darwin"* ]]; then
        echo "macos"
    elif [[ -f /etc/os-release ]]; then
        . /etc/os-release
        if [[ "$ID" == "ubuntu" ]]; then
            echo "ubuntu-$VERSION_ID"
        else
            echo "linux"
        fi
    else
        echo "unknown"
    fi
}

# Install kubectl on macOS
install_kubectl_macos() {
    print_info "Installing kubectl on macOS..."
    
    if command -v brew >/dev/null 2>&1; then
        if brew install kubectl >> "$LOG_FILE" 2>&1; then
            print_status "kubectl installed via Homebrew"
            return 0
        fi
    else
        # Fallback: direct download
        print_info "Homebrew not found, installing kubectl directly..."
        local kubectl_bin="/usr/local/bin/kubectl"
        
        if curl -LO "https://dl.k8s.io/release/$(curl -L -s https://dl.k8s.io/release/stable.txt)/bin/darwin/amd64/kubectl" >> "$LOG_FILE" 2>&1; then
            chmod +x kubectl
            sudo mv kubectl "$kubectl_bin" 2>/dev/null || mv kubectl "$HOME/.local/bin/kubectl"
            print_status "kubectl installed to $kubectl_bin"
            return 0
        fi
    fi
    
    return 1
}

# Install kubectl on Ubuntu
install_kubectl_ubuntu() {
    print_info "Installing kubectl on Ubuntu..."
    
    # Add Kubernetes apt repository
    if ! curl -fsSL https://pkgs.k8s.io/core:/stable:/v1.28/deb/Release.key | sudo gpg --dearmor -o /etc/apt/keyrings/kubernetes-apt-keyring.gpg >> "$LOG_FILE" 2>&1; then
        print_error "Failed to add Kubernetes GPG key"
        return 1
    fi
    
    echo 'deb [signed-by=/etc/apt/keyrings/kubernetes-apt-keyring.gpg] https://pkgs.k8s.io/core:/stable:/v1.28/deb/ /' | \
        sudo tee /etc/apt/sources.list.d/kubernetes.list >> "$LOG_FILE" 2>&1
    
    if sudo apt-get update >> "$LOG_FILE" 2>&1 && sudo apt-get install -y kubectl >> "$LOG_FILE" 2>&1; then
        print_status "kubectl installed via apt"
        return 0
    fi
    
    return 1
}

# Install helm on macOS
install_helm_macos() {
    print_info "Installing helm on macOS..."
    
    if command -v brew >/dev/null 2>&1; then
        if brew install helm >> "$LOG_FILE" 2>&1; then
            print_status "helm installed via Homebrew"
            return 0
        fi
    else
        # Fallback: direct download
        print_info "Homebrew not found, installing helm directly..."
        if curl -fsSL https://raw.githubusercontent.com/helm/helm/main/scripts/get-helm-3 | bash >> "$LOG_FILE" 2>&1; then
            print_status "helm installed"
            return 0
        fi
    fi
    
    return 1
}

# Install helm on Ubuntu
install_helm_ubuntu() {
    print_info "Installing helm on Ubuntu..."
    
    # Use official installation script
    if curl -fsSL https://raw.githubusercontent.com/helm/helm/main/scripts/get-helm-3 | bash >> "$LOG_FILE" 2>&1; then
        print_status "helm installed"
        return 0
    fi
    
    return 1
}

# Auto-install missing tools
auto_install_k8s_tools() {
    local os=$(detect_os)
    local tools_installed=0
    
    print_info "Detected OS: $os"
    
    # Check and install kubectl
    if ! command -v kubectl >/dev/null 2>&1; then
        echo ""
        print_warning "kubectl is not installed"
        read -p "Would you like to install kubectl automatically? (y/N): " -r install_kubectl
        
        if [[ "$install_kubectl" =~ ^[Yy]$ ]]; then
            case "$os" in
                macos)
                    if install_kubectl_macos; then
                        tools_installed=$((tools_installed + 1))
                    else
                        print_error "Failed to install kubectl"
                        print_info "Manual installation: https://kubernetes.io/docs/tasks/tools/install-kubectl-macos/"
                        return 1
                    fi
                    ;;
                ubuntu-*)
                    if install_kubectl_ubuntu; then
                        tools_installed=$((tools_installed + 1))
                    else
                        print_error "Failed to install kubectl"
                        print_info "Manual installation: https://kubernetes.io/docs/tasks/tools/install-kubectl-linux/"
                        return 1
                    fi
                    ;;
                *)
                    print_error "Unsupported OS for auto-installation: $os"
                    print_info "Manual installation: https://kubernetes.io/docs/tasks/tools/"
                    return 1
                    ;;
            esac
        else
            print_info "Skipping kubectl installation"
            print_info "Install manually: https://kubernetes.io/docs/tasks/tools/"
            return 1
        fi
    else
        print_status "kubectl is already installed"
    fi
    
    # Check and install helm
    if ! command -v helm >/dev/null 2>&1; then
        echo ""
        print_warning "helm is not installed"
        read -p "Would you like to install helm automatically? (y/N): " -r install_helm
        
        if [[ "$install_helm" =~ ^[Yy]$ ]]; then
            case "$os" in
                macos)
                    if install_helm_macos; then
                        tools_installed=$((tools_installed + 1))
                    else
                        print_error "Failed to install helm"
                        print_info "Manual installation: https://helm.sh/docs/intro/install/"
                        return 1
                    fi
                    ;;
                ubuntu-*)
                    if install_helm_ubuntu; then
                        tools_installed=$((tools_installed + 1))
                    else
                        print_error "Failed to install helm"
                        print_info "Manual installation: https://helm.sh/docs/intro/install/"
                        return 1
                    fi
                    ;;
                *)
                    print_error "Unsupported OS for auto-installation: $os"
                    print_info "Manual installation: https://helm.sh/docs/intro/install/"
                    return 1
                    ;;
            esac
        else
            print_info "Skipping helm installation"
            print_info "Install manually: https://helm.sh/docs/intro/install/"
            return 1
        fi
    else
        print_status "helm is already installed"
    fi
    
    if [ $tools_installed -gt 0 ]; then
        echo ""
        print_status "Installed $tools_installed tool(s) successfully"
        echo ""
    fi
    
    return 0
}

# Check Kubernetes prerequisites
check_k8s_prerequisites() {
    print_info "Checking Kubernetes prerequisites..."
    
    # Check if tools are installed
    local kubectl_installed=false
    local helm_installed=false
    
    command -v kubectl >/dev/null 2>&1 && kubectl_installed=true
    command -v helm >/dev/null 2>&1 && helm_installed=true
    
    # If tools are missing, offer to install
    if ! $kubectl_installed || ! $helm_installed; then
        print_warning "Some Kubernetes tools are missing"
        
        if ! auto_install_k8s_tools; then
            return 1
        fi
    fi
    
    # Verify installations
    if ! command -v kubectl >/dev/null 2>&1; then
        print_error "kubectl is still not available after installation attempt"
        return 1
    fi
    
    if ! command -v helm >/dev/null 2>&1; then
        print_error "helm is still not available after installation attempt"
        return 1
    fi
    
    # Modern kubectl version detection (v1.28+ compatible, macOS & Linux)
    local kubectl_version=""
    if command -v kubectl >/dev/null 2>&1; then
        # Try JSON output first (most reliable)
        kubectl_version=$(kubectl version --client -o json 2>/dev/null | jq -r '.clientVersion.gitVersion' 2>/dev/null || echo "")
        
        # Fallback: parse text output without deprecated --short flag
        if [[ -z "$kubectl_version" ]]; then
            kubectl_version=$(kubectl version --client 2>/dev/null | grep -oE 'v[0-9]+\.[0-9]+\.[0-9]+' | head -1 || echo "")
        fi
        
        # Only log if successfully detected (no error log if detection fails)
        if [[ -n "$kubectl_version" ]]; then
            print_status "kubectl version: $kubectl_version"
        fi
    fi
    
    # Helm version detection (already uses modern syntax)
    local helm_version=""
    if command -v helm >/dev/null 2>&1; then
        helm_version=$(helm version --short 2>/dev/null || echo "")
        if [[ -n "$helm_version" ]]; then
            print_status "helm version: $helm_version"
        fi
    fi
    
    # Check cluster connectivity
    if ! kubectl cluster-info >/dev/null 2>&1; then
        print_error "Cannot connect to Kubernetes cluster"
        echo ""
        echo "Please ensure:"
        echo "  1. Kubernetes cluster is running"
        echo "  2. kubectl is configured correctly"
        echo "  3. Current context is set: kubectl config current-context"
        echo ""
        return 1
    fi
    
    local current_context=$(kubectl config current-context 2>/dev/null || echo "unknown")
    print_status "Connected to cluster: $current_context"
    
    # Check if user has permissions
    if ! kubectl auth can-i create namespaces >/dev/null 2>&1; then
        print_warning "Limited cluster permissions detected"
        print_info "You may need admin rights to create namespaces and resources"
    fi
    
    return 0
}

# Check NodePort availability
check_nodeport_availability() {
    local port=$1
    local service_name=$2
    
    # Get all NodePort services across all namespaces
    local existing=$(kubectl get svc --all-namespaces -o json 2>/dev/null | \
        jq -r '.items[] | select(.spec.type=="NodePort") | .spec.ports[] | .nodePort' 2>/dev/null | \
        grep "^${port}$" || echo "")
    
    if [ -n "$existing" ]; then
        return 1  # Port in use
    fi
    return 0  # Port available
}

# Get cluster storage classes
get_storage_classes() {
    kubectl get storageclass -o jsonpath='{.items[*].metadata.name}' 2>/dev/null || echo ""
}

# Get default storage class
get_default_storage_class() {
    kubectl get storageclass -o json 2>/dev/null | \
        jq -r '.items[] | select(.metadata.annotations["storageclass.kubernetes.io/is-default-class"]=="true") | .metadata.name' 2>/dev/null | \
        head -1 || echo ""
}

# Monitor deployment progress with service-by-service spinners
monitor_deployment_progress() {
    local namespace="$1"
    # 15 min covers helm install + image pulls + pod scheduling on cold
    # clusters.
    local timeout="${2:-${K8S_READY_TIMEOUT_SECS:-900}}"
    
    local start_time=$(date +%s)
    # wait_services is the full readiness set (Temporal blocks deploy completion).
    # display_services hides Temporal and Tracker — internal dependencies, not user-facing.
    local wait_services=("mysql" "temporal" "config" "tracker" "manager" "worker" "provider")
    local display_services=("mysql" "config" "manager" "worker" "provider")
    local first_display=true
    local last_status_line=""

    echo ""

    while true; do
        local current_time=$(date +%s)
        local elapsed=$((current_time - start_time))

        if [ $elapsed -gt $timeout ]; then
            echo ""
            print_error "Deployment timeout after ${timeout}s"
            return 1
        fi

        # Get current status for all services
        local all_ready=true
        local current_status_line=""

        for service in "${wait_services[@]}"; do
            local pod=$(kubectl get pods -n "$namespace" -l "app.kubernetes.io/component=$service" \
                -o jsonpath='{.items[0].metadata.name}' 2>/dev/null || echo "")

            local status="pending"
            if [ -n "$pod" ]; then
                local phase=$(kubectl get pod "$pod" -n "$namespace" \
                    -o jsonpath='{.status.phase}' 2>/dev/null || echo "")
                local ready=$(kubectl get pod "$pod" -n "$namespace" \
                    -o jsonpath='{.status.conditions[?(@.type=="Ready")].status}' 2>/dev/null || echo "False")

                if [ "$phase" = "Running" ] && [ "$ready" = "True" ]; then
                    status="ready"
                elif [ "$phase" = "Running" ] || [ -n "$phase" ]; then
                    status="starting"
                fi
            fi

            current_status_line="${current_status_line}${service}:${status},"

            if [ "$status" != "ready" ]; then
                all_ready=false
            fi
        done

        # Display current status only if changed
        if [ "$first_display" = true ] || [ "$current_status_line" != "$last_status_line" ]; then
            # Clear previous lines if not first display
            if [ "$first_display" = false ]; then
                for service in "${display_services[@]}"; do
                    printf "\033[1A\033[2K"
                done
            fi

            # Print current status for all services
            for service in "${display_services[@]}"; do
                local display_name=$(echo "$service" | awk '{print toupper(substr($0,1,1)) tolower(substr($0,2))}')
                
                # Extract status for this service from current_status_line
                local status=$(echo "$current_status_line" | grep -o "${service}:[^,]*" | cut -d: -f2)
                
                case "$status" in
                    ready)
                        printf "   %-15s ${GREEN}✅ Ready${NC}\n" "$display_name"
                        ;;
                    starting)
                        printf "   %-15s ${YELLOW}⏳ Starting...${NC}\n" "$display_name"
                        ;;
                    *)
                        printf "   %-15s ${YELLOW}📦 Pending${NC}\n" "$display_name"
                        ;;
                esac
            done
            
            first_display=false
            last_status_line="$current_status_line"
        fi
        
        # Check if all are ready
        if [ "$all_ready" = true ]; then
            echo ""
            return 0
        fi
        
        sleep 3
    done
}

# Deploy via Helm
deploy_helm_chart() {
    local chart_dir="$1"
    local values_file="$2"
    local namespace="$3"
    local release_name="${4:-bitoarch}"
    
    # Input validation
    if [[ -z "$chart_dir" ]] || [[ -z "$values_file" ]] || [[ -z "$namespace" ]]; then
        print_error "Missing required parameters for helm deployment"
        print_info "Usage: deploy_helm_chart <chart_dir> <values_file> <namespace> [release_name]"
        return 1
    fi
    
    if [[ ! -d "$chart_dir" ]]; then
        print_error "Chart directory not found: $chart_dir"
        return 1
    fi
    
    if [[ ! -f "$values_file" ]]; then
        print_error "Values file not found: $values_file"
        return 1
    fi
    
    # Silent deployment with single spinner
    log_silent "Deploying helm chart: $release_name to $namespace"
    echo ""
    echo "🚀 Deploying Bito's AI Architect..."
    echo ""
    echo -e "${BLUE}ℹ${NC} Provisioning volumes, pulling container images, and rolling out pods. This might take around 10-15 minutes..."
    echo ""
    echo -e "  ${BLUE}Monitor deployment progress:${NC}"
    echo -e "     • ${YELLOW}kubectl get pods -n $namespace${NC}"
    echo ""
    
    # Start spinner
    show_loader "AI Architect Deployment In Progress"
    echo ""
    
    # Deploy with helm (blocking, with progress sent to log file)
    if helm upgrade --install "$release_name" "$chart_dir" \
        --namespace "$namespace" \
        --create-namespace \
        --values "$values_file" \
        --timeout 10m \
        >> "$LOG_FILE" 2>&1; then
        
        log_silent "Helm deployment successful"
        
        # Wait for all pods to be ready silently
        if wait_for_k8s_services "$namespace" 900; then
            stop_loader 0
            log_silent "All services ready"
            return 0
        else
            stop_loader 1
            print_error "Services failed to become ready"
            return 1
        fi
    else
        stop_loader 1
        print_error "Helm deployment failed"
        print_info "Check logs: $LOG_FILE"
        return 1
    fi
}

# Wait for K8s pods to be ready
wait_for_k8s_services() {
    local namespace="$1"
    local timeout="${2:-300}"  # 5 minutes default
    
    log_silent "Waiting for pods to be ready (timeout: ${timeout}s)..."
    
    local start_time=$(date +%s)
    local services=("mysql" "temporal" "config" "tracker" "manager" "worker" "provider")

    while true; do
        local current_time=$(date +%s)
        local elapsed=$((current_time - start_time))
        
        if [ $elapsed -gt $timeout ]; then
            print_error "Timeout waiting for services to be ready"
            return 1
        fi
        
        local all_ready=true
        for service in "${services[@]}"; do
            local pod=$(kubectl get pods -n "$namespace" -l "app.kubernetes.io/component=$service" \
                -o jsonpath='{.items[0].metadata.name}' 2>/dev/null || echo "")
            
            if [ -z "$pod" ]; then
                all_ready=false
                break
            fi
            
            local ready=$(kubectl get pod "$pod" -n "$namespace" \
                -o jsonpath='{.status.conditions[?(@.type=="Ready")].status}' 2>/dev/null || echo "False")
            
            if [ "$ready" != "True" ]; then
                all_ready=false
                break
            fi
        done
        
        if [ "$all_ready" = true ]; then
            log_silent "All pods are ready"
            return 0
        fi
        
        sleep 5
    done
}

# Get K8s service status
get_k8s_service_status() {
    local namespace="$1"
    
    echo ""
    echo -e "${BLUE}📊 Service Health & Status${NC}"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    
    # Get pods
    local pods=$(kubectl get pods -n "$namespace" -o json 2>/dev/null)
    
    if [ -z "$pods" ] || [ "$pods" = "null" ]; then
        echo "  No pods found in namespace: $namespace"
        return 1
    fi
    
    # Read internal ports from environment
    local provider_port="${XMCP_HTTP_PORT:-8080}"
    local manager_port="${CIS_MANAGER_PORT:-9090}"
    local config_port="${CIS_CONFIG_PORT:-8081}"
    local mysql_port="${MYSQL_PORT:-3306}"
    local tracker_port="${CIS_TRACKING_PORT:-9920}"
    
    # Parse and display pod status with uptime - process each pod once
    echo "$pods" | jq -r '.items[] | 
        "\(.metadata.labels."app.kubernetes.io/component" // "unknown")|\(.status.phase)|\([.status.conditions[]? | select(.type=="Ready")] | if length > 0 then .[0].status else "Unknown" end)|\(.status.startTime // "")"' | \
    while IFS='|' read -r component phase ready start_time; do
        # Map component names to display names and ports
        local display_name=""
        local port=""
        case "$component" in
            mysql)
                display_name="MySQL Database"
                port="$mysql_port"
                ;;
            config)
                display_name="AI Architect Config"
                port="$config_port"
                ;;
            manager)
                display_name="AI Architect Manager"
                port="$manager_port"
                ;;
            provider)
                display_name="AI Architect Provider"
                port="$provider_port"
                ;;
            tracker)
                display_name="AI Architect Tracker"
                port="$tracker_port"
                ;;
            temporal)
                # Hide Temporal from display — internal dependency
                continue
                ;;
            worker)
                display_name="AI Architect Worker"
                port=""
                ;;
            temporal-post-deploy|temporal-bootstrap|*-job)
                # Skip Helm hook Jobs - not a service
                continue
                ;;
            *)
                display_name=$(echo "$component" | awk '{print toupper(substr($0,1,1)) tolower(substr($0,2))}')
                port="unknown"
                ;;
        esac
        
        # Calculate uptime if pod is running
        local uptime_str=""
        if [ "$phase" = "Running" ] && [ -n "$start_time" ]; then
            local start_epoch=""
            local clean_time=$(echo "$start_time" | sed 's/\.[0-9]*Z$/Z/')
            
            if [[ "$OSTYPE" == "darwin"* ]]; then
                local time_no_z=$(echo "$clean_time" | sed 's/Z$//')
                start_epoch=$(date -u -j -f "%Y-%m-%dT%H:%M:%S" "$time_no_z" "+%s" 2>/dev/null || echo "")
            else
                start_epoch=$(date -d "$clean_time" "+%s" 2>/dev/null || echo "")
            fi
            
            if [ -n "$start_epoch" ] && [ "$start_epoch" -gt 0 ]; then
                local now=$(date +%s)
                local running_time=$((now - start_epoch))
                
                if [ "$running_time" -lt 60 ]; then
                    uptime_str="up ${running_time}s"
                elif [ "$running_time" -lt 3600 ]; then
                    uptime_str="up $((running_time / 60))m"
                else
                    uptime_str="up $((running_time / 3600))h"
                fi
            fi
        fi
        
        # Build port/uptime detail string
        local detail=""
        if [ -n "$uptime_str" ] && [ -n "$port" ]; then
            detail="(${uptime_str}, port ${port})"
        elif [ -n "$uptime_str" ]; then
            detail="(${uptime_str})"
        elif [ -n "$port" ]; then
            detail="(port ${port})"
        fi

        if [ "$phase" = "Running" ] && [ "$ready" = "True" ]; then
            printf "   %-29s ${GREEN}✅ Running${NC}      ${detail}\n" "$display_name"
        elif [ "$phase" = "Running" ] && [ "$ready" = "False" ]; then
            printf "   %-29s ${YELLOW}⏳ Starting${NC}     ${detail}\n" "$display_name"
        elif [ "$phase" = "Pending" ]; then
            printf "   %-29s ${YELLOW}📦 Pending${NC}      ${detail}\n" "$display_name"
        else
            printf "   %-29s ${RED}⚠️  $phase${NC}        ${detail}\n" "$display_name"
        fi
    done
    
    echo ""
}

# Get K8s service endpoints
get_k8s_endpoints() {
    local namespace="$1"
    
    echo -e "${BLUE}🔗 Service Endpoints${NC}"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    
    # Detect machine IP (works on Linux + macOS)
    local MACHINE_IP=""
    if command -v hostname >/dev/null 2>&1; then
        MACHINE_IP=$(hostname -I 2>/dev/null | awk '{print $1}')
    fi
    if [ -z "$MACHINE_IP" ] && command -v ifconfig >/dev/null 2>&1; then
        # Fallback for macOS
        MACHINE_IP=$(ifconfig | grep "inet " | grep -v 127.0.0.1 | awk '{print $2}' | head -1)
    fi
    if [ -z "$MACHINE_IP" ]; then
        MACHINE_IP="<host-ip>"
    fi
    
    # Read external port configuration from .env-bitoarch
    if [ -f "${SCRIPT_DIR}/.env-bitoarch" ]; then
        source "${SCRIPT_DIR}/.env-bitoarch"
    fi
    
    # Use default ports if not set
    local PROVIDER_PORT=${CIS_PROVIDER_EXTERNAL_PORT:-5001}
    local MANAGER_PORT=${CIS_MANAGER_EXTERNAL_PORT:-5002}
    local CONFIG_PORT=${CIS_CONFIG_EXTERNAL_PORT:-5003}
    local MYSQL_PORT=${MYSQL_EXTERNAL_PORT:-5004}
    local TRACKER_PORT=${CIS_TRACKER_EXTERNAL_PORT:-5005}
    
    echo "   Provider:  http://${MACHINE_IP}:${PROVIDER_PORT}"
    echo "   Manager:   http://${MACHINE_IP}:${MANAGER_PORT}"
    echo "   Config:    http://${MACHINE_IP}:${CONFIG_PORT}"
    echo "   MySQL:     ${MACHINE_IP}:${MYSQL_PORT}"
    echo "   Tracker:   http://${MACHINE_IP}:${TRACKER_PORT}"
    echo ""
    echo -e "  ${YELLOW}⚠️  Security Note:${NC}"
    echo -e "     • Port-forwards exposed on all network interfaces (0.0.0.0)"
    echo -e "     • Accessible from any machine on your network"
    echo -e "     • Use firewall rules to restrict access to trusted IPs"
    echo ""
}

# HTTP /health probe: a real status code = tunnel reaches the pod; "000"/empty = no.
_http_forward_alive() {
    local port="$1" path="${2:-/health}" code
    code=$(curl -s -o /dev/null -w '%{http_code}' --max-time "${PF_PROBE_TIMEOUT:-4}" "http://localhost:${port}${path}" 2>/dev/null)
    [ -n "$code" ] && [ "$code" != "000" ]
}

# Raw-TCP liveness fallback: a live forward sends a greeting or holds the
# connection open; a stale one closes immediately. Connect fail / EOF = dead.
_tcp_forward_alive() {
    local port="$1" timeout="${PF_PROBE_TIMEOUT:-4}" rc _b
    # Brace-group so a failed connect doesn't leak "Connection refused".
    { exec 3<>"/dev/tcp/127.0.0.1/${port}"; } 2>/dev/null || return 1
    if read -r -t "$timeout" -n 1 _b <&3 2>/dev/null; then
        rc=0          # server-initiated byte → alive
    elif [ $? -gt 128 ]; then
        rc=0          # read timed out, connection held open → alive
    else
        rc=1          # EOF before timeout → stale forward → dead
    fi
    # Brace-grouped so 2>/dev/null stays scoped; a bare `exec ... 2>` rebinds the
    # shell's stderr for good. See test-port-forward-verify.sh ("fd hygiene").
    { exec 3>&-; } 2>/dev/null
    return "$rc"
}

# Is the forward carrying traffic? HTTP /health first, raw-TCP fallback.
port_forward_accessible() {
    local port="$1" path="${2:-/health}"
    _http_forward_alive "$port" "$path" || _tcp_forward_alive "$port"
}

# Start one detached port-forward (nohup+disown so it outlives this shell).
_start_one_forward() {
    local svc="$1" ext_port="$2" int_port="$3" namespace="${4:-bito-ai-architect}"
    # DEBUG= clears the inherited DEBUG=false: kubectl's SPDY layer keys verbose
    # frame logging on a *non-empty* DEBUG. See test-port-forward-verify.sh.
    DEBUG= nohup kubectl port-forward --address 0.0.0.0 -n "$namespace" "svc/${svc}" "${ext_port}:${int_port}" </dev/null >> "${LOG_FILE:-/dev/null}" 2>&1 &
    disown 2>/dev/null || true
}

# Recreate one forward: free the local port (stale forwards keep LISTENing),
# then start a fresh one.
restart_port_forward() {
    local svc="$1" ext_port="$2" int_port="$3" namespace="${4:-bito-ai-architect}"
    # kubectl port-forward is a stateless tunnel, so a direct SIGKILL is fine
    # (same approach as kill_port_forwards). Scoped to this svc + local port.
    pkill -9 -f "kubectl port-forward.*svc/${svc} .*${ext_port}:" 2>/dev/null || true
    # Safety net: free the local port only if a *listener* still squats on it
    # (LISTEN-only avoids killing unrelated clients connected to localhost:$ext_port).
    if command -v lsof >/dev/null 2>&1; then
        local holders; holders=$(lsof -ti :"$ext_port" -sTCP:LISTEN 2>/dev/null)
        [ -n "$holders" ] && { echo "$holders" | xargs kill -9 2>/dev/null || true; }
    fi
    sleep 1   # let the OS release the local port before we rebind
    _start_one_forward "$svc" "$ext_port" "$int_port" "$namespace"
    sleep 1   # give the fresh tunnel a moment before verify_and_repair probes it
}

# Probe each forward (svc:ext:int) and recreate the ones that don't answer — a
# process count can't tell a stale-but-listening forward from a live one. The
# probe per service comes from bitoarch_service_probe: an HTTP path (/health,
# raw-TCP fallback), "tcp" (raw-TCP only, e.g. mysql), or "skip" (e.g. temporal,
# whose gRPC tunnel a probe connect would tear down). Returns non-zero if any
# service stays unreachable; the caller decides whether that's fatal.
verify_and_repair_port_forwards() {
    local namespace="$1"; shift
    local attempts="${PF_VERIFY_ATTEMPTS:-3}"
    local polls="${PF_PROBE_POLLS:-10}"
    local interval="${PF_PROBE_INTERVAL:-0.5}"
    local specs=("$@")

    local failed=() spec svc ext int mode attempt i ok
    for spec in "${specs[@]}"; do
        IFS=: read -r svc ext int <<< "$spec"
        [ -n "$ext" ] || continue
        mode="/health"
        command -v bitoarch_service_probe >/dev/null 2>&1 && mode="$(bitoarch_service_probe "$svc")"
        if [ "$mode" = "skip" ]; then
            log_silent "port-forward $svc (localhost:$ext): created best-effort, verify skipped"
            continue
        fi
        ok=0
        attempt=1
        while [ "$attempt" -le "$attempts" ]; do
            # Poll, don't probe once: a just-(re)created forward needs a moment
            # to establish its tunnel, so a single immediate probe false-fails.
            i=0
            while [ "$i" -lt "$polls" ]; do
                if [ "$mode" = "tcp" ]; then
                    if _tcp_forward_alive "$ext"; then ok=1; break; fi
                else
                    if port_forward_accessible "$ext" "$mode"; then ok=1; break; fi
                fi
                sleep "$interval"
                i=$((i + 1))
            done
            [ "$ok" -eq 1 ] && break
            if [ "$attempt" -lt "$attempts" ]; then
                log_silent "port-forward $svc (localhost:$ext) not accessible; recreating (attempt $attempt/$attempts)"
                restart_port_forward "$svc" "$ext" "$int" "$namespace"
            fi
            attempt=$((attempt + 1))
        done
        [ "$ok" -eq 1 ] || failed+=("$svc")
    done

    if [ "${#failed[@]}" -gt 0 ]; then
        print_warning "Port-forwards not accessible after ${attempts} attempts: ${failed[*]}"
        return 1
    fi
    return 0
}

# Setup port-forwards for all services (runs in background)
setup_port_forwards() {
    local namespace="$1"
    
    # Read external port configuration from .env-bitoarch (use config ports only)
    local provider_external_port="${CIS_PROVIDER_EXTERNAL_PORT:-5001}"
    local manager_external_port="${CIS_MANAGER_EXTERNAL_PORT:-5002}"
    local config_external_port="${CIS_CONFIG_EXTERNAL_PORT:-5003}"
    local mysql_external_port="${MYSQL_EXTERNAL_PORT:-5004}"
    local tracker_external_port="${CIS_TRACKER_EXTERNAL_PORT:-5005}"
    local temporal_external_port="${TEMPORAL_EXTERNAL_PORT:-5006}"

    local ports=("$provider_external_port" "$manager_external_port" "$config_external_port" "$mysql_external_port" "$tracker_external_port" "$temporal_external_port")
    
    # ALWAYS clean up existing port-forwards for this namespace before creating new ones
    # This prevents port conflicts and ensures fresh connections
    log_silent "Cleaning up existing port-forwards for $namespace"
    kill_port_forwards "$namespace"
    sleep 2
    
    # Verify ports are actually free before proceeding
    local ports_in_use=()
    for port in "${ports[@]}"; do
        if lsof -i ":$port" >/dev/null 2>&1; then
            ports_in_use+=("$port")
        fi
    done
    
    if [ ${#ports_in_use[@]} -gt 0 ]; then
        print_warning "Ports still in use after cleanup: ${ports_in_use[*]}"
        print_warning "These may be from non-kubectl processes (e.g., SSH tunnels)"
        print_info "Attempting to continue anyway..."
    fi
    
    # Ensure pods are ready before setting up port-forwards
    log_silent "Verifying pods are ready before establishing port-forwards..."
    local pods_ready=false
    local max_wait=60
    local waited=0
    
    while [ $waited -lt $max_wait ]; do
        local ready_pods=$(kubectl get pods -n "$namespace" -l "app.kubernetes.io/name=bitoarch" -o jsonpath='{.items[?(@.status.conditions[?(@.type=="Ready")].status=="True")].metadata.name}' 2>/dev/null | wc -w | xargs)
        
        if [ "$ready_pods" -ge 5 ]; then
            pods_ready=true
            break
        fi
        
        sleep 2
        waited=$((waited + 2))
    done
    
    if [ "$pods_ready" = false ]; then
        log_silent "Some pods may not be ready yet, attempting port-forwards removal anyway..."
    fi
    
    # Read external port configuration from .env-bitoarch
    local provider_external_port="${CIS_PROVIDER_EXTERNAL_PORT:-5001}"
    local manager_external_port="${CIS_MANAGER_EXTERNAL_PORT:-5002}"
    local config_external_port="${CIS_CONFIG_EXTERNAL_PORT:-5003}"
    local mysql_external_port="${MYSQL_EXTERNAL_PORT:-5004}"
    local tracker_external_port="${CIS_TRACKER_EXTERNAL_PORT:-5005}"
    local temporal_external_port="${TEMPORAL_EXTERNAL_PORT:-5006}"

    # Read internal port configuration from .env-bitoarch
    local provider_internal_port="${XMCP_HTTP_PORT:-8080}"
    local manager_internal_port="${CIS_MANAGER_PORT:-9090}"
    local config_internal_port="${CIS_CONFIG_PORT:-8081}"
    local mysql_internal_port="${MYSQL_PORT:-3306}"
    local tracker_internal_port="${CIS_TRACKING_PORT:-9920}"
    local temporal_internal_port="${TEMPORAL_PORT:-7233}"

    print_info "Setting up port-forwards (localhost → cluster services)..."

    # One svc:ext:int list (svc names from constants.sh, ports from above) used to
    # create AND verify the forwards. Add a service here and to bitoarch_service_probe.
    local pf_specs=(
        "${SERVICE_PROVIDER_NAME}:${provider_external_port}:${provider_internal_port}"
        "${SERVICE_MANAGER_NAME}:${manager_external_port}:${manager_internal_port}"
        "${SERVICE_CONFIG_NAME}:${config_external_port}:${config_internal_port}"
        "${SERVICE_MYSQL_NAME}:${mysql_external_port}:${mysql_internal_port}"
        "${SERVICE_TRACKER_NAME}:${tracker_external_port}:${tracker_internal_port}"
        "${SERVICE_TEMPORAL_NAME}:${temporal_external_port}:${temporal_internal_port}"
    )

    local spec svc ext int
    for spec in "${pf_specs[@]}"; do
        IFS=: read -r svc ext int <<< "$spec"
        _start_one_forward "$svc" "$ext" "$int" "$namespace"
        sleep 0.5
    done

    # Let the forwards settle, then verify each is reachable and recreate dead
    # ones. Stay non-fatal (always return 0 below) so the caller completes, but
    # don't claim success when verify reported a service still unreachable.
    sleep 2
    if verify_and_repair_port_forwards "$namespace" "${pf_specs[@]}"; then
        print_status "Port-forwards established"
    else
        print_warning "Port-forwards established with warnings (see ${LOG_FILE:-setup log})"
    fi
    # Per-service mapping → log file only (compact UX; `bitoarch info` shows it).
    log_silent "Port-forward map:"
    log_silent "  Provider: localhost:${provider_external_port} -> ai-architect-provider:${provider_internal_port}"
    log_silent "  Manager:  localhost:${manager_external_port} -> ai-architect-manager:${manager_internal_port}"
    log_silent "  Config:   localhost:${config_external_port} -> ai-architect-config:${config_internal_port}"
    log_silent "  MySQL:    localhost:${mysql_external_port} -> ai-architect-mysql:${mysql_internal_port}"
    log_silent "  Tracker:  localhost:${tracker_external_port} -> ai-architect-tracker:${tracker_internal_port}"
    log_silent "  Temporal: localhost:${temporal_external_port} -> ai-architect-temporal:${temporal_internal_port}"
    return 0
}

# Kill port-forwards for this namespace
kill_port_forwards() {
    local namespace="$1"
    
    # Find all kubectl port-forward processes for this namespace
    # Match: -n namespace, --namespace=namespace, or -n=namespace
    local pids=$(ps aux | grep "kubectl port-forward" | grep -E "(-n |--namespace=|-n=)$namespace" | grep -v grep | awk '{print $2}')
    
    if [ -n "$pids" ]; then
        log_silent "Killing existing port-forwards..."
        echo "$pids" | xargs kill -9 2>/dev/null || true
        log_silent "Port-forwards terminated"
    fi
}

# Uninstall Helm release
uninstall_helm_release() {
    local namespace="$1"
    local release_name="${2:-bitoarch}"
    local delete_pvcs="${3:-false}"
    
    # Kill any existing port-forwards first
    kill_port_forwards "$namespace"
    
    log_silent "Uninstalling Helm release: $release_name"
    
    if helm uninstall "$release_name" --namespace "$namespace" >> "$LOG_FILE" 2>&1; then
        log_silent "Helm release uninstalled"
    else
        print_warning "Failed to uninstall Helm release"
    fi
    
    # Delete PVCs if requested
    if [ "$delete_pvcs" = "true" ]; then
        log_silent "Deleting persistent volume claims..."
        if kubectl delete pvc -n "$namespace" -l app.kubernetes.io/name=bitoarch --timeout=60s >> "$LOG_FILE" 2>&1; then
            log_silent "PVCs deleted"
        else
            print_warning "Failed to delete some PVCs, they may be in use"
        fi
    else
        print_warning "Persistent volumes preserved (data retained)"
        print_info "To delete data: kubectl delete pvc -n $namespace -l app.kubernetes.io/name=bitoarch"
    fi
}

# Restart K8s deployment
restart_k8s_deployment() {
    local namespace="$1"
    local component="$2"
    
    if [ -z "$component" ]; then
        # Restart all (Temporal is a StatefulSet; everything else is a Deployment)
        print_info "Restarting all deployments..."
        kubectl rollout restart deployment -n "$namespace" -l "app.kubernetes.io/name=bitoarch" >> "$LOG_FILE" 2>&1
        kubectl rollout restart statefulset -n "$namespace" -l "app.kubernetes.io/name=bitoarch" >> "$LOG_FILE" 2>&1 || true
    else
        # Restart specific component (temporal is a StatefulSet)
        print_info "Restarting $component..."
        if [[ "$component" == "temporal" ]]; then
            kubectl rollout restart statefulset -n "$namespace" -l "app.kubernetes.io/component=$component" >> "$LOG_FILE" 2>&1
        else
            kubectl rollout restart deployment -n "$namespace" -l "app.kubernetes.io/component=$component" >> "$LOG_FILE" 2>&1
        fi
    fi
}

# Get K8s logs
get_k8s_logs() {
    local namespace="$1"
    local component="$2"
    local follow="${3:-false}"
    
    if [ -z "$component" ]; then
        # All logs
        if [ "$follow" = "true" ]; then
            kubectl logs -n "$namespace" -l "app.kubernetes.io/name=bitoarch" --tail=100 -f --max-log-requests=10
        else
            kubectl logs -n "$namespace" -l "app.kubernetes.io/name=bitoarch" --tail=100
        fi
    else
        # Specific component
        if [ "$follow" = "true" ]; then
            kubectl logs -n "$namespace" -l "app.kubernetes.io/component=$component" --tail=100 -f
        else
            kubectl logs -n "$namespace" -l "app.kubernetes.io/component=$component" --tail=100
        fi
    fi
}

# Check if K8s deployment exists
check_k8s_deployment_exists() {
    local namespace="$1"
    
    if kubectl get namespace "$namespace" >/dev/null 2>&1; then
        if kubectl get deployment -n "$namespace" -l "app.kubernetes.io/name=bitoarch" 2>/dev/null | grep -q "ai-architect"; then
            return 0  # Deployment exists
        fi
    fi
    return 1  # Deployment doesn't exist
}

# Check if K8s services are running (not stopped/scaled to 0)
# Returns 0 if services are running, 1 if not
# Usage: check_k8s_services_running <namespace> || { handle_not_running; exit 0; }
check_k8s_services_running() {
    local namespace="$1"
    local replicas_raw replicas_sum=0 r

    # Single query for spec.replicas across all bitoarch deployments. Empty
    # output means no matching deployments exist (not installed / wrong
    # namespace); any non-empty output gives us the per-deployment replicas
    # to sum. Summing in pure bash avoids the bc dependency (not installed
    # by default on minimal Linux images) that produced a
    # "[: : integer expression expected" error when the pipeline returned
    # an empty string.
    replicas_raw=$(kubectl get deployment -n "$namespace" \
                   -l "app.kubernetes.io/name=bitoarch" \
                   -o jsonpath='{.items[*].spec.replicas}' 2>/dev/null)

    [ -z "$replicas_raw" ] && return 1

    for r in $replicas_raw; do
        case "$r" in
            ''|*[!0-9]*) ;;
            *) replicas_sum=$((replicas_sum + r)) ;;
        esac
    done

    [ "$replicas_sum" -eq 0 ] && return 1
    return 0
}

# -----------------------------------------------------------------------------
# bitoarch_k8s_recreate [force=true|false] [image_pull_policy=IfNotPresent|Always]
# -----------------------------------------------------------------------------
# Silent K8s restart / force-recreate. Used by the `bitoarch restart [--force]`
# CLI path to produce compact output (single progress_run + unified success
# block) matching the Docker lifecycle UX. All stdout/stderr is left attached
# to the caller; progress_run (the only call path) captures the stream into
# the file whose path it prints on failure.
#
#   force=true  -> regenerate helm values from .env-bitoarch, helm upgrade,
#                  then kubectl rollout restart (picks up env/image changes).
#   force=false -> kubectl rollout restart only (quick bounce).
#
# Phased rollout (hard-coded; NOT derived from BITOARCH_LIFECYCLE_SERVICES --
# a new lifecycle service added to constants.sh will not be picked up here
# automatically and must be wired into a phase below):
#   Phase 1   mysql                            (Deployment, blocks)
#   Phase 2   temporal                         (StatefulSet, blocks)
#   Phase 3a  config + tracker                 (parallel within phase)
#   Phase 3b  manager + worker + provider      (parallel within phase)
#
# Temporal is a StatefulSet (helm-bitoarch/templates/16-temporal-statefulset.yaml)
# and gets a dedicated rollout branch; all other services are Deployments.
#
# Returns 0 on success, 1 on any helm/rollout failure.
# -----------------------------------------------------------------------------
bitoarch_k8s_recreate() {
    local force="${1:-false}"
    local image_pull_policy="${2:-IfNotPresent}"
    local namespace="bito-ai-architect"

    if [ "$force" = "true" ]; then
        # Regenerate values + helm upgrade (picks up env changes from the
        # caller's apply_install_yaml_to_env_file + any manual .env edits).
        if ! command -v generate_k8s_values_from_env >/dev/null 2>&1; then
            source "${SCRIPT_DIR}/scripts/values-generator.sh" 2>/dev/null \
                || source "${SCRIPT_DIR}/../scripts/values-generator.sh" 2>/dev/null \
                || return 1
        fi
        generate_k8s_values_from_env "$image_pull_policy" || return 1

        local vf
        vf=$(command -v get_k8s_values_file >/dev/null 2>&1 && get_k8s_values_file)
        [ -z "$vf" ] && vf="${BITOARCH_CONFIG_DIR:-/usr/local/etc/bitoarch}/.bitoarch-values.yaml"

        local chart="${SCRIPT_DIR}/helm-bitoarch"
        [ -d "$chart" ] || chart="${SCRIPT_DIR}/../helm-bitoarch"
        # K8S_HELM_TIMEOUT covers image pulls + pod scheduling.
        helm upgrade bitoarch "$chart" \
            --namespace "$namespace" \
            --values "$vf" \
            --wait --timeout "${K8S_HELM_TIMEOUT:-10m}" || return 1
    fi

    local k8s_rollout_timeout="${K8S_ROLLOUT_TIMEOUT:-25m}"
    # Phased rollout: mysql -> temporal -> (config + tracker) -> (manager +
    # worker + provider). Within each phase, rollout restart commands are
    # issued sequentially but return immediately (cheap annotation patch);
    # K8s then rolls the deployments concurrently. Rollout status calls
    # are backgrounded so we wait on all of them in parallel.

    # Phase 1: mysql.
    kubectl rollout restart deployment ai-architect-mysql -n "$namespace" || return 1
    kubectl rollout status  deployment ai-architect-mysql -n "$namespace" --timeout="$k8s_rollout_timeout" || return 1

    # Phase 2: temporal (StatefulSet).
    kubectl rollout restart statefulset ai-architect-temporal -n "$namespace" || return 1
    kubectl rollout status  statefulset ai-architect-temporal -n "$namespace" --timeout="$k8s_rollout_timeout" || return 1

    # Phase 3a: config + tracker.
    local phase3a_deployments=(
        ai-architect-config
        ai-architect-tracker
    )
    local d
    for d in "${phase3a_deployments[@]}"; do
        kubectl rollout restart deployment "$d" -n "$namespace" || return 1
    done
    local pids3a=()
    for d in "${phase3a_deployments[@]}"; do
        kubectl rollout status deployment "$d" -n "$namespace" --timeout="$k8s_rollout_timeout" &
        pids3a+=($!)
    done
    local rc any_fail=0 i
    for i in "${!pids3a[@]}"; do
        wait "${pids3a[$i]}"; rc=$?
        [ "$rc" -ne 0 ] && any_fail=1
    done
    [ "$any_fail" -eq 0 ] || return 1

    # Phase 3b: manager + worker + provider.
    local phase3b_deployments=(
        ai-architect-manager
        ai-architect-worker
        ai-architect-provider
    )
    for d in "${phase3b_deployments[@]}"; do
        kubectl rollout restart deployment "$d" -n "$namespace" || return 1
    done
    local pids3b=()
    for d in "${phase3b_deployments[@]}"; do
        kubectl rollout status deployment "$d" -n "$namespace" --timeout="$k8s_rollout_timeout" &
        pids3b+=($!)
    done
    any_fail=0
    for i in "${!pids3b[@]}"; do
        wait "${pids3b[$i]}"; rc=$?
        [ "$rc" -ne 0 ] && any_fail=1
    done
    [ "$any_fail" -eq 0 ] || return 1

    # Re-establish port-forwards (silent). Pods got new IPs on rollout.
    if command -v setup_port_forwards >/dev/null 2>&1; then
        setup_port_forwards "$namespace"
    fi
    return 0
}
export -f bitoarch_k8s_recreate 2>/dev/null || true

# bitoarch_k8s_update: pull+apply new image tags from versions-service-json.
# Used by `bitoarch update` on K8s.
bitoarch_k8s_update() {
    if command -v refresh_versions_from_service_json >/dev/null 2>&1; then
        local env_file
        env_file=$(command -v get_config_file >/dev/null 2>&1 && get_config_file)
        [ -n "$env_file" ] && refresh_versions_from_service_json "$env_file" || true
    fi
    # After version bump, force recreate picks up the new image tags.
    bitoarch_k8s_recreate "true" "Always"
}
export -f bitoarch_k8s_update 2>/dev/null || true
export -f setup_port_forwards 2>/dev/null || true
export -f verify_and_repair_port_forwards port_forward_accessible restart_port_forward _start_one_forward 2>/dev/null || true
export -f _http_forward_alive _tcp_forward_alive 2>/dev/null || true
