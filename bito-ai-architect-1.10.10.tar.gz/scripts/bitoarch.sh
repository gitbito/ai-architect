#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
# Bito's AI Architect CLI
# Command-line interface for managing Bito's AI Architect services

# Get script directory (resolve symlinks)
SOURCE="${BASH_SOURCE[0]}"
while [ -h "$SOURCE" ]; do
    DIR="$( cd -P "$( dirname "$SOURCE" )" && pwd )"
    SOURCE="$(readlink "$SOURCE")"
    [[ $SOURCE != /* ]] && SOURCE="$DIR/$SOURCE"
done
DIR="$( cd -P "$( dirname "$SOURCE" )" && pwd )"

# SCRIPT_DIR should always point to the scripts directory
SCRIPT_DIR="$DIR"
# Immutable copy: the k8s restart/update blocks re-export SCRIPT_DIR to the
# install root (kubernetes-manager.sh resolves helm-bitoarch/ from there), so
# helpers that source CLI libs must resolve from this frozen scripts dir.
BITOARCH_CLI_DIR="$DIR"

# Source path manager first (for standard paths)
source "${SCRIPT_DIR}/lib/path-manager.sh"
# Offline Wingman bundle. Needed here, not only in setup.sh: the lifecycle verbs
# reach kubernetes-manager.sh through this CLI, and the seed call sites there are
# guarded by `type wingman_bundle_seed_before_helm`. Without this source the guard
# is false and the shelf is never re-seeded on a CLI-driven recreate -- which
# matters after `uninstall --purge` deletes the PVC. Every entry point no-ops when
# the package carries no bundle, and the lib is guard-flagged against re-sourcing.
# shellcheck disable=SC1091
source "${SCRIPT_DIR}/lib/wingman-bundle.sh" 2>/dev/null \
    || { [ -f "${SCRIPT_DIR}/lib/wingman-bundle.sh" ] && type log_silent >/dev/null 2>&1 \
         && log_silent "wingman bundle: "${SCRIPT_DIR}/lib/wingman-bundle.sh" exists but failed to load; offline seeding unavailable"; true; }
# Feature-flag helpers (sso_ui_suppressed) -- small, independent; safe to
# source early so show_main_help can gate the SSO section.
# shellcheck disable=SC1091
source "${SCRIPT_DIR}/lib/bitoarch-config.sh"

# Source core libraries
source "${SCRIPT_DIR}/lib/cli-core.sh"
source "${SCRIPT_DIR}/lib/http-client.sh"
source "${SCRIPT_DIR}/lib/output-formatter.sh"
source "${SCRIPT_DIR}/lib/config-backup-manager.sh"
# Shared editor helper (resolve $EDITOR, backup, BOM/CRLF normalize). Provides
# _rewrite_in_place + open_editor_with_normalization, shared with the install
# path. Sourced after config-backup-manager.sh (it uses backup_config_file).
source "${SCRIPT_DIR}/lib/editor.sh"

# _rewrite_in_place + the BOM/CRLF normalization now live in scripts/lib/editor.sh
# (sourced above) so `config edit` and the install-time pre-seed editor share one
# copy. See open_editor_with_normalization / normalize_bom_crlf there.

# Pre-compose-up hook: provision the mkcert HTTPS cert + export
# HOST_MCP_CERT_DIR / XMCP_INTERNAL_PORT for docker-compose. Idempotent and
# gated on MCP_TRANSPORT=https inside mcp_cert_prepare_for_compose, so it is
# a cheap no-op on Enterprise / http installs.
_bitoarch_prep_compose_env() {
    local env_file="$1"
    [ -n "$env_file" ] && [ -f "$env_file" ] && {
        set -a; . "$env_file" 2>/dev/null || true; set +a
    }
    if [ -f "${SCRIPT_DIR}/lib/mcp-cert.sh" ]; then
        # shellcheck disable=SC1091
        source "${SCRIPT_DIR}/lib/mcp-cert.sh"
        mcp_cert_prepare_for_compose >> "$LOG_FILE" 2>&1 || true
    fi
}

# Lazily source the plugin lifecycle helpers; non-zero if unavailable.
_bitoarch_plugin_lifecycle() {
    if ! type plugin_lifecycle_any >/dev/null 2>&1; then
        # shellcheck disable=SC1091
        source "${BITOARCH_CLI_DIR:-$SCRIPT_DIR}/lib/plugin/lifecycle.sh" 2>/dev/null || return 1
    fi
    return 0
}

# Version — read from versions/service-versions.json (single source of truth)
_versions_file="${SCRIPT_DIR}/../versions/service-versions.json"
if [ -f "$_versions_file" ] && command -v jq >/dev/null 2>&1; then
    CLI_VERSION=$(jq -r '.platform_info.version // "1.0.0"' "$_versions_file" 2>/dev/null)
elif [ -f "$_versions_file" ]; then
    CLI_VERSION=$(grep -A2 '"platform_info"' "$_versions_file" | grep '"version"' | head -1 | cut -d'"' -f4 || echo "1.0.0")
else
    CLI_VERSION="1.0.0"
fi

# Show main help
show_main_help() {
    # Gate SSO section on the existing SKIP_SSO_PROMPT flag (set by SA
    # install_run, persisted into .env-bitoarch). Reused across setup.sh,
    # install.sh, help, and Next-Steps hints so "hide SSO UI" is a single
    # switch. Default (flag unset) = show SSO (prod behavior).
    local _hide_sso=0
    if command -v sso_ui_suppressed >/dev/null 2>&1 && sso_ui_suppressed; then
        _hide_sso=1
    fi

    cat << EOF
╔═══════════════════════════════════════════════════════════════╗
║          Bito's AI Architect - Command Line Interface         ║
╚═══════════════════════════════════════════════════════════════╝

USAGE:
  bitoarch <command> [options]

STATUS:
  status                        Show all services status
  health                        Check health of all services
  diagnose --bundle             Collect a shareable diagnostics .tar.gz for
                                support (use --output <dir> for path)
  info                          Show platform information

LIFECYCLE:
  start                         Start stopped services (idempotent)
  stop                          Stop all services (keeps data)
  restart [--force]             Restart services (--force reloads env, recreates all)
  logs [service]                Tail service logs (-f; all if omitted)
  upgrade [--version=<ver>]     Upgrade platform (latest by default)
  uninstall                     Remove the services (data and config are kept; 'bitoarch start' restores)
  uninstall --purge             Remove everything including data and configuration

REPOSITORIES:
  add-repo <ns>                    Add repository by namespace
  remove-repo <ns>                 Remove repository by namespace
  remove-index [<ns>...]           Purge repo indexes (no args: repos removed from config)
  add-repos                        Load repos from YAML (default path if omitted)
  update-repos                     Update repos from YAML (default path if omitted)
  repo-info <name>                 Get repository details
  fetch-repo-list [--force-load]   Sync repo list from git provider
  import-repos <path> [--allow-non-git]
                                   Copy pre-cloned repos into the platform and
                                   register them (local git provider only)

INDEXING:
  show-config                      Show current indexing configuration
  index-repos [OPTIONS]            Trigger workspace repository indexing
                                   [--mode force|incremental] [--repo <ns>]...
  index-status                     Check indexing status
  index-repo-list                  List all indexed repositories
  stop-indexing                    Stop indexing completely
  create-index-scheduler           Create scheduler tasks
  update-index-scheduler           Update existing scheduler tasks

CONFIGURATION:
  update-api-key                Update Bito API key
  update-git-creds              Update Git provider credentials
  update-llm-config             Update custom LLM provider configuration
  rotate-mcp-token              Rotate MCP access token
  config path [env|repos|llm]   Print config file path (default: env)
  config edit [env|repos|llm]   Open config file in \$EDITOR (default: env)

INSIGHTS:
  insights config                                  Show insights configuration
  insights status                                  Show detailed insights workflow status
  insights run [--force]                           Run insights analysis (--force re-analyzes all)
  insights enable [git|ticket-tracker|docs]        Enable an insights feature (interactive)
  insights disable [git|ticket-tracker|docs]       Disable an insights feature
  insights set-lookback [git|ticket-tracker]       Set lookback days for a feature
  insights tracker-projects [action] [KEY …]       Manage project keys (list|add|remove|set)
  insights discover-tracker-projects               List accessible ticket-tracker projects
  insights update-ticket-tracker-config            Update ticket-tracker credentials
  insights update-doc-config                       Update doc integration credentials

PLUGINS:
  plugin install <name>         Install a plugin by name, path, or URL
  plugin list                   List installed plugins
  plugin status [name]          Plugin health, services, dependency packs
  plugin start <name>           Set up (prompts for anything missing) + (re)start a plugin
  plugin stop <name>            Stop a plugin (keeps it installed)
  plugin restart <name>         Restart a plugin's services
  plugin upgrade <name>         Upgrade an installed plugin
  plugin config <name>          View or change a plugin's configuration
  plugin uninstall <name>       Remove a plugin (keeps its data; --purge deletes it)
  plugin deps <subcmd>          Manage shared dependency packs (event-bus | cache)
EOF

    if [ "$_hide_sso" -eq 0 ]; then
        cat << 'EOF'

SSO:
  sso setup                     Configure SSO (Enterprise IdP or Bito)
  sso status                    Check SSO configuration and verification
  sso enable                    Re-enable previously disabled SSO
  sso disable                   Disable SSO configuration
  sso rotate-key                Rotate SSO keys
EOF
    fi

    local _show_local_mcp=0
    if command -v mcp_auto_install_enabled >/dev/null 2>&1 && mcp_auto_install_enabled; then
        _show_local_mcp=1
    fi

    cat << EOF

MCP:
  mcp-info                      Show MCP configuration
  mcp-test                      Test MCP connection
  mcp-tools                     List available MCP tools
  mcp-tool-info <name>          Show MCP tool details
  mcp-capabilities              Show MCP server capabilities
EOF

    if [ "$_show_local_mcp" -eq 1 ]; then
        cat << EOF
  mcp-install [--email <addr>]  Register MCP with installed coding agents
  mcp-uninstall                 Deregister MCP from installed coding agents
  mcp-cert <subcmd>             Cert status / renew / paths — \`mcp-cert --help\`
EOF
    fi

    cat << EOF

OPTIONS:
  --help, -h                    Show this help
  <command> --help              Command-specific help

EXAMPLES:
  bitoarch status
  bitoarch add-repo myorg/myrepo
  bitoarch index-repos --only-new-repos
  bitoarch index-repos --mode force --repo myorg/myrepo
  bitoarch config edit repos

DOCS:    ${AI_ARCHITECT_DOCS_HOME_URL:-https://docs.bito.ai/ai-architect}
VERSION: ${CLI_VERSION}

To install or reinstall, use the install bootstrap (curl | bash).
See ${AI_ARCHITECT_DOCS_URL:-https://docs.bito.ai/ai-architect/install-ai-architect-self-hosted} for the install command.
EOF
}

# Source output modules (needed by adapters)
source "${SCRIPT_DIR}/lib/output-blocks.sh"
source "${SCRIPT_DIR}/lib/output-fields.sh"

# Shared MySQL query execution (used by remove-index reconcile/verification)
source "${SCRIPT_DIR}/lib/sql-exec.sh"

# Source adapters
source "${SCRIPT_DIR}/lib/adapters/provider-adapter.sh"
source "${SCRIPT_DIR}/lib/adapters/config-adapter.sh"
source "${SCRIPT_DIR}/lib/adapters/platform-adapter.sh"
source "${SCRIPT_DIR}/lib/adapters/manager-adapter.sh"
source "${SCRIPT_DIR}/lib/adapters/xmcp-adapter.sh"
source "${SCRIPT_DIR}/lib/local-repos-manager.sh"
source "${SCRIPT_DIR}/lib/insights-cli.sh"

# Plugin framework CLI surface (handle_plugin).
source "${SCRIPT_DIR}/lib/plugin/plugin-cli.sh"

# Source diagnose (platform_diagnose entry point + reusable atomic predicates).
# Self-contained -- does not modify any adapter; safe to source after them.
source "${SCRIPT_DIR}/lib/diagnose.sh"

# Source cleanup library (reset_run + uninstall_run)
# NOTE: scripts/lib/install.sh is NOT sourced here. Install is only invoked
# by the CDN bootstrap (scripts/bitoarch-install.sh); there's no
# `bitoarch install` CLI subcommand.
source "${SCRIPT_DIR}/lib/uninstall.sh"

# Lifecycle output blocks (start / restart / update) live in
# scripts/lib/output-blocks.sh: render_lifecycle_success_block,
# render_lifecycle_failure_block.

# Main command dispatcher
main() {
    # Check if no arguments
    if [ $# -eq 0 ]; then
        show_main_help
        exit 0
    fi

    # Handle global --help / --version BEFORE loading config so these work on a
    # fresh clone / pre-install machine (load_env_config hard-fails if there's
    # no .env-bitoarch yet).
    if [ "$1" = "--help" ] || [ "$1" = "-h" ]; then
        show_main_help
        exit 0
    fi

    if [ "$1" = "--version" ] || [ "$1" = "-v" ]; then
        echo "Bito AI Architect CLI v${CLI_VERSION}"
        exit 0
    fi

    # Env-loading tiers:
    #   HARD LOAD (domain commands) — fail if .env-bitoarch missing
    #   SOFT LOAD (discovery commands) — try to load; degrade gracefully pre-install
    #   NO LOAD (pure delegators + unknowns) — setup.sh or the catch-all handles it
    # Unknown commands deliberately fall through so they reach the "*)" catch-all
    # with a clean "Unknown command" error instead of "Config not found".
    case "$1" in
        index-repos|index-status|pause-indexing|resume-indexing|stop-indexing|\
        create-index-scheduler|update-index-scheduler|index-repo-list|show-config|\
        add-repo|remove-repo|remove-index|add-repos|update-repos|repo-info|fetch-repo-list|import-repos|\
        update-api-key|update-git-creds|update-llm-config|rotate-mcp-token|\
        insights|tracker-projects|discover-tracker-projects|\
        mcp-test|mcp-tools|mcp-tool-info|mcp-capabilities|mcp-info|mcp-install|mcp-uninstall|sso)
            load_env_config || exit 1
            ;;
        # restart|update join the SOFT-LOAD tier (not HARD): both handlers self-check a
        # missing .env and delegate to setup.sh (--restart/--update). A HARD `|| exit 1`
        # would preempt that graceful path with a bare "config not found" when the env
        # was removed. With env present, SOFT still loads it for the inline flow.
        status|health|info|mcp-cert|diagnose|plugin|restart|update|wingman)
            # Soft load: env if present, otherwise the handler renders a
            # pre-install banner / state-only output without bailing.
            # diagnose joins this tier because its primary use case is
            # post-install ("why is X broken?") AND pre-install ("why didn't
            # setup finish?").
            [ -f "$(get_config_file)" ] && load_env_config >/dev/null 2>&1 || true
            ;;
    esac

    # Pin kubectl/helm to the cluster.yaml context (via KUBECONFIG) once, up
    # front, so every command below -- and any setup.sh/upgrade.sh it exec's --
    # targets the right cluster regardless of the operator's current kube-context.
    # No-op when cluster.yaml sets no context. A context that is set but absent
    # aborts every mutating command -- acting on an unverified cluster is unsafe.
    # The read-only commands below pass --soft so they still run and report the
    # cause (a `diagnose` that refuses to start when the context is wrong is
    # useless); they read BITOARCH_KUBE_UNREACHABLE instead of querying. Verbs that
    # mutate the cluster are deliberately NOT in that list -- `plugin` runs helm
    # upgrade / kubectl delete pvc, `wingman` applies manifests, `mcp-cert renew`
    # restarts the provider. `config` skips the pin outright: it prints a local path
    # or opens an editor and never contacts the cluster, so the context is irrelevant
    # to it -- and being locked out of `config path` is exactly what an operator needs
    # when they are trying to fix the context. (--help/--version already returned
    # above.)
    if [ "$(get_deployment_type 2>/dev/null)" = "kubernetes" ]; then
        command -v _pin_kube_context >/dev/null 2>&1 \
            || source "${SCRIPT_DIR}/lib/cluster-yaml.sh" 2>/dev/null || true
        if command -v _pin_kube_context >/dev/null 2>&1; then
            case "$1" in
                config)                           : ;;   # local only -- no pin at all
                status|health|info|diagnose|logs) _pin_kube_context --soft || exit 1 ;;
                *)                                _pin_kube_context        || exit 1 ;;
            esac
        fi
    fi

    # Get command
    local command="$1"
    shift


    # Route to direct commands or legacy service handlers
    case "$command" in
        # Core Operations
        index-repos)
            manager_sync_simple "$@"
            ;;
        index-status)
            manager_status "$@"
            ;;
        pause-indexing)
            manager_pause_indexing "$@"
            ;;
        resume-indexing)
            manager_resume_indexing "$@"
            ;;
        stop-indexing)
            manager_stop_indexing "$@"
            ;;
        create-index-scheduler)
            manager_scheduler_create "$@"
            ;;
        update-index-scheduler)
            manager_scheduler_update "$@"
            ;;
        index-repo-list)
            provider_repo_list "$@"
            ;;
        show-config)
            config_repo_get "$@"
            ;;
        
        # Repository Management
        add-repo)
            if [ -f "$1" ]; then
                print_error "Use ${YELLOW}bitoarch add-repos <file>${NC} for YAML files"
                exit 1
            fi
            config_repo_add_namespace "$@"
            ;;
        remove-repo)
            config_repo_remove_namespace "$@"
            ;;
        remove-index)
            manager_remove_index "$@"
            ;;
        add-repos)
            config_repo_add_from_file "$@"
            ;;
        update-repos)
            config_repo_update_from_file "$@"
            ;;
        repo-info)
            provider_repo_info "$@"
            ;;
        fetch-repo-list)
          fetch_repo_config_from_api "$@"
          ;;
        import-repos)
            local_repos_import "$@"
            ;;
        
        # Service status / health / info
        status)
            # Base services, THEN plugins + dep packs, THEN the deployment/logs footer last:
            # platform_status skips its own footer under BITOARCH_DEFER_STATUS_FOOTER, and we print it here.
            BITOARCH_DEFER_STATUS_FOOTER=1 platform_status "$@"
            { _bitoarch_plugin_lifecycle && plugin_lifecycle_status_block; } 2>/dev/null || true
            unset BITOARCH_DEFER_STATUS_FOOTER
            type platform_status_footer >/dev/null 2>&1 && platform_status_footer
            ;;
        health)
            # The EXIT CODE is auto-recovery's failure signal (self-heal runs
            # `bitoarch restart` when it is non-zero): keep the base verdict and
            # fold in the plugin verdict so a crashed plugin also triggers recovery.
            platform_health "$@"
            _health_rc=$?
            # Plugin state is shown by `bitoarch status` (the canonical place); health only
            # folds the plugin verdict into its exit code (auto-recovery signal), no re-print.
            if { _bitoarch_plugin_lifecycle; } 2>/dev/null; then
                plugin_lifecycle_health_ok 2>/dev/null || _health_rc=1
            fi
            return $_health_rc
            ;;
        info)
            platform_info "$@"
            ;;
        diagnose)
            platform_diagnose "$@"
            ;;
        wingman)
            # Shared Wingman shelf (internal/ops): explicit subcommand required.
            local _wsub="${1:-}"
            if [ -z "$_wsub" ]; then
                echo "Usage: bitoarch wingman {status|update}" >&2
                exit 1
            fi
            . "${SCRIPT_DIR}/lib/wingman-shelf.sh" 2>/dev/null || true
            case "$_wsub" in
                status)
                    local _sv _sb _st _sk _base _sbase _cm _cb _ct _ck _seeded
                    _sv="$(wingman_shelf_versions 2>/dev/null)"
                    _sb="${_sv%%|*}"; _sv="${_sv#*|}"; _st="${_sv%%|*}"; _sk="${_sv##*|}"
                    _base="${WINGMAN_DOWNLOAD_BASE_URL:-https://wingman.bito.ai/}"; _base="${_base%/}"
                    _sbase="${MCP_INSTALLER_BASE_URL:-https://mcp-setup.bito.ai}"; _sbase="${_sbase%/}"
                    # Read the seed marker BEFORE deciding to reach the network: a
                    # bundle-seeded shelf is pinned to the packaged build, so the CDN
                    # versions are irrelevant. Probing anyway would stall this command
                    # for two timeouts on exactly the installs the bundle exists for --
                    # ones with no outbound access -- and then print <unreachable>,
                    # which reads like a fault rather than the intended state.
                    _seeded="$(_wingman_fs_apply "" "cat '$(get_wingman_shared_dir)/.bundle_seeded' 2>/dev/null" 2>/dev/null | tr -d '[:space:]')"
                    if [ -z "$_seeded" ]; then
                        _cm="$(curl -sfL -m 15 "${_base}/manifest.json" 2>/dev/null)"
                        _cb="$(printf '%s' "$_cm" | jq -r '."wingman-version" // empty' 2>/dev/null)"
                        _ct="$(printf '%s' "$_cm" | jq -r '."tools-version" // empty' 2>/dev/null)"
                        _ck="$(curl -sfL -m 15 "${_sbase}/skills/manifest.json" 2>/dev/null | jq -r '.version // empty' 2>/dev/null)"
                    fi
                    print_header "Shared Wingman"
                    if [ -n "$_seeded" ]; then
                        printf '   %-9s %-14s %s\n' "" "shelf" "latest (CDN)"
                        printf '   %-9s %-14s %s\n' "Binary:" "${_sb:-<none>}" "not checked"
                        printf '   %-9s %-14s %s\n' "Tools:"  "${_st:-<none>}" "not checked"
                        printf '   %-9s %-14s %s\n' "Skills:" "${_sk:-<none>}" "not checked"
                        printf '   Source:        offline bundle (%s); CDN not contacted\n' "$_seeded"
                        printf '   Override:      bitoarch wingman update (forces a CDN sync)\n'
                    else
                        printf '   %-9s %-14s %s\n' "" "shelf" "latest (CDN)"
                        printf '   %-9s %-14s %s\n' "Binary:" "${_sb:-<none>}" "${_cb:-<unreachable>}"
                        printf '   %-9s %-14s %s\n' "Tools:"  "${_st:-<none>}" "${_ct:-<unreachable>}"
                        printf '   %-9s %-14s %s\n' "Skills:" "${_sk:-<none>}" "${_ck:-<unreachable>}"
                        printf '   Source:        %s\n' "${_base:-<unset>}"
                        printf '   Skills source: %s\n' "${_sbase:-<unset>}"
                    fi
                    ;;
                update)
                    local _rc=0 _outcome
                    BITOARCH_WINGMAN_SYNC_FORCE=1 wingman_shelf_populate wait || _rc=$?
                    # The populate script is best-effort and always exits 0 so a failed
                    # sync can never block a running platform, so its exit code says
                    # nothing about whether anything was fetched. Read the outcome it
                    # records on the shelf instead -- reporting success on an air-gapped
                    # box that reached nothing is the worst possible answer here.
                    _outcome="$(_wingman_fs_apply "" "cat '$(get_wingman_shared_dir)/.last_sync' 2>/dev/null" 2>/dev/null | tr -d '[:space:]')"
                    case "$_outcome" in
                        ok)
                            print_success "Shared Wingman re-synced from the CDN (shelf: $(wingman_shelf_current_version 2>/dev/null))" ;;
                        unreachable)
                            print_warning "CDN unreachable; the shelf is unchanged (shelf: $(wingman_shelf_current_version 2>/dev/null))"
                            print_info "Nothing was downloaded. The existing shelf is intact and still in use." ;;
                        *)
                            if [ "$_rc" -ne 0 ]; then
                                print_warning "Wingman sync could not run; see the log"
                            else
                                print_warning "Wingman sync outcome unknown; see the log"
                            fi ;;
                    esac
                    ;;
                --rollback)
                    # Internal/ops (hidden — intentionally absent from the usage above): re-point the
                    # shelf 'current' to a prior on-shelf version. bitoarch wingman --rollback <version>
                    local _wver="${2:-}"
                    if [ -z "$_wver" ]; then print_error "usage: bitoarch wingman --rollback <version>"; exit 1; fi
                    if wingman_shelf_rollback "$_wver"; then
                        print_success "Shared Wingman rolled back to ${_wver} (shelf: $(wingman_shelf_current_version 2>/dev/null))"
                    else
                        print_error "Wingman rollback failed: version '${_wver}' is not on the shelf"
                        exit 1
                    fi
                    ;;
                *)
                    print_error "Unknown wingman subcommand: $_wsub"
                    echo "Usage: bitoarch wingman {status|update}"
                    exit 1
                    ;;
            esac
            ;;

        # Lifecycle commands -- delegate to setup.sh's existing flag handlers
        # for identical behavior to production (`./setup.sh --X`). Standalone
        # users see exactly the same output and exit codes as prod users.
        stop)
            # Drain plugins before base (e.g. Kafka consumers flush); never blocks.
            if _bitoarch_plugin_lifecycle; then
                plugin_lifecycle_stop_all || log_silent "plugin drain failed during stop; continuing base shutdown" || true
            fi
            exec "${SCRIPT_DIR}/../setup.sh" --stop
            ;;
        # restart -- no install → delegate to setup.sh --restart (same
        # "Services Not Running" UX as prod). With install → compact output
        # matching `bitoarch start`: single progress_run + shared success/
        # failure body. No per-service "✅ Restarted" ticker (industry
        # standard: docker compose restart + helm rollback + kubectl
        # rollout restart all produce terse output).
        restart)
            local env_file force=false
            [ "${1:-}" = "--force" ] && force=true
            # restart --force re-checks the CDN and bumps the shared Wingman shelf
            # (pull-if-newer) BEFORE the services recreate, so they pick up a newer
            # Wingman. Docker only: the busybox one-off runs here because the completed
            # compose populate service is not re-run on --force-recreate. On k8s the
            # chart-owned populate Job re-runs on the helm upgrade that recreate performs,
            # so no CLI populate is needed. A plain restart leaves the shelf untouched
            # (only --force refreshes).
            if [ "$force" = "true" ] && [ "$(get_deployment_type 2>/dev/null)" != "kubernetes" ]; then
                . "${SCRIPT_DIR}/lib/wingman-shelf.sh" 2>/dev/null || true
                type wingman_shelf_populate >/dev/null 2>&1 && wingman_shelf_populate wait
            fi
            env_file=$(get_config_file)
            if [ ! -f "$env_file" ]; then
                if [ "$force" = "true" ]; then
                    exec "${SCRIPT_DIR}/../setup.sh" --force-restart
                fi
                exec "${SCRIPT_DIR}/../setup.sh" --restart
            fi

            # Guard the indexing-concurrency knob before it is applied:
            # cis-manager silently ignores unparseable values and Temporal
            # treats <=0 as "no limit" (1000 activity slots). Warn, don't
            # block (cluster-yaml.sh replicas idiom). Read from the file, not
            # the process env, so the check sees exactly what env_file delivers.
            local _bic
            _bic=$(grep -E '^TEMPORAL_TASK_QUEUE_INDEXING_CONCURRENCY=' "$env_file" 2>/dev/null | tail -1 | cut -d= -f2-)
            if [ -n "$_bic" ] && command -v _is_positive_int >/dev/null 2>&1 && ! _is_positive_int "$_bic"; then
                print_warning "TEMPORAL_TASK_QUEUE_INDEXING_CONCURRENCY='${_bic}' is not a positive integer — the worker ignores unparseable values, and 0/negative removes its concurrency limit entirely. Fix it in: ${env_file}"
            fi

            # Pre-flight: restart requires running services. If zero are
            # running, report that and point at `bitoarch start` instead
            # of silently bringing everything up from nothing. Applies to
            # both plain restart and --force.
            local deploy_type
            deploy_type=$(get_deployment_type 2>/dev/null || echo "docker-compose")
            local _running_any=0
            if [ "$deploy_type" = "kubernetes" ]; then
                _running_any=$(kubectl get pods -n bito-ai-architect --no-headers 2>/dev/null \
                    | awk '$3=="Running"' | wc -l | tr -d ' ')
            else
                _running_any=$(docker ps -q --filter "name=ai-architect-" 2>/dev/null | wc -l | tr -d ' ')
            fi
            if [ "$_running_any" -eq 0 ]; then
                print_warning "No AI Architect services are currently running"
                print_info "To start services, run: ${YELLOW}bitoarch start${NC}"
                exit 1
            fi
            # Surface a bad worker-memory / Node-heap pairing before the services
            # recreate — the same check setup runs, so an operator who hand-edited
            # the env sees the runtime cap here rather than only in the logs.
            if source "${SCRIPT_DIR}/lib/worker-memory.sh" 2>/dev/null \
               && type worker_heap_exceeds_ceiling >/dev/null 2>&1; then
                local _rs_worker_mem _rs_heap_mb _rs_ceiling
                _rs_worker_mem=$(grep -m1 '^CIS_WORKER_MEMORY_LIMIT=' "$env_file" 2>/dev/null | cut -d= -f2- | tr -d '\042\047')
                _rs_worker_mem="${_rs_worker_mem:-$WORKER_MEMORY_DEFAULT_LIMIT}"
                _rs_heap_mb=$(grep -m1 '^CIS_MODULE_BASIC_INDEX_NODE_HEAP_MB=' "$env_file" 2>/dev/null | cut -d= -f2- | tr -d '\042\047')
                if [ -n "$_rs_heap_mb" ] && worker_heap_exceeds_ceiling "$_rs_worker_mem" "$_rs_heap_mb"; then
                    _rs_ceiling=$(worker_heap_ceiling_mb "$_rs_worker_mem")
                    print_warning "CIS_MODULE_BASIC_INDEX_NODE_HEAP_MB (${_rs_heap_mb}MB) exceeds what the cis-worker memory limit (${_rs_worker_mem}) can back after headroom; the worker will cap the Node heap to ${_rs_ceiling}MB at runtime. Raise CIS_WORKER_MEMORY_LIMIT or lower the heap together in .env-bitoarch."
                fi
            fi
            # K8s installs: inline compact flow matching Docker's UX (single
            # progress_run + render_lifecycle_success_block). Uses helpers
            # from kubernetes-manager.sh which silence helm/kubectl output
            # to the setup log so the terminal shows just the progress line.
            if [ "$(get_deployment_type 2>/dev/null)" = "kubernetes" ]; then
                # shellcheck disable=SC1091
                source "${SCRIPT_DIR}/lib/progress-output.sh"
                # shellcheck disable=SC1091
                export SCRIPT_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
                source "${SCRIPT_DIR}/scripts/kubernetes-manager.sh" || log_silent "failed to load kubernetes-manager.sh"
                local progress_label="Restarting AI Architect"
                if [ "$force" = "true" ]; then
                    progress_label="Recreating AI Architect"
                    # Live yaml reload -- source the yaml helpers directly
                    # to avoid pulling in install_run / setup.sh.
                    # shellcheck disable=SC1091
                    source "${SCRIPT_DIR}/scripts/lib/install-yaml.sh" || log_silent "failed to load install-yaml.sh"
                    if command -v validate_install_yaml_api_key >/dev/null 2>&1; then
                        validate_install_yaml_api_key "$env_file" || exit 1
                    fi
                    command -v apply_install_yaml_to_env_file >/dev/null 2>&1 \
                        && apply_install_yaml_to_env_file "$env_file" --if-changed
                fi
                set +e
                progress_run "$progress_label" -- \
                    bash -c "bitoarch_k8s_recreate '$force'"
                local k8s_rc=$?
                set +e
                if [ "$k8s_rc" -eq 0 ]; then
                    if [ "$force" = "true" ]; then
                        render_lifecycle_success_block "AI Architect Recreated" 0
                        _platform_reregister_mcp_with_agents
                    else
                        render_lifecycle_success_block "AI Architect Restarted" 0
                    fi
                    # Fan out to installed plugins (mirrors the Docker branch below).
                    local _plugin_restart_mode=""
                    [ "$force" = "true" ] && _plugin_restart_mode="--force"
                    # shellcheck disable=SC2086
                    { _bitoarch_plugin_lifecycle && plugin_lifecycle_restart_all $_plugin_restart_mode; } >>"$(bitoarch_resolve_log_file 2>/dev/null || echo /dev/null)" 2>&1 || true
                else
                    render_lifecycle_failure_block "restart"
                    exit 1
                fi
                exit 0
            fi
            # shellcheck disable=SC1091
            source "${SCRIPT_DIR}/docker-manager.sh" || log_silent "failed to load docker-manager.sh"
            # shellcheck disable=SC1091
            source "${SCRIPT_DIR}/lib/progress-output.sh"
            local compose_cmd
            compose_cmd=$(get_docker_compose_cmd) || exit 1
            cd "${SCRIPT_DIR}/.." || exit 1

            local action_verb="restart" progress_label="Restarting AI Architect"
            # Full lifecycle list (tracker, temporal, worker INCLUDED for compose
            # ops; hidden only from user-facing status/health UI). Sourced from
            # constants.sh so this list stays in sync with K8s rollout iteration
            # and setup.sh's parity. Falls back to a hardcoded literal if the
            # constant didn't load (defensive; constants.sh is always present
            # in a valid install).
            local svc_list
            if [ -n "${BITOARCH_LIFECYCLE_SERVICES+x}" ] && [ "${#BITOARCH_LIFECYCLE_SERVICES[@]}" -gt 0 ]; then
                svc_list="${BITOARCH_LIFECYCLE_SERVICES[*]}"
            else
                svc_list="ai-architect-mysql ai-architect-temporal ai-architect-config ai-architect-tracker ai-architect-manager ai-architect-worker ai-architect-provider"
            fi

            # Phased up -d in 3 batches with --wait between; --force adds
            # --force-recreate to each. compose restart isn't used because it
            # ignores depends_on (cis-manager / cis-config would start before
            # MySQL healthy and nil-pointer panic on DB ping). The phases also
            # gate cis-manager on cis-config + cis-tracker healthy at runtime.
            local compose_cmd_pre="" extra_flags=""
            if [ "$force" = "true" ]; then
                action_verb="recreate"; progress_label="Recreating AI Architect"
                extra_flags="--force-recreate"
                # Live yaml reload: apply $HOME/.bitoarch/install.yaml
                # onto env_file before recreate. No-op if yaml absent.
                # shellcheck disable=SC1091
                source "${SCRIPT_DIR}/lib/install-yaml.sh" || log_silent "failed to load install-yaml.sh"
                # If the user changed BITO_API_KEY in the yaml, validate it
                # against the tracking endpoint BEFORE rewriting env_file or
                # recreating containers. Bad key = hard fail; users shouldn't
                # silently restart into broken auth.
                if command -v validate_install_yaml_api_key >/dev/null 2>&1; then
                    validate_install_yaml_api_key "$env_file" || exit 1
                fi
                command -v apply_install_yaml_to_env_file >/dev/null 2>&1 \
                    && apply_install_yaml_to_env_file "$env_file" --if-changed
            else
                compose_cmd_pre="$compose_cmd --env-file '$env_file' stop $svc_list"
            fi

            local wait_timeout="${PHASED_WAIT_TIMEOUT_SECS:-900}"
            local phase1="$compose_cmd --env-file '$env_file' up -d --wait --wait-timeout \"$wait_timeout\" $extra_flags ai-architect-mysql ai-architect-temporal"
            local phase2="$compose_cmd --env-file '$env_file' up -d --wait --wait-timeout \"$wait_timeout\" $extra_flags ai-architect-config ai-architect-tracker"
            local phase3="$compose_cmd --env-file '$env_file' up -d --wait --wait-timeout \"$wait_timeout\" $extra_flags ai-architect-manager ai-architect-worker ai-architect-provider ai-architect-ingress"

            _bitoarch_prep_compose_env "$env_file"

            # Disable errexit across the progress_run + rc-capture. Some
            # sourced helpers (or a future caller) may set -e; in that case
            # progress_run's non-zero return would exit bash before we get
            # to inspect $rc.
            set +e
            progress_run "$progress_label" -- \
                bash -c "${compose_cmd_pre:+$compose_cmd_pre && }$phase1 && $phase2 && $phase3 && \
                         wait_for_services_healthy ${RESTART_WAIT_TIMEOUT_SECS:-240} ${SERVICE_WAIT_GRACE_SECS:-60}"
            local rc=$?
            set +e

            # Verify user-visible running state before rendering success.
            # wait_for_services_healthy can return rc=0 on transient
            # "running" states that crash immediately after; rc=2 "warming"
            # is the wrong diagnosis if zero containers are running.
            local running_now=0
            for svc in "${BITOARCH_USER_SERVICES[@]}"; do
                local st
                st=$(docker inspect --format='{{.State.Status}}' "$svc" 2>/dev/null)
                [ "$st" = "running" ] && running_now=$((running_now + 1))
            done
            if [ "$running_now" -eq 0 ]; then
                # Containers are not actually running despite the health-wait
                # result. This is the real user-visible state; render failure
                # accurately so the follow-up `bitoarch status` matches what
                # the lifecycle command just reported.
                render_lifecycle_failure_block "$action_verb"
                exit 1
            fi

            if [ $rc -eq 0 ] || [ $rc -eq 2 ]; then
                if [ "$force" = "true" ]; then
                    render_lifecycle_success_block "AI Architect Recreated" "$rc"
                    _platform_reregister_mcp_with_agents
                    # Match K8s helm post-upgrade hook: re-run Temporal post-deploy on --force recreate.
                    # shellcheck disable=SC1091
                    source "${SCRIPT_DIR}/service-manager.sh" || log_silent "failed to load service-manager.sh"
                    if command -v run_temporal_post_deploy >/dev/null 2>&1; then
                        run_temporal_post_deploy
                    fi
                else
                    render_lifecycle_success_block "AI Architect Restarted" "$rc"
                fi
                _plugin_restart_mode=""; [ "$force" = "true" ] && _plugin_restart_mode="--force"
                # shellcheck disable=SC2086
                { _bitoarch_plugin_lifecycle && plugin_lifecycle_restart_all $_plugin_restart_mode; } >>"$(bitoarch_resolve_log_file 2>/dev/null || echo /dev/null)" 2>&1 || true
            else
                render_lifecycle_failure_block "$action_verb"
                exit 1
            fi
            ;;
        # logs -- no args: delegate to setup.sh --logs (tails all services,
        # same UX as prod `./setup.sh --logs`). With args: filter to the
        # named service via docker compose directly. setup.sh --logs
        # hardcodes the full-stack tail and doesn't accept service args,
        # so we bypass it for the filtered case.
        # Accepts both short names ("manager") and full container names
        # ("ai-architect-manager") -- matches what render_lifecycle_failure_block
        # hints at ("Inspect: bitoarch logs <short-name>").
        logs)
            if [ $# -eq 0 ]; then
                exec "${SCRIPT_DIR}/../setup.sh" --logs
            fi
            # `setup` tails the unified install/lifecycle log; service names
            # tail per-container logs further down.
            if [ "$1" = "setup" ]; then
                exec tail -F "$(get_log_dir)/setup.log"
            fi
            local env_file
            env_file=$(get_config_file)
            if [ ! -f "$env_file" ]; then
                exec "${SCRIPT_DIR}/../setup.sh" --logs
            fi
            # Tail a plugin's logs and exit if the target is one.
            if { _bitoarch_plugin_lifecycle && plugin_lifecycle_logs "$1"; }; then
                exit 0
            fi
            local svc="$1"
            [[ "$svc" != ai-architect-* ]] && svc="ai-architect-$svc"

            # Branch by deployment type. K8s installs must use kubectl logs
            # (docker compose is unavailable); Docker installs use compose.
            local deploy_type
            deploy_type=$(get_deployment_type 2>/dev/null || echo "unknown")
            if [ "$deploy_type" = "kubernetes" ]; then
                local namespace="bito-ai-architect"
                # --max-log-requests is required, not tuning: kubectl refuses to follow
                # more than 5 streams by default and then prints NOTHING. With
                # --all-containers each pod contributes every container (worker and
                # manager have 5 apiece: main + 4 init waits), so a service breaks from
                # 2 replicas onward -- the scaled setup multi-node deployments use.
                # 50 covers 10 replicas of the widest service. --tail=100 matches the
                # all-services path: with a selector kubectl tails only 10 lines per
                # stream by default, which is too little to debug from.
                exec kubectl logs -f -n "$namespace" \
                    -l "app.kubernetes.io/component=${svc#ai-architect-}" \
                    --all-containers=true --max-log-requests=50 --tail=100
            fi

            # shellcheck disable=SC1091
            source "${SCRIPT_DIR}/docker-manager.sh" || log_silent "failed to load docker-manager.sh"
            local compose_cmd
            compose_cmd=$(get_docker_compose_cmd) || exit 1
            cd "${SCRIPT_DIR}/.." || exit 1
            exec $compose_cmd --env-file "$env_file" logs -f "$svc"
            ;;
        # update -- refresh service images per versions/service-versions.json.
        # Multi-step (pull is distinctly slow + user-meaningful; the two
        # phases match cargo/kubectl convention for deploy-then-roll).
        # No per-service tickers (industry standard: docker compose pull
        # shows its own per-image progress when unsilenced; our wrapper
        # silences it and emits a single step line).
        update)
            local env_file
            env_file=$(get_config_file)
            if [ ! -f "$env_file" ]; then
                exec "${SCRIPT_DIR}/../setup.sh" --update
            fi
            # The shared Wingman shelf is refreshed on update by the chart-owned populate
            # Job (k8s), which re-runs on the helm upgrade this update performs (pull-if-
            # newer), and by the compose one-shot on docker (ordered before base services).
            # K8s installs: inline compact flow via bitoarch_k8s_update
            # (bumps version tags + helm upgrade + rollout; silent). Matches
            # the Docker UX — single progress_run + unified success block.
            if [ "$(get_deployment_type 2>/dev/null)" = "kubernetes" ]; then
                # shellcheck disable=SC1091
                source "${SCRIPT_DIR}/lib/progress-output.sh"
                export SCRIPT_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
                # shellcheck disable=SC1091
                source "${SCRIPT_DIR}/scripts/kubernetes-manager.sh" || log_silent "failed to load kubernetes-manager.sh"
                set +e
                progress_run "Updating AI Architect" -- \
                    bash -c "bitoarch_k8s_update"
                local k8s_upd_rc=$?
                if [ "$k8s_upd_rc" -eq 0 ]; then
                    render_lifecycle_success_block "AI Architect Updated" 0
                    { _bitoarch_plugin_lifecycle && plugin_lifecycle_update_all; } >>"$(bitoarch_resolve_log_file 2>/dev/null || echo /dev/null)" 2>&1 || true
                else
                    render_lifecycle_failure_block "update"
                    exit 1
                fi
                exit 0
            fi
            # shellcheck disable=SC1091
            source "${SCRIPT_DIR}/docker-manager.sh" || log_silent "failed to load docker-manager.sh"
            # shellcheck disable=SC1091
            source "${SCRIPT_DIR}/lib/progress-output.sh"
            # shellcheck disable=SC1091
            source "${SCRIPT_DIR}/env-generator.sh" || log_silent "failed to load env-generator.sh"
            export -f refresh_versions_from_service_json 2>/dev/null || true
            local compose_cmd
            compose_cmd=$(get_docker_compose_cmd) || exit 1
            cd "${SCRIPT_DIR}/.." || exit 1

            # Full lifecycle list (tracker, temporal, worker INCLUDED for compose
            # ops; hidden only from user-facing status/health UI). Sourced from
            # constants.sh; see the equivalent block in `restart` for rationale.
            local svc_list
            if [ -n "${BITOARCH_LIFECYCLE_SERVICES+x}" ] && [ "${#BITOARCH_LIFECYCLE_SERVICES[@]}" -gt 0 ]; then
                svc_list="${BITOARCH_LIFECYCLE_SERVICES[*]}"
            else
                svc_list="ai-architect-mysql ai-architect-temporal ai-architect-config ai-architect-tracker ai-architect-manager ai-architect-worker ai-architect-provider"
            fi
            local versions_file="${SCRIPT_DIR}/../versions/service-versions.json"

            set +e  # guard against errexit from sourced helpers; see start/restart
            progress_start_multi 2
            # refresh_versions_from_service_json takes 1 arg (env_file) and
            # derives versions_file from $SCRIPT_DIR internally. Set the
            # REPO ROOT as SCRIPT_DIR inside the child bash so the derived
            # path resolves to versions/service-versions.json correctly.
            # (bitoarch.sh's SCRIPT_DIR points at scripts/, not repo root.)
            local repo_root
            repo_root=$(cd "${SCRIPT_DIR}/.." && pwd)
            progress_step "Pulling latest images" -- \
                bash -c "SCRIPT_DIR='$repo_root' refresh_versions_from_service_json '$env_file' >/dev/null 2>&1 && \
                         $compose_cmd --env-file '$env_file' pull $svc_list"
            local pull_rc=$?
            if [ "$pull_rc" -ne 0 ]; then
                render_lifecycle_failure_block "update"
                exit 1
            fi
            # Provision + mount the MCP HTTPS cert BEFORE recreating the provider:
            # exports HOST_MCP_CERT_DIR + XMCP_INTERNAL_PORT so the phased `up`
            # below remounts the real cert dir. Without it the provider recreates
            # against the empty default certs mount and crash-loops on a missing
            # server.key. Mirrors start/restart (523/789); no-op on Enterprise/http.
            _bitoarch_prep_compose_env "$env_file"
            # Phased up -d --force-recreate in 3 batches with --wait, mirroring
            # the restart path; see the comment in the `restart` case for the
            # depends_on / cold-boot-panic rationale.
            local upd_wait_timeout="${PHASED_WAIT_TIMEOUT_SECS:-900}"
            local upd_phase1="$compose_cmd --env-file '$env_file' up -d --wait --wait-timeout \"$upd_wait_timeout\" --force-recreate ai-architect-mysql ai-architect-temporal"
            local upd_phase2="$compose_cmd --env-file '$env_file' up -d --wait --wait-timeout \"$upd_wait_timeout\" --force-recreate ai-architect-config ai-architect-tracker"
            local upd_phase3="$compose_cmd --env-file '$env_file' up -d --wait --wait-timeout \"$upd_wait_timeout\" --force-recreate ai-architect-manager ai-architect-worker ai-architect-provider ai-architect-ingress"
            progress_step "Restarting services" -- \
                bash -c "$upd_phase1 && $upd_phase2 && $upd_phase3 && \
                         wait_for_services_healthy ${RESTART_WAIT_TIMEOUT_SECS:-240} ${SERVICE_WAIT_GRACE_SECS:-60}"
            local restart_rc=$?
            if [ "$restart_rc" -eq 0 ] || [ "$restart_rc" -eq 2 ]; then
                render_lifecycle_success_block "AI Architect Updated" "$restart_rc"
                # Match K8s helm post-upgrade hook: re-run Temporal post-deploy after image update.
                # shellcheck disable=SC1091
                source "${SCRIPT_DIR}/service-manager.sh" || log_silent "failed to load service-manager.sh"
                if command -v run_temporal_post_deploy >/dev/null 2>&1; then
                    run_temporal_post_deploy
                fi
                { _bitoarch_plugin_lifecycle && plugin_lifecycle_update_all; } >>"$(bitoarch_resolve_log_file 2>/dev/null || echo /dev/null)" 2>&1 || true
            else
                render_lifecycle_failure_block "update"
                exit 1
            fi
            ;;
        # upgrade -- thin CLI layer. By default execs the current install's
        # scripts/upgrade.sh; after it extracts the new tarball, it chain-
        # loads the NEW tarball's scripts/upgrade.sh (Phase 2) for the
        # version-specific upgrade logic. Tarball CDN is the single source
        # of truth (no GitHub dependency).
        #
        # Flags (upgrade.sh-native; CLI only intercepts --source):
        #   --source=<path>    Use this upgrade.sh instead of the installed
        #                      one. For testing an unreleased upgrade.sh
        #                      against an existing prod install without
        #                      building a new tarball.
        #   --url=<tarball>    Tarball to upgrade to (local file:// or HTTP).
        #   --version=<ver>    Specific version instead of latest.
        #   --old-path=<dir>   Override auto-detected old install dir.
        upgrade)
            local source_script="" forward_args=()
            for arg in "$@"; do
                case "$arg" in
                    --source=*) source_script="${arg#--source=}" ;;
                    *)          forward_args+=("$arg") ;;
                esac
            done
            local upgrade_script="${SCRIPT_DIR}/upgrade.sh"
            if [ -n "$source_script" ]; then
                upgrade_script="$source_script"
                if [ ! -r "$upgrade_script" ]; then
                    echo -e "${RED}✗${NC} --source script not readable: ${upgrade_script}" >&2
                    exit 1
                fi
                echo -e "${BLUE}ℹ${NC} Using custom upgrade script: ${upgrade_script}"
            fi
            # Refuse a base upgrade an incompatible plugin blocks; args still pass through.
            local _target_ver="" _a _stripped
            for _a in "${forward_args[@]}"; do
                _stripped="${_a#--version=}"
                [ "$_stripped" != "$_a" ] && _target_ver="$_stripped"
            done
            if [ -n "$_target_ver" ] && ! { _bitoarch_plugin_lifecycle && plugin_lifecycle_upgrade_guard "$_target_ver"; }; then
                print_error "Base upgrade to ${_target_ver} refused: an installed plugin requires a newer base. See 'bitoarch plugin status'."
                exit 1
            fi
            exec bash "$upgrade_script" "${forward_args[@]}"
            ;;

        # start -- no install → delegate to setup.sh --restart (same "Services
        # Not Running" UX as prod). With install → single progress_run wraps
        # compose up AND wait_for_containers_running (chained with &&). The
        # wait is part of starting, not a user-visible phase. On success we
        # print 3 body lines inline: "ready" sentence, MCP endpoint URL, and
        # Next: hints. On failure we list the services that didn't reach
        # running state with actionable `bitoarch logs <svc>` hints.
        start)
            local env_file
            env_file=$(get_config_file)
            if [ ! -f "$env_file" ]; then
                exec "${SCRIPT_DIR}/../setup.sh" --restart
            fi
            # K8s: setup.sh --restart brings the base up (as a child, not exec, so
            # the plugin fan-out below still runs), then start installed plugins.
            if [ "$(get_deployment_type 2>/dev/null)" = "kubernetes" ]; then
                "${SCRIPT_DIR}/../setup.sh" --restart
                local _k8s_start_rc=$?
                # Plugin fan-out is best-effort; the base rc decides the exit code.
                { _bitoarch_plugin_lifecycle && plugin_lifecycle_start_all; } >>"$(bitoarch_resolve_log_file 2>/dev/null || echo /dev/null)" 2>&1 || true
                exit "$_k8s_start_rc"
            fi
            # shellcheck disable=SC1091
            source "${SCRIPT_DIR}/docker-manager.sh" || log_silent "failed to load docker-manager.sh"
            # shellcheck disable=SC1091
            source "${SCRIPT_DIR}/lib/progress-output.sh"
            local compose_cmd
            compose_cmd=$(get_docker_compose_cmd) || exit 1
            cd "${SCRIPT_DIR}/.." || exit 1

            _bitoarch_prep_compose_env "$env_file"

            # Single step: compose up && container-state wait. progress_run
            # handles ✓/✗ + timing + failure log path.
            # Single progress_run wraps compose-up + health-wait. The health
            # wait uses .State.Health.Status (not just state=running) so we
            # don't claim "Ready" while provider/config are still warming up.
            # Return-code contract (from wait_for_services_healthy):
            #   0 = all healthy  → ✅ AI Architect Ready
            #   2 = soft-timeout → ℹ AI Architect Starting (warming up)
            #   1 = hard-fail    → enumerate failing services (below `else`)
            # Uses the same compact body + 3-state outcome handling as
            # `bitoarch restart` (shared helpers: _lifecycle_print_*_body).
            # set +e: guard against any errexit set by a sourced helper --
            # a non-zero return from progress_run would otherwise trip the
            # EXIT trap and skip our rc-dispatch below.
            set +e
            progress_run "Starting AI Architect" -- \
                bash -c "$compose_cmd --env-file '$env_file' up -d && \
                         wait_for_services_healthy ${RESTART_WAIT_TIMEOUT_SECS:-240} ${SERVICE_WAIT_GRACE_SECS:-60}"
            local rc=$?
            if [ $rc -eq 0 ] || [ $rc -eq 2 ]; then
                render_lifecycle_success_block "AI Architect Ready" "$rc"
                # Match K8s start-after-stop redeploy: re-run Temporal post-deploy on cold start.
                # shellcheck disable=SC1091
                source "${SCRIPT_DIR}/service-manager.sh" || log_silent "failed to load service-manager.sh"
                if command -v run_temporal_post_deploy >/dev/null 2>&1; then
                    run_temporal_post_deploy
                fi
                # Start plugins after base is healthy.
                { _bitoarch_plugin_lifecycle && plugin_lifecycle_start_all; } >>"$(bitoarch_resolve_log_file 2>/dev/null || echo /dev/null)" 2>&1 || true
            else
                render_lifecycle_failure_block "start"
                exit 1
            fi
            ;;

        uninstall)
            # Footgun guard: `bitoarch uninstall <plugin>` (a single arg naming an
            # installed plugin) is almost always meant as a PLUGIN uninstall, not a
            # full-platform teardown that happens to be passed a stray arg. Route it
            # to the plugin verb so the operator does not accidentally tear down the
            # whole stack. Bare `bitoarch uninstall` (no arg) still uninstalls the base.
            if [ -n "${1:-}" ] && [ "${1#-}" = "$1" ] \
               && _bitoarch_plugin_lifecycle 2>/dev/null \
               && journal_plugin_exists "$1" 2>/dev/null; then
                handle_plugin uninstall "$@"
                return $?
            fi
            # Same semantics as the plugin verb: keep data by default, --purge removes it.
            local _un_purge=0 _un_yes=0 _un_arg _un_reply
            for _un_arg in "$@"; do
                case "$_un_arg" in
                    --purge) _un_purge=1 ;;
                    --yes|-y) _un_yes=1 ;;
                    --help|-h) uninstall_run --help; return 0 ;;
                esac
            done
            if [ "$_un_purge" -eq 1 ]; then
                if [ "$_un_yes" -ne 1 ]; then
                    print_warning "This removes AI Architect INCLUDING all data and configuration (databases, repos, plugins)."
                    read -r -p "Type 'yes' to continue: " _un_reply; echo ""
                    [ "$_un_reply" = "yes" ] || { print_info "Uninstall cancelled."; return 0; }
                fi
                { _bitoarch_plugin_lifecycle && plugin_lifecycle_reset; } 2>/dev/null || true
                BITOARCH_RESET_CONFIRMED=1 exec "${SCRIPT_DIR}/../setup.sh" --clean
            fi
            if [ "$_un_yes" -ne 1 ]; then
                printf 'This removes the running services. Data and configuration are kept, %bbitoarch start%b brings everything back.\n' "${YELLOW:-}" "${NC:-}"
                read -r -p "Continue? [y/N]: " _un_reply; echo ""
                case "$_un_reply" in [Yy]*) ;; *) print_info "Uninstall cancelled."; return 0 ;; esac
            fi
            # Remove plugin + pack containers first (their config and data stay).
            { _bitoarch_plugin_lifecycle && plugin_lifecycle_down_all; } 2>/dev/null || true
            uninstall_keep_run
            ;;

        config)
            local subcmd="${1:-}"; shift 2>/dev/null || true
            case "$subcmd" in
                path)
                    case "${1:-env}" in
                        env)   echo "$(get_config_file)" ;;
                        repos) echo "$(get_repo_config_file)" ;;
                        llm)   echo "$(get_llm_config_file)" ;;
                        *)     echo "ERROR: Unknown config name: ${1} (env|repos|llm)" >&2; exit 1 ;;
                    esac
                    ;;
                edit)
                    local cfg_path="" cfg_name="${1:-env}"
                    case "$cfg_name" in
                        env)   cfg_path="$(get_config_file)" ;;
                        repos) cfg_path="$(get_repo_config_file)" ;;
                        llm)   cfg_path="$(get_llm_config_file)" ;;
                        *)     echo "ERROR: Unknown config name: ${1} (env|repos|llm)" >&2; exit 1 ;;
                    esac
                    if [ ! -f "$cfg_path" ]; then
                        # Three cases for a missing config file:
                        #   llm   → optional, auto-create template (user fills in)
                        #   env   → install hasn't happened; point at install bootstrap
                        #   repos → install happened (env exists) but no repos
                        #           configured yet → point at `bitoarch add-repos` /
                        #           `bitoarch fetch-repo-list`
                        case "$cfg_name" in
                            llm)
                                mkdir -p "$(dirname "$cfg_path")" 2>/dev/null
                                cat > "$cfg_path" <<'EOF'
# Bito AI Architect — Custom LLM Provider Configuration (optional)
# Uncomment and fill the keys you want to use. Leave empty to fall back to
# the Bito-managed LLM pool. Changes take effect on next `bitoarch restart`.

# ANTHROPIC_API_TOKEN=
# OPENAI_API_TOKEN=
# PORTKEY_API_TOKEN=
# PORTKEY_MODEL_NAME=
EOF
                                chmod 600 "$cfg_path" 2>/dev/null
                                echo "Created $cfg_path (template)."
                                ;;
                            env)
                                {
                                    echo -e "${RED}✗${NC} AI Architect is not installed."
                                    echo "  Config file expected at: ${cfg_path}"
                                    echo ""
                                    echo -e "${BLUE}💡 Install first${NC}"
                                    echo -e "   From a clone:    ${YELLOW}./scripts/bitoarch-install-standalone.sh${NC}"
                                    echo -e "   Production:      ${YELLOW}./scripts/bitoarch-install.sh${NC}"
                                    echo -e "   From CDN:        ${YELLOW}bash <(curl -fsSL \$UPGRADE_DOWNLOAD_URL/scripts/bitoarch-install-standalone.sh)${NC}"
                                } >&2
                                exit 1
                                ;;
                            repos)
                                # If env-bitoarch exists, install DID happen; user just
                                # hasn't added repos yet. Point at the right command.
                                if [ -f "$(get_config_file)" ]; then
                                    {
                                        echo -e "${YELLOW}⚠${NC} No repositories configured yet."
                                        echo "  Config file will be created at: ${cfg_path}"
                                        echo ""
                                        echo -e "${BLUE}💡 Add repositories${NC}"
                                        echo -e "   • Discover from Git provider:  ${YELLOW}bitoarch fetch-repo-list${NC}"
                                        echo -e "   • Add a single repo:           ${YELLOW}bitoarch add-repo <namespace>${NC}"
                                        echo -e "   • Load from a YAML file:       ${YELLOW}bitoarch add-repos <file>${NC}"
                                        echo ""
                                        echo -e "   Once configured, ${YELLOW}bitoarch config edit repos${NC} will open the file."
                                    } >&2
                                    exit 1
                                else
                                    # No env either → same message as env case.
                                    {
                                        echo -e "${RED}✗${NC} AI Architect is not installed."
                                        echo "  Config file expected at: ${cfg_path}"
                                        echo ""
                                        echo -e "${BLUE}💡 Install first${NC}"
                                        echo -e "   From a clone:    ${YELLOW}./scripts/bitoarch-install-standalone.sh${NC}"
                                        echo -e "   Production:      ${YELLOW}./scripts/bitoarch-install.sh${NC}"
                                    } >&2
                                    exit 1
                                fi
                                ;;
                        esac
                    fi
                    # Route detail to setup.log; only the headline goes to
                    # the user. log_silent is a no-op if LOG_FILE is unset.
                    : "${LOG_FILE:=$(get_setup_log 2>/dev/null)}"

                    # Resolve $EDITOR, warn on Windows editors, back up, open,
                    # and normalize BOM/CRLF — shared with the install-time
                    # pre-seed editor (scripts/lib/editor.sh).
                    open_editor_with_normalization "$cfg_path" "$cfg_name"
                    local editor_rc=$?
                    if [ "$editor_rc" -ne 0 ]; then
                        exit "$editor_rc"
                    fi
                    local pre_edit_backup="${EDITOR_PRE_EDIT_BACKUP:-}"

                    # Post-edit validation. Only the YAML repos config has a
                    # strict structural schema we can verify here; env/llm
                    # files are flat key=value and pass through after normalize.
                    # Helper falls back to python3 if yq is unavailable, and
                    # silently passes if neither tool is present.
                    if [ "$cfg_name" = "repos" ] && [ -f "$cfg_path" ]; then
                        if ! _validate_repos_yaml_shape "$cfg_path" ""; then
                            log_silent "config edit: validation failed for $cfg_path"
                            if [ -n "$pre_edit_backup" ] && [ -f "$pre_edit_backup" ]; then
                                if cp "$pre_edit_backup" "$cfg_path" 2>/dev/null; then
                                    print_warning "Restored previous version from backup."
                                    log_silent "config edit: restored $cfg_path from $pre_edit_backup"
                                else
                                    print_error "Restore from backup failed; see ${LOG_FILE:-setup.log} for the backup path."
                                    log_silent "config edit: restore FAILED — backup at $pre_edit_backup, target $cfg_path"
                                fi
                            else
                                print_warning "No pre-edit backup available; broken file left in place."
                            fi
                            exit 1
                        fi
                    fi
                    ;;
                ""|--help|-h)
                    cat <<'EOF'
USAGE:
  bitoarch config {path|edit} [env|repos|llm]

  path    Print absolute path to the named config file
  edit    Open the named config file in $EDITOR (default: vi)

  Target names: env (default), repos, llm
EOF
                    ;;
                *)
                    echo "ERROR: Unknown config subcommand: ${subcmd}" >&2
                    echo "Usage: bitoarch config {path|edit} [env|repos|llm]"
                    exit 1
                    ;;
            esac
            ;;
        
        # Configuration
        update-api-key)
            platform_update_api_key "$@"
            { _bitoarch_plugin_lifecycle && plugin_lifecycle_cred_rotation_restart BITO_API_KEY; } 2>/dev/null || true
            ;;
        update-git-creds)
            platform_update_git_creds "$@"
            { _bitoarch_plugin_lifecycle && plugin_lifecycle_cred_rotation_restart ""; } 2>/dev/null || true
            ;;
        update-llm-config)
            platform_update_llm_config "$@"
            { _bitoarch_plugin_lifecycle && plugin_lifecycle_cred_rotation_restart ""; } 2>/dev/null || true
            ;;
        rotate-mcp-token)
            platform_rotate_token "$@"
            { _bitoarch_plugin_lifecycle && plugin_lifecycle_cred_rotation_restart BITO_MCP_ACCESS_TOKEN; } 2>/dev/null || true
            ;;
        insights)
            handle_insights "$@"
            ;;
        tracker-projects)
            handle_insights tracker-projects "$@"
            ;;
        discover-tracker-projects)
            handle_insights discover-tracker-projects "$@"
            ;;

        # MCP Operations
        mcp-test)
            provider_mcp_test "$@"
            ;;
        mcp-tools)
            provider_mcp_tools "$@"
            ;;
        mcp-tool-info)
            provider_mcp_tool_info "$@"
            ;;
        mcp-capabilities)
            provider_mcp_capabilities "$@"
            ;;
        mcp-info)
            platform_mcp "$@"
            ;;
        mcp-install|mcp-uninstall|mcp-cert)
            # Gated on the MCP_AUTO_INSTALL feature flag. Standalone install_run
            # sets this true; Enterprise / shared deploys leave it false, so the
            # local-MCP CLI surface stays hidden + refused there.
            if ! { command -v mcp_auto_install_enabled >/dev/null 2>&1 && mcp_auto_install_enabled; }; then
                print_error "\`bitoarch ${command}\` is a Standalone-only command and is not available on this install."
                print_info  "Docs: ${BITO_STANDALONE_MCP_DOCS_URL:-https://docs.bito.ai/ai-architect/standalone-mcp-coding-agents}"
                exit 1
            fi
            case "$command" in
                mcp-install)
                    # shellcheck disable=SC1091
                    source "${SCRIPT_DIR}/lib/mcp-installer.sh"
                    mcp_installer_cli "$@"
                    ;;
                mcp-uninstall)
                    # shellcheck disable=SC1091
                    source "${SCRIPT_DIR}/lib/mcp-uninstaller.sh"
                    mcp_uninstaller_cli "$@"
                    ;;
                *)
                    # shellcheck disable=SC1091
                    source "${SCRIPT_DIR}/lib/mcp-cert-cli.sh"
                    mcp_cert_cli "$@"
                    ;;
            esac
            ;;
        
        # Plugin framework
        plugin)
            handle_plugin "$@"
            ;;

        # SSO Management
        sso)
            handle_sso "$@"
            # Bounce plugins that inherit a rotated SSO key.
            if [ "${1:-}" = "rotate-key" ]; then
                { _bitoarch_plugin_lifecycle && plugin_lifecycle_cred_rotation_restart ""; } 2>/dev/null || true
            fi
            ;;
        
        *)
            print_error "Unknown command: $command"
            echo ""
            echo "Use 'bitoarch --help' to see available commands"
            exit 1
            ;;
    esac
}

# Execute main function and exit with its return code
main "$@"
exit $?
