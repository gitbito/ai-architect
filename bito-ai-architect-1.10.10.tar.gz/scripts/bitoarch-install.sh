#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
#
# scripts/bitoarch-install.sh
# -----------------------------------------------------------------------------
# PRODUCTION edition install bootstrap.
#
# Two modes, auto-detected:
#
#   LOCAL mode
#     Run from inside an already-extracted tarball. scripts/lib/install.sh and
#     docker-compose.yml are present alongside. Action: install from current
#     dir (no download, no extract).
#
#   CDN mode
#     Fetched via `curl | bash`. Action: download the production tarball from
#     UPGRADE_DOWNLOAD_URL, extract to ~/bito-ai-architect, then install.
#
# Install flow:
#   install_run() in scripts/lib/install.sh sources setup.sh and calls its
#   main(). The production install path is entirely driven by setup.sh; this
#   bootstrap exists only to handle the curl|bash / tarball-extraction step.
#
# CDN URL (CDN mode only):
#   Read from UPGRADE_DOWNLOAD_URL. The release pipeline injects this value
#   when publishing the bootstrap at origin.
#
# Distribution:
#   Hosted at CDN AND shipped in the production tarball (same file serves
#   both modes). Standalone has a sibling bootstrap at
#   scripts/bitoarch-install-standalone.sh hosted on a separate CDN URL.
#
# -----------------------------------------------------------------------------
# INTENTIONAL DUPLICATION with scripts/bitoarch-install-standalone.sh
# -----------------------------------------------------------------------------
#   This file and scripts/bitoarch-install-standalone.sh are siblings served
#   from TWO separate CDN URLs (production vs standalone). Each must be FULLY
#   SELF-CONTAINED because it is the `curl | bash` target -- it runs before
#   any tarball has been downloaded, so it cannot `source` any other file.
#
#   MUST STAY DIVERGENT (edition-specific):
#     - Header comment block (edition docs)
#     - TARBALL_FILENAME / TEMP_DIR / EDITION constants
#     - show_help() body (edition UX)
#
#   MUST STAY IDENTICAL (keep in lockstep when editing either file):
#     - _bootstrap_die, parse_args, bootstrap_check_prerequisites,
#       bootstrap_download, bootstrap_extract,
#       bootstrap_handoff_to_install_run, cleanup, main
#
#   Any edit to a shared function here MUST also land in the sibling file
#   (and vice versa). A future packaging-time concatenation pass could remove
#   the duplication by sourcing a lib file into both bootstraps at publish
#   time, but today the manual lockstep is the cost of curl|bash.
# -----------------------------------------------------------------------------

set -e

# Buffer the whole script so bash doesn't re-read fd 0 after exec 0</dev/tty.
{

# -----------------------------------------------------------------------------
# Configuration (env-var driven; see header)
# -----------------------------------------------------------------------------
# No baked-in origin: the release pipeline rewrites this whole line (and
# VERSION) when publishing, and an unset value must reach the CDN-mode guard
# in bootstrap_check_prerequisites instead of silently defaulting to an
# origin that does not carry every edition or channel.
DOWNLOAD_BASE_URL="${UPGRADE_DOWNLOAD_URL:-}"
VERSION="latest"
TARBALL_FILENAME="bito-ai-architect-${VERSION}.tar.gz"
TEMP_DIR="/tmp/bito-install-$$"
EDITION="production"

# Resolve our own on-disk location (through any symlinks)
_SCRIPT_SELF="${BASH_SOURCE[0]}"
while [[ -L "$_SCRIPT_SELF" ]]; do
    _SCRIPT_SELF="$(readlink "$_SCRIPT_SELF")"
done
SCRIPT_OWN_DIR="$(cd "$(dirname "$_SCRIPT_SELF")" && pwd)"
TARBALL_ROOT_CANDIDATE="$(cd "${SCRIPT_OWN_DIR}/.." && pwd)"

# Auto-detect mode
if [[ -f "${TARBALL_ROOT_CANDIDATE}/scripts/lib/install.sh" ]] \
   && [[ -f "${TARBALL_ROOT_CANDIDATE}/docker-compose.yml" ]]; then
    INSTALL_MODE="local"
    INSTALL_DIR="$TARBALL_ROOT_CANDIDATE"
else
    INSTALL_MODE="cdn"
    INSTALL_DIR="${HOME}/bito-ai-architect"
fi

# -----------------------------------------------------------------------------
# Minimal bootstrap-only error helper. User-visible install output is produced
# by setup.sh via cli-core's print_* (sourced during install_run), so we don't
# introduce any new decoration here.
# -----------------------------------------------------------------------------
_bootstrap_die() { echo "ERROR: $*" >&2; exit 1; }

# -----------------------------------------------------------------------------
# Help
# -----------------------------------------------------------------------------
show_help() {
    cat <<EOF
Bito AI Architect -- Install (Production edition)

USAGE:
  ./scripts/bitoarch-install.sh [--auto] [--help]

MODES:
  INTERACTIVE (default)   Prompts for any required values.
  AUTO / NON-INTERACTIVE  (AUTO_SETUP=true or --auto) No prompts.

OPTIONS:
  --auto, --non-interactive   Same as AUTO_SETUP=true
  --help, -h                  Show this help

ENV VARS:
  AUTO_SETUP=true             Non-interactive mode
  UPGRADE_DOWNLOAD_URL=<url>  Install CDN base URL (CDN mode only)
EOF
}

# -----------------------------------------------------------------------------
# Parse args (--help, --auto). Unknown args forwarded to install_run.
# -----------------------------------------------------------------------------
parse_args() {
    INSTALL_EXTRA_ARGS=()
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --help|-h)                  show_help; exit 0 ;;
            --auto|--non-interactive)   export AUTO_SETUP=true; shift ;;
            *)                          INSTALL_EXTRA_ARGS+=("$1"); shift ;;
        esac
    done
}

# -----------------------------------------------------------------------------
# CDN-only prerequisites (URL set, curl+tar present). Docker-running check is
# done by setup.sh's check_prerequisites, so we don't duplicate it here.
# -----------------------------------------------------------------------------
bootstrap_check_prerequisites() {
    if [[ "$INSTALL_MODE" = "cdn" ]]; then
        if [[ -z "$DOWNLOAD_BASE_URL" ]]; then
            _bootstrap_die "UPGRADE_DOWNLOAD_URL is not set (required in CDN mode)."
        fi
        local missing=()
        for tool in curl tar; do
            command -v "$tool" >/dev/null 2>&1 || missing+=("$tool")
        done
        if [[ ${#missing[@]} -gt 0 ]]; then
            _bootstrap_die "Missing required tools: ${missing[*]}"
        fi
    fi
}

# -----------------------------------------------------------------------------
# CDN mode: download tarball
# -----------------------------------------------------------------------------
bootstrap_download() {
    mkdir -p "$TEMP_DIR"
    local tarball_url="${DOWNLOAD_BASE_URL}/${VERSION}/${TARBALL_FILENAME}"
    local tarball_path="${TEMP_DIR}/${TARBALL_FILENAME}"

    if ! curl -# -L -f -o "$tarball_path" "$tarball_url"; then
        _bootstrap_die "Download failed: ${tarball_url}"
    fi
    [[ -s "$tarball_path" ]] || _bootstrap_die "Downloaded file is empty"
    echo "$tarball_path"
}

# -----------------------------------------------------------------------------
# CDN mode: extract tarball (idempotent; replaces existing install dir)
# -----------------------------------------------------------------------------
bootstrap_extract() {
    local tarball_path="$1"
    mkdir -p "$INSTALL_DIR"
    # On extract failure, keep the dir only if the canonical tarball marker
    # (scripts/lib/install.sh) exists -- that lets a retry proceed.
    if ! tar -xzf "$tarball_path" -C "$INSTALL_DIR" --strip-components=1; then
        [[ -f "${INSTALL_DIR}/scripts/lib/install.sh" ]] || rm -rf "$INSTALL_DIR"
        _bootstrap_die "Extraction failed"
    fi
    if [[ ! -f "${INSTALL_DIR}/scripts/lib/install.sh" ]]; then
        _bootstrap_die "Invalid package (missing scripts/lib/install.sh)"
    fi
    find "${INSTALL_DIR}/scripts" -name "*.sh" -type f -exec chmod +x {} \; 2>/dev/null || true
    # Both `bitoarch` CLI and `setup.sh` ship in both tarballs; chmod both
    # unconditionally so this function stays identical across siblings.
    # Both files already ship with the exec bit set, so a chmod failure must
    # warn, never abort the install (these scripts run under `set -e`).
    [[ -f "${INSTALL_DIR}/bitoarch" ]] && { chmod +x "${INSTALL_DIR}/bitoarch" || echo "WARN: could not chmod +x ${INSTALL_DIR}/bitoarch" >&2; }
    [[ -f "${INSTALL_DIR}/setup.sh" ]] && { chmod +x "${INSTALL_DIR}/setup.sh" || echo "WARN: could not chmod +x ${INSTALL_DIR}/setup.sh" >&2; }
    true
}

# -----------------------------------------------------------------------------
# Handoff: set SCRIPT_DIR/PLATFORM_DIR (prod convention), source the install
# library, call install_run (which delegates to setup.sh::main).
#
# set +e is required because install_run sources adapter files that do
# `source <optional> || true`, and bash's source builtin interacts badly with
# set -e on missing files. setup.sh::main has explicit error handling where
# termination matters.
# -----------------------------------------------------------------------------
bootstrap_handoff_to_install_run() {
    cd "$INSTALL_DIR" || exit 1

    # Reconnect stdin to the terminal so interactive prompts work when the
    # script is piped through curl|bash.
    if [[ ! -t 0 ]]; then
        [ -r /dev/tty ] || _bootstrap_die "Interactive prompts require /dev/tty. Re-run as: curl -fsSL <url> -o install.sh && bash install.sh"
        exec 0</dev/tty
    fi

    export SCRIPT_DIR="${INSTALL_DIR}"
    export PLATFORM_DIR="${INSTALL_DIR}"

    set +e
    # shellcheck disable=SC1091
    source "${SCRIPT_DIR}/scripts/setup-utils.sh"
    # shellcheck disable=SC1091
    source "${SCRIPT_DIR}/scripts/lib/cli-core.sh"
    # shellcheck disable=SC1091
    source "${SCRIPT_DIR}/scripts/lib/path-manager.sh"
    # shellcheck disable=SC1091
    source "${SCRIPT_DIR}/scripts/lib/install.sh"

    install_run "$@"
}

# -----------------------------------------------------------------------------
# Cleanup + trap
# -----------------------------------------------------------------------------
cleanup() {
    local rc=$?
    [[ -d "$TEMP_DIR" ]] && rm -rf "$TEMP_DIR"
    # Guarantee a closing on any non-zero exit that did not already print one (never a silent exit).
    if [ "$rc" -ne 0 ] && [ -z "${_BITOARCH_INSTALL_CLOSED:-}" ]; then
        if type render_install_incomplete_block >/dev/null 2>&1; then
            render_install_incomplete_block >&2
        else
            printf '\n\033[0;31m✗ Setup did not finish.\033[0m Re-run to resume: bitoarch start (logs: bitoarch logs)\n\n' >&2
        fi
    fi
    return 0   # Don't let a missing TEMP_DIR (e.g. after --help) flip exit code
}
trap cleanup EXIT

# -----------------------------------------------------------------------------
# Main
# -----------------------------------------------------------------------------
main() {
    parse_args "$@"
    bootstrap_check_prerequisites

    if [[ "$INSTALL_MODE" = "cdn" ]]; then
        local tarball_path
        tarball_path=$(bootstrap_download)
        bootstrap_extract "$tarball_path"
    fi

    bootstrap_handoff_to_install_run "${INSTALL_EXTRA_ARGS[@]}"
}

main "$@"
exit "$?"

} # end script buffer
