#!/bin/bash
#
# Copyright (c) 2023-2026 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
#
# Local repos manager -- 'bitoarch import-repos' for the credential-less
# "local" git provider. Copies the operator's pre-cloned repositories from a
# host directory onto the shared data volume (the worker's clone directory)
# and registers each with cis-config, so indexing runs without any git
# credentials. The copy is streamed as a tar pipe into the RUNNING manager
# container/pod (which mounts the data volume and ships git) -- a bind mount
# is not visible on VM-backed docker daemons, and on Kubernetes the exec
# stream works regardless of node topology (no hostPath / RWX needed).

if [ -n "${_BITOARCH_LOCAL_REPOS_LOADED:-}" ]; then return 0; fi
_BITOARCH_LOCAL_REPOS_LOADED=1

# Service names come from constants.sh, which bitoarch.sh does not source on
# every dispatch path (it is lazy-loaded by other adapters) -- load it here so
# this lib never depends on another module's side effect.
if [ -z "${SERVICE_MANAGER_NAME:-}" ]; then
    # shellcheck disable=SC1091
    source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/constants.sh" 2>/dev/null || true
fi

# Marker dropped inside every imported repo. cis-manager reads it to keep the
# copy on repo removal; content "synthetic" additionally forces full (never
# incremental) indexing. Must match cis-manager models.LocalImportMarkerFile.
LOCAL_IMPORT_MARKER_FILE=".bito-local-import"
# Namespaces are registered as "local/<dir>" -- two segments, so the existing
# namespace validation and repo-dir derivation (last segment) work unchanged.
LOCAL_IMPORT_NAMESPACE_PREFIX="local"

# Manager pod/container coordinates on Kubernetes (docker uses the compose
# service name from constants.sh). Overridable for tests.
LOCAL_REPOS_K8S_DEPLOY="${LOCAL_REPOS_K8S_DEPLOY:-ai-architect-manager}"
LOCAL_REPOS_K8S_CONTAINER="${LOCAL_REPOS_K8S_CONTAINER:-manager}"

_lrm_log() { type log_silent >/dev/null 2>&1 && log_silent "import-repos: $1"; }

# _local_repos_exec [--stdin] <script> [ENV=val ...] -- run <script> with sh -c
# inside the running manager, where the shared clone volume is mounted and git
# is available. --stdin forwards the caller's stdin (the tar stream).
_local_repos_exec() {
    local use_stdin=0
    if [ "$1" = "--stdin" ]; then use_stdin=1; shift; fi
    local script="$1"; shift
    local deploy
    deploy="$(get_deployment_type 2>/dev/null || echo docker)"
    case "$deploy" in
        kubernetes)
            local ns pod
            ns="${BITOARCH_K8S_NAMESPACE:-bito-ai-architect}"
            pod="$(kubectl get pods -n "$ns" -o name 2>/dev/null | grep -m1 "$LOCAL_REPOS_K8S_DEPLOY" | sed 's@^pod/@@')"
            if [ -z "$pod" ]; then
                print_error "No running ${LOCAL_REPOS_K8S_DEPLOY} pod found -- is the platform running?"
                return 1
            fi
            if [ "$use_stdin" = "1" ]; then
                kubectl exec -i -n "$ns" "$pod" -c "$LOCAL_REPOS_K8S_CONTAINER" -- env "$@" sh -c "$script"
            else
                kubectl exec -n "$ns" "$pod" -c "$LOCAL_REPOS_K8S_CONTAINER" -- env "$@" sh -c "$script"
            fi
            ;;
        *)
            local envargs=()
            local kv
            for kv in "$@"; do envargs+=( -e "$kv" ); done
            if [ "$use_stdin" = "1" ]; then
                docker exec -i "${envargs[@]}" "${SERVICE_MANAGER_NAME:-ai-architect-manager}" sh -c "$script"
            else
                docker exec "${envargs[@]}" "${SERVICE_MANAGER_NAME:-ai-architect-manager}" sh -c "$script"
            fi
            ;;
    esac
}

# HEAD of an already-imported repo on the shared volume ("" when absent).
_local_repos_imported_head() {
    local dest="$1"
    _local_repos_exec "git -C \"\$DEST\" rev-parse HEAD 2>/dev/null || true" "DEST=$dest" 2>/dev/null | tr -d '[:space:]'
}

# Stream one repository into the clone dir and normalize it in-container:
# stage next to the destination (same filesystem, atomic swap), neutralize
# 'origin' (nothing may ever try the customer's remote from inside CIS), drop
# the import marker, and for plain trees synthesize git history -- preserving
# the previous synthetic .git across re-imports so an unchanged tree keeps its
# HEAD (and is skipped by the indexer).
_local_repos_stage_one() {
    local src="$1" name="$2" kind="$3" clone_dir="$4"
    local script
    # shellcheck disable=SC2016  # single-quoted on purpose: $VARs resolve in-container
    script='set -e
dest="$CLONE_DIR/$REPO_NAME"
stage="$CLONE_DIR/.import-stage-$REPO_NAME.$$"
rm -rf "$stage"
mkdir -p "$stage"
tar -C "$stage" -xf -
if [ "$KIND" = "synthetic" ]; then
    if [ -d "$dest/.git" ]; then
        # Copy (not move): until the final swap the destination must keep a
        # valid .git -- a mid-flight failure plus stage cleanup would otherwise
        # destroy the only copy of the synthesized history.
        cp -a "$dest/.git" "$stage/.git"
    else
        git -C "$stage" init -q
    fi
    printf "synthetic\n" > "$stage/$MARKER"
    git -C "$stage" add -A
    if ! git -C "$stage" diff --cached --quiet 2>/dev/null; then
        git -C "$stage" -c user.email=import@bito.local -c user.name=bitoarch-import commit -qm "bitoarch import-repos"
    fi
else
    # Strip every remote, not just origin: a secondary remote can carry an
    # embedded credential in its URL, and nothing inside CIS may ever contact
    # the customer'"'"'s remotes anyway.
    for r in $(git -C "$stage" remote); do
        git -C "$stage" remote remove "$r" >/dev/null 2>&1 || true
    done
    printf "git\n" > "$stage/$MARKER"
fi
rm -rf "$dest"
mv "$stage" "$dest"'
    # --no-xattrs: macOS provenance xattrs otherwise emit harmless-but-noisy
    # "unknown extended header" warnings from the in-container tar.
    COPYFILE_DISABLE=1 tar --no-xattrs -C "$src" -cf - . 2>>"${LOG_FILE:-/dev/null}" | \
        _local_repos_exec --stdin "$script" \
            "CLONE_DIR=$clone_dir" "REPO_NAME=$name" "KIND=$kind" "MARKER=$LOCAL_IMPORT_MARKER_FILE"
    # A failing host tar can still emit a complete-looking archive, so the
    # container-side extract (and the swap) succeeds on truncated content --
    # both pipe stages must be clean before the import counts.
    local pipe_status=("${PIPESTATUS[@]}")
    local rc="${pipe_status[1]:-1}"
    if [ "${pipe_status[0]:-1}" -ne 0 ]; then
        rc=1
    fi
    if [ "$rc" -ne 0 ]; then
        # Best-effort stage cleanup; the swap only happens on full success.
        _local_repos_exec 'rm -rf "$CLONE_DIR"/.import-stage-"$REPO_NAME".* 2>/dev/null || true' \
            "CLONE_DIR=$clone_dir" "REPO_NAME=$name" >/dev/null 2>&1
    fi
    return "$rc"
}

# bitoarch import-repos <source-path> [--allow-non-git]
#
# Scans <source-path> for repositories (immediate subdirectories), copies each
# onto the shared clone volume, and registers it as namespace local/<dir>.
# Requires the platform to be running and the git integration to use
# provider=local. Re-running is the update flow: a git repo whose HEAD already
# matches the imported copy is skipped; anything else is re-synced and picked
# up by the next indexing run.
local_repos_import() {
    local source_path="" allow_non_git=0 arg
    for arg in "$@"; do
        case "$arg" in
            --allow-non-git) allow_non_git=1 ;;
            -*)
                print_error "Unknown option: $arg"
                print_info "Usage: bitoarch import-repos <source-path> [--allow-non-git]"
                return 1
                ;;
            *) source_path="$arg" ;;
        esac
    done

    if [ -z "$source_path" ]; then
        print_error "Source path is required"
        print_info "Usage: bitoarch import-repos <source-path> [--allow-non-git]"
        return 1
    fi
    if [ ! -d "$source_path" ]; then
        print_error "Source path not found or not a directory: $source_path"
        return 1
    fi
    if [ "${GIT_PROVIDER:-}" != "local" ]; then
        print_error "import-repos requires the local git provider (current: ${GIT_PROVIDER:-unset})"
        print_info "Select provider 'Local (pre-cloned repos)' during setup, or run: bitoarch update-git-creds"
        return 1
    fi

    local clone_dir="${CIS_CLONE_DIR:-/opt/bito/ai-architect/data/clone-dir}"
    local size_limit="${CIS_REPO_SIZE_LIMIT:-5368709120}"

    local imported=0 skipped=0 failed=0 registered_new=0
    local dir name kind src_head dest_head size_kb size_bytes

    for dir in "$source_path"/*/; do
        [ -d "$dir" ] || continue
        name="$(basename "$dir")"

        # Namespace-safe directory names only (matches the add-repo validation).
        if ! printf '%s' "$name" | grep -Eq '^[a-zA-Z0-9_.-]+$'; then
            print_warning "Skipping '$name': directory name has characters not allowed in a repo namespace"
            skipped=$((skipped + 1))
            continue
        fi

        if [ -d "${dir}.git" ]; then
            kind="git"
        elif [ "$allow_non_git" = "1" ]; then
            kind="synthetic"
        else
            print_warning "Skipping '$name': not a git clone (use --allow-non-git to import plain source trees)"
            skipped=$((skipped + 1))
            continue
        fi

        # Pre-check the size on the host so an over-limit repo is not copied
        # only to be marked "Repo Limit" by the indexer.
        size_kb="$(du -sk "$dir" 2>/dev/null | awk '{print $1}')"
        size_bytes=$(( ${size_kb:-0} * 1024 ))
        if [ "$size_bytes" -gt "$size_limit" ]; then
            print_warning "Skipping '$name': size ${size_bytes} bytes exceeds CIS_REPO_SIZE_LIMIT (${size_limit})"
            skipped=$((skipped + 1))
            continue
        fi

        # Register BEFORE the same-HEAD skip: the add API and the local mirror
        # both dedupe, so re-registering every run is free -- and doing it here
        # means a run that copied but failed to register (cis-config briefly
        # down) is healed by the next run instead of being skipped forever.
        if config_repo_add_namespace "${LOCAL_IMPORT_NAMESPACE_PREFIX}/${name}" >/dev/null 2>&1; then
            registered_new=$((registered_new + 1))
        else
            print_error "Could not register ${LOCAL_IMPORT_NAMESPACE_PREFIX}/${name} -- is cis-config reachable? See ${LOG_FILE:-setup.log}"
            failed=$((failed + 1))
            continue
        fi

        # Unchanged git clone (same HEAD as the imported copy) -> nothing to do.
        if [ "$kind" = "git" ]; then
            src_head="$(git -C "$dir" rev-parse HEAD 2>/dev/null || true)"
            dest_head="$(_local_repos_imported_head "$clone_dir/$name")"
            if [ -n "$src_head" ] && [ "$src_head" = "$dest_head" ]; then
                print_info "'$name' is already imported at $src_head (skipped)"
                skipped=$((skipped + 1))
                continue
            fi
        fi

        print_info "Importing '$name' (${kind})..."
        if ! _local_repos_stage_one "$dir" "$name" "$kind" "$clone_dir"; then
            print_error "Failed to import '$name' -- see ${LOG_FILE:-setup.log}"
            failed=$((failed + 1))
            continue
        fi
        imported=$((imported + 1))
        _lrm_log "imported $name kind=$kind"
    done

    echo ""
    print_success "Import complete: ${imported} imported, ${skipped} skipped, ${failed} failed (${registered_new} registered)"
    if [ "$imported" -gt 0 ]; then
        print_info "Run ${YELLOW}bitoarch index-repos${NC} to index the imported repositories"
    fi
    [ "$failed" -eq 0 ]
}
