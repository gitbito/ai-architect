#!/bin/bash
#
# Copyright (c) 2023-2026 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
#
# Shared Wingman shelf -- base platform lib. Owns:
#   - the shelf population trigger (wingman_shelf_populate): a busybox helper
#     container downloads the latest binary + tools + base skills from the CDN
#     onto the shared shelf; non-blocking + best-effort so it never gates startup;
#   - the shelf version reader (wingman_shelf_current_version): the shelf 'current'
#     symlink is the single source of truth (no host journal);
#   - the in-container write bridge (_wingman_fs_apply) used by plugin skills, the
#     MCP cert, and plugin dir prep, since the host cannot write the volume/PVC.

if [ -n "${_BITOARCH_WINGMAN_SHELF_LOADED:-}" ]; then return 0; fi
_BITOARCH_WINGMAN_SHELF_LOADED=1

_wsh_err() { if type print_error >/dev/null 2>&1; then print_error "$1" >&2; else printf 'ERROR: %s\n' "$1" >&2; fi; type log_silent >/dev/null 2>&1 && log_silent "wingman shelf: $1"; }
_wsh_log() { type log_silent >/dev/null 2>&1 && log_silent "wingman shelf: $1"; }

# Shelf lives on its own volume/PVC nested under the data mount. All knobs overridable for tests.
WINGMAN_SHELF_VOLUME="${WINGMAN_SHELF_VOLUME:-$(type get_ai_architect_wingman_volume >/dev/null 2>&1 && get_ai_architect_wingman_volume || echo ai_architect_wingman)}"
WINGMAN_SHELF_MOUNT="${WINGMAN_SHELF_MOUNT:-/opt/bito/ai-architect/wingman}"
WINGMAN_DATA_VOLUME="${WINGMAN_DATA_VOLUME:-$(type get_ai_architect_data_volume >/dev/null 2>&1 && get_ai_architect_data_volume || echo ai_architect_data)}"
WINGMAN_DATA_MOUNT="${WINGMAN_DATA_MOUNT:-/opt/bito/ai-architect}"
WINGMAN_POPULATE_IMAGE="${WINGMAN_POPULATE_IMAGE:-busybox:1.36}"
WINGMAN_K8S_PVC="${WINGMAN_K8S_PVC:-bitoarch-wingman}"
WINGMAN_K8S_DEPLOY="${WINGMAN_K8S_DEPLOY:-ai-architect-manager}"
WINGMAN_K8S_CONTAINER="${WINGMAN_K8S_CONTAINER:-manager}"

# _wingman_fs_apply <src_dir|""> <sh-script> -- run <sh-script> where the shared location is writable ($SRC = source dir); returns its exit status.
_wingman_fs_apply() {
    local srcdir="$1" script="$2" deploy rc ns pod stage
    local _log="${LOG_FILE:-/dev/null}"
    deploy="$(get_deployment_type 2>/dev/null || echo unknown)"
    case "$deploy" in
        kubernetes)
            ns="${BITOARCH_K8S_NAMESPACE:-bito-ai-architect}"
            pod="$(kubectl get pods -n "$ns" -o name 2>/dev/null | grep -m1 "$WINGMAN_K8S_DEPLOY" | sed 's@^pod/@@')"
            if [ -z "$pod" ]; then
                _wsh_err "no running ${WINGMAN_K8S_DEPLOY} pod found to apply the shared-shelf change"
                return 1
            fi
            if [ -n "$srcdir" ]; then
                stage="$(get_wingman_shared_dir)/.fsapply.$$"
                if ! kubectl exec -n "$ns" "$pod" -c "$WINGMAN_K8S_CONTAINER" -- sh -c "rm -rf '$stage' && mkdir -p '$stage'" 2>>"$_log"; then
                    _wsh_err "k8s: could not stage the payload in pod ${pod}"; return 1
                fi
                if ! COPYFILE_DISABLE=1 tar -C "$srcdir" -cf - . 2>>"$_log" | kubectl exec -i -n "$ns" "$pod" -c "$WINGMAN_K8S_CONTAINER" -- tar -C "$stage" -xf - 2>>"$_log"; then
                    kubectl exec -n "$ns" "$pod" -c "$WINGMAN_K8S_CONTAINER" -- rm -rf "$stage" 2>/dev/null
                    _wsh_err "k8s: failed copying the payload into pod ${pod}"; return 1
                fi
                kubectl exec -n "$ns" "$pod" -c "$WINGMAN_K8S_CONTAINER" -- env SRC="$stage" sh -c "$script"; rc=$?
                kubectl exec -n "$ns" "$pod" -c "$WINGMAN_K8S_CONTAINER" -- rm -rf "$stage" 2>/dev/null
                return $rc
            fi
            kubectl exec -n "$ns" "$pod" -c "$WINGMAN_K8S_CONTAINER" -- sh -c "$script"
            return $?
            ;;
        docker-compose|docker)
            if [ -n "$srcdir" ]; then
                # Stream the source as a tar-pipe over stdin (a bind-mount isn't visible on VM-backed daemons); script via _WMFS_SCRIPT env, COPYFILE_DISABLE drops macOS ._* entries.
                stage="/tmp/.bitowingman-fsapply.$$"
                COPYFILE_DISABLE=1 tar -C "$srcdir" -cf - . 2>>"$_log" | docker run --rm -i \
                    -v "${WINGMAN_DATA_VOLUME}:${WINGMAN_DATA_MOUNT}" -v "${WINGMAN_SHELF_VOLUME}:${WINGMAN_SHELF_MOUNT}" \
                    -e "SRC=${stage}" -e "_WMFS_SCRIPT=${script}" \
                    "$WINGMAN_POPULATE_IMAGE" sh -c 'mkdir -p "$SRC" && tar -C "$SRC" -xf - && ( eval "$_WMFS_SCRIPT" ); rc=$?; rm -rf "$SRC"; exit $rc'
                rc="${PIPESTATUS[1]}"
                return "${rc:-1}"
            fi
            docker run --rm \
                -v "${WINGMAN_DATA_VOLUME}:${WINGMAN_DATA_MOUNT}" -v "${WINGMAN_SHELF_VOLUME}:${WINGMAN_SHELF_MOUNT}" \
                "$WINGMAN_POPULATE_IMAGE" sh -c "$script"
            return $?
            ;;
        *)
            if [ -n "$srcdir" ]; then ( SRC="$srcdir" sh -c "$script" ); else ( sh -c "$script" ); fi
            return $?
            ;;
    esac
}

# The shelf's current binary version = the 'current' symlink target, read in-container. Empty when unset or dangling.
wingman_shelf_current_version() {
    local d; d="$(get_wingman_shared_dir 2>/dev/null || echo "$WINGMAN_SHELF_MOUNT")"
    _wingman_fs_apply "" "[ -e '${d}/current' ] && readlink '${d}/current' 2>/dev/null" 2>/dev/null | tr -d '[:space:]'
}

# All three on-shelf versions as "binary|tools|skills" in a single in-container read.
wingman_shelf_versions() {
    local d; d="$(get_wingman_shared_dir 2>/dev/null || echo "$WINGMAN_SHELF_MOUNT")"
    _wingman_fs_apply "" "printf '%s|%s|%s' \"\$(readlink '${d}/current' 2>/dev/null)\" \"\$(cat '${d}/current/.tools_version' 2>/dev/null)\" \"\$(cat '${d}/skills/.manifest_version' 2>/dev/null)\"" 2>/dev/null
}

# Re-point the shelf 'current' symlink to <version> if that version dir is on the shelf
# (ops/rollback; no keep-last-good). In-container (docker + k8s) so the shared volume/PVC
# is writable; matches the populate script's `ln -sfn <ver> current` idiom. rc!=0 = no such version.
wingman_shelf_rollback() {   # <version>
    local ver="${1:-}"; [ -n "$ver" ] || return 1
    local d; d="$(get_wingman_shared_dir 2>/dev/null || echo "$WINGMAN_SHELF_MOUNT")"
    _wingman_fs_apply "" "[ -d '${d}/${ver}' ] && ln -sfn '${ver}' '${d}/current'"
}
export -f wingman_shelf_rollback 2>/dev/null || true

# Absolute path of the busybox populate script (sibling of scripts/, this lib is scripts/lib/).
_wingman_populate_script() {
    if [ -n "${WINGMAN_POPULATE_SCRIPT:-}" ]; then printf '%s' "$WINGMAN_POPULATE_SCRIPT"; return 0; fi
    printf '%s' "$(cd "$(dirname "${BASH_SOURCE[0]}")/.." 2>/dev/null && pwd)/wingman-shelf-populate.sh"
}

# Populate the shared shelf (binary + tools + base skills) from the CDN via a busybox
# helper container. NON-BLOCKING (fire-and-forget) + best-effort: startup never waits
# on it, and any failure leaves the shelf as-is. BITOARCH_WINGMAN_SYNC_FORCE=1 re-syncs.
#
# On k8s this is the ON-DEMAND path (a "-ondemand" Job/ConfigMap) for triggers that do
# NOT run a helm upgrade: `bitoarch wingman update`, the daily auto-updater, and plugin
# install/upgrade. The k8s LIFECYCLE flows (install/update/upgrade/restart --force) are
# covered by the chart-owned populate Job (07b-wingman-populate.yaml), which re-runs on
# every helm apply -- so they no longer call this. On docker every trigger uses this
# helper (busybox one-off) since there is no chart.
wingman_shelf_populate() {
    command -v docker >/dev/null 2>&1 || command -v kubectl >/dev/null 2>&1 || return 0
    local mode="${1:-async}" script deploy ns logf img
    script="$(_wingman_populate_script)"
    [ -f "$script" ] || { _wsh_log "populate script not found: ${script}"; return 0; }
    img="$WINGMAN_POPULATE_IMAGE"
    deploy="$(get_deployment_type 2>/dev/null || echo docker)"
    # Write the populate output to the caller's log so it lands beside the
    # operation that triggered it: the scheduled daily run sets LOG_FILE to
    # bitoarch-updater.log, install/other callers to setup.log. Fall back to the
    # managed setup.log when no caller log is set.
    logf="${LOG_FILE:-$(get_setup_log 2>/dev/null || echo "${BITOARCH_LOG_DIR:-/tmp}/setup.log")}"

    # Exact-shelf guarantee: the shelf must be byte-identical no matter which path
    # populates it (docker compose service / k8s chart Job / this CLI helper), which
    # means every path must download from the SAME CDN bases. Some callers -- notably
    # the scheduled daily updater (bitoarch-updater.sh) -- run with a minimal env and
    # never source the config, which would leave the base URLs empty and silently fall
    # back to the populate script's PROD defaults, diverging from a staging install.
    # Load the exact file docker reads via --env-file (get_config_file) when the URLs
    # aren't already in scope; the guard makes this a no-op for callers (bitoarch.sh,
    # install/upgrade) that already sourced it.
    if [ -z "${WINGMAN_DOWNLOAD_BASE_URL:-}" ] || [ -z "${MCP_INSTALLER_BASE_URL:-}" ]; then
        if type get_config_file >/dev/null 2>&1; then
            local _wsh_envf; _wsh_envf="$(get_config_file 2>/dev/null)"
            [ -f "$_wsh_envf" ] && { set -a; . "$_wsh_envf" 2>/dev/null || true; set +a; }
        fi
    fi

    case "$deploy" in
        kubernetes)
            ns="${BITOARCH_K8S_NAMESPACE:-bito-ai-architect}"
            command -v kubectl >/dev/null 2>&1 || return 0
            # Deliver the script via a ConfigMap; re-create so it always reflects the shipped script.
            kubectl create configmap ai-architect-wingman-populate-ondemand -n "$ns" \
                --from-file=populate.sh="$script" --dry-run=client -o yaml 2>/dev/null | kubectl apply -f - >/dev/null 2>&1 || { _wsh_log "k8s: configmap apply failed"; return 0; }
            # Jobs are immutable: replace any prior run, then apply a fresh Job (async, non-blocking).
            kubectl delete job ai-architect-wingman-populate-ondemand -n "$ns" --ignore-not-found >/dev/null 2>&1 || true
            kubectl apply -f - >/dev/null 2>&1 <<YAML || { _wsh_log "k8s: populate job apply failed"; return 0; }
apiVersion: batch/v1
kind: Job
metadata:
  name: ai-architect-wingman-populate-ondemand
  namespace: ${ns}
  labels:
    app.kubernetes.io/name: bitoarch
    app.kubernetes.io/component: wingman-populate
spec:
  backoffLimit: 2
  activeDeadlineSeconds: 900
  ttlSecondsAfterFinished: 300
  template:
    metadata:
      labels:
        app.kubernetes.io/name: bitoarch
        app.kubernetes.io/component: wingman-populate
    spec:
      restartPolicy: OnFailure
      containers:
      - name: populate
        image: ${img}
        command: ["sh", "/scripts/populate.sh"]
        env:
        - {name: WINGMAN_SHELF_DIR, value: "${WINGMAN_SHELF_MOUNT}"}
        - {name: WINGMAN_DOWNLOAD_BASE_URL, value: "${WINGMAN_DOWNLOAD_BASE_URL:-}"}
        - {name: MCP_INSTALLER_BASE_URL, value: "${MCP_INSTALLER_BASE_URL:-}"}
        - {name: WINGMAN_HOST_ARCH, value: "${WINGMAN_HOST_ARCH:-x86_64}"}
        - {name: WINGMAN_BINARY_NAME, value: "${WINGMAN_BINARY_NAME:-bito-wingman}"}
        - {name: BITOARCH_WINGMAN_SYNC_FORCE, value: "${BITOARCH_WINGMAN_SYNC_FORCE:-0}"}
        - {name: WINGMAN_SHELF_KEEP, value: "${WINGMAN_SHELF_KEEP:-2}"}
        volumeMounts:
        - {name: script, mountPath: /scripts}
        - {name: wingman, mountPath: ${WINGMAN_SHELF_MOUNT}}
      volumes:
      - name: script
        configMap: {name: ai-architect-wingman-populate-ondemand}
      - name: wingman
        persistentVolumeClaim: {claimName: ${WINGMAN_K8S_PVC}}
YAML
            if [ "$mode" = "wait" ]; then
                kubectl wait --for=condition=complete job/ai-architect-wingman-populate-ondemand -n "$ns" --timeout="${WINGMAN_POPULATE_TIMEOUT:-600}s" >/dev/null 2>&1 || _wsh_log "k8s: populate job did not complete in time (best-effort)"
            fi
            _wsh_log "k8s: wingman populate job submitted (ns ${ns}, mode ${mode})"
            ;;
        *)
            command -v docker >/dev/null 2>&1 || return 0
            # Busybox helper mounts only the shelf volume; script piped over stdin (VM-safe, no bind-mount).
            local -a dargs=( run --rm -i
                -v "${WINGMAN_SHELF_VOLUME}:${WINGMAN_SHELF_MOUNT}"
                -e "WINGMAN_SHELF_DIR=${WINGMAN_SHELF_MOUNT}"
                -e "WINGMAN_DOWNLOAD_BASE_URL=${WINGMAN_DOWNLOAD_BASE_URL:-}"
                -e "MCP_INSTALLER_BASE_URL=${MCP_INSTALLER_BASE_URL:-}"
                -e "WINGMAN_HOST_ARCH=${WINGMAN_HOST_ARCH:-x86_64}"
                -e "WINGMAN_BINARY_NAME=${WINGMAN_BINARY_NAME:-bito-wingman}"
                -e "BITOARCH_WINGMAN_SYNC_FORCE=${BITOARCH_WINGMAN_SYNC_FORCE:-0}"
                -e "WINGMAN_SHELF_KEEP=${WINGMAN_SHELF_KEEP:-2}"
                "$img" sh -s )
            if [ "$mode" = "wait" ]; then
                # Synchronous (plugin install/upgrade): the caller's requires.wingman gate reads the result.
                docker "${dargs[@]}" < "$script" >>"$logf" 2>&1 || _wsh_log "docker: populate exited non-zero (best-effort)"
                _wsh_log "docker: wingman populate finished (log ${logf})"
            else
                # Fire-and-forget (install/startup/restart): never block base start on the download.
                ( nohup docker "${dargs[@]}" < "$script" >>"$logf" 2>&1 & ) >/dev/null 2>&1 || true
                _wsh_log "docker: wingman populate started (log ${logf})"
            fi
            ;;
    esac
    return 0
}
