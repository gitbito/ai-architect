#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
#
# scripts/lib/bitoarch-config.sh
# Install-mode feature-flag readers. Reads from process env first, then from
# .env-bitoarch as the persistent source. Flags are set by install_run
# (Standalone defaults) or opted into by the user.

if [ -n "${_BITOARCH_CONFIG_LOADED:-}" ]; then
    return 0
fi
_BITOARCH_CONFIG_LOADED=1

# Hide SSO UI (help text sections, Next-Steps hints) when SKIP_SSO_PROMPT is set.
sso_ui_suppressed() {
    _bitoarch_install_flag "SKIP_SSO_PROMPT"
}

# Auto-generate MCP token instead of prompting.
auto_generate_mcp_token() {
    _bitoarch_install_flag "AUTO_GENERATE_MCP_TOKEN"
}

# Collapse per-service install progress to a single compact line.
compact_install_progress() {
    _bitoarch_install_flag "COMPACT_INSTALL_PROGRESS"
}

# Gates the local-MCP feature surface (`bitoarch mcp-install`,
# `bitoarch mcp-cert`, the cert-renew scheduler, NODE_EXTRA_CA_CERTS
# injection, JB cert drop). Set to true by Standalone install_run; persisted
# into .env-bitoarch. Default (unset / false) = Enterprise / shared deploy.
mcp_auto_install_enabled() {
    _bitoarch_install_flag "MCP_AUTO_INSTALL"
}

# Gates the auto-recovery feature surface (login autostart + daily self-heal).
# Set to true by Standalone install_run; decoupled from mcp_auto_install_enabled
# so MCP-only Enterprise opt-ins don't pull in laptop autostart.
auto_recovery_enabled() {
    _bitoarch_install_flag "BITOARCH_AUTORECOVERY"
}

# Host in the MCP URL given to the CLI and coding agents: the address MCP is
# bound to (Standalone binds 127.0.0.1), or localhost when it listens on every
# interface. Dialling localhost could reach ::1, where a loopback bind has nothing.
mcp_url_host() {
    local a="${CIS_PROVIDER_BIND_ADDRESS:-}"
    a="${a#[}"; a="${a%]}"
    case "$a" in
        ""|0.0.0.0|::) echo "localhost" ;;
        *:*)           echo "[${a}]" ;;
        *)             echo "$a" ;;
    esac
}

# Standalone serves this machine only, so MCP and the ingress listen on loopback.
# Exports both bind addresses and writes them to .env-bitoarch, so every compose
# up binds the same way. An address the operator set, in the environment or the
# file, is kept; an empty one becomes 127.0.0.1. Enterprise is left alone.
standalone_bind_defaults() {
    sso_ui_suppressed || return 0
    local key v env_file=""
    if command -v get_config_file >/dev/null 2>&1; then
        env_file="$(get_config_file 2>/dev/null)"
    fi
    [ -f "$env_file" ] || env_file=""
    for key in CIS_PROVIDER_BIND_ADDRESS INGRESS_BIND_ADDRESS; do
        v="${!key:-}"
        if [ -z "$v" ] && [ -n "$env_file" ]; then
            v=$(grep -E "^${key}=" "$env_file" 2>/dev/null | head -1 | cut -d= -f2- | tr -d "\"'" || true)
        fi
        v="${v:-127.0.0.1}"
        export "${key}=${v}"
        [ -n "$env_file" ] || continue
        if ! grep -q "^${key}=" "$env_file" 2>/dev/null; then
            printf '%s=%s\n' "$key" "$v" >> "$env_file"
        elif grep -qE "^${key}=[\"']*$" "$env_file" 2>/dev/null; then
            sed -i.bak "s|^${key}=.*|${key}=${v}|" "$env_file" && rm -f "${env_file}.bak"
        fi
    done
    return 0
}

# Generic reader: $<NAME> in env OR <NAME>= in .env-bitoarch, truthy = 0.
_bitoarch_install_flag() {
    local name="$1"
    local v="${!name:-}"
    case "$v" in
        true|TRUE|1|yes) return 0 ;;
    esac
    local env_file
    if command -v get_config_file >/dev/null 2>&1; then
        env_file="$(get_config_file 2>/dev/null)"
    fi
    if [ -n "${env_file:-}" ] && [ -f "$env_file" ]; then
        v=$(grep -E "^${name}=" "$env_file" 2>/dev/null \
            | cut -d= -f2 | tr -d '"' | tr -d "'" | head -1)
        case "$v" in
            true|TRUE|1|yes) return 0 ;;
        esac
    fi
    return 1
}

export -f mcp_url_host
