-- Add new columns to transient_state table for operation management
USE code_intelligence;
ALTER TABLE transient_state
ADD COLUMN operation_data JSON DEFAULT NULL,
ADD COLUMN is_paused BOOLEAN DEFAULT FALSE,
ADD COLUMN is_stopped BOOLEAN DEFAULT FALSE;