#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
# Bito's AI Architect Backup Script - Zero Data Loss Guarantee
# Creates comprehensive backups of database, configurations, and service data

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[1;34m'
NC='\033[0m' # No Color

# Configuration
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PLATFORM_DIR="$(dirname "$SCRIPT_DIR")"
ENV_FILE="${PLATFORM_DIR}/.env-bitoarch"
DATE=$(date +%Y%m%d_%H%M%S)

# Source environment for BACKUP_PATH
if [ -f "$ENV_FILE" ]; then
    source "$ENV_FILE"
fi

# Use BACKUP_PATH from config, fallback to container default
BACKUP_DIR="${BACKUP_PATH:-/opt/cis/backups}"

# Logging function
log() {
    echo "[$(date +'%Y-%m-%d %H:%M:%S')] $1" | tee -a "$BACKUP_DIR/backup.log"
}

print_status() {
    echo -e "${GREEN}✓${NC} $1"
    log "SUCCESS: $1"
}

print_error() {
    echo -e "${RED}✗${NC} $1"
    log "ERROR: $1"
}

print_info() {
    echo -e "${BLUE}ℹ${NC} $1"
    log "INFO: $1"
}

print_warning() {
    echo -e "${YELLOW}⚠${NC} $1"
    log "WARNING: $1"
}

# Create backup directory structure
create_backup_structure() {
    local backup_name="backup_${DATE}"
    local backup_path="${BACKUP_DIR}/${backup_name}"
    
    mkdir -p "${backup_path}"/{database,configs,volumes,services,metadata}
    echo "$backup_path"
}

# Backup database with transaction consistency
backup_database() {
    local backup_path="$1"
    local db_backup_path="${backup_path}/database"
    
    print_info "Creating database backup..."
    
    if [ ! -f "$ENV_FILE" ]; then
        print_error "Environment file not found: $ENV_FILE"
        exit 1
    fi
    
    # Source environment variables
    source "$ENV_FILE"
    
    # Check if MySQL container is running
    if ! docker compose --env-file "${PLATFORM_DIR}/.env-bitoarch" -f "${PLATFORM_DIR}/docker-compose.yml" ps mysql | grep -q "Up"; then
        print_error "MySQL container is not running"
        exit 1
    fi
    
    # Create full database backup with consistent snapshot
    print_info "Creating full database dump..."
    docker compose --env-file "${PLATFORM_DIR}/.env-bitoarch" -f "${PLATFORM_DIR}/docker-compose.yml" exec -T mysql mysqldump \
        --single-transaction \
        --routines \
        --triggers \
        --events \
        --hex-blob \
        --user="$DB_USER" \
        --password="$MYSQL_PASSWORD" \
        "$DB_NAME" > "${db_backup_path}/full_backup.sql"
    
    # Create structure-only backup
    docker compose --env-file "${PLATFORM_DIR}/.env-bitoarch" -f "${PLATFORM_DIR}/docker-compose.yml" exec -T mysql mysqldump \
        --no-data \
        --routines \
        --triggers \
        --events \
        --user="$DB_USER" \
        --password="$MYSQL_PASSWORD" \
        "$DB_NAME" > "${db_backup_path}/schema_only.sql"
    
    # Export system configuration
    docker compose --env-file "${PLATFORM_DIR}/.env-bitoarch" -f "${PLATFORM_DIR}/docker-compose.yml" exec -T mysql mysql \
        --user="$DB_USER" \
        --password="$MYSQL_PASSWORD" \
        --database="$DB_NAME" \
        --execute="SELECT * FROM system_config;" \
        --batch --raw > "${db_backup_path}/system_config.tsv"
    
    # Create binary log backup for point-in-time recovery
    print_info "Backing up binary logs..."
    docker compose --env-file "${PLATFORM_DIR}/.env-bitoarch" -f "${PLATFORM_DIR}/docker-compose.yml" exec mysql \
        sh -c "cd /var/log/mysql && tar -czf - mysql-bin.*" > "${db_backup_path}/binlogs.tar.gz" 2>/dev/null || true
    
    # Create metadata file
    cat > "${db_backup_path}/backup_metadata.json" << EOF
{
    "timestamp": "${DATE}",
    "database_name": "${DB_NAME}",
    "backup_type": "full",
    "mysql_version": "$(docker compose --env-file "${PLATFORM_DIR}/.env-bitoarch" -f "${PLATFORM_DIR}/docker-compose.yml" exec -T mysql mysql --version | head -1)",
    "platform_version": "${VERSION_CURRENT:-1.0.0}",
    "backup_files": {
        "full_backup": "full_backup.sql",
        "schema_only": "schema_only.sql",
        "system_config": "system_config.tsv",
        "binary_logs": "binlogs.tar.gz"
    }
}
EOF
    
    print_status "Database backup completed"
}

# Backup configuration files
backup_configurations() {
    local backup_path="$1"
    local config_backup_path="${backup_path}/configs"
    
    print_info "Backing up configurations..."
    
    # Copy environment file
    cp "$ENV_FILE" "${config_backup_path}/.env-bitoarch.backup"
    
    # Copy docker-compose and related files
    cp "${PLATFORM_DIR}/docker-compose.yml" "${config_backup_path}/"
    cp "${PLATFORM_DIR}/.env-bitoarch.default" "${config_backup_path}/" 2>/dev/null || true
    
    # Copy service configurations
    if [ -d "${PLATFORM_DIR}/config" ]; then
        cp -r "${PLATFORM_DIR}/config" "${config_backup_path}/" 2>/dev/null || true
    fi
    
    # Copy service-specific configs
    for service in ai-architect-manager ai-architect-config ai-architect-provider; do
        service_config_dir="${PLATFORM_DIR}/services/${service}/config"
        if [ -d "$service_config_dir" ]; then
            mkdir -p "${config_backup_path}/services/${service}"
            cp -r "$service_config_dir" "${config_backup_path}/services/${service}/" 2>/dev/null || true
        fi
    done
    
    print_status "Configuration backup completed"
}

# Backup Docker volumes
backup_volumes() {
    local backup_path="$1"
    local volume_backup_path="${backup_path}/volumes"
    
    print_info "Backing up Docker volumes..."
    
    # Get list of volumes used by the platform
    local volumes=$(docker compose --env-file "${PLATFORM_DIR}/.env-bitoarch" -f "${PLATFORM_DIR}/docker-compose.yml" config --volumes)
    
    for volume in $volumes; do
        print_info "Backing up volume: $volume"
        
        # Create volume backup using temporary container
        docker run --rm \
            -v "${volume}:/source" \
            -v "${volume_backup_path}:/backup" \
            alpine:latest \
            tar -czf "/backup/${volume}.tar.gz" -C /source . 2>/dev/null || {
            print_warning "Failed to backup volume: $volume"
        }
    done
    
    print_status "Volume backup completed"
}

# Backup service data and metadata
backup_service_data() {
    local backup_path="$1"
    local service_backup_path="${backup_path}/services"
    
    print_info "Backing up service data..."
    
    # Backup ai-architect-provider metadata
    if docker compose --env-file "${PLATFORM_DIR}/.env-bitoarch" -f "${PLATFORM_DIR}/docker-compose.yml" ps ai-architect-provider | grep -q "Up"; then
        docker compose --env-file "${PLATFORM_DIR}/.env-bitoarch" -f "${PLATFORM_DIR}/docker-compose.yml" exec ai-architect-provider \
            tar -czf - -C /app metadata 2>/dev/null > "${service_backup_path}/ai-architect-provider-metadata.tar.gz" || true
    fi
    
    # Backup application logs (last 7 days)
    for service in ai-architect-manager ai-architect-config ai-architect-provider; do
        if docker compose --env-file "${PLATFORM_DIR}/.env-bitoarch" -f "${PLATFORM_DIR}/docker-compose.yml" ps "$service" | grep -q "Up"; then
            docker compose --env-file "${PLATFORM_DIR}/.env-bitoarch" -f "${PLATFORM_DIR}/docker-compose.yml" logs --since="168h" "$service" \
                > "${service_backup_path}/${service}-recent.log" 2>/dev/null || true
        fi
    done
    
    print_status "Service data backup completed"
}

# Create backup manifest
create_backup_manifest() {
    local backup_path="$1"
    local manifest_file="${backup_path}/BACKUP_MANIFEST.json"
    
    print_info "Creating backup manifest..."
    
    # Calculate checksums
    local db_checksum=""
    local config_checksum=""
    
    if [ -f "${backup_path}/database/full_backup.sql" ]; then
        db_checksum=$(sha256sum "${backup_path}/database/full_backup.sql" | cut -d' ' -f1)
    fi
    
    if [ -f "${backup_path}/configs/.env-bitoarch.backup" ]; then
        config_checksum=$(sha256sum "${backup_path}/configs/.env-bitoarch.backup" | cut -d' ' -f1)
    fi
    
    cat > "$manifest_file" << EOF
{
    "backup_info": {
        "timestamp": "${DATE}",
        "platform_version": "${VERSION_CURRENT:-1.0.0}",
        "backup_type": "full",
        "created_by": "$(whoami)",
        "hostname": "$(hostname)"
    },
    "components": {
        "database": {
            "included": true,
            "checksum": "${db_checksum}",
            "size_bytes": $(stat -f%z "${backup_path}/database/full_backup.sql" 2>/dev/null || echo "0")
        },
        "configurations": {
            "included": true,
            "checksum": "${config_checksum}",
            "files_count": $(find "${backup_path}/configs" -type f | wc -l 2>/dev/null || echo "0")
        },
        "volumes": {
            "included": true,
            "volume_count": $(find "${backup_path}/volumes" -name "*.tar.gz" | wc -l 2>/dev/null || echo "0")
        },
        "service_data": {
            "included": true,
            "metadata_included": true
        }
    },
    "restore_instructions": {
        "command": "./scripts/restore.sh $(basename "$backup_path")",
        "prerequisites": ["Docker running", "Platform stopped"],
        "estimated_time_minutes": 10
    }
}
EOF
    
    print_status "Backup manifest created"
}

# Compress backup
compress_backup() {
    local backup_path="$1"
    local backup_name=$(basename "$backup_path")
    local compressed_backup="${BACKUP_DIR}/${backup_name}.tar.gz"
    
    print_info "Compressing backup..."
    
    cd "$BACKUP_DIR"
    tar -czf "${backup_name}.tar.gz" "$backup_name"
    
    # Verify compressed backup
    if [ -f "$compressed_backup" ]; then
        local compressed_size=$(stat -f%z "$compressed_backup" 2>/dev/null || stat -c%s "$compressed_backup" 2>/dev/null || echo "0")
        print_status "Backup compressed: $compressed_backup ($(numfmt --to=iec $compressed_size))"
        
        # Remove uncompressed backup
        rm -rf "$backup_path"
        
        echo "$compressed_backup"
    else
        print_error "Failed to create compressed backup"
        exit 1
    fi
}

# Cleanup old backups
cleanup_old_backups() {
    local retention_days=${BACKUP_RETENTION_DAYS:-30}
    
    print_info "Cleaning up backups older than $retention_days days..."
    
    find "$BACKUP_DIR" -name "backup_*.tar.gz" -type f -mtime +$retention_days -delete 2>/dev/null || true
    
    local remaining_backups=$(find "$BACKUP_DIR" -name "backup_*.tar.gz" -type f | wc -l)
    print_status "Cleanup completed. $remaining_backups backup(s) retained"
}

# Kubernetes backup functions
backup_kubernetes_pvcs() {
    local backup_path="$1"
    local pvc_backup_path="${backup_path}/pvcs"
    
    print_info "Backing up Kubernetes PVCs..."
    
    local namespace="bito-ai-architect"
    local pvcs=$(kubectl get pvc -n "$namespace" -o jsonpath='{.items[*].metadata.name}' 2>/dev/null || echo "")
    
    if [ -z "$pvcs" ]; then
        print_warning "No PVCs found to backup"
        return 0
    fi
    
    mkdir -p "$pvc_backup_path"
    
    for pvc in $pvcs; do
        print_info "Backing up PVC: $pvc"
        
        # Create a temporary pod to access PVC
        kubectl run pvc-backup-pod-$$ \
            --namespace="$namespace" \
            --image=busybox:1.36 \
            --restart=Never \
            --overrides="{
              \"apiVersion\": \"v1\",
              \"spec\": {
                \"containers\": [{
                  \"name\": \"backup\",
                  \"image\": \"busybox:1.36\",
                  \"command\": [\"sleep\", \"3600\"],
                  \"volumeMounts\": [{
                    \"name\": \"data\",
                    \"mountPath\": \"/data\"
                  }]
                }],
                \"volumes\": [{
                  \"name\": \"data\",
                  \"persistentVolumeClaim\": {
                    \"claimName\": \"$pvc\"
                  }
                }]
              }
            }" >/dev/null 2>&1
        
        # Wait for pod to be ready
        kubectl wait --for=condition=Ready pod/pvc-backup-pod-$$ -n "$namespace" --timeout=60s >/dev/null 2>&1
        
        # Backup PVC data
        kubectl exec -n "$namespace" pvc-backup-pod-$$ -- tar czf - -C /data . > "${pvc_backup_path}/${pvc}.tar.gz" 2>/dev/null || {
            print_warning "Failed to backup PVC: $pvc"
        }
        
        # Cleanup
        kubectl delete pod pvc-backup-pod-$$ -n "$namespace" --force --grace-period=0 >/dev/null 2>&1
    done
    
    print_status "PVC backup completed"
}

backup_kubernetes_resources() {
    local backup_path="$1"
    local resource_backup_path="${backup_path}/resources"
    
    print_info "Backing up Kubernetes resources..."
    
    local namespace="bito-ai-architect"
    mkdir -p "$resource_backup_path"
    
    # Backup ConfigMaps
    kubectl get configmaps -n "$namespace" -o yaml > "${resource_backup_path}/configmaps.yaml" 2>/dev/null || true
    
    # Backup Secrets (base64 encoded)
    kubectl get secrets -n "$namespace" -o yaml > "${resource_backup_path}/secrets.yaml" 2>/dev/null || true
    
    # Backup Helm release values
    if command -v helm >/dev/null 2>&1; then
        helm get values bitoarch -n "$namespace" > "${resource_backup_path}/helm-values.yaml" 2>/dev/null || true
    fi
    
    # Backup deployments
    kubectl get deployments -n "$namespace" -o yaml > "${resource_backup_path}/deployments.yaml" 2>/dev/null || true
    
    # Backup services
    kubectl get services -n "$namespace" -o yaml > "${resource_backup_path}/services.yaml" 2>/dev/null || true
    
    print_status "Kubernetes resources backed up"
}

backup_kubernetes_database() {
    local backup_path="$1"
    local db_backup_path="${backup_path}/database"
    
    print_info "Backing up database from Kubernetes..."
    
    local namespace="bito-ai-architect"
    
    # Find MySQL pod
    local mysql_pod=$(kubectl get pods -n "$namespace" -l "app.kubernetes.io/component=mysql" -o jsonpath='{.items[0].metadata.name}' 2>/dev/null || echo "")
    
    if [ -z "$mysql_pod" ]; then
        print_error "MySQL pod not found"
        return 1
    fi
    
    # Get credentials from secrets
    local db_user=$(kubectl get secret bitoarch-secrets -n "$namespace" -o jsonpath='{.data.mysql-user}' 2>/dev/null | base64 -d)
    local db_password=$(kubectl get secret bitoarch-secrets -n "$namespace" -o jsonpath='{.data.mysql-password}' 2>/dev/null | base64 -d)
    local db_name=$(kubectl get secret bitoarch-secrets -n "$namespace" -o jsonpath='{.data.mysql-database}' 2>/dev/null | base64 -d)
    
    mkdir -p "$db_backup_path"
    
    # Create full database backup
    kubectl exec -n "$namespace" "$mysql_pod" -- mysqldump \
        --single-transaction \
        --routines \
        --triggers \
        --events \
        --hex-blob \
        --user="$db_user" \
        --password="$db_password" \
        "$db_name" > "${db_backup_path}/full_backup.sql" 2>/dev/null || {
        print_error "Database backup failed"
        return 1
    }
    
    # Create schema-only backup
    kubectl exec -n "$namespace" "$mysql_pod" -- mysqldump \
        --no-data \
        --routines \
        --triggers \
        --events \
        --user="$db_user" \
        --password="$db_password" \
        "$db_name" > "${db_backup_path}/schema_only.sql" 2>/dev/null || true
    
    print_status "Database backup completed"
}

backup_kubernetes() {
    local backup_path="$1"
    
    print_info "Creating Kubernetes backup..."
    
    backup_kubernetes_database "$backup_path"
    backup_kubernetes_pvcs "$backup_path"
    backup_kubernetes_resources "$backup_path"
    
    print_status "Kubernetes backup completed"
}

# Main backup function
main() {
    echo -e "${BLUE}Bito's AI Architect Backup - Zero Data Loss${NC}"
    echo "================================================"
    echo ""
    
    # Create backup directory if it doesn't exist
    mkdir -p "$BACKUP_DIR"
    
    # Detect deployment type
    local deployment_type="docker-compose"
    if [ -f "${PLATFORM_DIR}/.deployment-type" ]; then
        deployment_type=$(cat "${PLATFORM_DIR}/.deployment-type")
    fi
    
    # Check if platform is running
    if [ "$deployment_type" = "kubernetes" ]; then
        if ! kubectl get namespace bito-ai-architect >/dev/null 2>&1; then
            print_warning "Kubernetes namespace not found. Creating offline backup..."
        fi
    else
        if ! docker compose --env-file "${PLATFORM_DIR}/.env-bitoarch" -f "${PLATFORM_DIR}/docker-compose.yml" ps | grep -q "Up"; then
            print_warning "Bito's AI Architect is not running. Creating offline backup..."
        fi
    fi
    
    # Create backup structure
    local backup_path=$(create_backup_structure)
    local backup_name=$(basename "$backup_path")
    
    print_info "Starting backup: $backup_name"
    
    # Perform backup components based on deployment type
    if [ "$deployment_type" = "kubernetes" ]; then
        backup_kubernetes "$backup_path"
        backup_configurations "$backup_path"
    else
        backup_database "$backup_path"
        backup_configurations "$backup_path"
        backup_volumes "$backup_path"
        backup_service_data "$backup_path"
    fi
    
    create_backup_manifest "$backup_path"
    
    # Compress and finalize
    local compressed_backup=$(compress_backup "$backup_path")
    
    # Cleanup old backups
    cleanup_old_backups
    
    echo ""
    print_status "Backup completed successfully!"
    echo -e "${BLUE}Backup location:${NC} $compressed_backup"
    echo -e "${BLUE}Restore command:${NC} ./scripts/restore.sh $backup_name"
    echo ""
}

# Handle command line arguments
case "${1:-}" in
    --help|-h)
        echo "Bito's AI Architect Backup Script"
        echo ""
        echo "Usage: $0 [options]"
        echo ""
        echo "Options:"
        echo "  --help, -h      Show this help message"
        echo "  --quick         Quick backup (database + configs only)"
        echo "  --full          Full backup (all components) [default]"
        echo ""
        echo "Environment variables:"
        echo "  BACKUP_RETENTION_DAYS    Days to keep backups (default: 30)"
        ;;
    --quick)
        print_info "Quick backup mode selected"
        # Override functions for quick backup
        backup_volumes() { print_info "Skipping volumes in quick mode"; }
        backup_service_data() { print_info "Skipping service data in quick mode"; }
        main
        ;;
    --full|"")
        main
        ;;
    *)
        echo "Unknown option: $1"
        echo "Use --help for usage information"
        exit 1
        ;;
esac
