#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai

# Source centralized output rendering system
SETUP_UTILS_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [ -f "${SETUP_UTILS_DIR}/lib/output-blocks.sh" ]; then
    source "${SETUP_UTILS_DIR}/lib/output-blocks.sh"
elif [ -f "$(dirname "$SETUP_UTILS_DIR")/scripts/lib/output-blocks.sh" ]; then
    source "$(dirname "$SETUP_UTILS_DIR")/scripts/lib/output-blocks.sh"
fi

# Set default LOG_FILE if not already set (ensures logging always works)
# This is needed when setup-utils.sh is sourced early by path-manager.sh
if [ -z "$LOG_FILE" ]; then
    # Create a temporary log in the script's var/logs directory
    LOG_FILE="${SETUP_UTILS_DIR}/var/logs/setup.log"
    mkdir -p "$(dirname "$LOG_FILE")" 2>/dev/null || true
fi

# Logging function - always log to file, customer-friendly output to console
log() {
    echo "[$(date +'%Y-%m-%d %H:%M:%S')] $1" >> "$LOG_FILE" 2>&1
}

# Silent log - only to file, not to console (for technical details)
log_silent() {
    echo "[$(date +'%Y-%m-%d %H:%M:%S')] $1" >> "$LOG_FILE" 2>&1
}

print_command() {
    echo -e "${YELLOW}  →${NC} ${BLUE}$1${NC}"
    log "COMMAND: $1"
}

generate_secret() {
    # Ensure consistent output format - remove trailing newlines from both paths
    (openssl rand -base64 32 2>/dev/null || head -c 32 /dev/urandom | base64) | tr -d '\n'
}

generate_encryption_key() {
    # Generate 32 random bytes and encode as URL-safe base64 without padding
    # This follows the same logic as the Go implementation:
    # - 32 bytes (256-bit key)
    # - RawURLEncoding: URL-safe characters, no padding
    local bytes
    if command -v openssl >/dev/null 2>&1; then
        bytes=$(openssl rand 32 2>/dev/null)
    else
        bytes=$(head -c 32 /dev/urandom)
    fi
    
    # Encode to base64, convert to URL-safe (+ -> -, / -> _), remove padding (=)
    echo -n "$bytes" | base64 | tr '+/' '-_' | tr -d '=' | tr -d '\n'
}

encrypt_secret() {
    local plaintext="$1"
    local encryption_key="$2"
    
    # Check if openssl is available
    if ! command -v openssl >/dev/null 2>&1; then
        echo "Error: openssl is required for encryption" >&2
        return 1
    fi
    
    # Decode the URL-safe base64 encryption key (convert back from RawURLEncoding)
    # Add padding if needed, convert URL-safe chars back to standard base64
    local key_b64=$(echo -n "$encryption_key" | tr '_-' '/+')
    local padding_length=$((4 - ${#key_b64} % 4))
    if [ $padding_length -ne 4 ]; then
        key_b64="${key_b64}$(printf '=%.0s' $(seq 1 $padding_length))"
    fi
    
    # Decode the key
    local key_bytes=$(echo -n "$key_b64" | base64 -d 2>/dev/null)
    if [ -z "$key_bytes" ]; then
        echo "Error: Failed to decode encryption key" >&2
        return 1
    fi
    
    # Generate a 16-byte random IV for AES-256-CBC
    local iv_bytes=$(openssl rand 16 2>/dev/null)
    if [ -z "$iv_bytes" ]; then
        echo "Error: Failed to generate IV" >&2
        return 1
    fi
    
    # Create temp files for key and IV
    local key_file=$(mktemp)
    local iv_file=$(mktemp)
    echo -n "$key_bytes" > "$key_file"
    echo -n "$iv_bytes" > "$iv_file"
    
    # Encrypt using AES-256-CBC (supported on both macOS and Linux)
    local ciphertext=$(echo -n "$plaintext" | openssl enc -aes-256-cbc -K "$(xxd -p -c 256 "$key_file" | tr -d '\n')" -iv "$(xxd -p -c 256 "$iv_file" | tr -d '\n')" 2>/dev/null | base64 | tr -d '\n')
    
    # Clean up temp files
    rm -f "$key_file" "$iv_file"
    
    if [ -z "$ciphertext" ]; then
        echo "Error: Encryption failed" >&2
        return 1
    fi
    
    # Encode IV as base64 (use as nonce)
    local iv_b64=$(echo -n "$iv_bytes" | base64 | tr -d '\n')
    
    # Return in the format: enc:v1:<iv_base64>:<ciphertext_base64>
    echo "enc:v1:${iv_b64}:${ciphertext}"
}

is_container_environment() {
    [ -f /.dockerenv ] || grep -q -E 'docker|lxc|containerd' /proc/1/cgroup 2>/dev/null
}

is_arm64_mac() {
    [[ "$OSTYPE" == "darwin"* ]] && [[ "$(uname -m)" == "arm64" ]]
}

show_spinner() {
    local pid=$1
    local message="$2"
    local spinner="⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏"
    local i=0
    
    while kill -0 $pid 2>/dev/null; do
        printf "\r${BLUE}%s${NC} %s " "$message" "${spinner:$i:1}"
        i=$(((i + 1) % ${#spinner}))
        sleep 0.1
    done
    printf "\r%s ✅\n" "$message"
}

# Global PID placeholder
LOADER_PID=""

show_loader() {
    local message="$1"
    (
        while true; do
            for s in '⠋' '⠙' '⠹' '⠸' '⠼' '⠴' '⠦' '⠧' '⠇' '⠏'; do
                printf "\r%s %s" "$s" "$message"
                sleep 0.1
            done
        done
    ) &
    LOADER_PID=$!
}

stop_loader() {
    if [[ -n "$LOADER_PID" ]]; then
        kill "$LOADER_PID" >/dev/null 2>&1
        wait "$LOADER_PID" 2>/dev/null
        LOADER_PID=""
        printf "\r"
    fi
}

safe_call() {
    set +e
    "$@"
    local exit_code=$?
    set -e
    return $exit_code
}
