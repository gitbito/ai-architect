#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
# Bito's AI Architect CLI - Manager Adapter
# Provides manager_sync_simple (used by index-repos) and manager_status (used by index-status)

# Source http-client for K8s port-forward support
if [ -z "$SCRIPT_DIR" ]; then
    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && cd ../.. && pwd)"
fi
source "${SCRIPT_DIR}/scripts/lib/http-client.sh" 2>/dev/null || true
source "${SCRIPT_DIR}/scripts/lib/output-fields.sh" 2>/dev/null || true

# Ensure manager service is accessible (handles K8s port-forward automatically)
ensure_manager_service_accessible() {
    # Get port from environment
    local MANAGER_PORT="${CIS_MANAGER_EXTERNAL_PORT:-5002}"
    
    # Ensure service is accessible (no-op for Docker, sets up port-forward for K8s)
    ensure_service_accessible "ai-architect-manager" "$MANAGER_PORT" 2>/dev/null || true
}

# Simple repository indexing (no parameters)
manager_sync_simple() {
    # Check for help first
    if [ "$1" = "--help" ] || [ "$1" = "-h" ]; then
        cat << 'EOF'
USAGE:
  bitoarch index-repos

DESCRIPTION:
  Trigger repository indexing. This command initiates the indexing
  process for all configured repositories. Indexing typically takes 3-10 minutes
  per repository depending on size.

OPTIONS:
  --help, -h    Show this help

EXAMPLES:
  # Start indexing all configured repositories
  bitoarch index-repos
  
  # Check indexing progress
  bitoarch index-status

NOTES:
  - Requires BITO_API_KEY to be configured in environment
  - Repositories must be configured first (use 'bitoarch add-repo')
  - Multiple calls will queue additional indexing requests
EOF
        return 0
    fi
    
    # Get BITO API key from environment
    if [ -z "$BITO_API_KEY" ]; then
        print_error "BITO_API_KEY not found in environment"
        return 1
    fi
    
    # Get manager external port from environment (default to 5002)
    local MANAGER_PORT="${CIS_MANAGER_EXTERNAL_PORT:-5002}"
    local MANAGER_URL="${CIS_MANAGER_URL:-http://localhost:${MANAGER_PORT}}"
    
    # Ensure manager service is accessible (sets up port-forward for K8s if needed)
    ensure_manager_service_accessible
    
    print_info "Initiating repository indexing..."
    
    # Make API call directly with curl
    local response=$(curl -s -w '\n%{http_code}' \
        -X POST \
        -H "Authorization: $BITO_API_KEY" \
        "${MANAGER_URL}/api/v2/sync-workspace" 2>/dev/null)
    
    # Extract HTTP code from last line
    local http_code=$(echo "$response" | tail -1)
    local body=$(echo "$response" | sed '$d')
    
    # Use field-based rendering
    if [ "$http_code" -ge 200 ] && [ "$http_code" -lt 300 ]; then
        echo ""
        echo -e "${GREEN}✅ Repository Indexing Initiated${NC}"
        echo ""
        
        # Extract message from response
        if command -v jq >/dev/null 2>&1; then
            local message=$(echo "$body" | jq -r '.message // "repository enqueued for processing"')
            echo -e "${BLUE}Status:${NC}"
            echo "  • $message"
        else
            echo "$body"
        fi
        
        # Show indexing information
        echo ""
        echo -e "${CYAN}${BOLD}📊 Note:${NC}"
        echo -e "${BOLD}Indexing has started, and will take approximately 3-10 minutes per repo. Smaller repos take less time${NC}"
        echo -e "${BOLD}You can check the status of your indexing by typing ${YELLOW}bitoarch index-status${NC}${BOLD} from your CLI${NC}"
        
        return 0
    else
        render_command_error "Repository Indexing Failed" "$body" "$MANAGER_SYNC_ERROR_OUTPUT"
        
        # Special handling for QUEUE_FULL error
        if command -v jq >/dev/null 2>&1; then
            local error_type=$(echo "$body" | jq -r '.error // ""' 2>/dev/null)
            if [ "$error_type" = "QUEUE_FULL" ] || [ "$error_type" = "CONFLICT" ]; then
                echo -e "${BLUE}Note:${NC}"
                echo "  Indexing is already in progress for your current repositories."
                echo "  New repositories can only be indexed after the ongoing process completes."
                echo ""
                echo -e "${YELLOW}Next Steps:${NC}"
                echo -e "  1. Wait for current indexing to finish (check with: ${YELLOW}bitoarch index-status${NC})"
                echo -e "  2. Once complete, run ${YELLOW}bitoarch index-repos${NC} again to index newly added repos"
                echo ""
            fi
        fi
        
        return 1
    fi
}

# Get sync status
manager_status() {
    local view_mode="default"
    
    # Parse flags
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --help|-h)
                cat << 'EOF'
STATUS COMMAND

USAGE:
  bitoarch index-status [OPTIONS]

DESCRIPTION:
  Retrieves the current indexing status from the CIS Manager service.
  Uses BITO_API_KEY from environment for authentication.

OPTIONS:
  --raw                 Show raw unfiltered JSON response
  --output json         Machine-readable filtered JSON output
  --help, -h           Show this help

OUTPUT MODES:
  default       Minimal summary (state, progress, key metrics)
  --raw         Complete API response (for debugging)
  --output json Filtered JSON for automation/scripting

EXAMPLES:
  # Quick status check
  bitoarch index-status

  # Detailed view
  bitoarch index-status --details

  # Raw API response
  bitoarch index-status --raw

  # For automation
  bitoarch index-status --output json | jq '.state'

NOTES:
  - Requires BITO_API_KEY to be set in environment
  - Connects to CIS Manager service using CIS_MANAGER_PORT from .env
EOF
                return 0
                ;;
            --raw)
                view_mode="raw"
                shift
                ;;
            --verbose)
                view_mode="verbose"
                shift
                ;;
            --output)
                if [ "$2" = "json" ]; then
                    view_mode="json"
                    shift 2
                else
                    print_error "Unknown output format: $2"
                    return 1
                fi
                ;;
            *)
                print_warning "Unknown option: $1"
                shift
                ;;
        esac
    done
    
    # Get BITO API key from environment
    if [ -z "$BITO_API_KEY" ]; then
        print_error "BITO_API_KEY not found in environment"
        return 1
    fi
    
    # Get manager external port from environment (default to 5002)
    local MANAGER_PORT="${CIS_MANAGER_EXTERNAL_PORT:-5002}"
    local MANAGER_URL="http://localhost:${MANAGER_PORT}"
    local ENDPOINT="${MANAGER_URL}/api/v2/indexing-status"
    
    # Ensure manager service is accessible (sets up port-forward for K8s if needed)
    ensure_manager_service_accessible
    
    # Only show progress message in non-JSON modes
    if [ "$view_mode" != "json" ]; then
        print_info "Fetching index status..."
    fi

    # Make API call with timeout
    local response=$(curl -s -w '\n%{http_code}' --max-time 30 \
        -X GET \
        -H "Authorization: Bearer ${BITO_API_KEY}" \
        "$ENDPOINT" 2>/dev/null)
    
    local curl_exit=$?
    
    # Handle curl errors (timeout, connection refused, etc.)
    if [ $curl_exit -ne 0 ]; then
        if [ "$view_mode" = "json" ]; then
            echo '{"error": "connection_failed", "message": "Failed to connect to CIS Manager"}'
        else
            render_manager_status_error "connection_failed" "Failed to connect to CIS Manager" "$ENDPOINT"
        fi
        return 1
    fi
    
    # Extract HTTP code from last line
    local http_code=$(echo "$response" | tail -1)
    local body=$(echo "$response" | sed '$d')
    
    # Handle HTTP errors
    if [ "$http_code" -lt 200 ] || [ "$http_code" -ge 300 ]; then
        if [ "$view_mode" = "json" ]; then
            echo "{\"error\": \"http_$http_code\", \"message\": \"API request failed\"}"
        else
            render_manager_status_error "$http_code" "$body" "$ENDPOINT"
        fi
        return 1
    fi
    
    # Render based on view mode
    case "$view_mode" in
        default)
            render_manager_status_default "$body"
            ;;
        raw)
            render_manager_status_raw "$body"
            ;;
        verbose)
            render_manager_status_raw "$body"
            ;;
        json)
            render_manager_status_json "$body"
            ;;
    esac
    
    return 0
}

# Pause indexing
manager_pause_indexing() {
    # Check for help first
    if [ "$1" = "--help" ] || [ "$1" = "-h" ]; then
        cat << 'EOF'
USAGE:
  bitoarch pause-indexing

DESCRIPTION:
  Pause the currently running indexing process. This temporarily halts
  repository indexing while preserving the current progress. The indexing
  can be resumed later using 'bitoarch resume-indexing'.

OPTIONS:
  --help, -h    Show this help

EXAMPLES:
  # Pause ongoing indexing
  bitoarch pause-indexing

  # Resume indexing later
  bitoarch resume-indexing

  # Check current status
  bitoarch index-status

NOTES:
  - Requires BITO_API_KEY to be configured in environment
  - Only works when indexing is currently running
  - Progress is preserved and can be resumed
EOF
        return 0
    fi

    # Get BITO API key from environment
    if [ -z "$BITO_API_KEY" ]; then
        print_error "BITO_API_KEY not found in environment"
        return 1
    fi

    # Get manager external port from environment (default to 5002)
    local MANAGER_PORT="${CIS_MANAGER_EXTERNAL_PORT:-5002}"
    local MANAGER_URL="${CIS_MANAGER_URL:-http://localhost:${MANAGER_PORT}}"

    # Ensure manager service is accessible (sets up port-forward for K8s if needed)
    ensure_manager_service_accessible

    print_info "Pausing indexing process..."

    # Make API call directly with curl
    local response=$(curl -s -w '\n%{http_code}' \
        -X POST \
        -H "Authorization: Bearer ${BITO_API_KEY}" \
        "${MANAGER_URL}/api/v2/indexing/pause" 2>/dev/null)

    # Extract HTTP code from last line
    local http_code=$(echo "$response" | tail -1)
    local body=$(echo "$response" | sed '$d')

    # Check for success (200 status code)
    if [ "$http_code" = "200" ]; then
        echo ""
        echo -e "${GREEN}✅ Indexing Paused Successfully${NC}"
        echo ""

        # Extract message from response if available
        if command -v jq >/dev/null 2>&1; then
            local message=$(echo "$body" | jq -r '.message // "Indexing process has been paused"')
            echo -e "${BLUE}Status:${NC}"
            echo "  • $message"
        else
            echo "$body"
        fi

        echo ""
        echo -e "${CYAN}${BOLD}📊 Next Steps:${NC}"
        echo -e "${BOLD}• Resume indexing: ${YELLOW}bitoarch resume-indexing${NC}${BOLD}"
        echo -e "${BOLD}• Check status: ${YELLOW}bitoarch index-status${NC}${BOLD}"
        echo -e "${BOLD}• Stop completely: ${YELLOW}bitoarch stop-indexing${NC}${BOLD}"

        return 0
    else
        echo ""
        echo -e "${RED}✗ Failed to Pause Indexing${NC}"
        echo ""
        echo -e "${BLUE}Error Details:${NC}"
        echo "  • HTTP Status: $http_code"
        echo "  • Response: $body"
        echo ""
        echo -e "${BLUE}Troubleshooting:${NC}"
        echo -e "  • Check if indexing is currently running: ${YELLOW}bitoarch index-status${NC}"
        echo -e "  • Verify BITO_API_KEY in environment"
        echo -e "  • Check if CIS Manager is accessible: ${YELLOW}bitoarch status${NC}"
        echo ""

        return 1
    fi
}

# Resume indexing
manager_resume_indexing() {
    # Check for help first
    if [ "$1" = "--help" ] || [ "$1" = "-h" ]; then
        cat << 'EOF'
USAGE:
  bitoarch resume-indexing

DESCRIPTION:
  Resume a previously paused indexing process. This continues repository
  indexing from where it was paused, preserving all previous progress.
  Only works if indexing was previously paused.

OPTIONS:
  --help, -h    Show this help

EXAMPLES:
  # Resume paused indexing
  bitoarch resume-indexing

  # Check progress after resuming
  bitoarch index-status

  # Pause again if needed
  bitoarch pause-indexing

NOTES:
  - Requires BITO_API_KEY to be configured in environment
  - Only works when indexing is currently paused
  - Continues from where indexing was paused
EOF
        return 0
    fi

    # Get BITO API key from environment
    if [ -z "$BITO_API_KEY" ]; then
        print_error "BITO_API_KEY not found in environment"
        return 1
    fi

    # Get manager external port from environment (default to 5002)
    local MANAGER_PORT="${CIS_MANAGER_EXTERNAL_PORT:-5002}"
    local MANAGER_URL="${CIS_MANAGER_URL:-http://localhost:${MANAGER_PORT}}"

    # Ensure manager service is accessible (sets up port-forward for K8s if needed)
    ensure_manager_service_accessible

    print_info "Resuming indexing process..."

    # Make API call directly with curl
    local response=$(curl -s -w '\n%{http_code}' \
        -X POST \
        -H "Authorization: Bearer ${BITO_API_KEY}" \
        "${MANAGER_URL}/api/v2/indexing/resume" 2>/dev/null)

    # Extract HTTP code from last line
    local http_code=$(echo "$response" | tail -1)
    local body=$(echo "$response" | sed '$d')

    # Check for success (200 status code)
    if [ "$http_code" = "200" ]; then
        echo ""
        echo -e "${GREEN}✅ Indexing Resumed Successfully${NC}"
        echo ""

        # Extract message from response if available
        if command -v jq >/dev/null 2>&1; then
            local message=$(echo "$body" | jq -r '.message // "Indexing process has been resumed"')
            echo -e "${BLUE}Status:${NC}"
            echo "  • $message"
        else
            echo "$body"
        fi

        echo ""
        echo -e "${CYAN}${BOLD}📊 Next Steps:${NC}"
        echo -e "${BOLD}• Monitor progress: ${YELLOW}bitoarch index-status${NC}${BOLD}"
        echo -e "${BOLD}• Pause if needed: ${YELLOW}bitoarch pause-indexing${NC}${BOLD}"
        echo -e "${BOLD}• Stop completely: ${YELLOW}bitoarch stop-indexing${NC}${BOLD}"

        return 0
    else
        echo ""
        echo -e "${RED}✗ Failed to Resume Indexing${NC}"
        echo ""
        echo -e "${BLUE}Error Details:${NC}"
        echo "  • HTTP Status: $http_code"
        echo "  • Response: $body"
        echo ""
        echo -e "${BLUE}Troubleshooting:${NC}"
        echo -e "  • Check if indexing is currently paused: ${YELLOW}bitoarch index-status${NC}"
        echo -e "  • Verify BITO_API_KEY in environment"
        echo -e "  • Check if CIS Manager is accessible: ${YELLOW}bitoarch status${NC}"
        echo ""

        return 1
    fi
}

# Stop indexing
manager_stop_indexing() {
    # Check for help first
    if [ "$1" = "--help" ] || [ "$1" = "-h" ]; then
        cat << 'EOF'
USAGE:
  bitoarch stop-indexing

DESCRIPTION:
  Completely stop the current indexing process. This terminates all
  indexing operations and clears the indexing queue. Unlike pause,
  this action cannot be resumed and will lose current progress.

OPTIONS:
  --help, -h    Show this help

EXAMPLES:
  # Stop indexing completely
  bitoarch stop-indexing

  # Start fresh indexing later
  bitoarch index-repos

  # Check status
  bitoarch index-status

NOTES:
  - Requires BITO_API_KEY to be configured in environment
  - This action cannot be undone - progress will be lost
  - Use 'pause-indexing' if you want to resume later
  - After stopping, use 'index-repos' to start fresh
EOF
        return 0
    fi

    # Get BITO API key from environment
    if [ -z "$BITO_API_KEY" ]; then
        print_error "BITO_API_KEY not found in environment"
        return 1
    fi

    # Get manager external port from environment (default to 5002)
    local MANAGER_PORT="${CIS_MANAGER_EXTERNAL_PORT:-5002}"
    local MANAGER_URL="${CIS_MANAGER_URL:-http://localhost:${MANAGER_PORT}}"

    # Ensure manager service is accessible (sets up port-forward for K8s if needed)
    ensure_manager_service_accessible

    print_info "Stopping indexing process..."

    # Make API call directly with curl
    local response=$(curl -s -w '\n%{http_code}' \
        -X POST \
        -H "Authorization: Bearer ${BITO_API_KEY}" \
        "${MANAGER_URL}/api/v2/indexing/stop" 2>/dev/null)

    # Extract HTTP code from last line
    local http_code=$(echo "$response" | tail -1)
    local body=$(echo "$response" | sed '$d')

    # Check for success (200 status code)
    if [ "$http_code" = "200" ]; then
        echo ""
        echo -e "${GREEN}✅ Indexing Stopped Successfully${NC}"
        echo ""

        # Extract message from response if available
        if command -v jq >/dev/null 2>&1; then
            local message=$(echo "$body" | jq -r '.message // "Indexing process has been stopped"')
            echo -e "${BLUE}Status:${NC}"
            echo "  • $message"
        else
            echo "$body"
        fi

        echo ""
        echo -e "${YELLOW}⚠️  Important:${NC}"
        echo "  • All indexing progress has been cleared"
        echo "  • Indexing queue has been reset"
        echo ""
        echo -e "${CYAN}${BOLD}📊 Next Steps:${NC}"
        echo -e "${BOLD}• Start fresh indexing: ${YELLOW}bitoarch index-repos${NC}${BOLD}"
        echo -e "${BOLD}• Check status: ${YELLOW}bitoarch index-status${NC}${BOLD}"

        return 0
    else
        echo ""
        echo -e "${RED}✗ Failed to Stop Indexing${NC}"
        echo ""
        echo -e "${BLUE}Error Details:${NC}"
        echo "  • HTTP Status: $http_code"
        echo "  • Response: $body"
        echo ""
        echo -e "${BLUE}Troubleshooting:${NC}"
        echo -e "  • Check if indexing is currently running: ${YELLOW}bitoarch index-status${NC}"
        echo -e "  • Verify BITO_API_KEY in environment"
        echo -e "  • Check if CIS Manager is accessible: ${YELLOW}bitoarch status${NC}"
        echo ""

        return 1
    fi
}

# Render functions for manager status
render_manager_status_default() {
    local response="$1"
    
    if ! command -v jq >/dev/null 2>&1; then
        print_error "jq is required for parsing"
        echo "$response"
        return 1
    fi

    echo ""

    # -----------------------------
    # 1) Configured Repositories
    # -----------------------------
    echo -e "${BLUE}Configured Repositories${NC}"
    echo ""

    local configured=$(echo "$response" | jq -r '.configured_repos // 0')
    echo "  Configured: $configured"
    echo -e "  ${BLUE}Note:${NC} Config can change while an index session is running."
    echo ""

    # -----------------------------
    # 2) Repo-level Index Status
    # -----------------------------
    echo -e "${BLUE}Index Status (Repo-level)${NC}"
    echo ""

    local state=$(echo "$response" | jq -r '.status // "unknown"')
    local completed=$(echo "$response" | jq -r '.completed_repos // 0')
    local total=$(echo "$response" | jq -r '.total_repos // 0')
    local in_progress=$(echo "$response" | jq -r '.in_progress_repos // 0')
    local failed=$(echo "$response" | jq -r '.failed_repos // 0')

    # Keep your existing "display_state" logic
    local display_state="$state"
    local state_message=""
    local is_indexing_control_state=false

    # Handle new indexing control states first
    case "$state" in
        "pausing")
            display_state="pausing"
            state_message="Indexing is being paused..."
            is_indexing_control_state=true
            ;;
        "paused")
            display_state="paused"
            state_message="Indexing is paused. Use ${YELLOW}'bitoarch resume-indexing'${NC} to continue."
            is_indexing_control_state=true
            ;;
        "stopping")
            display_state="stopping"
            state_message="Indexing is being stopped..."
            is_indexing_control_state=true
            ;;
        "stopped")
            display_state="stopped"
            state_message="Indexing has been stopped. Use ${YELLOW}'bitoarch index-repos'${NC} to restart."
            is_indexing_control_state=true
            ;;
        "resuming")
            display_state="resuming"
            state_message="Indexing is resuming..."
            is_indexing_control_state=true
            ;;
        *)
            ;;
    esac

    if [ "$failed" -gt 0 ] && [ "$is_indexing_control_state" = "false" ]; then
        if [ "$state" = "running" ] || [ "$state" = "indexing" ] || [ "$state" = "in_progress" ]; then
            display_state="running (with failures)"
        elif [ "$state" = "completed" ] || [ "$state" = "success" ]; then
            display_state="completed with errors"
        fi
    fi

    # Keep same repo-level State rendering
    # Show status with appropriate emoji and colors
    case "$display_state" in
        "pausing")
            echo -e "  State: ${YELLOW}⏸️  $display_state${NC}"
            ;;
        "paused")
            echo -e "  State: ${BLUE}⏸️  $display_state${NC}"
            ;;
        "stopping")
            echo -e "  State: ${YELLOW}⏹️  $display_state${NC}"
            ;;
        "stopped")
            echo -e "  State: ${RED}⏹️  $display_state${NC}"
            ;;
        "resuming")
            echo -e "  State: ${YELLOW}▶️  $display_state${NC}"
            ;;
        "indexing"|"running"|"in_progress")
            echo -e "  State: ${YELLOW}⏳ $display_state${NC}"
            ;;
        "running (with failures)")
            echo -e "  State: ${YELLOW}⚠️  $display_state${NC}"
            ;;
        "completed"|"success")
            echo -e "  State: ${GREEN}✓ $display_state${NC}"
            ;;
        "completed with errors")
            echo -e "  State: ${YELLOW}⚠️  $display_state${NC}"
            ;;
        "failed"|"error")
            echo -e "  State: ${RED}✗ $display_state${NC}"
            ;;
        "idle"|"waiting")
            echo -e "  State: ${BLUE}• $display_state${NC}"
            ;;
        *)
            echo -e "  State: $display_state"
            ;;
    esac

    if [ -n "$state_message" ]; then
        echo -e "  Message: $state_message"
    fi

    echo "  Progress: $completed / $total completed"
    if [ "$in_progress" -gt 0 ]; then
        if [ "$is_indexing_control_state" = "true" ]; then
            case "$state" in
                paused)
                    echo "  Repositories paused: $in_progress"
                    ;;
                pausing)
                    echo "  Repositories being paused: $in_progress"
                    ;;
                resuming)
                    echo "  Repositories resuming: $in_progress"
                    ;;
                stopping)
                    echo "  Repositories being stopped: $in_progress"
                    ;;
                stopped)
                    echo "  Repositories stopped: $in_progress"
                    ;;
            esac
        else
            echo "  In Progress: $in_progress"
        fi
    fi
    if [ "$failed" -gt 0 ]; then
        echo -e "  ${RED}Failed: $failed${NC}"
    fi

    # Keep your failed repo details block as-is
    if [ "$failed" -gt 0 ]; then
        echo ""
        echo -e "${RED}❌ Failed Repositories:${NC}"

        local failed_details
        failed_details=$(echo "$response" | jq -r '.failed_repo_details[]? | "  • \(.namespace // .repository_name): \(.error // .failure_reason // "Unknown error")"' 2>/dev/null)

        if [ -n "$failed_details" ]; then
            echo "$failed_details"
        else
            failed_details=$(echo "$response" | jq -r '.failures[]? | "  • \(.repo // .name): \(.message // .error)"' 2>/dev/null)
            if [ -n "$failed_details" ]; then
                echo "$failed_details"
            else
                echo "  • $failed repository(ies) failed (use --raw for details)"
            fi
        fi
    fi

    echo ""

    # -----------------------------
    # 3) Workspace-level Index Status
    # -----------------------------
    echo -e "${BLUE}Index Status (Cross-Repo)${NC}"
    echo ""

    local ws_total ws_success ws_failure ws_in_progress
    ws_total=$(echo "$response" | jq -r '.workspace_level_index.total // 0')
    ws_success=$(echo "$response" | jq -r '.workspace_level_index.success // 0')
    ws_failure=$(echo "$response" | jq -r '.workspace_level_index.failure // 0')
    ws_in_progress=$(echo "$response" | jq -r '.workspace_level_index.in_progress // 0')
    cross_repo_status=$(echo "$response" | jq -r '.workspace_level_index.ws_status // "pending"')


    case "$cross_repo_status" in
        "pausing")
            echo -e "  State: ${YELLOW}⏸️  $cross_repo_status${NC}"
            ;;
        "paused")
            echo -e "  State: ${BLUE}⏸️  $cross_repo_status${NC}"
            ;;
        "stopping")
            echo -e "  State: ${YELLOW}⏹️  $cross_repo_status${NC}"
            ;;
        "stopped")
            echo -e "  State: ${RED}⏹️  $cross_repo_status${NC}"
            ;;
        "resuming")
            echo -e "  State: ${YELLOW}▶️  $cross_repo_status${NC}"
            ;;
        "indexing"|"running"|"in_progress")
            echo -e "  State: ${YELLOW}⏳ $cross_repo_status${NC}"
            ;;
        "running (with failures)")
            echo -e "  State: ${YELLOW}⚠️  $cross_repo_status${NC}"
            ;;
        "completed"|"success")
            echo -e "  State: ${GREEN}✓ $cross_repo_status${NC}"
            ;;
        "completed with errors")
            echo -e "  State: ${YELLOW}⚠️  $cross_repo_status${NC}"
            ;;
        "failed"|"error")
            echo -e "  State: ${RED}✗ $cross_repo_status${NC}"
            ;;
        "idle"|"waiting")
            echo -e "  State: ${BLUE}• $cross_repo_status${NC}"
            ;;
        *)
            echo -e "  State: $cross_repo_status"
            ;;
    esac

    # Match repo-level style: "Progress: X / Y completed" + optional In Progress + Failed
#    echo "  Progress: $ws_success / $ws_total completed"
    if [ "$ws_in_progress" -gt 0 ]; then
        if [ "$is_indexing_control_state" = "true" ]; then
            case "$cross_repo_status" in
                paused)
                    echo "  Cross-Repo indexing paused"
                    ;;
                pausing)
                    echo "  Cross-Repo indexing being paused"
                    ;;
                resuming)
                    echo "  Cross-Repo indexing is resuming"
                    ;;
                stopping)
                    echo "  Cross-Repo indexing being stopped"
                    ;;
                stopped)
                    echo "  Cross-Repo indexing stopped"
                    ;;
            esac
        else
            echo "  Cross-Repo indexing in-Progress"
        fi
    fi

    if [ "$ws_failure" -gt 0 ]; then
        echo -e "  ${RED}Cross-Repo indexing failed${NC}"
    fi


    if [[ ( "$state" == "completed" || "$state" == "success" ) \
       && ( "$cross_repo_status" == "completed" || "$cross_repo_status" == "success" ) ]]; then
        # Source constants if not already loaded
        if [ -z "$MCP_SETUP_DOCS_URL" ]; then
            local SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && cd ../.. && pwd)"
            source "${SCRIPT_DIR}/scripts/lib/constants.sh" 2>/dev/null || true
        fi
        
        echo ""
        echo -e "${GREEN}✅ Indexing Complete!${NC}"
        echo ""
        echo -e "${BLUE}📖 Next Steps:${NC}"
        echo -e "  Set up your MCP server to access the indexed repositories"
        echo -e "  ${YELLOW}Guide: ${MCP_SETUP_DOCS_URL:-https://docs.bito.ai/ai-architect/install-ai-architect-self-hosted#setting-up-ai-architect-mcp-in-coding-agents}${NC}"
        echo ""
    else
        echo ""
        echo -e "${BLUE}💡 Options:${NC}"
        echo -e "  • ${YELLOW}--raw${NC}      Show complete API response with full error details"
        echo ""
    fi
}

render_manager_status_raw() {
    local response="$1"
    
    echo "# Raw API Response (unfiltered)"
    echo ""
    
    if command -v jq >/dev/null 2>&1; then
        echo "$response" | jq '.'
    else
        echo "$response"
    fi
}

render_manager_status_json() {
    local response="$1"
    
    # Filtered JSON for machine consumption - map from actual API fields
    if command -v jq >/dev/null 2>&1; then
        echo "$response" | jq '{
            status: .status,
            total_repos: .total_repos,
            completed_repos: .completed_repos,
            in_progress_repos: .in_progress_repos,
            failed_repos: .failed_repos,
            percentage_completion: .percentage_completion
        }'
    else
        echo '{"error": "jq required for JSON output"}'
    fi
}

render_manager_status_error() {
    local error_type="$1"
    local error_msg="$2"
    local endpoint="$3"
    
    echo ""
    echo -e "${RED}✗ Failed to retrieve index status${NC}"
    echo ""
    echo -e "${BLUE}Error Details:${NC}"
    
    if [ "$error_type" = "connection_failed" ]; then
        echo "  • Type: Connection Error"
        echo "  • Endpoint: $endpoint"
        echo "  • Message: $error_msg"
    else
        echo "  • HTTP Status: $error_type"
        echo "  • Endpoint: $endpoint"
        echo "  • Response: $error_msg"
    fi
    
    echo ""
    echo -e "${BLUE}Troubleshooting:${NC}"
    echo -e "  • Check if CIS Manager is running: ${YELLOW}bitoarch status${NC}"
    echo -e "  • Verify BITO_API_KEY in .env"
    echo -e "  • Check logs: ${YELLOW}./setup.sh --logs${NC}"
    echo ""
}

# Export functions
export -f manager_sync_simple
export -f manager_status
export -f manager_pause_indexing
export -f manager_resume_indexing
export -f manager_stop_indexing
