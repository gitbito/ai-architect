#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
# Bito's AI Architect - Output Rendering System
# Block-level output functions for coherent, structured user-facing messages
# Business logic calls these render functions with data - presentation is isolated here

# ============================================================================
# COLOR DEFINITIONS
# ============================================================================
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[1;34m'
CYAN='\033[0;36m'
NC='\033[0m'
BOLD='\033[1m'

# ============================================================================
# PATH MANAGER INTEGRATION
# ============================================================================
# Source path-manager for config file path resolution
SCRIPT_DIR="${SCRIPT_DIR:-$(cd "$(dirname "${BASH_SOURCE[0]}")" && cd ../.. && pwd)}"
if [ -f "${SCRIPT_DIR}/scripts/lib/path-manager.sh" ]; then
    source "${SCRIPT_DIR}/scripts/lib/path-manager.sh"
fi

# ============================================================================
# SIMPLE MESSAGE FUNCTIONS (1-2 lines)
# ============================================================================

# Success message (✓ green)
msg_success() {
    echo -e "${GREEN}✓${NC} $1"
    log_silent "SUCCESS: $1"
}

# Info message (ℹ blue)
msg_info() {
    echo -e "${BLUE}ℹ${NC} $1"
    log_silent "INFO: $1"
}

# Warning message (⚠ yellow)
msg_warn() {
    echo -e "${YELLOW}⚠${NC} $1"
    log_silent "WARNING: $1"
}

# Error message (✗ red)
msg_error() {
    echo -e "${RED}✗${NC} $1"
    log_silent "ERROR: $1"
}

# Backward compatibility aliases
print_status() { msg_success "$1"; }
print_info() { msg_info "$1"; }
print_warning() { msg_warn "$1"; }
print_error() { msg_error "$1"; }

# Technical logging (silent)
log_technical() {
    log_silent "TECHNICAL: $1"
}

# ============================================================================
# DEPLOYMENT BLOCKS
# ============================================================================

render_deploy_success_banner() {
    echo ""
    echo -e "${GREEN}🎉 Bito's AI Architect is successfully deployed! 🎉${NC}"
    echo ""
}

render_deploy_success_block() {
    local mcp_token="$1"
    local mcp_url="$2"
    local cli_path="$3"
    local git_provider="$4"
    local setup_mode="${5:-manual}"
    
    # Extract host and port from mcp_url for curl example
    local mcp_host=$(echo "$mcp_url" | sed 's|http://||' | sed 's|/mcp||')
    
    echo ""
    echo -e "${BLUE}🔑 MCP Server Configuration${NC}"
    echo ""
    echo -e "${YELLOW}⚠️ You will need this information to set up your MCP server in your coding agent${NC}"
    echo -e "${YELLOW}  (Claude, Cursor, Codex, Copilot, etc):${NC}"
    echo ""
    echo -e "  • Bito MCP URL:          ${CYAN}${mcp_url}${NC}"
    echo -e "  • Bito MCP Access Token: ${CYAN}${mcp_token}${NC}"
    echo ""
    echo -e "   For full information on how to access the AI Architect MCP Server in your coding agent,"
    echo -e "   please see our docs at: ${BLUE}${MCP_SETUP_DOCS_URL:-https://docs.bito.ai/ai-architect/install-ai-architect-self-hosted#setting-up-ai-architect-mcp-in-coding-agents}${NC}"
    echo ""
    
    echo -e "${BLUE}📋 Important Files${NC}"
    echo ""
    echo "  • ENV Config: ${ENV_FILE}"
    echo "  • LLM Config:  ${ENV_LLM_FILE:-${SCRIPT_DIR}/.env-llm-bitoarch}"
    echo "  • Setup Log:   ${LOG_FILE}"
    echo ""
    
    echo -e "${BLUE}🔧 CLI Commands${NC}"
    echo ""
    echo -e "  • Activate CLI:       ${YELLOW}source ~/.${SHELL##*/}rc${NC} (or restart terminal)"
    echo -e "  • Check status:       ${YELLOW}bitoarch status${NC}"
    echo -e "  • View MCP tools:     ${YELLOW}bitoarch mcp-tools${NC}"
    echo -e "  📖 CLI Reference:     ${YELLOW}docs/CLI_REFERENCE.md${NC}"
    echo ""
    
    if [[ "$setup_mode" == "manual" ]]; then
        local repo_config_file
        if type get_repo_config_file >/dev/null 2>&1; then
            repo_config_file="$(get_repo_config_file)"
        else
            repo_config_file=".bitoarch-config.yaml"
        fi
        
        echo -e "${BLUE}🚀 Next Steps${NC}"
        echo ""
        echo -e "  1. Add repositories:    ${YELLOW}bitoarch add-repos ${repo_config_file}${NC}"
        echo -e "  2. Start indexing:      ${YELLOW}bitoarch index-repos${NC}"
        echo -e "  3. Monitor progress:    ${YELLOW}bitoarch index-status${NC}"
        echo ""
    fi
    
    echo -e "For complete AI Architect documentation, visit: ${BLUE}${AI_ARCHITECT_DOCS_URL:-https://docs.bito.ai/ai-architect/install-ai-architect-self-hosted}${NC}"
    echo ""
}

render_deploy_failure_block() {
    local failed_service="$1"
    local error_msg="$2"
    local log_file="$3"
    
    echo ""
    echo -e "${RED}❌ Platform Deployment Failed${NC}"
    echo ""
    echo -e "${YELLOW}⚠️ Issue${NC}"
    echo -e "   Service: ${BOLD}${failed_service}${NC}"
    echo -e "   Error: ${error_msg}"
    echo ""
    echo -e "${BLUE}🔍 Troubleshooting${NC}"
    echo -e "   • Check logs: ${YELLOW}docker logs ${failed_service}${NC}"
    echo -e "   • View details: ${YELLOW}cat ${log_file}${NC}"
    echo -e "   • Restart: ${YELLOW}./setup.sh --restart${NC}"
    echo ""
}

# ============================================================================
# CONFIG COMMAND BLOCKS
# ============================================================================

render_config_get_summary_block() {
    local config_json="$1"
    
    if ! command -v jq >/dev/null 2>&1; then
        echo ""
        echo -e "${GREEN}✅ Configuration Retrieved${NC}"
        echo ""
        echo "$config_json"
        return 0
    fi
    
    echo ""
    echo -e "${GREEN}✅ Configuration Retrieved${NC}"
    echo ""
    echo -e "${BLUE}📊 Repository Configuration${NC}"
    echo ""
    
    local repo_count=$(echo "$config_json" | jq -r '.repository.configured_repos | length' 2>/dev/null || echo "0")
    local repo_limit=$(echo "$config_json" | jq -r '.repository.repo_limit // "N/A"')
    local size_limit=$(echo "$config_json" | jq -r '.repository.repo_size_limit // "N/A"')
    
    echo "  Repository Limit: $repo_limit"
    echo "  Repository Size Limit(Indexable size): $size_limit"
    echo "  Total Repositories: $repo_count"
    echo ""
    
    if [ "$repo_count" -gt 0 ]; then
        echo -e "${BLUE}📁 Configured Repositories${NC}"
        if [ "$repo_count" -le 5 ]; then
            echo "$config_json" | jq -r '.repository.configured_repos[]?.namespace // empty' 2>/dev/null | while read -r ns; do
                echo "  • $ns"
            done
        else
            echo "$config_json" | jq -r '.repository.configured_repos[0:5][] | .namespace // empty' 2>/dev/null | while read -r ns; do
                echo "  • $ns"
            done
            echo "  ... and $((repo_count - 5)) more"
        fi
        echo ""
    fi
    
    echo -e "${BLUE}💡 Tip:${NC} Use ${YELLOW}--raw${NC} to see full configuration"
    echo ""
}

render_config_get_raw_block() {
    local config_json="$1"
    
    echo ""
    echo -e "${GREEN}✅ Configuration Retrieved${NC}"
    echo ""
    echo "# Raw API Response (secrets masked for security)"
    echo ""
    mask_secrets "$config_json"
    echo ""
}

render_config_get_success_block() {
    local config_json="$1"
    
    echo ""
    echo -e "${GREEN}✅ Configuration Retrieved${NC}"
    echo ""
    if command -v jq >/dev/null 2>&1 && echo "$config_json" | jq . >/dev/null 2>&1; then
        echo "$config_json" | jq '.'
    else
        echo "$config_json"
    fi
    echo ""
}

render_config_get_failure_block() {
    local http_code="$1"
    local error_body="$2"
    
    echo ""
    echo -e "${RED}❌ Failed to Retrieve Configuration${NC}"
    echo ""
    echo -e "${YELLOW}⚠️ Details${NC}"
    echo -e "   HTTP Status: ${http_code}"
    echo -e "   Response: ${error_body}"
    echo ""
    echo -e "${BLUE}🔍 Check${NC}"
    echo -e "   • Is BITO_API_KEY set correctly in .env-bitoarch?"
    echo -e "   • Is AI Architect Config service running? ${YELLOW}bitoarch status${NC}"
    echo ""
}

render_config_add_success_block() {
    local config_json="$1"
    local show_raw="${2:-false}"
    
    if ! command -v jq >/dev/null 2>&1; then
        # Fallback without jq
        echo ""
        echo -e "${GREEN}✅ Configuration Added Successfully${NC}"
        echo ""
        return 0
    fi
    
    # If --raw flag, show full masked response
    if [ "$show_raw" = "true" ]; then
        echo ""
        echo -e "${GREEN}✅ Configuration Added Successfully${NC}"
        echo ""
        echo "# Raw API Response (secrets masked for security)"
        echo ""
        mask_secrets "$config_json"
        echo ""
        return 0
    fi
    
    # Extract customer-relevant fields only
    local repo_count=$(echo "$config_json" | jq -r '.repository.configured_repos | length' 2>/dev/null || echo "0")
    local repo_limit=$(echo "$config_json" | jq -r '.repository.repo_limit // "N/A"')
    local size_limit=$(echo "$config_json" | jq -r '.repository.repo_size_limit // "N/A"')
    local git_provider=$(echo "$config_json" | jq -r '.integration.git.provider // "N/A"')
    
    echo ""
    echo -e "${GREEN}✅ Configuration Added Successfully${NC}"
    echo ""
    echo -e "${BLUE}📊 Repository Configuration${NC}"
    echo -e "   • Git provider: ${BOLD}${git_provider}${NC}"
    echo -e "   • Total repositories: ${BOLD}${repo_count}${NC}"
    echo -e "   • Repo limit: ${repo_limit}"
    echo -e "   • Indexable size (per repository): ${size_limit}"
    echo -e "   • Re-indexing interval: manual"
    echo ""
    
    # Show repository list if not too many
    if [ "$repo_count" -gt 0 ] && [ "$repo_count" -le 10 ]; then
        echo -e "${BLUE}📁 Configured Repositories${NC}"
        echo "$config_json" | jq -r '.repository.configured_repos[]?.namespace // empty' 2>/dev/null | while read -r ns; do
            echo "   • $ns"
        done
        echo ""
    elif [ "$repo_count" -gt 10 ]; then
        echo -e "${BLUE}📁 Configured Repositories${NC}"
        echo "$config_json" | jq -r '.repository.configured_repos[0:5][]?.namespace // empty' 2>/dev/null | while read -r ns; do
            echo "   • $ns"
        done
        echo "   ... and $((repo_count - 5)) more"
        echo ""
    fi
}

render_config_add_next_steps() {
    echo -e "${BLUE}🚀 Next Steps${NC}"
    echo -e "   1. Start indexing: ${YELLOW}bitoarch index-repos${NC}"
    echo -e "   2. Monitor progress: ${YELLOW}bitoarch index-status${NC}"
    echo ""
}

render_config_add_failure_block() {
    local http_code="$1"
    local error_body="$2"
    
    echo ""
    echo -e "${RED}❌ Configuration Add Failed${NC}"
    echo ""
    
    # Parse error message if JSON
    local error_msg="$error_body"
    if command -v jq >/dev/null 2>&1 && echo "$error_body" | jq . >/dev/null 2>&1; then
        error_msg=$(echo "$error_body" | jq -r '.error // .message // "Unknown error"')
    fi
    
    echo -e "${YELLOW}⚠️ Details${NC}"
    echo -e "   HTTP Status: ${http_code}"
    echo -e "   Error: ${error_msg}"
    echo ""
    
    # Provide specific guidance based on error
    if echo "$error_msg" | grep -qi "already exists"; then
        echo -e "${BLUE}💡 Tip${NC}"
        echo -e "   Configuration already exists. Use ${YELLOW}bitoarch update-repos .bitoarch-config.yaml${NC} to update it"
        echo ""
    else
        echo -e "${BLUE}🔍 Check${NC}"
        echo -e "   • Is BITO_API_KEY set correctly in .env-bitoarch?"
        echo -e "   • Is GIT_PROVIDER set in .env-bitoarch?"
        echo -e "   • Is GIT_ACCESS_TOKEN set in .env-bitoarch?"
        echo -e "   • Is AI Architect Config service running? ${YELLOW}bitoarch status${NC}"
        echo ""
    fi
}

render_namespace_added_block() {
    local namespace="$1"
    local config_file="$2"
    
    echo ""
    echo -e "${GREEN}✅ Namespace Added${NC}"
    echo ""
    echo -e "${BLUE}📝 Details${NC}"
    echo -e "   • Namespace: ${BOLD}${namespace}${NC}"
    echo -e "   • File: ${config_file}"
    echo ""
    echo -e "${BLUE}🚀 Next Step${NC}"
    echo -e "   Apply changes: ${YELLOW}bitoarch add-repos ${config_file}${NC}"
    echo ""
}

render_namespace_removed_block() {
    local namespace="$1"
    local config_file="$2"
    
    echo ""
    echo -e "${GREEN}✅ Namespace Removed${NC}"
    echo ""
    echo -e "${BLUE}📝 Details${NC}"
    echo -e "   • Namespace: ${BOLD}${namespace}${NC}"
    echo -e "   • File: ${config_file}"
    echo ""
    echo -e "${BLUE}🚀 Next Step${NC}"
    echo -e "   Update config: ${YELLOW}bitoarch update-repos ${config_file}${NC}"
    echo ""
}

render_repo_add_success_block() {
    local namespace="$1"
    local response_json="$2"
    
    if ! command -v jq >/dev/null 2>&1; then
        echo ""
        echo -e "${GREEN}✅ Repository Added Successfully${NC}"
        echo ""
        echo -e "   • Namespace: ${BOLD}${namespace}${NC}"
        echo ""
        return 0
    fi
    
    # Extract details from response
    local workspace_id=$(echo "$response_json" | jq -r '.workspace_id // "N/A"')
    local repo_count=$(echo "$response_json" | jq -r '.configured_repos | length' 2>/dev/null || echo "0")
    
    echo ""
    echo -e "${GREEN}✅ Repository Added Successfully${NC}"
    echo ""
    echo -e "${BLUE}📝 Details${NC}"
    echo -e "   • Namespace: ${BOLD}${namespace}${NC}"
    echo -e "   • Workspace ID: ${workspace_id}"
    echo -e "   • Total Repositories: ${repo_count}"
    echo ""
    
    # Show configured repos if not too many
    if [ "$repo_count" -gt 0 ] && [ "$repo_count" -le 10 ]; then
        echo -e "${BLUE}📁 Configured Repositories${NC}"
        echo "$response_json" | jq -r '.configured_repos[]?.namespace // empty' 2>/dev/null | while read -r ns; do
            if [ "$ns" = "$namespace" ]; then
                echo -e "   • ${BOLD}${ns}${NC} ${GREEN}(newly added)${NC}"
            else
                echo "   • $ns"
            fi
        done
        echo ""
    elif [ "$repo_count" -gt 10 ]; then
        echo -e "${BLUE}📁 Recently Added${NC}"
        echo -e "   • ${BOLD}${namespace}${NC}"
        echo ""
    fi
    
    echo -e "${BLUE}🚀 Next Steps${NC}"
    echo -e "   1. View all repositories: ${YELLOW}bitoarch show-config${NC}"
    echo -e "   2. Start indexing: ${YELLOW}bitoarch index-repos${NC}"
    echo ""
}

render_repo_add_failure_block() {
    local namespace="$1"
    local http_code="$2"
    local error_body="$3"
    
    echo ""
    echo -e "${RED}❌ Failed to Add Repository${NC}"
    echo ""
    
    # Parse error message if JSON
    local error_msg="$error_body"
    if command -v jq >/dev/null 2>&1 && echo "$error_body" | jq . >/dev/null 2>&1; then
        error_msg=$(echo "$error_body" | jq -r '.error // .message // "Unknown error"')
    fi
    
    echo -e "${YELLOW}⚠️ Details${NC}"
    echo -e "   • Namespace: ${namespace}"
    echo -e "   • HTTP Status: ${http_code}"
    echo -e "   • Error: ${error_msg}"
    echo ""
    
    # Provide specific guidance based on error
    if echo "$error_msg" | grep -qi "already exists"; then
        echo -e "${BLUE}💡 Note${NC}"
        echo -e "   Repository '${namespace}' is already configured"
        echo ""
    elif echo "$error_msg" | grep -qi "authentication\|authorization\|unauthorized"; then
        echo -e "${BLUE}🔍 Check${NC}"
        echo -e "   • Is BITO_API_KEY set correctly in .env-bitoarch?"
        echo -e "   • Verify token has correct permissions"
        echo ""
    elif echo "$error_msg" | grep -qi "not found\|404"; then
        echo -e "${BLUE}🔍 Check${NC}"
        echo -e "   • Verify repository namespace is correct"
        echo -e "   • Ensure repository exists and is accessible"
        echo ""
    else
        echo -e "${BLUE}🔍 Check${NC}"
        echo -e "   • Is BITO_API_KEY set correctly in .env-bitoarch?"
        echo -e "   • Is AI Architect Config service running? ${YELLOW}bitoarch status${NC}"
        echo -e "   • Check service logs: ${YELLOW}docker logs ai-architect-config${NC}"
        echo ""
    fi
}

render_repo_remove_success_block() {
    local namespace="$1"
    local response_json="$2"
    
    if ! command -v jq >/dev/null 2>&1; then
        echo ""
        echo -e "${GREEN}✅ Repository Removed Successfully${NC}"
        echo ""
        echo -e "   • Namespace: ${BOLD}${namespace}${NC}"
        echo ""
        return 0
    fi
    
    # Extract details from response
    local workspace_id=$(echo "$response_json" | jq -r '.workspace_id // "N/A"')
    local repo_count=$(echo "$response_json" | jq -r '.configured_repos | length' 2>/dev/null || echo "0")
    
    echo ""
    echo -e "${GREEN}✅ Repository Removed Successfully${NC}"
    echo ""
    echo -e "${BLUE}📝 Details${NC}"
    echo -e "   • Namespace: ${BOLD}${namespace}${NC}"
    echo -e "   • Workspace ID: ${workspace_id}"
    echo -e "   • Remaining Repositories: ${repo_count}"
    echo ""
    
    # Show remaining repos if not too many
    if [ "$repo_count" -gt 0 ] && [ "$repo_count" -le 10 ]; then
        echo -e "${BLUE}📁 Remaining Configured Repositories${NC}"
        echo "$response_json" | jq -r '.configured_repos[]?.namespace // empty' 2>/dev/null | while read -r ns; do
            echo "   • $ns"
        done
        echo ""
    fi
    
    echo -e "${BLUE}🚀 Next Steps${NC}"
    echo -e "   1. View all repositories: ${YELLOW}bitoarch show-config${NC}"
    echo -e "   2. Re-index workspace: ${YELLOW}bitoarch index-repos${NC}"
    echo ""
}

render_repo_remove_failure_block() {
    local namespace="$1"
    local http_code="$2"
    local error_body="$3"
    
    echo ""
    echo -e "${RED}❌ Failed to Remove Repository${NC}"
    echo ""
    
    # Parse error message if JSON
    local error_msg="$error_body"
    if command -v jq >/dev/null 2>&1 && echo "$error_body" | jq . >/dev/null 2>&1; then
        error_msg=$(echo "$error_body" | jq -r '.error // .message // "Unknown error"')
    fi
    
    echo -e "${YELLOW}⚠️ Details${NC}"
    echo -e "   • Namespace: ${namespace}"
    echo -e "   • HTTP Status: ${http_code}"
    echo -e "   • Error: ${error_msg}"
    echo ""
    
    # Provide specific guidance based on error
    if echo "$error_msg" | grep -qi "not found\|does not exist"; then
        echo -e "${BLUE}💡 Note${NC}"
        echo -e "   Repository '${namespace}' is not in the configuration"
        echo -e "   • View configured repos: ${YELLOW}bitoarch show-config${NC}"
        echo ""
    elif echo "$error_msg" | grep -qi "authentication\|authorization\|unauthorized"; then
        echo -e "${BLUE}🔍 Check${NC}"
        echo -e "   • Is BITO_API_KEY set correctly in .env-bitoarch?"
        echo -e "   • Verify token has correct permissions"
        echo ""
    else
        echo -e "${BLUE}🔍 Check${NC}"
        echo -e "   • Is BITO_API_KEY set correctly in .env-bitoarch?"
        echo -e "   • Is AI Architect Config service running? ${YELLOW}bitoarch status${NC}"
        echo -e "   • Check service logs: ${YELLOW}docker logs ai-architect-config${NC}"
        echo ""
    fi
}

# ============================================================================
# MANAGER SYNC BLOCKS
# ============================================================================

render_sync_started_block() {
    local workspace_id="$1"
    local index_type="$2"
    local repo_count="$3"
    
    echo ""
    echo -e "${GREEN}✅ Indexing Initiated${NC}"
    echo ""
    echo -e "${BLUE}📊 Indexing Details${NC}"
    echo -e "   • Workspace: ${BOLD}${workspace_id}${NC}"
    echo -e "   • Type: ${index_type}"
    [ -n "$repo_count" ] && echo -e "   • Repositories: ${repo_count}"
    echo ""
    echo -e "${BLUE}🔍 Monitor Progress${NC}"
    echo -e "   ${YELLOW}bitoarch index-status${NC}"
    echo ""
}

render_sync_failure_block() {
    local workspace_id="$1"
    local error_msg="$2"
    
    echo ""
    echo -e "${RED}❌ Indexing Failed${NC}"
    echo ""
    echo -e "${YELLOW}⚠️ Details${NC}"
    echo -e "   • Workspace: ${workspace_id}"
    echo -e "   • Error: ${error_msg}"
    echo ""
    echo -e "${BLUE}🔍 Troubleshoot${NC}"
    echo -e "   • Verify configuration: ${YELLOW}bitoarch show-config${NC}"
    echo -e "   • Check service health: ${YELLOW}bitoarch status${NC}"
    echo ""
}

render_status_block() {
    local status_json="$1"
    
    echo ""
    echo -e "${BLUE}📊 Index Status${NC}"
    echo ""
    if command -v jq >/dev/null 2>&1 && echo "$status_json" | jq . >/dev/null 2>&1; then
        # Extract key fields for customer-centric view
        local state=$(echo "$status_json" | jq -r '.state // "unknown"')
        local progress=$(echo "$status_json" | jq -r '.progress // "0"')
        local total=$(echo "$status_json" | jq -r '.total // "0"')
        
        echo -e "   • State: ${BOLD}${state}${NC}"
        echo -e "   • Progress: ${progress}/${total}"
        echo ""
        
        # Show full JSON for details
        echo -e "${BLUE}📋 Full Details${NC}"
        echo "$status_json" | jq '.'
    else
        echo "$status_json"
    fi
    echo ""
}

# ============================================================================
# PLATFORM STATUS BLOCKS
# ============================================================================

render_platform_status_block() {
    local healthy_count="$1"
    local total_count="$2"
    local services_detail="$3"
    
    echo ""
    echo -e "${BLUE}🖥️  Platform Status${NC}"
    echo ""
    
    if [ "$healthy_count" -eq "$total_count" ]; then
        echo -e "${GREEN}✅ All Services Healthy${NC} (${healthy_count}/${total_count})"
    elif [ "$healthy_count" -gt 0 ]; then
        echo -e "${YELLOW}⚠️  Partial Health${NC} (${healthy_count}/${total_count})"
    else
        echo -e "${RED}❌ All Services Down${NC} (${healthy_count}/${total_count})"
    fi
    
    echo ""
    echo -e "${BLUE}📋 Services${NC}"
    echo "$services_detail"
    echo ""
    echo -e "${BLUE}🔧 Quick Actions${NC}"
    echo -e "   • View logs: ${YELLOW}./setup.sh --logs${NC}"
    echo -e "   • Restart: ${YELLOW}./setup.sh --restart${NC}"
    echo ""
}

# ============================================================================
# MCP PROVIDER BLOCKS
# ============================================================================

render_mcp_tools_list_block() {
    local tools_json="$1"
    local show_details="${2:-false}"
    
    if [ "$show_details" = "true" ]; then
        # Full details - show complete JSON response
        echo ""
        echo -e "${BLUE}MCP Tools (Detailed)${NC}"
        echo ""
        if command -v jq >/dev/null 2>&1; then
            echo "$tools_json" | jq '.'
        else
            echo "$tools_json"
        fi
        echo ""
    else
        # Just names - clean list
        echo ""
        echo -e "${CYAN}Available MCP Tools:${NC}"
        echo ""
        if command -v jq >/dev/null 2>&1; then
            # Extract tool names from result.tools array
            local tool_names=$(echo "$tools_json" | jq -r '.result.tools[]?.name // empty' 2>/dev/null)
            if [ -n "$tool_names" ]; then
                echo "$tool_names" | while read -r tool; do
                    echo "  • $tool"
                done
            else
                echo "  No tools found"
            fi
        else
            echo "$tools_json"
        fi
        echo ""
        echo -e "${BLUE}💡 Tips:${NC}"
        echo -e "   • Use ${YELLOW}--details${NC} flag to see full tool information"
        echo -e "   • Get specific tool info: ${YELLOW}bitoarch mcp-tool-info <toolname>${NC}"
        echo ""
    fi
}

render_mcp_test_success_block() {
    local mcp_url="$1"
    
    echo ""
    echo -e "${GREEN}✅ MCP Connection Test Passed${NC}"
    echo ""
    echo -e "${BLUE}🔍 Results${NC}"
    echo -e "   • Health check: ${GREEN}OK${NC}"
    echo -e "   • MCP endpoint: ${GREEN}OK${NC}"
    echo -e "   • Authentication: ${GREEN}OK${NC}"
    echo ""
    echo -e "${BLUE}🌐 Endpoint${NC}"
    echo -e "   ${mcp_url}"
    echo ""
}

render_mcp_test_failure_block() {
    local mcp_url="$1"
    local failure_reason="$2"
    
    echo ""
    echo -e "${RED}❌ MCP Connection Test Failed${NC}"
    echo ""
    echo -e "${YELLOW}⚠️ Issue${NC}"
    echo -e "   ${failure_reason}"
    echo ""
    echo -e "${BLUE}🔍 Troubleshoot${NC}"
    echo -e "   • Check service: ${YELLOW}bitoarch status${NC}"
    echo -e "   • Verify token in .env-bitoarch: BITO_MCP_ACCESS_TOKEN"
    echo -e "   • Test URL: ${mcp_url}"
    echo ""
}

# ============================================================================
# TOKEN ROTATION BLOCKS
# ============================================================================

render_token_rotated_block() {
    local new_token="$1"
    local mcp_url="$2"
    
    echo ""
    echo -e "${GREEN}✅ MCP Token Rotated${NC}"
    echo ""
    echo -e "${BLUE}🔑 New Credentials${NC}"
    echo -e "   • Token: ${BOLD}${new_token}${NC}"
    echo -e "   • URL: ${mcp_url}"
    echo ""
    echo -e "${GREEN}💡 Important${NC}"
    echo -e "   Update your MCP client configuration with the new token!"
    echo ""
}

# ============================================================================
# MCP CONFIGURATION BLOCKS
# ============================================================================

render_mcp_config_block() {
    local mcp_url="$1"
    local mcp_token="$2"
    
    echo ""
    echo -e "${BLUE}${BOLD}MCP Server Configuration${NC}"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo ""
    echo -e "${BLUE}Bito MCP URL:${NC}              ${mcp_url}"
    echo -e "${BLUE}Bito MCP Access Token:${NC}     ${mcp_token}"
    echo -e "${BLUE}Protocol:${NC}                  JSON-RPC 2.0"
    echo -e "${BLUE}Authentication:${NC}            Bearer Token"
    echo ""
    echo -e "${GREEN}📖 For full information on how to access the AI Architect MCP Server in your coding agent,${NC}"
    echo -e "${GREEN}   please see our docs at ${BLUE}${MCP_SETUP_DOCS_URL:-https://docs.bito.ai/ai-architect/install-ai-architect-self-hosted#setting-up-ai-architect-mcp-in-coding-agents}${NC}"
    echo ""
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo ""
    echo -e "${BLUE} Test Connection:${NC}   ${YELLOW}bitoarch mcp-test${NC}"
    echo ""
}

# ============================================================================
# CLEANUP BLOCKS
# ============================================================================

render_clean_complete_block() {
    local removed_services="$1"
    local removed_volumes="$2"
    
    echo ""
    echo -e "${GREEN}✅ AI Architect Cleanup Complete${NC}"
    echo ""
    echo -e "${BLUE}🗑️  Removed${NC}"
    echo -e "   • Services: ${removed_services}"
    echo -e "   • Data volumes: ${removed_volumes}"
    echo -e "   • Local directories: Cleared"
    echo -e "   • CLI: Uninstalled"
    echo ""
    echo -e "${BLUE}💡 Next Steps${NC}"
    echo -e "   • Run ${YELLOW}./setup.sh${NC} to reinstall"
    echo -e "   • All data has been permanently removed"
    echo ""
}

render_stop_complete_block() {
    echo ""
    echo -e "${GREEN}✅ AI Architect Stopped${NC}"
    echo ""
    echo -e "${BLUE}📊 Status${NC}"
    echo -e "   • All services stopped"
    echo -e "   • Containers preserved (for quick restart)"
    echo -e "   • Data volumes preserved"
    echo -e "   • Configuration preserved"
    echo ""
    echo -e "${BLUE}💡 Next Steps${NC}"
    echo -e "   • Restart services: ${YELLOW}./setup.sh${NC}"
    echo -e "   • Remove all data: ${YELLOW}./setup.sh --clean${NC}"
    echo ""
}

# ============================================================================
# CONFIGURATION BLOCKS
# ============================================================================

render_manual_repo_config_block() {
    local repo_config_file
    if type get_repo_config_file >/dev/null 2>&1; then
        repo_config_file="$(get_repo_config_file)"
    else
        repo_config_file=".bitoarch-config.yaml"
    fi
    
    echo ""
    echo -e "${CYAN}📝 Manual Configuration Required${NC}"
    echo -e "   Use the default template file to configure repositories:"
    echo -e "   1. Copy template: ${YELLOW}cp .bitoarch-config.default.yaml ${repo_config_file}${NC}"
    echo -e "   2. Edit file and add your repositories"
    echo -e "   3. Save configuration: ${YELLOW}bitoarch add-repos ${repo_config_file}${NC}"
    echo -e "   4. Start indexing: ${YELLOW}bitoarch index-repos${NC}"
    echo ""
}

render_repo_config_choice_block() {
    local repo_config_file
    if type get_repo_config_file >/dev/null 2>&1; then
        repo_config_file="$(get_repo_config_file)"
    else
        repo_config_file=".bitoarch-config.yaml"
    fi
    
    echo "📘 Before You Proceed"
    echo -e "  You can review or modify the generated repository list in:"
    echo -e "      ${YELLOW}nano ${repo_config_file}${NC}"
    echo ""
    echo "  Please review the repository list in the yaml file above and delete the repositories you do not want the AI Architect to index."
    echo "  Remember, there is an LLM tokens cost for each repository that is indexed. You can add more repositories later as well."
    echo ""
    echo "🛠  How would you like to proceed?"
    echo ""
    echo "  1) Auto Configure (recommended)"
    echo "      - Automatically saves the repositories and starts indexing"
    echo "      - If needed, edit the repo list before selecting this option"
    echo ""
    echo "  2) Manual Setup"
    echo "      - You will manually update the configuration file"
    echo "      - Add/remove repositories as needed"
    echo -e "      - Save configuration using: ${YELLOW}bitoarch add-repos ${repo_config_file}${NC}"
    echo -e "      - Start indexing when ready: ${YELLOW}bitoarch index-repos${NC}"
    echo ""
}

render_manual_config_instructions_block() {
    local repo_config_file
    if type get_repo_config_file >/dev/null 2>&1; then
        repo_config_file="$(get_repo_config_file)"
    else
        repo_config_file=".bitoarch-config.yaml"
    fi
    
    echo -e "${BLUE}📘 MANUAL CONFIGURATION NEEDED${NC}"
    echo ""
    echo -e "✨ Your configuration file has been generated!"
    echo -e "   Let's finish setting things up manually 😊"
    echo ""
    echo -e "📝 ${YELLOW}Step 1:${NC} Open the configuration file:"
    echo -e "      nano ${repo_config_file}"
    echo ""
    echo -e "🔧 ${YELLOW}Step 2:${NC} Update repository settings:"
    echo -e "      • Add or remove repositories as needed"
    echo ""
    echo -e "💾 ${YELLOW}Step 3:${NC} Save & exit the editor."
    echo ""
    echo -e "📦 ${YELLOW}Step 4:${NC} Save your configuration:"
    echo -e "      ${GREEN}bitoarch add-repos ${repo_config_file}${NC}"
    echo ""
    echo -e "🚀 ${YELLOW}Step 5:${NC} Start indexing whenever you're ready:"
    echo -e "      ${GREEN}bitoarch index-repos${NC}"
    echo ""
    echo -e "🙌 All set! Finish these steps & your environment will be ready."
}

# ============================================================================
# SETUP-SPECIFIC BLOCKS
# ============================================================================

render_security_notice_block() {
    # Source constants if not already loaded
    if [ -z "$BITO_API_KEY_URL" ]; then
        local SCRIPT_DIR="${SCRIPT_DIR:-$(cd "$(dirname "${BASH_SOURCE[0]}")" && cd ../.. && pwd)}"
        if [ -f "${SCRIPT_DIR}/scripts/lib/constants.sh" ]; then
            source "${SCRIPT_DIR}/scripts/lib/constants.sh"
        fi
    fi
    
    echo ""
    echo -e "${CYAN}${BOLD}📝 Notice : ${NC}"
    echo ""
    echo -e "${GREEN}🔐 Bito's AI Architect learns your codebase. This on-prem installation is totally secure:${NC}"
    echo ""
    echo -e "  ${GREEN}✓${NC} No data about your code will ever be sent to Bito"
    echo -e "  ${GREEN}✓${NC} Bito has no access to your code"
    echo ""
    echo -e "  ${BLUE}ℹ${NC} Bito does collect some minimal telemetry data about your usage, including:"
    echo "    - How many requests you make"
    echo "    - Which Bito Workspace you are connected to"
    echo ""
    echo -e "${YELLOW}⚠ Bito API Key is required to proceed${NC}"
    echo ""
    echo -e "Please get your key at ${BLUE}${BITO_API_KEY_URL:-https://alpha.bito.ai/home/advanced}${NC}"
    echo ""
}

render_git_integration_header_block() {
    # Source constants if not already loaded
    if [ -z "$GIT_TOKEN_DOCS_URL" ]; then
        local SCRIPT_DIR="${SCRIPT_DIR:-$(cd "$(dirname "${BASH_SOURCE[0]}")" && cd ../.. && pwd)}"
        if [ -f "${SCRIPT_DIR}/scripts/lib/constants.sh" ]; then
            source "${SCRIPT_DIR}/scripts/lib/constants.sh"
        fi
    fi
    
    echo -e "${BLUE}=== Git Integration ===${NC}"
    echo -e "${YELLOW}⚠ Git provider and access token are required to proceed${NC}"
    echo ""
    echo -e "See documentation: ${BLUE}${GIT_TOKEN_DOCS_URL:-https://docs.bito.ai/ai-architect/install-ai-architect-self-hosted#git-provider}${NC}"
    echo ""
}

# ============================================================================
# ERROR BLOCKS (GENERIC)
# ============================================================================

render_error_missing_dependency_block() {
    local tool_name="$1"
    local install_hint="$2"
    
    echo ""
    echo -e "${RED}❌ Missing Required Tool${NC}"
    echo ""
    echo -e "${YELLOW}⚠️ Required${NC}"
    echo -e "   ${BOLD}${tool_name}${NC} is required for this operation"
    echo ""
    echo -e "${BLUE}📦 Install${NC}"
    echo -e "   ${install_hint}"
    echo ""
}

render_error_env_var_missing_block() {
    local var_name="$1"
    local hint="$2"
    
    echo ""
    echo -e "${RED}❌ Missing Environment Variable${NC}"
    echo ""
    echo -e "${YELLOW}⚠️ Required${NC}"
    echo -e "   ${BOLD}${var_name}${NC} not found in environment"
    echo ""
    echo -e "${BLUE}🔧 Fix${NC}"
    echo -e "   ${hint}"
    echo ""
}

render_error_file_not_found_block() {
    local file_path="$1"
    local expected_location="$2"
    
    echo ""
    echo -e "${RED}❌ File Not Found${NC}"
    echo ""
    echo -e "${YELLOW}⚠️ Missing${NC}"
    echo -e "   ${file_path}"
    echo ""
    [ -n "$expected_location" ] && echo -e "${BLUE}📁 Expected Location${NC}"
    [ -n "$expected_location" ] && echo -e "   ${expected_location}"
    [ -n "$expected_location" ] && echo ""
}

# ============================================================================
# HELPER FUNCTIONS
# ============================================================================

# Silent logging (no output, just log file)
log_silent() {
    local message="$1"
    [ -n "${LOG_FILE:-}" ] && echo "[$(date +'%Y-%m-%d %H:%M:%S')] $message" >> "$LOG_FILE"
}

# Log-only banner for service lifecycle events (not shown to customer)
log_service_lifecycle_banner() {
    local operation="$1"  # "Starting", "Restarting", "Stopping"
    
    log_silent "========================================"
    log_silent "AI Architect Platform ${operation}"
    log_silent "========================================"
}

# ============================================================================
# INDEXING INFORMATION BLOCK
# ============================================================================

render_indexing_information_block() {
    echo ""
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo -e "${BLUE}${BOLD}📊 AI ARCHITECT: INDEXING INFORMATION${NC}"
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo ""
    echo "• 🧠 AI Architect uses LLMs to build a knowledge graph of your code."
    echo "• 🔒 Runs fully on-prem. Only basic telemetry is sent to Bito."
    echo "• 🛡️ Your code and artifacts never leave your environment."
    echo ""
    echo -e "${YELLOW}🔑 API key requirements:${NC}"
    echo "  • Anthropic API key is required."
    echo "  • Grok API key is optional — but Grok alone cannot be used."
    echo "  • Using both Anthropic + Grok gives best coverage and lowest cost."
    echo ""
    echo -e "${YELLOW}💰 Indexing cost estimates:${NC}"
    echo "  • Anthropic + Grok:             ~\$0.20 – \$0.40 per MB"
    echo "  • Anthropic only:               ~\$1.00 – \$1.50 per MB"
    echo "  (We index source code only; binaries/ZIPs/TARs/images are skipped.)"
    echo ""
    echo -e "${BLUE}❓ Questions or need an enterprise trial?${NC}"
    echo "📧 Email: support@bito.ai"
    echo ""
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo ""
}

# ============================================================================
# KUBERNETES DEPLOYMENT BLOCKS
# ============================================================================

render_k8s_deploy_success_block() {
    local mcp_token="$1"
    local mcp_url="$2"
    local namespace="$3"
    local setup_mode="${4:-manual}"
    
    echo ""
    echo -e "${GREEN}🎉 Bito AI Architect deployed to Kubernetes! 🎉${NC}"
    echo ""
    echo -e "${BLUE}🔑 MCP Server Configuration${NC}"
    echo ""
    echo -e "${YELLOW}⚠️ You will need this information to set up your MCP server in your coding agent${NC}"
    echo -e "${YELLOW}  (Claude, Cursor, Codex, Copilot, etc):${NC}"
    echo ""
    echo -e "  • Bito MCP URL:          ${CYAN}${mcp_url}${NC}"
    echo -e "  • Bito MCP Access Token: ${CYAN}${mcp_token}${NC}"
    echo ""
    echo -e "${BLUE}🔧 CLI Commands${NC}"
    echo ""
    echo -e "  • Activate CLI:       ${YELLOW}source ~/.${SHELL##*/}rc${NC} (or restart terminal)"
    echo -e "  • Check status:       ${YELLOW}bitoarch status${NC}"
    echo -e "  • View logs:          ${YELLOW}./setup.sh --logs${NC}"
    echo -e "  • View MCP tools:     ${YELLOW}bitoarch mcp-tools${NC}"
    echo ""
    
    if [[ "$setup_mode" == "manual" ]]; then
        local repo_config_file
        if type get_repo_config_file >/dev/null 2>&1; then
            repo_config_file="$(get_repo_config_file)"
        else
            repo_config_file=".bitoarch-config.yaml"
        fi
        
        echo -e "${BLUE}🚀 Next Steps${NC}"
        echo ""
        echo -e "  1. Add repositories:    ${YELLOW}bitoarch add-repos ${repo_config_file}${NC}"
        echo -e "  2. Start indexing:      ${YELLOW}bitoarch index-repos${NC}"
        echo -e "  3. Monitor progress:    ${YELLOW}bitoarch index-status${NC}"
        echo ""
    fi
    
    echo -e "${BLUE}☸️  Kubernetes Deployment${NC}"
    echo -e "  • Namespace: ${namespace}"
    echo -e "  • For advanced K8s operations, see: ${YELLOW}docs/KUBERNETES_SETUP.md${NC}"
    echo ""
}

render_k8s_deploy_failure_block() {
    local error_msg="$1"
    local log_file="${2:-}"
    
    echo ""
    echo -e "${RED}❌ Kubernetes Deployment Failed${NC}"
    echo ""
    echo -e "${YELLOW}⚠️ Issue${NC}"
    echo -e "   ${error_msg}"
    echo ""
    echo -e "${BLUE}🔍 Troubleshooting${NC}"
    echo -e "   • Check status: ${YELLOW}./setup.sh --status${NC}"
    echo -e "   • View logs: ${YELLOW}./setup.sh --logs${NC}"
    [ -n "$log_file" ] && echo -e "   • Setup log: ${YELLOW}cat ${log_file}${NC}"
    echo -e "   • Restart: ${YELLOW}./setup.sh --restart${NC}"
    echo ""
}

render_deployment_method_choice_block() {
    echo ""
    echo -e "${BLUE}=== Deployment Method Selection ===${NC}"
    echo ""
    echo "Choose your deployment platform:"
    echo ""
    echo "  1) Docker Compose (Recommended for single server)"
    echo "     • Quick setup (5-10 minutes)"
    echo "     • Requirements: Docker Desktop or Docker Engine"
    echo "     • Resource: 4GB RAM, 10GB disk"
    echo "     • Best for: Single server, development, small teams"
    echo ""
    echo "  2) Kubernetes (Recommended for enterprise/scale)"
    echo "     • High availability with auto-healing"
    echo "     • Requirements: kubectl, helm, running K8s cluster"
    echo "     • Resource: 8GB RAM, 20GB disk"
    echo "     • Best for: Multi-server, production, large deployments"
    echo ""
}

render_repo_reconfiguration_prompt_block() {
    local repo_count="$1"
    
    echo ""
    echo -e "${BLUE}=== Repository Configuration ===${NC}"
    msg_info "Found existing repository configuration with ${repo_count} repository(ies)"
    echo ""
    read -r -p "Do you want to reconfigure repositories? (y/N): " reconfigure
    
    # Return the user's choice via exit code
    if [[ "$reconfigure" =~ ^[Yy]$ ]]; then
        msg_info "Will fetch and reconfigure repository list..."
        return 0
    else
        echo ""
        msg_success "Repository configuration preserved"
        return 1
    fi
}

render_k8s_prerequisites_check_block() {
    local kubectl_version="$1"
    local helm_version="$2"
    local k8s_version="$3"
    
    echo ""
    echo -e "${BLUE}☸️  Kubernetes Prerequisites${NC}"
    echo ""
    echo -e "  ${GREEN}✓${NC} kubectl: ${kubectl_version}"
    echo -e "  ${GREEN}✓${NC} helm: ${helm_version}"
    echo -e "  ${GREEN}✓${NC} cluster: ${k8s_version}"
    echo ""
}

render_k8s_node_port_conflict_block() {
    local conflicting_ports="$1"
    
    echo ""
     echo -e "${RED}❌ Port Conflicts Detected${NC}"
    echo ""
    echo -e "${YELLOW}⚠️ Conflicting Ports${NC}"
    echo -e "   ${conflicting_ports}"
    echo ""
    echo -e "${YELLOW}To resolve:${NC}"
    echo -e "   Update ports in: ${YELLOW}.env-bitoarch.default${NC}"
    echo ""
}

render_k8s_not_available_block() {
    echo ""
    print_error "Cannot proceed with Kubernetes deployment"
    echo ""
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo ""
    echo "⚠️  Kubernetes Cluster Not Available"
    echo ""
    echo "The selected deployment requires a running Kubernetes cluster."
    echo ""
    echo "To validate your Kubernetes setup, run:"
    echo "  kubectl cluster-info"
    echo "  kubectl get nodes"
    echo ""
    echo "If you have a Kubernetes cluster:"
    echo "  • Ensure it's running"
    echo "  • Verify kubectl context: kubectl config current-context"
    echo "  • Check connectivity: kubectl cluster-info"
    echo ""
    echo "If you don't have a Kubernetes cluster:"
    echo "  • Run setup again and select Docker Compose (option 1)"
    echo "  • Command: ./setup.sh"
    echo ""
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo ""
}

# Export all functions
export -f msg_success
export -f msg_info
export -f msg_warn
export -f msg_error
export -f print_status
export -f print_info
export -f print_warning
export -f print_error
export -f log_silent
export -f log_technical
export -f render_deploy_success_block
export -f render_deploy_failure_block
export -f render_config_get_summary_block
export -f render_config_get_raw_block
export -f render_config_get_success_block
export -f render_config_get_failure_block
export -f render_config_add_success_block
export -f render_config_add_failure_block
export -f render_namespace_added_block
export -f render_namespace_removed_block
export -f render_repo_add_success_block
export -f render_repo_add_failure_block
export -f render_repo_remove_success_block
export -f render_repo_remove_failure_block
export -f render_sync_started_block
export -f render_sync_failure_block
export -f render_status_block
export -f render_platform_status_block
export -f render_mcp_tools_list_block
export -f render_mcp_test_success_block
export -f render_mcp_test_failure_block
export -f render_token_rotated_block
export -f render_mcp_config_block
export -f render_manual_repo_config_block
export -f render_repo_config_choice_block
export -f render_manual_config_instructions_block
export -f render_error_missing_dependency_block
export -f render_error_env_var_missing_block
export -f render_error_file_not_found_block
export -f render_k8s_deploy_success_block
export -f render_k8s_deploy_failure_block
export -f render_deployment_method_choice_block
export -f render_k8s_prerequisites_check_block
export -f render_k8s_node_port_conflict_block
export -f render_k8s_not_available_block
