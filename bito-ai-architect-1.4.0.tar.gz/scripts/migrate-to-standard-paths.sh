#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
#
# Migration Script - Migrate from installation directory to standard Unix paths
# Handles upgrade from legacy installations (v1.x, v2.0) to standard FHS layout
#
# Usage: ./scripts/migrate-to-standard-paths.sh [--auto|--dry-run]

set -e

# Get script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PLATFORM_DIR="$(dirname "$SCRIPT_DIR")"
LOG_FILE="${PLATFORM_DIR}/migrate.log"

# Source utilities
source "${SCRIPT_DIR}/setup-utils.sh"
source "${SCRIPT_DIR}/lib/path-manager.sh"

# Migration mode
DRY_RUN=false
AUTO_MODE=false

# Parse arguments
parse_args() {
    while [[ $# -gt 0 ]]; do
        case $1 in
            --dry-run)
                DRY_RUN=true
                shift
                ;;
            --auto)
                AUTO_MODE=true
                shift
                ;;
            --help|-h)
                show_usage
                exit 0
                ;;
            *)
                print_error "Unknown option: $1"
                show_usage
                exit 1
                ;;
        esac
    done
}

show_usage() {
    cat << EOF
Bito AI Architect - Migration to Standard Unix Paths

Usage: $0 [options]

Options:
  --auto       Run migration automatically (for upgrades)
  --dry-run    Show what would be migrated without making changes
  --help, -h   Show this help message

Description:
  Migrates existing installation from legacy paths to standard Unix locations:
  - Configs:  {install_dir}/ → /usr/local/etc/bitoarch/
  - Logs:     {install_dir}/var/logs/ → /usr/local/var/bitoarch/logs/
  - Binaries: {install_dir}/ → /usr/local/lib/bitoarch/versions/{version}/

EOF
}

# Detect if migration is needed
check_if_migration_needed() {
    # Already using standard layout?
    if is_standard_layout; then
        print_info "Already using standard Unix paths - no migration needed"
        return 1
    fi
    
    # Check if legacy files exist
    if [ ! -f "${PLATFORM_DIR}/.env-bitoarch" ]; then
        print_error "No legacy installation found at: $PLATFORM_DIR"
        return 1
    fi
    
    return 0
}

# Detect version from legacy installation
detect_version() {
    local install_dir="$1"
    local versions_file="${install_dir}/versions/service-versions.json"
    
    if [ -f "$versions_file" ] && command -v jq >/dev/null 2>&1; then
        local version=$(jq -r '.platform_info.version // "unknown"' "$versions_file" 2>/dev/null)
        if [ "$version" != "null" ] && [ "$version" != "unknown" ]; then
            echo "$version"
            return 0
        fi
    fi
    
    # Fallback: extract from directory name if it matches pattern
    local dir_name=$(basename "$install_dir")
    if [[ "$dir_name" =~ bito-ai-architect-([0-9]+\.[0-9]+\.[0-9]+) ]]; then
        echo "${BASH_REMATCH[1]}"
        return 0
    fi
    
    # Last resort: use timestamp
    echo "2.0.0-$(date +%Y%m%d)"
}

# Check permissions and determine target layout
determine_target_layout() {
    if can_use_system_wide; then
        echo "system"
        return 0
    else
        print_warning "Cannot use system-wide installation (sudo not available or denied)"
        print_info "Will use user-local installation instead"
        echo "user"
        return 0
    fi
}

# Pre-migration validation
validate_source() {
    local legacy_dir="$1"
    local errors=0
    
    print_info "Validating source installation..."
    
    # Check critical files
    local required_files=(
        ".env-bitoarch"
        "setup.sh"
        "docker-compose.yml"
        "scripts/bitoarch.sh"
    )
    
    for file in "${required_files[@]}"; do
        if [ ! -f "${legacy_dir}/${file}" ]; then
            print_error "Missing required file: $file"
            errors=$((errors + 1))
        fi
    done
    
    # Check if services are running
    if docker ps --filter "name=ai-architect" --format "{{.Names}}" 2>/dev/null | grep -q "ai-architect"; then
        print_warning "Services are currently running"
        print_info "Migration can proceed - services will continue running"
    fi
    
    if [ $errors -gt 0 ]; then
        print_error "Validation failed with $errors error(s)"
        return 1
    fi
    
    print_status "Source validation passed"
    return 0
}

# Create target directories
create_target_dirs() {
    local target_layout="$1"
    
    if [ "$DRY_RUN" = true ]; then
        print_info "[DRY-RUN] Would create directories for '$target_layout' layout"
        return 0
    fi
    
    print_info "Creating standard directories..."
    log_silent "Creating target directories for layout: $target_layout"
    
    case "$target_layout" in
        system)
            sudo mkdir -p /usr/local/etc/bitoarch/templates
            sudo mkdir -p /usr/local/var/bitoarch/logs
            sudo mkdir -p /usr/local/lib/bitoarch/versions
            
            # Set ownership
            sudo chown -R "$USER:$(id -gn)" /usr/local/etc/bitoarch
            sudo chown -R "$USER:$(id -gn)" /usr/local/var/bitoarch
            
            log_silent "Created system-wide directories in /usr/local/"
            print_status "Created system-wide directories in /usr/local/"
            ;;
        user)
            mkdir -p "$HOME/.local/bitoarch/etc/templates"
            mkdir -p "$HOME/.local/bitoarch/var/logs"
            mkdir -p "$HOME/.local/bitoarch/lib/versions"
            
            log_silent "Created user-local directories in ~/.local/bitoarch/"
            print_status "Created user-local directories in ~/.local/bitoarch/"
            ;;
    esac
    
    # Create service-specific log directories
    local log_dir=""
    if [ "$target_layout" = "system" ]; then
        log_dir="/usr/local/var/bitoarch/logs"
    else
        log_dir="$HOME/.local/bitoarch/var/logs"
    fi
    
    local services=("cis-config" "cis-manager" "cis-provider" "mysql" "cis-tracker")
    for service in "${services[@]}"; do
        mkdir -p "${log_dir}/${service}"
    done
    
    log_silent "Created service-specific log directories"
}

# Migrate configuration files
migrate_configs() {
    local source_dir="$1"
    local target_layout="$2"
    
    local target_config_dir=""
    if [ "$target_layout" = "system" ]; then
        target_config_dir="/usr/local/etc/bitoarch"
    else
        target_config_dir="$HOME/.local/bitoarch/etc"
    fi
    
    print_info "Migrating configuration files..."
    
    local config_files=(
        ".env-bitoarch"
        ".env-llm-bitoarch"
        ".bitoarch-config.yaml"
        ".deployment-type"
    )
    
    local migrated_count=0
    for file in "${config_files[@]}"; do
        if [ -f "${source_dir}/${file}" ]; then
            if [ "$DRY_RUN" = true ]; then
                print_info "[DRY-RUN] Would copy: $file → $target_config_dir/"
                log_silent "[DRY-RUN] Would copy: $file"
            else
                cp "${source_dir}/${file}" "${target_config_dir}/"
                log_silent "Migrated: $file"
                migrated_count=$((migrated_count + 1))
            fi
        fi
    done
    
    # Copy default templates
    if [ "$DRY_RUN" = false ]; then
        [ -f "${source_dir}/.env-bitoarch.default" ] && cp "${source_dir}/.env-bitoarch.default" "${target_config_dir}/templates/" 2>/dev/null || true
        [ -f "${source_dir}/.bitoarch-config.default.yaml" ] && cp "${source_dir}/.bitoarch-config.default.yaml" "${target_config_dir}/templates/" 2>/dev/null || true
    fi
    
    if [ "$DRY_RUN" = false ]; then
        print_status "Migrated $migrated_count configuration file(s)"
    fi
}

# Migrate logs
migrate_logs() {
    local source_dir="$1"
    local target_layout="$2"
    
    local target_log_dir=""
    if [ "$target_layout" = "system" ]; then
        target_log_dir="/usr/local/var/bitoarch/logs"
    else
        target_log_dir="$HOME/.local/bitoarch/var/logs"
    fi
    
    print_info "Migrating log files..."
    
    if [ -d "${source_dir}/var/logs" ]; then
        if [ "$DRY_RUN" = true ]; then
            print_info "[DRY-RUN] Would copy logs: ${source_dir}/var/logs/ → $target_log_dir/"
        else
            cp -r "${source_dir}/var/logs/"* "${target_log_dir}/" 2>/dev/null || true
            log_silent "Migrated logs from ${source_dir}/var/logs/"
            print_status "Migrated logs"
        fi
    fi
    
    # Copy setup.log if it exists
    if [ "$DRY_RUN" = false ] && [ -f "${source_dir}/setup.log" ]; then
        cp "${source_dir}/setup.log" "${target_log_dir}/"
        log_silent "Migrated setup.log"
    fi
}

# Migrate binaries
migrate_binaries() {
    local source_dir="$1"
    local version="$2"
    local target_layout="$3"
    
    local target_lib_dir=""
    if [ "$target_layout" = "system" ]; then
        target_lib_dir="/usr/local/lib/bitoarch"
    else
        target_lib_dir="$HOME/.local/bitoarch/lib"
    fi
    
    local version_dir="${target_lib_dir}/versions/${version}"
    
    print_info "Migrating binaries to: $version_dir"
    log_silent "Target version directory: $version_dir"
    
    if [ "$DRY_RUN" = true ]; then
        print_info "[DRY-RUN] Would copy installation to: $version_dir"
        print_info "[DRY-RUN] Would create symlink: ${target_lib_dir}/current → versions/${version}"
    else
        # Copy entire installation directory
        if [ "$target_layout" = "system" ]; then
            sudo mkdir -p "$version_dir"
            sudo cp -r "$source_dir"/* "$version_dir/"
            sudo chown -R "$USER:$(id -gn)" "$version_dir"
        else
            mkdir -p "$version_dir"
            cp -r "$source_dir"/* "$version_dir/"
        fi
        
        # Create 'current' symlink
        if [ "$target_layout" = "system" ]; then
            sudo ln -sfn "versions/${version}" "${target_lib_dir}/current"
        else
            ln -sfn "versions/${version}" "${target_lib_dir}/current"
        fi
        
        log_silent "Migrated binaries for version $version"
        print_status "Migrated binaries for version $version"
    fi
}

# Update CLI symlink
update_cli_symlink() {
    local target_layout="$1"
    
    local target_lib_dir=""
    if [ "$target_layout" = "system" ]; then
        target_lib_dir="/usr/local/lib/bitoarch"
    else
        target_lib_dir="$HOME/.local/bitoarch/lib"
    fi
    
    local cli_target="$HOME/.local/bin/bitoarch"
    local cli_source="${target_lib_dir}/current/scripts/bitoarch.sh"
    
    print_info "Updating CLI symlink..."
    
    if [ "$DRY_RUN" = true ]; then
        print_info "[DRY-RUN] Would create symlink: $cli_target → $cli_source"
    else
        mkdir -p "$HOME/.local/bin"
        ln -sf "$cli_source" "$cli_target"
        log_silent "Updated CLI symlink: $cli_target → $cli_source"
        print_status "Updated CLI symlink"
    fi
}

# Update docker-compose env variable
update_docker_compose_env() {
    local target_layout="$1"
    
    local config_file=""
    if [ "$target_layout" = "system" ]; then
        config_file="/usr/local/etc/bitoarch/.env-bitoarch"
    else
        config_file="$HOME/.local/bitoarch/etc/.env-bitoarch"
    fi
    
    local log_dir=""
    if [ "$target_layout" = "system" ]; then
        log_dir="/usr/local/var/bitoarch/logs"
    else
        log_dir="$HOME/.local/bitoarch/var/logs"
    fi
    
    print_info "Updating docker-compose log path..."
    
    if [ "$DRY_RUN" = true ]; then
        print_info "[DRY-RUN] Would add HOST_LOG_DIR=$log_dir to $config_file"
    else
        # Add HOST_LOG_DIR if not already present
        if ! grep -q "^HOST_LOG_DIR=" "$config_file" 2>/dev/null; then
            echo "" >> "$config_file"
            echo "# Host log directory (for docker-compose volume mounts)" >> "$config_file"
            echo "HOST_LOG_DIR=$log_dir" >> "$config_file"
            log_silent "Added HOST_LOG_DIR to config"
            print_status "Added HOST_LOG_DIR to config"
        else
            # Update existing value
            if [[ "$OSTYPE" == "darwin"* ]]; then
                sed -i '' "s|^HOST_LOG_DIR=.*|HOST_LOG_DIR=$log_dir|" "$config_file"
            else
                sed -i "s|^HOST_LOG_DIR=.*|HOST_LOG_DIR=$log_dir|" "$config_file"
            fi
            log_silent "Updated HOST_LOG_DIR in config"
            print_status "Updated HOST_LOG_DIR in config"
        fi
    fi
}

# Post-migration validation
validate_migration() {
    local target_layout="$1"
    
    print_info "Validating migration..."
    
    # Reinitialize paths with new layout
    init_paths
    
    local errors=0
    
    # Check config file exists
    if [ ! -f "$(get_config_file)" ]; then
        print_error "Config file not found: $(get_config_file)"
        errors=$((errors + 1))
    else
        log_silent "Validated config file: $(get_config_file)"
    fi
    
    # Check log directory exists
    if [ ! -d "$(get_log_dir)" ]; then
        print_error "Log directory not found: $(get_log_dir)"
        errors=$((errors + 1))
    else
        log_silent "Validated log directory: $(get_log_dir)"
    fi
    
    # Check binaries exist
    if [ ! -d "$(get_lib_dir)/current" ]; then
        print_error "Binary directory not found: $(get_lib_dir)/current"
        errors=$((errors + 1))
    else
        log_silent "Validated binaries: $(get_lib_dir)/current"
    fi
    
    # Check CLI symlink
    if [ -L "$HOME/.local/bin/bitoarch" ]; then
        log_silent "Validated CLI: $HOME/.local/bin/bitoarch"
    else
        print_warning "CLI symlink not found (this is okay if not previously installed)"
    fi
    
    if [ $errors -gt 0 ]; then
        print_error "Validation failed with $errors error(s)"
        return 1
    fi
    
    print_status "Validation passed"
    return 0
}

# Print success summary
print_success_summary() {
    local source_dir="$1"
    local target_layout="$2"
    
    echo ""
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo -e "${GREEN}✓ Migration Complete${NC}"
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo ""
    print_info "New Locations:"
    echo "  Config:   $(get_config_dir)"
    echo "  Logs:     $(get_log_dir)"
    echo "  Binaries: $(get_lib_dir)/current"
    echo ""
    print_info "Old Installation: $source_dir"
    print_info "Status: Preserved (you can remove manually after verification)"
    echo ""
    print_info "Cleanup (optional after verification):"
    echo "  rm -rf $source_dir"
    echo ""
}

# Main migration function
migrate() {
    log "Migration started at $(date)"
    
    # Check if migration is needed
    if ! check_if_migration_needed; then
        return 0
    fi
    
    # Validate source
    if ! validate_source "$PLATFORM_DIR"; then
        print_error "Source validation failed"
        exit 1
    fi
    
    # Detect version
    local version=$(detect_version "$PLATFORM_DIR")
    print_info "Detected version: $version"
    log_silent "Detected version: $version"
    
    # Determine target layout
    local target_layout=$(determine_target_layout)
    print_info "Target layout: $target_layout"
    log_silent "Target layout: $target_layout"
    
    # Show informational message about migration (no confirmation needed)
    if [ "$DRY_RUN" = false ]; then
        echo ""
        print_info "Migrating configuration files to standard Unix paths..."
        if [ "$target_layout" = "system" ]; then
            echo "  Config files → /usr/local/etc/bitoarch/"
            echo "  Log files    → /usr/local/var/bitoarch/logs/"
            echo "  Binaries     → /usr/local/lib/bitoarch/"
        else
            echo "  Config files → ~/.local/bitoarch/etc/"
            echo "  Log files    → ~/.local/bitoarch/var/logs/"
            echo "  Binaries     → ~/.local/bitoarch/lib/"
        fi
        echo ""
    fi
    
    # Perform migration steps
    create_target_dirs "$target_layout"
    migrate_configs "$PLATFORM_DIR" "$target_layout"
    migrate_logs "$PLATFORM_DIR" "$target_layout"
    migrate_binaries "$PLATFORM_DIR" "$version" "$target_layout"
    update_cli_symlink "$target_layout"
    update_docker_compose_env "$target_layout"
    
    # Validate
    if [ "$DRY_RUN" = false ]; then
        if ! validate_migration "$target_layout"; then
            print_error "Migration validation failed"
            exit 1
        fi
        
        print_success_summary "$PLATFORM_DIR" "$target_layout"
        log "Migration completed successfully at $(date)"
    else
        echo ""
        print_info "[DRY-RUN] Migration plan complete - no changes made"
    fi
}

# Main execution
main() {
    parse_args "$@"
    migrate
}

main "$@"
