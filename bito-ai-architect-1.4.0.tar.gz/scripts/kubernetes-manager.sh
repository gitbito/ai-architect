#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# Kubernetes Manager - Helper functions for K8s operations
# Used by setup.sh and upgrade.sh for Kubernetes deployments

# Detect OS
detect_os() {
    if [[ "$OSTYPE" == "darwin"* ]]; then
        echo "macos"
    elif [[ -f /etc/os-release ]]; then
        . /etc/os-release
        if [[ "$ID" == "ubuntu" ]]; then
            echo "ubuntu-$VERSION_ID"
        else
            echo "linux"
        fi
    else
        echo "unknown"
    fi
}

# Install kubectl on macOS
install_kubectl_macos() {
    print_info "Installing kubectl on macOS..."
    
    if command -v brew >/dev/null 2>&1; then
        if brew install kubectl >> "$LOG_FILE" 2>&1; then
            print_status "kubectl installed via Homebrew"
            return 0
        fi
    else
        # Fallback: direct download
        print_info "Homebrew not found, installing kubectl directly..."
        local kubectl_bin="/usr/local/bin/kubectl"
        
        if curl -LO "https://dl.k8s.io/release/$(curl -L -s https://dl.k8s.io/release/stable.txt)/bin/darwin/amd64/kubectl" >> "$LOG_FILE" 2>&1; then
            chmod +x kubectl
            sudo mv kubectl "$kubectl_bin" 2>/dev/null || mv kubectl "$HOME/.local/bin/kubectl"
            print_status "kubectl installed to $kubectl_bin"
            return 0
        fi
    fi
    
    return 1
}

# Install kubectl on Ubuntu
install_kubectl_ubuntu() {
    print_info "Installing kubectl on Ubuntu..."
    
    # Add Kubernetes apt repository
    if ! curl -fsSL https://pkgs.k8s.io/core:/stable:/v1.28/deb/Release.key | sudo gpg --dearmor -o /etc/apt/keyrings/kubernetes-apt-keyring.gpg >> "$LOG_FILE" 2>&1; then
        print_error "Failed to add Kubernetes GPG key"
        return 1
    fi
    
    echo 'deb [signed-by=/etc/apt/keyrings/kubernetes-apt-keyring.gpg] https://pkgs.k8s.io/core:/stable:/v1.28/deb/ /' | \
        sudo tee /etc/apt/sources.list.d/kubernetes.list >> "$LOG_FILE" 2>&1
    
    if sudo apt-get update >> "$LOG_FILE" 2>&1 && sudo apt-get install -y kubectl >> "$LOG_FILE" 2>&1; then
        print_status "kubectl installed via apt"
        return 0
    fi
    
    return 1
}

# Install helm on macOS
install_helm_macos() {
    print_info "Installing helm on macOS..."
    
    if command -v brew >/dev/null 2>&1; then
        if brew install helm >> "$LOG_FILE" 2>&1; then
            print_status "helm installed via Homebrew"
            return 0
        fi
    else
        # Fallback: direct download
        print_info "Homebrew not found, installing helm directly..."
        if curl -fsSL https://raw.githubusercontent.com/helm/helm/main/scripts/get-helm-3 | bash >> "$LOG_FILE" 2>&1; then
            print_status "helm installed"
            return 0
        fi
    fi
    
    return 1
}

# Install helm on Ubuntu
install_helm_ubuntu() {
    print_info "Installing helm on Ubuntu..."
    
    # Use official installation script
    if curl -fsSL https://raw.githubusercontent.com/helm/helm/main/scripts/get-helm-3 | bash >> "$LOG_FILE" 2>&1; then
        print_status "helm installed"
        return 0
    fi
    
    return 1
}

# Auto-install missing tools
auto_install_k8s_tools() {
    local os=$(detect_os)
    local tools_installed=0
    
    print_info "Detected OS: $os"
    
    # Check and install kubectl
    if ! command -v kubectl >/dev/null 2>&1; then
        echo ""
        print_warning "kubectl is not installed"
        read -p "Would you like to install kubectl automatically? (y/N): " -r install_kubectl
        
        if [[ "$install_kubectl" =~ ^[Yy]$ ]]; then
            case "$os" in
                macos)
                    if install_kubectl_macos; then
                        tools_installed=$((tools_installed + 1))
                    else
                        print_error "Failed to install kubectl"
                        print_info "Manual installation: https://kubernetes.io/docs/tasks/tools/install-kubectl-macos/"
                        return 1
                    fi
                    ;;
                ubuntu-*)
                    if install_kubectl_ubuntu; then
                        tools_installed=$((tools_installed + 1))
                    else
                        print_error "Failed to install kubectl"
                        print_info "Manual installation: https://kubernetes.io/docs/tasks/tools/install-kubectl-linux/"
                        return 1
                    fi
                    ;;
                *)
                    print_error "Unsupported OS for auto-installation: $os"
                    print_info "Manual installation: https://kubernetes.io/docs/tasks/tools/"
                    return 1
                    ;;
            esac
        else
            print_info "Skipping kubectl installation"
            print_info "Install manually: https://kubernetes.io/docs/tasks/tools/"
            return 1
        fi
    else
        print_status "kubectl is already installed"
    fi
    
    # Check and install helm
    if ! command -v helm >/dev/null 2>&1; then
        echo ""
        print_warning "helm is not installed"
        read -p "Would you like to install helm automatically? (y/N): " -r install_helm
        
        if [[ "$install_helm" =~ ^[Yy]$ ]]; then
            case "$os" in
                macos)
                    if install_helm_macos; then
                        tools_installed=$((tools_installed + 1))
                    else
                        print_error "Failed to install helm"
                        print_info "Manual installation: https://helm.sh/docs/intro/install/"
                        return 1
                    fi
                    ;;
                ubuntu-*)
                    if install_helm_ubuntu; then
                        tools_installed=$((tools_installed + 1))
                    else
                        print_error "Failed to install helm"
                        print_info "Manual installation: https://helm.sh/docs/intro/install/"
                        return 1
                    fi
                    ;;
                *)
                    print_error "Unsupported OS for auto-installation: $os"
                    print_info "Manual installation: https://helm.sh/docs/intro/install/"
                    return 1
                    ;;
            esac
        else
            print_info "Skipping helm installation"
            print_info "Install manually: https://helm.sh/docs/intro/install/"
            return 1
        fi
    else
        print_status "helm is already installed"
    fi
    
    if [ $tools_installed -gt 0 ]; then
        echo ""
        print_status "Installed $tools_installed tool(s) successfully"
        echo ""
    fi
    
    return 0
}

# Check Kubernetes prerequisites
check_k8s_prerequisites() {
    print_info "Checking Kubernetes prerequisites..."
    
    # Check if tools are installed
    local kubectl_installed=false
    local helm_installed=false
    
    command -v kubectl >/dev/null 2>&1 && kubectl_installed=true
    command -v helm >/dev/null 2>&1 && helm_installed=true
    
    # If tools are missing, offer to install
    if ! $kubectl_installed || ! $helm_installed; then
        print_warning "Some Kubernetes tools are missing"
        
        if ! auto_install_k8s_tools; then
            return 1
        fi
    fi
    
    # Verify installations
    if ! command -v kubectl >/dev/null 2>&1; then
        print_error "kubectl is still not available after installation attempt"
        return 1
    fi
    
    if ! command -v helm >/dev/null 2>&1; then
        print_error "helm is still not available after installation attempt"
        return 1
    fi
    
    # Modern kubectl version detection (v1.28+ compatible, macOS & Linux)
    local kubectl_version=""
    if command -v kubectl >/dev/null 2>&1; then
        # Try JSON output first (most reliable)
        kubectl_version=$(kubectl version --client -o json 2>/dev/null | jq -r '.clientVersion.gitVersion' 2>/dev/null || echo "")
        
        # Fallback: parse text output without deprecated --short flag
        if [[ -z "$kubectl_version" ]]; then
            kubectl_version=$(kubectl version --client 2>/dev/null | grep -oE 'v[0-9]+\.[0-9]+\.[0-9]+' | head -1 || echo "")
        fi
        
        # Only log if successfully detected (no error log if detection fails)
        if [[ -n "$kubectl_version" ]]; then
            print_status "kubectl version: $kubectl_version"
        fi
    fi
    
    # Helm version detection (already uses modern syntax)
    local helm_version=""
    if command -v helm >/dev/null 2>&1; then
        helm_version=$(helm version --short 2>/dev/null || echo "")
        if [[ -n "$helm_version" ]]; then
            print_status "helm version: $helm_version"
        fi
    fi
    
    # Check cluster connectivity
    if ! kubectl cluster-info >/dev/null 2>&1; then
        print_error "Cannot connect to Kubernetes cluster"
        echo ""
        echo "Please ensure:"
        echo "  1. Kubernetes cluster is running"
        echo "  2. kubectl is configured correctly"
        echo "  3. Current context is set: kubectl config current-context"
        echo ""
        return 1
    fi
    
    local current_context=$(kubectl config current-context 2>/dev/null || echo "unknown")
    print_status "Connected to cluster: $current_context"
    
    # Check if user has permissions
    if ! kubectl auth can-i create namespaces >/dev/null 2>&1; then
        print_warning "Limited cluster permissions detected"
        print_info "You may need admin rights to create namespaces and resources"
    fi
    
    return 0
}

# Check NodePort availability
check_nodeport_availability() {
    local port=$1
    local service_name=$2
    
    # Get all NodePort services across all namespaces
    local existing=$(kubectl get svc --all-namespaces -o json 2>/dev/null | \
        jq -r '.items[] | select(.spec.type=="NodePort") | .spec.ports[] | .nodePort' 2>/dev/null | \
        grep "^${port}$" || echo "")
    
    if [ -n "$existing" ]; then
        return 1  # Port in use
    fi
    return 0  # Port available
}

# Get cluster storage classes
get_storage_classes() {
    kubectl get storageclass -o jsonpath='{.items[*].metadata.name}' 2>/dev/null || echo ""
}

# Get default storage class
get_default_storage_class() {
    kubectl get storageclass -o json 2>/dev/null | \
        jq -r '.items[] | select(.metadata.annotations["storageclass.kubernetes.io/is-default-class"]=="true") | .metadata.name' 2>/dev/null | \
        head -1 || echo ""
}

# Monitor deployment progress with service-by-service spinners
monitor_deployment_progress() {
    local namespace="$1"
    local timeout="${2:-900}"  # 15 minutes default
    
    local start_time=$(date +%s)
    local services=("mysql" "config" "manager" "provider" "tracker")
    local first_display=true
    local last_status_line=""
    
    echo ""
    
    while true; do
        local current_time=$(date +%s)
        local elapsed=$((current_time - start_time))
        
        if [ $elapsed -gt $timeout ]; then
            echo ""
            print_error "Deployment timeout after ${timeout}s"
            return 1
        fi
        
        # Get current status for all services
        local all_ready=true
        local current_status_line=""
        
        for service in "${services[@]}"; do
            local pod=$(kubectl get pods -n "$namespace" -l "app.kubernetes.io/component=$service" \
                -o jsonpath='{.items[0].metadata.name}' 2>/dev/null || echo "")
            
            local status="pending"
            if [ -n "$pod" ]; then
                local phase=$(kubectl get pod "$pod" -n "$namespace" \
                    -o jsonpath='{.status.phase}' 2>/dev/null || echo "")
                local ready=$(kubectl get pod "$pod" -n "$namespace" \
                    -o jsonpath='{.status.conditions[?(@.type=="Ready")].status}' 2>/dev/null || echo "False")
                
                if [ "$phase" = "Running" ] && [ "$ready" = "True" ]; then
                    status="ready"
                elif [ "$phase" = "Running" ] || [ -n "$phase" ]; then
                    status="starting"
                fi
            fi
            
            current_status_line="${current_status_line}${service}:${status},"
            
            if [ "$status" != "ready" ]; then
                all_ready=false
            fi
        done
        
        # Display current status only if changed
        if [ "$first_display" = true ] || [ "$current_status_line" != "$last_status_line" ]; then
            # Clear previous lines if not first display
            if [ "$first_display" = false ]; then
                for service in "${services[@]}"; do
                    printf "\033[1A\033[2K"
                done
            fi
            
            # Print current status for all services
            for service in "${services[@]}"; do
                local display_name=$(echo "$service" | awk '{print toupper(substr($0,1,1)) tolower(substr($0,2))}')
                
                # Extract status for this service from current_status_line
                local status=$(echo "$current_status_line" | grep -o "${service}:[^,]*" | cut -d: -f2)
                
                case "$status" in
                    ready)
                        printf "   %-15s ${GREEN}✅ Ready${NC}\n" "$display_name"
                        ;;
                    starting)
                        printf "   %-15s ${YELLOW}⏳ Starting...${NC}\n" "$display_name"
                        ;;
                    *)
                        printf "   %-15s ${YELLOW}📦 Pending${NC}\n" "$display_name"
                        ;;
                esac
            done
            
            first_display=false
            last_status_line="$current_status_line"
        fi
        
        # Check if all are ready
        if [ "$all_ready" = true ]; then
            echo ""
            return 0
        fi
        
        sleep 3
    done
}

# Deploy via Helm
deploy_helm_chart() {
    local chart_dir="$1"
    local values_file="$2"
    local namespace="$3"
    local release_name="${4:-bitoarch}"
    
    # Input validation
    if [[ -z "$chart_dir" ]] || [[ -z "$values_file" ]] || [[ -z "$namespace" ]]; then
        print_error "Missing required parameters for helm deployment"
        print_info "Usage: deploy_helm_chart <chart_dir> <values_file> <namespace> [release_name]"
        return 1
    fi
    
    if [[ ! -d "$chart_dir" ]]; then
        print_error "Chart directory not found: $chart_dir"
        return 1
    fi
    
    if [[ ! -f "$values_file" ]]; then
        print_error "Values file not found: $values_file"
        return 1
    fi
    
    print_info "Deploying helm chart..."
    
    
    # Deploy/upgrade with Helm (without --wait, we'll monitor manually)
    print_info "Running: helm upgrade --install $release_name $chart_dir"
    print_info "This may take 3-5 minutes (provisioning volumes, pulling images, starting pods)..."
    
    # Start helm in background
    helm upgrade --install "$release_name" "$chart_dir" \
        --namespace "$namespace" \
        --create-namespace \
        --values "$values_file" \
        --timeout 10m \
        >> "$LOG_FILE" 2>&1 &
    
    local helm_pid=$!
    
    # Monitor progress while helm is running
    monitor_deployment_progress "$namespace" 900
    local monitor_result=$?
    
    # Wait for helm to finish
    wait $helm_pid
    local helm_result=$?
    
    echo ""
    
    if [ $helm_result -eq 0 ] && [ $monitor_result -eq 0 ]; then
        print_status "Helm deployment successful"
        return 0
    else
        print_error "Helm deployment failed"
        print_info "Check logs: $LOG_FILE"
        return 1
    fi
}

# Wait for K8s pods to be ready
wait_for_k8s_services() {
    local namespace="$1"
    local timeout="${2:-300}"  # 5 minutes default
    
    print_info "Waiting for pods to be ready (timeout: ${timeout}s)..."
    
    local start_time=$(date +%s)
    local services=("mysql" "config" "manager" "provider" "tracker")
    
    while true; do
        local current_time=$(date +%s)
        local elapsed=$((current_time - start_time))
        
        if [ $elapsed -gt $timeout ]; then
            print_error "Timeout waiting for services to be ready"
            return 1
        fi
        
        local all_ready=true
        for service in "${services[@]}"; do
            local pod=$(kubectl get pods -n "$namespace" -l "app.kubernetes.io/component=$service" \
                -o jsonpath='{.items[0].metadata.name}' 2>/dev/null || echo "")
            
            if [ -z "$pod" ]; then
                all_ready=false
                break
            fi
            
            local ready=$(kubectl get pod "$pod" -n "$namespace" \
                -o jsonpath='{.status.conditions[?(@.type=="Ready")].status}' 2>/dev/null || echo "False")
            
            if [ "$ready" != "True" ]; then
                all_ready=false
                break
            fi
        done
        
        if [ "$all_ready" = true ]; then
            print_status "All pods are ready"
            return 0
        fi
        
        printf "."
        sleep 5
    done
}

# Get K8s service status
get_k8s_service_status() {
    local namespace="$1"
    
    echo ""
    echo -e "${BLUE}📊 Service Health & Status${NC}"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    
    # Get pods
    local pods=$(kubectl get pods -n "$namespace" -o json 2>/dev/null)
    
    if [ -z "$pods" ] || [ "$pods" = "null" ]; then
        echo "  No pods found in namespace: $namespace"
        return 1
    fi
    
    # Parse and display pod status with uptime - process each pod once
    echo "$pods" | jq -r '.items[] | 
        "\(.metadata.labels."app.kubernetes.io/component" // "unknown")|\(.status.phase)|\([.status.conditions[]? | select(.type=="Ready")] | if length > 0 then .[0].status else "Unknown" end)|\(.status.startTime // "")"' | \
    while IFS='|' read -r component phase ready start_time; do
        local display_name=$(echo "$component" | awk '{print toupper(substr($0,1,1)) tolower(substr($0,2))}')
        
        # Calculate uptime if pod is running
        local uptime_str=""
        if [ "$phase" = "Running" ] && [ -n "$start_time" ]; then
            local start_epoch=""
            local clean_time=$(echo "$start_time" | sed 's/\.[0-9]*Z$/Z/')
            
            if [[ "$OSTYPE" == "darwin"* ]]; then
                local time_no_z=$(echo "$clean_time" | sed 's/Z$//')
                start_epoch=$(date -u -j -f "%Y-%m-%dT%H:%M:%S" "$time_no_z" "+%s" 2>/dev/null || echo "")
            else
                start_epoch=$(date -d "$clean_time" "+%s" 2>/dev/null || echo "")
            fi
            
            if [ -n "$start_epoch" ] && [ "$start_epoch" -gt 0 ]; then
                local now=$(date +%s)
                local running_time=$((now - start_epoch))
                
                if [ "$running_time" -lt 60 ]; then
                    uptime_str="up ${running_time}s"
                elif [ "$running_time" -lt 3600 ]; then
                    uptime_str="up $((running_time / 60))m"
                else
                    uptime_str="up $((running_time / 3600))h"
                fi
            fi
        fi
        
        if [ "$phase" = "Running" ] && [ "$ready" = "True" ]; then
            printf "   %-25s ${GREEN}✅ Running${NC}      (${uptime_str})\n" "$display_name"
        elif [ "$phase" = "Running" ] && [ "$ready" = "False" ]; then
            printf "   %-25s ${YELLOW}⏳ Starting${NC}     (${uptime_str})\n" "$display_name"
        elif [ "$phase" = "Pending" ]; then
            printf "   %-25s ${YELLOW}📦 Pending${NC}\n" "$display_name"
        else
            printf "   %-25s ${RED}⚠️  $phase${NC}\n" "$display_name"
        fi
    done
    
    echo ""
    echo "View logs:"
    echo "  ./setup.sh --logs"
    echo ""
}

# Get K8s service endpoints
get_k8s_endpoints() {
    local namespace="$1"
    
    echo -e "${BLUE}🔗 Service Endpoints${NC}"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    
    # Detect machine IP (works on Linux + macOS)
    local MACHINE_IP=""
    if command -v hostname >/dev/null 2>&1; then
        MACHINE_IP=$(hostname -I 2>/dev/null | awk '{print $1}')
    fi
    if [ -z "$MACHINE_IP" ] && command -v ifconfig >/dev/null 2>&1; then
        # Fallback for macOS
        MACHINE_IP=$(ifconfig | grep "inet " | grep -v 127.0.0.1 | awk '{print $2}' | head -1)
    fi
    if [ -z "$MACHINE_IP" ]; then
        MACHINE_IP="<host-ip>"
    fi
    
    # Read external port configuration from .env-bitoarch
    if [ -f "${SCRIPT_DIR}/.env-bitoarch" ]; then
        source "${SCRIPT_DIR}/.env-bitoarch"
    fi
    
    # Use default ports if not set
    local PROVIDER_PORT=${CIS_PROVIDER_EXTERNAL_PORT:-5001}
    local MANAGER_PORT=${CIS_MANAGER_EXTERNAL_PORT:-5002}
    local CONFIG_PORT=${CIS_CONFIG_EXTERNAL_PORT:-5003}
    local MYSQL_PORT=${MYSQL_EXTERNAL_PORT:-5004}
    local TRACKER_PORT=${CIS_TRACKER_EXTERNAL_PORT:-5005}
    
    echo ""
    echo ""
    echo "  Network Access (from other machines):"
    echo "    Provider:  http://${MACHINE_IP}:${PROVIDER_PORT}"
    echo "    Manager:   http://${MACHINE_IP}:${MANAGER_PORT}"
    echo "    Config:    http://${MACHINE_IP}:${CONFIG_PORT}"
    echo "    MySQL:     ${MACHINE_IP}:${MYSQL_PORT}"
    echo "    Tracker:   http://${MACHINE_IP}:${TRACKER_PORT}"
    echo ""
    echo -e "  ${YELLOW}⚠️  Security Note:${NC}"
    echo -e "  ${YELLOW}   • Port-forwards exposed on all network interfaces (0.0.0.0)${NC}"
    echo -e "  ${YELLOW}   • Accessible from any machine on your network${NC}"
    echo -e "  ${YELLOW}   • Use firewall rules to restrict access to trusted IPs${NC}"
    echo ""
}

# Check if a port-forward is healthy (not just existing)
check_port_forward_health() {
    local port="$1"
    local max_wait=3
    local count=0
    
    # Use same logic as http-client.sh's port_forward_active
    while [ $count -lt $max_wait ]; do
        if command -v lsof >/dev/null 2>&1; then
            if lsof -i :"$port" -sTCP:LISTEN >/dev/null 2>&1; then
                return 0
            fi
        elif command -v nc >/dev/null 2>&1; then
            if nc -z localhost "$port" >/dev/null 2>&1; then
                return 0
            fi
        else
            # Last resort: try curl
            if curl -s --connect-timeout 1 "http://localhost:$port" >/dev/null 2>&1; then
                return 0
            fi
        fi
        sleep 0.5
        count=$((count + 1))
    done
    
    return 1
}

# Setup port-forwards for all services (runs in background)
setup_port_forwards() {
    local namespace="$1"
    
    # Read external port configuration from .env-bitoarch (use config ports only)
    local provider_external_port="${CIS_PROVIDER_EXTERNAL_PORT:-5001}"
    local manager_external_port="${CIS_MANAGER_EXTERNAL_PORT:-5002}"
    local config_external_port="${CIS_CONFIG_EXTERNAL_PORT:-5003}"
    local mysql_external_port="${MYSQL_EXTERNAL_PORT:-5004}"
    local tracker_external_port="${CIS_TRACKER_EXTERNAL_PORT:-5005}"
    
    local ports=("$provider_external_port" "$manager_external_port" "$config_external_port" "$mysql_external_port" "$tracker_external_port")
    
    # ALWAYS clean up existing port-forwards for this namespace before creating new ones
    # This prevents port conflicts and ensures fresh connections
    print_info "Cleaning up any existing port-forwards for namespace: $namespace"
    kill_port_forwards "$namespace"
    sleep 2
    
    # Verify ports are actually free before proceeding
    local ports_in_use=()
    for port in "${ports[@]}"; do
        if lsof -i ":$port" >/dev/null 2>&1; then
            ports_in_use+=("$port")
        fi
    done
    
    if [ ${#ports_in_use[@]} -gt 0 ]; then
        print_warning "Ports still in use after cleanup: ${ports_in_use[*]}"
        print_warning "These may be from non-kubectl processes (e.g., SSH tunnels)"
        print_info "Attempting to continue anyway..."
    fi
    
    # Ensure pods are ready before setting up port-forwards
    print_info "Verifying pods are ready before establishing port-forwards..."
    local pods_ready=false
    local max_wait=60
    local waited=0
    
    while [ $waited -lt $max_wait ]; do
        local ready_pods=$(kubectl get pods -n "$namespace" -l "app.kubernetes.io/name=bitoarch" -o jsonpath='{.items[?(@.status.conditions[?(@.type=="Ready")].status=="True")].metadata.name}' 2>/dev/null | wc -w | xargs)
        
        if [ "$ready_pods" -ge 5 ]; then
            pods_ready=true
            break
        fi
        
        sleep 2
        waited=$((waited + 2))
    done
    
    if [ "$pods_ready" = false ]; then
        print_warning "Some pods may not be ready yet, attempting port-forwards anyway..."
    fi
    
    # Read external port configuration from .env-bitoarch
    local provider_external_port="${CIS_PROVIDER_EXTERNAL_PORT:-5001}"
    local manager_external_port="${CIS_MANAGER_EXTERNAL_PORT:-5002}"
    local config_external_port="${CIS_CONFIG_EXTERNAL_PORT:-5003}"
    local mysql_external_port="${MYSQL_EXTERNAL_PORT:-5004}"
    local tracker_external_port="${CIS_TRACKER_EXTERNAL_PORT:-5005}"
    
    # Read internal port configuration from .env-bitoarch
    local provider_internal_port="${XMCP_HTTP_PORT:-8080}"
    local manager_internal_port="${CIS_MANAGER_PORT:-9090}"
    local config_internal_port="${CIS_CONFIG_PORT:-8081}"
    local mysql_internal_port="${MYSQL_PORT:-3306}"
    local tracker_internal_port="${CIS_TRACKING_PORT:-9920}"
    
    print_info "Setting up port-forwards (localhost → cluster services)..."

    # Setup port-forwards with proper daemonization for stability
    # Use: nohup + stdin from /dev/null + disown to fully detach from shell
    # This prevents port-forwards from dying when the parent shell exits
    
    nohup kubectl port-forward --address 0.0.0.0 -n "$namespace" svc/ai-architect-provider "${provider_external_port}:${provider_internal_port}" </dev/null >> "${LOG_FILE:-/dev/null}" 2>&1 &
    disown 2>/dev/null || true
    sleep 0.5
    
    nohup kubectl port-forward --address 0.0.0.0 -n "$namespace" svc/ai-architect-manager "${manager_external_port}:${manager_internal_port}" </dev/null >> "${LOG_FILE:-/dev/null}" 2>&1 &
    disown 2>/dev/null || true
    sleep 0.5
    
    nohup kubectl port-forward --address 0.0.0.0 -n "$namespace" svc/ai-architect-config "${config_external_port}:${config_internal_port}" </dev/null >> "${LOG_FILE:-/dev/null}" 2>&1 &
    disown 2>/dev/null || true
    sleep 0.5
    
    nohup kubectl port-forward --address 0.0.0.0 -n "$namespace" svc/ai-architect-mysql "${mysql_external_port}:${mysql_internal_port}" </dev/null >> "${LOG_FILE:-/dev/null}" 2>&1 &
    disown 2>/dev/null || true
    sleep 0.5
    
    nohup kubectl port-forward --address 0.0.0.0 -n "$namespace" svc/ai-architect-tracker "${tracker_external_port}:${tracker_internal_port}" </dev/null >> "${LOG_FILE:-/dev/null}" 2>&1 &
    disown 2>/dev/null || true

    # Give port-forwards time to establish
    sleep 2

    # Verify port-forwards are running with retry for any missing
    local max_retries=3
    local retry=0

    while [ $retry -lt $max_retries ]; do
        local pf_count=$(ps aux | grep "kubectl port-forward" | grep -E "(-n |--namespace=|-n=)$namespace" | grep -v grep | wc -l | xargs)

        if [ "$pf_count" -ge 5 ]; then
            break
        fi

        # Check which port-forwards are missing and retry them
        local services=(
            "ai-architect-provider:${provider_external_port}:${provider_internal_port}"
            "ai-architect-manager:${manager_external_port}:${manager_internal_port}"
            "ai-architect-config:${config_external_port}:${config_internal_port}"
            "ai-architect-mysql:${mysql_external_port}:${mysql_internal_port}"
            "ai-architect-tracker:${tracker_external_port}:${tracker_internal_port}"
        )

        for service_spec in "${services[@]}"; do
            local svc_name=$(echo "$service_spec" | cut -d: -f1)
            local ext_port=$(echo "$service_spec" | cut -d: -f2)
            local int_port=$(echo "$service_spec" | cut -d: -f3)

            # Check if this service's port-forward is running
            if ! ps aux | grep "kubectl port-forward" | grep "$svc_name" | grep -v grep >/dev/null 2>&1; then
                log_silent "Retrying port-forward for $svc_name (attempt $((retry + 1)))"
                nohup kubectl port-forward --address 0.0.0.0 -n "$namespace" svc/"$svc_name" "${ext_port}:${int_port}" </dev/null >> "${LOG_FILE:-/dev/null}" 2>&1 &
                disown 2>/dev/null || true
                sleep 1
            fi
        done

        retry=$((retry + 1))
        sleep 2
    done

    # Final verification
    local pf_count=$(ps aux | grep "kubectl port-forward" | grep -E "(-n |--namespace=|-n=)$namespace" | grep -v grep | wc -l | xargs)

    if [ "$pf_count" -ge 5 ]; then
        print_status "Port-forwards established (5/5 services)"
        echo ""
        echo "  • Provider:  localhost:${provider_external_port} → ai-architect-provider:${provider_internal_port}"
        echo "  • Manager:   localhost:${manager_external_port} → ai-architect-manager:${manager_internal_port}"
        echo "  • Config:    localhost:${config_external_port} → ai-architect-config:${config_internal_port}"
        echo "  • MySQL:     localhost:${mysql_external_port} → ai-architect-mysql:${mysql_internal_port}"
        echo "  • Tracker:   localhost:${tracker_external_port} → ai-architect-tracker:${tracker_internal_port}"
        echo ""
        return 0
    else
        print_warning "Some port-forwards may have failed to start ($pf_count/5)"
        print_info "Check with: ps aux | grep 'kubectl port-forward'"
        return 1
    fi
}

# Kill port-forwards for this namespace
kill_port_forwards() {
    local namespace="$1"
    
    # Find all kubectl port-forward processes for this namespace
    # Match: -n namespace, --namespace=namespace, or -n=namespace
    local pids=$(ps aux | grep "kubectl port-forward" | grep -E "(-n |--namespace=|-n=)$namespace" | grep -v grep | awk '{print $2}')
    
    if [ -n "$pids" ]; then
        print_info "Killing existing port-forwards..."
        echo "$pids" | xargs kill -9 2>/dev/null || true
        print_status "Port-forwards terminated"
    fi
}

# Uninstall Helm release
uninstall_helm_release() {
    local namespace="$1"
    local release_name="${2:-bitoarch}"
    local delete_pvcs="${3:-false}"
    
    # Kill any existing port-forwards first
    kill_port_forwards "$namespace"
    
    print_info "Uninstalling Helm release: $release_name"
    
    if helm uninstall "$release_name" --namespace "$namespace" >> "$LOG_FILE" 2>&1; then
        print_status "Helm release uninstalled"
    else
        print_warning "Failed to uninstall Helm release"
    fi
    
    # Delete PVCs if requested
    if [ "$delete_pvcs" = "true" ]; then
        print_info "Deleting persistent volume claims..."
        if kubectl delete pvc -n "$namespace" -l app.kubernetes.io/name=bitoarch --timeout=60s >> "$LOG_FILE" 2>&1; then
            print_status "PVCs deleted"
        else
            print_warning "Failed to delete some PVCs, they may be in use"
        fi
    else
        print_info "Persistent volumes preserved (data retained)"
        print_info "To delete data: kubectl delete pvc -n $namespace -l app.kubernetes.io/name=bitoarch"
    fi
}

# Restart K8s deployment
restart_k8s_deployment() {
    local namespace="$1"
    local component="$2"
    
    if [ -z "$component" ]; then
        # Restart all
        print_info "Restarting all deployments..."
        kubectl rollout restart deployment -n "$namespace" -l "app.kubernetes.io/name=bitoarch" >> "$LOG_FILE" 2>&1
    else
        # Restart specific component
        print_info "Restarting $component..."
        kubectl rollout restart deployment -n "$namespace" -l "app.kubernetes.io/component=$component" >> "$LOG_FILE" 2>&1
    fi
}

# Get K8s logs
get_k8s_logs() {
    local namespace="$1"
    local component="$2"
    local follow="${3:-false}"
    
    if [ -z "$component" ]; then
        # All logs
        if [ "$follow" = "true" ]; then
            kubectl logs -n "$namespace" -l "app.kubernetes.io/name=bitoarch" --tail=100 -f --max-log-requests=10
        else
            kubectl logs -n "$namespace" -l "app.kubernetes.io/name=bitoarch" --tail=100
        fi
    else
        # Specific component
        if [ "$follow" = "true" ]; then
            kubectl logs -n "$namespace" -l "app.kubernetes.io/component=$component" --tail=100 -f
        else
            kubectl logs -n "$namespace" -l "app.kubernetes.io/component=$component" --tail=100
        fi
    fi
}

# Check if K8s deployment exists
check_k8s_deployment_exists() {
    local namespace="$1"
    
    if kubectl get namespace "$namespace" >/dev/null 2>&1; then
        if kubectl get deployment -n "$namespace" -l "app.kubernetes.io/name=bitoarch" 2>/dev/null | grep -q "ai-architect"; then
            return 0  # Deployment exists
        fi
    fi
    return 1  # Deployment doesn't exist
}

# Save deployment type
save_deployment_type() {
    local type="$1"
    
    # Source path-manager if not already loaded
    if ! type get_deployment_type_file >/dev/null 2>&1; then
        source "${SCRIPT_DIR}/scripts/lib/path-manager.sh" 2>/dev/null || true
    fi
    
    local deployment_file
    if type get_deployment_type_file >/dev/null 2>&1; then
        deployment_file=$(get_deployment_type_file)
    else
        deployment_file="${SCRIPT_DIR}/.deployment-type"
    fi
    
    # CRITICAL FIX: Ensure parent directory exists before writing
    local deployment_dir=$(dirname "$deployment_file")
    if [ ! -d "$deployment_dir" ]; then
        mkdir -p "$deployment_dir" 2>/dev/null || {
            if command -v sudo >/dev/null 2>&1 && [ -t 0 ]; then
                print_info "Creating configuration directory (requires sudo)..."
                sudo mkdir -p "$deployment_dir"
                sudo chown -R "$USER:$(id -gn)" "$deployment_dir"
            else
                print_error "Cannot create directory: $deployment_dir"
                print_info "Falling back to legacy installation directory"
                deployment_file="${SCRIPT_DIR}/.deployment-type"
                mkdir -p "$(dirname "$deployment_file")" 2>/dev/null || true
            fi
        }
    fi
    
    echo "$type" > "$deployment_file"
    log_silent "Deployment type saved: $type to $deployment_file"
}

# Get deployment type
get_deployment_type() {
    # Source path-manager if not already loaded
    if ! type get_deployment_type_file >/dev/null 2>&1; then
        source "${SCRIPT_DIR}/scripts/lib/path-manager.sh" 2>/dev/null || true
    fi
    
    local deployment_file
    if type get_deployment_type_file >/dev/null 2>&1; then
        deployment_file=$(get_deployment_type_file)
    else
        deployment_file="${SCRIPT_DIR}/.deployment-type"
    fi
    
    if [ -f "$deployment_file" ]; then
        cat "$deployment_file"
    else
        echo "unknown"
    fi
}
