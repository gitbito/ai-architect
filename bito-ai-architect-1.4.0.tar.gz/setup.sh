#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PLATFORM_DIR="$SCRIPT_DIR"  # Explicitly save platform root directory

# Source path manager for standard Unix paths
source "${SCRIPT_DIR}/scripts/lib/path-manager.sh"

# Use path-manager functions for file locations
ENV_FILE="$(get_config_file)"
ENV_LLM_FILE="$(get_llm_config_file)"
LOG_FILE="$(get_setup_log)"

# Export for background processes (parallel deployment)
export ENV_FILE
export ENV_LLM_FILE
export LOG_FILE
export SCRIPT_DIR
export PLATFORM_DIR

SETUP_IN_PROGRESS=false
SERVICES_WERE_RUNNING=false
DEPLOYMENT_STARTED=false

ENV_GENERATOR="${SCRIPT_DIR}/scripts/env-generator.sh"
if [ ! -f "$ENV_GENERATOR" ]; then
    echo "ERROR: env-generator.sh not found at $ENV_GENERATOR"
    exit 1
fi
source "$ENV_GENERATOR"

# Source other utilities
source "${SCRIPT_DIR}/scripts/setup-utils.sh"
source "${SCRIPT_DIR}/scripts/docker-manager.sh"
source "${SCRIPT_DIR}/scripts/kubernetes-manager.sh"
source "${SCRIPT_DIR}/scripts/prerequisites-manager.sh"
source "${SCRIPT_DIR}/scripts/service-manager.sh"
source "${SCRIPT_DIR}/scripts/sql-migration-manager.sh"
source "${SCRIPT_DIR}/scripts/lib/adapters/config-adapter.sh"
source "${SCRIPT_DIR}/scripts/lib/adapters/manager-adapter.sh"
source "${SCRIPT_DIR}/scripts/lib/adapters/tracker-adapter.sh"

# -------------------------------------------------------------------
# Function: get_repo_count_from_config
# Parses .bitoarch-config.yaml and returns the count of configured repos
# -------------------------------------------------------------------
get_repo_count_from_config() {
    # Use path-manager to get actual config file location (standard or legacy)
    local config_file=$(get_repo_config_file)
    
    if [ ! -f "$config_file" ]; then
        echo "0"
        return 0
    fi
    
    # Count the number of repository entries (lines starting with '- namespace:')
    local repo_count=$(grep -c "^\s*- namespace:" "$config_file" 2>/dev/null || echo "0")
    echo "$repo_count"
}

ask_llm_config_choice() {
    echo ""
    echo -e "${BLUE}=== LLM Provider Configuration ===${NC}"
    read -r -p "Do you want to configure a custom LLM provider? (y/n): " configure_llm

    if [[ "$configure_llm" =~ ^[Yy]$ ]]; then
        return 0
    fi
    return 1
}

CONFIGURED_PROVIDERS=()
# -------------------------------------------------------------------
# Function: get_provider_metadata
# Maps user selection → provider details
# Returns provider_name, url_key, token_key, example_url
# -------------------------------------------------------------------
get_provider_metadata() {
    case "$1" in
        1)
            provider_name="anthropic"
            url_key="ANTHROPIC_API_URL"
            token_key="ANTHROPIC_API_TOKEN"
            example_url="https://api.anthropic.com"
            ;;
        2)
            provider_name="xai"
            url_key="XAI_API_URL"
            token_key="XAI_API_TOKEN"
            example_url="https://api.x.ai/v1"
            ;;
        3)
            provider_name="openai"
            url_key="OPENAI_API_URL"
            token_key="OPENAI_API_TOKEN"
            example_url="https://api.openai.com/v1"
            ;;
        *)
            return 1
            ;;
    esac
}

configure_llm() {

    CONFIGURED_PROVIDERS=()
    local continue_config="y"

    while [[ "$continue_config" =~ ^[Yy]$ ]]; do

        # Auto-stop if all providers are configured
        if [[ ${#CONFIGURED_PROVIDERS[@]} -eq 3 ]]; then
            echo -e "${GREEN}💡 All LLM providers have been configured.${NC}"
            break
        fi

        local provider_choice
        echo ""
        read -r -p "Configure LLM: 1) Anthropic 2) XAI Grok 3) OpenAI [1-3]: " provider_choice

        get_provider_metadata "$provider_choice" || {
            echo "✗ Invalid option. Please select 1–3."
            continue
        }

        # Skip duplicates
        if [[ " ${CONFIGURED_PROVIDERS[*]} " =~ " ${provider_name} " ]]; then
            echo -e "${YELLOW}⚠ $provider_name is already configured.${NC}"
        else
            echo -e "\n${BLUE}=== Configuring ${provider_name} ===${NC}\n"

            local token=""
            while [[ -z "$token" ]]; do
                read -s -r -p "Enter ${provider_name} API token (input hidden): " token
                stty echo; echo ""
                [[ -z "$token" ]] && echo "Token cannot be empty."
            done

            set_env_key_value "${token_key}" "${token}" "$ENV_LLM_FILE"

            CONFIGURED_PROVIDERS+=("$provider_name")
            print_status " ${provider_name} configured successfully"
        fi

        # Ask whether to configure another provider only if some remain
        if [[ ${#CONFIGURED_PROVIDERS[@]} -lt 3 ]]; then
            read -r -p "Do you also want to add an API token for another LLM? (y/N): " continue_config

            if [[ -z "$continue_config" || "$continue_config" =~ ^[Nn]$ ]]; then
                if [[ ${#CONFIGURED_PROVIDERS[@]} -eq 1 && " ${CONFIGURED_PROVIDERS[*]} " =~ " xai " ]]; then
                    echo -e "${RED}⚠ XAI Grok API key alone cannot be used.${NC}"
                    echo -e "${YELLOW}Please configure another LLM (Anthropic or OpenAI).${NC}"
                    continue_config="y"  # Force loop to continue
                fi
            fi
        else
            continue_config="n"
        fi
    done
    return 0
}

configure_llm_provider() {
    # Run the flow → fills CONFIGURED_PROVIDERS[]
    configure_llm

    # Build final selection list (configured providers + bito)
    local options=("${CONFIGURED_PROVIDERS[@]}" "bito")
    local prefer_order=("xai" "openai" "anthropic" "bito")

    selected_provider=""

    for preferred in "${prefer_order[@]}"; do
        for p in "${options[@]}"; do
            if [[ "$p" == "$preferred" ]]; then
                selected_provider="$preferred"
                break 2
            fi
        done
    done
    set_env_key_value "LLM_DEFAULT_PROVIDER" "${selected_provider}" "$ENV_LLM_FILE"

    # Send LLM provider tracking event
    if [[ ${#CONFIGURED_PROVIDERS[@]} -gt 0 ]]; then
        local providers_csv=$(IFS=,; echo "${CONFIGURED_PROVIDERS[*]}")
        send_llm_provider_tracking "$providers_csv"
    fi

#    echo -e "\n${GREEN}💡Default provider set to: ${selected_provider}.${NC}\n"
}

generate_env_file() {
    print_info "Configuring Bito's AI Architect..."
    
    if [ -f "$ENV_FILE" ]; then
        print_info "Using existing configuration"
        return
    fi
    
    # Source constants for URLs
    if [ -f "${SCRIPT_DIR}/scripts/lib/constants.sh" ]; then
        source "${SCRIPT_DIR}/scripts/lib/constants.sh"
    fi
    
    # Prompt for BITO_API_KEY (REQUIRED - must be provided)
    echo ""


    # Security Notice
    render_security_notice_block
    
    local BITO_API_KEY=""
    while [ -z "$BITO_API_KEY" ]; do
        read -s -p "Enter your Bito API Key (input hidden): " BITO_API_KEY
        echo ""
        if [ -z "$BITO_API_KEY" ]; then
            echo -e "${RED}✗ Bito API Key cannot be empty. Please try again.${NC}"
            echo ""
        fi
    done
    
    echo ""
    
    # Call tracking endpoint with dummy data after user enters BITO_API_KEY
    # This sends a setup_started event to track the initialization
    local tracking_url=""
    if [ -f "${SCRIPT_DIR}/.env-bitoarch.default" ]; then
        tracking_url=$(grep "^TRACKING_SERVICE_BASE_URL=" "${SCRIPT_DIR}/.env-bitoarch.default" 2>/dev/null | cut -d'=' -f2)
        TRACKING_SERVICE_BASE_URL="$tracking_url"
    fi
    
    if [[ -n "$tracking_url" ]]; then
        # Build dummy data for tracking
        local tracking_data
        tracking_data=$(cat <<TRACKING_EOF
{
    "deployment_mode": "self_hosted"
}
TRACKING_EOF
        )
        
        # Call tracking endpoint with setup_started event
      
        TRACKING_HTTP_STATUS=$(call_tracking_endpoint_event "$tracking_url" "$BITO_API_KEY" "architect_install_started" "$tracking_data") || true
        
        # Check if HTTP 403 error (Invalid API Key)
        if [ "$TRACKING_HTTP_STATUS" = "403" ]; then
            echo "❌ Invalid Bito API Key. Please verify your key and try again."
            echo "   Get your key at: https://alpha.bito.ai/home/advanced"
            exit 1
        elif [ "$TRACKING_HTTP_STATUS" = "200" ] || [ "$TRACKING_HTTP_STATUS" = "201" ]; then
            print_status "Setup initialization tracked successfully"
            # Non-blocking: tracking failure doesn't stop setup
            
        fi
    fi
    print_status "Bito API Key received"
    echo ""
    
    # Collect Git Provider and Access Token (REQUIRED)
    echo -e "${BLUE}=== Git Integration ===${NC}"
    echo -e "${YELLOW}⚠ Git provider and access token are required to proceed${NC}"
    echo ""
    echo -e "See documentation: ${BLUE}${GIT_TOKEN_DOCS_URL:-https://docs.bito.ai/ai-architect/install-ai-architect-self-hosted#git-provider}${NC}"
    echo ""
    
    local GIT_PROVIDER=""
    local GIT_ACCESS_TOKEN=""
    local GIT_DOMAIN_URL=""
    local GIT_USER=""
    
    # Git Provider selection
    while [ -z "$GIT_PROVIDER" ]; do
        read -p "Select Git provider (1) GitLab  (2) GitHub  (3) Bitbucket  [1-3]: " git_choice
        
        case $git_choice in
            1) GIT_PROVIDER="gitlab" ;;
            2) GIT_PROVIDER="github" ;;
            3) GIT_PROVIDER="bitbucket" ;;
            *)
                echo -e "${RED}✗${NC} Invalid choice. Please select 1-3"
                ;;
        esac
    done

    if [ -z "$GIT_ACCESS_TOKEN" ]; then
        read -r -p "Is this an enterprise version of $GIT_PROVIDER (e.g., https://my.company.com)? (y/N):" is_enterprise
        if [[ "$is_enterprise" =~ ^[Yy]$ ]]; then
            while [ -z "$GIT_DOMAIN_URL" ]; do
                read -r -p "Enter domain for enterprise $GIT_PROVIDER: " GIT_DOMAIN_URL
                if [ -z "$GIT_DOMAIN_URL" ]; then
                    echo -e "${RED}✗${NC} Git domain is required for enterprise"
                fi
            done
        fi
    fi

    if [ -z "$GIT_ACCESS_TOKEN" ]; then
        if [[ "$GIT_PROVIDER" == "bitbucket" ]]; then
            echo ""
            echo -e "🛠 Configuring user authentication..."

            if [[ -z "$GIT_DOMAIN_URL" ]]; then
                # No domain → ask for email
                while [[ -z "$GIT_USER" ]]; do
                    read -r -p "Enter your Bitbucket account email: " GIT_USER
                    [[ -z "$GIT_USER" ]] && echo "⚠ Email is required. Please try again."
                done
            else
                # Domain exists → ask for username
                while [[ -z "$GIT_USER" ]]; do
                    read -r -p "Enter your Bitbucket username: " GIT_USER
                    [[ -z "$GIT_USER" ]] && echo "⚠ Username is required. Please try again."
                done
            fi

            echo -e "✅ Bitbucket user set: $GIT_USER"
        fi
    fi


    
    # Git Access Token input
    while [ -z "$GIT_ACCESS_TOKEN" ]; do
        echo ""
        read -s -p "Enter Git access token (input hidden): " GIT_ACCESS_TOKEN
        if [ -z "$GIT_ACCESS_TOKEN" ]; then
            echo -e "${RED}✗${NC} Git access token is required"
            echo ""
        fi
    done
    
    print_status "Git provider configured (${GIT_PROVIDER})"
    echo ""
    
    # Send git integration tracking event
    # Determine if this is enterprise based on user response
    local is_enterprise_bool="false"
    if [[ "$is_enterprise" =~ ^[Yy]$ ]]; then
        is_enterprise_bool="true"
    fi
    
    # Call tracking with git integration event
    send_git_integration_tracking "$GIT_PROVIDER" "$is_enterprise_bool" "$GIT_DOMAIN_URL"


    # Ask user if they want to configure custom LLM
    render_indexing_information_block

    local tracking_url=""
    if [ -f "${SCRIPT_DIR}/.env-bitoarch.default" ]; then
        tracking_url=$(grep "^TRACKING_SERVICE_BASE_URL=" "${SCRIPT_DIR}/.env-bitoarch.default" 2>/dev/null | cut -d'=' -f2)
    fi

    if check_indexing_enabled "${tracking_url}" "${BITO_API_KEY}" ; then
        print_info "Using Bito's LLM keys to index your code.  No LLM keys are required from you."
    else
        configure_llm_provider
    fi
    
    if [[ "${AUTO_SETUP:-}" == "true" ]]; then
        print_info "Auto-setup mode: Using default configuration with secure generated passwords"
    else
        echo -e "\n${BLUE}=== Quick Configuration ===${NC}"
        echo "Using defaults (recommended for quick setup)"
        echo ""
    fi
    
    DB_ROOT_PASS=$(generate_secret)
    DB_USER_PASS=$(generate_secret)
    JWT_SECRET=$(generate_secret)
    CIS_MANAGER_API_KEY=$(generate_secret)
    CIS_CONFIG_API_KEY=$(generate_secret)
    CIS_PROVIDER_API_KEY=$(generate_secret)
    SECRETS_ENCRYPTION_KEY=$(generate_encryption_key)
    
    # Read ONLY port defaults from .env-bitoarch.default if it exists (don't overwrite user inputs!)
    if [ -f "${SCRIPT_DIR}/.env-bitoarch.default" ]; then
        log_silent "Reading default port configuration from .env-bitoarch.default"
        # Extract only port variables using grep
        local temp_provider_port=$(grep "^CIS_PROVIDER_EXTERNAL_PORT=" "${SCRIPT_DIR}/.env-bitoarch.default" 2>/dev/null | cut -d'=' -f2 || echo "8080")
        local temp_manager_port=$(grep "^CIS_MANAGER_EXTERNAL_PORT=" "${SCRIPT_DIR}/.env-bitoarch.default" 2>/dev/null | cut -d'=' -f2 || echo "9090")
        local temp_config_port=$(grep "^CIS_CONFIG_EXTERNAL_PORT=" "${SCRIPT_DIR}/.env-bitoarch.default" 2>/dev/null | cut -d'=' -f2 || echo "8081")
        local temp_mysql_port=$(grep "^MYSQL_EXTERNAL_PORT=" "${SCRIPT_DIR}/.env-bitoarch.default" 2>/dev/null | cut -d'=' -f2 || echo "3306")
        local temp_tracker_port=$(grep "^CIS_TRACKER_EXTERNAL_PORT=" "${SCRIPT_DIR}/.env-bitoarch.default" 2>/dev/null | cut -d'=' -f2 || echo "9090")

        # Only use if not empty
        [ -n "$temp_provider_port" ] && CIS_PROVIDER_EXTERNAL_PORT="$temp_provider_port"
        [ -n "$temp_manager_port" ] && CIS_MANAGER_EXTERNAL_PORT="$temp_manager_port"
        [ -n "$temp_config_port" ] && CIS_CONFIG_EXTERNAL_PORT="$temp_config_port"
        [ -n "$temp_mysql_port" ] && MYSQL_EXTERNAL_PORT="$temp_mysql_port"
        [ -n "$temp_tracker_port" ] && CIS_TRACKER_EXTERNAL_PORT="$temp_tracker_port"
    fi
    
    # Load service versions from versions/service-versions.json (single source of truth)
    local versions_file="${SCRIPT_DIR}/versions/service-versions.json"
    if [ -f "$versions_file" ]; then
        if command -v jq >/dev/null 2>&1; then
            CIS_CONFIG_VERSION=$(jq -r '.services."cis-config".version' "$versions_file" 2>/dev/null || echo "latest")
            CIS_MANAGER_VERSION=$(jq -r '.services."cis-manager".version' "$versions_file" 2>/dev/null || echo "latest")
            CIS_PROVIDER_VERSION=$(jq -r '.services."cis-provider".version' "$versions_file" 2>/dev/null || echo "latest")
            CIS_TRACKER_VERSION=$(jq -r '.services."cis-tracker".version' "$versions_file" 2>/dev/null || echo "latest")
        else
            # Fallback parsing without jq
            CIS_CONFIG_VERSION=$(grep -A 10 '"cis-config"' "$versions_file" | grep '"version"' | head -1 | cut -d'"' -f4 || echo "latest")
            CIS_MANAGER_VERSION=$(grep -A 10 '"cis-manager"' "$versions_file" | grep '"version"' | head -1 | cut -d'"' -f4 || echo "latest")
            CIS_PROVIDER_VERSION=$(grep -A 10 '"cis-provider"' "$versions_file" | grep '"version"' | head -1 | cut -d'"' -f4 || echo "latest")
            CIS_TRACKER_VERSION=$(grep -A 10 '"cis-tracker"' "$versions_file" | grep '"version"' | head -1 | cut -d'"' -f4 || echo "latest")
        fi
        print_info "Service versions loaded from $versions_file"
        print_info "  AI Architect Config: $CIS_CONFIG_VERSION"
        print_info "  AI Architect Manager: $CIS_MANAGER_VERSION"
        print_info "  AI Architect Provider: $CIS_PROVIDER_VERSION"
        print_info "  AI Architect Tracker: $CIS_TRACKER_VERSION"
    else
        print_warning "versions/service-versions.json not found, using 'latest' tags"
        CIS_CONFIG_VERSION="latest"
        CIS_MANAGER_VERSION="latest"
        CIS_PROVIDER_VERSION="latest"
        CIS_TRACKER_VERSION="latest"
    fi
    
    if [[ "${AUTO_SETUP:-}" != "true" ]]; then
        echo ""
        echo -e "${BLUE}🔑 Bito MCP Access Token Configuration${NC}"
        read -p "Would you like Bito to generate a secure MCP access token to prevent unauthorized access to your MCP? [Y/n]: " -r REPLY
        if [[ $REPLY =~ ^[Nn]$ ]]; then
            echo ""
            read -p "Please create your custom Bito MCP access token (be sure to save this): " -r CUSTOM_TOKEN
            if [ -n "$CUSTOM_TOKEN" ]; then
                BITO_MCP_ACCESS_TOKEN="$CUSTOM_TOKEN"
                print_status "Using custom Bito MCP access token"
            else
                print_warning "Empty token provided, using auto-generated secure token"
                BITO_MCP_ACCESS_TOKEN=$(generate_secret)
            fi
        else
            BITO_MCP_ACCESS_TOKEN=$(generate_secret)
            print_status "Using auto-generated secure Bito MCP access token"
        fi
    else
        BITO_MCP_ACCESS_TOKEN=$(generate_secret)
    fi


    
    # Use external ports from .env-bitoarch.default if available, otherwise use defaults
    CIS_PROVIDER_EXTERNAL_PORT=${CIS_PROVIDER_EXTERNAL_PORT:-8080}
    CIS_MANAGER_EXTERNAL_PORT=${CIS_MANAGER_EXTERNAL_PORT:-9090}
    CIS_CONFIG_EXTERNAL_PORT=${CIS_CONFIG_EXTERNAL_PORT:-8081}
    MYSQL_EXTERNAL_PORT=${MYSQL_EXTERNAL_PORT:-3306}
    CIS_TRACKER_EXTERNAL_PORT=${CIS_TRACKER_EXTERNAL_PORT:-9920}
    
    print_info "Using configuration:"
    print_info "  - AI Architect Provider external port: $CIS_PROVIDER_EXTERNAL_PORT"
    print_info "  - AI Architect Manager external port: $CIS_MANAGER_EXTERNAL_PORT"
    print_info "  - AI Architect Config external port: $CIS_CONFIG_EXTERNAL_PORT"
    print_info "  - AI Architect MySQL external port: $MYSQL_EXTERNAL_PORT"
    print_info "  - AI Architect Tracker external port: $CIS_TRACKER_EXTERNAL_PORT"
    print_info "  - Secure passwords and tokens: auto-generated"
    
    print_info "Generating .env-bitoarch from template (.env-bitoarch.default)..."
    
    # Call env-generator function with all collected parameters
    generate_env_with_params "$ENV_FILE" \
        "$BITO_API_KEY" "$DB_ROOT_PASS" "$DB_USER_PASS" "$JWT_SECRET" \
        "$CIS_MANAGER_API_KEY" "$CIS_CONFIG_API_KEY" "$CIS_PROVIDER_API_KEY" \
        "$BITO_MCP_ACCESS_TOKEN" "$SECRETS_ENCRYPTION_KEY" \
        "$CIS_CONFIG_VERSION" "$CIS_MANAGER_VERSION" "$CIS_PROVIDER_VERSION" \
        "$CIS_PROVIDER_EXTERNAL_PORT" "$CIS_MANAGER_EXTERNAL_PORT" "$CIS_CONFIG_EXTERNAL_PORT" "$MYSQL_EXTERNAL_PORT" \
        "$GIT_PROVIDER" "$GIT_ACCESS_TOKEN" "$GIT_DOMAIN_URL" "$GIT_USER" "$CIS_TRACKER_EXTERNAL_PORT" "$CIS_TRACKER_VERSION"
    
    [ $? -ne 0 ] && return 1
    
    print_status "Configuration file created: $ENV_FILE"
}

prepare_data_directories() {
    print_info "Preparing all service directories with proper permissions..."
    
    # Source .env to get directory paths if file exists
    if [ -f "$ENV_FILE" ]; then
        source "$ENV_FILE"
    fi
    
    # Get config directory from path-manager (handles standard vs legacy paths)
    local config_dir="$(get_config_dir)"

    # Ensure config directory exists and is writable
    mkdir -p "$config_dir" 2>/dev/null || {
        if command -v sudo >/dev/null 2>&1; then
            sudo mkdir -p "$config_dir"
            sudo chown -R "$USER:$(id -gn)" "$config_dir"
        fi
    }

    # Get log directory from path-manager (handles standard vs legacy paths)
    local log_dir="$(get_log_dir)"

    # Ensure log directory exists and is writable
    mkdir -p "$log_dir" 2>/dev/null || {
        if command -v sudo >/dev/null 2>&1; then
            sudo mkdir -p "$log_dir"
            sudo chown -R "$USER:$(id -gn)" "$log_dir"
        fi
    }

    # Create service-specific log directories
    create_log_dirs

    # Define all directories that need full permissions for containers
    local directories=(
        "${SCRIPT_DIR}/${HOST_DATA_DIR:-services/cis-provider/data}"
        "$log_dir"
        "${SCRIPT_DIR}/${HOST_PROVIDER_METADATA_DIR:-services/cis-provider/metadata}"
    )
    
    local failed_dirs=()
    local success_count=0
    
    # Create and set permissions for each directory
    for dir in "${directories[@]}"; do
        # Create directory if it doesn't exist
        mkdir -p "$dir" 2>/dev/null
        
        # Set 777 permissions (rwxrwxrwx) so any container user can read/write
        if chmod -R 777 "$dir" 2>/dev/null; then
            success_count=$((success_count + 1))
            log_silent "Set 777 permissions on $dir"
        else
            # Try with sudo if regular chmod fails
            if command -v sudo >/dev/null 2>&1 && sudo chmod -R 777 "$dir" 2>/dev/null; then
                success_count=$((success_count + 1))
                log_silent "Set 777 permissions with sudo on $dir"
            else
                failed_dirs+=("$dir")
            fi
        fi
    done
    
    # Report results
    if [ ${#failed_dirs[@]} -eq 0 ]; then
        print_status "Set full permissions (777) on all service directories (${success_count}/${#directories[@]})"
    else
        print_warning "Failed to set permissions on ${#failed_dirs[@]} directories:"
        for dir in "${failed_dirs[@]}"; do
            echo "  - $dir"
        done
        print_warning "Please manually run: sudo chmod -R 777 ${failed_dirs[*]}"
        return 1
    fi
    
    print_status "All service directories prepared with proper permissions"
}

prepare_service_sql_scripts() {
    print_info "Preparing service SQL scripts for MySQL initialization..."
    
    local mysql_init_dir="${SCRIPT_DIR}/services/mysql/init"
    local scripts_copied=0
    
    # Copy cis-config SQL scripts (numbered 02-* to run after 00 and 01)
    local config_sql_dir="${SCRIPT_DIR}/services/cis-config/resources/sql"
    if [ -d "$config_sql_dir" ]; then
        for sql_file in "$config_sql_dir"/*.sql; do
            if [ -f "$sql_file" ]; then
                local filename=$(basename "$sql_file")
                local dest_file="${mysql_init_dir}/02-cis-config-${filename}"
                cp "$sql_file" "$dest_file"
                scripts_copied=$((scripts_copied + 1))
                log_silent "Copied: $filename -> 02-cis-config-${filename}"
            fi
        done
    fi
    
    # Copy cis-manager SQL scripts (database.sql first with 03-, others with 04-)
    local manager_sql_dir="${SCRIPT_DIR}/services/cis-manager/resources"
    if [ -d "$manager_sql_dir" ]; then
        # Handle database.sql separately with 03- prefix (must run first)
        if [ -f "$manager_sql_dir/database.sql" ]; then
            cp "$manager_sql_dir/database.sql" "${mysql_init_dir}/03-cis-manager-database.sql"
            scripts_copied=$((scripts_copied + 1))
            log_silent "Copied: database.sql -> 03-cis-manager-database.sql"
        fi

        # Copy all other SQL files with 04- prefix (run after database.sql)
        for sql_file in "$manager_sql_dir"/*.sql; do
            if [ -f "$sql_file" ]; then
                local filename=$(basename "$sql_file")
                # Skip database.sql as it's already handled above
                if [ "$filename" != "database.sql" ]; then
                    local dest_file="${mysql_init_dir}/04-cis-manager-${filename}"
                    cp "$sql_file" "$dest_file"
                    scripts_copied=$((scripts_copied + 1))
                    log_silent "Copied: $filename -> 04-cis-manager-${filename}"
                fi
            fi
        done
    fi
    
    if [ $scripts_copied -gt 0 ]; then
        print_status "Prepared $scripts_copied SQL script(s) for MySQL initialization"
        log_silent "SQL scripts will execute in order: 00-*, 01-*, 02-*, 03-*, 04-*"
    else
        print_warning "No service SQL scripts found to prepare"
    fi
    
    return 0
}

ask_repo_setup_mode() {
    local choice_normalized=""
    local tracking_url=""
    if [ -f "${SCRIPT_DIR}/.env-bitoarch.default" ]; then
        tracking_url=$(grep "^TRACKING_SERVICE_BASE_URL=" "${SCRIPT_DIR}/.env-bitoarch.default" 2>/dev/null | cut -d'=' -f2)
    fi
    while true; do
        echo ""
        read -r -p "Choose setup mode (auto/manual): " choice

        # Normalize: convert input to lowercase
        choice_normalized=$(echo "$choice" | tr '[:upper:]' '[:lower:]')

        case "$choice_normalized" in
            auto|a)
                SETUP_MODE="auto"
                echo ""
                print_info "⚙️  Auto mode selected. Saving configuration..."
                echo ""

                if [ -f "$ENV_LLM_FILE" ]; then
                    source "$ENV_LLM_FILE"
                fi

                config_repo_add_from_file_from_setup ".bitoarch-config.yaml"
                if [ $? -ne 0 ]; then
                    print_error "Failed to save configuration automatically."
                    render_manual_repo_config_block
                    SETUP_MODE="failed"
                    return 0
                fi

                print_status "Configuration saved successfully!"
                echo ""
                
                # Send tracking event for auto mode
               
                send_deployment_tracking "auto" "configuration_saved" ""
                
                manager_sync_simple
                echo ""
                return 0
                ;;

            manual|m)
                SETUP_MODE="manual"
                echo ""
                echo -e "🧩 Manual configuration selected."
                echo ""
                
                # Send tracking event for manual mode
               
                send_deployment_tracking "manual" "manual_setup_started" ""

                render_manual_config_instructions_block
                echo ""
                return 0
                ;;

            *)
                print_error "Invalid choice. Please type 'auto' or 'manual'."
                echo ""
                ;;
        esac
    done
}

setup_configuration() {
    # Load environment variables from .env-bitoarch if it exists
    # This is needed to fetch Git provider credentials (GIT_PROVIDER, GIT_ACCESS_TOKEN, BITO_API_KEY)
    if [ -f "$ENV_FILE" ]; then
        source "$ENV_FILE"
    fi
    
    # Check if we should skip repo reconfiguration
    local repo_count=$(get_repo_count_from_config)
    
    # Only ask if config already exists with repos
    if [ "$repo_count" -gt 0 ] && ! render_repo_reconfiguration_prompt_block "$repo_count"; then
        # Return 2 to indicate config was skipped (user said no)
        return 2
    fi

    
    # Proceed with configuration
    echo ""
    echo -e "🛠 Setting up configuration file for your workspace..."
    echo ""

    echo -e "⏳ Getting the repository list from your git account... (this may take 30–50 seconds)"

    # Start loader in background
#    show_loader "Fetching repository metadata"

    # Export deployment type for API calls
    export DEPLOYMENT_TYPE=$(get_deployment_type)

    create_repo_config_from_api
    load_cfg_exit_code=$?

    if [ $load_cfg_exit_code -ne 0 ]; then
        print_error "Failed to fetch repository information."
        render_manual_repo_config_block
        SETUP_MODE="failed"
        return 0
    fi


    echo ""
    # -------------------------------
    # 3. Ask user for auto/manual setup
    # -------------------------------

    render_repo_config_choice_block
    ask_repo_setup_mode

}

display_success() {
    source "$ENV_FILE"
    
    # Use block-level render function
    render_deploy_success_block \
        "$BITO_MCP_ACCESS_TOKEN" \
        "http://localhost:$CIS_PROVIDER_EXTERNAL_PORT/mcp" \
        "$HOME/.local/bin/bitoarch" \
        "${GIT_PROVIDER}" \
        "${SETUP_MODE:-manual}"
}

cleanup_on_interrupt() {
    local exit_code=${1:-1}
    
    echo ""
    
    if [[ "$DEPLOYMENT_STARTED" == "true" ]] && [[ "$SERVICES_WERE_RUNNING" == "false" ]]; then
        print_warning "🧹 Setup interrupted - cleaning up partial deployment..."
        
        local cleanup_cmd="${DOCKER_COMPOSE_CMD:-docker-compose}"
        
        printf "   %-25s" "Stopping Services"
        if eval "$cleanup_cmd down --timeout 30" >/dev/null 2>&1; then
            printf "${GREEN}✅${NC} Stopped gracefully\n"
        else
            printf "${YELLOW}⚠${NC} Timeout\n"
            eval "$cleanup_cmd kill" >/dev/null 2>&1 || true
            eval "$cleanup_cmd rm -f" >/dev/null 2>&1 || true
            printf "   %-25s${GREEN}✅${NC} Force stopped\n" "Cleanup"
        fi
        
        printf "   %-25s" "Releasing Resources"
        eval "$cleanup_cmd down --remove-orphans --volumes" >/dev/null 2>&1 || true
        printf "${GREEN}✅${NC} Released\n"
        
        print_status "Partial deployment cleaned up"
        print_info "You can safely restart the setup script now"
        
    elif [[ "$DEPLOYMENT_STARTED" == "true" ]] && [[ "$SERVICES_WERE_RUNNING" == "true" ]]; then
        print_info "Setup interrupted - existing services remain running"
        print_warning "Services may be in inconsistent state if restart was interrupted"
        print_info "Consider running: docker compose restart"
        
    else
        print_info "Setup cancelled - no changes made to services"
        if [[ "$SERVICES_WERE_RUNNING" == "true" ]]; then
            print_status "Your services remain running"
        fi
    fi
    
    exit $exit_code
}

cleanup_on_error() {
    if [[ "$DEPLOYMENT_STARTED" == "true" ]]; then
        print_error "Setup failed during deployment"
        cleanup_on_interrupt 1
    else
        print_error "Setup failed during initialization"
        print_info "No cleanup needed - services unaffected"
        exit 1
    fi
}

cleanup_on_sigint() {
    echo ""
    print_warning "Setup interrupted by user (Ctrl+C)"
    cleanup_on_interrupt 130
}

cleanup_on_sigterm() {
    echo ""
    print_warning "Setup terminated by system"
    cleanup_on_interrupt 143
}

install_cli() {
    local cli_source="${PLATFORM_DIR}/scripts/bitoarch.sh"
    local cli_bin_dir="$HOME/.local/bin"
    local cli_target="$cli_bin_dir/bitoarch"
    
    log_silent "Installing CLI to $cli_bin_dir"
    
    if [ ! -f "$cli_source" ]; then
        print_warning "CLI script not found, skipping CLI installation"
        log_silent "CLI not found at expected location: $cli_source"
        return 1
    fi
    
    # Create directory if it doesn't exist
    mkdir -p "$cli_bin_dir"
    
    # Make CLI executable and create symlink
    chmod +x "$cli_source"
    ln -sf "$cli_source" "$cli_target"
    
    # Add to PATH for current session (immediate availability)
    export PATH="$cli_bin_dir:$PATH"
    
    # Add to shell configs for future sessions (only if not already present)
    PATH_EXPORT_LINE='export PATH="$HOME/.local/bin:$PATH"'
    CLI_CONFIG_FILES="$HOME/.zshrc $HOME/.bashrc $HOME/.profile $HOME/.bash_profile"
    CLI_ADDED_TO_ANY=false
    CLI_FOUND_CONFIG=false
    
    for config_file in $CLI_CONFIG_FILES; do
        if [ -f "$config_file" ]; then
            CLI_FOUND_CONFIG=true
            # Check if PATH export already exists (using grep -F for fixed string matching)
            if ! grep -qF '.local/bin' "$config_file" 2>/dev/null; then
                echo "$PATH_EXPORT_LINE" >> "$config_file"
                log_silent "Added PATH to $config_file"
                CLI_ADDED_TO_ANY=true
            else
                log_silent "PATH already present in $config_file, skipping"
            fi
        fi
    done
    
    # Fallback: if no rc files found, create .bash_profile
    if [ "$CLI_FOUND_CONFIG" = "false" ]; then
        echo "$PATH_EXPORT_LINE" > "$HOME/.bash_profile"
        log_silent "No shell config files found, created $HOME/.bash_profile with PATH"
        CLI_ADDED_TO_ANY=true
    fi
    
    log_silent "CLI successfully installed to $cli_target"
    return 0
}

uninstall_cli() {
    local cli_target="$HOME/.local/bin/bitoarch"
    
    if [ -L "$cli_target" ] || [ -f "$cli_target" ]; then
        rm -f "$cli_target" 2>/dev/null && {
            print_status "CLI uninstalled"
            return 0
        }
    fi
}

rotate_mcp_token() {
    local new_token="$1"
    
    print_info "Rotating MCP access token..."
    
    # Validate token is provided
    if [ -z "$new_token" ]; then
        print_error "Token cannot be empty"
        return 1
    fi
    
    # Update .env file
    if [ -f "$ENV_FILE" ]; then
        sed -i.bak "s/^BITO_MCP_ACCESS_TOKEN=.*/BITO_MCP_ACCESS_TOKEN=${new_token}/" "$ENV_FILE"
        print_status "Updated token in .env-bitoarch"
    else
        print_error ".env file not found"
        return 1
    fi
    
    # Reload environment
    source "$ENV_FILE"
    export BITO_MCP_ACCESS_TOKEN="$new_token"
    
    # Restart ai-architect-provider to pick up new token from environment
    print_info "Restarting ai-architect-provider service to apply new token..."
    cd "$(dirname "$SCRIPT_DIR")" 2>/dev/null || cd "$PLATFORM_DIR" 2>/dev/null || true
    eval "${DOCKER_COMPOSE_CMD:-docker-compose} restart ai-architect-provider" >/dev/null 2>&1
    
    echo ""
    print_status "MCP token rotated successfully"
    print_info "The provider will apply the new token from environment at startup"
    echo ""
    print_info "New MCP URL: http://localhost:${CIS_PROVIDER_EXTERNAL_PORT}/mcp"
    print_info "New Token: ${new_token}"
    echo ""
    
    return 0
}

# Check Docker Compose port availability
check_docker_ports() {
    print_info "Checking port availability for Docker Compose..."
    
    # Read port values from .env-bitoarch.default
    local temp_provider_port=$(grep "^CIS_PROVIDER_EXTERNAL_PORT=" "${SCRIPT_DIR}/.env-bitoarch.default" 2>/dev/null | cut -d'=' -f2 || echo "8080")
    local temp_manager_port=$(grep "^CIS_MANAGER_EXTERNAL_PORT=" "${SCRIPT_DIR}/.env-bitoarch.default" 2>/dev/null | cut -d'=' -f2 || echo "9090")
    local temp_config_port=$(grep "^CIS_CONFIG_EXTERNAL_PORT=" "${SCRIPT_DIR}/.env-bitoarch.default" 2>/dev/null | cut -d'=' -f2 || echo "8081")
    local temp_mysql_port=$(grep "^MYSQL_EXTERNAL_PORT=" "${SCRIPT_DIR}/.env-bitoarch.default" 2>/dev/null | cut -d'=' -f2 || echo "3306")
    local temp_tracker_port=$(grep "^CIS_TRACKER_EXTERNAL_PORT=" "${SCRIPT_DIR}/.env-bitoarch.default" 2>/dev/null | cut -d'=' -f2 || echo "9920")
    
    local port_conflicts=()
    
    if command -v lsof >/dev/null 2>&1; then
        if lsof -i ":${temp_provider_port}" >/dev/null 2>&1; then
            port_conflicts+=("${temp_provider_port}")
        fi
        if lsof -i ":${temp_manager_port}" >/dev/null 2>&1; then
            port_conflicts+=("${temp_manager_port}")
        fi
        if lsof -i ":${temp_config_port}" >/dev/null 2>&1; then
            port_conflicts+=("${temp_config_port}")
        fi
        if lsof -i ":${temp_mysql_port}" >/dev/null 2>&1; then
            port_conflicts+=("${temp_mysql_port}")
        fi
        if lsof -i ":${temp_tracker_port}" >/dev/null 2>&1; then
            port_conflicts+=("${temp_tracker_port}")
        fi
    fi
    
    if [ ${#port_conflicts[@]} -gt 0 ]; then
        echo ""
        echo -e "${RED}⚠ PORT CONFLICTS DETECTED${NC}"
        echo ""
        echo -e "The following ports are already in use on your system:"
        for port in "${port_conflicts[@]}"; do
            echo -e "  - ${RED}${port}${NC}"
        done
        echo ""
        echo -e "${YELLOW}To resolve:${NC}"
        echo -e "1. Edit: ${BLUE}${SCRIPT_DIR}/.env-bitoarch.default${NC}"
        echo -e "2. Change the conflicting port values"
        echo -e "3. Re-run: ${BLUE}./setup.sh${NC}"
        echo ""
        exit 1
    fi
    
    print_status "All required ports are available"
}

# Check Kubernetes external port availability (for port-forwards)
check_k8s_external_ports() {
    print_info "Checking external port availability in Kubernetes cluster..."
    
    # Read port values from .env-bitoarch.default
    local temp_provider_port=$(grep "^CIS_PROVIDER_EXTERNAL_PORT=" "${SCRIPT_DIR}/.env-bitoarch.default" 2>/dev/null | cut -d'=' -f2 || echo "5001")
    local temp_manager_port=$(grep "^CIS_MANAGER_EXTERNAL_PORT=" "${SCRIPT_DIR}/.env-bitoarch.default" 2>/dev/null | cut -d'=' -f2 || echo "5002")
    local temp_config_port=$(grep "^CIS_CONFIG_EXTERNAL_PORT=" "${SCRIPT_DIR}/.env-bitoarch.default" 2>/dev/null | cut -d'=' -f2 || echo "5003")
    local temp_mysql_port=$(grep "^MYSQL_EXTERNAL_PORT=" "${SCRIPT_DIR}/.env-bitoarch.default" 2>/dev/null | cut -d'=' -f2 || echo "5004")
    local temp_tracker_port=$(grep "^CIS_TRACKER_EXTERNAL_PORT=" "${SCRIPT_DIR}/.env-bitoarch.default" 2>/dev/null | cut -d'=' -f2 || echo "5005")
    
    local ports=($temp_provider_port $temp_manager_port $temp_config_port $temp_mysql_port $temp_tracker_port)
    local conflicts=()
    
    # Check if jq is available for JSON parsing
    if command -v jq >/dev/null 2>&1; then
        # Check if any NodePort services already use these ports
        for port in "${ports[@]}"; do
            if kubectl get svc --all-namespaces -o json 2>/dev/null | \
               jq -r '.items[].spec.ports[]? | select(.nodePort=='$port') | .nodePort' 2>/dev/null | \
               grep -q "^${port}$"; then
                conflicts+=("$port")
            fi
        done
    else
        # Fallback: grep through kubectl output
        local all_nodeports=$(kubectl get svc --all-namespaces -o wide 2>/dev/null | grep -oE ":[0-9]{5}/" | tr -d ':/' | sort -u)
        for port in "${ports[@]}"; do
            if echo "$all_nodeports" | grep -q "^${port}$"; then
                conflicts+=("$port")
            fi
        done
    fi
    
    if [ ${#conflicts[@]} -gt 0 ]; then
        echo ""
        echo -e "${RED}⚠ PORT CONFLICTS DETECTED${NC}"
        echo ""
        echo -e "The following Ports are already in use in your Kubernetes cluster:"
        for port in "${conflicts[@]}"; do
            echo -e "  - ${RED}${port}${NC}"
        done
        echo ""
        echo -e "${YELLOW}To resolve:${NC}"
        echo -e "1. Edit: ${BLUE}${SCRIPT_DIR}/.env-bitoarch.default${NC}"
        echo -e "2. Change the conflicting port values"
        echo -e "3. Re-run: ${BLUE}./setup.sh${NC}"
        echo ""
        exit 1
    fi
    
    print_status "All required Ports are available"
}

# Setup environment variables for CONFIG_URL (used by setup_configuration)
setup_env_for_config() {
    local deployment_type=$(get_deployment_type)
    
    if [ "$deployment_type" = "kubernetes" ]; then
        # Kubernetes: source .env-bitoarch for credentials, then set CONFIG_URL
        if [ -f "$ENV_FILE" ]; then
            source "$ENV_FILE"
        fi
        
        # Read port from .env-bitoarch.default if not set
        if [ -z "$CIS_CONFIG_EXTERNAL_PORT" ] && [ -f "${SCRIPT_DIR}/.env-bitoarch.default" ]; then
            CIS_CONFIG_EXTERNAL_PORT=$(grep "^CIS_CONFIG_EXTERNAL_PORT=" "${SCRIPT_DIR}/.env-bitoarch.default" 2>/dev/null | cut -d'=' -f2 || echo "5003")
        fi
        CIS_CONFIG_EXTERNAL_PORT=${CIS_CONFIG_EXTERNAL_PORT:-5003}
        
        # Port-forwards work through localhost regardless of cluster type (KIND, GKE, etc.)
        local config_host="localhost"
        local namespace="bito-ai-architect"
        
        # CRITICAL FIX: Wait for pods to be ready BEFORE setting up port-forwards
        # This ensures services are operational before API calls
        print_info "Waiting for pods to be ready after restart..."
        if wait_for_k8s_services "$namespace" 180; then
            print_status "All pods are ready"
        else
            print_warning "Some pods may still be initializing"
        fi
        
        # Clean up any stale port-forwards before creating new ones
        # (especially important after --force-restart when old pods are terminated)
        print_info "Cleaning up old port-forwards..."
        pkill -f "kubectl.*port-forward.*${namespace}" 2>/dev/null || true
        sleep 2  # Brief pause to let processes die
        
        # Now setup port-forwards to healthy pods
        setup_port_forwards "$namespace"
        
        export CONFIG_URL="http://${config_host}:${CIS_CONFIG_EXTERNAL_PORT}"
        export CIS_CONFIG_EXTERNAL_PORT
        export DEPLOYMENT_TYPE="kubernetes"
    else
        # Docker: source .env-bitoarch and export necessary variables
        if [ -f "$ENV_FILE" ]; then
            source "$ENV_FILE"
            export CONFIG_URL="http://localhost:${CIS_CONFIG_EXTERNAL_PORT}"
            export DEPLOYMENT_TYPE="docker-compose"
        fi
    fi
}

# Ask user for deployment method
ask_deployment_method() {
    # Check if deployment type already exists (from previous setup)
    local existing_deployment=$(get_deployment_type)
    
    if [ "$existing_deployment" != "unknown" ]; then
        local deployment_display=""
        if [ "$existing_deployment" = "kubernetes" ]; then
            deployment_display="Kubernetes"
        else
            deployment_display="Docker Compose"
        fi
        
        print_info "Using existing deployment method: $deployment_display"
        DEPLOYMENT_METHOD="$existing_deployment"
        
        # Re-validate K8s prerequisites if kubernetes
        if [ "$DEPLOYMENT_METHOD" = "kubernetes" ]; then
            if ! check_k8s_prerequisites; then
                render_k8s_not_available_block
                exit 1
            fi
        fi
        return 0
    fi
    
    echo ""
    echo -e "${BLUE}=== Deployment Method ===${NC}"
    echo "Choose how to deploy Bito's AI Architect:"
    echo "  1) Docker Compose"
    echo "  2) Kubernetes (requires existing K8s cluster)"
    echo ""

    local choice=""
    read -p "Select deployment method [1-2, default: 1]: " choice
    choice=${choice:-1}

    case $choice in
        1)
            DEPLOYMENT_METHOD="docker-compose"
            print_info "Selected: Docker Compose"
            save_deployment_type "docker-compose"
            return 0
            ;;
        2)
            DEPLOYMENT_METHOD="kubernetes"
            print_info "Selected: Kubernetes"

            # Check K8s prerequisites (with auto-install)
            if ! check_k8s_prerequisites; then
                render_k8s_not_available_block
                exit 1
            fi
            
            save_deployment_type "kubernetes"
            return 0
            ;;
        *)
            print_warning "Invalid choice, using Docker Compose"
            DEPLOYMENT_METHOD="docker-compose"
            save_deployment_type "docker-compose"
            return 0
            ;;
    esac
}

# Deploy to Kubernetes
deploy_kubernetes() {
    print_info "Deploying to Kubernetes..."
    
    # Source values-generator functions
    source "${SCRIPT_DIR}/scripts/values-generator.sh"
    
    # Extract latest provider default.json from image to update helm chart ConfigMap
    # This ensures fresh K8s deployments have the latest config from the image
    print_info "Extracting latest provider configuration from image..."

    # Source env to get provider image
    if [ -f "$ENV_FILE" ]; then
        source "$ENV_FILE"
    fi

    local provider_image="${CIS_PROVIDER_IMAGE:-}"
    local helm_config_path="${SCRIPT_DIR}/helm-bitoarch/services/cis-provider/config/default.json"

    if [ -n "$provider_image" ]; then
        # Pull the image first to ensure we have the latest
        if docker pull "$provider_image" >> "$LOG_FILE" 2>&1; then
            # Create temp container and extract config
            if docker create --name temp-provider-config-fresh "$provider_image" >/dev/null 2>&1; then
                if docker cp temp-provider-config-fresh:/opt/bito/xmcp/config/default.json "$helm_config_path" 2>> "$LOG_FILE"; then
                    print_status "Provider configuration extracted for Helm chart"
                else
                    print_warning "Could not extract provider config from image, using packaged config"
                fi
                docker rm temp-provider-config-fresh >/dev/null 2>&1 || true
            else
                print_warning "Could not create temp container for config extraction"
            fi
        else
            print_warning "Could not pull provider image for config extraction, using packaged config"
        fi
    else
        print_warning "Provider image not set, using packaged config"
    fi

    # Generate K8s values file from .env-bitoarch
    print_info "Generating Kubernetes values from environment configuration..."

    # Get values file path from path-manager
    local values_file
    if type get_k8s_values_file >/dev/null 2>&1; then
        values_file=$(get_k8s_values_file)
    else
        values_file="${SCRIPT_DIR}/.bitoarch-values.yaml"
    fi
    
    if ! generate_k8s_values_from_env; then
        print_error "Failed to generate Kubernetes values"
        return 1
    fi
    
    print_status "Generated Kubernetes values file: $values_file"
    
    # Deploy via Helm
    local namespace="bito-ai-architect"
    local chart_dir="${SCRIPT_DIR}/helm-bitoarch"
    
    if [ ! -f "$values_file" ]; then
        print_error "Values file not found: $values_file"
        return 1
    fi
    
    # Deploy
    if deploy_helm_chart "$chart_dir" "$values_file" "$namespace"; then
        if wait_for_k8s_services "$namespace"; then
            print_status "Kubernetes deployment successful"
            get_k8s_service_status "$namespace"
            get_k8s_endpoints "$namespace"
            return 0
        else
            print_error "Kubernetes services failed to become ready"
            return 1
        fi
    else
        print_error "Helm deployment failed"
        return 1
    fi
}

main() {
    # Set up traps only for main deployment flow
    trap cleanup_on_error ERR
    trap cleanup_on_sigint SIGINT
    trap cleanup_on_sigterm SIGTERM
    echo -e "${BLUE}Bito's AI Architect - Installation${NC}"
    echo "===================================="
    echo ""

    # CRITICAL FIX: Create standard directories BEFORE any file operations
    # This prevents "No such file or directory" errors when saving deployment type
    local layout=$(get_layout)
    if [ "$layout" = "system" ] || [ "$layout" = "user" ]; then
        if ! create_standard_dirs "$layout" 2>/dev/null; then
            print_warning "Failed to create $layout directories, falling back to user layout"
            # Force user layout fallback
            export BITOARCH_LAYOUT="user"
            init_paths
            ENV_FILE="$(get_config_file)"
            ENV_LLM_FILE="$(get_llm_config_file)"
            LOG_FILE="$(get_setup_log)"
            if ! create_standard_dirs "user" 2>/dev/null; then
                print_error "Cannot create user directories, installation cannot proceed"
                exit 1
            fi
            log_silent "Forced fallback to user layout at ~/.local/bitoarch"
        fi
    fi

    # Ensure log directory exists before creating log file
    mkdir -p "$(dirname "$LOG_FILE")" 2>/dev/null || {
        if command -v sudo >/dev/null 2>&1; then
            sudo mkdir -p "$(dirname "$LOG_FILE")"
            sudo chown -R "$USER:$(id -gn)" "$(dirname "$LOG_FILE")"
        fi
    }

    touch "$LOG_FILE"

    touch "$LOG_FILE"
    log_silent "Bito's AI Architect setup started at $(date)"
    log_silent "Working directory: $SCRIPT_DIR"
    log_silent "Log file: $LOG_FILE"
    log_silent "Using layout: $(get_layout)"
    log_silent "Config directory: $(get_config_dir)"

    # Check if migration from legacy installation is needed
    if needs_migration && [ ! -f "$ENV_FILE" ]; then
        print_info "Legacy installation detected - migration will occur during first setup"
        log_silent "Migration will be triggered: legacy layout detected"
    fi

    check_prerequisites
    install_cli

    # Auto-migrate if this is an upgrade from legacy installation
    if needs_migration && [ -f "${PLATFORM_DIR}/.env-bitoarch" ]; then
        print_info "Migrating from legacy installation to standard Unix paths..."
        if "${SCRIPT_DIR}/scripts/migrate-to-standard-paths.sh" --auto; then
            print_status "Migration completed successfully"
            # Reinitialize paths after migration
            init_paths
            ENV_FILE="$(get_config_file)"
            ENV_LLM_FILE="$(get_llm_config_file)"
            LOG_FILE="$(get_setup_log)"
        else
            print_error "Migration failed"
            exit 1
        fi
    fi

    check_existing_services
    
    # Ask for deployment method
    ask_deployment_method
    
    # Check ports based on deployment method (before collecting credentials)
    if [ "$DEPLOYMENT_METHOD" = "kubernetes" ]; then
        check_k8s_external_ports
    else
        check_docker_ports
    fi
    
    # CRITICAL: Create directories BEFORE generating env file
    # This ensures /usr/local/etc/bitoarch/ exists before we try to copy files there
    prepare_data_directories

    # Now collect credentials (only if ports are available)
    generate_env_file
    
    # Deploy based on selected method
    if [ "$DEPLOYMENT_METHOD" = "kubernetes" ]; then
        # Kubernetes deployment path
        log_silent "Deployment method: Kubernetes"
        
        if deploy_kubernetes; then
            # Kubernetes deployment: Always use localhost with port-forwards
            local namespace="bito-ai-architect"
            local config_host="localhost"
            
            # Read port from .env-bitoarch if available
            if [ -f "$ENV_FILE" ]; then
                source "$ENV_FILE"
            fi
            if [ -z "$CIS_CONFIG_EXTERNAL_PORT" ] && [ -f "${SCRIPT_DIR}/.env-bitoarch.default" ]; then
                CIS_CONFIG_EXTERNAL_PORT=$(grep "^CIS_CONFIG_EXTERNAL_PORT=" "${SCRIPT_DIR}/.env-bitoarch.default" 2>/dev/null | cut -d'=' -f2 || echo "5003")
            fi
            CIS_CONFIG_EXTERNAL_PORT=${CIS_CONFIG_EXTERNAL_PORT:-5003}
            
            # Export CONFIG_URL with localhost (port-forwards work on all K8s clusters)
            export CONFIG_URL="http://${config_host}:${CIS_CONFIG_EXTERNAL_PORT}"
            export CIS_CONFIG_EXTERNAL_PORT
            export DEPLOYMENT_TYPE="kubernetes"
            
            # CRITICAL: Verify pods are still ready before setting up port-forwards
            # (they should be from deploy_kubernetes, but double-check for reliability)
            print_info "Verifying pods are ready before configuration..."
            if wait_for_k8s_services "$namespace" 60; then
                print_status "All pods confirmed ready"
            else
                print_warning "Some pods may still be initializing"
            fi
            
            # Setup port-forwards for CLI access to healthy pods
            setup_port_forwards "bito-ai-architect"
            
            # Capture return code without triggering set -e error trap
            local config_result=0
            setup_configuration || config_result=$?

            # Only show full success block for fresh setups (return 0 or 1)
            # Skip for existing config unchanged (return 2)
            if [ $config_result -ne 2 ]; then
                display_success
                log_silent "Bito's AI Architect setup completed successfully at $(date)"
            else
                # User declined reconfiguration - exit cleanly
                log_silent "Repository configuration unchanged - setup completed at $(date)"
                exit 0
            fi
        else
            print_error "Kubernetes deployment failed"
            print_info "Check detailed logs: $LOG_FILE"
            exit 1
        fi
    else
        # Docker Compose deployment path (existing flow)
        log_silent "Deployment method: Docker Compose"

        prepare_service_sql_scripts  # Copy service SQL scripts to MySQL init directory
        deploy_services
        
        if wait_for_services; then
            validate_deployment
            render_deploy_success_banner        

            setup_configuration
            local config_result=$?
            # Only show full success block for fresh setups (return 0 or 1)
            # Skip for existing config unchanged (return 2)
            if [ $config_result -ne 2 ]; then
                display_success
            fi
            
            log_silent "Bito's AI Architect setup completed successfully at $(date)"
        else
            echo ""
            print_error "Service health check failed"
            print_info "Check detailed logs: $LOG_FILE"
            print_info "View service logs: ${DOCKER_COMPOSE_CMD:-docker-compose} logs"
            
            # Show CLI installation status
            local cli_target="$HOME/.local/bin/bitoarch"
            if [ -L "$cli_target" ] || [ -f "$cli_target" ]; then
                echo ""
                print_status "CLI installed to ~/.local/bin/bitoarch"
                print_info "To activate: source ~/.${SHELL##*/}rc (or restart terminal)"
            fi
            
            exit 1
        fi
    fi
}

show_status() {
    echo -e "${BLUE}AI Architect - Service Status${NC}"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo ""
    
    local running_services=$(docker ps -q --filter "name=ai-architect-" 2>/dev/null | wc -l)
    
    if [ "$running_services" -eq 0 ]; then
        print_warning "No AI Architect services are currently running"
        echo ""
        print_info "To start services, run: ./setup.sh"
        return 0
    fi
    
    local services=(
        "ai-architect-mysql:MySQL Database:3306"
        "ai-architect-config:AI Architect Config:8081"
        "ai-architect-manager:AI Architect Manager:9090"
        "ai-architect-provider:AI Architect Provider:8080"
        "ai-architect-tracker:AI Architect Tracker:9920"
    )
    
    echo -e "${BLUE}📊 Service Health & Status${NC}"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    
    for service_info in "${services[@]}"; do
        local container_name=$(echo "$service_info" | cut -d: -f1)
        local display_name=$(echo "$service_info" | cut -d: -f2)
        local port=$(echo "$service_info" | cut -d: -f3)
        
        if ! docker ps -a --format '{{.Names}}' | grep -q "^${container_name}$"; then
            printf "   %-25s ${YELLOW}➖ Not Created${NC}\n" "$display_name"
            continue
        fi
        
        local status=$(docker inspect --format='{{.State.Status}}' "$container_name" 2>/dev/null || echo "unknown")
        local health=$(docker inspect --format='{{.State.Health.Status}}' "$container_name" 2>/dev/null || echo "no_health")
        
        local running_time=0
        local started_at=$(docker inspect --format='{{.State.StartedAt}}' "$container_name" 2>/dev/null)
        
        if [ -n "$started_at" ] && [ "$started_at" != "0001-01-01T00:00:00Z" ]; then
            local clean_time=$(echo "$started_at" | sed 's/\.[0-9]*Z$/Z/')
            
            local start_epoch=""
            if [[ "$OSTYPE" == "darwin"* ]]; then
                local time_no_z=$(echo "$clean_time" | sed 's/Z$//')
                start_epoch=$(date -u -j -f "%Y-%m-%dT%H:%M:%S" "$time_no_z" "+%s" 2>/dev/null || echo "")
            else
                start_epoch=$(date -d "$clean_time" "+%s" 2>/dev/null || echo "")
            fi
            
            if [ -n "$start_epoch" ] && [ "$start_epoch" -gt 0 ]; then
                local now=$(date +%s)
                running_time=$((now - start_epoch))
            fi
        fi
        
        local uptime_str=""
        if [ "$running_time" -gt 0 ]; then
            if [ "$running_time" -lt 60 ]; then
                uptime_str="${running_time}s"
            elif [ "$running_time" -lt 3600 ]; then
                uptime_str="$((running_time / 60))m"
            else
                uptime_str="$((running_time / 3600))h"
            fi
        fi
        
        case "$status" in
            "running")
                if [[ "$health" == "healthy" ]]; then
                    printf "   %-25s ${GREEN}✅ Healthy${NC}      (up ${uptime_str}, port ${port})\n" "$display_name"
                elif [[ "$health" == "starting" ]]; then
                    printf "   %-25s ${YELLOW}⏳ Starting${NC}     (up ${uptime_str}, port ${port})\n" "$display_name"
                elif [[ "$health" == "unhealthy" ]]; then
                    printf "   %-25s ${RED}⚠️  Unhealthy${NC}   (up ${uptime_str}, port ${port})\n" "$display_name"
                else
                    printf "   %-25s ${GREEN}✅ Running${NC}      (up ${uptime_str}, port ${port})\n" "$display_name"
                fi
                ;;
            "restarting")
                printf "   %-25s ${YELLOW}🔄 Restarting${NC}   (port ${port})\n" "$display_name"
                ;;
            "exited"|"dead")
                printf "   %-25s ${RED}⏹️  Stopped${NC}      (port ${port})\n" "$display_name"
                ;;
            "created")
                printf "   %-25s ${YELLOW}📦 Created${NC}      (port ${port})\n" "$display_name"
                ;;
            *)
                printf "   %-25s ${YELLOW}❓ Unknown${NC}      (port ${port})\n" "$display_name"
                ;;
        esac
    done
    
    echo ""
    echo -e "${BLUE}🔧 Quick Commands${NC}"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo -e "  • View logs:                 ${YELLOW}./setup.sh --logs${NC}"
    echo -e "  • Restart services:          ${YELLOW}./setup.sh --restart${NC}"
    echo -e "  • Force Restart services:    ${YELLOW}./setup.sh --force-restart${NC}"
    echo -e "  • Stop services:             ${YELLOW}./setup.sh --stop${NC}"
    echo -e "  • Detailed status:           ${YELLOW}docker compose ps${NC}"
    echo ""
}

show_help() {
    echo "AI Architect Setup Script"
    echo ""
    echo "Usage: $0 [options]"
    echo ""
    echo "Options:"
    echo "  --help, -h        Show this help message"
    echo "  --status          Show current service status"
    echo "  --logs            Show service logs"
    echo "  --stop            Stop all services (preserves containers)"
    echo "  --restart         Restart all services"
    echo "  --force-restart   Restart all services and reapply env variables"
    echo "  --update          Force pull latest images based on service-versions.json and restart services"
    echo "  --clean           Remove all data and services"
    echo ""
}

case "${1:-}" in
    --help|-h)
        show_help
        ;;
    --status)
        # Check deployment type
        DEPLOYMENT_TYPE=$(get_deployment_type)
        
        if [ "$DEPLOYMENT_TYPE" = "kubernetes" ]; then
            # Kubernetes status
            namespace="bito-ai-architect"
            get_k8s_service_status "$namespace"
            get_k8s_endpoints "$namespace"
        else
            # Docker Compose status
            show_status
        fi
        ;;
    --logs)
        # Check deployment type
        DEPLOYMENT_TYPE=$(get_deployment_type)
        
        if [ "$DEPLOYMENT_TYPE" = "kubernetes" ]; then
            # Kubernetes logs
            namespace="bito-ai-architect"
            get_k8s_logs "$namespace" "" "true"
        else
            # Docker Compose logs
            compose_cmd="${DOCKER_COMPOSE_CMD:-}"
            if [ -z "$compose_cmd" ]; then
                if command -v docker >/dev/null 2>&1 && docker compose version >/dev/null 2>&1; then
                    compose_cmd="docker compose"
                elif command -v docker-compose >/dev/null 2>&1; then
                    compose_cmd="docker-compose"
                else
                    print_error "Neither 'docker compose' nor 'docker-compose' found"
                    exit 1
                fi
            fi
            eval "${compose_cmd} --env-file \"${ENV_FILE}\" logs -f"
        fi
        ;;
    --stop)
        print_info "Stopping Bito's AI Architect services..."
        
        # Check deployment type
        DEPLOYMENT_TYPE=$(get_deployment_type)
        
        if [ "$DEPLOYMENT_TYPE" = "kubernetes" ]; then
            # Kubernetes stop (scale to 0 + delete services to free NodePorts)
            namespace="bito-ai-architect"
            print_info "Stopping Kubernetes deployment..."
            
            # Kill port-forwards first (so they don't point to deleted pods)
            if command -v kill_port_forwards >/dev/null 2>&1; then
                kill_port_forwards "$namespace"
            else
                # Inline cleanup if function not available
                PF_PIDS=$(ps aux | grep "kubectl port-forward" | grep -E "(-n |--namespace=|-n=)$namespace" | grep -v grep | awk '{print $2}')
                if [ -n "$PF_PIDS" ]; then
                    print_info "Terminating port-forwards..."
                    echo "$PF_PIDS" | xargs kill -9 2>/dev/null || true
                fi
            fi
            
            if kubectl scale deployment --all --replicas=0 -n "$namespace" >/dev/null 2>&1; then
                print_info "Pods stopped (scaled to 0 replicas)"
            else
                print_warning "Failed to scale deployments"
            fi
            
            # Delete services to free NodePorts (matching Docker Compose behavior)
            if kubectl delete svc --all -n "$namespace" >/dev/null 2>&1; then
                print_status "Services deleted - NodePorts freed"
            else
                print_warning "Failed to delete services"
            fi
            
            print_status "Kubernetes deployment stopped"
        else
            # Docker Compose stop
            compose_cmd="${DOCKER_COMPOSE_CMD:-}"
            if [ -z "$compose_cmd" ]; then
                if command -v docker >/dev/null 2>&1 && docker compose version >/dev/null 2>&1; then
                    compose_cmd="docker compose"
                elif command -v docker-compose >/dev/null 2>&1; then
                    compose_cmd="docker-compose"
                else
                    print_error "Neither 'docker compose' nor 'docker-compose' found"
                    exit 1
                fi
            fi
            
            # Stop services (preserve containers for quick restart)
            if [ -f "${SCRIPT_DIR}/.env-bitoarch" ]; then
                if eval "$compose_cmd --env-file .env-bitoarch stop" >> "$LOG_FILE" 2>&1; then
                    print_status "Services stopped (containers preserved)"
                else
                    print_error "Failed to stop services"
                    print_info "Trying force stop..."
                    eval "$compose_cmd --env-file .env-bitoarch kill" >> "$LOG_FILE" 2>&1 || true
                fi
            else
                # No env file, try without it
                if eval "$compose_cmd stop" >> "$LOG_FILE" 2>&1; then
                    print_status "Services stopped (containers preserved)"
                else
                    print_error "Failed to stop services"
                    print_info "Trying force stop..."
                    eval "$compose_cmd kill" >> "$LOG_FILE" 2>&1 || true
                fi
            fi
        fi
        
        render_stop_complete_block
        ;;
    --clean)
        print_warning "${YELLOW} This will remove ALL data including databases and configurations!${NC}"
        read -p "Are you sure you want to continue? Type 'yes' to confirm: " -r REPLY
        echo ""
        
        if [[ "$REPLY" != "yes" ]]; then
            print_info "Clean operation cancelled"
            exit 0
        fi
        
        print_info "Stopping services and removing all data..."
        
        # Check deployment type
        DEPLOYMENT_TYPE=$(get_deployment_type)
        
        if [ "$DEPLOYMENT_TYPE" = "kubernetes" ]; then
            # Kubernetes cleanup
            namespace="bito-ai-architect"
            uninstall_helm_release "$namespace" "bitoarch" "true"
        else
            # Docker Compose cleanup
            compose_cmd="${DOCKER_COMPOSE_CMD:-}"
            if [ -z "$compose_cmd" ]; then
                if command -v docker >/dev/null 2>&1 && docker compose version >/dev/null 2>&1; then
                    compose_cmd="docker compose"
                elif command -v docker-compose >/dev/null 2>&1; then
                    compose_cmd="docker-compose"
                else
                    print_error "Neither 'docker compose' nor 'docker-compose' found"
                    exit 1
                fi
            fi
            
            # CRITICAL: Stop services and remove volumes BEFORE removing .env-bitoarch file
            # Must use --env-file while it still exists to properly identify project volumes
            # Check for config file using $ENV_FILE (supports both standard and legacy paths)
            if [ -f "$ENV_FILE" ]; then
                if eval "$compose_cmd --env-file \"$ENV_FILE\" down --remove-orphans --volumes" >> "$LOG_FILE" 2>&1; then
                    print_status "Services and volumes removed"
                else
                    print_warning "Failed with env file, trying without..."
                    eval "$compose_cmd down --remove-orphans --volumes" >> "$LOG_FILE" 2>&1 || true
                fi
            elif [ -f "${SCRIPT_DIR}/.env-bitoarch" ]; then
                # Fallback: try symlink location
                if eval "$compose_cmd --env-file .env-bitoarch down --remove-orphans --volumes" >> "$LOG_FILE" 2>&1; then
                    print_status "Services and volumes removed"
                else
                    print_warning "Failed with env file, trying without..."
                    eval "$compose_cmd down --remove-orphans --volumes" >> "$LOG_FILE" 2>&1 || true
                fi
            else
                # No env file found, try without it
                eval "$compose_cmd down --remove-orphans --volumes" >> "$LOG_FILE" 2>&1 || true
            fi
        fi
        
        # Remove local data directories (handle root-owned directories from Docker)
        print_info "Removing local data directories..."
        
        dirs_to_clean=(
            "${SCRIPT_DIR}/var/logs/"
            "${SCRIPT_DIR}/services/cis-provider/data/"
            "${SCRIPT_DIR}/services/cis-provider/metadata/"
        )
        
        cleanup_failed=false
        for dir in "${dirs_to_clean[@]}"; do
            if [ -d "$dir" ]; then
                # Try normal removal first
                if rm -rf "${dir}"* 2>/dev/null; then
                    log_silent "Cleaned: $dir"
                else
                    # If normal removal fails, try with sudo
                    if command -v sudo >/dev/null 2>&1; then
                        print_info "Some directories require elevated permissions, using sudo..."
                        if sudo rm -rf "${dir}"* 2>/dev/null; then
                            log_silent "Cleaned with sudo: $dir"
                        else
                            print_warning "Failed to clean: $dir"
                            cleanup_failed=true
                        fi
                    else
                        print_warning "Could not remove some directories in $dir (may be root-owned)"
                        print_info "Run manually: sudo rm -rf ${dir}*"
                        cleanup_failed=true
                    fi
                fi
            fi
        done
        
        if [ "$cleanup_failed" = true ]; then
            echo ""
            print_warning "Some directories could not be removed automatically"
            print_info "This typically happens when Docker created them as root"
            print_info "To complete cleanup, run: sudo rm -rf ${SCRIPT_DIR}/var/logs/* ${SCRIPT_DIR}/services/cis-provider/data/* ${SCRIPT_DIR}/services/cis-provider/metadata/*"
            echo ""
        fi
        
        # Remove copied SQL scripts from MySQL init directory
        print_info "Removing copied service SQL scripts..."
        rm -f "${SCRIPT_DIR}/services/mysql/init/02-cis-config-"*.sql 2>/dev/null || true
        rm -f "${SCRIPT_DIR}/services/mysql/init/03-cis-manager-"*.sql 2>/dev/null || true
        
        # Clean up config files from standard Unix paths (using path-manager)
        print_info "Cleaning up configuration files..."

        # Get actual file locations from path-manager
        actual_env_file=$(get_config_file)
        actual_llm_file=$(get_llm_config_file)
        actual_deployment_file=$(get_deployment_type_file)
        actual_repo_config=$(get_repo_config_file)

        # Backup and remove LLM env file
        if [ -f "$actual_llm_file" ]; then
            backup_name=".env-llm-bitoarch.backup.$(date +%Y%m%d_%H%M%S)"
            cp "$actual_llm_file" "${SCRIPT_DIR}/${backup_name}" 2>/dev/null || true
            rm -f "$actual_llm_file" 2>/dev/null || true
            print_info "Backed up .env-llm-bitoarch to ${backup_name}"
        fi

        # Backup and remove main env file
        if [ -f "$actual_env_file" ]; then
            backup_name=".env-bitoarch.backup.$(date +%Y%m%d_%H%M%S)"
            cp "$actual_env_file" "${SCRIPT_DIR}/${backup_name}" 2>/dev/null || true
            rm -f "$actual_env_file" 2>/dev/null || true
            print_info "Backed up .env-bitoarch to ${backup_name}"
            print_info "Contains your API keys (Bito API Key, Git Access Token) and auto-generated secrets"
            print_info "Note: All auto-generated secrets will be regenerated on next setup for security"
        fi

        # Remove deployment type file
        if [ -f "$actual_deployment_file" ]; then
            rm -f "$actual_deployment_file" 2>/dev/null || true
            print_info "Removed deployment type marker"
        fi

        # Remove repository configuration file
        if [ -f "$actual_repo_config" ]; then
            rm -f "$actual_repo_config" 2>/dev/null || true
            print_info "Removed repository configuration"
        fi

        # Also remove legacy locations and symlinks
        rm -f "${SCRIPT_DIR}/.env-bitoarch" 2>/dev/null || true
        rm -f "${SCRIPT_DIR}/.env-llm-bitoarch" 2>/dev/null || true
        rm -f "${SCRIPT_DIR}/.deployment-type" 2>/dev/null || true
        rm -f "${SCRIPT_DIR}/.bitoarch-config.yaml" 2>/dev/null || true

        # Remove Kubernetes values file for fresh generation
        if [ -f "${SCRIPT_DIR}/.bitoarch-values.yaml" ]; then
            rm -f "${SCRIPT_DIR}/.bitoarch-values.yaml" 2>/dev/null || true
            print_info "Removed Kubernetes values file"
        fi

        # Remove setup.log
        if [ -f "${SCRIPT_DIR}/setup.log" ]; then
            rm -f "${SCRIPT_DIR}/setup.log" 2>/dev/null || true
        fi
        
        # Uninstall CLI
        uninstall_cli
        
        render_clean_complete_block "All containers" "All volumes"
        ;;
    --from-existing-config)
        print_info "Starting AI Architect with existing configuration..."
        
        # Check if config exists
        if [[ ! -f ".env-bitoarch" ]]; then
            print_error "No existing configuration found (.env-bitoarch missing)"
            exit 1
        fi
        
        # Must call check_prerequisites to initialize DOCKER_COMPOSE_CMD
        check_prerequisites
        install_cli
        check_existing_services
        check_ports
        prepare_data_directories
        prepare_service_sql_scripts
        
        # Now deploy with existing config
        deploy_services
        
        if wait_for_services; then
            validate_deployment
            print_status "Services started successfully with existing configuration"
        else
            print_error "Service health check failed"
            exit 1
        fi
        exit 0
        ;;
    --restart)
        print_info "Restarting AI Architect services..."
        
        # Check deployment type
        DEPLOYMENT_TYPE=$(get_deployment_type)
        
        if [ "$DEPLOYMENT_TYPE" = "kubernetes" ]; then
            namespace="bito-ai-architect"
            
            # Check if services exist (trim whitespace from wc -l for macOS/Linux compatibility)
            svc_count=$(kubectl get svc -n "$namespace" 2>/dev/null | wc -l | xargs)
            
            if [ "$svc_count" -le 1 ]; then
                # Services were deleted (only header line), need to redeploy via Helm
                print_info "Services were stopped, redeploying..."
                
                # Source values-generator to regenerate if needed
                source "${SCRIPT_DIR}/scripts/values-generator.sh"
                
                # Check if values file exists, regenerate if not
                if [ ! -f "${SCRIPT_DIR}/.bitoarch-values.yaml" ]; then
                    print_info "Regenerating Kubernetes values..."
                    if ! generate_k8s_values_from_env; then
                        print_error "Failed to generate Kubernetes values"
                        exit 1
                    fi
                fi
                
                # Redeploy via Helm (will recreate services and scale up)
                if helm upgrade bitoarch "${SCRIPT_DIR}/helm-bitoarch" \
                    --namespace "$namespace" \
                    --values "${SCRIPT_DIR}/.bitoarch-values.yaml" \
                    --wait \
                    --timeout 5m >/dev/null 2>&1; then
                    print_status "Services redeployed successfully"
                else
                    print_error "Failed to redeploy services"
                    exit 1
                fi
            else
                # Services exist, just restart pods
                echo ""
                print_info "Restarting deployments in order..."
                
                # Restart all deployments at once (parallel for speed)
                if ! kubectl -n "$namespace" rollout restart deployment -l "app.kubernetes.io/name=bitoarch" >/dev/null 2>&1; then
                    echo ""
                    print_error "Failed to initiate restart"
                    print_info "Check logs: kubectl logs -n $namespace"
                    exit 1
                fi
                
                # Check status of each deployment individually for Docker-like output
                deployments=("ai-architect-mysql" "ai-architect-config" "ai-architect-manager" "ai-architect-provider" "ai-architect-tracker")
                restart_failed=false
                
                for deployment in "${deployments[@]}"; do
                    printf "   %-25s" "$deployment"
                    
                    # Tracker needs longer timeout due to init container dependencies on config/manager
                    timeout="3m"
                    if [[ "$deployment" == "ai-architect-tracker" ]]; then
                        timeout="10m"
                    fi
                    
                    # Check if deployment rolled out successfully
                    if kubectl rollout status deployment "$deployment" -n "$namespace" --timeout=$timeout >/dev/null 2>&1; then
                        printf "${GREEN}✅ Restarted${NC}\n"
                    else
                        printf "${YELLOW}⏱ Timeout${NC}\n"
                        restart_failed=true
                    fi
                done
                
                echo ""
                if [ "$restart_failed" = true ]; then
                    print_warning "Some deployments timed out"
                    print_info "Services may still be starting - check status: ./setup.sh --status"
                else
                    print_status "All deployments restarted successfully"
                    print_info "Check status: ./setup.sh --status"
                fi
            fi
            
            # Setup environment for config API calls (works for both Docker & K8s)
            setup_env_for_config
            
            # Ask if user wants to reconfigure repos after restart
            # Capture return code without triggering set -e error trap
            setup_configuration || true
        else
            # Docker Compose restart
            compose_cmd="${DOCKER_COMPOSE_CMD:-}"
            if [ -z "$compose_cmd" ]; then
                if command -v docker >/dev/null 2>&1 && docker compose version >/dev/null 2>&1; then
                    compose_cmd="docker compose"
                elif command -v docker-compose >/dev/null 2>&1; then
                    compose_cmd="docker-compose"
                else
                    print_error "Neither 'docker compose' nor 'docker-compose' found"
                    exit 1
                fi
            fi

            # Check if services are running
            running_services=$(docker ps -q --filter "name=ai-architect-" 2>/dev/null | wc -l)
            if [ "$running_services" -eq 0 ]; then
                print_warning "No CIS Platform services are currently running"
                print_info "Use './setup.sh' to start services"
                exit 0
            fi

            # Restart all services
            echo ""
            print_info "Restarting services in order..."

            services=("ai-architect-mysql" "ai-architect-config" "ai-architect-manager" "ai-architect-provider" "ai-architect-tracker")
            restart_failed=false

            for service in "${services[@]}"; do
                printf "   %-25s" "$service"
                if eval "$compose_cmd --env-file .env-bitoarch restart $service" >/dev/null 2>&1; then
                    printf "${GREEN}✅ Restarted${NC}\n"
                else
                    printf "${RED}❌ Failed${NC}\n"
                    restart_failed=true
                fi
            done
            
            echo ""
            if [ "$restart_failed" = true ]; then
                print_warning "Some services failed to restart"
                print_info "Check logs: ./setup.sh --logs"
                exit 1
            else
                print_status "All services restarted successfully"
                print_info "Check status: ./setup.sh --status"
            fi
            
            # Ask if user wants to reconfigure repos after restart
            setup_configuration
        fi
        ;;
      --force-restart)
        print_info "Force Restarting AI Architect services with config update..."

        # Check deployment type
        DEPLOYMENT_TYPE=$(get_deployment_type)
        
        if [ "$DEPLOYMENT_TYPE" = "kubernetes" ]; then
            # Kubernetes force restart with config update
            namespace="bito-ai-architect"
            
            print_info "Regenerating Kubernetes configuration from .env-bitoarch..."
            
            # Regenerate values from .env-bitoarch
            source "${SCRIPT_DIR}/scripts/values-generator.sh"
            if ! generate_k8s_values_from_env; then
                print_error "Failed to regenerate Kubernetes values"
                exit 1
            fi
            
            print_status "Configuration regenerated"
            
            # Apply updated configuration via Helm upgrade
            # Don't use --reuse-values with --values (contradictory flags cause conflicts)
            # Helm won't modify PVCs since their specs haven't changed - only ConfigMaps/Secrets are updated
            # Use get_k8s_values_file to get actual file path (supports standard Unix paths)
            k8s_values_file="$(get_k8s_values_file)"
            print_info "Applying configuration update via Helm..."
            if helm upgrade bitoarch "${SCRIPT_DIR}/helm-bitoarch" \
                --namespace "$namespace" \
                --values "$k8s_values_file" \
                --wait \
                --timeout 5m 2>&1 | tee -a "$LOG_FILE" | grep -q "has been upgraded"; then
                print_status "Configuration applied successfully"
            else
                print_warning "Helm upgrade may have timed out (check logs)"
                print_info "Continuing with pod restart..."
            fi
            
            echo ""
            print_info "Force restarting services with updated configuration..."
            
            deployments=("ai-architect-mysql" "ai-architect-config" "ai-architect-manager" "ai-architect-provider" "ai-architect-tracker")
            restart_failed=false
            
                for deployment in "${deployments[@]}"; do
                    printf "   %-25s" "$deployment"
                    
                    # Tracker needs longer timeout due to init container dependencies on config/manager
                    timeout="3m"
                    if [[ "$deployment" == "ai-architect-tracker" ]]; then
                        timeout="10m"
                    fi
                    
                    # Restart deployment
                    if kubectl rollout restart deployment "$deployment" -n "$namespace" >/dev/null 2>&1; then
                        # Wait for rollout to complete
                        if kubectl rollout status deployment "$deployment" -n "$namespace" --timeout=$timeout >/dev/null 2>&1; then
                            printf "${GREEN}✅ Restarted${NC}\n"
                        else
                            printf "${YELLOW}⏱ Timeout${NC}\n"
                            restart_failed=true
                        fi
                    else
                        printf "${RED}❌ Failed${NC}\n"
                        restart_failed=true
                    fi
                done
            
            echo ""
            if [ "$restart_failed" = true ]; then
                print_warning "Some deployments failed or timed out"
                print_info "Check status: ./setup.sh --status"
            else
                print_status "All services force restarted successfully with updated configuration"
                print_info "Check status: ./setup.sh --status"
            fi
            
            # Setup environment for config API calls (works for both Docker & K8s)
            setup_env_for_config
            
            # Ask if user wants to reconfigure repos after restart
            # Capture return code without triggering set -e error trap
            setup_configuration || true
        else
            # Docker Compose force restart with config update
            
            # Determine docker compose command
            compose_cmd="${DOCKER_COMPOSE_CMD:-}"
            if [ -z "$compose_cmd" ]; then
                if command -v docker >/dev/null 2>&1 && docker compose version >/dev/null 2>&1; then
                    compose_cmd="docker compose"
                elif command -v docker-compose >/dev/null 2>&1; then
                    compose_cmd="docker-compose"
                else
                    print_error "Neither 'docker compose' nor 'docker-compose' found"
                    exit 1
                fi
            fi

            # Check if services are running
            running_services=$(docker ps -q --filter "name=ai-architect-" 2>/dev/null | wc -l)
            if [ "$running_services" -eq 0 ]; then
                print_warning "No AI Architect services are currently running"
                print_info "Use './setup.sh' to start services"
                exit 0
            fi

            # Force recreate all services with updated environment
            echo ""
            print_info "Force restarting services with updated configuration..."

            services=("ai-architect-mysql" "ai-architect-config" "ai-architect-manager" "ai-architect-provider" "ai-architect-tracker")
            restart_failed=false

            for service in "${services[@]}"; do
                printf "   %-25s" "$service"

                if eval "$compose_cmd --env-file .env-bitoarch up -d --force-recreate $service" >/dev/null 2>&1; then
                    printf "${GREEN}✅ Restarted${NC}\n"
                else
                    printf "${RED}❌ Failed${NC}\n"
                    restart_failed=true
                fi
            done

            echo ""
            if [ "$restart_failed" = true ]; then
                print_warning "Some services failed to force restart"
                print_info "Check logs: ./setup.sh --logs"
                exit 1
            else
                print_status "All services force restarted successfully with updated configuration"
                print_info "Check status: ./setup.sh --status"
            fi
            
            # Ask if user wants to reconfigure repos after restart
            setup_configuration
        fi
        ;;
    --update)
        print_info "Updating AI Architect - Force pulling latest images and restarting services..."
        
        # Check deployment type
        DEPLOYMENT_TYPE=$(get_deployment_type)
        
        # Load service versions from versions/service-versions.json
        versions_file="${SCRIPT_DIR}/versions/service-versions.json"
        if [ ! -f "$versions_file" ]; then
            print_error "versions/service-versions.json not found"
            exit 1
        fi
        
        if [ "$DEPLOYMENT_TYPE" = "kubernetes" ]; then
            # Kubernetes update
            namespace="bito-ai-architect"
            
            print_info "Pulling latest images for Kubernetes deployment..."
            echo ""
            
            # Read versions and images from service-versions.json
            if command -v jq >/dev/null 2>&1; then
                CIS_CONFIG_VERSION=$(jq -r '.services."cis-config".version' "$versions_file" 2>/dev/null || echo "latest")
                CIS_CONFIG_IMAGE_BASE=$(jq -r '.services."cis-config".image' "$versions_file" 2>/dev/null || echo "docker.io/bitoai/cis-config")
                
                CIS_MANAGER_VERSION=$(jq -r '.services."cis-manager".version' "$versions_file" 2>/dev/null || echo "latest")
                CIS_MANAGER_IMAGE_BASE=$(jq -r '.services."cis-manager".image' "$versions_file" 2>/dev/null || echo "docker.io/bitoai/cis-manager")
                
                CIS_PROVIDER_VERSION=$(jq -r '.services."cis-provider".version' "$versions_file" 2>/dev/null || echo "latest")
                CIS_PROVIDER_IMAGE_BASE=$(jq -r '.services."cis-provider".image' "$versions_file" 2>/dev/null || echo "docker.io/bitoai/cis-provider")
                
                CIS_TRACKER_VERSION=$(jq -r '.services."cis-tracker".version' "$versions_file" 2>/dev/null || echo "latest")
                CIS_TRACKER_IMAGE_BASE=$(jq -r '.services."cis-tracker".image' "$versions_file" 2>/dev/null || echo "docker.io/bitoai/cis-tracker")
            else
                CIS_CONFIG_VERSION=$(grep -A 10 '"cis-config"' "$versions_file" | grep '"version"' | head -1 | cut -d'"' -f4 || echo "latest")
                CIS_CONFIG_IMAGE_BASE=$(grep -A 10 '"cis-config"' "$versions_file" | grep '"image"' | head -1 | cut -d'"' -f4 || echo "docker.io/bitoai/cis-config")
                
                CIS_MANAGER_VERSION=$(grep -A 10 '"cis-manager"' "$versions_file" | grep '"version"' | head -1 | cut -d'"' -f4 || echo "latest")
                CIS_MANAGER_IMAGE_BASE=$(grep -A 10 '"cis-manager"' "$versions_file" | grep '"image"' | head -1 | cut -d'"' -f4 || echo "docker.io/bitoai/cis-manager")
                
                CIS_PROVIDER_VERSION=$(grep -A 10 '"cis-provider"' "$versions_file" | grep '"version"' | head -1 | cut -d'"' -f4 || echo "latest")
                CIS_PROVIDER_IMAGE_BASE=$(grep -A 10 '"cis-provider"' "$versions_file" | grep '"image"' | head -1 | cut -d'"' -f4 || echo "docker.io/bitoai/cis-provider")
                
                CIS_TRACKER_VERSION=$(grep -A 10 '"cis-tracker"' "$versions_file" | grep '"version"' | head -1 | cut -d'"' -f4 || echo "latest")
                CIS_TRACKER_IMAGE_BASE=$(grep -A 10 '"cis-tracker"' "$versions_file" | grep '"image"' | head -1 | cut -d'"' -f4 || echo "docker.io/bitoai/cis-tracker")
            fi
            
            print_info "Target versions:"
            print_info "  AI Architect Config: $CIS_CONFIG_VERSION"
            print_info "  AI Architect Manager: $CIS_MANAGER_VERSION"
            print_info "  AI Architect Provider: $CIS_PROVIDER_VERSION"
            print_info "  AI Architect Tracker: $CIS_TRACKER_VERSION"
            echo ""
            
            # Update .env-bitoarch with new versions AND images (use real file, not symlink)
            env_config_file="$(get_config_file)"
            if [ -f "$env_config_file" ]; then
                sed -i.bak "s|^CIS_CONFIG_VERSION=.*|CIS_CONFIG_VERSION=${CIS_CONFIG_VERSION}|" "$env_config_file"
                sed -i.bak "s|^CIS_CONFIG_IMAGE=.*|CIS_CONFIG_IMAGE=${CIS_CONFIG_IMAGE_BASE}:${CIS_CONFIG_VERSION}|" "$env_config_file"
                
                sed -i.bak "s|^CIS_MANAGER_VERSION=.*|CIS_MANAGER_VERSION=${CIS_MANAGER_VERSION}|" "$env_config_file"
                sed -i.bak "s|^CIS_MANAGER_IMAGE=.*|CIS_MANAGER_IMAGE=${CIS_MANAGER_IMAGE_BASE}:${CIS_MANAGER_VERSION}|" "$env_config_file"
                
                sed -i.bak "s|^CIS_PROVIDER_VERSION=.*|CIS_PROVIDER_VERSION=${CIS_PROVIDER_VERSION}|" "$env_config_file"
                sed -i.bak "s|^CIS_PROVIDER_IMAGE=.*|CIS_PROVIDER_IMAGE=${CIS_PROVIDER_IMAGE_BASE}:${CIS_PROVIDER_VERSION}|" "$env_config_file"
                
                sed -i.bak "s|^CIS_TRACKER_VERSION=.*|CIS_TRACKER_VERSION=${CIS_TRACKER_VERSION}|" "$env_config_file"
                sed -i.bak "s|^CIS_TRACKER_IMAGE=.*|CIS_TRACKER_IMAGE=${CIS_TRACKER_IMAGE_BASE}:${CIS_TRACKER_VERSION}|" "$env_config_file"
            fi
            
            # Regenerate values with new versions and imagePullPolicy=Always to force pull
            source "${SCRIPT_DIR}/scripts/values-generator.sh"
            if ! generate_k8s_values_from_env "Always"; then
                print_error "Failed to regenerate Kubernetes values"
                exit 1
            fi
            
            # Extract latest provider default.json from new image to update helm chart ConfigMap
            print_info "Extracting latest provider configuration from new image..."
            provider_image="${CIS_PROVIDER_IMAGE_BASE}:${CIS_PROVIDER_VERSION}"
            helm_config_path="${SCRIPT_DIR}/helm-bitoarch/services/cis-provider/config/default.json"

            # Pull the image first to ensure we have the latest
            if docker pull "$provider_image" >> "$LOG_FILE" 2>&1; then
                # Create temp container and extract config
                if docker create --name temp-provider-config-k8s "$provider_image" >/dev/null 2>&1; then
                    if docker cp temp-provider-config-k8s:/opt/bito/xmcp/config/default.json "$helm_config_path" 2>> "$LOG_FILE"; then
                        print_status "Provider configuration extracted for Helm chart"
                    else
                        print_warning "Could not extract provider config from image, using existing config"
                    fi
                    docker rm temp-provider-config-k8s >/dev/null 2>&1 || true
                else
                    print_warning "Could not create temp container for config extraction"
                fi
            else
                print_warning "Could not pull provider image for config extraction"
            fi

            # Apply updated configuration via Helm upgrade (will pull new images)
            # Use get_k8s_values_file to get actual file path (supports standard Unix paths)
            k8s_values_file="$(get_k8s_values_file)"
            print_info "Applying update via Helm (pulling new images)..."
            if helm upgrade bitoarch "${SCRIPT_DIR}/helm-bitoarch" \
                --namespace "$namespace" \
                --values "$k8s_values_file" \
                --wait \
                --timeout 10m >> "$LOG_FILE" 2>&1; then
                print_status "Images updated successfully"
            else
                print_error "Failed to apply update"
                print_info "Check logs: cat $LOG_FILE"
                print_info "Check Helm release: helm list -n $namespace"
                exit 1
            fi
            
            echo ""
            print_info "Restarting services with updated images..."
            
            deployments=("ai-architect-mysql" "ai-architect-config" "ai-architect-manager" "ai-architect-provider" "ai-architect-tracker")
            restart_failed=false
            
            for deployment in "${deployments[@]}"; do
                printf "   %-25s" "$deployment"
                
                # Tracker needs longer timeout due to init container dependencies on config/manager
                timeout="3m"
                if [[ "$deployment" == "ai-architect-tracker" ]]; then
                    timeout="10m"
                fi
                
                # Restart deployment to pick up new image
                if kubectl rollout restart deployment "$deployment" -n "$namespace" >> "$LOG_FILE" 2>&1; then
                    # Wait for rollout to complete
                    if kubectl rollout status deployment "$deployment" -n "$namespace" --timeout=$timeout >> "$LOG_FILE" 2>&1; then
                        printf "${GREEN}✅ Updated${NC}\n"
                    else
                        printf "${YELLOW}⏱ Timeout${NC}\n"
                        restart_failed=true
                    fi
                else
                    printf "${RED}❌ Failed${NC}\n"
                    restart_failed=true
                fi
            done
            
            echo ""
            if [ "$restart_failed" = true ]; then
                print_warning "Some services failed or timed out"
                print_info "Check status: ./setup.sh --status"
                exit 1
            else
                print_status "All services updated successfully"
                
                # Refresh port-forwards to point to new pods after update
                print_info "Refreshing port-forwards for updated pods..."
                pkill -f "kubectl.*port-forward.*${namespace}" 2>/dev/null || true
                sleep 2
                
                # Wait for pods to be stable before recreating port-forwards
                if wait_for_k8s_services "$namespace" 60; then
                    setup_port_forwards "$namespace"
                    print_status "Port-forwards refreshed"
                fi
                
                print_info "Check status: ./setup.sh --status"
            fi
        else
            # Docker Compose update
            compose_cmd="${DOCKER_COMPOSE_CMD:-}"
            if [ -z "$compose_cmd" ]; then
                if command -v docker >/dev/null 2>&1 && docker compose version >/dev/null 2>&1; then
                    compose_cmd="docker compose"
                elif command -v docker-compose >/dev/null 2>&1; then
                    compose_cmd="docker-compose"
                else
                    print_error "Neither 'docker compose' nor 'docker-compose' found"
                    exit 1
                fi
            fi
            
            # Check if services are running
            running_services=$(docker ps -q --filter "name=ai-architect-" 2>/dev/null | wc -l)
            if [ "$running_services" -eq 0 ]; then
                print_warning "No AI Architect services are currently running"
                print_info "Use './setup.sh' to start services"
                exit 0
            fi
            
            # DOCKER FIX: Refresh versions from service-versions.json to .env-bitoarch
            # This replaces the manual sed commands and ensures single source of truth
            # Use get_config_file to get actual file path (not symlink) for sed compatibility
            env_config_file="$(get_config_file)"
            print_info "Refreshing service versions from ${versions_file}..."
            if ! refresh_versions_from_service_json "$env_config_file"; then
                print_error "Failed to refresh versions from service-versions.json"
                exit 1
            fi

            # Source the updated env file to get version info for display
            source "$env_config_file"

            # Extract versions from IMAGE variables (format: docker.io/bitoai/service:version)
            config_version="${CIS_CONFIG_IMAGE##*:}"
            manager_version="${CIS_MANAGER_IMAGE##*:}"
            provider_version="${CIS_PROVIDER_IMAGE##*:}"
            tracker_version="${CIS_TRACKER_IMAGE##*:}"
            mysql_version="${MYSQL_IMAGE##*:}"
            
            print_info "Target versions from ${versions_file}:"
            print_info "  AI Architect Config: ${config_version}"
            print_info "  AI Architect Manager: ${manager_version}"
            print_info "  AI Architect Provider: ${provider_version}"
            print_info "  AI Architect Tracker: ${tracker_version}"
            print_info "  MySQL: ${mysql_version}"
            echo ""
                        
            echo ""
            print_info "Pulling latest images (this may take a few minutes)..."
            
            # Pull images one by one with progress
            services=("ai-architect-mysql" "ai-architect-config" "ai-architect-manager" "ai-architect-provider" "ai-architect-tracker")
            pull_failed=false
            
            for service in "${services[@]}"; do
                printf "   %-25s" "$service"
                if eval "$compose_cmd --env-file .env-bitoarch pull $service" >> "$LOG_FILE" 2>&1; then
                    printf "${GREEN}✅ Pulled${NC}\n"
                else
                    printf "${RED}❌ Failed${NC}\n"
                    pull_failed=true
                fi
            done
            
            if [ "$pull_failed" = true ]; then
                echo ""
                print_error "Failed to pull some images"
                print_info "Check logs: cat $LOG_FILE"
                exit 1
            fi
            
            # Extract latest provider default.json from new image
            echo ""
            print_info "Extracting latest provider configuration from new image..."
            docker_config_path="${SCRIPT_DIR}/services/cis-provider/config/default.json"

            # Create temp container and extract config
            if docker create --name temp-provider-config-docker "${CIS_PROVIDER_IMAGE}" >/dev/null 2>&1; then
                if docker cp temp-provider-config-docker:/opt/bito/xmcp/config/default.json "$docker_config_path" 2>> "$LOG_FILE"; then
                    chmod 666 "$docker_config_path"
                    print_status "Provider configuration extracted from latest image"
                else
                    print_warning "Could not extract provider config from image, using existing config"
                fi
                docker rm temp-provider-config-docker >/dev/null 2>&1 || true
            else
                print_warning "Could not create temp container for config extraction"
            fi

            echo ""
            print_info "Restarting services with updated images..."
            
            restart_failed=false
            for service in "${services[@]}"; do
                printf "   %-25s" "$service"
                # Use up -d --force-recreate to ensure new image is used
                if eval "$compose_cmd --env-file .env-bitoarch up -d --force-recreate --no-deps $service" >> "$LOG_FILE" 2>&1; then
                    printf "${GREEN}✅ Updated${NC}\n"
                else
                    printf "${RED}❌ Failed${NC}\n"
                    restart_failed=true
                fi
            done
            
            echo ""
            if [ "$restart_failed" = true ]; then
                print_warning "Some services failed to update"
                print_info "Check logs: ./setup.sh --logs"
                exit 1
            else
                print_status "All services updated successfully with latest images"
                print_info "Check status: ./setup.sh --status"
            fi
        fi
        ;;
    *)
        # Check if an unknown option was provided
        if [[ "${1:-}" == --* ]]; then
            print_error "Unknown option: ${1}"
            echo ""
            show_help
            exit 1
        else
            # No option provided, run main setup
            main
        fi
        ;;
esac
