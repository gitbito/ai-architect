#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
# CIS Platform - Output Field Configurations
# Defines JSON paths for extracting customer-relevant fields from API responses

# ============================================================================
# CONFIG COMMANDS
# ============================================================================

# config repo add - success output
CONFIG_ADD_SUCCESS_OUTPUT="\
.integration.git.provider:Git Provider,\
.repository.repo_limit:Repository Limit,\
.repository.repo_size_limit:Size Limit,\
.repository.default_sync_interval:Sync Interval,\
.repository.configured_repos|length:Total Repositories"

# config repo add - error output
CONFIG_ADD_ERROR_OUTPUT="\
.error:Error Type,\
.message:Error Message,\
.details:Details"

# config repo get - success output
CONFIG_GET_SUCCESS_OUTPUT="\
.integration.git.provider:Git Provider,\
.repository.repo_limit:Repository Limit,\
.repository.repo_size_limit:Size Limit,\
.repository.configured_repos|length:Total Repositories"

# config repo get - error output
CONFIG_GET_ERROR_OUTPUT="\
.error:Error,\
.message:Message"

# config repo update - success output
CONFIG_UPDATE_SUCCESS_OUTPUT="\
.integration.git.provider:Git Provider,\
.repository.configured_repos|length:Total Repositories,\
.repository.repo_limit:Repository Limit"

# config repo update - error output
CONFIG_UPDATE_ERROR_OUTPUT="\
.error:Error,\
.message:Message,\
.details:Details"

# ============================================================================
# MANAGER COMMANDS
# ============================================================================

# manager sync - success output
MANAGER_SYNC_SUCCESS_OUTPUT="\
.message:Message"

# manager sync - error output
MANAGER_SYNC_ERROR_OUTPUT="\
.error:Error,\
.message:Message,\
.details:Details"

# manager status - success output (default view)
MANAGER_STATUS_SUCCESS_OUTPUT="\
.state:State,\
.progress:Progress,\
.total:Total,\
.current_repository:Current Repository"

# manager status - error output
MANAGER_STATUS_ERROR_OUTPUT="\
.error:Error,\
.message:Message"

# ============================================================================
# PROVIDER COMMANDS
# ============================================================================

# provider mcp tools - success output (names only)
PROVIDER_TOOLS_SUCCESS_OUTPUT="\
.result.tools[].name"

# provider mcp tools - error output
PROVIDER_TOOLS_ERROR_OUTPUT="\
.error:Error,\
.message:Message"

# provider mcp resources - success output
PROVIDER_RESOURCES_SUCCESS_OUTPUT="\
.result.resources[].uri"

# provider mcp resources - error output
PROVIDER_RESOURCES_ERROR_OUTPUT="\
.error:Error,\
.message:Message"

# provider mcp capabilities - success output
PROVIDER_CAPABILITIES_SUCCESS_OUTPUT="\
.result.capabilities.tools.listChanged:Tools Support,\
.result.capabilities.resources.listChanged:Resources Support"

# provider mcp capabilities - error output
PROVIDER_CAPABILITIES_ERROR_OUTPUT="\
.error:Error,\
.message:Message"

# ============================================================================
# HELPER FUNCTIONS
# ============================================================================

# Extract fields from JSON response based on field spec
# Usage: extract_fields "$json" "$field_spec"
extract_fields() {
    local json="$1"
    local field_spec="$2"
    
    if ! command -v jq >/dev/null 2>&1; then
        echo "$json"
        return 1
    fi
    
    # Handle array extraction (no label, just values)
    if [[ "$field_spec" == *"[]"* ]] && [[ "$field_spec" != *":"* ]]; then
        echo "$json" | jq -r "$field_spec // empty" 2>/dev/null
        return 0
    fi
    
    # Parse comma-separated field:label pairs
    IFS=',' read -ra FIELDS <<< "$field_spec"
    
    local output=""
    for field in "${FIELDS[@]}"; do
        field=$(echo "$field" | xargs)  # trim whitespace
        
        local path="${field%%:*}"
        local label="${field#*:}"
        
        # If no label, use path as label
        [ "$path" = "$label" ] && label=$(echo "$path" | sed 's/\./ /g;s/^  *//;s/_/ /g')
        
        local value=$(echo "$json" | jq -r "$path // \"N/A\"" 2>/dev/null)
        
        output="${output}${label}: ${value}\n"
    done
    
    echo -e "$output"
}

# Render success message with extracted fields
# Usage: render_command_success "Title" "$json_response" "$SUCCESS_OUTPUT_SPEC"
render_command_success() {
    local title="$1"
    local json="$2"
    local field_spec="$3"
    
    echo ""
    echo -e "${GREEN}✅ ${title}${NC}"
    echo ""
    
    if [ -n "$field_spec" ]; then
        # Check if it's an array extraction (like tool names)
        if [[ "$field_spec" == *"[]"* ]] && [[ "$field_spec" != *":"* ]]; then
            echo -e "${BLUE}Available Items:${NC}"
            echo ""
            extract_fields "$json" "$field_spec" | while read -r item; do
                [ -n "$item" ] && echo "  • $item"
            done
        else
            echo -e "${BLUE}Summary:${NC}"
            extract_fields "$json" "$field_spec" | while IFS= read -r line; do
                [ -n "$line" ] && echo "  • $line"
            done
        fi
    fi
    
    echo ""
}

# Render error message with extracted fields
# Usage: render_command_error "Title" "$json_response" "$ERROR_OUTPUT_SPEC"
render_command_error() {
    local title="$1"
    local json="$2"
    local field_spec="$3"
    
    echo ""
    echo -e "${RED}❌ ${title}${NC}"
    echo ""
    
    if [ -n "$field_spec" ]; then
        echo -e "${YELLOW}Error Details:${NC}"
        extract_fields "$json" "$field_spec" | while IFS= read -r line; do
            [ -n "$line" ] && echo "  • $line"
        done
    fi
    
    echo ""
}

# Export all configurations and functions
export CONFIG_ADD_SUCCESS_OUTPUT
export CONFIG_ADD_ERROR_OUTPUT
export CONFIG_GET_SUCCESS_OUTPUT
export CONFIG_GET_ERROR_OUTPUT
export CONFIG_UPDATE_SUCCESS_OUTPUT
export CONFIG_UPDATE_ERROR_OUTPUT
export MANAGER_SYNC_SUCCESS_OUTPUT
export MANAGER_SYNC_ERROR_OUTPUT
export MANAGER_STATUS_SUCCESS_OUTPUT
export MANAGER_STATUS_ERROR_OUTPUT
export PROVIDER_TOOLS_SUCCESS_OUTPUT
export PROVIDER_TOOLS_ERROR_OUTPUT
export PROVIDER_RESOURCES_SUCCESS_OUTPUT
export PROVIDER_RESOURCES_ERROR_OUTPUT
export PROVIDER_CAPABILITIES_SUCCESS_OUTPUT
export PROVIDER_CAPABILITIES_ERROR_OUTPUT

export -f extract_fields
export -f render_command_success
export -f render_command_error
