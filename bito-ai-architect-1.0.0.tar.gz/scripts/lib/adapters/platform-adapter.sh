#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
# Bito's AI Architect CLI - Platform Adapter
# Handles platform-wide operations (health, status)

# Platform command handler
handle_platform() {
    local command="$1"
    shift
    
    # Check for help
    if [ "$command" = "--help" ] || [ "$command" = "-h" ] || [ -z "$command" ]; then
        show_platform_help
        return 0
    fi
    
    # Route to command
    case "$command" in
        health)
            platform_health "$@"
            ;;
        status)
            platform_status "$@"
            ;;
        info)
            platform_info "$@"
            ;;
        rotate-token)
            platform_rotate_token "$@"
            ;;
        update-api-key)
            platform_update_api_key "$@"
            ;;
        update-git-creds)
            platform_update_git_creds "$@"
            ;;
        mcp)
            platform_mcp "$@"
            ;;
        *)
            print_error "Unknown platform command: $command"
            echo ""
            echo "Available commands: health, status, info, rotate-token, update-api-key, update-git-creds, mcp"
            echo "Use 'bitoarch --help' for more information"
            return 1
            ;;
    esac
}

# Check health of all services
platform_health() {
    # Check for help first
    if [ "$1" = "--help" ] || [ "$1" = "-h" ]; then
        cat << 'EOF'
USAGE:
  bitoarch health [OPTIONS]

OPTIONS:
  --verbose, -v    Show detailed health information
  --help, -h       Show this help

EXAMPLES:
  bitoarch health
  bitoarch health --verbose
EOF
        return 0
    fi
    
    local verbose=false
    
    # Parse options
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --verbose|-v)
                verbose=true
                shift
                ;;
            *)
                shift
                ;;
        esac
    done
    
    print_header "Bito's AI Architect Health Check"
    echo ""
    
    local services=(
        "provider|${PROVIDER_URL}|AI Architect Provider (MCP)"
        "config|${CONFIG_URL}|AI Architect Config"
        "manager|${MANAGER_URL}|AI Architect Manager"
        "mysql|mysql://localhost:${MYSQL_PORT}|MySQL Database"
    )
    
    local healthy_count=0
    local total_count=${#services[@]}
    
    for service_info in "${services[@]}"; do
        IFS='|' read -r name url display <<< "$service_info"
        
        printf "%-25s " "$display"
        
        if [ "$name" = "mysql" ]; then
            # Check MySQL using docker
            if check_service_running "ai-architect-mysql"; then
                echo -e "$(format_status "healthy")"
                healthy_count=$((healthy_count + 1))
                
                if [ "$verbose" = "true" ]; then
                    echo "    Port: ${MYSQL_PORT}"
                    local uptime=$(docker inspect --format='{{.State.StartedAt}}' ai-architect-mysql 2>/dev/null)
                    echo "    Started: $uptime"
                fi
            else
                echo -e "$(format_status "down")"
            fi
        else
            # Check HTTP services
            if health_check "$url"; then
                echo -e "$(format_status "healthy")"
                healthy_count=$((healthy_count + 1))
                
                if [ "$verbose" = "true" ]; then
                    local port=$(echo "$url" | sed -n 's/.*:\([0-9]*\)$/\1/p')
                    echo "    URL: $url"
                    echo "    Port: $port"
                    
                    # Get additional info from health endpoint
                    local health_info=$(http_request "GET" "${url}/health" "" "" "" 2>/dev/null)
                    if require_command jq && [ -n "$health_info" ]; then
                        local uptime=$(echo "$health_info" | jq -r '.uptime // "N/A"')
                        echo "    Uptime: ${uptime}s"
                    fi
                fi
            else
                echo -e "$(format_status "down")"
            fi
        fi
        echo ""
    done
    
    # Summary
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    
    if [ $healthy_count -eq $total_count ]; then
        print_success "All services healthy ($healthy_count/$total_count)"
        return 0
    elif [ $healthy_count -gt 0 ]; then
        print_warning "Some services unhealthy ($healthy_count/$total_count)"
        return 1
    else
        print_error "All services down ($healthy_count/$total_count)"
        return 1
    fi
}

# Get platform status
platform_status() {
    print_header "Bito's AI Architect Status"
    echo ""
    
    # Get service status from docker
    local services=("ai-architect-mysql" "ai-architect-provider" "ai-architect-config" "ai-architect-manager")
    
    for container in "${services[@]}"; do
        
        local display_name=$(echo "$container" | sed 's/cis-//' | tr '[:lower:]' '[:upper:]')
        
        if docker ps --format '{{.Names}}' | grep -q "^${container}$"; then
            local status=$(docker inspect --format='{{.State.Status}}' "$container" 2>/dev/null)
            local health=$(docker inspect --format='{{.State.Health.Status}}' "$container" 2>/dev/null)
            local uptime=$(docker inspect --format='{{.State.StartedAt}}' "$container" 2>/dev/null)
            
            printf "%-15s " "$display_name"
            
            if [ "$status" = "running" ]; then
                if [ "$health" = "healthy" ] || [ "$health" = "" ]; then
                    echo -e "$(format_status "running")"
                elif [ "$health" = "starting" ]; then
                    # During start_period, check actual health endpoint
                    local port=$(docker inspect --format='{{range $p, $conf := .NetworkSettings.Ports}}{{if eq $p "8080/tcp"}}8080{{else if eq $p "8081/tcp"}}8081{{else if eq $p "9090/tcp"}}9090{{end}}{{end}}' "$container" 2>/dev/null)
                    if [ -n "$port" ] && curl -sf "http://localhost:$port/health" >/dev/null 2>&1; then
                        echo -e "$(format_status "running")"
                    else
                        echo -e "$(format_status "$health")"
                    fi
                else
                    echo -e "$(format_status "$health")"
                fi
                
                echo "  Started: $uptime"
                
                # Get port mapping
                local ports=$(docker port "$container" 2>/dev/null | head -1)
                if [ -n "$ports" ]; then
                    echo "  Ports: $ports"
                fi
            else
                echo -e "$(format_status "$status")"
            fi
            echo ""
        else
            printf "%-15s " "$display_name"
            echo -e "$(format_status "stopped")"
            echo ""
        fi
    done
}

# Get platform information
platform_info() {
    print_header "Bito's AI Architect Information"
    echo ""
    
    # Platform version
    if [ -f "$SCRIPT_DIR/versions/service-versions.json" ]; then
        if require_command jq; then
            local platform_version=$(jq -r '.platform_version // "1.0.0"' "$SCRIPT_DIR/versions/service-versions.json")
            format_key_value "Platform Version" "$platform_version"
        fi
    fi
    
    # Configuration
    format_key_value "Configuration" "$ENV_FILE"
    echo ""
    print_subheader "Service Endpoints:"
    format_key_value "  Provider" "$PROVIDER_URL"
    format_key_value "  Config" "$CONFIG_URL"
    format_key_value "  Manager" "$MANAGER_URL"
    format_key_value "  MySQL" "localhost:$MYSQL_PORT"
    
    echo ""
    print_subheader "Running Services:"
    
    local running_count=$(docker ps --filter "name=cis-" --format '{{.Names}}' | wc -l)
    local total_services=4
    
    format_key_value "  Active" "$running_count / $total_services"
    
    # List running services
    docker ps --filter "name=cis-" --format "  • {{.Names}} ({{.Status}})"
    
    echo ""
    print_subheader "Resource Usage:"
    
    # Get resource usage
    if command -v docker >/dev/null 2>&1; then
        # Get list of container IDs
        local container_ids=$(docker ps -q --filter "name=cis-" 2>/dev/null)
        
        if [ -n "$container_ids" ]; then
            # Calculate total CPU usage (strip % and sum)
            local cpu_usage=$(docker stats --no-stream --format "{{.CPUPerc}}" $container_ids 2>/dev/null | \
                              sed 's/%$//' | \
                              awk '{s+=$1} END {printf "%.2f%%", s}')
            
            # Get first container's memory usage as sample
            local mem_usage=$(docker stats --no-stream --format "{{.MemUsage}}" $container_ids 2>/dev/null | head -1)
            
            if [ -n "$cpu_usage" ] && [ "$cpu_usage" != "%" ]; then
                format_key_value "  CPU" "$cpu_usage"
            fi
            if [ -n "$mem_usage" ]; then
                format_key_value "  Memory" "$mem_usage"
            fi
        fi
    fi
    
    echo ""
}

# Rotate MCP access token
platform_rotate_token() {
    local new_token="$1"
    
    if [ "$1" = "--help" ] || [ "$1" = "-h" ] || [ -z "$new_token" ]; then
        cat << 'EOF'
USAGE:
  bitoarch rotate-mcp-token <new-token>

DESCRIPTION:
  Rotate the Bito MCP access token and restart cis-provider service

ARGUMENTS:
  <new-token>    New MCP access token (required)

EXAMPLES:
  # Rotate to a new token
  bitoarch rotate-mcp-token "new-secure-token-abc123"
  
  # This will:
  # 1. Update token in .env file
  # 2. Update MCP server configuration
  # 3. Restart cis-provider service only
  # 4. Display new MCP connection details

NOTE:
  - Only cis-provider is restarted (minimal downtime ~2 seconds)
  - Other services remain running
  - Token takes effect immediately

EOF
        return 0
    fi
    
    print_info "Rotating MCP access token..."
    
    # Validate token is provided
    if [ -z "$new_token" ]; then
        print_error "Token cannot be empty"
        return 1
    fi
    
    # Update .env file
    if [ -f "$ENV_FILE" ]; then
        sed -i.bak "s/^BITO_MCP_ACCESS_TOKEN=.*/BITO_MCP_ACCESS_TOKEN=${new_token}/" "$ENV_FILE"
        print_success "Updated token in .env"
    else
        print_error ".env file not found: $ENV_FILE"
        return 1
    fi
    
    # Reload environment
    load_env_config
    export BITO_MCP_ACCESS_TOKEN="$new_token"
    
    # Update MCP config
    local mcp_config_file="${PROJECT_ROOT}/services/cis-provider/config/default.json"
    
    if [ -f "$mcp_config_file" ]; then
        if command -v jq >/dev/null 2>&1; then
            local temp_config=$(mktemp)
            jq --arg token "$new_token" \
               '.auth.bearer_token = $token' \
               "$mcp_config_file" > "$temp_config"
            mv "$temp_config" "$mcp_config_file"
            print_success "MCP configuration updated using jq"
        else
            cp "$mcp_config_file" "${mcp_config_file}.backup"
            sed -i.tmp "s/\"bearer_token\"[[:space:]]*:[[:space:]]*\"[^\"]*\"/\"bearer_token\": \"$new_token\"/g" "$mcp_config_file"
            rm -f "${mcp_config_file}.tmp"
            print_success "MCP configuration updated using sed"
        fi
    else
        print_warning "MCP config file not found, skipping config update"
    fi
    
    # Restart only cis-provider
    print_info "Restarting ai-architect-provider service..."
    
    # Change to project root
    local orig_dir=$(pwd)
    cd "$PROJECT_ROOT" 2>/dev/null || {
        print_error "Failed to change to project directory: $PROJECT_ROOT"
        return 1
    }
    
    # Try docker compose restart
    if docker compose restart ai-architect-provider 2>/dev/null; then
        cd "$orig_dir"
        echo ""
        print_success "MCP token rotated successfully"
        echo ""
        print_info "New MCP URL: ${PROVIDER_URL}/mcp"
        print_info "New Token: ${new_token}"
        echo ""
        return 0
    elif docker-compose restart ai-architect-provider 2>/dev/null; then
        cd "$orig_dir"
        echo ""
        print_success "MCP token rotated successfully"
        echo ""
        print_info "New MCP URL: ${PROVIDER_URL}/mcp"
        print_info "New Token: ${new_token}"
        echo ""
        return 0
    else
        cd "$orig_dir"
        print_error "Failed to restart ai-architect-provider"
        print_warning "Try manually: cd $PROJECT_ROOT && docker compose restart ai-architect-provider"
        return 1
    fi
}

# Update Bito API key
platform_update_api_key() {
    local new_api_key=""
    local restart_services=false
    
    # Parse options
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --help|-h)
                cat << 'EOF'
USAGE:
  bitoarch update-api-key [OPTIONS]

DESCRIPTION:
  Update the Bito API key in the .env-bitoarch file.
  Optionally update Git credentials in the same session.

OPTIONS:
  --api-key <key>    The new Bito API key
  --restart          Restart services after updating
  --help, -h         Show this help

NOTES:
  - Interactive mode will prompt for API key and optionally Git credentials
  - Services must be restarted for changes to take effect
  - Use --restart flag to automatically restart services
EOF
                return 0
                ;;
            --api-key)
                new_api_key="$2"
                shift 2
                ;;
            --restart)
                restart_services=true
                shift
                ;;
            *)
                print_error "Unknown option: $1"
                return 1
                ;;
        esac
    done
    
    # If no API key provided, prompt securely
    if [ -z "$new_api_key" ]; then
        echo ""
        echo -e "${BLUE}${BOLD}Update Bito API Key${NC}"
        echo ""
        echo "Enter new Bito API key (input hidden):"
        read -s new_api_key
        echo ""
        if [ -z "$new_api_key" ]; then
            print_error "API key cannot be empty"
            return 1
        fi
        # Show masked confirmation
        local masked_key=$(printf '%*s' ${#new_api_key} | tr ' ' '*')
        echo -e "${GREEN}✓${NC} API key received: ${masked_key}"
        echo ""
    fi
    
    # Create timestamped backup before making changes
    local timestamp=$(date +%Y%m%d_%H%M%S)
    local backup_file="${ENV_FILE}.backup.${timestamp}"
    cp "$ENV_FILE" "$backup_file"
    
    # Keep only last N backups (configurable via ENV_BACKUP_RETENTION)
    local retention="${ENV_BACKUP_RETENTION:-5}"
    ls -t "${ENV_FILE}.backup."* 2>/dev/null | tail -n +$((retention + 1)) | xargs rm -f 2>/dev/null || true
    
    # Update .env file using @ as delimiter for special characters
    sed -i.bak "s@^BITO_API_KEY=.*@BITO_API_KEY=$new_api_key@" "$ENV_FILE"
    rm -f "${ENV_FILE}.bak"
    
    echo ""
    print_success "Bito API key updated successfully"
    print_info "Backup created: $(basename "$backup_file")"
    echo ""
    
    # Ask if they want to update Git credentials too
    echo "Do you want to update Git credentials as well? (y/N):"
    read -r update_git
    
    if [[ "$update_git" =~ ^[Yy]$ ]]; then
        echo ""
        
        # Get supported providers from environment
        local supported_list="${SUPPORTED_GIT_PROVIDERS:-github,gitlab,bitbucket}"
        local providers_display=$(echo "$supported_list" | tr ',' ' ')
        
        echo "Supported providers: ${providers_display}"
        echo ""
        read -p "Enter Git provider: " new_provider
        
        if [ -z "$new_provider" ]; then
            print_error "Git provider cannot be empty"
            return 1
        fi
        
        # Normalize provider to lowercase
        new_provider=$(echo "$new_provider" | tr '[:upper:]' '[:lower:]')
        
        # Validate provider is in supported list
        if [[ ",$supported_list," != *",$new_provider,"* ]]; then
            print_error "Unsupported provider: $new_provider"
            echo "Supported providers: ${providers_display}"
            return 1
        fi
        
        echo ""
        echo "Enter Git access token (input hidden):"
        read -s new_token
        echo ""
        
        if [ -z "$new_token" ]; then
            print_error "Git token cannot be empty"
            return 1
        fi
        
        # Show masked confirmation
        local masked_token=$(printf '%*s' ${#new_token} | tr ' ' '*')
        echo -e "${GREEN}✓${NC} Git token received: ${masked_token}"
        echo ""
        
        # Create timestamped backup for Git creds update (if not already created above)
        if [ ! -f "$backup_file" ]; then
            local timestamp=$(date +%Y%m%d_%H%M%S)
            local backup_file="${ENV_FILE}.backup.${timestamp}"
            cp "$ENV_FILE" "$backup_file"
        fi
        
        # Update Git credentials in .env file
        sed -i.bak "s@^GIT_PROVIDER=.*@GIT_PROVIDER=$new_provider@" "$ENV_FILE"
        sed -i.bak "s@^GIT_ACCESS_TOKEN=.*@GIT_ACCESS_TOKEN=$new_token@" "$ENV_FILE"
        rm -f "${ENV_FILE}.bak"
        
        echo ""
        print_success "Git credentials updated successfully"
        echo ""
        print_info "Provider: $new_provider"
        print_info "Token: $(echo "$new_token" | head -c 10)... (masked)"
        echo ""
    fi
    
    # Ask about restarting services if not explicitly set
    if [ "$restart_services" != true ]; then
        echo "Restart services to apply changes? (y/N):"
        read -r restart_choice
        if [[ "$restart_choice" =~ ^[Yy]$ ]]; then
            restart_services=true
        fi
    fi
    
    # Restart services
    if [ "$restart_services" = true ]; then
        echo ""
        print_info "Restarting services to apply changes..."
        
        local orig_dir=$(pwd)
        cd "$PROJECT_ROOT" 2>/dev/null || {
            print_error "Failed to change to project directory"
            return 1
        }
        
        if docker compose restart ai-architect-config ai-architect-manager ai-architect-provider ai-architect-tracker 2>/dev/null || \
           docker-compose restart ai-architect-config ai-architect-manager ai-architect-provider ai-architect-tracker 2>/dev/null; then
            cd "$orig_dir"
            print_success "Services restarted successfully"
            echo ""
            print_info "Updated credentials are now active"
            echo ""
        else
            cd "$orig_dir"
            print_error "Failed to restart services"
            print_info "Try manually: docker compose restart ai-architect-config ai-architect-manager ai-architect-provider ai-architect-tracker"
            echo ""
            return 1
        fi
    else
        print_warning "Services not restarted. Changes will take effect after manual restart:"
        echo "  docker compose restart ai-architect-config ai-architect-manager ai-architect-provider ai-architect-tracker"
        echo ""
    fi
}

# Update Git credentials
platform_update_git_creds() {
    local new_provider=""
    local new_token=""
    local restart_services=false
    
    # Parse options
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --help|-h)
                # Read supported providers from environment
                local supported_list="${SUPPORTED_GIT_PROVIDERS:-github,gitlab,bitbucket}"
                local providers_display=$(echo "$supported_list" | tr ',' ' ')
                
                cat << EOF
USAGE:
  bitoarch update-git-creds [OPTIONS]

DESCRIPTION:
  Update Git provider credentials in the .env-bitoarch file.
  Supported providers: ${providers_display}

OPTIONS:
  --provider <name>  Git provider name
  --token <token>    Git access token or PAT
  --restart          Restart services after updating
  --help, -h         Show this help

TOKEN TYPES:
  GitHub: Personal Access Token (ghp_xxx or github_pat_xxx)
  GitLab: Personal/Project Access Token (glpat-xxx)
  Bitbucket: App Password

NOTES:
  - Services must be restarted for changes to take effect
  - Use --restart flag to automatically restart services
  - Ensure token has appropriate repository access permissions
EOF
                return 0
                ;;
            --provider)
                new_provider="$2"
                shift 2
                ;;
            --token)
                new_token="$2"
                shift 2
                ;;
            --restart)
                restart_services=true
                shift
                ;;
            *)
                print_error "Unknown option: $1"
                return 1
                ;;
        esac
    done
    
    # Get supported providers from environment
    local supported_list="${SUPPORTED_GIT_PROVIDERS:-github,gitlab,bitbucket}"
    local providers_display=$(echo "$supported_list" | tr ',' ' ')
    
    # Prompt for provider if not provided
    if [ -z "$new_provider" ]; then
        echo ""
        echo -e "${BLUE}${BOLD}Update Git Credentials${NC}"
        echo ""
        echo "Supported providers: ${providers_display}"
        echo ""
        read -p "Enter Git provider: " new_provider
        if [ -z "$new_provider" ]; then
            print_error "Git provider cannot be empty"
            return 1
        fi
    fi
    
    # Normalize provider to lowercase
    new_provider=$(echo "$new_provider" | tr '[:upper:]' '[:lower:]')
    
    # Validate provider is in supported list
    if [[ ",$supported_list," != *",$new_provider,"* ]]; then
        print_error "Unsupported provider: $new_provider"
        echo "Supported providers: ${providers_display}"
        return 1
    fi
    
    # Prompt for token if not provided (secure input)
    if [ -z "$new_token" ]; then
        echo ""
        echo "Enter Git access token (input hidden):"
        read -s new_token
        echo ""
        if [ -z "$new_token" ]; then
            print_error "Git token cannot be empty"
            return 1
        fi
        # Show masked confirmation
        local masked_token=$(printf '%*s' ${#new_token} | tr ' ' '*')
        echo -e "${GREEN}✓${NC} Git token received: ${masked_token}"
        echo ""
    fi
    
    # Create timestamped backup before making changes
    local timestamp=$(date +%Y%m%d_%H%M%S)
    local backup_file="${ENV_FILE}.backup.${timestamp}"
    cp "$ENV_FILE" "$backup_file"
    
    # Keep only last N backups (configurable via ENV_BACKUP_RETENTION)
    local retention="${ENV_BACKUP_RETENTION:-5}"
    ls -t "${ENV_FILE}.backup."* 2>/dev/null | tail -n +$((retention + 1)) | xargs rm -f 2>/dev/null || true
    
    # Update .env file using @ as delimiter for special characters
    sed -i.bak "s@^GIT_PROVIDER=.*@GIT_PROVIDER=$new_provider@" "$ENV_FILE"
    sed -i.bak "s@^GIT_ACCESS_TOKEN=.*@GIT_ACCESS_TOKEN=$new_token@" "$ENV_FILE"
    rm -f "${ENV_FILE}.bak"
    
    echo ""
    print_success "Git credentials updated successfully"
    print_info "Backup created: $(basename "$backup_file")"
    echo ""
    print_info "Provider: $new_provider"
    print_info "Token: $(echo "$new_token" | head -c 10)... (masked)"
    echo ""
    
    # Ask about restarting services if not explicitly set
    if [ "$restart_services" != true ]; then
        echo "Restart services to apply changes? (y/N):"
        read -r restart_choice
        if [[ "$restart_choice" =~ ^[Yy]$ ]]; then
            restart_services=true
        fi
    fi
    
    # Restart services
    if [ "$restart_services" = true ]; then
        echo ""
        print_info "Restarting services to apply changes..."
        
        local orig_dir=$(pwd)
        cd "$PROJECT_ROOT" 2>/dev/null || {
            print_error "Failed to change to project directory"
            return 1
        }
        
        if docker compose restart ai-architect-config ai-architect-manager ai-architect-provider ai-architect-tracker 2>/dev/null || \
           docker-compose restart ai-architect-config ai-architect-manager ai-architect-provider ai-architect-tracker 2>/dev/null; then
            cd "$orig_dir"
            print_success "Services restarted successfully"
            echo ""
            print_info "Updated credentials are now active"
            print_info "Test Git connectivity:"
            echo "  bitoarch add-repo your-org/your-repo"
            echo ""
        else
            cd "$orig_dir"
            print_error "Failed to restart services"
            print_info "Try manually: docker compose restart ai-architect-config ai-architect-manager ai-architect-provider ai-architect-tracker"
            echo ""
            return 1
        fi
    else
        print_warning "Services not restarted. Changes will take effect after manual restart:"
        echo "  docker compose restart ai-architect-config ai-architect-manager ai-architect-provider ai-architect-tracker"
        echo "  Then test Git connectivity:"
        echo "  bitoarch add-repo your-org/your-repo"
        echo ""
    fi
}

# Show MCP configuration
platform_mcp() {
    # Check for help
    if [ "$1" = "--help" ] || [ "$1" = "-h" ]; then
        cat << 'EOF'
USAGE:
  bitoarch mcp-info

DESCRIPTION:
  Display MCP server configuration details including URL and access token.
  Use this information to configure MCP clients like Cursor, Cline, or Windsurf.

NOTES:
  - Test connection with: bitoarch mcp-test
EOF
        return 0
    fi
    
    # Get MCP URL and token from environment
    local mcp_url="${PROVIDER_URL:-http://localhost:${CIS_PROVIDER_EXTERNAL_PORT:-5001}}/mcp"
    local mcp_token="${BITO_MCP_ACCESS_TOKEN:-not-set}"
    
    # Use render function for consistent output
    render_mcp_config_block "$mcp_url" "$mcp_token"
}

# Export functions
export -f handle_platform
export -f platform_health
export -f platform_status
export -f platform_info
export -f platform_update_api_key
export -f platform_update_git_creds
export -f platform_rotate_token
export -f platform_mcp
