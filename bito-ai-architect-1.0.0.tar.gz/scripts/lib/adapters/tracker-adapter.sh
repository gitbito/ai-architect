#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
# Bito's AI Architect CLI - Tracker Adapter

check_indexing_enabled() {
    local base_url="$1"
    local api_key="$2"

    if [[ -z "$base_url" ]]; then
        print_error "TRACKING_SERVICE_BASE_URL is not set"
        return 1
    fi
    if [[ -z "$api_key" ]]; then
        echo "ERROR: Bito API Key is not set"
        return 1
    fi

    local url="${base_url}/v1/project-info/context"

    # Call API
    local response
    response=$(curl -s -X GET "$url" \
        -H "ws-api-key: Bearer ${api_key}")

    # If curl failed
    if [[ $? -ne 0 || -z "$response" ]]; then
        echo "ERROR: API call failed"
        return 1
    fi

    # Extract indexing_enabled (can be true/false/null)
    local indexing_enabled
    indexing_enabled=$(echo "$response" | jq -r '.indexing_enabled')

    # Debug print (optional)
    # echo "API response: $response"
    # echo "indexing_enabled: $indexing_enabled"

    # Logic:
    # success => indexing_enabled == true
    # failure => null or false
    if [[ "$indexing_enabled" == "true" ]]; then
        return 0
    else
        return 1
    fi
}

export -f check_indexing_enabled
