#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
# CIS Platform - Output Formatting Utilities
# Field-level and formatting utilities

# Source output blocks for rendering
FORMATTER_SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [ -f "${FORMATTER_SCRIPT_DIR}/output-blocks.sh" ]; then
    source "${FORMATTER_SCRIPT_DIR}/output-blocks.sh"
fi

# Mask secrets in JSON output for security
mask_secrets() {
    local json_input="$1"
    
    if ! command -v jq >/dev/null 2>&1; then
        echo "$json_input"
        return
    fi
    
    echo "$json_input" | jq '
        # Mask bito_access_key
        if .bito_access_key then
            .bito_access_key = (.bito_access_key | if (. != null and . != "") then "***MASKED***" else . end)
        else . end |
        # Mask git access_token
        if .integration.git.access_token then
            .integration.git.access_token = (.integration.git.access_token | if (. != null and . != "") then "***MASKED***" else . end)
        else . end |
        # Mask LLM provider api_keys
        if .llm.providers then
            .llm.providers = (.llm.providers | to_entries | map(
                .value.api_key = (.value.api_key | if (. != null and . != "") then "***MASKED***" else . end)
            ) | from_entries)
        else . end
    '
}

# Default output format
OUTPUT_FORMAT="${OUTPUT_FORMAT:-table}"

# Format JSON output
format_json() {
    local json_data="$1"
    
    if require_command jq 2>/dev/null; then
        echo "$json_data" | jq '.'
    else
        echo "$json_data"
    fi
}

# Format table output from JSON array
format_table() {
    local json_data="$1"
    local columns="$2"  # Comma-separated list of column names
    
    if ! require_command jq 2>/dev/null; then
        echo "$json_data"
        return 0
    fi
    
    # If no columns specified, try to extract from first object
    if [ -z "$columns" ]; then
        columns=$(echo "$json_data" | jq -r '.[0] | keys | join(",")')
    fi
    
    # Convert columns to array
    IFS=',' read -ra COL_ARRAY <<< "$columns"
    
    # Print header
    printf "${BOLD}"
    for col in "${COL_ARRAY[@]}"; do
        printf "%-20s " "$col"
    done
    printf "${NC}\n"
    
    # Print separator
    for col in "${COL_ARRAY[@]}"; do
        printf "%-20s " "--------------------"
    done
    printf "\n"
    
    # Print rows
    echo "$json_data" | jq -r --arg cols "$columns" '
        .[] | 
        [($cols | split(",") | .[] as $col | .[$col] // "N/A")] |
        @tsv
    ' | while IFS=$'\t' read -r -a values; do
        for value in "${values[@]}"; do
            printf "%-20s " "$value"
        done
        printf "\n"
    done
}

# Format simple key-value pairs
format_key_value() {
    local key="$1"
    local value="$2"
    local indent="${3:-0}"
    
    local spacing=$(printf '%*s' "$indent" '')
    printf "${spacing}${BOLD}%-20s${NC} %s\n" "$key:" "$value"
}

# Format list output
format_list() {
    local items="$1"
    local bullet="${2:-•}"
    
    echo "$items" | while read -r item; do
        echo "  ${bullet} $item"
    done
}

# Format status indicator
format_status() {
    local status="$1"
    
    case "$status" in
        healthy|active|running|ok|success)
            echo -e "${GREEN}● $status${NC}"
            ;;
        starting|pending|progress)
            echo -e "${YELLOW}◐ $status${NC}"
            ;;
        unhealthy|failed|error|down)
            echo -e "${RED}● $status${NC}"
            ;;
        inactive|stopped|disabled)
            echo -e "${YELLOW}○ $status${NC}"
            ;;
        *)
            echo "  $status"
            ;;
    esac
}

# Format MCP result content
format_mcp_content() {
    local result="$1"
    local format="${2:-text}"
    
    if [ "$format" = "json" ]; then
        format_json "$result"
        return
    fi
    
    if require_command jq 2>/dev/null; then
        # Extract text content from MCP result
        local content=$(echo "$result" | jq -r '.content[0].text // .content // .')
        
        # If it's still JSON, format it
        if echo "$content" | jq '.' >/dev/null 2>&1; then
            if [ "$format" = "table" ] && echo "$content" | jq -e 'type == "array"' >/dev/null 2>&1; then
                format_table "$content"
            else
                format_json "$content"
            fi
        else
            echo "$content"
        fi
    else
        echo "$result"
    fi
}

# Format error message
format_error_message() {
    local title="$1"
    local message="$2"
    local suggestion="${3:-}"
    
    print_error "$title"
    if [ -n "$message" ]; then
        echo ""
        echo "$message" | sed 's/^/  /'
    fi
    if [ -n "$suggestion" ]; then
        echo ""
        print_info "Suggestion: $suggestion"
    fi
}

# Format success message
format_success_message() {
    local title="$1"
    local details="${2:-}"
    
    print_success "$title"
    if [ -n "$details" ]; then
        echo ""
        echo "$details" | sed 's/^/  /'
    fi
}

# Format box/panel
format_box() {
    local title="$1"
    local content="$2"
    local width="${3:-60}"
    
    # Top border
    printf "╭"
    printf '─%.0s' $(seq 1 $((width - 2)))
    printf "╮\n"
    
    # Title
    if [ -n "$title" ]; then
        printf "│ ${BOLD}%-$((width - 4))s${NC} │\n" "$title"
        printf "├"
        printf '─%.0s' $(seq 1 $((width - 2)))
        printf "┤\n"
    fi
    
    # Content
    echo "$content" | while IFS= read -r line; do
        printf "│ %-$((width - 4))s │\n" "$line"
    done
    
    # Bottom border
    printf "╰"
    printf '─%.0s' $(seq 1 $((width - 2)))
    printf "╯\n"
}

# Format progress indicator
format_progress() {
    local current="$1"
    local total="$2"
    local width="${3:-40}"
    
    local percent=$((current * 100 / total))
    local filled=$((width * current / total))
    local empty=$((width - filled))
    
    printf "["
    printf "${GREEN}█%.0s${NC}" $(seq 1 $filled)
    printf "░%.0s" $(seq 1 $empty)
    printf "] %3d%%" "$percent"
}

# Export functions
export -f mask_secrets
export -f format_json
export -f format_table
export -f format_key_value
export -f format_list
export -f format_status
export -f format_mcp_content
export -f format_error_message
export -f format_success_message
export -f format_box
export -f format_progress
