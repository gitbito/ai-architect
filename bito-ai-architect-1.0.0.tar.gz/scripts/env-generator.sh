#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai

set -e

# Use SCRIPT_DIR from caller if already set (when sourced), otherwise calculate it
if [ -z "${SCRIPT_DIR:-}" ]; then
    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
fi
ENV_EXAMPLE="${SCRIPT_DIR}/.env-bitoarch.default"

# Source setup utilities for helper functions
if [ -f "${SCRIPT_DIR}/scripts/setup-utils.sh" ]; then
    source "${SCRIPT_DIR}/scripts/setup-utils.sh"
else
    generate_secret() {
        openssl rand -base64 32 2>/dev/null || head -c 32 /dev/urandom | base64
    }
    
    generate_encryption_key() {
        openssl rand -base64 32 2>/dev/null || head -c 32 /dev/urandom | base64 | tr -d '=' | tr '+/' '-_'
    }
fi

set_env_key_value() {
    local key="$1"
    local value="$2"
    local file="$3"

    # Create file if missing
    touch "$file"

    # If key exists → replace value
    if grep -q "^${key}=" "$file"; then
        # Use sed to replace entire line where KEY=...
        sed -i.bak "s|^${key}=.*|${key}=${value}|" "$file"
    else
        # Append new entry
        echo "${key}=${value}" >> "$file"
    fi
}

# Function to generate .env-bitoarch with all parameters
# Called by setup.sh with collected values, or standalone with auto-generated values
generate_env_with_params() {
    local output_file="$1"
    local bito_api_key="$2"
    local db_root_pass="$3"
    local db_user_pass="$4"
    local jwt_secret="$5"
    local cis_manager_api_key="$6"
    local cis_config_api_key="$7"
    local cis_provider_api_key="$8"
    local bito_mcp_access_token="$9"
    local secrets_encryption_key="${10}"
    local cis_config_version="${11}"
    local cis_manager_version="${12}"
    local cis_provider_version="${13}"
    local cis_provider_external_port="${14:-8080}"
    local cis_manager_external_port="${15:-9090}"
    local cis_config_external_port="${16:-8081}"
    local mysql_external_port="${17:-3306}"
    local git_provider="${18:-gitlab}"
    local git_access_token="${19}"
    local git_domain="${20}"
    local git_user="${21}"
    local cis_tracker_external_port="${22}"
    local cis_tracker_version="${23}"
    
    [ ! -f "$ENV_EXAMPLE" ] && echo "Error: $ENV_EXAMPLE not found" && return 1
    
    # Copy template (gets ALL properties with defaults)
    cp "$ENV_EXAMPLE" "$output_file"
    
    # Replace generated values
    sed -i.bak "s/# Generated on .*/# Generated on $(date)/" "$output_file"
    sed -i.bak "s|MYSQL_ROOT_PASSWORD=.*|MYSQL_ROOT_PASSWORD=${db_root_pass}|" "$output_file"
    sed -i.bak "s|MYSQL_PASSWORD=.*|MYSQL_PASSWORD=${db_user_pass}|" "$output_file"
    sed -i.bak "s|JWT_SECRET=.*|JWT_SECRET=${jwt_secret}|" "$output_file"
    sed -i.bak "s|BITO_API_KEY=.*|BITO_API_KEY=${bito_api_key}|" "$output_file"
    sed -i.bak "s|BITO_MCP_ACCESS_TOKEN=.*|BITO_MCP_ACCESS_TOKEN=${bito_mcp_access_token}|" "$output_file"
    sed -i.bak "s|CIS_MANAGER_API_KEY=.*|CIS_MANAGER_API_KEY=${cis_manager_api_key}|" "$output_file"
    sed -i.bak "s|CIS_CONFIG_API_KEY=.*|CIS_CONFIG_API_KEY=${cis_config_api_key}|" "$output_file"
    sed -i.bak "s|CIS_PROVIDER_API_KEY=.*|CIS_PROVIDER_API_KEY=${cis_provider_api_key}|" "$output_file"
    sed -i.bak "s|SECRETS_ENCRYPTION_KEY=.*|SECRETS_ENCRYPTION_KEY=${secrets_encryption_key}|" "$output_file"
    sed -i.bak "s|CIS_CONFIG_VERSION=.*|CIS_CONFIG_VERSION=${cis_config_version}|" "$output_file"
    sed -i.bak "s|CIS_MANAGER_VERSION=.*|CIS_MANAGER_VERSION=${cis_manager_version}|" "$output_file"
    sed -i.bak "s|CIS_PROVIDER_VERSION=.*|CIS_PROVIDER_VERSION=${cis_provider_version}|" "$output_file"
    sed -i.bak "s|CIS_PROVIDER_EXTERNAL_PORT=.*|CIS_PROVIDER_EXTERNAL_PORT=${cis_provider_external_port}|" "$output_file"
    sed -i.bak "s|CIS_MANAGER_EXTERNAL_PORT=.*|CIS_MANAGER_EXTERNAL_PORT=${cis_manager_external_port}|" "$output_file"
    sed -i.bak "s|CIS_CONFIG_EXTERNAL_PORT=.*|CIS_CONFIG_EXTERNAL_PORT=${cis_config_external_port}|" "$output_file"
    sed -i.bak "s|MYSQL_EXTERNAL_PORT=.*|MYSQL_EXTERNAL_PORT=${mysql_external_port}|" "$output_file"
    sed -i.bak "s|GIT_PROVIDER=.*|GIT_PROVIDER=${git_provider}|" "$output_file"
    sed -i.bak "s|GIT_ACCESS_TOKEN=.*|GIT_ACCESS_TOKEN=${git_access_token}|" "$output_file"
    sed -i.bak "s|GIT_DOMAIN_URL=.*|GIT_DOMAIN_URL=${git_domain}|" "$output_file"
    sed -i.bak "s|GIT_USER=.*|GIT_USER=${git_user}|" "$output_file"
    sed -i.bak "s|CIS_TRACKER_EXTERNAL_PORT=.*|CIS_TRACKER_EXTERNAL_PORT=${cis_tracker_external_port}|" "$output_file"
    sed -i.bak "s|CIS_TRACKER_VERSION=.*|CIS_TRACKER_VERSION=${cis_tracker_version}|" "$output_file"

    
    rm -f "${output_file}.bak"
    chmod 600 "$output_file"
    
    echo "✓ Environment file generated successfully: $output_file"
    return 0
}

# Simplified function for standalone use (auto-generates everything)
generate_env_file() {
    local output_file="${1:-.env-bitoarch}"
    
    [ ! -f "$ENV_EXAMPLE" ] && echo "Error: $ENV_EXAMPLE not found" && return 1
    
    # Auto-generate all secrets
    local DB_ROOT_PASS=$(generate_secret)
    local DB_USER_PASS=$(generate_secret)
    local JWT_SECRET=$(generate_secret)
    local BITO_API_KEY=$(generate_secret)
    local CIS_MANAGER_API_KEY=$(generate_secret)
    local CIS_CONFIG_API_KEY=$(generate_secret)
    local CIS_PROVIDER_API_KEY=$(generate_secret)
    local BITO_MCP_ACCESS_TOKEN=$(generate_secret)
    local SECRETS_ENCRYPTION_KEY=$(generate_encryption_key)
    
    # Load versions
    local CIS_CONFIG_VERSION="latest"
    local CIS_MANAGER_VERSION="latest"
    local CIS_PROVIDER_VERSION="latest"
    
    local versions_file="${SCRIPT_DIR}/versions/service-versions.json"
    if [ -f "$versions_file" ] && command -v jq >/dev/null 2>&1; then
        CIS_CONFIG_VERSION=$(jq -r '.services."cis-config".version' "$versions_file" 2>/dev/null || echo "latest")
        CIS_MANAGER_VERSION=$(jq -r '.services."cis-manager".version' "$versions_file" 2>/dev/null || echo "latest")
        CIS_PROVIDER_VERSION=$(jq -r '.services."cis-provider".version' "$versions_file" 2>/dev/null || echo "latest")
    fi
    
    # Call shared function
    generate_env_with_params "$output_file" \
        "$BITO_API_KEY" "$DB_ROOT_PASS" "$DB_USER_PASS" "$JWT_SECRET" \
        "$CIS_MANAGER_API_KEY" "$CIS_CONFIG_API_KEY" "$CIS_PROVIDER_API_KEY" \
        "$BITO_MCP_ACCESS_TOKEN" "$SECRETS_ENCRYPTION_KEY" \
        "$CIS_CONFIG_VERSION" "$CIS_MANAGER_VERSION" "$CIS_PROVIDER_VERSION"
    
    return $?
}

# Main
if [ "${BASH_SOURCE[0]}" == "${0}" ]; then
    generate_env_file "${1:-.env-bitoarch-test}"
fi
