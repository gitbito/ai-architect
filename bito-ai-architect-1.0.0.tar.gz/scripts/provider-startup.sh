#!/bin/sh
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
# ============================================================================
# xMCP Provider Config Processor
# ============================================================================
# Processes config at container startup by mapping JSON fields to env vars
# Uses jq for type-safe JSON manipulation
# ============================================================================

set -e

CONFIG_FILE="/opt/bito/xmcp/config/default.json"
CONFIG_TEMP="${CONFIG_FILE}.tmp"

# Check if config exists
if [ ! -f "$CONFIG_FILE" ]; then
    echo "ERROR: Config not found at $CONFIG_FILE"
    exit 1
fi

echo "✓ Processing configuration with environment values..."

# Check if jq is available, install if missing (containers run as root, no sudo needed)
if ! command -v jq >/dev/null 2>&1; then
    echo "ℹ jq not found, installing..."
    
    jq_installed=false
    
    # Try package managers
    if command -v apk >/dev/null 2>&1; then
        echo "  Trying apk (Alpine)..."
        if apk add --no-cache jq 2>&1; then
            jq_installed=true
        fi
    elif command -v apt-get >/dev/null 2>&1; then
        echo "  Trying apt-get (Debian/Ubuntu)..."
        if apt-get update 2>&1 && apt-get install -y jq 2>&1; then
            jq_installed=true
        fi
    elif command -v yum >/dev/null 2>&1; then
        echo "  Trying yum (RHEL/CentOS)..."
        if yum install -y jq 2>&1; then
            jq_installed=true
        fi
    elif command -v dnf >/dev/null 2>&1; then
        echo "  Trying dnf (Fedora/RHEL 8+)..."
        if dnf install -y jq 2>&1; then
            jq_installed=true
        fi
    fi
    
    # Fallback: download jq binary directly
    if [ "$jq_installed" = "false" ]; then
        echo "  Package manager installation failed, downloading jq binary..."
        if command -v curl >/dev/null 2>&1 || command -v wget >/dev/null 2>&1; then
            JQ_VERSION="1.6"
            JQ_URL="https://github.com/stedolan/jq/releases/download/jq-${JQ_VERSION}/jq-linux64"
            
            if command -v curl >/dev/null 2>&1; then
                curl -sL "$JQ_URL" -o /usr/local/bin/jq && chmod +x /usr/local/bin/jq && jq_installed=true
            elif command -v wget >/dev/null 2>&1; then
                wget -q "$JQ_URL" -O /usr/local/bin/jq && chmod +x /usr/local/bin/jq && jq_installed=true
            fi
        fi
    fi
    
    if [ "$jq_installed" = "true" ] && command -v jq >/dev/null 2>&1; then
        echo "✓ jq installed successfully"
    else
        echo "ERROR: Failed to install jq"
        echo "Please ensure jq is available in the container image"
        exit 1
    fi
fi

# Update specific JSON paths with environment variable values
# Uses --arg for safe string handling and type conversion where needed
# Write to temp file first for atomic update
jq \
  --arg port "${CIS_PROVIDER_PORT:-8080}" \
  --arg host "${CIS_SERVER_HOST:-0.0.0.0}" \
  --arg apiKey "${CIS_PROVIDER_API_KEY}" \
  --arg bearerToken "${BITO_MCP_ACCESS_TOKEN}" \
  --arg dataDir "${XMCP_DATA_DIR}" \
  --arg metadataDir "${XMCP_METADATA_DIR}" \
  --arg reposDir "${CIS_CLONE_DIR}" \
  --arg zoektBinary "${ZOEKT_BINARY_PATH:-/usr/local/bin/zoekt-webserver}" \
  --arg jwtSecret "${JWT_SECRET}" \
  --arg configUrl "http://ai-architect-config:${CIS_CONFIG_PORT:-8081}" \
  --arg managerUrl "http://ai-architect-manager:${CIS_MANAGER_PORT:-9090}" \
  --arg logLevel "${LOG_LEVEL:-info}" \
  '
  .transport.http.port = ($port | tonumber) |
  .transport.http.host = $host |
  .transport.http.internalApiKey = $apiKey |
  .transport.http.bearerToken = $bearerToken |
  .transport.https.host = $host |
  .transport.https.internalApiKey = $apiKey |
  .transport.https.bearerToken = $bearerToken |
  .data.dataDir = $dataDir |
  .data.metadataDir = $metadataDir |
  .data.reposDir = $reposDir |
  .zoekt.binaryPath = $zoektBinary |
  .services.cis_config_url = $configUrl |
  .services.cis_manager_url = $managerUrl |
  .auth.jwt_secret = $jwtSecret |
  .auth.bearer_token = $bearerToken |
  .logging.level = $logLevel
  ' "$CONFIG_FILE" > "$CONFIG_TEMP"

if ! jq empty "$CONFIG_TEMP" 2>/dev/null; then
    echo "ERROR: Processed config is not valid JSON"
    rm -f "$CONFIG_TEMP"
    exit 1
fi

if ! mv "$CONFIG_TEMP" "$CONFIG_FILE"; then
    echo "ERROR: Failed to write processed config to $CONFIG_FILE"
    rm -f "$CONFIG_TEMP"
    exit 1
fi

echo "✓ Configuration processed successfully and written to $CONFIG_FILE"
echo ""
echo "Starting xMCP Server with config: $CONFIG_FILE"
echo "========================================"

# Execute the default container command
exec "$@"
