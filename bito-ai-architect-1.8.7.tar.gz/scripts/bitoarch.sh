#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
# Bito's AI Architect CLI
# Command-line interface for managing Bito's AI Architect services

# Get script directory (resolve symlinks)
SOURCE="${BASH_SOURCE[0]}"
while [ -h "$SOURCE" ]; do
    DIR="$( cd -P "$( dirname "$SOURCE" )" && pwd )"
    SOURCE="$(readlink "$SOURCE")"
    [[ $SOURCE != /* ]] && SOURCE="$DIR/$SOURCE"
done
DIR="$( cd -P "$( dirname "$SOURCE" )" && pwd )"

# SCRIPT_DIR should always point to the scripts directory
SCRIPT_DIR="$DIR"

# Source path manager first (for standard paths)
source "${SCRIPT_DIR}/lib/path-manager.sh"
# Feature-flag helpers (sso_ui_suppressed) -- small, independent; safe to
# source early so show_main_help can gate the SSO section.
# shellcheck disable=SC1091
source "${SCRIPT_DIR}/lib/bitoarch-config.sh"

# Source core libraries
source "${SCRIPT_DIR}/lib/cli-core.sh"
source "${SCRIPT_DIR}/lib/http-client.sh"
source "${SCRIPT_DIR}/lib/output-formatter.sh"
source "${SCRIPT_DIR}/lib/config-backup-manager.sh"

# Rewrite a file in place by piping it through a filter command. Uses an
# atomic temp-file + mv so a half-written rewrite can't truncate the source.
# Falls back to a sibling path if mktemp is unavailable.
# Usage: _rewrite_in_place <file> <cmd...>
_rewrite_in_place() {
    local file="$1"; shift
    [ -f "$file" ] || return 1
    local tmp
    tmp="$(mktemp 2>/dev/null)" || tmp="${file}.norm.$$"
    if "$@" < "$file" > "$tmp"; then
        mv "$tmp" "$file"
    else
        local _rc=$?
        rm -f "$tmp" 2>/dev/null
        return $_rc
    fi
}

# Pre-compose-up hook: provision the mkcert HTTPS cert + export
# HOST_MCP_CERT_DIR / XMCP_INTERNAL_PORT for docker-compose. Idempotent and
# gated on MCP_TRANSPORT=https inside mcp_cert_prepare_for_compose, so it is
# a cheap no-op on Enterprise / http installs.
_bitoarch_prep_compose_env() {
    local env_file="$1"
    [ -n "$env_file" ] && [ -f "$env_file" ] && {
        set -a; . "$env_file" 2>/dev/null || true; set +a
    }
    if [ -f "${SCRIPT_DIR}/lib/mcp-cert.sh" ]; then
        # shellcheck disable=SC1091
        source "${SCRIPT_DIR}/lib/mcp-cert.sh"
        mcp_cert_prepare_for_compose >/dev/null 2>&1 || true
    fi
}

# Version — read from versions/service-versions.json (single source of truth)
_versions_file="${SCRIPT_DIR}/../versions/service-versions.json"
if [ -f "$_versions_file" ] && command -v jq >/dev/null 2>&1; then
    CLI_VERSION=$(jq -r '.platform_info.version // "1.0.0"' "$_versions_file" 2>/dev/null)
elif [ -f "$_versions_file" ]; then
    CLI_VERSION=$(grep -A2 '"platform_info"' "$_versions_file" | grep '"version"' | head -1 | cut -d'"' -f4 || echo "1.0.0")
else
    CLI_VERSION="1.0.0"
fi

# Show main help
show_main_help() {
    # Gate SSO section on the existing SKIP_SSO_PROMPT flag (set by SA
    # install_run, persisted into .env-bitoarch). Reused across setup.sh,
    # install.sh, help, and Next-Steps hints so "hide SSO UI" is a single
    # switch. Default (flag unset) = show SSO (prod behavior).
    local _hide_sso=0
    if command -v sso_ui_suppressed >/dev/null 2>&1 && sso_ui_suppressed; then
        _hide_sso=1
    fi

    cat << EOF
╔═══════════════════════════════════════════════════════════════╗
║          Bito's AI Architect - Command Line Interface         ║
╚═══════════════════════════════════════════════════════════════╝

USAGE:
  bitoarch <command> [options]

STATUS:
  status                        Show all services status
  health                        Check health of all services
  diagnose --bundle             Collect a shareable diagnostics .tar.gz for
                                support (use --output <dir> for path)
  info                          Show platform information

LIFECYCLE:
  start                         Start stopped services (idempotent)
  stop                          Stop all services (keeps data)
  restart [--force]             Restart services (--force reloads env, recreates all)
  logs [service]                Tail service logs (-f; all if omitted)
  upgrade [--version=<ver>]     Upgrade platform (latest by default)
  reset                         Remove services, volumes, config (keeps install dir)
  uninstall                     Full removal (services + install directory)

REPOSITORIES:
  add-repo <ns>                    Add repository by namespace
  remove-repo <ns>                 Remove repository by namespace
  add-repos                        Load repos from YAML (default path if omitted)
  update-repos                     Update repos from YAML (default path if omitted)
  repo-info <name>                 Get repository details
  fetch-repo-list [--force-load]   Sync repo list from git provider

INDEXING:
  show-config                      Show current indexing configuration
  index-repos [--only-new-repos]   Trigger workspace repository indexing
  index-status                     Check indexing status
  index-repo-list                  List all indexed repositories
  stop-indexing                    Stop indexing completely
  create-index-scheduler           Create scheduler tasks
  update-index-scheduler           Update existing scheduler tasks

CONFIGURATION:
  update-api-key                Update Bito API key
  update-git-creds              Update Git provider credentials
  update-llm-config             Update custom LLM provider configuration
  rotate-mcp-token              Rotate MCP access token
  config path [env|repos|llm]   Print config file path (default: env)
  config edit [env|repos|llm]   Open config file in \$EDITOR (default: env)

INSIGHTS:
  insights config                                Show insights configuration
  insights status                                Show detailed insights workflow status
  insights run [--force]                         Run insights analysis (--force re-analyzes all)
  insights enable [git|ticket-tracker|docs]      Enable an insights feature (interactive)
  insights disable [git|ticket-tracker|docs]     Disable an insights feature
  insights set-lookback [git|ticket-tracker]     Set lookback days for a feature
  insights tracker-projects [action] [KEY …]     Manage project keys (list|add|remove|set)
  insights discover-tracker-projects             List accessible ticket-tracker projects
  insights update-ticket-tracker                 Update ticket-tracker credentials
  insights update-doc-config                     Update doc integration credentials
EOF

    if [ "$_hide_sso" -eq 0 ]; then
        cat << 'EOF'

SSO:
  sso setup                     Configure SSO (Enterprise IdP or Bito)
  sso status                    Check SSO configuration and verification
  sso enable                    Re-enable previously disabled SSO
  sso disable                   Disable SSO configuration
  sso rotate-key                Rotate SSO keys
EOF
    fi

    local _show_local_mcp=0
    if command -v mcp_auto_install_enabled >/dev/null 2>&1 && mcp_auto_install_enabled; then
        _show_local_mcp=1
    fi

    cat << EOF

MCP:
  mcp-info                      Show MCP configuration
  mcp-test                      Test MCP connection
  mcp-tools                     List available MCP tools
  mcp-tool-info <name>          Show MCP tool details
  mcp-capabilities              Show MCP server capabilities
EOF

    if [ "$_show_local_mcp" -eq 1 ]; then
        cat << EOF
  mcp-install [--email <addr>]  Register MCP with installed coding agents
  mcp-uninstall                 Deregister MCP from installed coding agents
  mcp-cert <subcmd>             Cert status / renew / paths — \`mcp-cert --help\`
EOF
    fi

    cat << EOF

OPTIONS:
  --help, -h                    Show this help
  <command> --help              Command-specific help

EXAMPLES:
  bitoarch status
  bitoarch add-repo myorg/myrepo
  bitoarch index-repos --only-new-repos
  bitoarch config edit repos

DOCS:    ${AI_ARCHITECT_DOCS_HOME_URL:-https://docs.bito.ai/ai-architect}
VERSION: ${CLI_VERSION}

To install or reinstall, use the install bootstrap (curl | bash).
See ${AI_ARCHITECT_DOCS_URL:-https://docs.bito.ai/ai-architect/install-ai-architect-self-hosted} for the install command.
EOF
}

# Source output modules (needed by adapters)
source "${SCRIPT_DIR}/lib/output-blocks.sh"
source "${SCRIPT_DIR}/lib/output-fields.sh"

# Source adapters
source "${SCRIPT_DIR}/lib/adapters/provider-adapter.sh"
source "${SCRIPT_DIR}/lib/adapters/config-adapter.sh"
source "${SCRIPT_DIR}/lib/adapters/platform-adapter.sh"
source "${SCRIPT_DIR}/lib/adapters/manager-adapter.sh"
source "${SCRIPT_DIR}/lib/adapters/xmcp-adapter.sh"
source "${SCRIPT_DIR}/lib/insights-cli.sh"

# Source diagnose (platform_diagnose entry point + reusable atomic predicates).
# Self-contained -- does not modify any adapter; safe to source after them.
source "${SCRIPT_DIR}/lib/diagnose.sh"

# Source cleanup library (reset_run + uninstall_run)
# NOTE: scripts/lib/install.sh is NOT sourced here. Install is only invoked
# by the CDN bootstrap (scripts/bitoarch-install.sh); there's no
# `bitoarch install` CLI subcommand.
source "${SCRIPT_DIR}/lib/uninstall.sh"

# Lifecycle output blocks (start / restart / update) live in
# scripts/lib/output-blocks.sh: render_lifecycle_success_block,
# render_lifecycle_failure_block.

# Main command dispatcher
main() {
    # Check if no arguments
    if [ $# -eq 0 ]; then
        show_main_help
        exit 0
    fi

    # Handle global --help / --version BEFORE loading config so these work on a
    # fresh clone / pre-install machine (load_env_config hard-fails if there's
    # no .env-bitoarch yet).
    if [ "$1" = "--help" ] || [ "$1" = "-h" ]; then
        show_main_help
        exit 0
    fi

    if [ "$1" = "--version" ] || [ "$1" = "-v" ]; then
        echo "Bito AI Architect CLI v${CLI_VERSION}"
        exit 0
    fi

    # Env-loading tiers:
    #   HARD LOAD (domain commands) — fail if .env-bitoarch missing
    #   SOFT LOAD (discovery commands) — try to load; degrade gracefully pre-install
    #   NO LOAD (pure delegators + unknowns) — setup.sh or the catch-all handles it
    # Unknown commands deliberately fall through so they reach the "*)" catch-all
    # with a clean "Unknown command" error instead of "Config not found".
    case "$1" in
        index-repos|index-status|pause-indexing|resume-indexing|stop-indexing|\
        create-index-scheduler|update-index-scheduler|index-repo-list|show-config|\
        add-repo|remove-repo|add-repos|update-repos|repo-info|fetch-repo-list|\
        update-api-key|update-git-creds|update-llm-config|rotate-mcp-token|\
        insights|tracker-projects|discover-tracker-projects|\
        mcp-test|mcp-tools|mcp-tool-info|mcp-capabilities|mcp-info|mcp-install|mcp-uninstall|sso|\
        restart|update)
            load_env_config || exit 1
            ;;
        status|health|info|mcp-cert|diagnose)
            # Soft load: env if present, otherwise the handler renders a
            # pre-install banner / state-only output without bailing.
            # diagnose joins this tier because its primary use case is
            # post-install ("why is X broken?") AND pre-install ("why didn't
            # setup finish?").
            [ -f "$(get_config_file)" ] && load_env_config >/dev/null 2>&1 || true
            ;;
    esac

    # Get command
    local command="$1"
    shift


    # Route to direct commands or legacy service handlers
    case "$command" in
        # Core Operations
        index-repos)
            manager_sync_simple "$@"
            ;;
        index-status)
            manager_status "$@"
            ;;
        pause-indexing)
            manager_pause_indexing "$@"
            ;;
        resume-indexing)
            manager_resume_indexing "$@"
            ;;
        stop-indexing)
            manager_stop_indexing "$@"
            ;;
        create-index-scheduler)
            manager_scheduler_create "$@"
            ;;
        update-index-scheduler)
            manager_scheduler_update "$@"
            ;;
        index-repo-list)
            provider_repo_list "$@"
            ;;
        show-config)
            config_repo_get "$@"
            ;;
        
        # Repository Management
        add-repo)
            if [ -f "$1" ]; then
                print_error "Use ${YELLOW}bitoarch add-repos <file>${NC} for YAML files"
                exit 1
            fi
            config_repo_add_namespace "$@"
            ;;
        remove-repo)
            config_repo_remove_namespace "$@"
            ;;
        add-repos)
            config_repo_add_from_file "$@"
            ;;
        update-repos)
            config_repo_update_from_file "$@"
            ;;
        repo-info)
            provider_repo_info "$@"
            ;;
        fetch-repo-list)
          fetch_repo_config_from_api "$@"
          ;;
        
        # Service status / health / info
        status)
            platform_status "$@"
            ;;
        health)
            platform_health "$@"
            ;;
        info)
            platform_info "$@"
            ;;
        diagnose)
            platform_diagnose "$@"
            ;;

        # Lifecycle commands -- delegate to setup.sh's existing flag handlers
        # for identical behavior to production (`./setup.sh --X`). Standalone
        # users see exactly the same output and exit codes as prod users.
        stop)
            exec "${SCRIPT_DIR}/../setup.sh" --stop
            ;;
        # restart -- no install → delegate to setup.sh --restart (same
        # "Services Not Running" UX as prod). With install → compact output
        # matching `bitoarch start`: single progress_run + shared success/
        # failure body. No per-service "✅ Restarted" ticker (industry
        # standard: docker compose restart + helm rollback + kubectl
        # rollout restart all produce terse output).
        restart)
            local env_file force=false
            [ "${1:-}" = "--force" ] && force=true
            env_file=$(get_config_file)
            if [ ! -f "$env_file" ]; then
                if [ "$force" = "true" ]; then
                    exec "${SCRIPT_DIR}/../setup.sh" --force-restart
                fi
                exec "${SCRIPT_DIR}/../setup.sh" --restart
            fi

            # Pre-flight: restart requires running services. If zero are
            # running, report that and point at `bitoarch start` instead
            # of silently bringing everything up from nothing. Applies to
            # both plain restart and --force.
            local deploy_type
            deploy_type=$(get_deployment_type 2>/dev/null || echo "docker-compose")
            local _running_any=0
            if [ "$deploy_type" = "kubernetes" ]; then
                _running_any=$(kubectl get pods -n bito-ai-architect --no-headers 2>/dev/null \
                    | awk '$3=="Running"' | wc -l | tr -d ' ')
            else
                _running_any=$(docker ps -q --filter "name=ai-architect-" 2>/dev/null | wc -l | tr -d ' ')
            fi
            if [ "$_running_any" -eq 0 ]; then
                print_warning "No AI Architect services are currently running"
                print_info "To start services, run: ${YELLOW}bitoarch start${NC}"
                exit 1
            fi
            # K8s installs: inline compact flow matching Docker's UX (single
            # progress_run + render_lifecycle_success_block). Uses helpers
            # from kubernetes-manager.sh which silence helm/kubectl output
            # to the setup log so the terminal shows just the progress line.
            if [ "$(get_deployment_type 2>/dev/null)" = "kubernetes" ]; then
                # shellcheck disable=SC1091
                source "${SCRIPT_DIR}/lib/progress-output.sh"
                # shellcheck disable=SC1091
                export SCRIPT_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
                source "${SCRIPT_DIR}/scripts/kubernetes-manager.sh" 2>/dev/null || true
                local progress_label="Restarting AI Architect"
                if [ "$force" = "true" ]; then
                    progress_label="Recreating AI Architect"
                    # Live yaml reload -- source the yaml helpers directly
                    # to avoid pulling in install_run / setup.sh.
                    # shellcheck disable=SC1091
                    source "${SCRIPT_DIR}/scripts/lib/install-yaml.sh" 2>/dev/null || true
                    if command -v validate_install_yaml_api_key >/dev/null 2>&1; then
                        validate_install_yaml_api_key "$env_file" || exit 1
                    fi
                    command -v apply_install_yaml_to_env_file >/dev/null 2>&1 \
                        && apply_install_yaml_to_env_file "$env_file"
                fi
                set +e
                progress_run "$progress_label" -- \
                    bash -c "bitoarch_k8s_recreate '$force'"
                local k8s_rc=$?
                set +e
                if [ "$k8s_rc" -eq 0 ]; then
                    if [ "$force" = "true" ]; then
                        render_lifecycle_success_block "AI Architect Recreated" 0
                        _platform_reregister_mcp_with_agents
                    else
                        render_lifecycle_success_block "AI Architect Restarted" 0
                    fi
                else
                    render_lifecycle_failure_block "restart"
                    exit 1
                fi
                exit 0
            fi
            # shellcheck disable=SC1091
            source "${SCRIPT_DIR}/docker-manager.sh" 2>/dev/null || true
            # shellcheck disable=SC1091
            source "${SCRIPT_DIR}/lib/progress-output.sh"
            local compose_cmd
            compose_cmd=$(get_docker_compose_cmd) || exit 1
            cd "${SCRIPT_DIR}/.." || exit 1

            local action_verb="restart" progress_label="Restarting AI Architect"
            # Full lifecycle list (tracker, temporal, worker INCLUDED for compose
            # ops; hidden only from user-facing status/health UI). Sourced from
            # constants.sh so this list stays in sync with K8s rollout iteration
            # and setup.sh's parity. Falls back to a hardcoded literal if the
            # constant didn't load (defensive; constants.sh is always present
            # in a valid install).
            local svc_list
            if [ -n "${BITOARCH_LIFECYCLE_SERVICES+x}" ] && [ "${#BITOARCH_LIFECYCLE_SERVICES[@]}" -gt 0 ]; then
                svc_list="${BITOARCH_LIFECYCLE_SERVICES[*]}"
            else
                svc_list="ai-architect-mysql ai-architect-temporal ai-architect-config ai-architect-tracker ai-architect-manager ai-architect-worker ai-architect-provider"
            fi

            # Phased up -d in 3 batches with --wait between; --force adds
            # --force-recreate to each. compose restart isn't used because it
            # ignores depends_on (cis-manager / cis-config would start before
            # MySQL healthy and nil-pointer panic on DB ping). The phases also
            # gate cis-manager on cis-config + cis-tracker healthy at runtime.
            local compose_cmd_pre="" extra_flags=""
            if [ "$force" = "true" ]; then
                action_verb="recreate"; progress_label="Recreating AI Architect"
                extra_flags="--force-recreate"
                # Live yaml reload: apply $HOME/.bitoarch/install.yaml
                # onto env_file before recreate. No-op if yaml absent.
                # shellcheck disable=SC1091
                source "${SCRIPT_DIR}/lib/install-yaml.sh" 2>/dev/null || true
                # If the user changed BITO_API_KEY in the yaml, validate it
                # against the tracking endpoint BEFORE rewriting env_file or
                # recreating containers. Bad key = hard fail; users shouldn't
                # silently restart into broken auth.
                if command -v validate_install_yaml_api_key >/dev/null 2>&1; then
                    validate_install_yaml_api_key "$env_file" || exit 1
                fi
                command -v apply_install_yaml_to_env_file >/dev/null 2>&1 \
                    && apply_install_yaml_to_env_file "$env_file"
            else
                compose_cmd_pre="$compose_cmd --env-file '$env_file' stop $svc_list"
            fi

            local wait_timeout="${PHASED_WAIT_TIMEOUT_SECS:-900}"
            local phase1="$compose_cmd --env-file '$env_file' up -d --wait --wait-timeout \"$wait_timeout\" $extra_flags ai-architect-mysql ai-architect-temporal"
            local phase2="$compose_cmd --env-file '$env_file' up -d --wait --wait-timeout \"$wait_timeout\" $extra_flags ai-architect-config ai-architect-tracker"
            local phase3="$compose_cmd --env-file '$env_file' up -d --wait --wait-timeout \"$wait_timeout\" $extra_flags ai-architect-manager ai-architect-worker ai-architect-provider"

            _bitoarch_prep_compose_env "$env_file"

            # Disable errexit across the progress_run + rc-capture. Some
            # sourced helpers (or a future caller) may set -e; in that case
            # progress_run's non-zero return would exit bash before we get
            # to inspect $rc.
            set +e
            progress_run "$progress_label" -- \
                bash -c "${compose_cmd_pre:+$compose_cmd_pre && }$phase1 && $phase2 && $phase3 && \
                         wait_for_services_healthy ${RESTART_WAIT_TIMEOUT_SECS:-240} ${SERVICE_WAIT_GRACE_SECS:-60}"
            local rc=$?
            set +e

            # Verify user-visible running state before rendering success.
            # wait_for_services_healthy can return rc=0 on transient
            # "running" states that crash immediately after; rc=2 "warming"
            # is the wrong diagnosis if zero containers are running.
            local running_now=0
            for svc in "${BITOARCH_USER_SERVICES[@]}"; do
                local st
                st=$(docker inspect --format='{{.State.Status}}' "$svc" 2>/dev/null)
                [ "$st" = "running" ] && running_now=$((running_now + 1))
            done
            if [ "$running_now" -eq 0 ]; then
                # Containers are not actually running despite the health-wait
                # result. This is the real user-visible state; render failure
                # accurately so the follow-up `bitoarch status` matches what
                # the lifecycle command just reported.
                render_lifecycle_failure_block "$action_verb"
                exit 1
            fi

            if [ $rc -eq 0 ] || [ $rc -eq 2 ]; then
                if [ "$force" = "true" ]; then
                    render_lifecycle_success_block "AI Architect Recreated" "$rc"
                    _platform_reregister_mcp_with_agents
                    # Match K8s helm post-upgrade hook: re-run Temporal post-deploy on --force recreate.
                    # shellcheck disable=SC1091
                    source "${SCRIPT_DIR}/service-manager.sh" 2>/dev/null || true
                    if command -v run_temporal_post_deploy >/dev/null 2>&1; then
                        run_temporal_post_deploy
                    fi
                else
                    render_lifecycle_success_block "AI Architect Restarted" "$rc"
                fi
            else
                render_lifecycle_failure_block "$action_verb"
                exit 1
            fi
            ;;
        # logs -- no args: delegate to setup.sh --logs (tails all services,
        # same UX as prod `./setup.sh --logs`). With args: filter to the
        # named service via docker compose directly. setup.sh --logs
        # hardcodes the full-stack tail and doesn't accept service args,
        # so we bypass it for the filtered case.
        # Accepts both short names ("manager") and full container names
        # ("ai-architect-manager") -- matches what render_lifecycle_failure_block
        # hints at ("Inspect: bitoarch logs <short-name>").
        logs)
            if [ $# -eq 0 ]; then
                exec "${SCRIPT_DIR}/../setup.sh" --logs
            fi
            # `setup` tails the unified install/lifecycle log; service names
            # tail per-container logs further down.
            if [ "$1" = "setup" ]; then
                exec tail -F "$(get_log_dir)/setup.log"
            fi
            local env_file
            env_file=$(get_config_file)
            if [ ! -f "$env_file" ]; then
                exec "${SCRIPT_DIR}/../setup.sh" --logs
            fi
            local svc="$1"
            [[ "$svc" != ai-architect-* ]] && svc="ai-architect-$svc"

            # Branch by deployment type. K8s installs must use kubectl logs
            # (docker compose is unavailable); Docker installs use compose.
            local deploy_type
            deploy_type=$(get_deployment_type 2>/dev/null || echo "unknown")
            if [ "$deploy_type" = "kubernetes" ]; then
                local namespace="bito-ai-architect"
                exec kubectl logs -f -n "$namespace" -l "app.kubernetes.io/component=${svc#ai-architect-}" --all-containers=true
            fi

            # shellcheck disable=SC1091
            source "${SCRIPT_DIR}/docker-manager.sh" 2>/dev/null || true
            local compose_cmd
            compose_cmd=$(get_docker_compose_cmd) || exit 1
            cd "${SCRIPT_DIR}/.." || exit 1
            exec $compose_cmd --env-file "$env_file" logs -f "$svc"
            ;;
        # update -- refresh service images per versions/service-versions.json.
        # Multi-step (pull is distinctly slow + user-meaningful; the two
        # phases match cargo/kubectl convention for deploy-then-roll).
        # No per-service tickers (industry standard: docker compose pull
        # shows its own per-image progress when unsilenced; our wrapper
        # silences it and emits a single step line).
        update)
            local env_file
            env_file=$(get_config_file)
            if [ ! -f "$env_file" ]; then
                exec "${SCRIPT_DIR}/../setup.sh" --update
            fi
            # K8s installs: inline compact flow via bitoarch_k8s_update
            # (bumps version tags + helm upgrade + rollout; silent). Matches
            # the Docker UX — single progress_run + unified success block.
            if [ "$(get_deployment_type 2>/dev/null)" = "kubernetes" ]; then
                # shellcheck disable=SC1091
                source "${SCRIPT_DIR}/lib/progress-output.sh"
                export SCRIPT_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
                # shellcheck disable=SC1091
                source "${SCRIPT_DIR}/scripts/kubernetes-manager.sh" 2>/dev/null || true
                set +e
                progress_run "Updating AI Architect" -- \
                    bash -c "bitoarch_k8s_update"
                local k8s_upd_rc=$?
                if [ "$k8s_upd_rc" -eq 0 ]; then
                    render_lifecycle_success_block "AI Architect Updated" 0
                else
                    render_lifecycle_failure_block "update"
                    exit 1
                fi
                exit 0
            fi
            # shellcheck disable=SC1091
            source "${SCRIPT_DIR}/docker-manager.sh" 2>/dev/null || true
            # shellcheck disable=SC1091
            source "${SCRIPT_DIR}/lib/progress-output.sh"
            # shellcheck disable=SC1091
            source "${SCRIPT_DIR}/env-generator.sh" 2>/dev/null || true
            export -f refresh_versions_from_service_json 2>/dev/null || true
            local compose_cmd
            compose_cmd=$(get_docker_compose_cmd) || exit 1
            cd "${SCRIPT_DIR}/.." || exit 1

            # Full lifecycle list (tracker, temporal, worker INCLUDED for compose
            # ops; hidden only from user-facing status/health UI). Sourced from
            # constants.sh; see the equivalent block in `restart` for rationale.
            local svc_list
            if [ -n "${BITOARCH_LIFECYCLE_SERVICES+x}" ] && [ "${#BITOARCH_LIFECYCLE_SERVICES[@]}" -gt 0 ]; then
                svc_list="${BITOARCH_LIFECYCLE_SERVICES[*]}"
            else
                svc_list="ai-architect-mysql ai-architect-temporal ai-architect-config ai-architect-tracker ai-architect-manager ai-architect-worker ai-architect-provider"
            fi
            local versions_file="${SCRIPT_DIR}/../versions/service-versions.json"

            set +e  # guard against errexit from sourced helpers; see start/restart
            progress_start_multi 2
            # refresh_versions_from_service_json takes 1 arg (env_file) and
            # derives versions_file from $SCRIPT_DIR internally. Set the
            # REPO ROOT as SCRIPT_DIR inside the child bash so the derived
            # path resolves to versions/service-versions.json correctly.
            # (bitoarch.sh's SCRIPT_DIR points at scripts/, not repo root.)
            local repo_root
            repo_root=$(cd "${SCRIPT_DIR}/.." && pwd)
            progress_step "Pulling latest images" -- \
                bash -c "SCRIPT_DIR='$repo_root' refresh_versions_from_service_json '$env_file' >/dev/null 2>&1 && \
                         $compose_cmd --env-file '$env_file' pull $svc_list"
            local pull_rc=$?
            if [ "$pull_rc" -ne 0 ]; then
                render_lifecycle_failure_block "update"
                exit 1
            fi
            # Phased up -d --force-recreate in 3 batches with --wait, mirroring
            # the restart path; see the comment in the `restart` case for the
            # depends_on / cold-boot-panic rationale.
            local upd_wait_timeout="${PHASED_WAIT_TIMEOUT_SECS:-900}"
            local upd_phase1="$compose_cmd --env-file '$env_file' up -d --wait --wait-timeout \"$upd_wait_timeout\" --force-recreate ai-architect-mysql ai-architect-temporal"
            local upd_phase2="$compose_cmd --env-file '$env_file' up -d --wait --wait-timeout \"$upd_wait_timeout\" --force-recreate ai-architect-config ai-architect-tracker"
            local upd_phase3="$compose_cmd --env-file '$env_file' up -d --wait --wait-timeout \"$upd_wait_timeout\" --force-recreate ai-architect-manager ai-architect-worker ai-architect-provider"
            progress_step "Restarting services" -- \
                bash -c "$upd_phase1 && $upd_phase2 && $upd_phase3 && \
                         wait_for_services_healthy ${RESTART_WAIT_TIMEOUT_SECS:-240} ${SERVICE_WAIT_GRACE_SECS:-60}"
            local restart_rc=$?
            if [ "$restart_rc" -eq 0 ] || [ "$restart_rc" -eq 2 ]; then
                render_lifecycle_success_block "AI Architect Updated" "$restart_rc"
                # Match K8s helm post-upgrade hook: re-run Temporal post-deploy after image update.
                # shellcheck disable=SC1091
                source "${SCRIPT_DIR}/service-manager.sh" 2>/dev/null || true
                if command -v run_temporal_post_deploy >/dev/null 2>&1; then
                    run_temporal_post_deploy
                fi
            else
                render_lifecycle_failure_block "update"
                exit 1
            fi
            ;;
        # upgrade -- thin CLI layer. By default execs the current install's
        # scripts/upgrade.sh; after it extracts the new tarball, it chain-
        # loads the NEW tarball's scripts/upgrade.sh (Phase 2) for the
        # version-specific upgrade logic. Tarball CDN is the single source
        # of truth (no GitHub dependency).
        #
        # Flags (upgrade.sh-native; CLI only intercepts --source):
        #   --source=<path>    Use this upgrade.sh instead of the installed
        #                      one. For testing an unreleased upgrade.sh
        #                      against an existing prod install without
        #                      building a new tarball.
        #   --url=<tarball>    Tarball to upgrade to (local file:// or HTTP).
        #   --version=<ver>    Specific version instead of latest.
        #   --old-path=<dir>   Override auto-detected old install dir.
        upgrade)
            local source_script="" forward_args=()
            for arg in "$@"; do
                case "$arg" in
                    --source=*) source_script="${arg#--source=}" ;;
                    *)          forward_args+=("$arg") ;;
                esac
            done
            local upgrade_script="${SCRIPT_DIR}/upgrade.sh"
            if [ -n "$source_script" ]; then
                upgrade_script="$source_script"
                if [ ! -r "$upgrade_script" ]; then
                    echo -e "${RED}✗${NC} --source script not readable: ${upgrade_script}" >&2
                    exit 1
                fi
                echo -e "${BLUE}ℹ${NC} Using custom upgrade script: ${upgrade_script}"
            fi
            exec bash "$upgrade_script" "${forward_args[@]}"
            ;;

        # start -- no install → delegate to setup.sh --restart (same "Services
        # Not Running" UX as prod). With install → single progress_run wraps
        # compose up AND wait_for_containers_running (chained with &&). The
        # wait is part of starting, not a user-visible phase. On success we
        # print 3 body lines inline: "ready" sentence, MCP endpoint URL, and
        # Next: hints. On failure we list the services that didn't reach
        # running state with actionable `bitoarch logs <svc>` hints.
        start)
            local env_file
            env_file=$(get_config_file)
            if [ ! -f "$env_file" ]; then
                exec "${SCRIPT_DIR}/../setup.sh" --restart
            fi
            # K8s installs: delegate to setup.sh --restart (has K8s branch
            # with helm/rollout handling). Docker installs continue inline.
            if [ "$(get_deployment_type 2>/dev/null)" = "kubernetes" ]; then
                exec "${SCRIPT_DIR}/../setup.sh" --restart
            fi
            # shellcheck disable=SC1091
            source "${SCRIPT_DIR}/docker-manager.sh" 2>/dev/null || true
            # shellcheck disable=SC1091
            source "${SCRIPT_DIR}/lib/progress-output.sh"
            local compose_cmd
            compose_cmd=$(get_docker_compose_cmd) || exit 1
            cd "${SCRIPT_DIR}/.." || exit 1

            _bitoarch_prep_compose_env "$env_file"

            # Single step: compose up && container-state wait. progress_run
            # handles ✓/✗ + timing + failure log path.
            # Single progress_run wraps compose-up + health-wait. The health
            # wait uses .State.Health.Status (not just state=running) so we
            # don't claim "Ready" while provider/config are still warming up.
            # Return-code contract (from wait_for_services_healthy):
            #   0 = all healthy  → ✅ AI Architect Ready
            #   2 = soft-timeout → ℹ AI Architect Starting (warming up)
            #   1 = hard-fail    → enumerate failing services (below `else`)
            # Uses the same compact body + 3-state outcome handling as
            # `bitoarch restart` (shared helpers: _lifecycle_print_*_body).
            # set +e: guard against any errexit set by a sourced helper --
            # a non-zero return from progress_run would otherwise trip the
            # EXIT trap and skip our rc-dispatch below.
            set +e
            progress_run "Starting AI Architect" -- \
                bash -c "$compose_cmd --env-file '$env_file' up -d && \
                         wait_for_services_healthy ${RESTART_WAIT_TIMEOUT_SECS:-240} ${SERVICE_WAIT_GRACE_SECS:-60}"
            local rc=$?
            if [ $rc -eq 0 ] || [ $rc -eq 2 ]; then
                render_lifecycle_success_block "AI Architect Ready" "$rc"
                # Match K8s start-after-stop redeploy: re-run Temporal post-deploy on cold start.
                # shellcheck disable=SC1091
                source "${SCRIPT_DIR}/service-manager.sh" 2>/dev/null || true
                if command -v run_temporal_post_deploy >/dev/null 2>&1; then
                    run_temporal_post_deploy
                fi
            else
                render_lifecycle_failure_block "start"
                exit 1
            fi
            ;;

        reset)
            exec "${SCRIPT_DIR}/../setup.sh" --clean
            ;;
        uninstall)
            uninstall_run "$@"
            ;;

        config)
            local subcmd="${1:-}"; shift 2>/dev/null || true
            case "$subcmd" in
                path)
                    case "${1:-env}" in
                        env)   echo "$(get_config_file)" ;;
                        repos) echo "$(get_repo_config_file)" ;;
                        llm)   echo "$(get_llm_config_file)" ;;
                        *)     echo "ERROR: Unknown config name: ${1} (env|repos|llm)" >&2; exit 1 ;;
                    esac
                    ;;
                edit)
                    local cfg_path="" cfg_name="${1:-env}"
                    case "$cfg_name" in
                        env)   cfg_path="$(get_config_file)" ;;
                        repos) cfg_path="$(get_repo_config_file)" ;;
                        llm)   cfg_path="$(get_llm_config_file)" ;;
                        *)     echo "ERROR: Unknown config name: ${1} (env|repos|llm)" >&2; exit 1 ;;
                    esac
                    if [ ! -f "$cfg_path" ]; then
                        # Three cases for a missing config file:
                        #   llm   → optional, auto-create template (user fills in)
                        #   env   → install hasn't happened; point at install bootstrap
                        #   repos → install happened (env exists) but no repos
                        #           configured yet → point at `bitoarch add-repos` /
                        #           `bitoarch fetch-repo-list`
                        case "$cfg_name" in
                            llm)
                                mkdir -p "$(dirname "$cfg_path")" 2>/dev/null
                                cat > "$cfg_path" <<'EOF'
# Bito AI Architect — Custom LLM Provider Configuration (optional)
# Uncomment and fill the keys you want to use. Leave empty to fall back to
# the Bito-managed LLM pool. Changes take effect on next `bitoarch restart`.

# ANTHROPIC_API_TOKEN=
# OPENAI_API_TOKEN=
# PORTKEY_API_TOKEN=
# PORTKEY_MODEL_NAME=
EOF
                                chmod 600 "$cfg_path" 2>/dev/null
                                echo "Created $cfg_path (template)."
                                ;;
                            env)
                                {
                                    echo -e "${RED}✗${NC} AI Architect is not installed."
                                    echo "  Config file expected at: ${cfg_path}"
                                    echo ""
                                    echo -e "${BLUE}💡 Install first${NC}"
                                    echo -e "   From a clone:    ${YELLOW}./scripts/bitoarch-install-standalone.sh${NC}"
                                    echo -e "   Production:      ${YELLOW}./scripts/bitoarch-install.sh${NC}"
                                    echo -e "   From CDN:        ${YELLOW}bash <(curl -fsSL \$UPGRADE_DOWNLOAD_URL/scripts/bitoarch-install-standalone.sh)${NC}"
                                } >&2
                                exit 1
                                ;;
                            repos)
                                # If env-bitoarch exists, install DID happen; user just
                                # hasn't added repos yet. Point at the right command.
                                if [ -f "$(get_config_file)" ]; then
                                    {
                                        echo -e "${YELLOW}⚠${NC} No repositories configured yet."
                                        echo "  Config file will be created at: ${cfg_path}"
                                        echo ""
                                        echo -e "${BLUE}💡 Add repositories${NC}"
                                        echo -e "   • Discover from Git provider:  ${YELLOW}bitoarch fetch-repo-list${NC}"
                                        echo -e "   • Add a single repo:           ${YELLOW}bitoarch add-repo <namespace>${NC}"
                                        echo -e "   • Load from a YAML file:       ${YELLOW}bitoarch add-repos <file>${NC}"
                                        echo ""
                                        echo -e "   Once configured, ${YELLOW}bitoarch config edit repos${NC} will open the file."
                                    } >&2
                                    exit 1
                                else
                                    # No env either → same message as env case.
                                    {
                                        echo -e "${RED}✗${NC} AI Architect is not installed."
                                        echo "  Config file expected at: ${cfg_path}"
                                        echo ""
                                        echo -e "${BLUE}💡 Install first${NC}"
                                        echo -e "   From a clone:    ${YELLOW}./scripts/bitoarch-install-standalone.sh${NC}"
                                        echo -e "   Production:      ${YELLOW}./scripts/bitoarch-install.sh${NC}"
                                    } >&2
                                    exit 1
                                fi
                                ;;
                        esac
                    fi
                    local editor="${VISUAL:-${EDITOR:-vi}}"

                    # Route detail to setup.log; only the headline goes to
                    # the user. log_silent is a no-op if LOG_FILE is unset.
                    : "${LOG_FILE:=$(get_setup_log 2>/dev/null)}"

                    # Warn (once, briefly) if the editor looks like a Windows
                    # binary — these inject BOM/CRLF that breaks YAML parsing
                    # (BITO-13283). The post-save step normalizes it anyway.
                    # Match on basename (so /home/u/notepad-clone/vim does NOT
                    # trip) plus WSL/Windows path shapes. Flag instead of a
                    # nested case so the warn/log isn't duplicated.
                    local _editor_base _editor_is_windows=0
                    _editor_base="$(basename -- "$editor")"
                    case "$_editor_base" in
                        *.exe|notepad*) _editor_is_windows=1 ;;
                    esac
                    case "$editor" in
                        /mnt/c/*|*\\*) _editor_is_windows=1 ;;
                    esac
                    if [ "$_editor_is_windows" -eq 1 ]; then
                        print_warning "EDITOR='$editor' may inject BOM/CRLF; will normalize after save."
                        log_silent "config edit: detected Windows-style editor '$editor' for $cfg_name"
                    fi

                    # Pre-edit backup (silent — path goes to log only).
                    local pre_edit_backup=""
                    if [ -f "$cfg_path" ]; then
                        pre_edit_backup=$(backup_config_file "$cfg_path" "$cfg_name" 2>/dev/null) || pre_edit_backup=""
                        [ -n "$pre_edit_backup" ] && log_silent "config edit: pre-edit backup -> $pre_edit_backup"
                    fi

                    "$editor" "$cfg_path"
                    local editor_rc=$?
                    if [ $editor_rc -ne 0 ]; then
                        log_silent "config edit: editor '$editor' exited rc=$editor_rc on $cfg_path"
                        exit $editor_rc
                    fi

                    # Post-edit normalization: silent on success — only the
                    # user-visible failure modes (validation) speak up below.
                    # No -w guard: the editor just wrote this file successfully,
                    # so the perms check would only mask a real perms regression.
                    if [ -f "$cfg_path" ]; then
                        if head -c 3 "$cfg_path" 2>/dev/null | od -An -tx1 2>/dev/null | tr -d ' ' | grep -q '^efbbbf'; then
                            _rewrite_in_place "$cfg_path" tail -c +4 \
                                && log_silent "config edit: stripped UTF-8 BOM from $cfg_path"
                        fi
                        # Portable CRLF detection: -lU is GNU-grep-only and
                        # silently no-ops on BSD/Alpine grep, which is the
                        # primary code path for this fix on WSL.
                        if LC_ALL=C grep -q $'\r' "$cfg_path" 2>/dev/null; then
                            _rewrite_in_place "$cfg_path" tr -d '\r' \
                                && log_silent "config edit: converted CRLF -> LF in $cfg_path"
                        fi
                    fi

                    # Post-edit validation. Only the YAML repos config has a
                    # strict structural schema we can verify here; env/llm
                    # files are flat key=value and pass through after normalize.
                    # Helper falls back to python3 if yq is unavailable, and
                    # silently passes if neither tool is present.
                    if [ "$cfg_name" = "repos" ] && [ -f "$cfg_path" ]; then
                        if ! _validate_repos_yaml_shape "$cfg_path" ""; then
                            log_silent "config edit: validation failed for $cfg_path"
                            if [ -n "$pre_edit_backup" ] && [ -f "$pre_edit_backup" ]; then
                                if cp "$pre_edit_backup" "$cfg_path" 2>/dev/null; then
                                    print_warning "Restored previous version from backup."
                                    log_silent "config edit: restored $cfg_path from $pre_edit_backup"
                                else
                                    print_error "Restore from backup failed; see ${LOG_FILE:-setup.log} for the backup path."
                                    log_silent "config edit: restore FAILED — backup at $pre_edit_backup, target $cfg_path"
                                fi
                            else
                                print_warning "No pre-edit backup available; broken file left in place."
                            fi
                            exit 1
                        fi
                    fi
                    ;;
                ""|--help|-h)
                    cat <<'EOF'
USAGE:
  bitoarch config {path|edit} [env|repos|llm]

  path    Print absolute path to the named config file
  edit    Open the named config file in $EDITOR (default: vi)

  Target names: env (default), repos, llm
EOF
                    ;;
                *)
                    echo "ERROR: Unknown config subcommand: ${subcmd}" >&2
                    echo "Usage: bitoarch config {path|edit} [env|repos|llm]"
                    exit 1
                    ;;
            esac
            ;;
        
        # Configuration
        update-api-key)
            platform_update_api_key "$@"
            ;;
        update-git-creds)
            platform_update_git_creds "$@"
            ;;
        update-llm-config)
            platform_update_llm_config "$@"
            ;;
        rotate-mcp-token)
            platform_rotate_token "$@"
            ;;
        insights)
            handle_insights "$@"
            ;;
        tracker-projects)
            handle_insights tracker-projects "$@"
            ;;
        discover-tracker-projects)
            handle_insights discover-tracker-projects "$@"
            ;;

        # MCP Operations
        mcp-test)
            provider_mcp_test "$@"
            ;;
        mcp-tools)
            provider_mcp_tools "$@"
            ;;
        mcp-tool-info)
            provider_mcp_tool_info "$@"
            ;;
        mcp-capabilities)
            provider_mcp_capabilities "$@"
            ;;
        mcp-info)
            platform_mcp "$@"
            ;;
        mcp-install|mcp-uninstall|mcp-cert)
            # Gated on the MCP_AUTO_INSTALL feature flag. Standalone install_run
            # sets this true; Enterprise / shared deploys leave it false, so the
            # local-MCP CLI surface stays hidden + refused there.
            if ! { command -v mcp_auto_install_enabled >/dev/null 2>&1 && mcp_auto_install_enabled; }; then
                print_error "\`bitoarch ${command}\` is a Standalone-only command and is not available on this install."
                print_info  "Docs: ${BITO_STANDALONE_MCP_DOCS_URL:-https://docs.bito.ai/ai-architect/standalone-mcp-coding-agents}"
                exit 1
            fi
            case "$command" in
                mcp-install)
                    # shellcheck disable=SC1091
                    source "${SCRIPT_DIR}/lib/mcp-installer.sh"
                    mcp_installer_cli "$@"
                    ;;
                mcp-uninstall)
                    # shellcheck disable=SC1091
                    source "${SCRIPT_DIR}/lib/mcp-uninstaller.sh"
                    mcp_uninstaller_cli "$@"
                    ;;
                *)
                    # shellcheck disable=SC1091
                    source "${SCRIPT_DIR}/lib/mcp-cert-cli.sh"
                    mcp_cert_cli "$@"
                    ;;
            esac
            ;;
        
        # SSO Management
        sso)
            handle_sso "$@"
            ;;
        
        *)
            print_error "Unknown command: $command"
            echo ""
            echo "Use 'bitoarch --help' to see available commands"
            exit 1
            ;;
    esac
}

# Execute main function and exit with its return code
main "$@"
exit $?
