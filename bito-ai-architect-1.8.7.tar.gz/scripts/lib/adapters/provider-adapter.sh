#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
# Bito's AI Architect CLI - Provider Adapter
# Handles Provider (MCP Server) commands

# Source http-client for K8s port-forward support
if [ -z "$SCRIPT_DIR" ]; then
    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && cd ../.. && pwd)"
fi
source "${SCRIPT_DIR}/scripts/lib/http-client.sh" 2>/dev/null || true

# Ensure provider service is accessible (handles K8s port-forward automatically)
ensure_provider_service_accessible() {
    local PROVIDER_PORT="${CIS_PROVIDER_EXTERNAL_PORT:-5001}"
    ensure_service_accessible "ai-architect-provider" "$PROVIDER_PORT" 2>/dev/null || true
}

# List repositories
provider_repo_list() {
    # Check for help first
    if [ "$1" = "--help" ] || [ "$1" = "-h" ]; then
        cat << 'EOF'
USAGE:
  bitoarch index-repo-list

DESCRIPTION:
  List indexed repositories. Uses the server-side default page size.

OPTIONS:
  --help, -h               Show this help

EXAMPLES:
  bitoarch index-repo-list
EOF
        return 0
    fi

    # No options accepted today — reject anything passed so typos and
    # legacy flags (--status, --limit, --format) fail loudly instead of
    # being silently ignored.
    if [ $# -gt 0 ]; then
        print_error "Unexpected argument: $1"
        echo -e "Run ${YELLOW}bitoarch index-repo-list --help${NC} for usage"
        return 1
    fi

    if ! require_command jq; then
        print_error "jq is required for this operation"
        print_info "Install jq: brew install jq (macOS) or apt-get install jq (Ubuntu)"
        return 1
    fi

    ensure_provider_service_accessible

    print_info "Listing repositories..."

    # xmcp requires purposeType + purpose on every tools/call. All other
    # listRepositories args (pageNumber, pageSize, includeSummary) are
    # optional — let the server apply its defaults.
    local request
    request=$(jq -n \
        '{jsonrpc:"2.0",method:"tools/call",id:1,params:{name:"listRepositories",arguments:{purposeType:"codebase_understanding",purpose:"Listing indexed repositories via bitoarch CLI"}}}')

    local result=$(mcp_request "$request")
    if [ $? -ne 0 ]; then
        return 1
    fi

    format_mcp_content "$result" "$OUTPUT_FORMAT"
}

# Get repository info
provider_repo_info() {
    # Check for help first
    if [ "$1" = "--help" ] || [ "$1" = "-h" ]; then
        cat << 'EOF'
USAGE:
  bitoarch repo-info <repository-name> [OPTIONS]

DESCRIPTION:
  Get detailed information about a specific indexed repository

ARGUMENTS:
  <repository-name>    Name of the repository (required)

OPTIONS:
  --dependencies       Include dependency information
  --help, -h          Show this help

EXAMPLES:
  bitoarch repo-info myorg/myrepo
  bitoarch repo-info myorg/myrepo --dependencies
EOF
        return 0
    fi
    
    local name="$1"
    local dependencies="false"
    
    if [ -z "$name" ]; then
        print_error "Usage: ${YELLOW}bitoarch repo-info <name> [--dependencies]${NC}"
        return 1
    fi
    
    shift

    # Parse options. Unknown flags fail loudly — same convention as
    # provider_repo_list, so typos and legacy flags don't get silently
    # dropped.
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --dependencies)
                dependencies="true"
                shift
                ;;
            *)
                print_error "Unknown option: $1"
                echo -e "Run ${YELLOW}bitoarch repo-info --help${NC} for usage"
                return 1
                ;;
        esac
    done

    if ! require_command jq; then
        print_error "jq is required for this operation"
        print_info "Install jq: brew install jq (macOS) or apt-get install jq (Ubuntu)"
        return 1
    fi

    ensure_provider_service_accessible

    print_info "Getting info for '$name'..."

    # purposeType flips to dependency_analysis when caller asks for the dep
    # graph; otherwise the call is a general repo-detail lookup.
    local purpose_type="codebase_understanding"
    local purpose_text="Getting repository details for '$name' via bitoarch CLI"
    if [ "$dependencies" = "true" ]; then
        purpose_type="dependency_analysis"
        purpose_text="Getting repository dependencies for '$name' via bitoarch CLI"
    fi

    local request=$(jq -n --arg name "$name" --arg deps "$dependencies" \
        --arg ptype "$purpose_type" --arg ptext "$purpose_text" \
        '{jsonrpc:"2.0",method:"tools/call",id:1,params:{name:"getRepositoryInfo",arguments:{repositoryName:$name,includeIncomingDependencies:($deps=="true"),includeOutgoingDependencies:($deps=="true"),purposeType:$ptype,purpose:$ptext}}}')
    
    # Make MCP request  
    local result=$(mcp_request "$request")
    local exit_code=$?
    
    # If mcp_request returned non-zero, it failed
    if [ $exit_code -ne 0 ]; then
        print_error "Repository not found or error occurred: $name"
        return 1
    fi
    
    # Check if result contains error JSON
    if echo "$result" | grep -q '"error"'; then
        print_error "Repository not found or error occurred: $name"
        return 1
    fi
    
    # Check if MCP request actually returned data
    if [ -z "$result" ] || [ "$result" = "null" ]; then
        print_error "No data returned for repository: $name"
        return 1
    fi
    
    format_mcp_content "$result" "$OUTPUT_FORMAT"
    return $?
}

# Get MCP capabilities
provider_mcp_capabilities() {
    local output_file=""

    # Parse options. Unknown flags fail loudly.
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --output|-o)
                output_file="$2"
                shift 2
                ;;
            --help|-h)
                cat << 'EOF'
USAGE:
  bitoarch mcp-capabilities [OPTIONS]

OPTIONS:
  --output, -o <file>    Save output to JSON file

EXAMPLES:
  bitoarch mcp-capabilities
  bitoarch mcp-capabilities --output capabilities.json
EOF
                return 0
                ;;
            *)
                print_error "Unknown option: $1"
                echo -e "Run ${YELLOW}bitoarch mcp-capabilities --help${NC} for usage"
                return 1
                ;;
        esac
    done

    ensure_provider_service_accessible

    # Build JSON-RPC request for initialize. clientInfo.name identifies this
    # CLI in xmcp's analytics — keep it stable across releases.
    local request='{"jsonrpc": "2.0", "method": "initialize", "id": 1, "params": {"protocolVersion": "2024-11-05", "capabilities": {}, "clientInfo": {"name": "bitoarch-cli", "version": "1.0.0"}}}'
    local auth_header="Authorization: Bearer $PROVIDER_TOKEN"

    local response=$(http_request "POST" "${PROVIDER_URL}/mcp" "$auth_header" "$request")
    if [ $? -ne 0 ]; then
        return 1
    fi

    # Output to file or formatted stdout
    if [ -n "$output_file" ]; then
        # Save beautified JSON to file
        if require_command jq; then
            echo "$response" | jq '.' > "$output_file"
        else
            echo "$response" > "$output_file"
        fi
        print_success "Output saved to: $output_file"
    else
        render_mcp_capabilities_block "$response"
    fi
}

# List MCP tools
provider_mcp_tools() {
    local output_file=""
    local show_details="false"

    # Parse options. Unknown flags fail loudly.
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --output|-o)
                output_file="$2"
                shift 2
                ;;
            --details|--summary)
                show_details="true"
                shift
                ;;
            --help|-h)
                cat << 'EOF'
USAGE:
  bitoarch mcp-tools [OPTIONS]

OPTIONS:
  --details, --summary   Show detailed tool information
  --output, -o <file>    Save output to JSON file

EXAMPLES:
  bitoarch mcp-tools                  List tool names only
  bitoarch mcp-tools --details        Show full tool details
  bitoarch mcp-tools --output tools.json
EOF
                return 0
                ;;
            *)
                print_error "Unknown option: $1"
                echo -e "Run ${YELLOW}bitoarch mcp-tools --help${NC} for usage"
                return 1
                ;;
        esac
    done

    ensure_provider_service_accessible
    # Build JSON-RPC request for tools/list
    local request='{"jsonrpc": "2.0", "method": "tools/list", "id": 1}'
    local auth_header="Authorization: Bearer $PROVIDER_TOKEN"

    local response=$(http_request "POST" "${PROVIDER_URL}/mcp" "$auth_header" "$request")
    if [ $? -ne 0 ]; then
        return 1
    fi

    # Output to file or formatted stdout
    if [ -n "$output_file" ]; then
        # Save beautified JSON to file
        if require_command jq; then
            echo "$response" | jq '.' > "$output_file"
        else
            echo "$response" > "$output_file"
        fi
        print_success "Output saved to: $output_file"
    else
        # Use block render function with show_details flag
        render_mcp_tools_list_block "$response" "$show_details"
    fi
}

# Test MCP connection
provider_mcp_test() {
    if mcp_env_drift_check; then
        render_mcp_drift_block "$DRIFTED_KEYS"
        echo ""
    fi

    print_info "Testing MCP connection..."
    
    # Ensure provider service is accessible (sets up port-forward for K8s if needed)
    ensure_provider_service_accessible
    
    # HTTPS in Standalone uses an mkcert self-signed cert; -k keeps the
    # probe scheme-aware without depending on host trust state.
    local curl_tls_opts=""
    case "$PROVIDER_URL" in
        https://*) curl_tls_opts="-k" ;;
    esac

    # Test MCP endpoint directly with tools/list request using simple curl
    local response=$(curl -s --max-time 10 --connect-timeout 5 $curl_tls_opts \
        -X POST "${PROVIDER_URL}/mcp" \
        -H "Authorization: Bearer $PROVIDER_TOKEN" \
        -H "Content-Type: application/json" \
        -d '{"jsonrpc": "2.0", "method": "tools/list", "id": 1}' 2>&1)
    
    local curl_exit=$?
    
    # Check curl exit code
    if [ $curl_exit -eq 0 ] && [ -n "$response" ]; then
        # Check if response contains valid MCP data
        if echo "$response" | grep -q '"result"'; then
            print_success "MCP endpoint: OK"
            print_success "Authentication: OK"
            print_success "Connection test passed"
            return 0
        fi
    fi
    
    # Handle specific error cases
    if [ $curl_exit -eq 28 ]; then
        print_error "MCP endpoint test failed: Connection timeout"
    elif [ $curl_exit -eq 7 ]; then
        print_error "MCP endpoint test failed: Cannot connect to server"
    else
        print_error "MCP endpoint test failed"
    fi
    
    echo "Endpoint: ${PROVIDER_URL}/mcp"
    echo -e "Check that the provider service is running: ${YELLOW}bitoarch status${NC}"
    return 1
}

# Get information about a specific MCP tool
provider_mcp_tool_info() {
    if [ "$1" = "--help" ] || [ "$1" = "-h" ]; then
        cat << 'EOF'
USAGE:
  bitoarch mcp-tool-info <toolname>

DESCRIPTION:
  Show the description and input parameters for a single MCP tool.

ARGUMENTS:
  <toolname>    Name of the MCP tool (required)

EXAMPLES:
  bitoarch mcp-tool-info listRepositories
  bitoarch mcp-tool-info getRepositoryInfo
EOF
        return 0
    fi

    local tool_name="$1"

    if [ -z "$tool_name" ]; then
        print_error "Usage: ${YELLOW}bitoarch mcp-tool-info <toolname>${NC}"
        echo ""
        echo "EXAMPLE:"
        echo -e "  ${YELLOW}bitoarch mcp-tool-info listRepositories${NC}"
        return 1
    fi
    shift

    # Reject anything past the tool name — this command takes no options today,
    # so extras (typos, legacy flags) should fail loudly instead of being lost.
    if [ $# -gt 0 ]; then
        print_error "Unexpected argument: $1"
        echo -e "Run ${YELLOW}bitoarch mcp-tool-info --help${NC} for usage"
        return 1
    fi

    if ! require_command jq; then
        print_error "jq is required for this operation"
        return 1
    fi

    ensure_provider_service_accessible
    # Fetch tool list
    local request='{"jsonrpc": "2.0", "method": "tools/list", "id": 1}'
    local auth_header="Authorization: Bearer $PROVIDER_TOKEN"

    local response=$(http_request "POST" "${PROVIDER_URL}/mcp" "$auth_header" "$request")
    if [ $? -ne 0 ]; then
        return 1
    fi

    # Extract tool info
    local tool_data=$(echo "$response" | jq --arg name "$tool_name" '.result.tools[] | select(.name == $name)' 2>/dev/null)
    
    if [ -z "$tool_data" ] || [ "$tool_data" = "null" ]; then
        print_error "Tool '$tool_name' not found"
        echo ""
        echo -e "Use ${YELLOW}bitoarch mcp-tools${NC} to see available tools"
        return 1
    fi
    
    # Extract fields
    local description=$(echo "$tool_data" | jq -r '.description // "No description available"')
    local schema=$(echo "$tool_data" | jq -r '.inputSchema // {}')
    
    # Display tool info
    echo ""
    echo -e "${BLUE}Tool: ${BOLD}$tool_name${NC}"
    echo ""
    echo -e "${CYAN}Description:${NC}"
    echo "  $description"
    echo ""
    
    # Display input schema if available
    if [ "$schema" != "{}" ] && [ "$schema" != "null" ]; then
        echo -e "${CYAN}Input Parameters:${NC}"
        
        # Extract required and optional properties
        local properties=$(echo "$schema" | jq -r '.properties // {}')
        local required=$(echo "$schema" | jq -r '.required // []')
        
        if [ "$properties" != "{}" ]; then
            echo "$properties" | jq -r 'to_entries[] | "  • \(.key): \(.value.description // .value.type)"' 2>/dev/null
        else
            echo "  (no parameters)"
        fi
        echo ""
    fi
}

# Export functions
export -f provider_repo_list
export -f provider_repo_info
export -f provider_mcp_capabilities
export -f provider_mcp_tools
export -f provider_mcp_test
export -f provider_mcp_tool_info
