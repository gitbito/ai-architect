#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
#
# LLM Configuration Functions
# Shared functions for configuring LLM providers

# Global array to track configured providers
CONFIGURED_PROVIDERS=()

# Function: get_provider_metadata
# Maps user selection → provider details
# Returns provider_name, url_key, token_key, example_url
# -------------------------------------------------------------------
get_provider_metadata() {
    case "$1" in
        1)
            provider_name="anthropic"
            url_key="ANTHROPIC_API_URL"
            token_key="ANTHROPIC_API_TOKEN"
            example_url="https://api.anthropic.com"
            ;;
        2)
            provider_name="openai"
            url_key="OPENAI_API_URL"
            token_key="OPENAI_API_TOKEN"
            example_url="https://api.openai.com/v1"
            ;;
        3)
            provider_name="portkey"
            url_key="PORTKEY_API_URL"
            token_key="PORTKEY_API_TOKEN"
            model_key="PORTKEY_MODEL_NAME"
            example_url="https://api.portkey.ai/v1"
            ;;
        4)
            provider_name="vertex-ai"
            url_key=""
            token_key="VERTEX_SERVICE_ACCOUNT_KEY_JSON"
            example_url=""
            ;;
        5)
            provider_name="azure-ai"
            url_key="AZURE_AI_ENDPOINT"
            token_key="AZURE_AI_API_KEY"
            example_url="https://<your-resource>.openai.azure.com"
            ;;
        *)
            return 1
            ;;
    esac
}

# Function: configure_llm
# Interactive LLM provider configuration
# -------------------------------------------------------------------
configure_llm() {

    CONFIGURED_PROVIDERS=()
    local continue_config="y"

    while [[ "$continue_config" =~ ^[Yy]$ ]]; do

        # Auto-stop if all providers are configured
        if [[ ${#CONFIGURED_PROVIDERS[@]} -eq 5 ]]; then
            echo -e "${GREEN}💡 All LLM providers have been configured.${NC}"
            break
        fi

        local provider_choice
        echo ""
        read -r -p "Configure LLM: 1) Anthropic 2) OpenAI 3) Portkey 4) Google Vertex AI 5) Azure AI [1-5]: " provider_choice

        get_provider_metadata "$provider_choice" || {
            echo "✗ Invalid option. Please select 1–5."
            continue
        }

        # Skip duplicates
        if [[ " ${CONFIGURED_PROVIDERS[*]} " =~ " ${provider_name} " ]]; then
            echo -e "${YELLOW}⚠ $provider_name is already configured.${NC}"
        else
            echo -e "\n${BLUE}=== Configuring ${provider_name} ===${NC}\n"

            # Special handling for Portkey (requires model and optional URL)
            if [[ "$provider_name" == "portkey" ]]; then
                local url=""
                local default_url="https://api.portkey.ai/v1"
                while true; do
                    read -r -p "Enter Portkey API URL (press Enter to use default: $default_url): " url

                    # If user pressed Enter without input, set to empty
                    if [[ -z "$url" ]]; then
                        url=""
                        break
                    fi

                    # Remove trailing slash if present
                    url="${url%/}"

                    # If user entered the default value, set to empty
                    if [[ "$url" == "$default_url" ]]; then
                        url=""
                        break
                    fi

                    # Validate URL format (must start with http:// or https://)
                    if [[ "$url" =~ ^https?://[a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*(/.*)?$ ]]; then
                        break
                    else
                        echo -e "${RED}⚠ Invalid URL format. URL must start with http:// or https://${NC}"
                    fi
                done

                set_env_key_value "PORTKEY_API_URL" "$url" "$ENV_LLM_FILE"

                local model=""
                while [[ -z "$model" ]]; do
                    read -r -p "Enter Portkey model (format: @provider/model-name): " model

                    if [[ -z "$model" ]]; then
                        echo -e "${RED}⚠ Model name is required. Please enter a value.${NC}"
                    elif ! [[ "$model" =~ ^@[^/]+/[^/]+$ ]]; then
                        echo -e "${RED}⚠ Invalid model format. Expected: @provider/model-name (e.g. @slug/claude-haiku).${NC}"
                        model=""
                    fi
                done

                set_env_key_value "PORTKEY_MODEL_NAME" "$model" "$ENV_LLM_FILE"
            fi

            # Special handling for Vertex AI (service-account JSON file + project + region).
            # The SA JSON is base64-encoded before persisting so it fits in a single .env
            # line (set_env_key_value writes plain KEY=VALUE\n). Decoded later in
            # create_llm_integration_json before inlining into the cis-config PUT body.
            if [[ "$provider_name" == "vertex-ai" ]]; then
                local sa_path=""
                while true; do
                    read -r -p "Enter path to your GCP service-account JSON file: " sa_path
                    [[ -z "$sa_path" ]] && { echo "Path cannot be empty."; continue; }
                    [[ ! -f "$sa_path" ]] && { echo "File not found: $sa_path"; continue; }
                    if ! jq empty "$sa_path" >/dev/null 2>&1; then
                        echo "File is not valid JSON: $sa_path"
                        continue
                    fi
                    break
                done
                local sa_b64
                sa_b64=$(base64 < "$sa_path" | tr -d '\n')
                set_env_key_value "VERTEX_SERVICE_ACCOUNT_KEY_JSON" "$sa_b64" "$ENV_LLM_FILE"

                local project=""
                while [[ -z "$project" ]]; do
                    read -r -p "Enter GCP Project ID: " project
                    [[ -z "$project" ]] && echo "Project cannot be empty."
                done
                set_env_key_value "VERTEX_PROJECT" "$project" "$ENV_LLM_FILE"

                local region=""
                while [[ -z "$region" ]]; do
                    read -r -p "Enter GCP Region (e.g. us-central1): " region
                    [[ -z "$region" ]] && echo "Region cannot be empty."
                done
                set_env_key_value "VERTEX_REGION" "$region" "$ENV_LLM_FILE"
            fi

            # Special handling for Azure AI (endpoint; the primary AZURE_AI_API_KEY
            # is set via the generic token prompt below)
            if [[ "$provider_name" == "azure-ai" ]]; then
                local endpoint=""
                while [[ -z "$endpoint" ]]; do
                    read -r -p "Enter Azure AI endpoint (e.g. https://<resource>.openai.azure.com): " endpoint
                    if [[ -z "$endpoint" ]]; then
                        echo "Endpoint cannot be empty."
                    elif ! [[ "$endpoint" =~ ^https?:// ]]; then
                        echo "Endpoint must start with http:// or https://"
                        endpoint=""
                    fi
                done
                set_env_key_value "AZURE_AI_ENDPOINT" "$endpoint" "$ENV_LLM_FILE"
            fi

            # Vertex AI's primary token (VERTEX_SERVICE_ACCOUNT_KEY_JSON) is set
            # above via the file-read path, not via the generic API-token prompt.
            # Skip the generic prompt for vertex-ai so it doesn't overwrite the
            # base64-encoded SA JSON.
            if [[ "$provider_name" != "vertex-ai" ]]; then
                local token=""
                while [[ -z "$token" ]]; do
                    read -s -r -p "Enter ${provider_name} API token (input hidden): " token
                    stty echo; echo ""
                    [[ -z "$token" ]] && echo "Token cannot be empty."
                done

                set_env_key_value "${token_key}" "${token}" "$ENV_LLM_FILE"
            fi

            CONFIGURED_PROVIDERS+=("$provider_name")
            print_status " ${provider_name} configured successfully"
        fi

        # Ask whether to configure another provider only if some remain
        # Skip asking for more providers if Portkey is selected (it's a gateway)
        if [[ " ${CONFIGURED_PROVIDERS[*]} " =~ " portkey " ]]; then
            continue_config="n"
        elif [[ ${#CONFIGURED_PROVIDERS[@]} -lt 5 ]]; then
            read -r -p "Do you also want to add an API token for another LLM? (y/N): " continue_config
        else
            continue_config="n"
        fi
    done
    return 0
}

# Function: reset_all_llm_keys
# Clears all LLM provider keys to ensure clean state
# -------------------------------------------------------------------
reset_all_llm_keys() {
    # Clear all LLM provider keys
    set_env_key_value "ANTHROPIC_API_URL" "" "$ENV_LLM_FILE"
    set_env_key_value "ANTHROPIC_API_TOKEN" "" "$ENV_LLM_FILE"
    set_env_key_value "OPENAI_API_URL" "" "$ENV_LLM_FILE"
    set_env_key_value "OPENAI_API_TOKEN" "" "$ENV_LLM_FILE"
    set_env_key_value "PORTKEY_API_URL" "" "$ENV_LLM_FILE"
    set_env_key_value "PORTKEY_API_TOKEN" "" "$ENV_LLM_FILE"
    set_env_key_value "PORTKEY_MODEL_NAME" "" "$ENV_LLM_FILE"
    # Vertex AI
    set_env_key_value "VERTEX_SERVICE_ACCOUNT_KEY_JSON" "" "$ENV_LLM_FILE"
    set_env_key_value "VERTEX_PROJECT" "" "$ENV_LLM_FILE"
    set_env_key_value "VERTEX_REGION" "" "$ENV_LLM_FILE"
    # Azure AI
    set_env_key_value "AZURE_AI_API_KEY" "" "$ENV_LLM_FILE"
    set_env_key_value "AZURE_AI_ENDPOINT" "" "$ENV_LLM_FILE"
    set_env_key_value "LLM_DEFAULT_PROVIDER" "" "$ENV_LLM_FILE"
}

# Returns 0 when any LLM token is pre-exported (yaml-driven install bypass).
_llm_tokens_preset() {
    [ -n "${ANTHROPIC_API_TOKEN:-}" ]              && return 0
    [ -n "${OPENAI_API_TOKEN:-}" ]                 && return 0
    [ -n "${PORTKEY_API_TOKEN:-}" ]                && return 0
    [ -n "${VERTEX_SERVICE_ACCOUNT_KEY_JSON:-}" ]  && return 0
    [ -n "${AZURE_AI_API_KEY:-}" ]                 && return 0
    return 1
}

# Writes pre-exported LLM tokens to $ENV_LLM_FILE and populates
# CONFIGURED_PROVIDERS so LLM_DEFAULT_PROVIDER resolution still works.
# Clears all LLM keys first so stale values from a previous install do not
# linger if the new yaml defines a smaller provider set.
_llm_persist_preset_tokens() {
    CONFIGURED_PROVIDERS=()
    reset_all_llm_keys

    # Portkey is an exclusive gateway: when its token is preset it owns the
    # configuration and direct providers are ignored (mirrors the interactive
    # flow, which stops after Portkey).
    if [ -n "${PORTKEY_API_TOKEN:-}" ]; then
        set_env_key_value "PORTKEY_API_TOKEN" "${PORTKEY_API_TOKEN}" "$ENV_LLM_FILE"
        if [ -n "${PORTKEY_API_URL:-}" ]; then
            set_env_key_value "PORTKEY_API_URL" "${PORTKEY_API_URL}" "$ENV_LLM_FILE"
        fi
        if [ -n "${PORTKEY_MODEL_NAME:-}" ]; then
            set_env_key_value "PORTKEY_MODEL_NAME" "${PORTKEY_MODEL_NAME}" "$ENV_LLM_FILE"
        fi
        CONFIGURED_PROVIDERS+=("portkey")
        return 0
    fi

    if [ -n "${ANTHROPIC_API_TOKEN:-}" ]; then
        set_env_key_value "ANTHROPIC_API_TOKEN" "${ANTHROPIC_API_TOKEN}" "$ENV_LLM_FILE"
        CONFIGURED_PROVIDERS+=("anthropic")
    fi
    if [ -n "${OPENAI_API_TOKEN:-}" ]; then
        set_env_key_value "OPENAI_API_TOKEN" "${OPENAI_API_TOKEN}" "$ENV_LLM_FILE"
        CONFIGURED_PROVIDERS+=("openai")
    fi
    # Vertex AI needs all three fields; a partial set would be marked "configured"
    # yet silently dropped from the cis-config PUT (create_llm_integration_json
    # emits it only when all three are present), so require the full set here.
    if [ -n "${VERTEX_SERVICE_ACCOUNT_KEY_JSON:-}" ]; then
        if [ -n "${VERTEX_PROJECT:-}" ] && [ -n "${VERTEX_REGION:-}" ]; then
            set_env_key_value "VERTEX_SERVICE_ACCOUNT_KEY_JSON" "${VERTEX_SERVICE_ACCOUNT_KEY_JSON}" "$ENV_LLM_FILE"
            set_env_key_value "VERTEX_PROJECT" "${VERTEX_PROJECT}" "$ENV_LLM_FILE"
            set_env_key_value "VERTEX_REGION" "${VERTEX_REGION}" "$ENV_LLM_FILE"
            CONFIGURED_PROVIDERS+=("vertex-ai")
        else
            print_warning "Vertex AI not configured: requires VERTEX_SERVICE_ACCOUNT_KEY_JSON, VERTEX_PROJECT and VERTEX_REGION"
        fi
    fi
    # Azure AI needs both api_key and endpoint (same PUT-emission rule as above).
    if [ -n "${AZURE_AI_API_KEY:-}" ]; then
        if [ -n "${AZURE_AI_ENDPOINT:-}" ]; then
            set_env_key_value "AZURE_AI_API_KEY" "${AZURE_AI_API_KEY}" "$ENV_LLM_FILE"
            set_env_key_value "AZURE_AI_ENDPOINT" "${AZURE_AI_ENDPOINT}" "$ENV_LLM_FILE"
            CONFIGURED_PROVIDERS+=("azure-ai")
        else
            print_warning "Azure AI not configured: requires both AZURE_AI_API_KEY and AZURE_AI_ENDPOINT"
        fi
    fi
}

# Function: configure_llm_provider
# Main entry point for LLM provider configuration
# Pass "force_interactive" to bypass preset-token detection (e.g. when called
# from `bitoarch update-llm-config` where load_env_config has already exported
# the existing tokens into the caller's shell).
# -------------------------------------------------------------------
configure_llm_provider() {
    local mode="${1:-}"

    if [ "$mode" = "force_interactive" ]; then
        reset_all_llm_keys
        configure_llm
    elif _llm_tokens_preset; then
        # Yaml-driven install: persist pre-exported tokens, skip prompt.
        _llm_persist_preset_tokens
    else
        reset_all_llm_keys
        configure_llm
    fi

    # Build final selection list (configured providers + bito)
    local options=("${CONFIGURED_PROVIDERS[@]}" "bito")
    local prefer_order=("portkey" "openai" "anthropic" "vertex-ai" "azure-ai" "bito")

    selected_provider=""

    for preferred in "${prefer_order[@]}"; do
        for p in "${options[@]}"; do
            if [[ "$p" == "$preferred" ]]; then
                selected_provider="$preferred"
                break 2
            fi
        done
    done
    set_env_key_value "LLM_DEFAULT_PROVIDER" "${selected_provider}" "$ENV_LLM_FILE"

    # Send LLM provider tracking event (suppress output to prevent HTTP status leakage)
    if [[ ${#CONFIGURED_PROVIDERS[@]} -gt 0 ]]; then
        local providers_csv=$(IFS=,; echo "${CONFIGURED_PROVIDERS[*]}")
        send_llm_provider_tracking "$providers_csv" >/dev/null 2>&1
    fi
}

# Export functions
export -f _llm_tokens_preset
export -f _llm_persist_preset_tokens
export -f get_provider_metadata
export -f configure_llm
export -f reset_all_llm_keys
export -f configure_llm_provider
