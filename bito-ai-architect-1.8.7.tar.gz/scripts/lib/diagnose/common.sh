#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
# Bito's AI Architect CLI - Diagnose Bundle Common Helpers
# Shared utilities for collect-*.sh modules. Every collector sources this
# (transitively, via diagnose.sh) and uses:
#   - redact_env_file        : sanitize .env-style files in place / to stdout
#   - safe_step              : run a step, capture failure, never abort the sweep
#   - _bundle_step / _bundle_warn / _bundle_fail : progress + accumulator
#   - bundle_log_section     : write a labeled section header to a collector file

if [ -n "${_DIAGNOSE_COMMON_LOADED:-}" ]; then
    return 0
fi
_DIAGNOSE_COMMON_LOADED=1

# bitoarch.sh doesn't auto-source constants.sh -- it's lazy-loaded by adapters.
# Bundle collectors depend on SERVICE_*_NAME / BITOARCH_LIFECYCLE_SERVICES.
_DIAG_COMMON_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [ -z "${SERVICE_MYSQL_NAME:-}" ] || [ "${#BITOARCH_LIFECYCLE_SERVICES[@]}" -eq 0 ]; then
    # shellcheck disable=SC1091
    source "${_DIAG_COMMON_DIR}/../constants.sh" 2>/dev/null || \
        echo "[diagnose] WARN: constants.sh not sourced -- collectors may be empty" >&2
fi

# Shared async loader (show_loader / stop_loader). The diagnose lib isn't
# downstream of setup-utils.sh, so source the canonical helper directly --
# works both at runtime and when tests source this file in isolation.
# shellcheck disable=SC1091
source "${_DIAG_COMMON_DIR}/../loader.sh" 2>/dev/null || \
    echo "[diagnose] WARN: loader.sh not sourced -- spinner unavailable" >&2

# ─── Accumulators (reset by bundler.sh before each sweep) ─────────────────
_BUNDLE_STEPS_OK=0
_BUNDLE_WARNED=0
_BUNDLE_FAILED=0
_BUNDLE_FAILED_STEPS=""

# Path to the in-bundle run log, set by bundler.sh. Per-step progress is
# written here (and to the host log via log_silent), NOT to the terminal --
# the terminal shows a single loader for the whole sweep instead.
_BUNDLE_RUN_LOG=""

# Append a timestamped line to the in-bundle run log (when set) and the host
# log. Never writes to stdout, so step progress can run behind the loader.
_bundle_log() {
    local msg="$1"
    [ -n "${_BUNDLE_RUN_LOG:-}" ] \
        && echo "[$(date '+%Y-%m-%d %H:%M:%S')] ${msg}" >> "$_BUNDLE_RUN_LOG" 2>/dev/null
    log_silent "[diagnose-bundle] ${msg}"
}

_bundle_step_start() { _bundle_log "collecting: $1"; }
_bundle_step_ok()    { _BUNDLE_STEPS_OK=$((_BUNDLE_STEPS_OK + 1)); }

_bundle_step_warn() {
    local label="$1" msg="$2"
    _BUNDLE_WARNED=$((_BUNDLE_WARNED + 1))
    _bundle_log "⚠ ${label}: ${msg}"
}

_bundle_step_fail() {
    local label="$1" msg="$2"
    _BUNDLE_FAILED=$((_BUNDLE_FAILED + 1))
    _BUNDLE_FAILED_STEPS="${_BUNDLE_FAILED_STEPS} ${label}"
    _bundle_log "✗ ${label}: ${msg}"
}

# The async loader (show_loader / stop_loader) is provided by
# scripts/lib/loader.sh, sourced above; the bundler calls it directly.

# Run a collector with errexit off. rc=0 ok, rc=2 soft-skip, else fail.
# Usage: safe_step "<label>" <collect_fn> <args...>
safe_step() {
    local label="$1"; shift
    _bundle_step_start "$label"
    set +e
    "$@"
    local rc=$?
    if [ "$rc" -eq 0 ]; then
        _bundle_step_ok
    elif [ "$rc" -eq 2 ]; then
        :  # collector emitted its own warn line
    else
        _bundle_step_fail "$label" "exit $rc"
    fi
}

# Append a labeled section header to an existing file.
bundle_log_section() {
    local file="$1" title="$2"
    {
        echo ""
        echo "── ${title} ──────────────────────────────────────────"
    } >> "$file"
}

# Initialise a collector output file with title + timestamp + host.
bundle_init_file() {
    local file="$1" title="$2"
    mkdir -p "$(dirname "$file")" 2>/dev/null || true
    {
        echo "${title}"
        echo "Generated: $(date '+%Y-%m-%d %H:%M:%S %Z')"
        echo "Host: $(hostname 2>/dev/null || echo unknown)"
    } > "$file"
}

# ─── Redaction ────────────────────────────────────────────────────────────

# Redact sensitive values in a .env file. Reads file, writes redacted to stdout.
# Keys matched (case-insensitive substring): API_KEY, TOKEN, SECRET, PASSWORD,
# PRIVATE_KEY, ACCESS_KEY, CLIENT_SECRET, ENCRYPTION, CREDENTIAL.
redact_env_file() {
    local file="$1"
    [ -f "$file" ] || { echo "# file not found: $file"; return 1; }

    awk '
        /^[[:space:]]*#/ { print; next }
        /^[[:space:]]*$/ { print; next }

        {
            eq = index($0, "=")
            if (eq == 0) { print; next }

            key = substr($0, 1, eq - 1)
            val = substr($0, eq + 1)

            mkey = key
            sub(/^[[:space:]]*export[[:space:]]+/, "", mkey)
            gsub(/[[:space:]]/, "", mkey)
            mkey_uc = toupper(mkey)

            if (mkey_uc ~ /(API_KEY|TOKEN|SECRET|PASSWORD|PASSWD|PRIVATE_KEY|ACCESS_KEY|CLIENT_SECRET|ENCRYPTION|CREDENTIAL)/) {
                # Preserve quoting style so the file stays a valid .env.
                if (val ~ /^".*"$/)            { print key "=\"***REDACTED***\"" }
                else if (val ~ /^'\''.*'\''$/) { print key "='\''***REDACTED***'\''" }
                else if (val == "")            { print key "=" }
                else                           { print key "=***REDACTED***" }
            } else {
                print
            }
        }
    ' "$file"
}

# Redact arbitrary text on stdin -- Bearer tokens, AWS keys, JWTs, provider
# token prefixes (GitHub / GitLab / Slack), and labelled kv-pairs.
#
# The prefix arm catches bare tokens in log lines that aren't behind a
# `token=`/`Authorization:` label -- e.g. "git clone failed with token
# ghp_abc..." -- which the kv-pair arm would otherwise miss.
redact_stream() {
    sed -E \
        -e 's/(Bearer[[:space:]]+)[A-Za-z0-9._\-]+/\1***REDACTED***/g' \
        -e 's/(AKIA|ASIA)[A-Z0-9]{16}/\1***REDACTED***/g' \
        -e 's/(eyJ[A-Za-z0-9_\-]{10,}\.[A-Za-z0-9_\-]+\.[A-Za-z0-9_\-]+)/***REDACTED-JWT***/g' \
        -e 's/(gh[pousr]_|github_pat_|glpat-|xox[abprs]-)[A-Za-z0-9_-]+/\1***REDACTED***/g' \
        -e 's/(password|passwd|api[_-]?key|access[_-]?key|secret|token)([[:space:]]*[:=][[:space:]]*)"?[^"[:space:],}]+"?/\1\2"***REDACTED***"/gI'
}

# ─── Deployment helpers ───────────────────────────────────────────────────

# Returns 0 when docker daemon is reachable.
bundle_have_docker() {
    command -v docker >/dev/null 2>&1 && docker info >/dev/null 2>&1
}

# Returns 0 when kubectl can reach the cluster.
bundle_have_kubectl() {
    command -v kubectl >/dev/null 2>&1 \
        && kubectl version --request-timeout=5s >/dev/null 2>&1
}

BUNDLE_K8S_NAMESPACE="${BUNDLE_K8S_NAMESPACE:-bito-ai-architect}"
BUNDLE_LOG_TAIL_LINES="${BITOARCH_DIAG_LOG_LINES:-1000}"
BUNDLE_LOG_MAX_BYTES="${BITOARCH_DIAG_LOG_MAX_BYTES:-5242880}"
# Per-component cap on app-log files copied from BITOARCH_LOG_DIR (live log +
# newest rotations); bounds bundle size. See _collect_app_logs.
BUNDLE_APP_LOG_MAX_FILES="${BITOARCH_DIAG_APP_LOG_MAX_FILES:-3}"
