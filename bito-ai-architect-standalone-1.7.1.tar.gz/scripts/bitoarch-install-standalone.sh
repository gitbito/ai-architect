#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
#
# scripts/bitoarch-install-standalone.sh
# -----------------------------------------------------------------------------
# STANDALONE edition install bootstrap.
#
# Two modes, auto-detected:
#
#   LOCAL mode
#     Run from inside an already-extracted tarball. scripts/lib/install.sh and
#     docker-compose.yml are present alongside. Action: install from current
#     dir (no download, no extract).
#
#   CDN mode
#     Fetched via `curl | bash`. Action: download the Standalone tarball from
#     UPGRADE_DOWNLOAD_URL, extract to ~/bito-ai-architect, then install.
#
# Install flow:
#   install_run() in scripts/lib/install.sh reads $HOME/.bitoarch/install.yaml
#   (pre-placed by user OR seeded from the internal template on first run),
#   translates it into env vars, forces DEPLOYMENT_METHOD=docker-compose and
#   SKIP_SSO_PROMPT=true, then delegates to setup.sh::main(). Every step
#   beyond that point is the same code path as production's ./setup.sh flow --
#   same prompts, same messages, same exit codes. After prompts complete,
#   install.sh writes answers back to the yaml so future installs are
#   non-interactive. See scripts/lib/install.sh for details.
#
# CDN URL (CDN mode only):
#   Read from UPGRADE_DOWNLOAD_URL. The release pipeline injects this value
#   when publishing the bootstrap at origin. LOCAL mode does not require it.
#
# Distribution:
#   Hosted at CDN AND shipped in the Standalone tarball (same file serves both
#   modes). Production has a sibling bootstrap at scripts/bitoarch-install.sh
#   hosted on a separate CDN URL.
#
# -----------------------------------------------------------------------------
# INTENTIONAL DUPLICATION with scripts/bitoarch-install.sh
# -----------------------------------------------------------------------------
#   This file and scripts/bitoarch-install.sh are siblings served from TWO
#   separate CDN URLs (standalone vs production). Each must be FULLY
#   SELF-CONTAINED because it is the `curl | bash` target -- it runs before
#   any tarball has been downloaded, so it cannot `source` any other file.
#
#   MUST STAY DIVERGENT (edition-specific):
#     - Header comment block (edition docs)
#     - TARBALL_FILENAME / TEMP_DIR / EDITION constants
#     - show_help() body (edition UX)
#
#   MUST STAY IDENTICAL (keep in lockstep when editing either file):
#     - _bootstrap_die, parse_args, bootstrap_check_prerequisites,
#       bootstrap_download, bootstrap_extract,
#       bootstrap_handoff_to_install_run, cleanup, main
#
#   Any edit to a shared function here MUST also land in the sibling file
#   (and vice versa). A future packaging-time concatenation pass could remove
#   the duplication by sourcing a lib file into both bootstraps at publish
#   time, but today the manual lockstep is the cost of curl|bash.
# -----------------------------------------------------------------------------

set -e

# Buffer the whole script so bash doesn't re-read fd 0 after exec 0</dev/tty.
{

# -----------------------------------------------------------------------------
# Configuration (env-var driven; see header)
# -----------------------------------------------------------------------------
DOWNLOAD_BASE_URL="${UPGRADE_DOWNLOAD_URL:-https://aiarch.bito.ai}"
TARBALL_FILENAME="bito-ai-architect-standalone-latest.tar.gz"
TEMP_DIR="/tmp/bito-install-standalone-$$"
EDITION="standalone"

# Resolve our own on-disk location (through any symlinks)
_SCRIPT_SELF="${BASH_SOURCE[0]}"
while [[ -L "$_SCRIPT_SELF" ]]; do
    _SCRIPT_SELF="$(readlink "$_SCRIPT_SELF")"
done
SCRIPT_OWN_DIR="$(cd "$(dirname "$_SCRIPT_SELF")" && pwd)"
TARBALL_ROOT_CANDIDATE="$(cd "${SCRIPT_OWN_DIR}/.." && pwd)"

# Auto-detect mode
if [[ -f "${TARBALL_ROOT_CANDIDATE}/scripts/lib/install.sh" ]] \
   && [[ -f "${TARBALL_ROOT_CANDIDATE}/docker-compose.yml" ]]; then
    INSTALL_MODE="local"
    INSTALL_DIR="$TARBALL_ROOT_CANDIDATE"
else
    INSTALL_MODE="cdn"
    INSTALL_DIR="${HOME}/bito-ai-architect"
fi

# -----------------------------------------------------------------------------
# Minimal bootstrap-only error helper. User-visible install output is produced
# by setup.sh via cli-core's print_* (sourced during install_run), so we don't
# introduce any new decoration here.
# -----------------------------------------------------------------------------
_bootstrap_die() { echo "ERROR: $*" >&2; exit 1; }

# -----------------------------------------------------------------------------
# Help
# -----------------------------------------------------------------------------
show_help() {
    cat <<EOF
Bito AI Architect -- Standalone Install

USAGE:
  ./scripts/bitoarch-install-standalone.sh [--auto] [--help]

INSTALL YAML LOCATION:
  $HOME/.bitoarch/install.yaml
  Pre-place this file before `curl | bash` for zero-prompt installs. If
  absent, the installer creates it and writes back your prompt answers.

MODES:
  INTERACTIVE (default)
      Prompts for any required values not set in ~/.bitoarch/install.yaml.
      Identical UX to production setup.sh.

  AUTO / NON-INTERACTIVE  (AUTO_SETUP=true  or  --auto)
      No prompts. ~/.bitoarch/install.yaml must contain:
        * bito_api_key
        * git.provider       (github | gitlab | bitbucket)
        * git.access_token

OPTIONS:
  --auto, --non-interactive   Same as AUTO_SETUP=true
  --help, -h                  Show this help

ENV VARS:
  AUTO_SETUP=true             Non-interactive mode
  UPGRADE_DOWNLOAD_URL=<url>  Install CDN base URL (CDN mode only)

TYPICAL FLOWS:

  1. Pre-filled YAML (recommended for CI / scripted installs)
       mkdir -p ~/.bitoarch
       vim ~/.bitoarch/install.yaml
       curl -fsSL <install-url-sa> | bash

  2. Interactive (quick evaluation)
       curl -fsSL <install-url-sa> | bash
       # answers are written back to ~/.bitoarch/install.yaml

  3. Local mode (from an extracted tarball)
       ./scripts/bitoarch-install-standalone.sh
EOF
}

# -----------------------------------------------------------------------------
# Parse args (--help, --auto). Unknown args forwarded to install_run.
# -----------------------------------------------------------------------------
parse_args() {
    INSTALL_EXTRA_ARGS=()
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --help|-h)                  show_help; exit 0 ;;
            --auto|--non-interactive)   export AUTO_SETUP=true; shift ;;
            *)                          INSTALL_EXTRA_ARGS+=("$1"); shift ;;
        esac
    done
}

# -----------------------------------------------------------------------------
# CDN-only prerequisites (URL set, curl+tar present). Docker-running check is
# done by setup.sh's check_prerequisites, so we don't duplicate it here.
# -----------------------------------------------------------------------------
bootstrap_check_prerequisites() {
    if [[ "$INSTALL_MODE" = "cdn" ]]; then
        if [[ -z "$DOWNLOAD_BASE_URL" ]]; then
            _bootstrap_die "UPGRADE_DOWNLOAD_URL is not set (required in CDN mode)."
        fi
        local missing=()
        for tool in curl tar; do
            command -v "$tool" >/dev/null 2>&1 || missing+=("$tool")
        done
        if [[ ${#missing[@]} -gt 0 ]]; then
            _bootstrap_die "Missing required tools: ${missing[*]}"
        fi
    fi
}

# -----------------------------------------------------------------------------
# CDN mode: download tarball
# -----------------------------------------------------------------------------
bootstrap_download() {
    mkdir -p "$TEMP_DIR"
    local tarball_url="${DOWNLOAD_BASE_URL}/standalone/latest/${TARBALL_FILENAME}"
    local tarball_path="${TEMP_DIR}/${TARBALL_FILENAME}"

    if ! curl -# -L -f -o "$tarball_path" "$tarball_url"; then
        _bootstrap_die "Download failed: ${tarball_url}"
    fi
    [[ -s "$tarball_path" ]] || _bootstrap_die "Downloaded file is empty"
    echo "$tarball_path"
}

# -----------------------------------------------------------------------------
# CDN mode: extract tarball (idempotent; replaces existing install dir)
# -----------------------------------------------------------------------------
bootstrap_extract() {
    local tarball_path="$1"
    mkdir -p "$INSTALL_DIR"
    # On extract failure, keep the dir only if the canonical tarball marker
    # (scripts/lib/install.sh) exists -- that lets a retry proceed.
    if ! tar -xzf "$tarball_path" -C "$INSTALL_DIR" --strip-components=1; then
        [[ -f "${INSTALL_DIR}/scripts/lib/install.sh" ]] || rm -rf "$INSTALL_DIR"
        _bootstrap_die "Extraction failed"
    fi
    if [[ ! -f "${INSTALL_DIR}/scripts/lib/install.sh" ]]; then
        _bootstrap_die "Invalid package (missing scripts/lib/install.sh)"
    fi
    find "${INSTALL_DIR}/scripts" -name "*.sh" -type f -exec chmod +x {} \; 2>/dev/null || true
    # Both `bitoarch` CLI and `setup.sh` ship in both tarballs; chmod both
    # unconditionally so this function stays identical across siblings.
    [[ -f "${INSTALL_DIR}/bitoarch" ]] && chmod +x "${INSTALL_DIR}/bitoarch" 2>/dev/null || true
    [[ -f "${INSTALL_DIR}/setup.sh" ]] && chmod +x "${INSTALL_DIR}/setup.sh" 2>/dev/null || true
}

# -----------------------------------------------------------------------------
# Handoff: set SCRIPT_DIR/PLATFORM_DIR (prod convention), source the install
# library, call install_run (which delegates to setup.sh::main).
#
# set +e is required because install_run sources adapter files that do
# `source <optional> || true`, and bash's source builtin interacts badly with
# set -e on missing files. setup.sh::main has explicit error handling where
# termination matters.
# -----------------------------------------------------------------------------
bootstrap_handoff_to_install_run() {
    cd "$INSTALL_DIR" || exit 1

    # Reconnect stdin to the terminal so interactive prompts work when the
    # script is piped through curl|bash.
    if [[ ! -t 0 ]]; then
        [ -r /dev/tty ] || _bootstrap_die "Interactive prompts require /dev/tty. Re-run as: curl -fsSL <url> -o install.sh && bash install.sh"
        exec 0</dev/tty
    fi

    export SCRIPT_DIR="${INSTALL_DIR}"
    export PLATFORM_DIR="${INSTALL_DIR}"

    # Standalone edition env consumed by setup.sh: Docker-only, no SSO prompt,
    # auto MCP token, compact per-service output. install_run persists these
    # to .env-bitoarch on success.
    export DEPLOYMENT_METHOD="docker-compose"
    export SKIP_SSO_PROMPT=true
    export AUTO_GENERATE_MCP_TOKEN=true
    export COMPACT_INSTALL_PROGRESS=true

    set +e
    # shellcheck disable=SC1091
    source "${SCRIPT_DIR}/scripts/setup-utils.sh"
    # shellcheck disable=SC1091
    source "${SCRIPT_DIR}/scripts/lib/cli-core.sh"
    # shellcheck disable=SC1091
    source "${SCRIPT_DIR}/scripts/lib/path-manager.sh"
    # shellcheck disable=SC1091
    source "${SCRIPT_DIR}/scripts/lib/install.sh"

    install_run "$@"
}

# -----------------------------------------------------------------------------
# Cleanup + trap
# -----------------------------------------------------------------------------
cleanup() {
    [[ -d "$TEMP_DIR" ]] && rm -rf "$TEMP_DIR"
    return 0   # Don't let a missing TEMP_DIR (e.g. after --help) flip exit code
}
trap cleanup EXIT

# -----------------------------------------------------------------------------
# Main
# -----------------------------------------------------------------------------
main() {
    parse_args "$@"
    bootstrap_check_prerequisites

    if [[ "$INSTALL_MODE" = "cdn" ]]; then
        local tarball_path
        tarball_path=$(bootstrap_download)
        bootstrap_extract "$tarball_path"
    fi

    bootstrap_handoff_to_install_run "${INSTALL_EXTRA_ARGS[@]}"
}

main "$@"
exit "$?"

} # end script buffer
