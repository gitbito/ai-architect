# Bito's AI Architect — Standalone Setup Guide

One-machine developer install. Under 5 minutes to first MCP query.

> Multi-user or shared-server install? Use the [Enterprise Setup Guide](enterprise-setup-guide.md) instead.
>
> Install URLs come from the release announcement:
> - `https://aiarchitect.bito.ai/standalone/install.sh` — Standalone bootstrap
> - `https://aiarchitect.bito.ai/standalone/uninstall.sh` — CDN uninstaller (broken-CLI recovery)

---

## 1. Requirements

| | Minimum | Recommended |
|--|--------|-------------|
| OS | macOS 12+, Ubuntu 20.04+, WSL2 | Same |
| Docker | Desktop 20.10+ with Compose v2 | Docker Desktop 4.x+ |
| Docker RAM | 6 GB | 8 GB+ |
| Docker CPUs | 3 | 4+ |
| Disk | 10 GB | 50 GB+ |
| Ports | 5001–5005 free on localhost | Same |

---

## 2. Install

```bash
curl -fsSL https://aiarchitect.bito.ai/standalone/install.sh | bash
```

Prompts for Bito API key + git provider + PAT (unless `~/.bitoarch/install.yaml` is pre-seeded). Prints MCP URL + token on success.

**Skip prompts (pre-seed creds):**

```bash
mkdir -p ~/.bitoarch
cat > ~/.bitoarch/install.yaml <<'EOF'
bito_api_key: "<your-bito-api-key>"
git:
  provider: github
  access_token: "<your-git-pat>"
EOF
curl -fsSL https://aiarchitect.bito.ai/standalone/install.sh | bash
```

**Re-install / update-in-place:** re-run the same curl. Idempotent — existing `.env-bitoarch` is reused, no prompts.

**Live config reload:** edit `~/.bitoarch/install.yaml`, then `bitoarch restart --force`. Mapped fields (ports, resources, creds) reload; auto-generated secrets (JWT, DB pwds, MCP token) untouched.

---

## 3. Connect MCP client

Standalone runs MCP over **HTTPS** at `https://localhost:5001/mcp` with a local mkcert-signed leaf cert. The cert is per-host (issued at install time, never reused across machines); mkcert is auto-downloaded if not on PATH. The install bootstrap auto-registers the local MCP into every detected coding agent (Claude Code, Cursor, Windsurf, VS Code, Junie, JetBrains AI Assistant) and prints a one-time IDE-restart prompt for each. After restart, your IDE connects without further config.

```bash
bitoarch mcp-info        # URL + token + auth mode
bitoarch mcp-install     # re-run agent registration (e.g., after installing a new IDE)
bitoarch mcp-cert status # cert verdict, days remaining, scheduler state
```

**Manual config fallback** (if your IDE isn't auto-detected, or for the Claude Desktop main chat which doesn't read `~/.claude.json`):

```json
{
  "mcpServers": {
    "BitoAIArchitect": {
      "url": "https://localhost:5001/mcp",
      "headers": { "Authorization": "Bearer <TOKEN>" }
    }
  }
}
```

> The cert auto-renews daily via an OS-native scheduler (launchd on macOS, systemd-user timer or crontab on Linux/WSL). Override the renew time via `bitoarch mcp-cert schedule HH:MM`. To opt out, set `BITOARCH_CERT_AUTO_RENEW=false` in `.env-bitoarch` and re-run `bitoarch install`.

---

## 4. Add repos

```bash
bitoarch add-repo myorg/my-backend-repo
bitoarch add-repo myorg/my-frontend-repo
bitoarch index-repos
bitoarch index-status
```

Or pre-populate `~/bito-ai-architect/.bitoarch-config.yaml`:

```yaml
repository:
  configured_repos:
    - namespace: myorg/backend-api
    - namespace: myorg/frontend-app
```

```bash
bitoarch add-repos
bitoarch index-repos
```

> One indexing job per workspace at a time. Re-trigger `bitoarch index-repos` after the current run if you add a repo mid-index.

---

## 5. Standalone-only commands

These exist only when `MCP_AUTO_INSTALL=true` in `.env-bitoarch` (set automatically by the Standalone install bootstrap). On Enterprise installs they are hidden from `bitoarch --help` and refuse to run.

| Command | Description |
|---------|-------------|
| `bitoarch mcp-install [--email <addr>]` | Re-register the local MCP with detected coding agents (Claude Code, Cursor, Windsurf, VS Code, Junie, JetBrains AI Assistant). Run after installing a new IDE. |
| `bitoarch mcp-cert status` | Cert verdict (✓/⚠/✗), days remaining, paths, scheduler state. |
| `bitoarch mcp-cert renew` | Force re-issue cert and restart cis-provider. |
| `bitoarch mcp-cert renew --check` | Renew only if expiring within 60 days (this is the cron entry point — not normally run by hand). |
| `bitoarch mcp-cert paths` | Print cert path. |
| `bitoarch mcp-cert schedule` | Show current renew time + scheduler state. |
| `bitoarch mcp-cert schedule HH:MM` | Set the daily auto-renew time (24h). Persists to `.env-bitoarch` as `BITOARCH_CERT_RENEW_TIME`. |

The cert auto-renews daily via an OS-native scheduler (launchd on macOS, systemd-user timer on Linux/WSL, crontab fallback). To opt out, add `BITOARCH_CERT_AUTO_RENEW=false` to `.env-bitoarch` and re-run `bitoarch install`.

---

## 6. Common commands

```bash
bitoarch status            # service health
bitoarch logs              # tail logs (append a service name to filter)
bitoarch mcp-info          # URL + token + auth mode
bitoarch mcp-test          # end-to-end MCP check
bitoarch mcp-install       # re-register MCP with installed coding agents (Standalone-only)
bitoarch mcp-cert --help   # cert lifecycle: status / renew / schedule (Standalone-only)

bitoarch stop
bitoarch start
bitoarch restart
bitoarch restart --force   # reload env + recreate containers
bitoarch update            # refresh images per versions/service-versions.json
bitoarch upgrade           # blue/green tarball swap

bitoarch config edit
bitoarch config edit repos
bitoarch config path

bitoarch reset             # wipe state; keep install dir
bitoarch uninstall         # full removal
```

---

## 7. Troubleshooting

```bash
# "Docker has only X GB RAM allocated (6 GB recommended)"
# → Docker Desktop → Settings → Resources → Memory → 6 GB+ → Apply & Restart

# "Port 5001 is in use" — edit ~/.bitoarch/install.yaml BEFORE install:
# ports: { cis_provider: 6001, cis_manager: 6002, cis_config: 6003, mysql: 6004, cis_tracker: 6005 }

# "bitoarch: command not found" right after install
source ~/.zshrc        # or ~/.bashrc

# Services stopped after sleep / reboot
bitoarch start

# Indexing stuck
bitoarch index-status
bitoarch logs cis-manager
bitoarch stop-indexing && bitoarch index-repos

# Corporate proxy — before install
export HTTP_PROXY=http://proxy:8080 HTTPS_PROXY=http://proxy:8080
export NO_PROXY=localhost,127.0.0.1,ai-architect-config,ai-architect-manager,ai-architect-provider
curl -fsSL https://aiarchitect.bito.ai/standalone/install.sh | bash

# Defensive uninstall (CLI broken)
curl -fsSL https://aiarchitect.bito.ai/standalone/uninstall.sh | bash
```

---

## 8. Upgrade

```bash
bitoarch upgrade                    # latest
bitoarch upgrade --version=1.8.0    # specific version
```

Blue/green tarball swap. Volumes (indexed data + config) are preserved; previous install stays at `<parent>/bito-ai-architect-<old>` until you `rm -rf` it. Rollback is not supported after a successful upgrade.

---

## 9. Uninstall

```bash
bitoarch reset       # wipe containers/volumes/config; keep install dir
bitoarch uninstall   # full removal (+ install dir + ~/.bitoarch/install.yaml)
```

Docker images are kept — `docker image prune` to reclaim.

---

## 10. Known limits (v1)

- Single instance per machine (fixed container names).
- One indexing job per workspace at a time.
- Requires Bito LLM (from API key) or custom LLM key — no basic-indexing-only mode.
- Git auth is PAT-only; no SSH / OAuth helpers.
- No demo mode / pre-seeded sample repo.

---

## 11. Help

```bash
bitoarch logs
cat ~/bito-ai-architect/setup.log
bitoarch mcp-test
bitoarch --help
bitoarch <command> --help
```
