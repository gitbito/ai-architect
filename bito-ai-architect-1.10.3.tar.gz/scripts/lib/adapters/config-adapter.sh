#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
# Bito's AI Architect CLI - Config Adapter
# Handles AI Architect Config service commands

# Source http-client for K8s port-forward support
if [ -z "$SCRIPT_DIR" ]; then
    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && cd ../.. && pwd)"
fi
source "${SCRIPT_DIR}/scripts/lib/http-client.sh" 2>/dev/null || true

# Source the LLM provider registry (drives create_llm_integration_json).
# Resolved relative to this file so it loads even if SCRIPT_DIR is stale/unset.
source "$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)/llm-registry.sh" 2>/dev/null || true

# Source config-backup-manager for centralized backup utility
if [ -f "${SCRIPT_DIR}/scripts/lib/config-backup-manager.sh" ]; then
    source "${SCRIPT_DIR}/scripts/lib/config-backup-manager.sh"
fi

# Ensure config service is accessible (handles K8s port-forward automatically)
ensure_config_service_accessible() {
    # Get port from environment
    local CONFIG_PORT="${CIS_CONFIG_EXTERNAL_PORT:-5003}"

    # Ensure service is accessible (no-op for Docker, sets up port-forward for K8s)
    ensure_service_accessible "ai-architect-config" "$CONFIG_PORT" 2>/dev/null || true
}

# Sync the workspace's stored bito_access_key in cis-config to a rotated Bito
# API key (single-tenant PATCH partial update). cis-config authenticates the
# caller against the key the service is currently running with, so a rotation
# must authenticate with the CURRENT (old) key while setting the stored value
# to the new one — hence the separate auth_key.
# Returns 0 on a 2xx response, non-zero otherwise so callers can warn without
# aborting (e.g. when no base config row exists yet).
# Usage: config_sync_bito_access_key <new_key> [<auth_key>]
#   new_key   stored as bito_access_key (the PATCH body)
#   auth_key  Bearer key to authenticate with (default: new_key)
config_sync_bito_access_key() {
    local new_key="$1"
    local auth_key="${2:-$new_key}"
    [ -z "$new_key" ] && return 1

    ensure_config_service_accessible
    local CONFIG_PORT="${CIS_CONFIG_EXTERNAL_PORT:-5003}"
    local CONFIG_URL="${CONFIG_URL:-http://localhost:${CONFIG_PORT}}"

    local code
    code=$(curl -s -o /dev/null -w '%{http_code}' --max-time 15 \
        -X PATCH \
        -H "Authorization: Bearer ${auth_key}" \
        -H "Content-Type: application/json" \
        -d "{\"bito_access_key\": \"${new_key}\"}" \
        "${CONFIG_URL}/api/v1/config" 2>/dev/null) || true

    case "$code" in
        2[0-9][0-9]) return 0 ;;
        *) log_silent "cis-config bito_access_key sync failed (HTTP ${code:-000})"; return 1 ;;
    esac
}
export -f config_sync_bito_access_key

# Fetch the workspace_id of this instance's current cis-config row, authenticating
# with the given (current/old) key — the running service accepts that key. Echoes
# the workspace_id on stdout when a config row exists.
# Returns: 0 = config row exists (stdout = workspace_id); 2 = no config row (404);
# 1 = request error / no key. Callers branch on the return code.
# Usage: config_fetch_workspace_id <auth_key>
config_fetch_workspace_id() {
    local auth_key="$1"
    [ -z "$auth_key" ] && return 1

    ensure_config_service_accessible
    local CONFIG_PORT="${CIS_CONFIG_EXTERNAL_PORT:-5003}"
    local CONFIG_URL="${CONFIG_URL:-http://localhost:${CONFIG_PORT}}"

    local resp code body
    resp=$(curl -s -w '\n%{http_code}' --max-time 15 \
        -H "Authorization: Bearer ${auth_key}" \
        "${CONFIG_URL}/api/v1/config" 2>/dev/null) || true
    code=$(printf '%s' "$resp" | tail -1)
    body=$(printf '%s' "$resp" | sed '$d')

    case "$code" in
        2[0-9][0-9]) printf '%s' "$body" | jq -r '.workspace_id // empty' 2>/dev/null; return 0 ;;
        404)         return 2 ;;
        *)           return 1 ;;
    esac
}
export -f config_fetch_workspace_id

# Validate the structural shape of a .bitoarch-config.yaml file.
#
# Checks (in order): syntax, top-level `repository` key, `.repository` is a
# mapping, `.repository.configured_repos` is a list or null. Pure bash —
# delegates the actual YAML parsing to yq. If yq is unavailable, returns 0
# silently (validation skipped) and the next extraction step will surface
# any tooling error.
#
# _build_json_field runs a JSON builder function and extracts a jq path from its
# output, failing if the builder fails OR emits nothing. This must NOT be written
# as `field=$(builder | jq …) || …`: with no `set -o pipefail`, the pipeline's exit
# status is jq's, and jq on empty stdin exits 0 with no output — so a builder that
# returns 1 (e.g. missing Git creds) would slip through the `||` guard and a broken
# empty config would be built and pushed. Capturing the builder output first
# restores the builder's failure/emptiness guard.
#
# Usage: field=$(_build_json_field create_git_integration_json '.integration.git') || { print_error …; return 1; }
_build_json_field() {
    local builder="$1" filter="$2" raw
    raw=$("$builder") || return 1
    [ -n "$raw" ] || return 1
    printf '%s' "$raw" | jq "$filter"
}

# Usage: _validate_repos_yaml_shape <yaml_file> [hint]
#   hint defaults to "Run: bitoarch config edit repos"; pass "" to omit.
# Returns: 0 if valid (or yq unavailable), 1 if invalid.
_validate_repos_yaml_shape() {
    local yaml_file="$1"
    local hint="${2-Run: bitoarch config edit repos}"
    local hint_suffix=""
    [ -n "$hint" ] && hint_suffix=". $hint"

    if [ ! -f "$yaml_file" ]; then
        print_error "Config file not found: $yaml_file"
        log_silent "config validation: file not found: $yaml_file"
        return 1
    fi

    # yq is the canonical YAML parser; skip validation if it's missing so
    # we don't block on environments without it. The extraction step in the
    # caller will still error out cleanly if it needs a YAML processor.
    command -v yq >/dev/null 2>&1 || return 0

    if ! yq eval '.' "$yaml_file" >/dev/null 2>&1; then
        print_error "Invalid YAML syntax in $yaml_file${hint_suffix}"
        log_silent "config validation: invalid YAML syntax in $yaml_file"
        return 1
    fi
    if [ "$(yq eval 'has("repository")' "$yaml_file" 2>/dev/null)" != "true" ]; then
        print_error "Invalid config file structure: missing 'repository' key in $yaml_file${hint_suffix}"
        log_silent "config validation: missing 'repository' key in $yaml_file"
        return 1
    fi
    if [ "$(yq eval '.repository | type' "$yaml_file" 2>/dev/null)" != "!!map" ]; then
        print_error "'repository' must be a mapping in $yaml_file${hint_suffix}"
        log_silent "config validation: .repository is not a map in $yaml_file"
        return 1
    fi
    local cr_type
    cr_type=$(yq eval '.repository.configured_repos | type' "$yaml_file" 2>/dev/null)
    if [ "$cr_type" != "!!seq" ] && [ "$cr_type" != "!!null" ]; then
        print_error "'repository.configured_repos' must be a list in $yaml_file (found: ${cr_type})${hint_suffix}"
        log_silent "config validation: .repository.configured_repos type=${cr_type} in $yaml_file (expected !!seq or !!null)"
        return 1
    fi

    return 0
}

# Validate a repository namespace.
#
# Accepts org/repo and GitLab nested subgroups (group/subgroup/.../repo):
# two or more slash-separated segments, with no leading, trailing, or empty
# segment. Returns 0 when the namespace is valid, 1 otherwise.
_is_valid_repo_namespace() {
    [[ "$1" =~ ^[a-zA-Z0-9_-]+(/[a-zA-Z0-9_.-]+)+$ ]]
}

# Helper function to encrypt secrets for config payload
config_encrypt_secrets() {
    local bito_key="$1"
    local git_json="$2"
    
    # Get encryption key from environment
    if [ -z "$SECRETS_ENCRYPTION_KEY" ]; then
        print_error "SECRETS_ENCRYPTION_KEY not found in environment"
        return 1
    fi
    
    # Set LOG_FILE if not already set (required by setup-utils.sh)
    if [ -z "$LOG_FILE" ]; then
        export LOG_FILE="/dev/null"
    fi
    
    # Source encryption function from setup-utils
    if [ -f "${SCRIPT_DIR}/setup-utils.sh" ]; then
        source "${SCRIPT_DIR}/setup-utils.sh"
    elif [ -f "./scripts/setup-utils.sh" ]; then
        source "./scripts/setup-utils.sh"
    else
        print_error "setup-utils.sh not found"
        return 1
    fi
    
    # Encrypt BITO API key
    local encrypted_bito=$(encrypt_secret "$bito_key" "$SECRETS_ENCRYPTION_KEY")
    if [ $? -ne 0 ] || [ -z "$encrypted_bito" ]; then
        print_error "Failed to encrypt Bito API key"
        return 1
    fi
    
    # Extract and encrypt git access token
    local git_token=$(echo "$git_json" | jq -r '.access_token')
    if [ -z "$git_token" ] || [ "$git_token" = "null" ]; then
        print_error "Git access token not found"
        return 1
    fi
    
    local encrypted_token=$(encrypt_secret "$git_token" "$SECRETS_ENCRYPTION_KEY")
    if [ $? -ne 0 ] || [ -z "$encrypted_token" ]; then
        print_error "Failed to encrypt git access token"
        return 1
    fi
    
    # Update git JSON with encrypted token
    local encrypted_git=$(echo "$git_json" | jq --arg token "$encrypted_token" '.access_token = $token')
    
    # Output encrypted values as JSON for easy parsing
    jq -n \
        --arg bito "$encrypted_bito" \
        --argjson git "$encrypted_git" \
        '{bito_key: $bito, git_json: $git}'
}

# ── Helper: Extract workspace_id from config API response and persist to env ──
_persist_workspace_id_from_response() {
    local body="$1"
    
    # Try to extract workspace_id from the response JSON
    local workspace_id=""
    if command -v jq >/dev/null 2>&1; then
        workspace_id=$(echo "$body" | jq -r '.workspace_id // .workspaceId // .data.workspace_id // .data.workspaceId // empty' 2>/dev/null)
    fi
    
    # Only persist if we got a valid numeric workspace_id
    if [ -n "$workspace_id" ] && [[ "$workspace_id" =~ ^[0-9]+$ ]]; then
        local env_file
        if command -v get_config_file >/dev/null 2>&1; then
            env_file=$(get_config_file)
        elif [ -n "${ENV_FILE:-}" ]; then
            env_file="$ENV_FILE"
        else
            env_file="${BITOARCH_CONFIG_DIR:-/usr/local/etc/bitoarch}/.env-bitoarch"
        fi
        
        if [ -f "$env_file" ] && command -v set_env_key_value >/dev/null 2>&1; then
            # Skip if workspace_id is already set to the same value (avoids unnecessary restart)
            local existing_wid=""
            existing_wid=$(grep -m1 '^XMCP_SSO_DEFAULT_WORKSPACE_ID=' "$env_file" 2>/dev/null | cut -d= -f2 | tr -d '"' | tr -d "'")
            if [ "$existing_wid" = "$workspace_id" ]; then
                log_silent "workspace_id=$workspace_id already set, skipping update and restart"
                return 0
            fi
            
            set_env_key_value "XMCP_SSO_DEFAULT_WORKSPACE_ID" "$workspace_id" "$env_file"
            log_silent "Persisted workspace_id=$workspace_id to $env_file (was: ${existing_wid:-empty})"

            # For K8s: update ConfigMap + restart provider to pick up new workspace_id
            local deployment_type="docker-compose"
            if type get_deployment_type >/dev/null 2>&1; then
                deployment_type=$(get_deployment_type)
            else
                local dt_file="${BITOARCH_CONFIG_DIR:-/usr/local/etc/bitoarch}/.deployment-type"
                [ -f "$dt_file" ] && deployment_type=$(cat "$dt_file")
            fi
            if [ "$deployment_type" = "kubernetes" ]; then
                # Reuse xmcp_restart_provider which handles: ConfigMap patch → rollout restart → port-forwards
                if command -v xmcp_restart_provider >/dev/null 2>&1; then
                    log_silent "K8s: restarting provider to sync workspace_id=$workspace_id"
                    xmcp_restart_provider >/dev/null 2>&1
                fi
            fi
        fi
    fi
}

# Config command handler
handle_config() {
    local command="$1"
    shift
    
    # Check for help
    if [ "$command" = "--help" ] || [ "$command" = "-h" ] || [ -z "$command" ]; then
        show_config_help
        return 0
    fi
    
    # Route to command
    case "$command" in
        repo)
            handle_config_repo "$@"
            ;;
        *)
            print_error "Unknown config command: $command"
            echo ""
            echo "Available commands: repo"
            echo -e "Use ${YELLOW}bitoarch --help${NC} for more information"
            return 1
            ;;
    esac
}

# Repository configuration commands
handle_config_repo() {
    local command="$1"
    shift

    case "$command" in
        get)
            config_repo_get "$@"
            ;;
        add)
            # Check if argument looks like a namespace or a file
            if [ -n "$1" ] && [ ! -f "$1" ] && _is_valid_repo_namespace "$1"; then
                # It's a namespace pattern (org/repo or group/subgroup/repo)
                config_repo_add_namespace "$@"
            elif [ -n "$1" ] && [ -f "$1" ]; then
                # It's a file
                config_repo_add_from_file "$@"

            else
                print_error "Invalid argument. Expected namespace (org/repo or group/subgroup/repo) or YAML file path"
                echo ""
                echo "Usage:"
                echo -e "  ${YELLOW}bitoarch add-repo <namespace>${NC}        # Add single repository"
                echo -e "  ${YELLOW}bitoarch add-repos [yaml-file]${NC}       # Add from YAML file"
                echo ""
                echo "Examples:"
                echo -e "  ${YELLOW}bitoarch add-repo myorg/myrepo${NC}"
                echo -e "  ${YELLOW}bitoarch add-repos${NC}                   # Uses default config location"
                return 1
            fi
            ;;
        remove)
            config_repo_remove_namespace "$@"
            ;;
        update)
            config_repo_update_from_file "$@"
            ;;
        validate)
            config_repo_validate "$@"
            ;;
        --help|-h|"")
            cat << 'EOF'
REPOSITORY CONFIGURATION

COMMANDS:
  get                Get current configuration
  add <namespace>    Add single repository by namespace
  add <yaml-file>    Add repositories from YAML file
  remove <namespace> Remove repository by namespace
  update             Update configuration from YAML file
  validate           Validate configuration

Use 'bitoarch <command> --help' for command details
EOF
            ;;
        *)
            print_error "Unknown repo config command: $command"
            return 1
            ;;
    esac
}

# Get current configuration from cis-config
config_repo_get() {
    local show_raw=false
    
    # Parse options
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --help|-h)
                cat << 'EOF'
USAGE:
  bitoarch show-config [OPTIONS]

DESCRIPTION:
  Retrieve the current configuration from AI Architect Config service.
  Returns the complete workspace configuration including Git integration and repository settings.

OPTIONS:
  --raw    Show raw API response with secrets masked

EXAMPLES:
  bitoarch show-config
  bitoarch show-config --raw
  bitoarch show-config | jq '.repository'

NOTES:
  - Requires BITO_API_KEY to be set in environment
  - Connects to AI Architect Config service using CONFIG_URL from .env-bitoarch
  - Output is in JSON format
  - Secrets are automatically masked in output
EOF
                return 0
                ;;
            --raw)
                show_raw=true
                shift
                ;;
            *)
                shift
                ;;
        esac
    done
    
    # Get BITO API key from environment
    if [ -z "$BITO_API_KEY" ]; then
        print_error "BITO_API_KEY not found in environment"
        return 1
    fi
    
    # Get config external port from environment (default to 5003)
    ensure_config_service_accessible
    local CONFIG_PORT="${CIS_CONFIG_EXTERNAL_PORT:-5003}"
    local CONFIG_URL="${CONFIG_URL:-http://localhost:${CONFIG_PORT}}"
    
    print_info "Fetching configuration from ${CONFIG_URL}..."
    
    # Make API call directly with curl
    local response=$(curl -s -w '\n%{http_code}' \
        -X GET \
        -H "Authorization: Bearer ${BITO_API_KEY}" \
        "${CONFIG_URL}/api/v1/config" 2>&1)
    
    # Extract HTTP code from last line
    local http_code=$(echo "$response" | tail -1)
    local body=$(echo "$response" | sed '$d')
    
    # Check HTTP code
    if [ "$http_code" -ge 200 ] && [ "$http_code" -lt 300 ]; then
        # Use appropriate render function based on --raw flag
        if [ "$show_raw" = "true" ]; then
            render_config_get_raw_block "$body"
        else
            render_config_get_summary_block "$body"
        fi
        return 0
    else
        render_config_get_failure_block "$http_code" "$body"
        return 1
    fi
}

# Update configuration from YAML file (generic YAML to JSON conversion with PUT method)
config_repo_update_from_file() {
    local yaml_file=""
    local show_raw=false
    
    # Parse options
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --help|-h)
                yaml_file="--help"
                shift
                ;;
            --raw)
                show_raw=true
                shift
                ;;
            *)
                if [ -z "$yaml_file" ] || [ "$yaml_file" = "--help" ]; then
                    yaml_file="$1"
                fi
                shift
                ;;
        esac
    done
    
    if [ "$yaml_file" = "--help" ]; then
        cat << 'EOF'
USAGE:
  bitoarch update-repos [yaml-file]

DESCRIPTION:
  Update the configuration with settings from a YAML file.
  If no file is specified, uses the default config file location.
  The entire YAML file is converted to JSON and sent to the Config API.

YAML FILE FORMAT:
  bito_access_key: ${BITO_API_KEY}
  integration:
    git:
      provider: ${GIT_PROVIDER}
      access_token: ${GIT_ACCESS_TOKEN}
  repository:
    repo_limit: 200
    repo_size_limit: "2GB"
    configured_repos:
      - namespace: "your-org/your-repo"
      - namespace: "another-org/another-repo"
  # Optional: LLM configuration
  # llm:
  #   providers:
  #     openai:
  #       model: "gpt-4"
  #       api_key: "${OPENAI_KEY}"

EXAMPLES:
  bitoarch update-repos                           # Uses default config location
  bitoarch update-repos /path/to/custom-config.yaml  # Use custom path if needed

NOTES:
  - File path is optional - defaults to standard config location
  - This is a PUT operation - performs full configuration update
  - Entire YAML file is converted to JSON generically 
  - Environment variables are automatically substituted from .env-bitoarch
  - API accepts JSON with Content-Type: application/json
  - Requires 'jq' and 'yq' (or python3 with PyYAML) for parsing
EOF
        return 0
    fi
    
    # If no file specified, use default from path-manager
    if [ -z "$yaml_file" ]; then
        if type get_repo_config_file >/dev/null 2>&1; then
            yaml_file=$(get_repo_config_file)
            log_silent "Using default config file: $yaml_file"
        else
            print_error "Cannot determine default config file location"
            print_info "Please specify the config file path explicitly"
            return 1
        fi
    fi

    # Validate file exists and is readable
    if [ ! -f "$yaml_file" ]; then
        print_error "Config file not found: $yaml_file"
        print_info "Please create the configuration file or specify a valid path"
        return 1
    fi

    if [ ! -r "$yaml_file" ]; then
        print_error "Cannot read config file: $yaml_file"
        print_info "Check file permissions"
        return 1
    fi
    
    # Verify we have jq for JSON processing
#    if ! require_command jq; then
#        print_error "jq is required for this operation"
#        print_info "Install jq: brew install jq (macOS) or apt-get install jq (Ubuntu)"
#        return 1
#    fi

    local json_data
#    json_data=$(build_cis_config_json  "$yaml_file")

    # ---- ENV validation --------------------------------------------------
    if [ -z "$BITO_API_KEY" ]; then
        print_error "BITO_API_KEY missing in environment"
        return 1
    fi

    # ---- Git integration JSON -------------------------------------------
    local git_json
    git_json=$(_build_json_field create_git_integration_json '.integration.git') || {
        print_error "Failed generating Git integration JSON"; return 1
    }

    # ---- LLM integration JSON -------------------------------------------
    local llm_json
    llm_json=$(_build_json_field create_llm_integration_json '.llm') || {
        print_error "Failed generating LLM provider JSON"; return 1
    }

    # ---- Scheduler config JSON ------------------------------------------
    local scheduler_json
    scheduler_json=$(create_scheduler_config_json)

    # ---- Extract configured repos ---------------------------------------
    local repos_json

    # Validate shape (syntax + .repository is map + configured_repos is seq/null).
    # Helper handles both yq and python3 internally so the two engines can't drift.
    if ! _validate_repos_yaml_shape "$yaml_file"; then
        return 1
    fi

    # Extract — engine choice is independent of validation above.
    if command -v yq >/dev/null 2>&1; then
        repos_json=$(yq -o=json '.repository.configured_repos // []' "$yaml_file")
    elif command -v python3 >/dev/null 2>&1 && python3 -c "import yaml" 2>/dev/null; then
        repos_json=$(python3 -c "import yaml, json, sys; data=yaml.safe_load(open(sys.argv[1])); print(json.dumps(data.get('repository', {}).get('configured_repos', [])))" "$yaml_file" 2>/dev/null)
    else
        print_error "YAML processing tool not found"
        print_error "Please install either:"
        print_info "  • yq: https://github.com/mikefarah/yq#install"
        print_info "  • python3 with PyYAML: pip3 install PyYAML"
        return 1
    fi

    if [ -z "$repos_json" ] || [ "$repos_json" = "null" ]; then
        print_error "Failed reading repository.configured_repos from $yaml_file. Run: bitoarch config edit repos"
        log_silent "config parse: extraction returned empty/null for $yaml_file (likely BOM/CRLF or a non-map repository value)"
        return 1
    fi

    # Normalize: convert plain string → {"namespace": "..."}
    repos_json=$(echo "$repos_json" | jq '
        map(
            if type=="string" then { "namespace": . }
            else .
            end
        )
    ')

    # ---- Build final JSON payload ----------------------------------------
    local repository_json
    repository_json=$(create_repository_config_json "$repos_json")

    local json_data
    if [ -n "$scheduler_json" ] && [ "$scheduler_json" != "null" ]; then
        json_data=$(jq -n \
            --arg access "$BITO_API_KEY" \
            --argjson git "$git_json" \
            --argjson llm "$llm_json" \
            --argjson repository "$repository_json" \
            --argjson scheduler "$scheduler_json" \
            '
            {
                bito_access_key: $access,
                integration: { git: $git },
                repository: $repository,
                llm: $llm,
                scheduler: $scheduler
            }
            '
        )
    else
        json_data=$(jq -n \
            --arg access "$BITO_API_KEY" \
            --argjson git "$git_json" \
            --argjson llm "$llm_json" \
            --argjson repository "$repository_json" \
            '
            {
                bito_access_key: $access,
                integration: { git: $git },
                repository: $repository,
                llm: $llm
            }
            '
        )
    fi

    if [ $? -ne 0 ] || [ -z "$json_data" ]; then
        print_error "Failed to build repository configuration JSON"
        return 1
    fi

    # Merge insights sub-objects so a full PUT doesn't wipe them.
    json_data=$(_merge_insights_into_config "$json_data")
    if [ -z "$json_data" ]; then
        print_error "Failed merging insights config into payload"
        return 1
    fi

    # Get config external port from environment (default to 5003)
    ensure_config_service_accessible
    local CONFIG_PORT="${CIS_CONFIG_EXTERNAL_PORT:-5003}"
    local CONFIG_URL="${CONFIG_URL:-http://localhost:${CONFIG_PORT}}"

    print_info "Updating configuration at ${CONFIG_URL}..."

    # Send JSON to API with Bearer authentication using PUT method
    local response=$(curl -s -w '\n%{http_code}' \
        -X PUT \
        -H "Authorization: Bearer $BITO_API_KEY" \
        -H "Content-Type: application/json" \
        -d "$json_data" \
        "${CONFIG_URL}/api/v1/config" 2>&1)

    # Extract HTTP code from last line (silently to prevent leakage to stdout)
    local http_code=$(echo "$response" | tail -1 2>/dev/null)
    local body=$(echo "$response" | sed '$d' 2>/dev/null)
    
    # Use render functions for output
    if [ "$http_code" -ge 200 ] && [ "$http_code" -lt 300 ]; then
        # Backup successfully applied configuration
        backup_config_file "$yaml_file" "repo-config" >/dev/null 2>&1 || true
        
        render_config_add_success_block "$body" "$show_raw"
        _persist_workspace_id_from_response "$body"
        render_config_add_next_steps
        return 0
    else
        render_config_add_failure_block "$http_code" "$body"
        return 1
    fi
}


# Validate repository configuration
config_repo_validate() {
    local repo_name="$1"
    
    if [ -z "$repo_name" ]; then
        print_error "Usage: ${YELLOW}bitoarch validate-repo <repo-name>${NC}"
        return 1
    fi
    
    print_info "Validating configuration for '$repo_name'..."
    
    # Make API call
    local response=$(config_api_call "POST" "/api/v1/config/repositories/${repo_name}/validate")
    if [ $? -ne 0 ]; then
        return 1
    fi
    
    # Parse validation result
    if require_command jq; then
        local valid=$(echo "$response" | jq -r '.valid // false')
        if [ "$valid" = "true" ]; then
            print_success "Configuration is valid"
        else
            print_error "Configuration validation failed"
            echo "$response" | jq -r '.errors[] | "  • \(.)"'
            return 1
        fi
    else
        echo "$response"
    fi
}

# Add repositories from YAML file (generic YAML to JSON conversion)
config_repo_add_from_file() {
    local yaml_file=""
    local show_raw=false

    # Parse options
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --help|-h)
                yaml_file="--help"
                shift
                ;;
            --raw)
                show_raw=true
                shift
                ;;
            *)
                if [ -z "$yaml_file" ] || [ "$yaml_file" = "--help" ]; then
                    yaml_file="$1"
                fi
                shift
                ;;
        esac
    done

    if [ "$yaml_file" = "--help" ]; then
        cat << 'EOF'
USAGE:
  bitoarch add-repos [yaml-file]

DESCRIPTION:
  Configure AI Architect with repository settings from a YAML file.
  If no file is specified, uses the default config file location.
  The entire YAML file is converted to JSON and sent to the Config API.
  Environment variables in the YAML file (${VARIABLE}) are automatically replaced.

YAML FILE FORMAT:
  repository:
    configured_repos:
      - namespace: "your-org/your-repo"
      - namespace: "another-org/another-repo"

ENV PROPERTIES:
  - Update git properties from env file
  - Update llm properties from llm config env file

EXAMPLES:
  bitoarch add-repos                              # Uses default config location
  bitoarch add-repos /path/to/custom-config.yaml  # Use custom path if needed

NOTES:
  - File path is optional - defaults to standard config location
  - Entire YAML file is converted to JSON generically (no field-specific code)
  - Environment variables are automatically substituted from .env-bitoarch
  - API accepts JSON with Content-Type: application/json
  - Requires 'jq' and 'yq' (or python3 with PyYAML) for parsing
EOF
        return 0
    fi

    # If no file specified, use default from path-manager
    if [ -z "$yaml_file" ]; then
        if type get_repo_config_file >/dev/null 2>&1; then
            yaml_file=$(get_repo_config_file)
            log_silent "Using default config file: $yaml_file"
        else
            print_error "Cannot determine default config file location"
            print_info "Please specify the config file path explicitly"
            return 1
        fi
    fi

    # Validate file exists and is readable
    if [ ! -f "$yaml_file" ]; then
        print_error "Config file not found: $yaml_file"
        print_info "Please create the configuration file or specify a valid path"
        return 1
    fi

    if [ ! -r "$yaml_file" ]; then
        print_error "Cannot read config file: $yaml_file"
        print_info "Check file permissions"
        return 1
    fi

#    Verify we have jq for JSON processing
#    if ! require_command jq; then
#        print_error "jq is required for this operation"
#        print_info "Install jq: brew install jq (macOS) or apt-get install jq (Ubuntu)"
#        return 1
#    fi

    local json_data
#    json_data=$(build_cis_config_json  "$yaml_file")

    # ---- ENV validation --------------------------------------------------
    if [ -z "$BITO_API_KEY" ]; then
        print_error "BITO_API_KEY missing in environment"
        return 1
    fi

    # ---- Git integration JSON -------------------------------------------
    local git_json
    git_json=$(_build_json_field create_git_integration_json '.integration.git') || {
        print_error "Failed generating Git integration JSON"; return 1
    }

    # ---- LLM integration JSON -------------------------------------------
    local llm_json
    llm_json=$(_build_json_field create_llm_integration_json '.llm') || {
        print_error "Failed generating LLM provider JSON"; return 1
    }

    # ---- Scheduler config JSON ------------------------------------------
    local scheduler_json
    scheduler_json=$(create_scheduler_config_json)

    # ---- Extract configured repos ---------------------------------------
    local repos_json

    # Validate shape (syntax + .repository is map + configured_repos is seq/null).
    # Helper handles both yq and python3 internally so the two engines can't drift.
    if ! _validate_repos_yaml_shape "$yaml_file"; then
        return 1
    fi

    # Extract — engine choice is independent of validation above.
    if command -v yq >/dev/null 2>&1; then
        repos_json=$(yq -o=json '.repository.configured_repos // []' "$yaml_file")
    elif command -v python3 >/dev/null 2>&1 && python3 -c "import yaml" 2>/dev/null; then
        repos_json=$(python3 -c "import yaml, json, sys; data=yaml.safe_load(open(sys.argv[1])); print(json.dumps(data.get('repository', {}).get('configured_repos', [])))" "$yaml_file" 2>/dev/null)
    else
        print_error "YAML processing tool not found"
        print_error "Please install either:"
        print_info "  • yq: https://github.com/mikefarah/yq#install"
        print_info "  • python3 with PyYAML: pip3 install PyYAML"
        return 1
    fi

    if [ -z "$repos_json" ] || [ "$repos_json" = "null" ]; then
        print_error "Failed reading repository.configured_repos from $yaml_file. Run: bitoarch config edit repos"
        log_silent "config parse: extraction returned empty/null for $yaml_file (likely BOM/CRLF or a non-map repository value)"
        return 1
    fi

    # Normalize: convert plain string → {"namespace": "..."}
    repos_json=$(echo "$repos_json" | jq '
        map(
            if type=="string" then { "namespace": . }
            else .
            end
        )
    ')

    # ---- Build final JSON payload ----------------------------------------
    local repository_json
    repository_json=$(create_repository_config_json "$repos_json")

    local json_data
    if [ -n "$scheduler_json" ] && [ "$scheduler_json" != "null" ]; then
        json_data=$(jq -n \
            --arg access "$BITO_API_KEY" \
            --argjson git "$git_json" \
            --argjson llm "$llm_json" \
            --argjson repository "$repository_json" \
            --argjson scheduler "$scheduler_json" \
            '
            {
                bito_access_key: $access,
                integration: { git: $git },
                repository: $repository,
                llm: $llm,
                scheduler: $scheduler
            }
            '
        )
    else
        json_data=$(jq -n \
            --arg access "$BITO_API_KEY" \
            --argjson git "$git_json" \
            --argjson llm "$llm_json" \
            --argjson repository "$repository_json" \
            '
            {
                bito_access_key: $access,
                integration: { git: $git },
                repository: $repository,
                llm: $llm
            }
            '
        )
    fi

    if [ $? -ne 0 ] || [ -z "$json_data" ]; then
        print_error "Failed to build repository configuration JSON"
        return 1
    fi

    # ---- Merge insights config into the payload -------------
    # Include ticket-tracker, docs, and tuning in the same atomic POST so
    # there is no race between the base row insert and the insights PUTs.
    json_data=$(_merge_insights_into_config "$json_data")
    if [ -z "$json_data" ]; then
        print_error "Failed merging insights config into payload"
        return 1
    fi

    ensure_config_service_accessible
    local CONFIG_PORT="${CIS_CONFIG_EXTERNAL_PORT:-5003}"
    local CONFIG_URL="${CONFIG_URL:-http://localhost:${CONFIG_PORT}}"

    log_silent "Sending configuration to ${CONFIG_URL}..."

    # Send JSON to API with Bearer authentication
    local response=$(curl -s -w '\n%{http_code}' \
        -X POST \
        -H "Authorization: Bearer $BITO_API_KEY" \
        -H "Content-Type: application/json" \
        -d "$json_data" \
        "${CONFIG_URL}/api/v1/config" 2>&1)

    # Extract HTTP code from last line
    local http_code=$(echo "$response" | tail -1)
    local body=$(echo "$response" | sed '$d')

    # Use render functions for output
    if [ "$http_code" -ge 200 ] && [ "$http_code" -lt 300 ]; then
        # Backup successfully applied configuration
        backup_config_file "$yaml_file" "repo-config" >/dev/null 2>&1 || true

        render_config_add_success_block "$body" "$show_raw"
        _persist_workspace_id_from_response "$body"

        _config_post_add_repos_sync

        render_config_add_next_steps
        return 0
    else
        render_config_add_failure_block "$http_code" "$body"
        return 1
    fi
}

# Add repositories from YAML file (generic YAML to JSON conversion)
config_repo_add_from_file_from_setup() {
    local yaml_file=""
    local show_raw=false
    
    # Parse options
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --help|-h)
                yaml_file="--help"
                shift
                ;;
            --raw)
                show_raw=true
                shift
                ;;
            *)
                if [ -z "$yaml_file" ] || [ "$yaml_file" = "--help" ]; then
                    yaml_file="$1"
                fi
                shift
                ;;
        esac
    done
    
    # If the filename is just the default name, resolve it using path-manager
    if [ "$yaml_file" = ".bitoarch-config.yaml" ]; then
        # Source path-manager if not already loaded
        if ! type get_repo_config_file >/dev/null 2>&1; then
            if [ -n "$SCRIPT_DIR" ]; then
                source "${SCRIPT_DIR}/scripts/lib/path-manager.sh" 2>/dev/null || true
            else
                source "$(dirname "${BASH_SOURCE[0]}")/../path-manager.sh" 2>/dev/null || true
            fi
        fi
        
        if type get_repo_config_file >/dev/null 2>&1; then
            yaml_file=$(get_repo_config_file)
            log_silent "Resolved config file to: $yaml_file"
        fi
    fi
    
    if [ "$yaml_file" = "--help" ] || [ -z "$yaml_file" ]; then
        cat << 'EOF'
USAGE:
  bitoarch add-repos <yaml-file>

DESCRIPTION:
  Configure AI Architect with repository settings from a YAML file.
  The entire YAML file is converted to JSON and sent to the Config API.
  Environment variables in the YAML file (${VARIABLE}) are automatically replaced.

YAML FILE FORMAT:
  repository:
    configured_repos:
      - namespace: "your-org/your-repo"
      - namespace: "another-org/another-repo"

ENV PROPERTIES:
  - Update git properties from env file
  - Update llm propertied from llm config env file

EXAMPLES:
  bitoarch add-repos                              # Uses default config location
  bitoarch add-repos /path/to/custom-config.yaml  # Use custom path if needed

NOTES:
  - Entire YAML file is converted to JSON generically (no field-specific code)
  - Environment variables are automatically substituted from .env-bitoarch
  - API accepts JSON with Content-Type: application/json
  - Requires 'jq' and 'yq' (or python3 with PyYAML) for parsing
  - See .bitoarch-config.yaml for complete example
EOF
        return 0
    fi
    
    if [ ! -f "$yaml_file" ]; then
        print_error "YAML file not found: $yaml_file"
        return 1
    fi
    
#    Verify we have jq for JSON processing
#    if ! require_command jq; then
#        print_error "jq is required for this operation"
#        print_info "Install jq: brew install jq (macOS) or apt-get install jq (Ubuntu)"
#        return 1
#    fi
    
    local json_data
#    json_data=$(build_cis_config_json  "$yaml_file")

    # ---- ENV validation --------------------------------------------------
    if [ -z "$BITO_API_KEY" ]; then
        log_silent "BITO_API_KEY missing in environment"
        return 1
    fi

    # ---- Git integration JSON -------------------------------------------
    local git_json
    git_json=$(_build_json_field create_git_integration_json '.integration.git') || {
        log_silent "Failed generating Git integration JSON"; return 1
    }

    # ---- LLM integration JSON -------------------------------------------
    local llm_json
    llm_json=$(_build_json_field create_llm_integration_json '.llm') || {
        log_silent "Failed generating LLM provider JSON"; return 1
    }

    # ---- Scheduler config JSON ------------------------------------------
    local scheduler_json
    scheduler_json=$(create_scheduler_config_json)

    # ---- Extract configured repos ---------------------------------------
    local repos_json

    # Try yq first, fallback to python if not available
    if command -v yq >/dev/null 2>&1; then
        repos_json=$(yq -o=json '.repository.configured_repos // []' "$yaml_file")
    elif command -v python3 >/dev/null 2>&1 && python3 -c "import yaml" 2>/dev/null; then
        repos_json=$(python3 -c "import yaml, json, sys; data=yaml.safe_load(open(sys.argv[1])); print(json.dumps(data.get('repository', {}).get('configured_repos', [])))" "$yaml_file" 2>/dev/null)
    else
        log_silent "YAML processing tool not found - need yq or python3+PyYAML"
        return 1
    fi

    if [ -z "$repos_json" ] || [ "$repos_json" = "null" ]; then
        log_silent "Failed reading repository.configured_repos from $yaml_file"
        return 1
    fi

    # Normalize: convert plain string → {"namespace": "..."}
    repos_json=$(echo "$repos_json" | jq '
        map(
            if type=="string" then { "namespace": . }
            else .
            end
        )
    ')
    log_silent "Configured repo details: $repos_json"

    # ---- Build final JSON payload ----------------------------------------
    local repository_json
    repository_json=$(create_repository_config_json "$repos_json")

    local json_data
    if [ -n "$scheduler_json" ] && [ "$scheduler_json" != "null" ]; then
        json_data=$(jq -n \
            --arg access "$BITO_API_KEY" \
            --argjson git "$git_json" \
            --argjson llm "$llm_json" \
            --argjson repository "$repository_json" \
            --argjson scheduler "$scheduler_json" \
            '
            {
                bito_access_key: $access,
                integration: { git: $git },
                repository: $repository,
                llm: $llm,
                scheduler: $scheduler
            }
            '
        )
    else
        json_data=$(jq -n \
            --arg access "$BITO_API_KEY" \
            --argjson git "$git_json" \
            --argjson llm "$llm_json" \
            --argjson repository "$repository_json" \
            '
            {
                bito_access_key: $access,
                integration: { git: $git },
                repository: $repository,
                llm: $llm
            }
            '
        )
    fi

    if [ $? -ne 0 ] || [ -z "$json_data" ]; then
        log_silent "Failed to build repository configuration JSON"
        return 1
    fi

    # Merge insights sub-objects so a full POST/PUT doesn't wipe them.
    json_data=$(_merge_insights_into_config "$json_data")
    if [ -z "$json_data" ]; then
        log_silent "Failed merging insights config into payload"
        return 1
    fi

    ensure_config_service_accessible
    local CONFIG_PORT="${CIS_CONFIG_EXTERNAL_PORT:-5003}"
    local CONFIG_URL="${CONFIG_URL:-http://localhost:${CONFIG_PORT}}"

    log_silent "Sending configuration to ${CONFIG_URL}..."

    # Try POST first (for initial setup)
    local response=$(curl -s -w '\n%{http_code}' \
        -X POST \
        -H "Authorization: Bearer $BITO_API_KEY" \
        -H "Content-Type: application/json" \
        -d "$json_data" \
        "${CONFIG_URL}/api/v1/config" 2>&1)
    
    # Extract HTTP code from last line
    local http_code=$(echo "$response" | tail -1)
    local body=$(echo "$response" | sed '$d')
    
    # If config already exists (HTTP 500), retry with PUT (update)
    if [ "$http_code" = "500" ] && echo "$body" | grep -qi "config already exists"; then
        log_silent "Config exists, retrying with PUT (update) method..."
        
        response=$(curl -s -w '\n%{http_code}' \
            -X PUT \
            -H "Authorization: Bearer $BITO_API_KEY" \
            -H "Content-Type: application/json" \
            -d "$json_data" \
            "${CONFIG_URL}/api/v1/config" 2>&1)
        
        # Extract HTTP code from last line
        http_code=$(echo "$response" | tail -1)
        body=$(echo "$response" | sed '$d')
    fi

    log_silent "Configuration sent to ${CONFIG_URL} with HTTP $http_code"
    
    # Use render functions for output
    if [ "$http_code" -ge 200 ] && [ "$http_code" -lt 300 ]; then
        # Backup successfully applied configuration. Redirect stdout too --
        # backup_config_file echoes the path for callers that capture it; this
        # caller doesn't, so the bare stdout would leak the backup path into
        # the user-facing output.
        if command -v backup_config_file >/dev/null 2>&1; then
            backup_config_file "$yaml_file" "repo-config" >/dev/null 2>&1 || log_silent "Warning: Backup failed"
            log_silent "Configuration backup attempted"
        fi
        
        render_config_add_success_block "$body" "$show_raw"
        _persist_workspace_id_from_response "$body"
        return 0
    else
        render_config_add_failure_block "$http_code" "$body"
        return 1
    fi
}

# Add single repository by namespace
config_repo_add_namespace() {
    local namespace="$1"
    
    # Parse options
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --help|-h)
                cat << 'EOF'
USAGE:
  bitoarch add-repo <namespace>

DESCRIPTION:
  Add a single repository to the configured repositories list.
  Uses the API endpoint to add the repository by namespace and updates the local .bitoarch-config.yaml file.

ARGUMENTS:
  namespace    Repository namespace, e.g. org/repo or group/subgroup/repo (GitLab nested subgroups supported)

EXAMPLE:
  bitoarch add-repo myorg/myrepo
  bitoarch add-repo mygroup/mysubgroup/myrepo

NOTES:
  - Requires BITO_API_KEY to be set in environment
  - Repository will be added to existing configuration
  - Updates both API and local .bitoarch-config.yaml file
  - Use 'bitoarch show-config' to verify changes
EOF
                return 0
                ;;
            *)
                namespace="$1"
                shift
                ;;
        esac
    done
    
    if [ -z "$namespace" ]; then
        print_error "Usage: ${YELLOW}bitoarch add-repo <namespace>${NC}"
        echo ""
        echo -e "Example: ${YELLOW}bitoarch add-repo myorg/myrepo${NC}"
        return 1
    fi
    
    # Validate namespace format
    if ! _is_valid_repo_namespace "$namespace"; then
        print_error "Invalid namespace format. Expected: org/repo (GitLab subgroups: group/subgroup/repo)"
        echo ""
        echo "Example: myorg/myrepo  or  mygroup/mysubgroup/myrepo"
        return 1
    fi
    
    # Get required environment variables
    if [ -z "$BITO_API_KEY" ]; then
        print_error "BITO_API_KEY not found in environment"
        return 1
    fi
    
    # Get config external port from environment (default to 5003 which maps to internal 9910)
    ensure_config_service_accessible
    local CONFIG_PORT="${CIS_CONFIG_EXTERNAL_PORT:-5003}"
    local CONFIG_URL="${CONFIG_URL:-http://localhost:${CONFIG_PORT}}"
    
    print_info "Adding repository '${namespace}'..."
    
    # Create JSON payload
    local json_payload=$(jq -n \
        --arg ns "$namespace" \
        '{repositories: [{namespace: $ns}]}')
    
    # Make API call (uses raw token without Bearer prefix)
    local response=$(curl -s -w '\n%{http_code}' \
        -X POST \
        -H "accept: application/json" \
        -H "Content-Type: application/json" \
        -H "Authorization: ${BITO_API_KEY}" \
        -d "$json_payload" \
        "${CONFIG_URL}/api/v1/config/repository/add" 2>&1)
    
    # Extract HTTP code from last line
    local http_code=$(echo "$response" | tail -1)
    local body=$(echo "$response" | sed '$d')
    
    # Check HTTP code and render appropriate output
    if [ "$http_code" -ge 200 ] && [ "$http_code" -lt 300 ]; then
        # API call succeeded, now update local .bitoarch-config.yaml 
        # Source path-manager if not already loaded
        if ! type get_repo_config_file >/dev/null 2>&1; then
            source "${SCRIPT_DIR}/scripts/lib/path-manager.sh" 2>/dev/null || true
        fi
        
        local config_file
        if type get_repo_config_file >/dev/null 2>&1; then
            config_file=$(get_repo_config_file)
        else
            config_file=".bitoarch-config.yaml"
        fi
        
        if [ -f "$config_file" ]; then
            print_info "Updating local .bitoarch-config.yaml file..."
            
            # Check if namespace already exists in .bitoarch-config.yaml 
            local exists=false
            if command -v yq >/dev/null 2>&1; then
                if yq eval ".repository.configured_repos[] | select(.namespace == \"${namespace}\")" "$config_file" 2>/dev/null | grep -q "namespace"; then
                    exists=true
                fi
            elif command -v python3 >/dev/null 2>&1; then
                if python3 -c "import yaml; data=yaml.safe_load(open('$config_file')); print(any(r.get('namespace') == '$namespace' for r in data.get('repository', {}).get('configured_repos', [])))" 2>/dev/null | grep -q "True"; then
                    exists=true
                fi
            fi
            
            if [ "$exists" = "false" ]; then
                # Backup config file before modification
                backup_config_file "$config_file" "repo-config" >/dev/null 2>&1 || true
                
                # Add namespace to .bitoarch-config.yaml 
                if command -v yq >/dev/null 2>&1; then
                    # Use yq to add the namespace
                    yq eval ".repository.configured_repos += [{\"namespace\": \"${namespace}\"}]" -i "$config_file" 2>/dev/null
                    if [ $? -eq 0 ]; then
                        print_success "Updated .bitoarch-config.yaml with new repository"
                    else
                        print_warning "API call succeeded but failed to update .bitoarch-config.yaml automatically"
                        print_info "Please manually add '- namespace: ${namespace}' to .bitoarch-config.yaml "
                    fi
                elif command -v python3 >/dev/null 2>&1; then
                    # Use python to add the namespace
                    python3 << EOF
import yaml
try:
    with open('$config_file', 'r') as f:
        data = yaml.safe_load(f)
    
    if 'repository' not in data:
        data['repository'] = {}
    if 'configured_repos' not in data['repository']:
        data['repository']['configured_repos'] = []
    
    data['repository']['configured_repos'].append({'namespace': '$namespace'})
    
    with open('$config_file', 'w') as f:
        yaml.dump(data, f, default_flow_style=False, sort_keys=False)
    
    print("SUCCESS")
except Exception as e:
    print(f"ERROR: {e}")
EOF
                    if [ $? -eq 0 ]; then
                        print_success "Updated .bitoarch-config.yaml with new repository"
                    else
                        print_warning "API call succeeded but failed to update .bitoarch-config.yaml automatically"
                        print_info "Please manually add '- namespace: ${namespace}' to .bitoarch-config.yaml "
                    fi
                else
                    print_warning "yq or python3 not available - .bitoarch-config.yaml not updated"
                    print_info "Please manually add '- namespace: ${namespace}' to .bitoarch-config.yaml under repository.configured_repos"
                fi
            else
                print_info "Repository already exists in .bitoarch-config.yaml "
            fi
        else
            print_warning ".bitoarch-config.yaml not found - only API updated"
            print_info "Repository added to API but .bitoarch-config.yaml not found for local update"
        fi
        
        render_repo_add_success_block "$namespace" "$body"
        _persist_workspace_id_from_response "$body"
        return 0
    else
        render_repo_add_failure_block "$namespace" "$http_code" "$body"
        return 1
    fi
}

# Remove repository by namespace
config_repo_remove_namespace() {
    local namespace="$1"
    
    # Parse options
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --help|-h)
                cat << 'EOF'
USAGE:
  bitoarch remove-repo <namespace>

DESCRIPTION:
  Remove a repository from the configured repositories list.
  Uses the API endpoint to remove the repository by namespace and updates the local .bitoarch-config.yaml file.

ARGUMENTS:
  namespace    Repository namespace, e.g. org/repo or group/subgroup/repo (GitLab nested subgroups supported)

EXAMPLE:
  bitoarch remove-repo myorg/myrepo
  bitoarch remove-repo mygroup/mysubgroup/myrepo

NOTES:
  - Requires BITO_API_KEY to be set in environment
  - Repository will be removed from configuration
  - Updates both API and local .bitoarch-config.yaml file
  - Use 'bitoarch show-config' to verify changes
EOF
                return 0
                ;;
            *)
                namespace="$1"
                shift
                ;;
        esac
    done
    
    if [ -z "$namespace" ]; then
        print_error "Usage: ${YELLOW}bitoarch remove-repo <namespace>${NC}"
        echo ""
        echo -e "Example: ${YELLOW}bitoarch remove-repo myorg/myrepo${NC}"
        return 1
    fi
    
    # Validate namespace format
    if ! _is_valid_repo_namespace "$namespace"; then
        print_error "Invalid namespace format. Expected: org/repo (GitLab subgroups: group/subgroup/repo)"
        echo ""
        echo "Example: myorg/myrepo  or  mygroup/mysubgroup/myrepo"
        return 1
    fi
    
    # Get required environment variables
    if [ -z "$BITO_API_KEY" ]; then
        print_error "BITO_API_KEY not found in environment"
        return 1
    fi
    
    # Get config external port from environment (default to 5003 which maps to internal 9910)
    ensure_config_service_accessible
    local CONFIG_PORT="${CIS_CONFIG_EXTERNAL_PORT:-5003}"
    local CONFIG_URL="${CONFIG_URL:-http://localhost:${CONFIG_PORT}}"
    
    print_info "Removing repository '${namespace}'..."
    
    # Create JSON payload
    local json_payload=$(jq -n \
        --arg ns "$namespace" \
        '{repositories: [{namespace: $ns}]}')
    
    # Make API call (uses raw token without Bearer prefix)
    local response=$(curl -s -w '\n%{http_code}' \
        -X POST \
        -H "accept: application/json" \
        -H "Content-Type: application/json" \
        -H "Authorization: ${BITO_API_KEY}" \
        -d "$json_payload" \
        "${CONFIG_URL}/api/v1/config/repository/remove" 2>&1)
    
    # Extract HTTP code from last line
    local http_code=$(echo "$response" | tail -1)
    local body=$(echo "$response" | sed '$d')
    
    # Check HTTP code and render appropriate output
    if [ "$http_code" -ge 200 ] && [ "$http_code" -lt 300 ]; then
        # API call succeeded, now update local .bitoarch-config.yaml 
        # Source path-manager if not already loaded
        if ! type get_repo_config_file >/dev/null 2>&1; then
            source "${SCRIPT_DIR}/scripts/lib/path-manager.sh" 2>/dev/null || true
        fi
        
        local config_file
        if type get_repo_config_file >/dev/null 2>&1; then
            config_file=$(get_repo_config_file)
        else
            config_file=".bitoarch-config.yaml"
        fi
        
        if [ -f "$config_file" ]; then
            print_info "Updating local .bitoarch-config.yaml file..."
            
            # Check if namespace exists in .bitoarch-config.yaml 
            local exists=false
            if command -v yq >/dev/null 2>&1; then
                if yq eval ".repository.configured_repos[] | select(.namespace == \"${namespace}\")" "$config_file" 2>/dev/null | grep -q "namespace"; then
                    exists=true
                fi
            elif command -v python3 >/dev/null 2>&1; then
                if python3 -c "import yaml; data=yaml.safe_load(open('$config_file')); print(any(r.get('namespace') == '$namespace' for r in data.get('repository', {}).get('configured_repos', [])))" 2>/dev/null | grep -q "True"; then
                    exists=true
                fi
            fi
            
            if [ "$exists" = "true" ]; then
                # Backup config file before modification
                backup_config_file "$config_file" "repo-config" >/dev/null 2>&1 || true
                
                # Remove namespace from .bitoarch-config.yaml 
                if command -v yq >/dev/null 2>&1; then
                    # Use yq to remove the namespace
                    yq eval "del(.repository.configured_repos[] | select(.namespace == \"${namespace}\"))" -i "$config_file" 2>/dev/null
                    if [ $? -eq 0 ]; then
                        print_success "Updated .bitoarch-config.yaml - removed repository"
                    else
                        print_warning "API call succeeded but failed to update .bitoarch-config.yaml automatically"
                        print_info "Please manually remove '- namespace: ${namespace}' from .bitoarch-config.yaml "
                    fi
                elif command -v python3 >/dev/null 2>&1; then
                    # Use python to remove the namespace
                    python3 << EOF
import yaml
try:
    with open('$config_file', 'r') as f:
        data = yaml.safe_load(f)
    
    if 'repository' in data and 'configured_repos' in data['repository']:
        data['repository']['configured_repos'] = [
            r for r in data['repository']['configured_repos']
            if r.get('namespace') != '$namespace'
        ]
    
    with open('$config_file', 'w') as f:
        yaml.dump(data, f, default_flow_style=False, sort_keys=False)
    
    print("SUCCESS")
except Exception as e:
    print(f"ERROR: {e}")
EOF
                    if [ $? -eq 0 ]; then
                        print_success "Updated .bitoarch-config.yaml - removed repository"
                    else
                        print_warning "API call succeeded but failed to update .bitoarch-config.yaml automatically"
                        print_info "Please manually remove '- namespace: ${namespace}' from .bitoarch-config.yaml "
                    fi
                else
                    print_warning "yq or python3 not available - .bitoarch-config.yaml not updated"
                    print_info "Please manually remove '- namespace: ${namespace}' from .bitoarch-config.yaml under repository.configured_repos"
                fi
            else
                print_info "Repository not found in .bitoarch-config.yaml "
            fi
        else
            print_warning ".bitoarch-config.yaml not found - only API updated"
            print_info "Repository removed from API but .bitoarch-config.yaml not found for local update"
        fi
        
        render_repo_remove_success_block "$namespace" "$body"
        _persist_workspace_id_from_response "$body"
        return 0
    else
        render_repo_remove_failure_block "$namespace" "$http_code" "$body"
        return 1
    fi
}

build_cis_config_json() {
    local yaml_file="$1"

    # ---- ENV validation --------------------------------------------------
    if [ -z "$BITO_API_KEY" ]; then
        log_silent "BITO_API_KEY missing in environment"
        return 1
    fi

    # ---- Git integration JSON -------------------------------------------
    local git_json
    git_json=$(_build_json_field create_git_integration_json '.integration.git') || {
        log_silent "Failed generating Git integration JSON"; return 1
    }

    # ---- LLM integration JSON -------------------------------------------
    local llm_json
    llm_json=$(_build_json_field create_llm_integration_json '.llm') || {
        log_silent "Failed generating LLM provider JSON"; return 1
    }

    # ---- Scheduler config JSON ------------------------------------------
    local scheduler_json
    scheduler_json=$(create_scheduler_config_json)

    # ---- Extract configured repos ---------------------------------------
    local repos_json

    # Try yq first, fallback to python if not available
    if command -v yq >/dev/null 2>&1; then
        repos_json=$(yq -o=json '.repository.configured_repos // []' "$yaml_file")
    elif command -v python3 >/dev/null 2>&1 && python3 -c "import yaml" 2>/dev/null; then
        repos_json=$(python3 -c "import yaml, json, sys; data=yaml.safe_load(open(sys.argv[1])); print(json.dumps(data.get('repository', {}).get('configured_repos', [])))" "$yaml_file" 2>/dev/null)
    else
        log_silent "YAML processing tool not found - need yq or python3+PyYAML"
        return 1
    fi

    if [ -z "$repos_json" ] || [ "$repos_json" = "null" ]; then
        log_silent "Failed reading repository.configured_repos from $yaml_file"
        return 1
    fi

    # Normalize: convert plain string → {"namespace": "..."}
    repos_json=$(echo "$repos_json" | jq '
        map(
            if type=="string" then { "namespace": . }
            else .
            end
        )
    ')
    log_silent "Configured repo details: $repos_json"

    # ---- Build final JSON payload ----------------------------------------
    local repository_json
    repository_json=$(create_repository_config_json "$repos_json")

    local final_json
    if [ -n "$scheduler_json" ] && [ "$scheduler_json" != "null" ]; then
        final_json=$(jq -n \
                --arg access "$BITO_API_KEY" \
                --argjson git "$git_json" \
                --argjson llm "$llm_json" \
                --argjson repository "$repository_json" \
                --argjson scheduler "$scheduler_json" \
                '
                {
                    bito_access_key: $access,
                    integration: { git: $git },
                    repository: $repository,
                    llm: $llm,
                    scheduler: $scheduler
                }
                '
        )
    else
        final_json=$(jq -n \
                --arg access "$BITO_API_KEY" \
                --argjson git "$git_json" \
                --argjson llm "$llm_json" \
                --argjson repository "$repository_json" \
                '
                {
                    bito_access_key: $access,
                    integration: { git: $git },
                    repository: $repository,
                    llm: $llm
                }
                '
        )
    fi

    echo "$final_json"
}

# Utility function to create Git integration JSON from environment variables
create_git_integration_json() {
    # Get Git configuration from environment variables
    local git_provider="${GIT_PROVIDER:-}"
    local git_token="${GIT_ACCESS_TOKEN:-}"
    local git_domain="${GIT_DOMAIN_URL:-}"
    local git_user="${GIT_USER:-}"
    local git_azure_org="${GIT_AZURE_ORG:-}"
    # auth_type is additive; empty/absent means personal_access_token (back-compat).
    local git_auth_type="${GIT_AUTH_TYPE:-personal_access_token}"
    [ -z "$git_auth_type" ] && git_auth_type="personal_access_token"

    # Validate required environment variables
    if [ -z "$git_provider" ]; then
        print_error "GIT_PROVIDER not found in environment"
        return 1
    fi

    if [ "$git_auth_type" = "app" ]; then
        # ── GitHub App auth ──────────────────────────────────────────────────
        # Emit an "app" block (the cis-config App-auth config contract) instead of an
        # access_token; domain lives once at git.domain (no per-installation domain).
        # cis-config stores the PEM encrypted and mints tokens per request.
        local git_app_id="${GIT_APP_ID:-}"
        local git_installation_id="${GIT_INSTALLATION_ID:-}"
        local git_app_key_b64="${GIT_APP_PRIVATE_KEY_B64:-}"

        if [ -z "$git_app_id" ] || [ -z "$git_installation_id" ]; then
            print_error "GitHub App auth requires GIT_APP_ID and GIT_INSTALLATION_ID"
            return 1
        fi

        # Decode the single-line base64 back to the multi-line PEM. openssl handles
        # this portably (GNU base64 uses -d, BSD/macOS -D); openssl is already a hard
        # dependency of App auth (JWT signing at setup). An empty value is allowed only
        # on a rotation that keeps the stored key: private_key is then omitted so
        # cis-config preserves the encrypted key it already holds.
        local git_app_key=""
        if [ -n "$git_app_key_b64" ]; then
            git_app_key=$(printf '%s' "$git_app_key_b64" | openssl base64 -d -A 2>/dev/null)
            if [ -z "$git_app_key" ]; then
                print_error "GIT_APP_PRIVATE_KEY_B64 is not valid base64"
                return 1
            fi
        fi

        local git_json
        if ! git_json=$(jq -n \
            --arg provider "$git_provider" \
            --arg auth_type "$git_auth_type" \
            --arg user "$git_user" \
            --arg organization "$git_azure_org" \
            --arg domain "$git_domain" \
            --arg app_id "$git_app_id" \
            --arg installation_id "$git_installation_id" \
            --arg private_key "$git_app_key" \
            '
            ( { app_id: $app_id, installations: [ { installation_id: $installation_id } ] }
                + (if $private_key != "" then { private_key: $private_key } else {} end) ) as $app
            | { integration: { git: (
                  { provider: $provider,
                    auth_type: $auth_type,
                    username: $user,
                    additional_property: $organization,
                    app: $app }
                  + (if $domain != "" then { domain: $domain } else {} end)
              ) } }
            '); then
            log_silent "Failed to create GitHub App integration JSON"
            return 1
        fi
        if [ -z "$git_json" ] || [ "$git_json" = "null" ]; then
            log_silent "Failed to create GitHub App integration JSON"
            return 1
        fi
        echo "$git_json"
        return 0
    fi

    # ── Personal Access Token auth (default; output unchanged) ───────────────
    if [ -z "$git_token" ]; then
        print_error "GIT_ACCESS_TOKEN not found in environment"
        return 1
    fi

    # Create JSON structure using jq
#    if ! require_command jq; then
#        print_error "jq is required for JSON creation"
#        print_info "Install jq: brew install jq (macOS) or apt-get install jq (Ubuntu)"
#        return 1
#    fi

    # Build the Git integration JSON
    local git_json
    if [ -n "$git_domain" ]; then
        # Include domain URL if provided
        git_json=$(jq -n \
            --arg provider "$git_provider" \
            --arg token "$git_token" \
            --arg domain "$git_domain" \
            --arg user "$git_user" \
            --arg organization "$git_azure_org" \
            --arg auth_type "$git_auth_type" \
            '{
                "integration": {
                    "git": {
                        "provider": $provider,
                        "access_token": $token,
                        "domain": $domain,
                        "auth_type": $auth_type,
                        "username": $user,
                        "additional_property": $organization
                    }
                }
            }')
    else
        # Standard structure without domain URL
        git_json=$(jq -n \
            --arg provider "$git_provider" \
            --arg token "$git_token" \
            --arg user "$git_user" \
            --arg organization "$git_azure_org" \
            --arg auth_type "$git_auth_type" \
            '{
                "integration": {
                    "git": {
                        "provider": $provider,
                        "access_token": $token,
                        "auth_type": $auth_type,
                        "username": $user,
                        "additional_property": $organization
                    }
                }
            }')
    fi

    # Validate JSON creation
    if [ $? -ne 0 ] || [ -z "$git_json" ] || [ "$git_json" = "null" ]; then
        log_silent "Failed to create Git integration JSON"
        return 1
    fi

    echo "$git_json"
}

# Builds one provider's payload object from its registry config fields, applying
# each field's post_process hook (validate + convert env -> payload). Echoes the
# JSON object; returns non-zero if a post_process rejects a value (skip provider).
# $2 emit_empty: when "1", empty optional fields are still emitted (the exclusive
# gateway always carries its api_url/model keys); otherwise an empty value is
# omitted so optional fields (e.g. Vertex model) defer to the workspace default.
_llm_build_provider_payload() {
    local id="$1" emit_empty="${2:-0}" env kind required config pre post prompt v obj="{}"
    while IFS=$'\x1f' read -r env kind required config pre post prompt; do
        [ -z "$config" ] && continue
        v="${!env:-}"
        if [ -n "$post" ]; then
            v=$("$post" "$v") || return 1
        fi
        [ -z "$v" ] && [ "$emit_empty" != "1" ] && continue
        obj=$(printf '%s' "$obj" | jq --arg v "$v" --arg path "$config" 'setpath($path | split("."); $v)')
    done < <(_llm_fields_tsv "$id")
    printf '%s' "$obj"
}

# Creates LLM integration JSON from environment variables (registry-driven).
# Reads LLM_DEFAULT_PROVIDER plus each provider's env keys and returns the
# { "llm": { provider_configured, providers } } structure for the cis-config PUT.
# Provider shape (top-level api_key vs `additional`), validation and the
# exclusive-gateway rule are all declared in llm-registry.sh.
create_llm_integration_json() {
    local default_provider="${LLM_DEFAULT_PROVIDER:-bito}"
    local providers_json="{}"
    local id primary env obj missing any

    # An exclusive gateway (e.g. Portkey) owns the providers object when its
    # primary key is set; direct providers are ignored (mirrors the interactive
    # and preset flows, which stop after the gateway).
    local exclusive_id=""
    while IFS= read -r id; do
        primary=$(_llm_primary "$id")
        if [ -n "${!primary:-}" ]; then exclusive_id="$id"; break; fi
    done < <(llm_registry | jq -r '.providers[] | select(.exclusive==true) | .id')

    if [ -n "$exclusive_id" ]; then
        obj=$(_llm_build_provider_payload "$exclusive_id" 1) || obj="{}"
        providers_json=$(printf '%s' "$obj" | jq --arg id "$exclusive_id" '{($id): .}')
    else
        while IFS= read -r id; do
            # Emit only when all required fields are present; warn-and-skip a
            # partial set (it would otherwise be silently dropped downstream).
            missing=0 any=0
            while IFS= read -r env; do
                if [ -n "${!env:-}" ]; then any=1; else missing=1; fi
            done < <(_llm_required_envs "$id")
            [ "$any" -eq 0 ] && continue
            if [ "$missing" -eq 1 ]; then
                log_silent "create_llm_integration_json: skipping ${id} (incomplete configuration)"
                continue
            fi
            if ! obj=$(_llm_build_provider_payload "$id" 0); then
                log_silent "create_llm_integration_json: skipping ${id} (invalid field value)"
                continue
            fi
            providers_json=$(printf '%s' "$providers_json" | jq --arg id "$id" --argjson o "$obj" '. + {($id): $o}')
        done < <(llm_registry | jq -r '.providers[] | select(.exclusive!=true) | .id')
    fi

    # Provider construction (incl. vertex-ai/azure-ai) is registry-driven via the
    # loop above (_llm_build_provider_payload + llm-registry.sh); validate the result.
    if ! printf '%s' "$providers_json" | jq empty 2>/dev/null; then
        log_silent "create_llm_integration_json: providers_json is invalid: $providers_json"
        providers_json="{}"
    fi

    # Per-component model overrides (LLM_PLUGIN_MODEL / LLM_AI_INDEX_MODEL). Each
    # maps to llm.components.<component>.model, a single model cis-config applies to
    # the configured provider. Only components the operator set are emitted; an
    # absent component falls back to cis-config's per-component default. The whole
    # "components" key is omitted when no per-component model is set.
    local components_json="{}"
    local _comp _cenv
    # model fields
    while IFS=' ' read -r _comp _cenv; do
        [ -n "$_comp" ] || continue
        if [ -n "${!_cenv:-}" ]; then
            components_json=$(printf '%s' "$components_json" | jq --arg c "$_comp" --arg v "${!_cenv}" '.[$c] = ((.[$c] // {}) + {"model": $v})')
        fi
    done < <(_llm_component_model_pairs)
    # provider fields
    while IFS=' ' read -r _comp _cenv; do
        [ -n "$_comp" ] || continue
        if [ -n "${!_cenv:-}" ]; then
            components_json=$(printf '%s' "$components_json" | jq --arg c "$_comp" --arg v "${!_cenv}" '.[$c] = ((.[$c] // {}) + {"provider": $v})')
        fi
    done < <(_llm_component_provider_pairs)

    local llm_json
    llm_json=$(jq -n \
        --arg default_provider "$default_provider" \
        --argjson providers "$providers_json" \
        --argjson components "$components_json" \
        '{
            "llm": (
                {
                    "provider_configured": $default_provider,
                    "providers": $providers
                }
                + (if ($components | length) > 0 then {"components": $components} else {} end)
            )
        }') || { log_silent "Failed to create LLM integration JSON"; return 1; }

    echo "$llm_json"
}

# =============================================================================
# Insights integrations (jira-git-on-prem)
# =============================================================================
# Builders return the request body for cis-config single-tenant routes.
# Orchestrators load env, build, and PUT to /api/v1/config/{ticket-tracker,docs}.
# Tokens are sent plaintext over the local docker network — cis-config encrypts
# at rest using its own SECRETS_ENCRYPTION_KEY (matches existing git PUT path).

# Build PUT body for /api/v1/config/ticket-tracker.
# Reads INSIGHTS_TICKET_TRACKER_* env. Project keys merged from .bitoarch-config.yaml.
# Returns empty + exit 0 when feature disabled. Exits 1 with print_error on missing required.
create_ticket_tracker_integration_json() {
    local enabled="${INSIGHTS_TICKET_TRACKER_ENABLED:-}"
    if [ "$enabled" != "true" ]; then
        return 0
    fi

    local provider="${INSIGHTS_TICKET_TRACKER_PROVIDER:-jira}"
    local base_url="${JIRA_DOMAIN:-}"
    local domain_url="${INSIGHTS_TICKET_TRACKER_DOMAIN_URL:-}"
    local email="${JIRA_EMAIL:-}"
    local token="${JIRA_API_TOKEN:-}"
    local host_type="${JIRA_HOST_TYPE:-cloud}"
    local cloud_id="${JIRA_CLOUD_ID:-}"
    local auth_type="${INSIGHTS_TICKET_TRACKER_AUTH_TYPE:-api-token}"

    if [ -z "$base_url" ]; then
        print_error "JIRA_DOMAIN is required when ticket tracker is enabled"
        return 1
    fi
    if [ -z "$email" ]; then
        print_error "JIRA_EMAIL is required when ticket tracker is enabled"
        return 1
    fi
    if [ -z "$token" ]; then
        print_error "JIRA_API_TOKEN is required when ticket tracker is enabled"
        return 1
    fi
    if [ "$host_type" = "cloud" ] && [ "$auth_type" != "api-token" ] && [ -z "$cloud_id" ]; then
        print_error "JIRA_CLOUD_ID is required for host_type=cloud with OAuth"
        return 1
    fi

    # Project keys: prefer .bitoarch-config.yaml (lets users edit + re-apply
    # without touching env), fall back to the comma-separated INSIGHTS_TICKET_-
    # TRACKER_PROJECT_KEYS env var (captured at install-prompt time so the very
    # first apply has values; lifecycle later flows through the yaml).
    local project_keys_json="[]"
    local cfg_file=""
    if type get_repo_config_file >/dev/null 2>&1; then
        cfg_file=$(get_repo_config_file 2>/dev/null)
    fi
    if [ -n "$cfg_file" ] && [ -f "$cfg_file" ]; then
        if command -v yq >/dev/null 2>&1; then
            project_keys_json=$(yq -o=json '.ticket_tracker.project_keys // []' "$cfg_file" 2>/dev/null)
        elif command -v python3 >/dev/null 2>&1 && python3 -c "import yaml" 2>/dev/null; then
            project_keys_json=$(python3 -c "import yaml,json,sys; d=yaml.safe_load(open(sys.argv[1])) or {}; print(json.dumps((d.get('ticket_tracker') or {}).get('project_keys') or []))" "$cfg_file" 2>/dev/null)
        fi
        [ -z "$project_keys_json" ] || [ "$project_keys_json" = "null" ] && project_keys_json="[]"
    fi

    # Env-var fallback when yaml had nothing (or no yaml exists yet).
    if [ "$project_keys_json" = "[]" ] && [ -n "${INSIGHTS_TICKET_TRACKER_PROJECT_KEYS:-}" ]; then
        project_keys_json=$(echo "$INSIGHTS_TICKET_TRACKER_PROJECT_KEYS" \
            | tr ',' '\n' \
            | awk 'NF{gsub(/^ +| +$/,""); print}' \
            | jq -R . | jq -s .)
        [ -z "$project_keys_json" ] || [ "$project_keys_json" = "null" ] && project_keys_json="[]"
    fi

    jq -n \
        --arg provider "$provider" \
        --arg base_url "$base_url" \
        --arg domain_url "$domain_url" \
        --arg email "$email" \
        --arg auth_type "$auth_type" \
        --arg host_type "$host_type" \
        --arg cloud_id "$cloud_id" \
        --arg access_token "$token" \
        --argjson project_keys "$project_keys_json" \
        '{
            enabled: true,
            provider: $provider,
            config: {
                base_url: $base_url,
                domain_url: $domain_url,
                email: $email,
                auth_type: $auth_type,
                host_type: $host_type,
                cloud_id: $cloud_id,
                access_token: $access_token,
                project_keys: $project_keys
            }
        }'
}

# Build PUT body for /api/v1/config/docs (Confluence).
# Reads INSIGHTS_DOCS_* env.
create_docs_integration_json() {
    local enabled="${INSIGHTS_DOCS_ENABLED:-}"
    if [ "$enabled" != "true" ]; then
        return 0
    fi

    local provider="${INSIGHTS_DOCS_PROVIDER:-confluence}"
    local url="${INSIGHTS_DOCS_URL:-}"
    local email="${INSIGHTS_DOCS_EMAIL:-}"
    local token="${INSIGHTS_DOCS_API_TOKEN:-}"
    local auth_type="${INSIGHTS_DOCS_AUTH_TYPE:-api-token}"
    local cloud_id="${INSIGHTS_DOCS_CLOUD_ID:-}"

    if [ -z "$url" ]; then
        print_error "INSIGHTS_DOCS_URL is required when docs is enabled"
        return 1
    fi
    if [ -z "$email" ]; then
        print_error "INSIGHTS_DOCS_EMAIL is required when docs is enabled"
        return 1
    fi
    if [ -z "$token" ]; then
        print_error "INSIGHTS_DOCS_API_TOKEN is required when docs is enabled"
        return 1
    fi

    jq -n \
        --arg provider "$provider" \
        --arg url "$url" \
        --arg email "$email" \
        --arg auth_type "$auth_type" \
        --arg cloud_id "$cloud_id" \
        --arg token "$token" \
        '{
            enabled: true,
            provider: $provider,
            config: {
                url: $url,
                email: $email,
                auth_type: $auth_type,
                cloud_id: $cloud_id,
                token: $token
            }
        }'
}

# Pre-flight check: does the base workspace config row exist in the config
# service? Returns 0 if yes, 1 if not. Used to give actionable errors before
# attempting insights PUT/DELETE calls that would 404 on a missing row.
_config_base_row_exists() {
    ensure_config_service_accessible
    local CONFIG_PORT="${CIS_CONFIG_EXTERNAL_PORT:-5003}"
    local CONFIG_URL="${CONFIG_URL:-http://localhost:${CONFIG_PORT}}"
    [ -z "${BITO_API_KEY:-}" ] && return 1
    local http_code
    http_code=$(curl -s -o /dev/null -w '%{http_code}' --max-time 5 \
        -H "Authorization: Bearer $BITO_API_KEY" \
        "${CONFIG_URL}/api/v1/config" 2>/dev/null) || return 1
    [ "$http_code" -ge 200 ] && [ "$http_code" -lt 300 ]
}

# Retry wrapper: runs a command up to 3 times with 1s between attempts.
# Used by per-feature enable/disable flows where the workspace row may
# not be immediately visible.
_insights_retry() {
    local _max=3 _attempt=1
    while [ $_attempt -lt $_max ]; do
        if "$@" 2>/dev/null; then
            return 0
        fi
        sleep 1
        _attempt=$((_attempt + 1))
    done
    "$@"
}

# Merge insights sub-objects (ticket_tracker, docs, tuning) into a base
# config JSON payload so everything is sent in one atomic POST/PUT to
# cis-config. Eliminates the insights/config PUT race condition.
# Args: <base_json>   Prints merged JSON to stdout.
_merge_insights_into_config() {
    local _base="$1"

    local _glb="${INSIGHTS_GIT_LOOKBACK_DAYS:-}"
    [ -n "$_glb" ] && ! [[ "$_glb" =~ ^[0-9]+$ ]] && _glb=""
    local _jlb="${INSIGHTS_JIRA_LOOKBACK_DAYS:-}"
    [ -n "$_jlb" ] && ! [[ "$_jlb" =~ ^[0-9]+$ ]] && _jlb=""

    # -- ticket_tracker integration --
    local _tt_json="null"
    if [ "${INSIGHTS_TICKET_TRACKER_ENABLED:-}" = "true" ]; then
        _tt_json=$(create_ticket_tracker_integration_json 2>/dev/null) || true
        [ -z "$_tt_json" ] && _tt_json="null"
    fi

    # -- docs integration --
    local _docs_json="null"
    if [ "${INSIGHTS_DOCS_ENABLED:-}" = "true" ]; then
        _docs_json=$(create_docs_integration_json 2>/dev/null) || true
        [ -z "$_docs_json" ] && _docs_json="null"
    fi

    # -- tuning --
    # Include ALL features (enabled AND disabled) so the full PUT does not
    # wipe disabled-feature state that insights disable wrote.
    local _tuning_json="null"
    local _tuning_parts=""
    if [ "${INSIGHTS_GIT_ENABLED:-}" = "true" ]; then
        local _gt='{"enabled":true}'
        [ -n "$_glb" ] && _gt="{\"enabled\":true,\"lookback_days\":${_glb}}"
        _tuning_parts="${_tuning_parts}\"git\":${_gt},"
    elif [ "${INSIGHTS_SETUP_COMPLETE:-}" = "true" ]; then
        _tuning_parts="${_tuning_parts}\"git\":{\"enabled\":false},"
    fi
    if [ "${INSIGHTS_TICKET_TRACKER_ENABLED:-}" = "true" ]; then
        local _jt='{"enabled":true}'
        [ -n "$_jlb" ] && _jt="{\"enabled\":true,\"lookback_days\":${_jlb}}"
        _tuning_parts="${_tuning_parts}\"jira\":${_jt},"
    elif [ "${INSIGHTS_SETUP_COMPLETE:-}" = "true" ]; then
        _tuning_parts="${_tuning_parts}\"jira\":{\"enabled\":false},"
    fi
    if [ "${INSIGHTS_DOCS_ENABLED:-}" = "true" ]; then
        _tuning_parts="${_tuning_parts}\"docs\":{\"enabled\":true},"
    elif [ "${INSIGHTS_SETUP_COMPLETE:-}" = "true" ]; then
        _tuning_parts="${_tuning_parts}\"docs\":{\"enabled\":false},"
    fi
    if [ -n "$_tuning_parts" ]; then
        _tuning_parts="${_tuning_parts%,}"
        _tuning_json="{${_tuning_parts}}"
    fi

    # Nothing to merge
    if [ "$_tt_json" = "null" ] && [ "$_docs_json" = "null" ] && [ "$_tuning_json" = "null" ]; then
        echo "$_base"
        return 0
    fi

    echo "$_base" | jq \
        --argjson tt "$_tt_json" \
        --argjson docs "$_docs_json" \
        --argjson tuning "$_tuning_json" \
        '
        if $tt   != null then .integration.ticket_tracker = $tt   else . end |
        if $docs != null then .integration.docs           = $docs else . end |
        if $tuning != null then .tuning = $tuning                 else . end
        '
}

# Internal: PUT/DELETE a single integration row.
# Args: <method> <path-without-leading-slash> [<json-body>]
# Returns 0 on 2xx, 1 otherwise (with body printed via render).
_insights_http_call() {
    local method="$1"
    local path="$2"
    local body="${3:-}"

    if [ -z "$BITO_API_KEY" ]; then
        print_error "BITO_API_KEY missing in environment"
        return 1
    fi

    ensure_config_service_accessible

    local CONFIG_PORT="${CIS_CONFIG_EXTERNAL_PORT:-5003}"
    local CONFIG_URL="${CONFIG_URL:-http://localhost:${CONFIG_PORT}}"
    local url="${CONFIG_URL}/${path}"

    local response http_code resp_body
    if [ -n "$body" ]; then
        response=$(printf '%s' "$body" | curl -s -w '\n%{http_code}' \
            -X "$method" \
            -H "Authorization: Bearer $BITO_API_KEY" \
            -H "Content-Type: application/json" \
            --data-binary @- \
            "$url" 2>&1)
    else
        response=$(curl -s -w '\n%{http_code}' \
            -X "$method" \
            -H "Authorization: Bearer $BITO_API_KEY" \
            "$url" 2>&1)
    fi

    http_code=$(echo "$response" | tail -1 2>/dev/null)
    resp_body=$(echo "$response" | sed '$d' 2>/dev/null)

    if [ "$http_code" -ge 200 ] && [ "$http_code" -lt 300 ]; then
        return 0
    fi

    # cis-config returns 404 + a "create base config first" message when no
    # workspace config row exists yet (manual-mode install path). Surface a
    # more actionable hint than the raw API error.
    if [ "$http_code" = "404" ] && \
       echo "$resp_body" 2>/dev/null | grep -qi "create base config first"; then
        print_error "Base workspace config not found."
        print_info  "Run \`bitoarch add-repos <yaml>\` first to create the base config, then re-run this command."
        return 1
    fi

    print_error "Config API ${method} ${path} failed (HTTP ${http_code})"
    [ -n "$resp_body" ] && echo "$resp_body" >&2
    return 1
}

# Opaque-passthrough PUT /api/v1/config/tuning?key=<module_key>.
# Args: <module_key> <json_body>
# cis-config stores under tuning.<module_key> in config_json. No encryption.
apply_tuning() {
    local key="$1"
    local body="${2:-}"

    if [ -z "$key" ]; then
        print_error "apply_tuning: module key is required"
        return 1
    fi

    _insights_http_call PUT "api/v1/config/tuning?key=${key}" "$body"
}

# Push insights config via per-feature PUTs. Used by callers where the
# base workspace row already exists (insights run interactive setup,
# install.sh). For add-repos, insights config is sent atomically in the
# main POST — see _merge_insights_into_config.
_config_push_insights_after_add_repos() {
    local _glb="${INSIGHTS_GIT_LOOKBACK_DAYS:-}"
    [ -n "$_glb" ] && ! [[ "$_glb" =~ ^[0-9]+$ ]] && _glb=""
    local _jlb="${INSIGHTS_JIRA_LOOKBACK_DAYS:-}"
    [ -n "$_jlb" ] && ! [[ "$_jlb" =~ ^[0-9]+$ ]] && _jlb=""

    local _pushed_any=false

    if [ "${INSIGHTS_GIT_ENABLED:-}" = "true" ] && type apply_tuning >/dev/null 2>&1; then
        local _git_body='{"enabled":true}'
        [ -n "$_glb" ] && _git_body="{\"enabled\":true,\"lookback_days\":${_glb}}"
        if _insights_retry apply_tuning git "$_git_body" >/dev/null 2>&1; then
            log_silent "insights: git tuning applied"
            _pushed_any=true
        else
            print_warning "Failed to apply git insights config; run ${YELLOW}bitoarch insights enable git${NC} later"
        fi
    fi

    if [ "${INSIGHTS_TICKET_TRACKER_ENABLED:-}" = "true" ] && type config_apply_ticket_tracker >/dev/null 2>&1; then
        if _insights_retry config_apply_ticket_tracker >/dev/null 2>&1; then
            log_silent "insights: ticket tracker config applied"
            _pushed_any=true
        else
            print_warning "Failed to apply ticket tracker config; run ${YELLOW}bitoarch insights enable ticket-tracker${NC} later"
        fi
        local _jira_body='{"enabled":true}'
        [ -n "$_jlb" ] && _jira_body="{\"enabled\":true,\"lookback_days\":${_jlb}}"
        if type apply_tuning >/dev/null 2>&1; then
            if _insights_retry apply_tuning jira "$_jira_body" >/dev/null 2>&1; then
                _pushed_any=true
            fi
        fi
    fi

    if [ "${INSIGHTS_DOCS_ENABLED:-}" = "true" ] && type config_apply_docs >/dev/null 2>&1; then
        if type apply_tuning >/dev/null 2>&1; then
            if _insights_retry apply_tuning docs '{"enabled":true}' >/dev/null 2>&1; then
                _pushed_any=true
            fi
        fi
        if _insights_retry config_apply_docs >/dev/null 2>&1; then
            log_silent "insights: docs config applied"
            _pushed_any=true
        else
            print_warning "Failed to apply docs config; run ${YELLOW}bitoarch insights enable docs${NC} later"
        fi
    fi

    if $_pushed_any; then
        print_status "Insights configuration applied"
        if [[ "${_INSIGHTS_SUPPRESS_RUN_HINT:-}" != "1" ]]; then
            echo -e "  Run insights (after indexing completes) with: ${YELLOW}bitoarch insights run${NC}"
        fi
    fi
}

# Post-add-repos housekeeping: sync project keys between env var and
# .bitoarch-config.yaml, print status. No HTTP calls — insights config
# was already sent atomically in the main POST.
_config_post_add_repos_sync() {
    local _any_enabled=false

    [ "${INSIGHTS_GIT_ENABLED:-}" = "true" ] && _any_enabled=true
    [ "${INSIGHTS_DOCS_ENABLED:-}" = "true" ] && _any_enabled=true

    if [ "${INSIGHTS_TICKET_TRACKER_ENABLED:-}" = "true" ]; then
        _any_enabled=true
        if type _insights_tp_has_yaml_tool >/dev/null 2>&1 \
           && _insights_tp_has_yaml_tool 2>/dev/null; then
            local _sync_cfg
            _sync_cfg=$(_insights_tp_repo_config_path 2>/dev/null)
            if [ -n "$_sync_cfg" ] && [ -f "$_sync_cfg" ]; then
                if [ -n "${INSIGHTS_TICKET_TRACKER_PROJECT_KEYS:-}" ]; then
                    echo "${INSIGHTS_TICKET_TRACKER_PROJECT_KEYS}" | tr ',' '\n' \
                        | _insights_tp_write_keys "$_sync_cfg" 2>/dev/null || true
                else
                    local _yaml_pk
                    _yaml_pk=$(_insights_tp_read_keys "$_sync_cfg" 2>/dev/null | paste -sd, -)
                    if [ -n "$_yaml_pk" ]; then
                        INSIGHTS_TICKET_TRACKER_PROJECT_KEYS="$_yaml_pk"
                        export INSIGHTS_TICKET_TRACKER_PROJECT_KEYS
                    fi
                fi
            fi
        fi
    fi

    if $_any_enabled; then
        print_status "Insights configuration applied"
        if [[ "${_INSIGHTS_SUPPRESS_RUN_HINT:-}" != "1" ]]; then
            echo -e "  Run insights (after indexing completes) with: ${YELLOW}bitoarch insights run${NC}"
        fi
    fi
}

# Orchestrator: read env -> build -> PUT/DELETE /api/v1/config/ticket-tracker.
config_apply_ticket_tracker() {
    local body
    body=$(create_ticket_tracker_integration_json)
    local rc=$?
    if [ $rc -ne 0 ]; then
        return $rc
    fi

    if [ -z "$body" ]; then
        _insights_http_call DELETE "api/v1/config/ticket-tracker"
        local drc=$?
        if [ $drc -ne 0 ]; then
            log_silent "insights: ticket tracker already disabled (DELETE returned non-2xx)"
        else
            log_silent "insights: ticket tracker disabled"
        fi
        return 0
    fi

    if _insights_http_call PUT "api/v1/config/ticket-tracker" "$body"; then
        log_silent "insights: ticket tracker configuration applied"
        return 0
    fi
    return 1
}

# Orchestrator: read env -> build -> PUT/DELETE /api/v1/config/docs.
config_apply_docs() {
    local body
    body=$(create_docs_integration_json)
    local rc=$?
    if [ $rc -ne 0 ]; then
        return $rc
    fi

    if [ -z "$body" ]; then
        _insights_http_call DELETE "api/v1/config/docs"
        local drc=$?
        if [ $drc -ne 0 ]; then
            log_silent "insights: docs integration already disabled (DELETE returned non-2xx)"
        else
            log_silent "insights: docs integration disabled"
        fi
        return 0
    fi

    if _insights_http_call PUT "api/v1/config/docs" "$body"; then
        log_silent "insights: docs configuration applied"
        return 0
    fi
    return 1
}

# Creates Scheduler configuration JSON from environment variables
# Reads CIS_SCHEDULER_ENABLED, SCHEDULER_BASIC_INDEX_INTERVAL, SCHEDULER_INDEX_INTERVAL
# Returns JSON structure with scheduler task configurations
create_scheduler_config_json() {
    local scheduler_enabled="${CIS_SCHEDULER_ENABLED:-true}"
    local basic_index_interval="${SCHEDULER_BASIC_INDEX_INTERVAL:-1h}"
    local ai_index_interval="${SCHEDULER_INDEX_INTERVAL:-7d}"

    # Only include scheduler config if enabled
    if [ "$scheduler_enabled" != "true" ]; then
        echo "null"
        return 0
    fi

    local scheduler_json
    scheduler_json=$(jq -n \
        --arg basic_interval "$basic_index_interval" \
        --arg ai_interval "$ai_index_interval" \
        '{
            "tasks": [
                {
                    "task_type": "basic_index",
                    "enabled": true,
                    "interval_expression": $basic_interval
                },
                {
                    "task_type": "ai_index",
                    "enabled": true,
                    "interval_expression": $ai_interval
                }
            ]
        }')

    if [ $? -ne 0 ] || [ -z "$scheduler_json" ] || [ "$scheduler_json" = "null" ]; then
        log_silent "Failed to create Scheduler config JSON"
        return 1
    fi

    echo "$scheduler_json"
    return 0
}

# Creates the repository configuration object for the Config API payload.
create_repository_config_json() {
    local repos_json="${1:-[]}"
    local repo_limit="${CIS_REPO_LIMIT:-50}"

    # Guard against a non-integer override slipping in from .env-bitoarch.
    case "$repo_limit" in
        ''|*[!0-9]*)
            log_silent "CIS_REPO_LIMIT='${CIS_REPO_LIMIT}' is not a positive integer; falling back to 50"
            repo_limit=50
            ;;
    esac

    jq -n \
        --argjson repos "$repos_json" \
        --argjson limit "$repo_limit" \
        '{ repo_limit: $limit, configured_repos: $repos }'
}

# Verify the git env carries the credentials the selected auth_type needs for a
# repo-list call: PAT needs GIT_ACCESS_TOKEN; GitHub App needs GIT_APP_ID +
# GIT_INSTALLATION_ID + GIT_APP_PRIVATE_KEY_B64 (cis-config mints the token from the
# inline key at repo-selection time and rejects an empty key). Returns 1 with a
# logged reason otherwise. Empty/absent auth_type is treated as personal_access_token.
_require_git_repo_list_creds() {
    local git_auth_type="${GIT_AUTH_TYPE:-personal_access_token}"
    [ -z "$git_auth_type" ] && git_auth_type="personal_access_token"
    if [ "$git_auth_type" = "app" ]; then
        if [ -z "${GIT_APP_ID:-}" ] || [ -z "${GIT_INSTALLATION_ID:-}" ] || [ -z "${GIT_APP_PRIVATE_KEY_B64:-}" ]; then
            log_silent "GitHub App auth requires GIT_APP_ID, GIT_INSTALLATION_ID and GIT_APP_PRIVATE_KEY_B64"
            return 1
        fi
    else
        if [ -z "${GIT_ACCESS_TOKEN:-}" ]; then
            log_silent "GIT_ACCESS_TOKEN environment variable is required"
            return 1
        fi
    fi
    return 0
}

# Build the POST /api/v1/git/repositories request body from the git env. PAT sends
# {provider,domain,token,username,additional_property} (unchanged). GitHub App sends
# the same envelope with an empty token plus inline {auth_type:"app", app_id,
# installation_id, private_key(PEM)} -- config isn't stored yet at repo-selection
# time, so cis-config mints + enumerates from these and normalizes the response to
# the same flat array shape (the .[].full_name parser is unchanged). Echoes JSON;
# returns 1 if the base64 PEM can't be decoded.
_build_git_repos_request_payload() {
    local git_auth_type="${GIT_AUTH_TYPE:-personal_access_token}"
    [ -z "$git_auth_type" ] && git_auth_type="personal_access_token"
    if [ "$git_auth_type" = "app" ]; then
        local key=""
        if [ -n "${GIT_APP_PRIVATE_KEY_B64:-}" ]; then
            # openssl decodes portably (GNU base64 -d / BSD -D); openssl is a hard
            # dependency of App auth (JWT signing at setup).
            key=$(printf '%s' "${GIT_APP_PRIVATE_KEY_B64}" | openssl base64 -d -A 2>/dev/null) || return 1
            [ -z "$key" ] && return 1
        fi
        jq -n \
            --arg provider "${GIT_PROVIDER:-}" \
            --arg domain "${GIT_DOMAIN_URL:-}" \
            --arg username "${GIT_USER:-}" \
            --arg organization "${GIT_AZURE_ORG:-}" \
            --arg auth_type "$git_auth_type" \
            --arg app_id "${GIT_APP_ID:-}" \
            --arg installation_id "${GIT_INSTALLATION_ID:-}" \
            --arg private_key "$key" \
            '{
                provider: $provider,
                domain: $domain,
                token: "",
                username: $username,
                additional_property: $organization,
                auth_type: $auth_type,
                app_id: $app_id,
                installation_id: $installation_id,
                private_key: $private_key
            }'
    else
        jq -n \
            --arg provider "${GIT_PROVIDER:-}" \
            --arg domain "${GIT_DOMAIN_URL:-}" \
            --arg token "${GIT_ACCESS_TOKEN:-}" \
            --arg username "${GIT_USER:-}" \
            --arg organization "${GIT_AZURE_ORG:-}" \
            '{
                provider: $provider,
                domain: $domain,
                token: $token,
                username: $username,
                additional_property: $organization
            }'
    fi
}

# Export functions
# Git Repositories API call
# Calls the /api/v1/git/repositories endpoint with environment variables
# TODO: not using it, due to log and console print message.
git_repositories_api() {
    log_silent "Calling Git Repositories API..."
    
    # Source environment variables
#    source_env_file
    
    # Check for required environment variables
    if [ -z "$GIT_PROVIDER" ]; then
        print_error "GIT_PROVIDER environment variable is required"
        return 1
    fi
    
    if [ -z "$GIT_ACCESS_TOKEN" ]; then
        print_error "GIT_ACCESS_TOKEN environment variable is required"
        return 1
    fi
    
    if [ -z "$BITO_API_KEY" ]; then
        print_error "BITO_API_KEY environment variable is required"
        return 1
    fi
    
    # Check if jq is available
    if ! command -v jq >/dev/null 2>&1; then
        print_error "jq is required but not installed. Please install jq first."
        print_error "Install with: brew install jq (macOS) or apt-get install jq (Ubuntu)"
        return 1
    fi
    
    # Build configuration URL
    ensure_config_service_accessible
    local CONFIG_PORT="${CIS_CONFIG_EXTERNAL_PORT:-5003}"
    local CONFIG_HOST="localhost"
    
    # Detect if running in Kubernetes mode and get node IP
    if [ "${DEPLOYMENT_TYPE}" = "kubernetes" ] && command -v kubectl >/dev/null 2>&1; then
        local NODE_IP=$(kubectl get nodes -o jsonpath='{.items[0].status.addresses[?(@.type=="InternalIP")].address}' 2>/dev/null)
        if [ -n "$NODE_IP" ]; then
            CONFIG_HOST="$NODE_IP"
            log_silent "Detected Kubernetes deployment, using node IP: $NODE_IP"
        else
            log_silent "Could not get Kubernetes node IP, falling back to localhost"
        fi
    fi
    
    local CONFIG_URL="${CONFIG_URL:-http://${CONFIG_HOST}:${CONFIG_PORT}}"
    local API_ENDPOINT="${CONFIG_URL}/api/v1/git/repositories"
    
    # Set domain (empty string if not provided)
    local GIT_DOMAIN="${GIT_DOMAIN_URL:-}"
    
    log_silent "Calling API endpoint: $API_ENDPOINT"
    log_silent "Using provider: $GIT_PROVIDER"
    
    # Build JSON payload using jq
    local json_payload
    json_payload=$(jq -n \
        --arg provider "$GIT_PROVIDER" \
        --arg domain "$GIT_DOMAIN" \
        --arg token "$GIT_ACCESS_TOKEN" \
        --arg username "" \
        --arg organization "${GIT_AZURE_ORG:-}" \
        '{
            "provider": $provider,
            "domain": $domain,
            "token": $token,
            "username": $username,
            "additional_property": $organization
        }')
    
    if [ $? -ne 0 ]; then
        log_silent "Failed to create JSON payload"
        return 1
    fi
    
    # Make the API call
    local response
    local http_code
    
    response=$(curl -s -w '\n%{http_code}' \
        --location "$API_ENDPOINT" \
        --header "Authorization: Bearer $BITO_API_KEY" \
        --header "Content-Type: application/json" \
        --data "$json_payload" 2>/dev/null)
    
    if [ $? -ne 0 ]; then
        log_silent "Failed to make API call to $API_ENDPOINT"
        return 1
    fi
    
    # Extract HTTP code and response body
    log_silent "Raw response: $response"

    http_code="${response: -3}"
    response_body="${response:0:${#response}-3}"

    log_silent "Body extracted: ${#response_body} bytes"
    
    # Check HTTP status code
    case "$http_code" in
        2*)
            log_silent "Git repositories API call successful (HTTP $http_code) Response: $response_body"
            echo "$response_body" >&2
            return 0
            ;;
        4*)
            log_silent "Client error (HTTP $http_code): $response_body"
            return 1
            ;;
        5*)
            log_silent "Server error (HTTP $http_code): $response_body"
            return 1
            ;;
        *)
            log_silent "Unexpected HTTP status code: $http_code"
            log_silent "Response: $response_body"
            return 1
            ;;
    esac
}


# Create repository configuration YAML from Git repositories API response
create_repo_config_from_api() {
    set +e
    log_silent "Creating repository configuration from Git repositories API..."
    
    # Source environment variables
#    source_env_file

    log_silent "Calling Git Repositories API..."

    # Check for required environment variables
    if [ -z "$GIT_PROVIDER" ]; then
        log_silent "GIT_PROVIDER environment variable is required"
        return 1
    fi

    if ! _require_git_repo_list_creds; then
        return 1
    fi

    if [ -z "$BITO_API_KEY" ]; then
        log_silent "BITO_API_KEY environment variable is required"
        return 1
    fi

    # Check if jq is available
    if ! command -v jq >/dev/null 2>&1; then
        log_silent "jq is required but not installed. Please install jq first."
        log_silent "Install with: brew install jq (macOS) or apt-get install jq (Ubuntu)"
        return 1
    fi

    # Build configuration URL
    local CONFIG_PORT="${CIS_CONFIG_EXTERNAL_PORT:-5003}"
    local CONFIG_URL="${CONFIG_URL:-http://localhost:${CONFIG_PORT}}"
    local API_ENDPOINT="${CONFIG_URL}/api/v1/git/repositories"
    
    # Ensure config service is accessible (sets up port-forward for K8s if needed)
    ensure_config_service_accessible

    # Set domain (empty string if not provided)
    local GIT_DOMAIN="${GIT_DOMAIN_URL:-}"

    log_silent "Calling API endpoint: $API_ENDPOINT"
    log_silent "Using provider: $GIT_PROVIDER"

    # Build JSON payload (PAT or GitHub App) using the shared builder. For App auth
    # this adds inline auth_type/app_id/installation_id/private_key so cis-config can
    # mint + enumerate; the response is normalized to the same flat array shape, so
    # the .[].full_name parser below is unchanged.
    local json_payload
    if ! json_payload=$(_build_git_repos_request_payload); then
        log_silent "Failed to create JSON payload"
        return 1
    fi

    # Make the API call
    local response
    local http_code

    response=$(curl -s -w '\n%{http_code}' \
        --location "$API_ENDPOINT" \
        --header "Authorization: $BITO_API_KEY" \
        --header "Content-Type: application/json" \
        --data "$json_payload" 2>/dev/null)

    if [ $? -ne 0 ]; then
        log_silent "Failed to make API call to $API_ENDPOINT"
        return 1
    fi

    # Extract HTTP code and response body
    log_silent "Raw response: $response"

    http_code="${response: -3}"
    response_body="${response:0:${#response}-3}"

    log_silent "Body extracted: ${#response_body} bytes"

    # Check HTTP status code
    case "$http_code" in
        2*)
            log_silent "Git repositories API call successful (HTTP $http_code) Response: $response_body"
            ;;
        4*)
            log_silent "Client error (HTTP $http_code): $response_body"
            ;;
        5*)
            log_silent "Server error (HTTP $http_code): $response_body"
            ;;
        *)
            log_silent "Unexpected HTTP status code: $http_code"
            log_silent "Response: $response_body"
            ;;
    esac
    
    # Call the Git repositories API
    local api_response
#    api_response=$(git_repositories_api)
    api_response=$response_body


    log_silent "API response: $api_response"
    
    if [ $? -ne 0 ]; then
        print_error "Failed to get repositories from API"
        return 1
    fi
    
    # Check if jq is available
    if ! command -v jq >/dev/null 2>&1; then
        log_silent "jq is required but not installed. Please install jq first."
        log_silent "Install with: brew install jq (macOS) or apt-get install jq (Ubuntu)"
        return 1
    fi
    
    # Parse the API response and validate structure
    local success
    success=$(echo "$api_response" | jq -r '.success // false' 2>/dev/null)
    
    if [ "$success" != "true" ]; then
        log_silent "API response indicates failure or invalid JSON structure"
        log_silent "Response: $api_response"
        return 1
    fi

    log_silent "API response indicates success"

    # Extract repositories array
    local repositories
    repositories=$(echo "$api_response" | jq -r '.repositories // []' 2>/dev/null)
    
    if [ "$repositories" = "[]" ] || [ "$repositories" = "null" ]; then
        log_warn "No repositories found in API response"
        repositories="[]"
    fi
    
    # Count repositories
    local repo_count
    repo_count=$(echo "$repositories" | jq 'length' 2>/dev/null)
    
    log_silent "Found $repo_count repositories to configure"
    
    # Get config file location using path-manager
    # Source path-manager if not already loaded
    if ! type get_repo_config_file >/dev/null 2>&1; then
        if [ -n "$SCRIPT_DIR" ]; then
            source "${SCRIPT_DIR}/scripts/lib/path-manager.sh" 2>/dev/null || true
        else
            source "$(dirname "${BASH_SOURCE[0]}")/../path-manager.sh" 2>/dev/null || true
        fi
    fi
    
    local config_file
    if type get_repo_config_file >/dev/null 2>&1; then
        config_file=$(get_repo_config_file)
    else
        config_file=".bitoarch-config.yaml"
    fi
    
    log_silent "Creating config file at: $config_file"

    # Build the complete YAML content in memory
    yaml_content="repository:\n  configured_repos:"

    # Add each repository namespace
    if [ "$repo_count" -gt 0 ]; then
        while IFS= read -r full_name; do
            if [ -n "$full_name" ]; then
                yaml_content="${yaml_content}\n    - namespace: ${full_name}"
            fi
        done <<< "$(echo "$repositories" | jq -r '.[] | select(.full_name != null) | .full_name')"
    else
        # Add empty array on same line
        yaml_content="${yaml_content}: []"
    fi

    # Write the complete content in one step using printf to preserve newlines
    printf "%b\n" "$yaml_content" > "$config_file"
    
    # Verify file was created successfully
    if [ -f "$config_file" ]; then
        log_silent "Successfully created $config_file with $repo_count repositories"
        echo ""
        print_info "$repo_count repositories added for indexing"
        log_silent "Repo config written to: $config_file"
        echo ""

        # Show the generated content
        log_silent "Generated configuration:"
#        cat "$config_file"

        return 0
    else
        log_silent "Failed to create $config_file"
        return 1
    fi
    set -e
}


fetch_repo_config_from_api() {
    set +e
    log_silent "Creating repository configuration from Git repositories API..."
    echo "⏳ Getting the repository list from your git account... (this may take 30–50 seconds)"
     # Parse arguments for force-load flag
    local force_load="false"
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --force-load)
                force_load="true"
                shift
                ;;
            *)
                # Unknown option, just ignore
                shift
                ;;
        esac
    done

    # Source environment variables
#    source_env_file

    log_silent "Calling Git Repositories API..."

    # Check for required environment variables
    if [ -z "$GIT_PROVIDER" ]; then
        log_silent "GIT_PROVIDER environment variable is required"
        return 1
    fi

    if ! _require_git_repo_list_creds; then
        return 1
    fi

    if [ -z "$BITO_API_KEY" ]; then
        log_silent "BITO_API_KEY environment variable is required"
        return 1
    fi

    # Check if jq is available
    if ! command -v jq >/dev/null 2>&1; then
        log_silent "jq is required but not installed. Please install jq first."
        log_silent "Install with: brew install jq (macOS) or apt-get install jq (Ubuntu)"
        return 1
    fi

    # Build configuration URL
    local CONFIG_PORT="${CIS_CONFIG_EXTERNAL_PORT:-5003}"
    local CONFIG_URL="${CONFIG_URL:-http://localhost:${CONFIG_PORT}}"
    local API_ENDPOINT="${CONFIG_URL}/api/v1/git/repositories"

    # Add force_load parameter if specified
    if [ "$force_load" = "true" ]; then
        API_ENDPOINT="${API_ENDPOINT}?force_load=true"
        log_silent "Force loading repositories from git provider"
    fi

    # Ensure config service is accessible (sets up port-forward for K8s if needed)
    ensure_config_service_accessible

    # Set domain (empty string if not provided)
    local GIT_DOMAIN="${GIT_DOMAIN_URL:-}"

    log_silent "Calling API endpoint: $API_ENDPOINT"
    log_silent "Using provider: $GIT_PROVIDER"

    # Build JSON payload (PAT or GitHub App) using the shared builder. For App auth
    # this adds inline auth_type/app_id/installation_id/private_key so cis-config can
    # mint + enumerate; the response is normalized to the same flat array shape, so
    # the .[].full_name parser below is unchanged.
    local json_payload
    if ! json_payload=$(_build_git_repos_request_payload); then
        log_silent "Failed to create JSON payload"
        return 1
    fi

    # Make the API call
    local response
    local http_code

    response=$(curl -s -w '\n%{http_code}' \
        --location "$API_ENDPOINT" \
        --header "Authorization: $BITO_API_KEY" \
        --header "Content-Type: application/json" \
        --data "$json_payload" 2>/dev/null)

    if [ $? -ne 0 ]; then
        log_silent "Failed to make API call to $API_ENDPOINT"
        return 1
    fi

    # Extract HTTP code and response body
    log_silent "Raw response: $response"

    http_code="${response: -3}"
    response_body="${response:0:${#response}-3}"

    log_silent "Body extracted: ${#response_body} bytes"

    # Check HTTP status code - use render function for user-friendly errors
    case "$http_code" in
        2*)
            log_silent "Git repositories API call successful (HTTP $http_code) Response: $response_body"
            ;;
        *)
            # Non-success codes: parse nested status if present (e.g., status=401 in error message)
            log_silent "API error (HTTP $http_code): $response_body"
            
            # Extract nested status code from error message if present
            local actual_status="$http_code"
            local actual_error="$response_body"
            
            # Parse error message from JSON if possible
            if command -v jq >/dev/null 2>&1 && echo "$response_body" | jq . >/dev/null 2>&1; then
                local error_msg=$(echo "$response_body" | jq -r '.error // .message // ""')
                
                # Check for nested status code in error message
                if echo "$error_msg" | grep -q "status="; then
                    actual_status=$(echo "$error_msg" | sed -n 's/.*status=\([0-9]*\).*/\1/p')
                    log_silent "Extracted nested HTTP status: $actual_status"
                fi
                
                # Extract nested body if present
                if echo "$error_msg" | grep -q "body="; then
                    local nested_body=$(echo "$error_msg" | sed -n 's/.*body=\({[^}]*}\).*/\1/p')
                    if [ -n "$nested_body" ] && command -v jq >/dev/null 2>&1; then
                        # Try to extract message from nested body
                        local nested_msg=$(echo "$nested_body" | jq -r '.message // ""' 2>/dev/null)
                        if [ -n "$nested_msg" ]; then
                            actual_error="$nested_msg"
                        fi
                    fi
                fi
            fi
            
            render_fetch_repo_list_failure_block "$actual_status" "$actual_error"
            return 1
            ;;
    esac

    # Call the Git repositories API
    local api_response
#    api_response=$(git_repositories_api)
    api_response=$response_body


    log_silent "API response: $api_response"

    # Check if jq is available
    if ! command -v jq >/dev/null 2>&1; then
        log_silent "jq is required but not installed. Please install jq first."
        log_silent "Install with: brew install jq (macOS) or apt-get install jq (Ubuntu)"
        return 1
    fi

    # Parse the API response and validate structure
    local success
    success=$(echo "$api_response" | jq -r '.success // false' 2>/dev/null)

    if [ "$success" != "true" ]; then
        # API returned success:false - use render function for consistent error display
        render_fetch_repo_list_failure_block "200" "$api_response"
        log_silent "API failure response: $api_response"
        return 1
    fi

    log_silent "API response indicates success"

    # Extract repositories array
    local repositories
    repositories=$(echo "$api_response" | jq -r '.repositories // []' 2>/dev/null)

    if [ "$repositories" = "[]" ] || [ "$repositories" = "null" ]; then
        log_warn "No repositories found in API response"
        repositories="[]"
    fi

    # Count repositories
    local repo_count
    repo_count=$(echo "$repositories" | jq 'length' 2>/dev/null)

    log_silent "Found $repo_count repositories to configure"

    # Get config file location using path-manager
    # Source path-manager if not already loaded
    if ! type get_repo_list_file >/dev/null 2>&1; then
        if [ -n "$SCRIPT_DIR" ]; then
            source "${SCRIPT_DIR}/scripts/lib/path-manager.sh" 2>/dev/null || true
        else
            source "$(dirname "${BASH_SOURCE[0]}")/../path-manager.sh" 2>/dev/null || true
        fi
    fi

    local repo_list_file
    if type get_repo_list_file >/dev/null 2>&1; then
        repo_list_file=$(get_repo_list_file)
    else
        repo_list_file=".git-repo-list.yaml"
    fi

    log_silent "Creating config file at: $repo_list_file"

    # Start building the YAML content
    cat > "$repo_list_file" << 'EOF'
repository:
  configured_repos:
EOF

    # Add each repository namespace
    if [ "$repo_count" -gt 0 ]; then
        echo "$repositories" | jq -r '.[] | select(.full_name != null) | .full_name' | while read -r full_name; do
            if [ -n "$full_name" ]; then
                echo "    - namespace: $full_name" >> "$repo_list_file"
            fi
        done
    else
        # Add empty array if no repositories
        echo "    []" >> "$repo_list_file"
    fi

    # Verify file was created successfully
    if [ -f "$repo_list_file" ]; then
        log_silent "Successfully created $repo_list_file with $repo_count repositories"
        echo ""
        echo -e "📝 Found $repo_count repositories. The complete repository list has been added to $repo_list_file for reference."
        echo ""

        # Show the generated content
        log_silent "Generated configuration:"

        return 0
    else
        log_silent "Failed to create $repo_list_file"
        return 1
    fi
    set -e
}

export -f handle_config
export -f handle_config_repo
export -f config_repo_get
export -f config_repo_add_from_file
export -f config_repo_update_from_file
export -f config_repo_add_namespace
export -f config_repo_remove_namespace
export -f create_git_integration_json
export -f _require_git_repo_list_creds
export -f _build_git_repos_request_payload
export -f create_llm_integration_json
export -f create_scheduler_config_json
export -f create_repository_config_json
export -f git_repositories_api
export -f create_repo_config_from_api
export -f fetch_repo_config_from_api
export -f create_ticket_tracker_integration_json
export -f create_docs_integration_json
export -f apply_tuning
export -f config_apply_ticket_tracker
export -f config_apply_docs
export -f _insights_http_call
export -f _insights_retry
export -f _merge_insights_into_config
export -f _config_push_insights_after_add_repos
export -f _config_post_add_repos_sync
