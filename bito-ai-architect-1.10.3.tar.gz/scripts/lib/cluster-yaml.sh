#!/bin/bash
# ============================================================================
# Copyright (c) 2023-2026 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# @company Bito Inc.
# @website https://bito.ai
# ============================================================================
# cluster-yaml.sh -- reads the operator-owned cluster profile
# ($HOME/.bitoarch/cluster.yaml) for Kubernetes deployments.
#
# Scalar fields export env vars consumed by values-generator. Structured
# scheduling/replica fields are deep-merged (via yq) into the single generated
# helm values file, so there is no separate overlay file. The cluster yaml is
# never written back.

# Prevent multiple sourcing
if [ -n "${_BITOARCH_CLUSTER_YAML_LOADED:-}" ]; then
    return 0
fi
_BITOARCH_CLUSTER_YAML_LOADED=1

# Resolve the cluster profile path. CLUSTER_YAML env overrides the default.
_cluster_yaml_file() {
    echo "${CLUSTER_YAML:-$HOME/.bitoarch/cluster.yaml}"
}

# True when python3 can actually parse YAML. `command -v python3` alone is NOT
# enough -- python3 without PyYAML runs the reader below, fails on `import yaml`,
# and prints nothing, which is indistinguishable from "field not set". Memoized:
# the probe costs an interpreter start and the readers call it per field.
_cluster_py_yaml_ok() {
    if [ -z "${_CLUSTER_PY_YAML_OK:-}" ]; then
        if command -v python3 >/dev/null 2>&1 && python3 -c 'import yaml' >/dev/null 2>&1
        then _CLUSTER_PY_YAML_OK=yes; else _CLUSTER_PY_YAML_OK=no; fi
    fi
    [ "$_CLUSTER_PY_YAML_OK" = yes ]
}

# Read the top-level `context:` scalar with no external tooling. The context
# decides WHICH CLUSTER every kubectl/helm hits, so it must stay readable even on
# a host with no working YAML parser -- otherwise the pin silently falls back to
# the operator's ambient context. Handles the forms an operator's file takes:
# quoted, inline comment, trailing whitespace, CRLF. Anchored to `^context:` so a
# nested or commented-out key never matches. A quoted value is taken up to its
# closing quote (so a '#' inside it survives and any trailing comment is dropped);
# an unquoted value drops only a whitespace-preceded '#', which is the sole form
# YAML treats as a comment. `tail -1` takes the last duplicate key, matching YAML
# (and yq) last-wins semantics.
_cluster_yaml_read_context_raw() {
    sed -n 's/\r$//; s/^context:[[:space:]]*//p' "$1" 2>/dev/null \
        | sed -e 's/^"\([^"]*\)".*$/\1/' \
              -e "s/^'\([^']*\)'.*\$/\1/" \
              -e 's/[[:space:]][[:space:]]*#.*$//' \
              -e 's/[[:space:]]*$//' \
        | tail -1
}

# Self-contained YAML scalar reader (yq preferred, python3+PyYAML fallback). Kept
# local to cluster-yaml.sh so this lib never depends on install-yaml.sh --
# cluster.yaml is owned and handled entirely here, separate from install.yaml.
# Returns empty when no parser is available; callers that need to tell "unset"
# from "unreadable" must consult _cluster_py_yaml_ok.
_cluster_yaml_read_value() {
    local yaml="$1" path="$2" out=""
    if command -v yq >/dev/null 2>&1; then
        out="$(yq eval "$path" "$yaml" 2>/dev/null)"
    elif _cluster_py_yaml_ok; then
        out="$(python3 -c "
import yaml
with open('$yaml') as f: data = yaml.safe_load(f) or {}
cur = data
for k in '$path'.lstrip('.').split('.'):
    if isinstance(cur, dict) and k in cur: cur = cur[k]
    else: cur = None; break
print(cur if cur is not None else '')
" 2>/dev/null)"
    fi
    # The context decides which cluster every kubectl/helm acts on, so when no
    # parser produced a value -- none installed, or a `yq` that cannot `eval`
    # (python-yq) -- resolve it with the tooling-free reader instead of letting an
    # empty read fall through to the operator's ambient context.
    if [ "$path" = ".context" ]; then
        case "$out" in ''|null|'~') out="$(_cluster_yaml_read_context_raw "$yaml")" ;; esac
    fi
    printf '%s\n' "$out"
}

# Validate that the cluster yaml actually parses. Unlike the scalar reader
# above (which swallows parser errors and returns empty), this surfaces the
# error and returns non-zero so _cluster_apply_yaml can ABORT rather than
# silently default. Treated as valid only when no YAML parser is installed --
# that tooling gap is caught separately by the preflight/prereq checks.
_cluster_yaml_validate() {
    local yaml="$1"
    _CLUSTER_YAML_ERR=""
    if command -v yq >/dev/null 2>&1; then
        _CLUSTER_YAML_ERR="$(yq eval '.' "$yaml" 2>&1 >/dev/null)" && return 0
    elif _cluster_py_yaml_ok; then
        _CLUSTER_YAML_ERR="$(python3 -c 'import yaml,sys; yaml.safe_load(open(sys.argv[1]))' "$yaml" 2>&1)" && return 0
    else
        # No usable YAML parser (no yq, and no python3 with PyYAML) -- treat as
        # valid so a missing parser module never misreports good YAML as broken.
        return 0
    fi
    return 1
}

# yaml_path <-> env_key pairs for SCALAR fields only (one per line).
# Structured fields (scheduling, per-service maps/lists) travel via the
# values overlay, not env.
_cluster_yaml_mapping_pairs() {
    cat <<'EOF'
.storage.shared_class    SHARED_STORAGE_CLASS
.storage.mysql_class     MYSQL_STORAGE_CLASS
.storage.access_mode     STORAGE_ACCESS_MODE
# pvc_sizes: deliberately NOT documented in cluster.yaml.default -- static shared
# PVs are not resizable, so we don't invite size changes. Still read + honored if
# an operator sets them by hand (an override hatch, e.g. for dynamic provisioning).
.storage.pvc_sizes.data      STORAGE_DATA_SIZE
.storage.pvc_sizes.backups   STORAGE_BACKUPS_SIZE
.storage.pvc_sizes.temp      STORAGE_TEMP_SIZE
.storage.pvc_sizes.logs      STORAGE_LOGS_SIZE
.storage.pvc_sizes.insights  STORAGE_INSIGHTS_SIZE
.storage.pvc_sizes.mysql     STORAGE_MYSQL_SIZE
.image_pull_secret       K8S_IMAGE_PULL_SECRET
EOF
}

# YAML -> `export KEY='value'` lines for the scalar mapping pairs above.
# Uses the local reader above; skips empty/null values so a blank field never
# clobbers an env var the operator already set.
_cluster_yaml_to_env() {
    local yaml="$1"
    if ! command -v yq >/dev/null 2>&1 && ! command -v python3 >/dev/null 2>&1; then
        print_error "Neither yq nor python3 available; cannot parse YAML"
        return 1
    fi

    while IFS= read -r line || [ -n "$line" ]; do
        [ -z "$line" ] && continue
        case "$line" in \#*) continue ;; esac
        local path envkey value
        path=$(echo "$line" | awk '{print $1}')
        envkey=$(echo "$line" | awk '{print $2}')
        [ -z "$envkey" ] && continue
        value=$(_cluster_yaml_read_value "$yaml" "$path")
        if [ -n "$value" ] && [ "$value" != "null" ] && [ "$value" != "~" ]; then
            local escaped=${value//\'/\'\\\'\'}
            echo "export ${envkey}='${escaped}'"
        fi
    done < <(_cluster_yaml_mapping_pairs)
}

# Apply the cluster yaml's scalar fields to the environment. Silent when the
# file is absent (interactive behavior unchanged); hard error on parse failure.
_cluster_apply_yaml() {
    LOG_FILE="$(get_setup_log)"
    local yaml
    yaml="$(_cluster_yaml_file)"
    if [ ! -f "$yaml" ]; then
        log_silent "No cluster yaml at $yaml; using environment/interactive values"
        return 0
    fi

    # FAIL LOUD on a malformed cluster.yaml. Without this, the scalar reads
    # below silently return empty and the installer falls back to the current
    # kube-context + default storage -- which can deploy to the WRONG cluster.
    # A present-but-unparseable profile must abort the deploy, not default.
    if ! _cluster_yaml_validate "$yaml"; then
        print_error "cluster.yaml is present but is not valid YAML: $yaml"
        [ -n "${_CLUSTER_YAML_ERR:-}" ] && print_error "  parser: ${_CLUSTER_YAML_ERR}"
        print_error "Refusing to continue -- a malformed cluster profile would silently fall back to the current kube-context and default storage (risking deployment to the wrong cluster)."
        print_error "Fix it (validate with:  yq . \"$yaml\") and re-run."
        exit 1
    fi

    local exports
    exports=$(_cluster_yaml_to_env "$yaml") || {
        print_error "Failed to parse ${yaml}"
        exit 1
    }

    if [ -n "$exports" ]; then
        # shellcheck disable=SC1090
        eval "$exports"
        log_silent "Loaded cluster values from ${yaml}"
    fi

    # Normalize the provisioning mode into STORAGE_PROVISIONING_TYPE so prep and
    # preflight branch on an explicit value instead of deducing it: honor
    # storage.provisioning_type (static|dynamic); if unset, infer static when an
    # nfs: share is given, else dynamic. In static mode the shared class is only
    # an internal binding label, so default it (the installer owns PVs + PVCs).
    local _prov _nfs_server
    _prov=$(_cluster_yaml_read_value "$yaml" ".storage.provisioning_type")
    _nfs_server=$(_cluster_yaml_read_value "$yaml" ".storage.nfs.server")
    case "$_prov" in
        static|dynamic) export STORAGE_PROVISIONING_TYPE="$_prov" ;;
        *) case "$_nfs_server" in
               ''|null|'~') export STORAGE_PROVISIONING_TYPE="dynamic" ;;
               *)           export STORAGE_PROVISIONING_TYPE="static"  ;;
           esac ;;
    esac
    # In static mode the shared class is only an internal binding label, so
    # default it (the installer owns the PVs + PVCs). Access mode is NOT inferred
    # here -- it stays operator-controlled via cluster.yaml (storage.access_mode),
    # defaulting to ReadWriteOnce in the values file; set it to ReadWriteMany for
    # shared / multi-node storage.
    if [ "$STORAGE_PROVISIONING_TYPE" = "static" ] && [ -z "${SHARED_STORAGE_CLASS:-}" ]; then
        export SHARED_STORAGE_CLASS="bito-shared-nfs"
    fi
}

# Emit one yaml block (map/list) from the cluster yaml into the overlay
# buffer at 4-space indent under a 2-space-indented destination key.
# Prints nothing when the source path is empty/absent. yq required.
# Element count of a map/list, or 0 when absent or empty. Structural, so a trailing
# comment cannot affect it -- a `[] # why` line reads as an empty list, which comparing
# the rendered text against the literal '[]' does not.
_cluster_yaml_len() {
    local n
    n=$(yq eval "$2 // {} | length" "$1" 2>/dev/null)
    case "$n" in ''|*[!0-9]*) echo 0 ;; *) echo "$n" ;; esac
}

# Render a map/list with comments stripped. `... comments=""` is structural: it also
# clears comments nested inside a populated block, and unlike a text-level strip it
# cannot damage a value that legitimately contains '#'.
_cluster_yaml_render() {
    yq eval -P "... comments=\"\" | $2 // \"\"" "$1" 2>/dev/null
}

_cluster_overlay_block() {
    local yaml="$1" path="$2" dst="$3" v
    [ "$(_cluster_yaml_len "$yaml" "$path")" -gt 0 ] || return 1
    v=$(_cluster_yaml_render "$yaml" "$path")
    [ -n "$v" ] || return 1
    printf '  %s:\n' "$dst"
    printf '%s\n' "$v" | sed 's/^/    /'
}

# Merge cluster.yaml's structured scheduling/replica fields into the single
# generated helm values file (deep-merge via yq; cluster.yaml wins). No separate
# overlay file. Only keys the operator actually set are merged.
# services.provider.replicas is deliberately never mapped (provider runs a single
# replica); its presence sets CLUSTER_PROVIDER_REPLICAS_IGNORED=1 so preflight can
# warn. Takes the path of the generated values file to merge into.
_cluster_merge_values_overlay() {
    LOG_FILE="$(get_setup_log)"
    local main_values="$1"
    local yaml tmp
    yaml="$(_cluster_yaml_file)"
    unset CLUSTER_PROVIDER_REPLICAS_IGNORED

    [ -f "$yaml" ] || return 0
    [ -f "$main_values" ] || return 0

    if ! command -v yq >/dev/null 2>&1; then
        # The overlay translation and the deep-merge both need yq. Preflight
        # already fails when cluster.yaml sets scheduling/replicas but yq is gone.
        print_warning "yq not available; cluster.yaml scheduling/replicas not applied to the values file"
        return 0
    fi

    tmp="$(mktemp)"
    : > "$tmp"

    # section spec: <values key>|<cluster.yaml path>|<scalable: yes/no>
    local spec key path scalable section
    for spec in \
        "scheduling|.scheduling|no" \
        "cisWorker|.services.worker|yes" \
        "cisConfig|.services.config|yes" \
        "cisManager|.services.manager|yes" \
        "cisTracker|.services.tracker|yes" \
        "cisProvider|.services.provider|no" \
        "mysql|.services.mysql|no" \
        "temporal|.services.temporal|no" \
        "ingressController|.services.ingress_controller|no" \
        "wingmanPopulate|.services.wingman_populate|no"; do
        IFS='|' read -r key path scalable <<< "$spec"

        section=""
        local blk
        blk=$(_cluster_overlay_block "$yaml" "${path}.node_selector" "nodeSelector") && section="${section}${blk}
"
        blk=$(_cluster_overlay_block "$yaml" "${path}.tolerations" "tolerations") && section="${section}${blk}
"
        if [ "$scalable" = "yes" ]; then
            local replicas spread
            replicas=$(_cluster_yaml_read_value "$yaml" "${path}.replicas")
            case "$replicas" in
                ''|null|'~') ;;
                *[!0-9]*) print_warning "Ignoring non-numeric replicas '${replicas}' at ${path}.replicas in ${yaml}" ;;
                *) section="${section}  replicaCount: ${replicas}
" ;;
            esac
            spread=$(_cluster_yaml_read_value "$yaml" "${path}.spread")
            # `spread` unset means the documented default, soft. Emit it explicitly
            # here rather than defaulting in the chart: the templates render the
            # spread constraint only for an explicit value, so an existing
            # single-node install that scaled a service WITHOUT a cluster.yaml keeps
            # rendering byte-identically instead of gaining a constraint (and a
            # rolling restart) on upgrade. This layer is the one that knows the
            # install is multi-node, so the default belongs here.
            case "$spread" in
                ''|null|'~') section="${section}  spread: soft
" ;;   # not gated on replicas: the effective count may come from the env
                       # default, which this layer cannot see -- the chart's own
                       # replicaCount>1 test decides whether it renders.
                soft|strict|off) section="${section}  spread: ${spread}
" ;;
                *) print_warning "Ignoring invalid spread '${spread}' at ${path}.spread in ${yaml} (soft|strict|off)" ;;
            esac
        fi

        if [ -n "$section" ]; then
            printf '%s:\n%s' "$key" "$section" >> "$tmp"
        fi
    done

    # Provider replica requests are ignored by design; surface for preflight.
    local prov_replicas
    prov_replicas=$(_cluster_yaml_read_value "$yaml" ".services.provider.replicas")
    case "$prov_replicas" in
        ''|null|'~') ;;
        *)
            export CLUSTER_PROVIDER_REPLICAS_IGNORED=1
            log_silent "cluster.yaml sets services.provider.replicas; ignored (provider runs a single replica)"
            ;;
    esac

    if [ -s "$tmp" ]; then
        # Deep-merge the overlay into the main values file; cluster.yaml (the
        # right operand) wins for scalars like replicaCount.
        local merged; merged="$(mktemp)"
        if yq eval-all 'select(fileIndex == 0) * select(fileIndex == 1)' "$main_values" "$tmp" > "$merged" 2>>"$LOG_FILE" && [ -s "$merged" ]; then
            mv "$merged" "$main_values"
            log_silent "Merged cluster.yaml scheduling/replicas into $main_values"
        else
            rm -f "$merged"
            print_warning "Failed to merge cluster.yaml scheduling/replicas into $main_values"
        fi
    fi
    rm -f "$tmp"
    return 0
}

# Static provisioning (the only supported shared-storage mode): when
# cluster.yaml carries storage.nfs.server/path, create the shared subdirectories
# (one-shot Job mounting the share root) and the five PersistentVolumes the
# chart's claims bind to. Idempotent: re-applying existing PVs is a no-op.
# shared_class is optional (defaults to bito-shared-nfs). No-op when nfs.server
# is empty and no shared storage was requested (single node). Dynamic (CSI)
# shared storage needs no pre-created PVs here -- the driver provisions them.

# Render the GLOBAL scheduling block (nodeSelector + tolerations) from
# cluster.yaml as a pod-spec fragment indented by <indent>, for Jobs we create
# directly (outside helm, so they miss the values overlay). Empty when no
# global scheduling is set, and a no-op without yq. Command substitution strips
# the trailing newline, so callers place the expansion on its own heredoc line.
_cluster_pod_scheduling_yaml() {
    local yaml="$1" indent="$2" v out=""
    command -v yq >/dev/null 2>&1 || return 0
    # -P forces block style so a flow-style cluster.yaml ({} / []) still renders
    # as valid indented YAML after the sed prefix below.
    # Emit on element count, never on the rendered text. A reconciled cluster.yaml
    # carries the template's trailing comments, so `tolerations: [] # why` renders as
    # `[] # why` -- which is not the literal '[]', so a text comparison mistakes an
    # empty list for a populated one and splices invalid YAML into the Job manifest.
    if [ "$(_cluster_yaml_len "$yaml" '.scheduling.node_selector')" -gt 0 ]; then
        v=$(_cluster_yaml_render "$yaml" '.scheduling.node_selector')
        [ -n "$v" ] && out="${indent}nodeSelector:
$(printf '%s\n' "$v" | sed "s/^/${indent}  /")
"
    fi
    if [ "$(_cluster_yaml_len "$yaml" '.scheduling.tolerations')" -gt 0 ]; then
        v=$(_cluster_yaml_render "$yaml" '.scheduling.tolerations')
        [ -n "$v" ] && out="${out}${indent}tolerations:
$(printf '%s\n' "$v" | sed "s/^/${indent}/")
"
    fi
    printf '%s' "$out"
}

# Apply a manifest (read from stdin) with a bounded retry. A single transient
# API-server blip (common on public GKE control-plane endpoints / flaky bastion
# links) must not abort a multi-node install mid-loop. `kubectl apply` is
# idempotent, so retrying -- and re-running the installer -- is safe. Non-zero
# only after all attempts fail.
_cluster_kubectl_apply_retry() {
    local manifest attempt
    manifest="$(cat)"
    for attempt in 1 2 3; do
        printf '%s\n' "$manifest" | kubectl apply -f - >> "$LOG_FILE" 2>&1 && return 0
        [ "$attempt" -lt 3 ] && sleep $((attempt * 2))
    done
    return 1
}

_cluster_prepare_static_nfs() {
    LOG_FILE="$(get_setup_log)"
    local yaml server share cls mode
    yaml="$(_cluster_yaml_file)"
    [ -f "$yaml" ] || return 0

    # Only static provisioning creates PVs. Dynamic (or unset) -> nothing to do.
    [ "${STORAGE_PROVISIONING_TYPE:-}" = "static" ] || return 0

    server=$(_cluster_yaml_read_value "$yaml" ".storage.nfs.server")
    share=$(_cluster_yaml_read_value "$yaml" ".storage.nfs.path")
    case "$server" in ''|null|'~')
        print_error "storage.provisioning_type is 'static' but storage.nfs.server is not set in cluster.yaml."
        print_error "Set storage.nfs.server + storage.nfs.path, or use storage.provisioning_type: dynamic."
        return 1 ;;
    esac
    case "$share" in ''|null|'~')
        print_error "cluster.yaml sets storage.nfs.server but no storage.nfs.path"
        return 1 ;;
    esac
    # In static mode shared_class is only an internal binding label; default it.
    cls="${SHARED_STORAGE_CLASS:-bito-shared-nfs}"
    mode="${STORAGE_ACCESS_MODE:-ReadWriteMany}"
    share="${share%/}"

    log_silent "Preparing static NFS volumes on ${server}:${share} (class: ${cls}, mode ${mode})"
    print_info "Preparing shared storage volumes..."

    # Subdirectories must exist on the share before PVs referencing them can
    # mount; create them via a one-shot Job that mounts the share root.
    # The prepare Job runs outside helm, so it never gets the values overlay;
    # inject the global scheduling block so it tolerates the same node taints
    # and lands on the same pool as the app pods (else it stays Pending on a
    # dedicated/tainted cluster and the mount is never even attempted).
    local sched
    sched=$(_cluster_pod_scheduling_yaml "$yaml" "      ")

    kubectl delete job bitoarch-nfs-prepare --ignore-not-found >/dev/null 2>&1
    if ! _cluster_kubectl_apply_retry <<EOF
apiVersion: batch/v1
kind: Job
metadata:
  name: bitoarch-nfs-prepare
  namespace: default
spec:
  backoffLimit: 2
  ttlSecondsAfterFinished: 300
  template:
    spec:
      restartPolicy: Never
${sched}
      containers:
      - name: prepare
        image: busybox:1.36
        command: ["sh", "-c", "mkdir -p /mnt/data /mnt/wingman /mnt/backups /mnt/temp /mnt/logs /mnt/insights && chmod 777 /mnt/data /mnt/wingman /mnt/backups /mnt/temp /mnt/logs /mnt/insights"]
        volumeMounts:
        - name: share-root
          mountPath: /mnt
      volumes:
      - name: share-root
        nfs:
          server: ${server}
          path: ${share}
EOF
    then
        print_error "Failed to create the NFS prepare job (server ${server}, path ${share})"
        return 1
    fi
    if ! kubectl wait --for=condition=complete job/bitoarch-nfs-prepare -n default --timeout=120s >> "$LOG_FILE" 2>&1; then
        # Distinguish the cause rather than always blaming NFS: a failed image
        # pull (no registry egress) otherwise masquerades as an NFS timeout.
        local waitreason
        waitreason=$(kubectl get pods -n default -l batch.kubernetes.io/job-name=bitoarch-nfs-prepare \
            -o jsonpath='{range .items[*]}{.status.containerStatuses[*].state.waiting.reason} {.status.initContainerStatuses[*].state.waiting.reason} {end}' 2>/dev/null)
        kubectl describe pods -n default -l batch.kubernetes.io/job-name=bitoarch-nfs-prepare >> "$LOG_FILE" 2>&1 || true
        kubectl logs job/bitoarch-nfs-prepare -n default >> "$LOG_FILE" 2>&1 || true
        case "$waitreason" in
            *ImagePull*|*ErrImage*|*RegistryUnavailable*)
                print_error "NFS prepare job could not pull busybox:1.36 -- the nodes likely lack registry (Docker Hub) egress. See ${LOG_FILE}." ;;
            *)
                print_error "NFS prepare job did not complete; verify ${server}:${share} is reachable from the nodes (NFS tcp/2049) and that busybox can be pulled. See ${LOG_FILE}." ;;
        esac
        return 1
    fi
    kubectl delete job bitoarch-nfs-prepare -n default --ignore-not-found >/dev/null 2>&1

    # Reclaim our own Released volumes before (re)creating them. Our PVs are
    # `Retain` + a hardcoded claimRef, so when their PVC goes away the PV survives
    # holding a reservation for a claim that no longer exists -- state `Released`.
    # Kubernetes will not rebind a Released volume, so a reinstall would find the
    # data intact but every volume unusable. Clearing claimRef returns it to
    # Available so the freshly created PVC binds to the existing data. Scoped to
    # PVs we labelled ourselves, and only ones actually Released.
    local pv phase
    while read -r pv phase; do
        [ -n "$pv" ] || continue
        [ "$phase" = "Released" ] || continue
        if kubectl patch pv "$pv" --type=json \
             -p='[{"op":"remove","path":"/spec/claimRef"}]' >/dev/null 2>&1; then
            log_silent "Reclaimed Released static-NFS PV ${pv} (cleared stale claimRef) so it can rebind"
        else
            print_warning "Could not clear the stale claimRef on ${pv}; it may stay Released and its PVC Pending"
        fi
    done < <(kubectl get pv -l volume-type=static-nfs \
                 -o jsonpath='{range .items[*]}{.metadata.name}{" "}{.status.phase}{"\n"}{end}' 2>/dev/null)

    # One PV per shared claim. These size defaults MUST match the PVC-request
    # defaults in values-generator.sh (storage.<vol>.size) -- a PV smaller than
    # its claim leaves the PVC Pending.
    local vol size
    for vol in "data:${STORAGE_DATA_SIZE:-20Gi}" "wingman:${WINGMAN_PVC_SIZE:-5Gi}" \
               "backups:${STORAGE_BACKUPS_SIZE:-10Gi}" "temp:${STORAGE_TEMP_SIZE:-5Gi}" \
               "logs:${STORAGE_LOGS_SIZE:-5Gi}" "insights:${STORAGE_INSIGHTS_SIZE:-5Gi}"; do
        size="${vol#*:}"; vol="${vol%%:*}"
        if ! _cluster_kubectl_apply_retry <<EOF
apiVersion: v1
kind: PersistentVolume
metadata:
  name: bitoarch-shared-${vol}
  labels:
    app.kubernetes.io/name: bitoarch
    volume-type: static-nfs
spec:
  capacity:
    storage: ${size}
  accessModes:
    - ReadWriteMany
    - ReadWriteOnce
  persistentVolumeReclaimPolicy: Retain
  storageClassName: ${cls}
  claimRef:
    namespace: bito-ai-architect
    name: bitoarch-${vol}
  nfs:
    server: ${server}
    path: ${share}/${vol}
EOF
        then
            print_error "Failed to apply PersistentVolume bitoarch-shared-${vol}"
            return 1
        fi
    done
    log_silent "Static NFS volumes ready: 6 PVs, class ${cls}, mode ${mode}, share ${server}:${share}"
    print_status "Shared storage ready (6 volumes)"
    return 0
}

# Reset/uninstall counterpart to the prepare step. The shared PVs and their data
# live outside Helm, so reset/uninstall must remove them by hand to match the
# default storage behavior (which deletes volume data on reset). This wipes the
# data in the shared subdirectories via a one-shot Job mounting the share root.
# No-op when nfs.server is empty; best-effort -- never blocks uninstall on error.
_cluster_wipe_static_nfs() {
    command -v get_setup_log >/dev/null 2>&1 && LOG_FILE="$(get_setup_log)" || LOG_FILE="${LOG_FILE:-/dev/null}"
    local yaml server share sched
    yaml="$(_cluster_yaml_file)"
    [ -f "$yaml" ] || return 0
    server=$(_cluster_yaml_read_value "$yaml" ".storage.nfs.server")
    share=$(_cluster_yaml_read_value "$yaml" ".storage.nfs.path")
    case "$server" in ''|null|'~') return 0 ;; esac
    case "$share" in ''|null|'~') return 0 ;; esac
    share="${share%/}"

    # Only static provisioning ran prepare and created these subdirs, so only
    # static may delete them. If provisioning is explicitly dynamic, a lingering
    # nfs: block in cluster.yaml is not ours to touch -- leave the share alone.
    case "$(_cluster_yaml_read_value "$yaml" ".storage.provisioning_type")" in
        dynamic) return 0 ;;
    esac

    print_info "Wiping static NFS data on ${server}:${share}..."
    sched=$(_cluster_pod_scheduling_yaml "$yaml" "      ")
    kubectl delete job bitoarch-nfs-wipe -n default --ignore-not-found >/dev/null 2>&1
    if ! _cluster_kubectl_apply_retry <<EOF
apiVersion: batch/v1
kind: Job
metadata:
  name: bitoarch-nfs-wipe
  namespace: default
spec:
  backoffLimit: 1
  ttlSecondsAfterFinished: 120
  template:
    spec:
      restartPolicy: Never
${sched}
      containers:
      - name: wipe
        image: busybox:1.36
        command: ["sh", "-c", "rm -rf /mnt/data /mnt/wingman /mnt/backups /mnt/temp /mnt/logs /mnt/insights"]
        volumeMounts:
        - name: share-root
          mountPath: /mnt
      volumes:
      - name: share-root
        nfs:
          server: ${server}
          path: ${share}
EOF
    then
        print_warning "Could not start the NFS data-wipe job; remove data on ${server}:${share} manually if needed"
        return 0
    fi
    if ! kubectl wait --for=condition=complete job/bitoarch-nfs-wipe -n default --timeout=120s >> "$LOG_FILE" 2>&1; then
        print_warning "NFS data-wipe job did not complete; data on ${server}:${share} may remain"
        kubectl logs job/bitoarch-nfs-wipe -n default >> "$LOG_FILE" 2>&1 || true
    fi
    kubectl delete job bitoarch-nfs-wipe -n default --ignore-not-found >/dev/null 2>&1
    return 0
}

# Reconcile a customer's cluster.yaml against the shipped template (upgrade path):
# additively add any keys the new template introduced that the customer's file
# lacks -- with the template's default values -- while preserving every value the
# operator already set. Backs the file up first and restores it if the merge
# yields invalid YAML. No-op when the customer file is absent (single-node), when
# mikefarah yq is unavailable, or when no keys were added (new keys still default
# at read time either way). Best-effort: never aborts a caller running under set -e.
_cluster_reconcile_yaml() {
    command -v get_setup_log >/dev/null 2>&1 && LOG_FILE="$(get_setup_log)" || LOG_FILE="${LOG_FILE:-/dev/null}"
    local customer template
    customer="${1:-$(_cluster_yaml_file)}"
    template="$2"
    [ -f "$customer" ] || return 0
    [ -f "$template" ] || return 0
    # A malformed customer file is left for _cluster_apply_yaml to fail loudly on.
    _cluster_yaml_validate "$customer" || { log_silent "cluster.yaml invalid; skipping reconcile"; return 0; }
    # The comment-preserving additive merge needs mikefarah yq v4 (eval-all + *n).
    if ! { command -v yq >/dev/null 2>&1 && printf 'a: 1\n' | yq eval '.a' - >/dev/null 2>&1; }; then
        log_silent "mikefarah yq unavailable; skipping cluster.yaml reconcile (new keys default at read time)"
        return 0
    fi

    # Only rewrite when the template adds key paths the customer's file lacks.
    # props emits comment/blank lines too, so keep only real `key = value` paths.
    local tmpl_paths cust_paths new_paths
    tmpl_paths=$(yq eval -o=props '.' "$template" 2>/dev/null | grep -E '^[[:alnum:]_.-]+ =' | sed 's/ =.*//' | sort -u || true)
    cust_paths=$(yq eval -o=props '.' "$customer" 2>/dev/null | grep -E '^[[:alnum:]_.-]+ =' | sed 's/ =.*//' | sort -u || true)
    new_paths=$(comm -23 <(printf '%s\n' "$tmpl_paths") <(printf '%s\n' "$cust_paths") 2>/dev/null || true)
    if [ -z "$new_paths" ]; then
        log_silent "cluster.yaml already carries every template key; no reconcile needed"
        return 0
    fi

    # Additively merge (customer base, add-only) and validate before touching the
    # file, so a bad merge leaves no stray backup and the original stays untouched.
    local backup merged
    merged=$(yq eval-all 'select(fileIndex==0) *n select(fileIndex==1)' "$customer" "$template" 2>/dev/null || true)
    if [ -z "$merged" ] || ! printf '%s\n' "$merged" | yq eval '.' - >/dev/null 2>&1; then
        print_warning "cluster.yaml reconcile produced invalid YAML; kept the original unchanged"
        return 0
    fi
    backup="${customer}.backup.$(date +%Y%m%d_%H%M%S)"
    cp "$customer" "$backup" 2>/dev/null || { print_warning "Could not back up cluster.yaml; skipping reconcile"; return 0; }
    # Write to a temp file in the same directory and rename over the original:
    # `>` would truncate the operator's live profile first, and a signal or crash
    # between truncate and write would leave it half-written with no restore (the
    # restore below only runs on a non-zero write). Rename is atomic within a
    # filesystem, so the file is either the old profile or the new one.
    local tmpf="${customer}.tmp.$$"
    if ! printf '%s\n' "$merged" > "$tmpf" 2>/dev/null || ! mv "$tmpf" "$customer" 2>/dev/null; then
        rm -f "$tmpf" 2>/dev/null
        cp "$backup" "$customer" 2>/dev/null
        print_warning "cluster.yaml write failed; restored from backup"
        return 0
    fi
    print_status "cluster.yaml updated with new options from this version (backup: $backup)"
    log_silent "Reconciled cluster.yaml; added: $(printf '%s' "$new_paths" | tr '\n' ' ')"
    return 0
}

# Pin every kubectl/helm in THIS process (and its exec'd / child processes,
# including nohup'd port-forwards) to the cluster.yaml context, by exporting an
# ephemeral KUBECONFIG whose current-context is that context. This is the single
# context mechanism: raw kubectl/helm and nohup-exec'd kubectl all read
# KUBECONFIG, so one call at a process entry point covers them.
#
# No-op when cluster.yaml sets no context (single-node / Docker, and the shipped
# `context: ""` default) -- the operator's current context is used, unchanged, by
# design. When a context IS named, it is honored or we fail loud: never a silent
# fallback to the ambient cluster. Returns 1 both when the named context is absent
# and when no context is readable at all (broken kubeconfig), which are reported
# as different errors. Idempotent + inherited: a child skips when the marker and
# its KUBECONFIG are both still live. The operator's real kubeconfig is never
# modified -- we copy it and switch the copy's current-context.
_pin_kube_context() {
    # --soft: for read-only commands (status/health/info/diagnose/logs). A context
    # we cannot resolve still reports its cause, but returns 0 so the command runs
    # instead of refusing at the moment the operator needs it. The contract for a
    # --soft caller is to check BITOARCH_KUBE_UNREACHABLE before any kubectl and
    # report that rather than query: unpinned means the ambient context, so a query
    # would answer from the wrong cluster (or fail and be read as "not deployed").
    local soft=""
    [ "${1:-}" = "--soft" ] && soft=1
    unset BITOARCH_KUBE_UNREACHABLE
    command -v kubectl >/dev/null 2>&1 || return 0
    # Trust the "already pinned" marker only while one of OUR ephemeral pins is
    # still the KUBECONFIG in effect; a leaked/stale export would otherwise skip
    # the pin and leave the ambient context targeted. Ownership is the test, not
    # the context name: an operator-set KUBECONFIG that merely happens to name the
    # same context is their live, mutable file and can be re-pointed mid-run.
    # Pattern-only (no kubectl fork) -- the file is ours and we set its context.
    local _pin_dir="${TMPDIR:-/tmp}/bitoarch-kubeconfig"
    if [ -n "${BITOARCH_KUBECONFIG_PINNED:-}" ]; then
        case "${KUBECONFIG:-}" in
            "$_pin_dir"/kc.*) [ -r "${KUBECONFIG}" ] && return 0 ;;
        esac
        # Stale marker: drop it and re-pin below. KUBECONFIG is left untouched --
        # it may be the operator's own path or colon-joined list, and discarding it
        # would re-resolve the context against the wrong file.
        unset BITOARCH_KUBECONFIG_PINNED
    fi
    local ctx
    ctx="$(_cluster_yaml_read_value "$(_cluster_yaml_file)" ".context" 2>/dev/null)"
    case "$ctx" in ''|null|'~') return 0 ;; esac
    local available
    available="$(kubectl config get-contexts -o name 2>/dev/null)"
    if [ -z "$available" ]; then
        # No contexts readable at all: the kubeconfig is missing/unreadable/malformed.
        # Reported separately so the operator fixes the kubeconfig instead of hunting
        # for a cluster.yaml typo that isn't there.
        print_error "cannot read any kube-context from the kubeconfig (KUBECONFIG=${KUBECONFIG:-$HOME/.kube/config})"
        print_error "cluster.yaml targets context '$ctx'; fix or point KUBECONFIG at a valid kubeconfig, then re-run"
        [ -n "$soft" ] && { export BITOARCH_KUBE_UNREACHABLE="$ctx"; return 0; }
        return 1
    fi
    if ! printf '%s\n' "$available" | grep -Fxq "$ctx"; then
        print_error "cluster.yaml context not found in kubeconfig: $ctx"
        print_error "Available contexts: $(printf '%s' "$available" | tr '\n' ' ')"
        [ -n "$soft" ] && { export BITOARCH_KUBE_UNREACHABLE="$ctx"; return 0; }
        return 1
    fi
    # Ephemeral kubeconfig in a private dir. Cleanup is a stale-PID sweep (not an
    # EXIT trap) so we never clobber a caller's own trap (e.g. restore.sh).
    local dir="$_pin_dir"
    ( umask 077; mkdir -p "$dir" ) 2>/dev/null
    local f
    for f in "$dir"/kc.*; do
        [ -e "$f" ] || continue
        kill -0 "${f##*.}" 2>/dev/null || rm -f "$f" 2>/dev/null
    done
    local tmp="$dir/kc.$$"
    if ( umask 077; kubectl config view --raw > "$tmp" ) 2>/dev/null \
       && kubectl --kubeconfig "$tmp" config use-context "$ctx" >/dev/null 2>&1; then
        export KUBECONFIG="$tmp"
        export BITOARCH_KUBECONFIG_PINNED="$ctx"
        command -v get_setup_log >/dev/null 2>&1 && LOG_FILE="$(get_setup_log)"
        command -v log_silent >/dev/null 2>&1 && log_silent "Pinned kubectl/helm to cluster.yaml context: $ctx" || true
        return 0
    fi
    rm -f "$tmp" 2>/dev/null
    print_error "Failed to pin kube-context: $ctx"
    [ -n "$soft" ] && { export BITOARCH_KUBE_UNREACHABLE="$ctx"; return 0; }
    return 1
}

# Export for use when sourced by setup.sh / kubernetes-manager flows.
if [[ "${BASH_SOURCE[0]}" != "${0}" ]]; then
    export -f _cluster_yaml_file
    export -f _cluster_py_yaml_ok
    export -f _cluster_yaml_read_context_raw
    export -f _cluster_yaml_read_value
    export -f _cluster_yaml_validate
    export -f _cluster_yaml_mapping_pairs
    export -f _cluster_yaml_to_env
    export -f _cluster_apply_yaml
    export -f _cluster_merge_values_overlay
    export -f _cluster_overlay_block
    export -f _cluster_pod_scheduling_yaml
    # Both of the two above call these, so they must cross the same boundary. An
    # exported function whose helper is missing in the child emits nothing and reports
    # success -- the scheduling overlay would silently vanish in a `bash -c` child.
    export -f _cluster_yaml_len
    export -f _cluster_yaml_render
    export -f _cluster_reconcile_yaml
    export -f _pin_kube_context
    # _cluster_prepare_static_nfs / _cluster_wipe_static_nfs are deliberately NOT
    # exported: they carry heredocs, which do not survive `declare -f` round-trip
    # through `export -f` (a child bash prints "error importing function definition"
    # and the copy is unusable). Every caller sources this file, so they are always
    # freshly defined -- never imported from the environment.
fi
