#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai

create_log_directories() {
    print_info "Creating centralized log directories..."
    
    local log_dirs=(
        "var/logs"
        "var/logs/mysql"
        "var/logs/cis-manager"
        "var/logs/cis-config"
        "var/logs/cis-provider"
        "var/logs/cis-worker"
        "var/logs/temporal"
    )
    
    local root_owned_dirs=()
    local could_not_detect_user=false
    # Get the actual user (not root if using sudo or su)
    local current_user="${SUDO_USER:-$(whoami)}"
    
    if [ "$current_user" = "root" ]; then
        local dir_owner=""
        if [[ "$OSTYPE" == "darwin"* ]]; then
            dir_owner=$(stat -f '%Su' "$SCRIPT_DIR" 2>/dev/null || echo "")
        else
            dir_owner=$(stat -c '%U' "$SCRIPT_DIR" 2>/dev/null || echo "")
        fi
        
        if [ -n "$dir_owner" ] && [ "$dir_owner" != "root" ]; then
            current_user="$dir_owner"
        else
            # Cannot reliably detect the actual user
            could_not_detect_user=true
        fi
    fi
    
    # First pass: check for root-owned directories
    for dir in "${log_dirs[@]}"; do
        local full_path="$SCRIPT_DIR/$dir"
        
        if [ -d "$full_path" ]; then
            # Check directory ownership
            local owner=""
            if [[ "$OSTYPE" == "darwin"* ]]; then
                owner=$(stat -f '%Su' "$full_path" 2>/dev/null || echo "")
            else
                owner=$(stat -c '%U' "$full_path" 2>/dev/null || echo "")
            fi
            
            if [ "$owner" = "root" ]; then
                root_owned_dirs+=("$full_path")
            fi
        fi
    done
    
    if [ ${#root_owned_dirs[@]} -gt 0 ]; then
        if [ "$(whoami)" = "root" ]; then
            log_silent "Found root-owned directories, fixing permissions (running as root)"
            for dir in "${root_owned_dirs[@]}"; do
                chmod 777 "$dir" 2>/dev/null || true
                log_silent "  - Fixed: $dir"
            done
        elif [[ "${SERVICES_WERE_RUNNING:-false}" == "true" ]]; then
            # Services exist - just warn, don't block restart
            log_silent "Warning: Found root-owned log directories (not blocking restart)"
            for dir in "${root_owned_dirs[@]}"; do
                log_silent "  - $dir"
            done
            log_silent "Directories are functional despite root ownership"
            # Continue without error - services can restart
        else
            echo ""
            print_error "Cannot set permissions: Some log directories are owned by root"
            echo ""
            print_info "This typically happens after a previous Docker deployment"
            print_info "Root-owned directories found:"
            for dir in "${root_owned_dirs[@]}"; do
                echo "  - $dir"
            done
            echo ""
            print_info "To fix this, run one of the following commands:"
            echo ""
            if [ "$could_not_detect_user" = true ]; then
                echo -e "  ${YELLOW}Option 1:${NC} Change ownership to your user:"
                echo -e "    ${BLUE}sudo chown -R \$USER:\$USER ${SCRIPT_DIR}/var/logs${NC}"
                echo -e "    ${YELLOW}Note:${NC} Replace \$USER with your actual username (run as non-root user)"
            else
                echo -e "  ${YELLOW}Option 1:${NC} Change ownership to your user:"
                echo -e "    ${BLUE}sudo chown -R $current_user:$current_user ${SCRIPT_DIR}/var/logs${NC}"
            fi
            echo ""
            echo -e "  ${YELLOW}Option 2:${NC} Run the full cleanup (removes all data):"
            echo -e "    ${YELLOW}bitoarch uninstall --purge${NC}"
            echo ""
            return 1
        fi
    fi
    
    # Second pass: create directories and set permissions
    for dir in "${log_dirs[@]}"; do
        local full_path="$SCRIPT_DIR/$dir"
        mkdir -p "$full_path"
        
        # Use 777 for better Docker compatibility
        if ! chmod 777 "$full_path" 2>/dev/null; then
            # Try with sudo if regular chmod fails
            if command -v sudo >/dev/null 2>&1; then
                if sudo chmod 777 "$full_path" 2>/dev/null; then
                    log_silent "Set permissions with sudo on $full_path"
                else
                    print_warning "Failed to set permissions on $full_path"
                fi
            else
                print_warning "Failed to set permissions on $full_path (continuing anyway)"
            fi
        fi
    done
    
    print_status "Log directories created at ./var/logs/"
}

show_container_progress() {
    local container_name="$1"
    local display_name="$2"
    local timeout="${3:-120}"
    
    if is_arm64_mac; then
        timeout=$((timeout * 2))
    fi
    
    printf "   %-20s " "$display_name"
    
    local elapsed=0
    local spinner="⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏"
    local i=0
    
    while [ $elapsed -lt $timeout ]; do
        local status=$(docker inspect --format='{{.State.Status}}' "$container_name" 2>/dev/null || echo "not_found")
        local health=$(docker inspect --format='{{.State.Health.Status}}' "$container_name" 2>/dev/null || echo "no_health")
        
        case "$status" in
            "running")
                if [[ "$health" == "healthy" ]] || [[ "$health" == "no_health" ]]; then
                    printf "\r   %-25s ${GREEN}✅ Ready${NC}            \n" "$display_name"
                    return 0
                elif [[ "$health" == "starting" ]]; then
                    # During start_period, check actual health endpoint
                    local port=$(docker inspect --format='{{range $p, $conf := .NetworkSettings.Ports}}{{if eq $p "8080/tcp"}}8080{{else if eq $p "8081/tcp"}}8081{{else if eq $p "9090/tcp"}}9090{{end}}{{end}}' "$container_name" 2>/dev/null)
                    if [ -n "$port" ] && curl -sf "http://localhost:$port/health" >/dev/null 2>&1; then
                        printf "\r   %-25s ${GREEN}✅ Ready${NC}            \n" "$display_name"
                        return 0
                    fi
                    printf "\r   %-20s ${YELLOW}⏳ %s Initializing...${NC}" "$display_name" "${spinner:$i:1}"
                else
                    printf "\r   %-20s ${YELLOW}⏳ %s Starting...${NC}" "$display_name" "${spinner:$i:1}"
                fi
                ;;
            "restarting")
                printf "\r   %-20s ${YELLOW}🔄 %s Restarting...${NC}" "$display_name" "${spinner:$i:1}"
                ;;
            "exited"|"dead")
                printf "\r   %-20s ${RED}❌ Failed${NC}           \n" "$display_name"
                return 1
                ;;
            "not_found")
                printf "\r   %-20s ${YELLOW}📦 %s Creating...${NC}" "$display_name" "${spinner:$i:1}"
                ;;
            *)
                printf "\r   %-20s ${YELLOW}⏳ %s Starting...${NC}" "$display_name" "${spinner:$i:1}"
                ;;
        esac
        
        i=$(((i + 1) % ${#spinner}))
        sleep 0.3
        elapsed=$((elapsed + 1))
    done
    
    printf "\r   %-20s ${RED}⏱️  Timeout${NC}          \n" "$display_name"
    return 1
}

deploy_mysql() {
    eval "${DOCKER_COMPOSE_CMD} --env-file \"$ENV_FILE\" up -d ai-architect-mysql" >/dev/null 2>&1
}

deploy_cis_config() {
    eval "${DOCKER_COMPOSE_CMD} --env-file \"$ENV_FILE\" up -d ai-architect-config" >> "$LOG_FILE" 2>&1
}

deploy_cis_manager() {
    eval "${DOCKER_COMPOSE_CMD} --env-file \"$ENV_FILE\" up -d ai-architect-manager" >> "$LOG_FILE" 2>&1
}

deploy_cis_tracker() {
    eval "${DOCKER_COMPOSE_CMD} --env-file \"$ENV_FILE\" up -d ai-architect-tracker" >> "$LOG_FILE" 2>&1
}

deploy_cis_provider() {
    eval "${DOCKER_COMPOSE_CMD} --env-file \"$ENV_FILE\" up -d ai-architect-provider" >> "$LOG_FILE" 2>&1
}

# Configurable health-wait for the Temporal container, shared by the install
# path and the lifecycle helper. Returns the wait_for_services_healthy rc
# contract (0 ready / 1 hard-fail / 2 soft-timeout). Override the budget with
# TEMPORAL_WAIT_TIMEOUT_SECS on slow networks. Idempotent: returns at once
# once the container is already healthy.
_temporal_wait_healthy() {
    wait_for_services_healthy \
        "${TEMPORAL_WAIT_TIMEOUT_SECS:-300}" \
        "${SERVICE_WAIT_GRACE_SECS:-60}" \
        ai-architect-temporal
}

# Always returns 0 even on failure (logged via print_warning) so callers
# in the bitoarch lifecycle path never break on Temporal hiccups.
_temporal_run_bootstrap() {
    log_silent "Waiting for ai-architect-temporal to become healthy before bootstrap..."
    if ! _temporal_wait_healthy; then
        print_warning "ai-architect-temporal did not report healthy in time; skipping bootstrap"
        return 0
    fi

    log_silent "Running Temporal bootstrap (namespaces, search attributes, validation)..."
    if docker exec ai-architect-temporal sh /etc/temporal/init/bootstrap.sh >> "$LOG_FILE" 2>&1; then
        log_silent "Temporal bootstrap complete"
    else
        print_warning "Temporal bootstrap reported errors — check $LOG_FILE"
    fi
    return 0
}

# Branches on TEMPORAL_WORKER_VERSIONING_ENABLED from $ENV_FILE:
#   true  -> promote the worker's build-id as the namespace's current
#            deployment version so versioned dispatch actually routes.
#   false -> verify the worker is polling the UNVERSIONED slot so
#            unversioned StartWorkflow calls from cis-manager match.
# Always returns 0 even on failure (logged via print_warning).
_temporal_run_worker_versioning() {
    local versioning
    versioning=$(grep -E '^TEMPORAL_WORKER_VERSIONING_ENABLED=' "$ENV_FILE" 2>/dev/null | tail -1 | cut -d= -f2- | tr -d '"' | tr -d "'" | tr '[:upper:]' '[:lower:]')
    versioning="${versioning:-true}"   # Must match docker-compose.yml default

    if [ "$versioning" = "true" ]; then
        log_silent "Worker versioning ENABLED — pairing deployment version with namespace..."
        if docker exec ai-architect-temporal sh /etc/temporal/init/setup-worker-deployment.sh >> "$LOG_FILE" 2>&1; then
            log_silent "Worker deployment version set as current"
        else
            print_warning "Could not set worker deployment as current — check $LOG_FILE"
        fi
    else
        log_silent "Worker versioning DISABLED — verifying unversioned poller attachment..."
        if docker exec ai-architect-temporal sh /etc/temporal/init/verify-unversioned-worker.sh >> "$LOG_FILE" 2>&1; then
            log_silent "Unversioned worker verified on task queue"
        else
            print_warning "Unversioned worker verification failed — check $LOG_FILE"
        fi
    fi
    return 0
}

run_temporal_post_deploy() {
    # Pin LOG_FILE / ENV_FILE to canonical paths when invoked from the
    # bitoarch CLI lifecycle: bitoarch.sh uses a local lowercase env_file
    # and setup-utils.sh's LOG_FILE fallback otherwise routes output to
    # <repo>/scripts/var/logs/setup.log. No-ops when already canonical.
    if command -v get_setup_log >/dev/null 2>&1; then
        LOG_FILE="$(get_setup_log)"
    fi
    if [ -z "$ENV_FILE" ] && command -v get_config_file >/dev/null 2>&1; then
        ENV_FILE="$(get_config_file)"
    fi
    _temporal_run_bootstrap
    _temporal_run_worker_versioning
    return 0
}
export -f run_temporal_post_deploy 2>/dev/null || true

deploy_temporal() {
    eval "${DOCKER_COMPOSE_CMD} --env-file \"$ENV_FILE\" up -d ai-architect-temporal" >> "$LOG_FILE" 2>&1 || return 1

    # Install path: wait with a tunable budget and surface the real health
    # state so install never reports success while Temporal is still warming
    #. Override TEMPORAL_WAIT_TIMEOUT_SECS for slow networks.
    log_silent "Waiting for ai-architect-temporal to become healthy before bootstrap..."
    wait_for_services_healthy \
        "${TEMPORAL_WAIT_TIMEOUT_SECS:-300}" \
        "${SERVICE_WAIT_GRACE_SECS:-60}" \
        ai-architect-temporal
    local rc=$?
    case $rc in
        0) ;;
        2) print_error "ai-architect-temporal did not reach healthy within ${TEMPORAL_WAIT_TIMEOUT_SECS:-300}s. On slow networks set TEMPORAL_WAIT_TIMEOUT_SECS in .env-bitoarch." ;;
        *) print_error "ai-architect-temporal failed health check (exited or reported unhealthy)." ;;
    esac
    if [ $rc -ne 0 ]; then
        print_info "Logs: docker logs ai-architect-temporal"
        return 1
    fi

    # Health confirmed — run the shared bootstrap (same code path the
    # lifecycle helper uses, so install and start/update/restart stay in
    # lockstep). The wait inside is a no-op now that we're healthy.
    _temporal_run_bootstrap
    return 0
}

deploy_cis_worker() {
    eval "${DOCKER_COMPOSE_CMD} --env-file \"$ENV_FILE\" up -d ai-architect-worker" >> "$LOG_FILE" 2>&1 || return 1
    _temporal_run_worker_versioning
    return 0
}

# Shared plugin ingress (nginx). Generic base service: started on every fresh
# install (both deploy paths route through deploy_services) so the ingress port
# serves even before any plugin exists. Best-effort -- the base runs fine without
# it, and plugin install re-ensures it (ingress.sh:_ingress_ensure_up).
deploy_ingress() {
    local out
    out="$(eval "${DOCKER_COMPOSE_CMD} --env-file \"$ENV_FILE\" up -d --wait --wait-timeout 60 ai-architect-ingress" 2>&1)"
    printf '%s\n' "$out" >> "$LOG_FILE" 2>&1
    # Judge by the actual running state, not the exit code: a host-port clash
    # leaves the container Created with a non-obvious rc. Surface the cause so a
    # customer can self-serve instead of hitting a silent "webhook unreachable".
    if docker ps --format '{{.Names}}' 2>/dev/null | grep -qx "ai-architect-ingress"; then
        return 0
    fi
    # Log-only: this runs under the deployment spinner (a terminal write garbles the
    # progress line); `bitoarch diagnose` surfaces the same state interactively.
    if printf '%s' "$out" | grep -qiE 'port is already allocated|address already in use|bind for .* failed'; then
        log_silent "Ingress could not bind host port ${INGRESS_PORT:-5080} — it is already in use. Plugin webhooks will be unreachable until this is resolved. Fix: set INGRESS_PORT to a free port in ${ENV_FILE} and re-run, or free port ${INGRESS_PORT:-5080}."
    else
        log_silent "Ingress did not start. Plugins that need public webhooks won't be reachable until it is running."
    fi
    return 1
}

# Place the packaged Wingman assets on the shared shelf before the populate
# one-shot runs, so an install with no outbound network never needs the CDN.
# A no-op when the package carries no bundle. Fatal when a bundle is present but
# cannot be seeded: there is no download to fall back on in that case.
#
# Progress is log-only: this runs under the deployment spinner, where a terminal
# write garbles the progress line.
seed_wingman_bundle_if_packaged() {
    local lib="${SCRIPT_DIR}/scripts/lib/wingman-bundle.sh"
    [ -f "$lib" ] || return 0
    # shellcheck disable=SC1090
    source "$lib" 2>/dev/null || return 0
    type wingman_bundle_seed_docker >/dev/null 2>&1 || return 0

    wingman_bundle_present || return 0

    # Only now, past every early return: this pins the caller's LOG_FILE, so a
    # package with no bundle must reach none of it.
    LOG_FILE="$(get_setup_log)"

    # Materialize the shelf volume under its compose-project name FIRST. `create`
    # makes the container and its volumes without starting anything, so the
    # populate one-shot still sees the marker when it is started further down.
    eval "${DOCKER_COMPOSE_CMD} --env-file \"$ENV_FILE\" create ai-architect-wingman-populate" >> "$LOG_FILE" 2>&1 \
        || log_silent "could not pre-create the wingman shelf volume; seeding may target the wrong volume"

    # Then take the volume name from that container rather than deriving it. The
    # generic resolver identifies the compose project by inspecting the long-running
    # services, none of which exist yet at this point in a fresh install, so it falls
    # back to the bare name -- and seeding a bare-named volume fills one that no
    # service mounts, leaving the real shelf empty and the populate one-shot
    # downloading from the CDN. The container we just created mounts the real shelf,
    # so it is the authoritative source.
    local _shelf_vol
    _shelf_vol="$(docker inspect ai-architect-wingman-populate \
        --format "{{range .Mounts}}{{if eq .Destination \"${WINGMAN_SHELF_MOUNT:-/opt/bito/ai-architect/wingman}\"}}{{.Name}}{{end}}{{end}}" 2>/dev/null)"
    if [ -n "$_shelf_vol" ]; then
        export WINGMAN_SHELF_VOLUME="$_shelf_vol"
        log_silent "wingman bundle: shelf volume resolved from the populate container: ${_shelf_vol}"
    else
        log_silent "wingman bundle: could not read the shelf volume off ai-architect-wingman-populate; falling back to name resolution"
    fi

    if wingman_bundle_seed_docker; then
        return 0
    fi
    wingman_bundle_seed_failed
    return 1
}

deploy_sequential() {
    log_silent "Using sequential deployment..."

    seed_wingman_bundle_if_packaged || return 1

    # Pre-warm the shared Wingman shelf up front (best-effort, non-fatal), same as the parallel path:
    # a standalone one-shot with no deps/dependants, so its CDN download overlaps the rest of the
    # sequential deploy. (cis-index still falls back to fetching the Wingman binary at runtime.)
    eval "${DOCKER_COMPOSE_CMD} --env-file \"$ENV_FILE\" up -d ai-architect-wingman-populate" >> "$LOG_FILE" 2>&1 || true

    # MySQL always first
    deploy_mysql || return 1
    
    # Deploy other services in configured order
    local service_order="${SERVICE_DEPLOY_ORDER:-ai-architect-temporal,ai-architect-config,ai-architect-tracker,ai-architect-manager,ai-architect-worker,ai-architect-provider}"
    IFS=',' read -ra SERVICES <<< "$service_order"

    for service in "${SERVICES[@]}"; do
        local service_clean=$(echo "$service" | xargs)  # Trim whitespace
        case "$service_clean" in
            "ai-architect-temporal")
                deploy_temporal || return 1
                ;;
            "ai-architect-config")
                deploy_cis_config || return 1
                ;;
            "ai-architect-manager")
                deploy_cis_manager || return 1
                ;;
            "ai-architect-worker")
                deploy_cis_worker || return 1
                ;;
            "ai-architect-provider")
                deploy_cis_provider || return 1
                ;;
            "ai-architect-tracker")
                deploy_cis_tracker || return 1
                ;;
            *)
                print_warning "Unknown service in SERVICE_DEPLOY_ORDER: $service_clean"
                ;;
        esac
    done
    
    return 0
}

deploy_parallel() {
    log_silent "Using parallel deployment..."

    seed_wingman_bundle_if_packaged || return 1

    # Start the shared Wingman-shelf populate up front, best-effort (non-fatal). It's a standalone
    # one-shot needing only the network + shelf volume + outbound CDN — nothing depends on it and it
    # depends on nothing — so kicking it off first lets its download run in parallel with the
    # MySQL/Temporal/config boot instead of after them. (If the shelf isn't ready in time, cis-index
    # still falls back to fetching the Wingman binary at runtime.)
    eval "${DOCKER_COMPOSE_CMD} --env-file \"$ENV_FILE\" up -d ai-architect-wingman-populate" >> "$LOG_FILE" 2>&1 || true

    deploy_mysql || return 1
    deploy_temporal || return 1

    local phase_wait_timeout="${PHASED_WAIT_TIMEOUT_SECS:-900}"

    # Phase 3a: config + tracker, wait healthy before phase 3b.
    eval "${DOCKER_COMPOSE_CMD} --env-file \"$ENV_FILE\" up -d --wait --wait-timeout \"$phase_wait_timeout\" ai-architect-config ai-architect-tracker" >> "$LOG_FILE" 2>&1 || return 1

    # Phase 3b: manager + worker + provider in parallel (helpers keep
    # deploy_cis_worker's temporal bootstrap). Per-pid wait+rc preserves
    # "any failure -> return 1".
    deploy_cis_manager  & local pid_manager=$!
    deploy_cis_worker   & local pid_worker=$!
    deploy_cis_provider & local pid_provider=$!

    local rc_manager rc_worker rc_provider
    wait $pid_manager;  rc_manager=$?
    wait $pid_worker;   rc_worker=$?
    wait $pid_provider; rc_provider=$?

    [ $rc_manager  -eq 0 ] || return 1
    [ $rc_worker   -eq 0 ] || return 1
    [ $rc_provider -eq 0 ] || return 1

    # Phase 3b healthy gate: helpers return on "running", not "healthy".
    # Block until manager (Wingman download) + others are actually up.
    eval "${DOCKER_COMPOSE_CMD} --env-file \"$ENV_FILE\" up -d --wait --wait-timeout \"$phase_wait_timeout\" ai-architect-manager ai-architect-worker ai-architect-provider" >> "$LOG_FILE" 2>&1 || return 1

    return 0
}

deploy_services() {
    DEPLOYMENT_STARTED=true
    
    log_service_lifecycle_banner "Starting"
    
    cd "$SCRIPT_DIR"
    
    SETUP_IN_PROGRESS=true
    
    # Clean up any old CIS containers to avoid name conflicts
    # This handles exited containers from previous deployments (especially init-dirs)
    log_silent "Checking for old CIS containers..."
    local old_containers=$(docker ps -a --filter "name=ai-architect-" --format '{{.Names}}' 2>/dev/null || true)
    
    if [ -n "$old_containers" ]; then
        log_silent "Found old containers, removing: $(echo "$old_containers" | tr '\n' ' ')"
        echo "$old_containers" | while read -r container; do
            [ -n "$container" ] && docker rm -f "$container" >> "$LOG_FILE" 2>&1 || true
        done
        log_silent "Container cleanup completed"
    fi
    
    log_silent "Creating log directories..."
    create_log_directories >> "$LOG_FILE" 2>&1
    log_silent "Log directories created successfully"

    # Create symlink to .env-bitoarch in project directory for docker-compose env_file directive
    log_silent "Creating .env-bitoarch symlink..."
    ln -sf "$ENV_FILE" "${SCRIPT_DIR}/.env-bitoarch"
    log_silent ".env-bitoarch symlink created successfully"

    log_silent "Pulling Docker images..."
    local pull_error=$(mktemp)
    local pull_output=$(mktemp)
    if ! eval "${DOCKER_COMPOSE_CMD} --env-file \"$ENV_FILE\" pull" >/dev/null 2>"$pull_output"; then
        echo "pull_failed" > "$pull_error"
        # Capture specific error type from stderr
        if grep -qi "manifest.*not found\|no such image" "$pull_output" 2>/dev/null; then
            echo "image_not_found" > "$pull_error"
        elif grep -qi "unauthorized\|authentication" "$pull_output" 2>/dev/null; then
            echo "auth_failed" > "$pull_error"
        elif grep -qi "timeout\|network" "$pull_output" 2>/dev/null; then
            echo "network_error" > "$pull_error"
        fi
        # Log errors only (not progress noise)
        grep -iE "error|fail|denied|unauthorized|timeout" "$pull_output" >> "$LOG_FILE" 2>/dev/null || true
    fi
    rm -f "$pull_output"

    # Check pull result
    if [ -f "$pull_error" ] && [ -s "$pull_error" ]; then
        local error_type=$(cat "$pull_error")
        rm -f "$pull_error"
        
        echo ""
        print_error "Failed to pull Docker images"
        
        case "$error_type" in
            "image_not_found")
                print_info "Image version error - check versions/service-versions.json"
                ;;
            "auth_failed")
                print_info "Docker authentication failed - check Docker Hub access"
                ;;
            "network_error")
                print_info "Network error - check your internet connection"
                ;;
            *)
                print_info "Unknown error - check $LOG_FILE for details"
                log_silent "Docker images pull failed: error_type=$error_type"
                ;;
        esac
        
        return 1
    fi
    rm -f "$pull_error"
    log_silent "Docker images pulled successfully"
    
    log_silent "Building Docker images..."
    local services_to_build=("ai-architect-mysql" "ai-architect-provider")
    local build_error=$(mktemp)
    
    for service in "${services_to_build[@]}"; do
        log_silent "Building $service..."
        if ! eval "${DOCKER_COMPOSE_CMD} --env-file \"$ENV_FILE\" build $service" >/dev/null 2>&1; then
            echo "$service" > "$build_error"
            break
        fi
    done
    
    # Check build result
    if [ -f "$build_error" ] && [ -s "$build_error" ]; then
        local failed_service=$(cat "$build_error")
        rm -f "$build_error"
        
        echo ""
        print_error "Build failed for $failed_service"
        print_info "Check $LOG_FILE for details"
        
        # Show last few error lines from log
        echo ""
        tail -10 "$LOG_FILE" | grep -i "error" | head -5 || true
        echo ""
        
        return 1
    fi
    rm -f "$build_error"
    log_silent "Docker images built successfully"
    echo ""
    # Deploy banner + progress loader (dev-parity for both editions). The
    # "Pulling container images and initializing services..." line sets the
    # 3-5 minute expectation; the spinner confirms liveness throughout.
    echo "🚀 Deploying Bito's AI Architect..."
    echo ""
    echo -e "${BLUE}ℹ${NC} Pulling container images and initializing services. This might take around 3-5 minutes..."
    echo ""
    echo -e "  ${BLUE}Monitor deployment progress:${NC}"
    echo -e "     • ${YELLOW}docker ps --filter name=ai-architect${NC}"
    echo ""
    show_loader "AI Architect Deployment In Progress"
    echo ""
    
    log_silent "Starting services..."
    source "$ENV_FILE"
    
    if [[ "${PARALLEL_SERVICE_DEPLOY:-true}" == "true" ]]; then
        log_silent "Using parallel deployment strategy"
        if ! deploy_parallel; then
            stop_loader 1
            return 1
        fi
    else
        log_silent "Using sequential deployment strategy"
        if ! deploy_sequential; then
            stop_loader 1
            return 1
        fi
    fi

    # Shared plugin ingress, after core services (covers both deploy paths). Best-
    # effort: a hiccup here must not fail the base install (no plugins need it yet).
    deploy_ingress || true   # deploy_ingress already surfaced + logged any failure; non-fatal for the base (plugin install re-ensures it)

    # Log syncing is handled by unified-log-manager.sh in wait_for_services()
    log_silent "Log management configured via unified-log-manager.sh"
    
    # Store loader PID for cleanup in wait_for_services
    export DEPLOY_SPINNER_PID="$LOADER_PID"
}

wait_for_services() {
    local services=("ai-architect-mysql:MySQL Database" "ai-architect-temporal:Temporal Server" "ai-architect-config:AI Architect Config" "ai-architect-tracker:AI Architect Tracker" "ai-architect-manager:AI Architect Manager" "ai-architect-worker:AI Architect Worker" "ai-architect-provider:AI Architect Provider")
    local all_healthy=true

    # Default: compact single-spinner path (keeps the deploy spinner running
    # through the health wait so the user sees continuous progress for the
    # full 3-5 min; stop only after outcome is known). Opt out with
    # VERBOSE_INSTALL_PROGRESS=true for the legacy per-service table (kept
    # for debugging / rollback only).
    if [ "${VERBOSE_INSTALL_PROGRESS:-}" != "true" ] \
       && command -v wait_for_services_healthy >/dev/null 2>&1; then
        # Defaults cover manager's start_period (120s) + first-boot binary
        # downloads. Tunable via .env-bitoarch.
        if wait_for_services_healthy "${INSTALL_WAIT_TIMEOUT_SECS:-360}" "${SERVICE_WAIT_GRACE_SECS:-60}"; then
            stop_loader 0
            unset DEPLOY_SPINNER_PID
            extract_all_service_sql_scripts
            verify_flyway_tables
            [ -f "${SCRIPT_DIR}/scripts/unified-log-manager.sh" ] && \
                "${SCRIPT_DIR}/scripts/unified-log-manager.sh" sync >/dev/null 2>&1 || true
            return 0
        fi
        stop_loader 1
        unset DEPLOY_SPINNER_PID
        # Timed out is not necessarily failed: on slow links the image pull often
        # finishes minutes later and the services come up on their own.
        print_warning "Deployment did not finish within the wait window. It may still be completing in the background (large images on a slow connection)."
        printf '   Watch it:      %bdocker ps --filter name=ai-architect%b\n' "${YELLOW:-}" "${NC:-}"
        printf '   Check again:   %bbitoarch status%b\n' "${YELLOW:-}" "${NC:-}"
        printf '   Then resume:   %bbitoarch start%b (safe to re-run once containers are Up)\n' "${YELLOW:-}" "${NC:-}"
        return 1
    fi

    # Verbose mode: stop the deploy spinner BEFORE rendering the per-service
    # progress table (each row has its own ticker). Pass rc=0 so the close
    # line reads "✓ done"; per-service table below reports real outcomes.
    if [ -n "${DEPLOY_SPINNER_PID:-}" ]; then
        stop_loader 0
        unset DEPLOY_SPINNER_PID
    fi

    echo ""
    echo -e "${BLUE}📋 Service Startup Progress:${NC}"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

    for service_info in "${services[@]}"; do
        local container_name=$(echo "$service_info" | cut -d: -f1)
        local display_name=$(echo "$service_info" | cut -d: -f2)

        # Wait for Temporal silently — required dependency but not shown in the progress table.
        # We still check the exit code so a Temporal failure surfaces here (as the real root cause)
        # instead of cascading into misleading Manager/Worker health check failures later.
        if [ "$container_name" = "ai-architect-temporal" ]; then
            if ! show_container_progress "$container_name" "$display_name" 150 >/dev/null 2>&1; then
                all_healthy=false
                echo -e "   ${RED}❌ $display_name failed to start${NC}"
                echo -e "   ${RED}💡 Troubleshooting $display_name:${NC}"
                echo -e "     • Check logs: docker logs $container_name"
                echo -e "     • Check status: docker inspect $container_name"
            fi
            continue
        fi

        if ! show_container_progress "$container_name" "$display_name" 3000; then
            all_healthy=false
            echo -e "   ${RED}💡 Troubleshooting $display_name:${NC}"
            echo -e "     • Check logs: docker logs $container_name"
            echo -e "     • Check status: docker inspect $container_name"
        fi
    done
    
    if [ "$all_healthy" = false ]; then
        echo ""
        echo -e "${RED}❌ Some services failed to start${NC}"
        return 1
    fi
    
    extract_all_service_sql_scripts
    verify_flyway_tables
    
    # Sync logs from containers to log files
    if [ -f "${SCRIPT_DIR}/scripts/unified-log-manager.sh" ]; then
        log_silent "Syncing service logs..."
        "${SCRIPT_DIR}/scripts/unified-log-manager.sh" sync >/dev/null 2>&1 || true
    fi
    
    return 0
}

batch_validate_database() {
    local script='
    mysqladmin ping --silent || exit 1
    mysql -h localhost -u "${MYSQL_USER}" -p"${MYSQL_PASSWORD}" -e "SELECT 1;" "${MYSQL_DATABASE}" >/dev/null 2>&1 || exit 2
    mysql -h localhost -u root -p"${MYSQL_ROOT_PASSWORD}" -e "SELECT 1;" >/dev/null 2>&1 || exit 3
    '
    
    docker exec -i ai-architect-mysql bash -c "$script" >/dev/null 2>&1
}

validate_deployment() {
    log_technical "Validating deployment..."
    
    source "$ENV_FILE"
    
    log_technical "Waiting for database to initialize..."
    local db_max_wait=90
    local db_wait_time=0
    
    while [ $db_wait_time -lt $db_max_wait ]; do
        local health_status=$(docker inspect --format='{{.State.Health.Status}}' ai-architect-mysql 2>/dev/null || echo "no-health")
        
        if [[ "$health_status" == "healthy" ]]; then
            log_technical "Database is healthy and ready"
            break
        elif [[ "$health_status" == "starting" ]]; then
            # Silent wait
            true
        else
            if batch_validate_database >/dev/null 2>&1; then
                log_technical "Database is responding"
                break
            fi
        fi
        
        sleep 3
        db_wait_time=$((db_wait_time + 3))
    done
    
    if [ $db_wait_time -ge $db_max_wait ]; then
        print_error "Database failed to become healthy within 90 seconds"
        return 1
    fi
    
    log_technical "Testing database connections..."
    
    if batch_validate_database; then
        log_silent "Database scripts validated and connections established"
    else
        log_technical "Some database checks failed, but services may still work"
    fi
    
    local services=("ai-architect-config:$CIS_CONFIG_EXTERNAL_PORT" "ai-architect-tracker:$CIS_TRACKER_EXTERNAL_PORT" "ai-architect-manager:$CIS_MANAGER_EXTERNAL_PORT" "ai-architect-provider:$CIS_PROVIDER_EXTERNAL_PORT")

    # Each service gets a retry budget -- a single-shot curl right after
    # `docker compose restart` races with the app's start_period and fails
    # spuriously. 30 attempts × 2s = 60s per service, matches the health
    # poll budget used by `bitoarch start` (wait_for_services_healthy).
    local attempts=30 sleep_s=2
    for service in "${services[@]}"; do
        local name=$(echo "$service" | cut -d: -f1)
        local port=$(echo "$service" | cut -d: -f2)

        # Provider runs HTTPS in Standalone (MCP_TRANSPORT=https) -- mkcert
        # cert is on the host but the install probe uses -k to stay scheme-
        # aware without depending on host trust state. All other services
        # are HTTP-only.
        local scheme="http" curl_opts="-f -s"
        if [ "$name" = "ai-architect-provider" ] && [ "${MCP_TRANSPORT:-http}" = "https" ]; then
            scheme="https"
            curl_opts="-f -s -k"
        fi

        local ok=0 i=0
        while [ $i -lt $attempts ]; do
            if curl $curl_opts "$scheme://localhost:$port/health" >/dev/null 2>&1; then
                ok=1
                break
            fi
            i=$((i + 1))
            sleep "$sleep_s"
        done

        if [ "$ok" -eq 1 ]; then
            log_technical "$name service is responding"
        else
            print_error "$name service is not responding on port $port after $((attempts * sleep_s))s"
            return 1
        fi
    done

    log_technical "Deployment validation completed"
#    msg_success "${MSG_PLATFORM_READY}"
}

check_existing_services() {
    # Use docker-compose to check services managed by this project
    local compose_services
    compose_services=$(eval "${DOCKER_COMPOSE_CMD:-docker compose} --env-file \"$ENV_FILE\" ps -q" 2>/dev/null || true)

    if [ -n "$compose_services" ]; then
        SERVICES_WERE_RUNNING=true

        echo ""
        print_warning "Previous Bito's AI Architect deployment detected"
        echo ""

        if [[ "${AUTO_SETUP:-}" != "true" ]]; then
            read -p "Restart existing services? [Y/n]: " -r REPLY
            if [[ $REPLY =~ ^[Nn]$ ]]; then
                print_info "Setup cancelled. Services remain running."
                exit 0
            fi
        else
            print_info "Auto-setup mode: restarting existing services automatically"
        fi

        print_info "Restarting existing services..."

        # Use `stop + up -d` (respects depends_on health-ordering). Plain
        # `docker compose restart` IGNORES depends_on and races cis-manager
        # / cis-config's DB-ping against MySQL's cold-start — they panic
        # (nil Server.Start) and fail validation. stop+up reliably waits
        # for MySQL to be healthy before dependents start.
        local compose_cmd="${DOCKER_COMPOSE_CMD:-docker compose} --env-file \"$ENV_FILE\""
        if eval "$compose_cmd stop" >/dev/null 2>&1 && \
           eval "$compose_cmd up -d" >/dev/null 2>&1; then
            print_status "Services restarted successfully"

            print_info "Validating restarted services..."
            if validate_deployment; then
                display_success
                exit 0
            fi
            # Validation failed even after a depends_on-respecting restart —
            # something is genuinely broken. Don't fall through to the full
            # deploy flow (would cascade into port-conflict errors because
            # our own containers still hold those ports). Stop here with a
            # clear next step.
            echo ""
            print_error "Services restarted but failed health checks"
            print_info "Inspect service logs with: ${YELLOW}bitoarch logs${NC}"
            print_info "For a clean redeploy:  ${YELLOW}bitoarch uninstall --purge${NC} then re-run your install command"
            exit 1
        fi

        # Restart itself failed to execute (rare; docker daemon issue).
        print_warning "Graceful restart failed, performing full restart..."
        cleanup_on_interrupt 0
    fi
}
