#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# Kubernetes Manager - Helper functions for K8s operations
# Used by setup.sh and upgrade.sh for Kubernetes deployments

# kubectl/helm are called directly. Context is pinned once per process via an
# ephemeral KUBECONFIG (_pin_kube_context in cluster-yaml.sh), which every
# kubectl/helm -- including nohup'd port-forwards and the `bash -c` restart/update
# subshells -- inherits, so no per-call context handling is needed here.

# Detect OS
detect_os() {
    if [[ "$OSTYPE" == "darwin"* ]]; then
        echo "macos"
    elif [[ -f /etc/os-release ]]; then
        . /etc/os-release
        if [[ "$ID" == "ubuntu" ]]; then
            echo "ubuntu-$VERSION_ID"
        else
            echo "linux"
        fi
    else
        echo "unknown"
    fi
}

# Install kubectl on macOS
install_kubectl_macos() {
    print_info "Installing kubectl on macOS..."
    
    if command -v brew >/dev/null 2>&1; then
        if brew install kubectl >> "$LOG_FILE" 2>&1; then
            print_status "kubectl installed via Homebrew"
            return 0
        fi
    else
        # Fallback: direct download
        print_info "Homebrew not found, installing kubectl directly..."
        local kubectl_bin="/usr/local/bin/kubectl"
        
        if curl -LO "https://dl.k8s.io/release/$(curl -L -s https://dl.k8s.io/release/stable.txt)/bin/darwin/amd64/kubectl" >> "$LOG_FILE" 2>&1; then
            chmod +x kubectl
            sudo mv kubectl "$kubectl_bin" 2>/dev/null || mv kubectl "$HOME/.local/bin/kubectl"
            print_status "kubectl installed to $kubectl_bin"
            return 0
        fi
    fi
    
    return 1
}

# Install kubectl on Ubuntu
install_kubectl_ubuntu() {
    print_info "Installing kubectl on Ubuntu..."
    
    # Add Kubernetes apt repository
    if ! curl -fsSL https://pkgs.k8s.io/core:/stable:/v1.28/deb/Release.key | sudo gpg --dearmor -o /etc/apt/keyrings/kubernetes-apt-keyring.gpg >> "$LOG_FILE" 2>&1; then
        print_error "Failed to add Kubernetes GPG key"
        return 1
    fi
    
    echo 'deb [signed-by=/etc/apt/keyrings/kubernetes-apt-keyring.gpg] https://pkgs.k8s.io/core:/stable:/v1.28/deb/ /' | \
        sudo tee /etc/apt/sources.list.d/kubernetes.list >> "$LOG_FILE" 2>&1
    
    if sudo apt-get update >> "$LOG_FILE" 2>&1 && sudo apt-get install -y kubectl >> "$LOG_FILE" 2>&1; then
        print_status "kubectl installed via apt"
        return 0
    fi
    
    return 1
}

# Install helm on macOS
install_helm_macos() {
    print_info "Installing helm on macOS..."
    
    if command -v brew >/dev/null 2>&1; then
        if brew install helm >> "$LOG_FILE" 2>&1; then
            print_status "helm installed via Homebrew"
            return 0
        fi
    else
        # Fallback: direct download
        print_info "Homebrew not found, installing helm directly..."
        if curl -fsSL https://raw.githubusercontent.com/helm/helm/main/scripts/get-helm-3 | bash >> "$LOG_FILE" 2>&1; then
            print_status "helm installed"
            return 0
        fi
    fi
    
    return 1
}

# Install helm on Ubuntu
install_helm_ubuntu() {
    print_info "Installing helm on Ubuntu..."
    
    # Use official installation script
    if curl -fsSL https://raw.githubusercontent.com/helm/helm/main/scripts/get-helm-3 | bash >> "$LOG_FILE" 2>&1; then
        print_status "helm installed"
        return 0
    fi
    
    return 1
}

# Auto-install missing tools
auto_install_k8s_tools() {
    local os=$(detect_os)
    local tools_installed=0
    
    print_info "Detected OS: $os"
    
    # Check and install kubectl
    if ! command -v kubectl >/dev/null 2>&1; then
        echo ""
        print_warning "kubectl is not installed"
        read -p "Would you like to install kubectl automatically? (y/N): " -r install_kubectl
        
        if [[ "$install_kubectl" =~ ^[Yy]$ ]]; then
            case "$os" in
                macos)
                    if install_kubectl_macos; then
                        tools_installed=$((tools_installed + 1))
                    else
                        print_error "Failed to install kubectl"
                        print_info "Manual installation: https://kubernetes.io/docs/tasks/tools/install-kubectl-macos/"
                        return 1
                    fi
                    ;;
                ubuntu-*)
                    if install_kubectl_ubuntu; then
                        tools_installed=$((tools_installed + 1))
                    else
                        print_error "Failed to install kubectl"
                        print_info "Manual installation: https://kubernetes.io/docs/tasks/tools/install-kubectl-linux/"
                        return 1
                    fi
                    ;;
                *)
                    print_error "Unsupported OS for auto-installation: $os"
                    print_info "Manual installation: https://kubernetes.io/docs/tasks/tools/"
                    return 1
                    ;;
            esac
        else
            print_info "Skipping kubectl installation"
            print_info "Install manually: https://kubernetes.io/docs/tasks/tools/"
            return 1
        fi
    else
        print_status "kubectl is already installed"
    fi
    
    # Check and install helm
    if ! command -v helm >/dev/null 2>&1; then
        echo ""
        print_warning "helm is not installed"
        read -p "Would you like to install helm automatically? (y/N): " -r install_helm
        
        if [[ "$install_helm" =~ ^[Yy]$ ]]; then
            case "$os" in
                macos)
                    if install_helm_macos; then
                        tools_installed=$((tools_installed + 1))
                    else
                        print_error "Failed to install helm"
                        print_info "Manual installation: https://helm.sh/docs/intro/install/"
                        return 1
                    fi
                    ;;
                ubuntu-*)
                    if install_helm_ubuntu; then
                        tools_installed=$((tools_installed + 1))
                    else
                        print_error "Failed to install helm"
                        print_info "Manual installation: https://helm.sh/docs/intro/install/"
                        return 1
                    fi
                    ;;
                *)
                    print_error "Unsupported OS for auto-installation: $os"
                    print_info "Manual installation: https://helm.sh/docs/intro/install/"
                    return 1
                    ;;
            esac
        else
            print_info "Skipping helm installation"
            print_info "Install manually: https://helm.sh/docs/intro/install/"
            return 1
        fi
    else
        print_status "helm is already installed"
    fi
    
    if [ $tools_installed -gt 0 ]; then
        echo ""
        print_status "Installed $tools_installed tool(s) successfully"
        echo ""
    fi
    
    return 0
}

# Check Kubernetes prerequisites
check_k8s_prerequisites() {
    print_info "Checking Kubernetes prerequisites..."

    # Load the operator's cluster profile first so storage settings from
    # cluster.yaml drive the checks below (context is pinned via KUBECONFIG).
    if ! type _cluster_apply_yaml >/dev/null 2>&1; then
        source "${SCRIPT_DIR}/scripts/lib/cluster-yaml.sh" 2>/dev/null || true
    fi
    if type _cluster_apply_yaml >/dev/null 2>&1; then
        _cluster_apply_yaml
    fi

    # Check if tools are installed
    local kubectl_installed=false
    local helm_installed=false
    
    command -v kubectl >/dev/null 2>&1 && kubectl_installed=true
    command -v helm >/dev/null 2>&1 && helm_installed=true
    
    # If tools are missing, offer to install
    if ! $kubectl_installed || ! $helm_installed; then
        print_warning "Some Kubernetes tools are missing"
        
        if ! auto_install_k8s_tools; then
            return 1
        fi
    fi
    
    # Verify installations
    if ! command -v kubectl >/dev/null 2>&1; then
        print_error "kubectl is still not available after installation attempt"
        return 1
    fi
    
    if ! command -v helm >/dev/null 2>&1; then
        print_error "helm is still not available after installation attempt"
        return 1
    fi
    
    # Modern kubectl version detection (v1.28+ compatible, macOS & Linux)
    local kubectl_version=""
    if command -v kubectl >/dev/null 2>&1; then
        # Try JSON output first (most reliable)
        kubectl_version=$(kubectl version --client -o json 2>/dev/null | jq -r '.clientVersion.gitVersion' 2>/dev/null || echo "")
        
        # Fallback: parse text output without deprecated --short flag
        if [[ -z "$kubectl_version" ]]; then
            kubectl_version=$(kubectl version --client 2>/dev/null | grep -oE 'v[0-9]+\.[0-9]+\.[0-9]+' | head -1 || echo "")
        fi
        
        # Only log if successfully detected (no error log if detection fails)
        if [[ -n "$kubectl_version" ]]; then
            print_status "kubectl version: $kubectl_version"
        fi
    fi
    
    # Helm version detection (already uses modern syntax)
    local helm_version=""
    if command -v helm >/dev/null 2>&1; then
        helm_version=$(helm version --short 2>/dev/null || echo "")
        if [[ -n "$helm_version" ]]; then
            print_status "helm version: $helm_version"
        fi
    fi
    
    # Pin kubectl/helm to the cluster.yaml context (via KUBECONFIG): validates
    # the context exists and fails loud rather than hitting the wrong cluster.
    # No-op when cluster.yaml sets no context.
    if ! _pin_kube_context; then
        return 1
    fi

    # Check cluster connectivity (targets the pinned context via KUBECONFIG)
    if ! kubectl cluster-info >/dev/null 2>&1; then
        print_error "Cannot connect to Kubernetes cluster${BITOARCH_KUBECONFIG_PINNED:+ (context: $BITOARCH_KUBECONFIG_PINNED)}"
        echo ""
        echo "Please ensure:"
        echo "  1. Kubernetes cluster is running"
        echo "  2. kubectl is configured correctly"
        echo "  3. Current context is set: kubectl config current-context"
        echo ""
        return 1
    fi

    if [ -n "${BITOARCH_KUBECONFIG_PINNED:-}" ]; then
        print_status "Connected to cluster: $BITOARCH_KUBECONFIG_PINNED"
    else
        local current_context=$(kubectl config current-context 2>/dev/null || echo "unknown")
        print_status "Connected to cluster: $current_context"
        # Confirm the ambient context only when the operator opted into a managed
        # cluster profile (cluster.yaml present) but left context: unset -- there a
        # stray kubeconfig switch could deploy to the wrong cluster. A plain
        # single-node install (no cluster.yaml) keeps its prior behavior: deploy to
        # the current context with no added prompt.
        local _cyaml
        _cyaml="$(_cluster_yaml_file 2>/dev/null || echo "$HOME/.bitoarch/cluster.yaml")"
        if [ -f "$_cyaml" ] && [ -t 0 ]; then
            local _ctx_ok=""
            read -p "Deploy to this cluster? (y/N): " -r _ctx_ok
            if [[ ! "$_ctx_ok" =~ ^[Yy]$ ]]; then
                print_info "Aborted. Set the target context in cluster.yaml (context:) or run: kubectl config use-context <name>"
                return 1
            fi
        else
            log_silent "Proceeding with current context: $current_context"
        fi
    fi
    
    # Check if user has permissions
    if ! kubectl auth can-i create namespaces >/dev/null 2>&1; then
        print_warning "Limited cluster permissions detected"
        print_info "You may need admin rights to create namespaces and resources"
    fi

    # Bundled ingress controller needs two cluster-scoped objects (IngressClass,
    # ClusterRole). On clusters that forbid them, the one-key remedy is using
    # the existing controller instead.
    if [ -z "${BITOARCH_INGRESS_CLASS:-}" ]; then
        if ! kubectl auth can-i create ingressclasses >/dev/null 2>&1 || ! kubectl auth can-i create clusterroles >/dev/null 2>&1; then
            print_error "This cluster does not allow installing the bundled ingress controller (cluster-scoped RBAC denied)."
            print_info  "Use the cluster's existing controller instead: set BITOARCH_INGRESS_CLASS to its class (e.g. nginx) and re-run."
            return 1
        fi
    fi

    return 0
}

# Check NodePort availability
check_nodeport_availability() {
    local port=$1
    local service_name=$2
    
    # Get all NodePort services across all namespaces
    local existing=$(kubectl get svc --all-namespaces -o json 2>/dev/null | \
        jq -r '.items[] | select(.spec.type=="NodePort") | .spec.ports[] | .nodePort' 2>/dev/null | \
        grep "^${port}$" || echo "")
    
    if [ -n "$existing" ]; then
        return 1  # Port in use
    fi
    return 0  # Port available
}

# Get cluster storage classes
get_storage_classes() {
    kubectl get storageclass -o jsonpath='{.items[*].metadata.name}' 2>/dev/null || echo ""
}

# Get default storage class
get_default_storage_class() {
    kubectl get storageclass -o json 2>/dev/null | \
        jq -r '.items[] | select(.metadata.annotations["storageclass.kubernetes.io/is-default-class"]=="true") | .metadata.name' 2>/dev/null | \
        head -1 || echo ""
}

# Monitor deployment progress with service-by-service spinners
monitor_deployment_progress() {
    local namespace="$1"
    # 15 min covers helm install + image pulls + pod scheduling on cold
    # clusters.
    local timeout="${2:-${K8S_READY_TIMEOUT_SECS:-900}}"
    
    local start_time=$(date +%s)
    # wait_services is the full readiness set (Temporal blocks deploy completion).
    # display_services hides Temporal and Tracker — internal dependencies, not user-facing.
    local wait_services=("mysql" "temporal" "config" "tracker" "manager" "worker" "provider")
    local display_services=("mysql" "config" "manager" "worker" "provider")
    local first_display=true
    local last_status_line=""

    echo ""

    while true; do
        local current_time=$(date +%s)
        local elapsed=$((current_time - start_time))

        if [ $elapsed -gt $timeout ]; then
            echo ""
            print_error "Deployment timeout after ${timeout}s"
            return 1
        fi

        # Get current status for all services
        local all_ready=true
        local current_status_line=""

        for service in "${wait_services[@]}"; do
            local pod=$(kubectl get pods -n "$namespace" -l "app.kubernetes.io/component=$service" \
                -o jsonpath='{.items[0].metadata.name}' 2>/dev/null || echo "")

            local status="pending"
            if [ -n "$pod" ]; then
                local phase=$(kubectl get pod "$pod" -n "$namespace" \
                    -o jsonpath='{.status.phase}' 2>/dev/null || echo "")
                local ready=$(kubectl get pod "$pod" -n "$namespace" \
                    -o jsonpath='{.status.conditions[?(@.type=="Ready")].status}' 2>/dev/null || echo "False")

                if [ "$phase" = "Running" ] && [ "$ready" = "True" ]; then
                    status="ready"
                elif [ "$phase" = "Running" ] || [ -n "$phase" ]; then
                    status="starting"
                fi
            fi

            current_status_line="${current_status_line}${service}:${status},"

            if [ "$status" != "ready" ]; then
                all_ready=false
            fi
        done

        # Display current status only if changed
        if [ "$first_display" = true ] || [ "$current_status_line" != "$last_status_line" ]; then
            # Clear previous lines if not first display
            if [ "$first_display" = false ]; then
                for service in "${display_services[@]}"; do
                    printf "\033[1A\033[2K"
                done
            fi

            # Print current status for all services
            for service in "${display_services[@]}"; do
                local display_name=$(echo "$service" | awk '{print toupper(substr($0,1,1)) tolower(substr($0,2))}')
                
                # Extract status for this service from current_status_line
                local status=$(echo "$current_status_line" | grep -o "${service}:[^,]*" | cut -d: -f2)
                
                case "$status" in
                    ready)
                        printf "   %-15s ${GREEN}✅ Ready${NC}\n" "$display_name"
                        ;;
                    starting)
                        printf "   %-15s ${YELLOW}⏳ Starting...${NC}\n" "$display_name"
                        ;;
                    *)
                        printf "   %-15s ${YELLOW}📦 Pending${NC}\n" "$display_name"
                        ;;
                esac
            done
            
            first_display=false
            last_status_line="$current_status_line"
        fi
        
        # Check if all are ready
        if [ "$all_ready" = true ]; then
            echo ""
            return 0
        fi
        
        sleep 3
    done
}

# Deploy via Helm
deploy_helm_chart() {
    local chart_dir="$1"
    local values_file="$2"
    local namespace="$3"
    local release_name="${4:-bitoarch}"
    
    # Input validation
    if [[ -z "$chart_dir" ]] || [[ -z "$values_file" ]] || [[ -z "$namespace" ]]; then
        print_error "Missing required parameters for helm deployment"
        print_info "Usage: deploy_helm_chart <chart_dir> <values_file> <namespace> [release_name]"
        return 1
    fi
    
    if [[ ! -d "$chart_dir" ]]; then
        print_error "Chart directory not found: $chart_dir"
        return 1
    fi
    
    if [[ ! -f "$values_file" ]]; then
        print_error "Values file not found: $values_file"
        return 1
    fi
    
    # Silent deployment with single spinner
    log_silent "Deploying helm chart: $release_name to $namespace"
    echo ""
    echo "🚀 Deploying Bito's AI Architect..."
    echo ""
    echo -e "${BLUE}ℹ${NC} Provisioning volumes, pulling container images, and rolling out pods. This might take around 10-15 minutes..."
    echo ""
    echo -e "  ${BLUE}Monitor deployment progress:${NC}"
    echo -e "     • ${YELLOW}kubectl get pods -n $namespace${NC}"
    echo ""
    
    # Start spinner
    show_loader "AI Architect Deployment In Progress"
    echo ""

    # One argument list for the server dry-run and the real install so both
    # validate exactly what gets deployed. cluster.yaml scheduling/replicas are
    # already deep-merged into this values file by the generator.
    local helm_args=(
        upgrade --install "$release_name" "$chart_dir"
        --namespace "$namespace"
        --create-namespace
        --values "$values_file"
    )

    # `--dry-run=server` validates namespaced objects against the API server, and
    # --create-namespace does NOT create the namespace during a dry-run, so a
    # first-time install would fail the dry-run with "namespace not found".
    # Create it up front (idempotent) so the dry-run has a namespace to validate.
    kubectl get namespace "$namespace" >/dev/null 2>&1 || \
        kubectl create namespace "$namespace" >> "$LOG_FILE" 2>&1 || true

    # Server-side dry-run: surfaces admission/webhook rejections before anything
    # is installed. Retried because managed control planes (GKE/EKS) briefly go
    # unreachable during upgrades, maintenance, or right after a cluster change;
    # a larger timeout would not help -- only a retry rides over such a blip.
    local dry_attempt dry_out dry_rc=0
    for dry_attempt in 1 2 3; do
        dry_out="$(helm "${helm_args[@]}" --dry-run=server 2>&1)"
        dry_rc=$?
        # $dry_out is never written to the log wholesale. On success helm prints
        # every rendered manifest, and the platform Secret renders `stringData`
        # in cleartext -- git token, API keys, DB passwords -- into a log that
        # `diagnose --bundle` collects and customers attach to support requests.
        # Only the lines that explain a rejection are logged; the console reason
        # below is extracted from $dry_out in memory, so nothing is lost.
        if [ "$dry_rc" -eq 0 ]; then
            log_silent "Server dry-run passed"
            break
        fi
        log_silent "Server dry-run failed (attempt ${dry_attempt}/3, rc=${dry_rc})"
        printf '%s\n' "$dry_out" \
            | grep -iE 'error|denied|forbidden|admission|webhook|not allowed|violat|unreachable|timeout|refused|no route' \
            >> "$LOG_FILE" 2>/dev/null || true
        case "$dry_out" in
            *"cluster unreachable"*|*"i/o timeout"*|*"connection refused"*|*"no route to host"*|*"TLS handshake timeout"*|*"dial tcp"*)
                if [ "$dry_attempt" -lt 3 ]; then
                    log_silent "Control plane unreachable (attempt ${dry_attempt}/3); retrying in $((dry_attempt * 5))s"
                    sleep $((dry_attempt * 5))
                    continue
                fi
                stop_loader 1
                print_error "Cluster unreachable: could not connect to the API server after 3 attempts"
                print_info "The control plane may be mid-upgrade or blocked by a network/firewall rule. Verify with 'kubectl get nodes' and re-run."
                print_info "Check logs: $LOG_FILE"
                return 1
                ;;
            *)
                stop_loader 1
                print_error "Cluster rejected the deployment during server dry-run (nothing was installed)"
                # Surface the actual rejection reason (GKE Autopilot / Pod Security /
                # admission webhook denials land here); the full output is in the log.
                local reason
                reason=$(printf '%s\n' "$dry_out" | grep -iE 'denied|forbidden|admission|webhook|not allowed|violat' | head -1)
                [ -n "$reason" ] && print_info "Reason: ${reason}"
                print_info "Check logs: $LOG_FILE"
                return 1
                ;;
        esac
    done

    # Seed the shared Wingman shelf BEFORE the apply when the package ships a bundle.
    # The apply cannot complete without it: helm waits for its post-install hook, the
    # hook waits up to six minutes for the worker to attach as a Temporal poller, and
    # the worker's wait-for-wingman init blocks on an empty shelf. Seeding afterwards
    # deadlocks that cycle and the services fall back to downloading, which is exactly
    # what a bundled install exists to avoid.
    # Sourced here for the same reason as the recreate path below: this function can
    # run in a child shell that inherited no shell functions.
    local _wblib
    for _wblib in "${PLATFORM_DIR:-}/scripts/lib" \
                  "${SCRIPT_DIR:-}/scripts/lib" \
                  "${SCRIPT_DIR:-}/../scripts/lib" \
                  "${BITOARCH_CLI_DIR:-}/lib"; do
        [ -f "$_wblib/wingman-bundle.sh" ] || continue
        source "$_wblib/wingman-shelf.sh" 2>/dev/null || true
        source "$_wblib/wingman-bundle.sh" 2>/dev/null || true
        break
    done
    if type wingman_bundle_seed_before_helm >/dev/null 2>&1; then
        if ! wingman_bundle_seed_before_helm "$namespace" "$dry_out" "$release_name"; then
            wingman_bundle_seed_failed
            stop_loader 1
            return 1
        fi
    else
        log_silent "wingman bundle: seed helper unavailable (wingman-bundle.sh not found from any anchor); shelf not seeded before helm"
    fi

    # Deploy with helm (blocking, with progress sent to log file)
    if helm upgrade --install "$release_name" "$chart_dir" \
        --namespace "$namespace" \
        --create-namespace \
        --values "$values_file" \
        --timeout 10m \
        >> "$LOG_FILE" 2>&1; then

        log_silent "Helm deployment successful"

        # The shared Wingman shelf was filled before the apply: a bundled install
        # seeds it there, and without a bundle the chart-owned populate Job
        # (helm-bitoarch/templates/07b-wingman-populate.yaml) runs inside this same
        # apply alongside the manager/worker wait-for-wingman init.

        # Wait for all pods to be ready silently
        if wait_for_k8s_services "$namespace" 900; then
            stop_loader 0
            log_silent "All services ready"
            return 0
        else
            stop_loader 1
            # Timed out is not necessarily failed: on slow links the image pull often
        # finishes minutes later and the services come up on their own.
        print_warning "Deployment did not finish within the wait window. It may still be completing in the background (large images on a slow connection)."
        printf '   Watch it:      %bkubectl get pods -n %s%b\n' "${YELLOW:-}" "${namespace:-bito-ai-architect}" "${NC:-}"
        printf '   Check again:   %bbitoarch status%b\n' "${YELLOW:-}" "${NC:-}"
        printf '   Then resume:   %bbitoarch start%b (safe to re-run once containers are Up)\n' "${YELLOW:-}" "${NC:-}"

            print_error "Services failed to become ready"
            return 1
        fi
    else
        stop_loader 1
        print_error "Helm deployment failed"
        print_info "Check logs: $LOG_FILE"
        return 1
    fi
}

# Wait for K8s pods to be ready
wait_for_k8s_services() {
    local namespace="$1"
    local timeout="${2:-300}"  # 5 minutes default
    
    log_silent "Waiting for pods to be ready (timeout: ${timeout}s)..."
    
    local start_time=$(date +%s)
    local services=("mysql" "temporal" "config" "tracker" "manager" "worker" "provider")

    while true; do
        local current_time=$(date +%s)
        local elapsed=$((current_time - start_time))
        
        if [ $elapsed -gt $timeout ]; then
            print_error "Timeout waiting for services to be ready"
            return 1
        fi
        
        local all_ready=true
        for service in "${services[@]}"; do
            local pod=$(kubectl get pods -n "$namespace" -l "app.kubernetes.io/component=$service" \
                -o jsonpath='{.items[0].metadata.name}' 2>/dev/null || echo "")
            
            if [ -z "$pod" ]; then
                all_ready=false
                break
            fi
            
            local ready=$(kubectl get pod "$pod" -n "$namespace" \
                -o jsonpath='{.status.conditions[?(@.type=="Ready")].status}' 2>/dev/null || echo "False")
            
            if [ "$ready" != "True" ]; then
                all_ready=false
                break
            fi
        done
        
        if [ "$all_ready" = true ]; then
            log_silent "All pods are ready"
            return 0
        fi
        
        sleep 5
    done
}

# Get K8s service status
get_k8s_service_status() {
    local namespace="$1"
    
    echo ""
    echo -e "${BLUE}📊 Service Health & Status${NC}"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    
    # Get pods
    local pods=$(kubectl get pods -n "$namespace" -o json 2>/dev/null)
    
    if [ -z "$pods" ] || [ "$pods" = "null" ]; then
        echo "  No pods found in namespace: $namespace"
        return 1
    fi
    
    # Read internal ports from environment
    local provider_port="${XMCP_HTTP_PORT:-8080}"
    local manager_port="${CIS_MANAGER_PORT:-9090}"
    local config_port="${CIS_CONFIG_PORT:-8081}"
    local mysql_port="${MYSQL_PORT:-3306}"
    local tracker_port="${CIS_TRACKING_PORT:-9920}"
    
    # Parse and display pod status with uptime - process each pod once
    echo "$pods" | jq -r '.items[] | 
        "\(.metadata.labels."app.kubernetes.io/component" // "unknown")|\(.status.phase)|\([.status.conditions[]? | select(.type=="Ready")] | if length > 0 then .[0].status else "Unknown" end)|\(.status.startTime // "")"' | \
    while IFS='|' read -r component phase ready start_time; do
        # Map component names to display names and ports
        local display_name=""
        local port=""
        case "$component" in
            mysql)
                display_name="MySQL Database"
                port="$mysql_port"
                ;;
            config)
                display_name="AI Architect Config"
                port="$config_port"
                ;;
            manager)
                display_name="AI Architect Manager"
                port="$manager_port"
                ;;
            provider)
                display_name="AI Architect Provider"
                port="$provider_port"
                ;;
            tracker)
                display_name="AI Architect Tracker"
                port="$tracker_port"
                ;;
            temporal)
                # Hide Temporal from display — internal dependency
                continue
                ;;
            worker)
                display_name="AI Architect Worker"
                port=""
                ;;
            temporal-post-deploy|temporal-bootstrap|*-job)
                # Skip Helm hook Jobs - not a service
                continue
                ;;
            *)
                display_name=$(echo "$component" | awk '{print toupper(substr($0,1,1)) tolower(substr($0,2))}')
                port="unknown"
                ;;
        esac
        
        # Calculate uptime if pod is running
        local uptime_str=""
        if [ "$phase" = "Running" ] && [ -n "$start_time" ]; then
            local start_epoch=""
            local clean_time=$(echo "$start_time" | sed 's/\.[0-9]*Z$/Z/')
            
            if [[ "$OSTYPE" == "darwin"* ]]; then
                local time_no_z=$(echo "$clean_time" | sed 's/Z$//')
                start_epoch=$(date -u -j -f "%Y-%m-%dT%H:%M:%S" "$time_no_z" "+%s" 2>/dev/null || echo "")
            else
                start_epoch=$(date -d "$clean_time" "+%s" 2>/dev/null || echo "")
            fi
            
            if [ -n "$start_epoch" ] && [ "$start_epoch" -gt 0 ]; then
                local now=$(date +%s)
                local running_time=$((now - start_epoch))
                
                if [ "$running_time" -lt 60 ]; then
                    uptime_str="up ${running_time}s"
                elif [ "$running_time" -lt 3600 ]; then
                    uptime_str="up $((running_time / 60))m"
                else
                    uptime_str="up $((running_time / 3600))h"
                fi
            fi
        fi
        
        # Build port/uptime detail string
        local detail=""
        if [ -n "$uptime_str" ] && [ -n "$port" ]; then
            detail="(${uptime_str}, port ${port})"
        elif [ -n "$uptime_str" ]; then
            detail="(${uptime_str})"
        elif [ -n "$port" ]; then
            detail="(port ${port})"
        fi

        if [ "$phase" = "Running" ] && [ "$ready" = "True" ]; then
            printf "   %-29s ${GREEN}✅ Running${NC}      ${detail}\n" "$display_name"
        elif [ "$phase" = "Running" ] && [ "$ready" = "False" ]; then
            printf "   %-29s ${YELLOW}⏳ Starting${NC}     ${detail}\n" "$display_name"
        elif [ "$phase" = "Pending" ]; then
            printf "   %-29s ${YELLOW}📦 Pending${NC}      ${detail}\n" "$display_name"
        else
            printf "   %-29s ${RED}⚠️  $phase${NC}        ${detail}\n" "$display_name"
        fi
    done
    
    echo ""
}

# Kill port-forwards for this namespace
kill_port_forwards() {
    local namespace="$1"
    
    # Find all kubectl port-forward processes for this namespace
    # Match: -n namespace, --namespace=namespace, or -n=namespace
    local pids=$(ps aux | grep "kubectl port-forward" | grep -E "(-n |--namespace=|-n=)$namespace" | grep -v grep | awk '{print $2}')
    
    if [ -n "$pids" ]; then
        log_silent "Killing existing port-forwards..."
        echo "$pids" | xargs kill -9 2>/dev/null || true
        log_silent "Port-forwards terminated"
    fi
}
# Exported so the `bash -c bitoarch_k8s_recreate` subshell can tear down stale forwards.
export -f kill_port_forwards 2>/dev/null || true

# Uninstall Helm release
uninstall_helm_release() {
    local namespace="$1"
    local release_name="${2:-bitoarch}"
    local delete_pvcs="${3:-false}"

    # Pin to the cluster.yaml context BEFORE any cluster op: reset/uninstall may
    # run with a drifted current-context, and helm uninstall + PVC/PV delete + NFS
    # wipe must all hit the same cluster. Also covered by the CLI/setup entry pin,
    # but pinned here too so a direct caller is safe. No-op without a cluster.yaml
    # context. Source cluster-yaml.sh here so _cluster_wipe_static_nfs /
    # _pin_kube_context are DEFINED: they are not exported (the wipe's heredoc can't
    # cross the export -f boundary), so they must be sourced, not inherited -- else
    # the NFS wipe below silently skips and shared data is left behind on purge. Use
    # absolute anchors ($PLATFORM_DIR for reset/uninstall, $SCRIPT_DIR for recreate),
    # NOT ${BASH_SOURCE[0]} which is unreliable across the export -f / bash -c boundary.
    local _cy
    for _cy in "${PLATFORM_DIR:-}/scripts/lib/cluster-yaml.sh" \
               "${SCRIPT_DIR:-}/scripts/lib/cluster-yaml.sh" \
               "${SCRIPT_DIR:-}/../scripts/lib/cluster-yaml.sh" \
               "$(dirname "${BASH_SOURCE[0]}")/lib/cluster-yaml.sh"; do
        [ -f "$_cy" ] && { source "$_cy" 2>/dev/null || true; break; }
    done
    if command -v _pin_kube_context >/dev/null 2>&1; then
        _pin_kube_context || return 1
    fi

    # Kill any existing port-forwards first
    kill_port_forwards "$namespace"
    
    log_silent "Uninstalling Helm release: $release_name"
    
    if helm uninstall "$release_name" --namespace "$namespace" >> "$LOG_FILE" 2>&1; then
        log_silent "Helm release uninstalled"
    elif helm status "$release_name" --namespace "$namespace" >/dev/null 2>&1; then
        # Release still present after a failed uninstall — a real problem.
        print_warning "Failed to uninstall Helm release"
    else
        # Idempotent: already removed (an earlier purge step got it) — not an error.
        log_silent "Helm release ${release_name} already removed"
    fi
    
    # Delete PVCs if requested
    if [ "$delete_pvcs" = "true" ]; then
        log_silent "Deleting persistent volume claims..."
        # The on-demand wingman-populate Job is applied by the CLI, not helm (the
        # chart's own populate Job is removed by `helm uninstall` above). Its pod
        # mounts bitoarch-wingman and would block that PVC's deletion, so remove it
        # first so the PVC delete below doesn't time out.
        kubectl delete job ai-architect-wingman-populate-ondemand -n "$namespace" --ignore-not-found >> "$LOG_FILE" 2>&1 || true
        if kubectl delete pvc -n "$namespace" -l app.kubernetes.io/name=bitoarch --timeout=60s >> "$LOG_FILE" 2>&1; then
            log_silent "PVCs deleted"
        else
            print_warning "Failed to delete some PVCs, they may be in use"
        fi

        # Static NFS shared volumes are created outside Helm (cluster-yaml.sh),
        # so remove them by hand to match default-storage behavior: reset/
        # uninstall deletes the volume data. Wipe the share data, then drop the
        # PV objects. Best-effort and guarded, so Docker / non-static installs
        # (no such libs, no static PVs) are unaffected. Context pinned at the top.
        # Wipe the shared NFS subdirs we created (our data, made for the customer --
        # same intent as single-node purge deleting its volumes). The helper removes
        # only our subdirs, never the share/mount root, and self-no-ops when no nfs
        # share is set. If it is unavailable, say so loudly rather than silently
        # leaving data behind (a purge must never falsely claim everything is gone).
        if command -v _cluster_wipe_static_nfs >/dev/null 2>&1; then
            _cluster_wipe_static_nfs || true
        else
            print_warning "cluster-yaml.sh unavailable; static-NFS shared data (if any) was NOT wiped -- remove the created subdirs on the NFS share manually."
        fi
        kubectl delete pv -l volume-type=static-nfs --timeout=60s >> "$LOG_FILE" 2>&1 || true
    else
        print_warning "Persistent volumes preserved (data retained)"
        print_info "To delete data: kubectl delete pvc -n $namespace -l app.kubernetes.io/name=bitoarch"
    fi
}

# Get K8s logs
get_k8s_logs() {
    local namespace="$1"
    local component="$2"
    local follow="${3:-false}"
    
    if [ -z "$component" ]; then
        # All logs
        if [ "$follow" = "true" ]; then
            kubectl logs -n "$namespace" -l "app.kubernetes.io/name=bitoarch" --tail=100 -f --max-log-requests=10
        else
            kubectl logs -n "$namespace" -l "app.kubernetes.io/name=bitoarch" --tail=100
        fi
    else
        # Specific component
        if [ "$follow" = "true" ]; then
            kubectl logs -n "$namespace" -l "app.kubernetes.io/component=$component" --tail=100 -f
        else
            kubectl logs -n "$namespace" -l "app.kubernetes.io/component=$component" --tail=100
        fi
    fi
}

# Check if K8s deployment exists
check_k8s_deployment_exists() {
    local namespace="$1"
    
    if kubectl get namespace "$namespace" >/dev/null 2>&1; then
        if kubectl get deployment -n "$namespace" -l "app.kubernetes.io/name=bitoarch" 2>/dev/null | grep -q "ai-architect"; then
            return 0  # Deployment exists
        fi
    fi
    return 1  # Deployment doesn't exist
}

# Check if K8s services are running (not stopped/scaled to 0)
# Returns 0 if services are running, 1 if not
# Usage: check_k8s_services_running <namespace> || { handle_not_running; exit 0; }
check_k8s_services_running() {
    local namespace="$1"
    local replicas_raw replicas_sum=0 r

    # Single query for spec.replicas across all bitoarch deployments. Empty
    # output means no matching deployments exist (not installed / wrong
    # namespace); any non-empty output gives us the per-deployment replicas
    # to sum. Summing in pure bash avoids the bc dependency (not installed
    # by default on minimal Linux images) that produced a
    # "[: : integer expression expected" error when the pipeline returned
    # an empty string.
    replicas_raw=$(kubectl get deployment -n "$namespace" \
                   -l "app.kubernetes.io/name=bitoarch" \
                   -o jsonpath='{.items[*].spec.replicas}' 2>/dev/null)

    [ -z "$replicas_raw" ] && return 1

    for r in $replicas_raw; do
        case "$r" in
            ''|*[!0-9]*) ;;
            *) replicas_sum=$((replicas_sum + r)) ;;
        esac
    done

    [ "$replicas_sum" -eq 0 ] && return 1
    return 0
}

# -----------------------------------------------------------------------------
# bitoarch_k8s_recreate [force=true|false] [image_pull_policy=IfNotPresent|Always]
# -----------------------------------------------------------------------------
# Silent K8s restart / force-recreate. Used by the `bitoarch restart [--force]`
# CLI path to produce compact output (single progress_run + unified success
# block) matching the Docker lifecycle UX. All stdout/stderr is left attached
# to the caller; progress_run (the only call path) captures the stream into
# the file whose path it prints on failure.
#
#   force=true  -> regenerate helm values from .env-bitoarch, helm upgrade,
#                  then kubectl rollout restart (picks up env/image changes).
#   force=false -> kubectl rollout restart only (quick bounce).
#
# Single-roll design: force=true lets `helm upgrade --wait` do the rollout for
# every workload whose pod template changed, then bounces ONLY the workloads helm
# did not roll (generation unchanged — env-only/no-op cases). Two bounce phases,
# parallel within each: data plane (mysql, temporal) then apps.
#
# Temporal is a StatefulSet (helm-bitoarch/templates/16-temporal-statefulset.yaml)
# and gets a dedicated rollout branch; all other services are Deployments.
#
# Returns 0 on success, 1 on any helm/rollout failure.
# -----------------------------------------------------------------------------
bitoarch_k8s_recreate() {
    local force="${1:-false}"
    local image_pull_policy="${2:-IfNotPresent}"
    local namespace="bito-ai-architect"

    # Pin to the cluster.yaml context for EVERY restart path (not just --force)
    # so a multi-node bounce never rolls the wrong cluster on a drifted context.
    if ! command -v _pin_kube_context >/dev/null 2>&1; then
        source "${SCRIPT_DIR}/scripts/lib/cluster-yaml.sh" 2>/dev/null \
            || source "${SCRIPT_DIR}/../scripts/lib/cluster-yaml.sh" 2>/dev/null || true
    fi
    if command -v _pin_kube_context >/dev/null 2>&1; then
        _pin_kube_context || return 1
    fi

    # Pre-helm generation snapshot: lets the bounce below skip every workload
    # the helm upgrade already rolled (see the single-roll comment).
    # Plain "name gen" lines — /bin/bash on macOS is 3.2 (no associative arrays).
    local _gen_before=""
    if [ "$force" = "true" ]; then
        local _w _g
        for _w in ai-architect-mysql ai-architect-config ai-architect-tracker \
                  ai-architect-manager ai-architect-worker ai-architect-provider \
                  ai-architect-ingress-controller; do
            _g="$(kubectl get deployment "$_w" -n "$namespace" -o jsonpath='{.metadata.generation}' 2>/dev/null)"
            _gen_before="${_gen_before}${_w} ${_g}
"
        done
        _g="$(kubectl get statefulset ai-architect-temporal -n "$namespace" -o jsonpath='{.metadata.generation}' 2>/dev/null)"
        _gen_before="${_gen_before}ai-architect-temporal ${_g}
"
    fi

    if [ "$force" = "true" ]; then
        # Regenerate values + helm upgrade (picks up env changes from the
        # caller's apply_install_yaml_to_env_file + any manual .env edits).
        if ! command -v generate_k8s_values_from_env >/dev/null 2>&1; then
            source "${SCRIPT_DIR}/scripts/values-generator.sh" 2>/dev/null \
                || source "${SCRIPT_DIR}/../scripts/values-generator.sh" 2>/dev/null \
                || return 1
        fi
        # `restart --force` is the config-reload surface: source cluster-yaml.sh
        # (self-contained -- no install-yaml.sh) so the regen below re-applies
        # cluster.yaml (context/storage) and merges scheduling/replicas. Plain
        # restart skips this whole block (no re-read); `update` DOES re-read it --
        # it routes through bitoarch_k8s_update -> bitoarch_k8s_recreate "true",
        # the same force path.
        if ! command -v _cluster_merge_values_overlay >/dev/null 2>&1; then
            source "${SCRIPT_DIR}/scripts/lib/cluster-yaml.sh" 2>/dev/null \
                || source "${SCRIPT_DIR}/../scripts/lib/cluster-yaml.sh" 2>/dev/null || true
        fi
        generate_k8s_values_from_env "$image_pull_policy" || return 1

        local vf
        vf=$(command -v get_k8s_values_file >/dev/null 2>&1 && get_k8s_values_file)
        [ -z "$vf" ] && vf="${BITOARCH_CONFIG_DIR:-/usr/local/etc/bitoarch}/.bitoarch-values.yaml"

        local chart="${SCRIPT_DIR}/helm-bitoarch"
        [ -d "$chart" ] || chart="${SCRIPT_DIR}/../helm-bitoarch"
        # K8S_HELM_TIMEOUT covers image pulls + pod scheduling.
        # Seed the shelf BEFORE this apply, for the same reason deploy_helm_chart does:
        # `--wait` blocks on pod readiness and on the post-install hook, that hook waits
        # for the worker to attach as a Temporal poller, and the worker's
        # wait-for-wingman init blocks on an empty shelf. After a purge the PVC is gone
        # and the shelf starts empty, so seeding after the apply could never run -- helm
        # would not return, and `|| return 1` would abort first.
        local _wblib
        for _wblib in "${PLATFORM_DIR:-}/scripts/lib" \
                      "${SCRIPT_DIR:-}/scripts/lib" \
                      "${SCRIPT_DIR:-}/../scripts/lib" \
                      "${BITOARCH_CLI_DIR:-}/lib"; do
            [ -f "$_wblib/wingman-bundle.sh" ] || continue
            source "$_wblib/wingman-shelf.sh" 2>/dev/null || true
            source "$_wblib/wingman-bundle.sh" 2>/dev/null || true
            break
        done
        # `wingman_bundle_present` first, so a package with no bundle does no extra work
        # here at all -- not the claim lookup, and above all not the chart render.
        if type wingman_bundle_seed_before_helm >/dev/null 2>&1 && wingman_bundle_present 2>/dev/null; then
            # The claim normally still exists here, so no rendered manifest is needed.
            # Render one only for the post-purge case, where it has to be re-created.
            local _rendered=""
            if ! kubectl get pvc "${WINGMAN_BUNDLE_K8S_PVC:-bitoarch-wingman}" -n "$namespace" >/dev/null 2>&1; then
                _rendered="$(helm template bitoarch "$chart" --namespace "$namespace" --values "$vf" 2>/dev/null)"
            fi
            if ! wingman_bundle_seed_before_helm "$namespace" "$_rendered" bitoarch; then
                wingman_bundle_seed_failed
                return 1
            fi
        else
            log_silent "wingman bundle: seed helper unavailable (wingman-bundle.sh not found from any anchor); shelf not seeded before the recreate"
        fi

        helm upgrade --install bitoarch "$chart" \
            --namespace "$namespace" \
            --values "$vf" \
            --wait --timeout "${K8S_HELM_TIMEOUT:-10m}" || return 1

        # The shelf was seeded before the apply above.
    fi

    local k8s_rollout_timeout="${K8S_ROLLOUT_TIMEOUT:-25m}"

    # Single-roll bounce. When force=true the helm upgrade above ALREADY rolled
    # every workload whose pod template changed (image tags, pull policy, spec)
    # and --wait blocked on their readiness — restarting those again doubles the
    # whole rollout (the "update takes 3x a fresh install" bug). Workloads whose
    # template did NOT change (env-only ConfigMap edits, or a no-op upgrade)
    # keep their .metadata.generation — bounce exactly those.
    #
    # Two phases, parallel within each (was 4 serial phases):
    #   Phase 1  data plane: mysql (Deployment) + temporal (StatefulSet)
    #   Phase 2  apps: config tracker manager worker provider
    # NOT derived from BITOARCH_LIFECYCLE_SERVICES — a new lifecycle service must
    # be wired into a phase list below.
    local data_deployments=(ai-architect-mysql)
    local data_statefulsets=(ai-architect-temporal)
    # ingress-controller is base-chart-owned (18-ingress-controller.yaml) but only
    # rendered when the bundled ingress is enabled; _k8s_bounce_needed skips it when absent.
    local app_deployments=(ai-architect-config ai-architect-tracker ai-architect-manager ai-architect-worker ai-architect-provider ai-architect-ingress-controller)

    _k8s_workload_generation() {   # <kind> <name>
        kubectl get "$1" "$2" -n "$namespace" -o jsonpath='{.metadata.generation}' 2>/dev/null
    }
    _k8s_bounce_needed() {   # <kind> <name>  -> rc 0 when a rollout restart is required
        local after before
        after="$(_k8s_workload_generation "$1" "$2")"
        [ -n "$after" ] || return 1                             # workload absent (e.g. bundled ingress off): nothing to bounce
        [ "$force" = "true" ] || return 0                       # plain restart: always bounce what exists
        before="$(printf '%s' "$_gen_before" | awk -v w="$2" '$1 == w {print $2; exit}')"
        [ "$after" = "$before" ]                                # unchanged => helm did NOT roll it
    }

    _k8s_roll_phase() {   # <kind:name>...  restart + wait, all in parallel
        local w kind name pids=() any_fail=0 rc
        for w in "$@"; do
            kind="${w%%:*}"; name="${w#*:}"
            kubectl rollout restart "$kind" "$name" -n "$namespace" || return 1
        done
        for w in "$@"; do
            kind="${w%%:*}"; name="${w#*:}"
            kubectl rollout status "$kind" "$name" -n "$namespace" --timeout="$k8s_rollout_timeout" &
            pids+=($!)
        done
        for rc in "${pids[@]}"; do
            wait "$rc" || any_fail=1
        done
        [ "$any_fail" -eq 0 ]
    }

    local phase1=() phase2=() d
    for d in "${data_deployments[@]}";  do _k8s_bounce_needed deployment  "$d" && phase1+=("deployment:$d");  done
    for d in "${data_statefulsets[@]}"; do _k8s_bounce_needed statefulset "$d" && phase1+=("statefulset:$d"); done
    for d in "${app_deployments[@]}";   do _k8s_bounce_needed deployment  "$d" && phase2+=("deployment:$d");  done

    if [ "${#phase1[@]}" -gt 0 ]; then
        _k8s_roll_phase "${phase1[@]}" || return 1
    fi
    if [ "${#phase2[@]}" -gt 0 ]; then
        _k8s_roll_phase "${phase2[@]}" || return 1
    fi

    # Pods got new IPs on rollout — drop stale forwards; the CLI reopens them on demand.
    if command -v kill_port_forwards >/dev/null 2>&1; then
        kill_port_forwards "$namespace"
    fi
    return 0
}
export -f bitoarch_k8s_recreate 2>/dev/null || true

# bitoarch_k8s_update: pull+apply new image tags from versions-service-json.
# Used by `bitoarch update` on K8s.
bitoarch_k8s_update() {
    if command -v refresh_versions_from_service_json >/dev/null 2>&1; then
        local env_file
        env_file=$(command -v get_config_file >/dev/null 2>&1 && get_config_file)
        [ -n "$env_file" ] && refresh_versions_from_service_json "$env_file" || true
    fi
    # After version bump, force recreate picks up the new image tags.
    bitoarch_k8s_recreate "true" "Always"
}
export -f bitoarch_k8s_update 2>/dev/null || true
