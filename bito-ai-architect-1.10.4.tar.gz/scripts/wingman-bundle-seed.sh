#!/bin/sh
#
# Copyright (c) 2023-2026 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
#
# Places a packaged Wingman bundle onto the shared shelf. Runs INSIDE a container
# that mounts the shelf volume/PVC (docker one-shot / k8s Job), so it is POSIX sh
# + busybox-only (no jq, no bash builtins).
#
# Reads:
#   SRC   -- the extracted bundle payload (manifest.json, current/, skills/)
#   SHELF -- the shelf mount, e.g. /opt/bito/ai-architect/wingman
#
# Publishes atomically: stage under a dot-prefixed sibling, move the version dir
# into place, then flip `current`. The `.bundle_seeded` marker is written LAST so
# a partial seed never looks complete to the populate script's gate.
#
# Exits non-zero on failure. The caller decides how fatal that is -- an air-gapped
# install has no CDN to fall back on, so the installer treats it as fatal.

SRC="${SRC:-}"
SHELF="${SHELF:-/opt/bito/ai-architect/wingman}"

# Log to stderr so lines stream immediately (stdout is block-buffered when not a TTY).
log() { echo "[wingman-seed] $*" >&2; }

[ -n "$SRC" ] || { log "SRC is not set"; exit 1; }
[ -d "$SRC/current" ] || { log "payload has no current/ directory"; exit 1; }

# First non-empty string value for a top-level "key": "value" pair.
_json_str() { grep -o "\"$1\"[[:space:]]*:[[:space:]]*\"[^\"]*\"" "$2" 2>/dev/null | head -1 | sed 's/.*:[[:space:]]*"\([^"]*\)".*/\1/'; }

VER="$(_json_str wingman-version "$SRC/manifest.json")"
[ -n "$VER" ] || { log "bundle manifest has no wingman-version"; exit 1; }

BIN_NAME="${WINGMAN_BINARY_NAME:-bito-wingman}"
[ -f "$SRC/current/$BIN_NAME" ] || { log "payload has no ${BIN_NAME}"; exit 1; }

# tools/ is checked here, not only host-side: the host gate validates the bundle
# directory, this validates what survived the transfer. Publishing without tools/
# would still write the seed marker, and the marker then blocks every CDN sync --
# so a truncated payload would leave a shelf that never self-heals.
if [ ! -d "$SRC/current/tools" ] || [ -z "$(ls -A "$SRC/current/tools" 2>/dev/null)" ]; then
    log "payload has no tools/, or it is empty"
    exit 1
fi

# Nothing to do when the shelf already carries this exact bundle. Decided here
# rather than by the caller because not every entry point can read the marker
# before starting the container. Skipping matters beyond speed: republishing
# removes the live version directory before moving the new one in, and a consumer
# that resolves current/ inside that window finds no binary and tries to download.
if [ "$(cat "$SHELF/.bundle_seeded" 2>/dev/null)" = "$VER" ] && [ -x "$SHELF/$VER/$BIN_NAME" ]; then
    log "shelf already carries bundle ${VER}; nothing to do"
    exit 0
fi

# The shelf root must stay writable: Wingman creates sessions/, data/,
# history.json and certsDir under the published version dir at runtime as a
# non-root user, while this seed runs as root. On k8s the pod fsGroup also
# covers the volume, but it is applied at mount time and cannot be relied on
# for files a different pod writes afterwards.
mkdir -p "$SHELF" || { log "cannot create ${SHELF}"; exit 1; }
chmod 0777 "$SHELF" 2>/dev/null || true

STAGE="$SHELF/.bundleseed.$$"
rm -rf "$STAGE"
mkdir -p "$STAGE/$VER" || { log "cannot stage in ${SHELF}"; exit 1; }

if ! cp -R "$SRC/current/." "$STAGE/$VER/"; then
    log "failed staging the payload"
    rm -rf "$STAGE"
    exit 1
fi

chmod 0555 "$STAGE/$VER/$BIN_NAME" 2>/dev/null || true
[ -f "$STAGE/$VER/.tools_version" ] && chmod 0644 "$STAGE/$VER/.tools_version" 2>/dev/null
# The version dir itself must be writable for Wingman's runtime working files.
chmod 0777 "$STAGE/$VER" 2>/dev/null || true

# Replace any existing dir for this version, then move ours into place.
# ${VAR:?} so an empty expansion aborts instead of becoming the volume root: this
# runs as root on the mounted shelf.
chmod -R u+w "${SHELF:?}/${VER:?}" 2>/dev/null || true
rm -rf "${SHELF:?}/${VER:?}"
if ! mv "$STAGE/$VER" "$SHELF/$VER"; then
    log "publish move failed; the shelf is unchanged"
    rm -rf "$STAGE"
    exit 1
fi
rm -rf "$STAGE"

# Point current/ at the seeded version. current/ is a symlink when the platform
# owns it, but a service self-download leaves a REAL dir -- drop that so ln
# cannot nest inside it; ln -sfn re-points an existing symlink in place.
[ -L "$SHELF/current" ] || rm -rf "$SHELF/current"
if ! ln -sfn "$VER" "$SHELF/current"; then
    log "could not point current/ at ${VER}"
    exit 1
fi

# Base skills live beside the version dirs and are not versioned with the binary.
if [ -d "$SRC/skills" ]; then
    mkdir -p "$SHELF/skills" || { log "cannot create the skills shelf"; exit 1; }
    if ! cp -R "$SRC/skills/." "$SHELF/skills/"; then
        log "failed copying base skills"
        exit 1
    fi
    chmod -R a+rX "$SHELF/skills" 2>/dev/null || true
fi

# Written last: the populate gate reads this marker, so it must only appear once
# the shelf is actually complete.
printf '%s' "$VER" > "$SHELF/.bundle_seeded" || { log "could not write the seed marker"; exit 1; }
chmod 0644 "$SHELF/.bundle_seeded" 2>/dev/null || true

log "seeded Wingman ${VER} from the offline bundle"
exit 0
