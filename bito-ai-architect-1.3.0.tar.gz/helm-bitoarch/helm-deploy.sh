#!/bin/bash
# Helm Chart Deployment Script for CIS Platform
# Usage: ./helm-deploy.sh [dev|prod] [install|upgrade]

set -e

CHART_PATH="."
RELEASE_NAME="bito-ai-architect"
NAMESPACE="bito-ai-architect"
ENVIRONMENT="${1:-dev}"
ACTION="${2:-install}"

# Colors for output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${BLUE}=== CIS Platform Helm Deployment ===${NC}"
echo "Environment: $ENVIRONMENT"
echo "Action: $ACTION"
echo "Chart: $CHART_PATH"
echo "Release: $RELEASE_NAME"
echo "Namespace: $NAMESPACE"
echo ""

# Use generated values file from root directory
VALUES_FILE="../.bitoarch-values.yaml"

if [ ! -f "$VALUES_FILE" ]; then
    echo -e "${RED}✗ Generated values file not found: $VALUES_FILE${NC}"
    echo -e "${YELLOW}Please run: ./scripts/values-generator.sh${NC}"
    echo -e "${YELLOW}This will generate values from your .env-bitoarch configuration${NC}"
    exit 1
fi

echo -e "${BLUE}Using values file: $VALUES_FILE${NC}"
echo -e "${YELLOW}To view deployment values: cat $VALUES_FILE${NC}"
echo ""

# Template preview
echo -e "${BLUE}[1/4] Generating templates...${NC}"
helm template "$RELEASE_NAME" "$CHART_PATH" -f "$VALUES_FILE" > /tmp/cis-platform-manifests.yaml
echo -e "${GREEN}✓ Templates generated (saved to /tmp/cis-platform-manifests.yaml)${NC}"
echo ""

# Confirmation
echo -e "${YELLOW}This will ${ACTION} the following:${NC}"
echo "  - Helm Release: $RELEASE_NAME"
echo "  - Namespace: $NAMESPACE"
echo "  - Environment: $ENVIRONMENT"
echo "  - Values File: $VALUES_FILE"
echo ""
read -p "Continue? (y/n) " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo -e "${RED}Cancelled${NC}"
    exit 1
fi
echo ""

# Create namespace with Helm labels
echo -e "${BLUE}[2/4] Creating/updating namespace...${NC}"

# Check if namespace exists
if kubectl get namespace "$NAMESPACE" &> /dev/null; then
    echo "Namespace exists. Adding Helm labels..."
    # Add Helm labels to existing namespace
    kubectl patch namespace "$NAMESPACE" -p '{"metadata":{"labels":{"app.kubernetes.io/managed-by":"Helm"},"annotations":{"meta.helm.sh/release-name":"'"$RELEASE_NAME"'","meta.helm.sh/release-namespace":"'"$NAMESPACE"'"}}}' || true
    echo -e "${GREEN}✓ Namespace labels updated${NC}"
else
    echo "Creating new namespace..."
    # Create namespace with proper Helm labels
    kubectl create namespace "$NAMESPACE" \
        --dry-run=client -o yaml | \
        kubectl apply -f - && \
    kubectl patch namespace "$NAMESPACE" -p '{"metadata":{"labels":{"app.kubernetes.io/managed-by":"Helm"},"annotations":{"meta.helm.sh/release-name":"'"$RELEASE_NAME"'","meta.helm.sh/release-namespace":"'"$NAMESPACE"'"}}}'
    echo -e "${GREEN}✓ Namespace created with Helm labels${NC}"
fi
echo ""

# Deploy or upgrade
echo -e "${BLUE}[3/4] ${ACTION}ing Helm release...${NC}"
if [ "$ACTION" = "upgrade" ]; then
    helm upgrade "$RELEASE_NAME" "$CHART_PATH" \
        -f "$VALUES_FILE" \
        -n "$NAMESPACE" \
        --wait \
        --timeout 3m
else
    helm install "$RELEASE_NAME" "$CHART_PATH" \
        -f "$VALUES_FILE" \
        -n "$NAMESPACE" \
        --wait \
        --timeout 3m
fi
echo -e "${GREEN}✓ Helm release ${ACTION}d${NC}"
echo ""

# Verify deployment
echo -e "${BLUE}[4/4] Verifying deployment...${NC}"
echo ""
echo "Release Status:"
helm status "$RELEASE_NAME" -n "$NAMESPACE"
echo ""
echo "Pods:"
kubectl get pods -n "$NAMESPACE" -o wide
echo ""
echo "Services:"
kubectl get svc -n "$NAMESPACE"
echo ""
echo "PersistentVolumeClaims:"
kubectl get pvc -n "$NAMESPACE"
echo ""

echo -e "${GREEN}=== Deployment Complete ===${NC}"
echo ""
echo "Useful commands:"
echo "  View logs:        kubectl logs -l app=cis-platform -n $NAMESPACE"
echo "  Port forward:     kubectl port-forward svc/cis-manager 5002:5002 -n $NAMESPACE"
echo "  Check status:     helm status $RELEASE_NAME -n $NAMESPACE"
echo "  View values:      helm get values $RELEASE_NAME -n $NAMESPACE"
echo "  Rollback:         helm rollback $RELEASE_NAME -n $NAMESPACE"
echo "  Uninstall:        helm uninstall $RELEASE_NAME -n $NAMESPACE"
