#!/bin/bash
# Helm Chart Backup Script
# Usage: ./helm-backup.sh

RELEASE_NAME="bito-ai-architect"
NAMESPACE="bito-ai-architect"
BACKUP_DIR="./helm-backups"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)

# Colors
BLUE='\033[0;34m'
GREEN='\033[0;32m'
RED='\033[0;31m'
NC='\033[0m'

echo -e "${BLUE}=== CIS Platform Helm Backup ===${NC}"
echo "Backup Directory: $BACKUP_DIR"
echo "Timestamp: $TIMESTAMP"
echo ""

# Create backup directory
mkdir -p "$BACKUP_DIR/$TIMESTAMP"

# Backup Helm release values
echo -e "${BLUE}[1/4] Backing up Helm values...${NC}"
helm get values "$RELEASE_NAME" -n "$NAMESPACE" > "$BACKUP_DIR/$TIMESTAMP/values.yaml"
echo -e "${GREEN}✓ Values backed up${NC}"

# Backup Helm release manifests
echo -e "${BLUE}[2/4] Backing up Helm manifests...${NC}"
helm get manifest "$RELEASE_NAME" -n "$NAMESPACE" > "$BACKUP_DIR/$TIMESTAMP/manifests.yaml"
echo -e "${GREEN}✓ Manifests backed up${NC}"

# Backup database (MySQL)
echo -e "${BLUE}[3/4] Backing up MySQL database...${NC}"
MYSQL_POD=$(kubectl get pods -n "$NAMESPACE" -l component=mysql -o jsonpath='{.items[0].metadata.name}')
if [ -n "$MYSQL_POD" ]; then
    kubectl exec "$MYSQL_POD" -n "$NAMESPACE" -- \
        mysqldump -u root -p$MYSQL_ROOT_PASSWORD cis_db > "$BACKUP_DIR/$TIMESTAMP/mysql-dump.sql"
    echo -e "${GREEN}✓ MySQL database backed up${NC}"
else
    echo -e "${RED}✗ MySQL pod not found${NC}"
fi

# Backup PVCs metadata
echo -e "${BLUE}[4/4] Backing up PVC metadata...${NC}"
kubectl get pvc -n "$NAMESPACE" -o yaml > "$BACKUP_DIR/$TIMESTAMP/pvcs.yaml"
echo -e "${GREEN}✓ PVC metadata backed up${NC}"

echo ""
echo -e "${GREEN}=== Backup Complete ===${NC}"
echo ""
echo "Backup location: $BACKUP_DIR/$TIMESTAMP"
echo ""
echo "Restore commands:"
echo "  Restore values:   helm upgrade $RELEASE_NAME . -f $BACKUP_DIR/$TIMESTAMP/values.yaml"
echo "  Restore database: kubectl exec mysql-0 -n $NAMESPACE -- mysql -u root < $BACKUP_DIR/$TIMESTAMP/mysql-dump.sql"
echo ""
