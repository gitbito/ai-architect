# Bito's AI Architect - Customer Quick Start Guide

**One-page guide for deploying and using your on-premise Bito's AI Architect**

---

## 📦 Step 1: Extract Package

```bash
# Extract the downloaded package
tar -xzf bito-cis-*.tar.gz
cd bito-cis-*
```

---

## 🚀 Step 2: Run Setup

```bash
./setup.sh
```

**What you'll need:**
- **Bito API Key** (required) - Your Bito authentication key
- **Git Provider** - Select: GitLab (1), GitHub (2), or Bitbucket (3)
- **Git Access Token** (required) - Personal access token for your Git provider
- **Workspace ID** - Your workspace identifier [temporary - should be removed in final release]

**What setup does automatically:**
- ✅ Validates prerequisites (Docker, ports)
- ✅ Generates secure passwords and tokens
- ✅ Deploys all services (Provider, Manager, Config, MySQL)
- ✅ Installs `bitoarch` CLI tool globally
- ✅ Creates configuration files

**Setup complete!** You'll see your MCP URL and access token.

---

## ⚙️ Step 3: Add Repositories

Edit `.bitoarch-config.yaml` to add your repositories:

```yaml
repository:
  configured_repos:
    - namespace: your-org/repo-name-1
    - namespace: your-org/repo-name-2
    - namespace: your-org/repo-name-3
```

Then apply the configuration:

```bash
bitoarch add-repos .bitoarch-config.yaml
```

---

## 🔄 Step 4: Start Indexing

Trigger workspace synchronization to index your repositories:

```bash
bitoarch index-repos
```

Check indexing status:

```bash
bitoarch index-status
```

**Status indicators:**
- `in_progress` - Indexing is running
- `completed` - All repositories indexed
- `failed` - Check logs for errors

---

## 📊 Monitoring & Management

### Check Service Health
```bash
bitoarch status
```

### View Logs
```bash
bitoarch platform logs
# Or for specific service:
bitoarch platform logs cis-provider
```

### Test MCP Connection
```bash
bitoarch mcp-test
```

### View Available Tools
```bash
bitoarch mcp-tools
```

### Get Platform Information
```bash
bitoarch info
```

---

## 🔧 Common Operations

### Update Repository Configuration
```bash
# Edit .bitoarch-config.yaml to add/remove repositories
vim .bitoarch-config.yaml

# Apply changes
bitoarch update-repos .bitoarch-config.yaml

# Sync changes
bitoarch index-repos
```

### Check Current Configuration
```bash
bitoarch show-config
```

### Update Services 
```bash
# Force pulls images based on versions/service-versions.json and restart
./setup.sh --update
```

### Restart Services
```bash
./setup.sh --restart
```

### Stop Services
```bash
./setup.sh --stop
```

### View Service Status
```bash
./setup.sh --status
```

---

## 🔒 Security Notes

**Important credentials** (stored in `.env-bitoarch` file):
- `BITO_API_KEY` - Your Bito API Key
- `Git Access Token` - Git provider access token
- `BITO_MCP_ACCESS_TOKEN` - MCP server authentication (auto-generated)
- Database passwords (auto-generated)

**Keep these secure!** Back up your `.env-bitoarch` file safely.

### Rotate MCP Access Token
```bash
bitoarch rotate-mcp-token <new-token>
```

---

## 📍 Service Endpoints

After setup, services are available at:

| Service | Default Port | Endpoint |
|---------|--------------|----------|
| CIS Provider (MCP) | 8080 | http://localhost:8080/mcp |
| CIS Manager | 9090 | http://localhost:9090 |
| CIS Config | 8081 | http://localhost:8081 |
| MySQL Database | 3306 | localhost:3306 |

**Note:** Ports can be customized in `.env.default` before setup.

---

## 🆘 Troubleshooting

### Services Not Starting
```bash
# Check setup log
tail -f setup.log

# View service logs
bitoarch platform logs
```

### Port Conflicts
Before running setup, edit `.env.default`:
```bash
vim .env.default
# Change: CIS_PROVIDER_EXTERNAL_PORT, CIS_MANAGER_EXTERNAL_PORT, etc.
```

### Indexing Issues
```bash
# Check manager status
bitoarch index-status --raw

# View manager logs
bitoarch platform logs cis-manager
```

### Reset Installation
```bash
# Complete clean (removes all data and configuration)
./setup.sh --clean

# Then run setup again
./setup.sh
```

---

## 📚 Additional Resources

- **Setup Guide:** https://docs.bito.ai/ai-architect/install-ai-architect-self-hosted
- **How to Use AI Architect:** https://docs.bito.ai/ai-architect/install-ai-architect-self-hosted#how-to-use-ai-architect
- **CLI Reference:** `docs/CLI_REFERENCE.md`

---

## 🔄 Typical Workflow Summary

1. **Extract** → `tar -xzf bito-cis-*.tar.gz`
2. **Setup** → `./setup.sh` (provide API key, Git credentials)
3. **Configure** → Edit `.bitoarch-config.yaml` with your repositories
4. **Add Config** → `bitoarch add-repos .bitoarch-config.yaml`
5. **Index** → `bitoarch index-repos`
6. **Monitor** → `bitoarch index-status`, `bitoarch status`
7. **Use MCP** → `bitoarch mcp-test` and integrate with your tools

---

## ✅ Quick Health Check

Run this anytime to verify your platform:

```bash
# 1. Check all services are healthy
bitoarch status

# 2. Verify configuration
bitoarch show-config

# 3. Check indexing status
bitoarch index-status

# 4. Test MCP connectivity
bitoarch mcp-test
```

---

**Need help?** 
- Check service logs: `bitoarch platform logs`
- View setup log: `cat setup.log`
- Check platform info: `bitoarch info`

**That's it!** Your on-premise Bito's AI Architect is ready to provide repository intelligence through MCP.
