# Kubernetes Quick Start Guide

---

## Prerequisites

### Check Docker Resources

```bash
docker info --format 'CPUs={{.NCPU}} Mem={{.MemTotal}}'
```

**Required:** Minimum 4 CPUs and 8GB RAM

**If insufficient:** Increase Docker Desktop resources (Preferences → Resources) and restart Docker.

---

## Step 1: Install Tools

### macOS

```bash
brew install kind kubectl helm
```

### Linux

```bash
# KIND
curl -Lo ./kind https://kind.sigs.k8s.io/dl/v0.20.0/kind-linux-amd64
chmod +x ./kind
sudo mv ./kind /usr/local/bin/kind

# kubectl
curl -LO "https://dl.k8s.io/release/$(curl -L -s https://dl.k8s.io/release/stable.txt)/bin/linux/amd64/kubectl"
chmod +x kubectl
sudo mv kubectl /usr/local/bin/

# Helm
curl https://raw.githubusercontent.com/helm/helm/main/scripts/get-helm-3 | bash
```

---

## Step 2: Create KIND Cluster

```bash
kind create cluster --name bito-test
kind: Cluster
apiVersion: kind.x-k8s.io/v1alpha4
nodes:
- role: control-plane
  extraPortMappings:
  - containerPort: 80
    hostPort: 80
  - containerPort: 443
    hostPort: 443
EOF
```

**Note:** Services now use ClusterIP (secure, internal-only access). External access is via Ingress Controller on ports 80/443.

### Verify

```bash
kubectl cluster-info --context kind-bito-test
kubectl get nodes
```

---

## Step 3: Deploy

```bash
./setup.sh
```

**Select:** `Kubernetes`  
**Provide:** Bito API key and Git credentials

---

## Step 4: Verify

```bash
# Check services
bitoarch status

# Check health
bitoarch health

# Check pods
kubectl get pods -n bito-ai-architect
```

---

## Step 5: Access Services

**Option A: Via Ingress (Recommended for Production)**

```bash
# If Ingress Controller is configured with your domain
curl http://your-domain.com/api/provider/health
curl http://your-domain.com/api/manager/health
curl http://your-domain.com/api/config/health
curl http://your-domain.com/api/tracker/health
```

**Option B: Via Port-Forward (For Testing/Development)**

```bash
# Port-forward to provider service
kubectl port-forward svc/ai-architect-provider 8080:8080 -n bito-ai-architect
curl http://localhost:8080/health

# Port-forward to manager service
kubectl port-forward svc/ai-architect-manager 9090:9090 -n bito-ai-architect
curl http://localhost:9090/health

# Port-forward to config service
kubectl port-forward svc/ai-architect-config 8081:8081 -n bito-ai-architect
curl http://localhost:8081/health
```

**Option C: From Inside Cluster (Pod-to-Pod)**

```bash
# Run a temporary curl pod
kubectl run curl --image=curlimages/curl -it --rm --restart=Never -n bito-ai-architect -- \
  curl http://ai-architect-provider:8080/health
```

**Note:** Services now use ClusterIP for security. External access requires an Ingress Controller (nginx, traefik, etc.) configured by your cluster administrator.

---

## View Logs

```bash
# Kubernetes logs (live)
kubectl logs -n bito-ai-architect -l app.kubernetes.io/component=provider --tail=100 -f
kubectl logs -n bito-ai-architect -l app.kubernetes.io/component=manager --tail=100 -f

# OR local log files
tail -f var/logs/cis-provider/provider.log
tail -f var/logs/cis-manager/manager.log

# OR check via setup command for complete logs
./setup.sh --logs
```

---

## Debugging

### Check Pods

```bash
kubectl get pods -n bito-ai-architect
kubectl describe pod <pod-name> -n bito-ai-architect
```

### Access Pod

```bash
kubectl exec -it -n bito-ai-architect \
  $(kubectl get pod -n bito-ai-architect -l app.kubernetes.io/component=provider -o jsonpath='{.items[0].metadata.name}') \
  -- /bin/sh
```

### Common Issues

**CrashLoopBackOff:**
```bash
kubectl logs <pod-name> -n bito-ai-architect --previous
```

---

## Cleanup

```bash
# Remove deployment
./setup.sh --clean

# Stop cluster (keeps data)
docker stop bito-test-control-plane

# Delete cluster completely
kind delete cluster --name bito-test
```

---

## Upgrade

```bash
# Auto-detects Kubernetes deployment
./upgrade.sh
```

---

## More Commands

See `docs/CLI_REFERENCE.md` for all available commands.
