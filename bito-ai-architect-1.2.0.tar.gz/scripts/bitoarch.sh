#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
# Bito's AI Architect CLI
# Command-line interface for managing Bito's AI Architect services

# Get script directory (resolve symlinks)
SOURCE="${BASH_SOURCE[0]}"
while [ -h "$SOURCE" ]; do
    DIR="$( cd -P "$( dirname "$SOURCE" )" && pwd )"
    SOURCE="$(readlink "$SOURCE")"
    [[ $SOURCE != /* ]] && SOURCE="$DIR/$SOURCE"
done
DIR="$( cd -P "$( dirname "$SOURCE" )" && pwd )"

# SCRIPT_DIR should always point to the scripts directory
SCRIPT_DIR="$DIR"

# Source core libraries
source "${SCRIPT_DIR}/lib/cli-core.sh"
source "${SCRIPT_DIR}/lib/http-client.sh"
source "${SCRIPT_DIR}/lib/output-formatter.sh"

# Version
CLI_VERSION="1.0.0"

# Show main help
show_main_help() {
    cat << 'EOF'
╔═══════════════════════════════════════════════════════════════╗
║          Bito's AI Architect - Command Line Interface         ║
╚═══════════════════════════════════════════════════════════════╝

USAGE:
  bitoarch <command> [options]

CORE OPERATIONS:
  index-repos         Trigger workspace repository indexing
  index-status        Check indexing status
  index-repo-list     List all indexed repositories
  show-config         Show current configuration

REPOSITORY MANAGEMENT:
  add-repo <ns>       Add single repository by namespace
  remove-repo <ns>    Remove repository by namespace
  add-repos <file>    Load configuration from YAML file
  update-repos <file> Update configuration from YAML file
  repo-info <name>    Get detailed repository information

SERVICE OPERATIONS:
  status              Show all services status (docker ps-like)
  health              Check health of all services
  info                Get platform information

CONFIGURATION:
  update-api-key      Update Bito API key
  update-git-creds    Update Git provider credentials
  rotate-mcp-token    Rotate MCP access token

MCP OPERATIONS:
  mcp-test             Test MCP connection
  mcp-tools            List available MCP tools
  mcp-tool-info <name> Get detailed information about a specific MCP tool
  mcp-capabilities     Show MCP server capabilities
  mcp-resources        List MCP resources
  mcp-info             Show MCP configuration

GLOBAL OPTIONS:
  --format <fmt>      Output format: table, json (default: table)
  --verbose, -v       Verbose output
  --quiet, -q         Minimal output
  --help, -h          Show help

EXAMPLES:
  # Check service status
  bitoarch status

  # Trigger repository indexing
  bitoarch index-repos

  # Add a repository
  bitoarch add-repo myorg/myrepo

  # List all indexed repositories
  bitoarch index-repo-list

  # Check indexing status
  bitoarch index-status

USE 'bitoarch <command> --help' for command-specific help

ENVIRONMENT:
  Configuration: .env-bitoarch
  Logs: var/logs/

VERSION: 1.0.0
EOF
}

# Source output modules (needed by adapters)
source "${SCRIPT_DIR}/lib/output-blocks.sh"
source "${SCRIPT_DIR}/lib/output-fields.sh"

# Source adapters
source "${SCRIPT_DIR}/lib/adapters/provider-adapter.sh"
source "${SCRIPT_DIR}/lib/adapters/config-adapter.sh"
source "${SCRIPT_DIR}/lib/adapters/platform-adapter.sh"
source "${SCRIPT_DIR}/lib/adapters/manager-adapter.sh"

# Main command dispatcher
main() {
    # Check if no arguments
    if [ $# -eq 0 ]; then
        show_main_help
        exit 0
    fi
    
    # Load configuration
    load_env_config || exit 1
    
    # Get command
    local command="$1"
    shift
    
    # Check for help
    if [ "$command" = "--help" ] || [ "$command" = "-h" ]; then
        show_main_help
        exit 0
    fi
    
    if [ "$command" = "--version" ] || [ "$command" = "-v" ]; then
        echo "Bito AI Architect CLI v${CLI_VERSION}"
        exit 0
    fi
    
    # Route to direct commands or legacy service handlers
    case "$command" in
        # Core Operations
        index-repos)
            manager_sync_simple "$@"
            ;;
        index-status)
            manager_status "$@"
            ;;
        index-repo-list)
            provider_repo_list "$@"
            ;;
        show-config)
            config_repo_get "$@"
            ;;
        
        # Repository Management
        add-repo)
            if [ -f "$1" ]; then
                print_error "Use 'bitoarch add-repos <file>' for YAML files"
                exit 1
            fi
            config_repo_add_namespace "$@"
            ;;
        remove-repo)
            config_repo_remove_namespace "$@"
            ;;
        add-repos)
            config_repo_add_from_file "$@"
            ;;
        update-repos)
            config_repo_update_from_file "$@"
            ;;
        repo-info)
            provider_repo_info "$@"
            ;;
        
        # Service Operations
        status)
            platform_status "$@"
            ;;
        health)
            platform_health "$@"
            ;;
        info)
            platform_info "$@"
            ;;
        
        # Configuration
        update-api-key)
            platform_update_api_key "$@"
            ;;
        update-git-creds)
            platform_update_git_creds "$@"
            ;;
        rotate-mcp-token)
            platform_rotate_token "$@"
            ;;
        
        # MCP Operations
        mcp-test)
            provider_mcp_test "$@"
            ;;
        mcp-tools)
            provider_mcp_tools "$@"
            ;;
        mcp-tool-info)
            provider_mcp_tool_info "$@"
            ;;
        mcp-capabilities)
            provider_mcp_capabilities "$@"
            ;;
        mcp-resources)
            provider_mcp_resources "$@"
            ;;
        mcp-info)
            platform_mcp "$@"
            ;;
        
        *)
            print_error "Unknown command: $command"
            echo ""
            echo "Use 'bitoarch --help' to see available commands"
            exit 1
            ;;
    esac
}

# Execute main function
main "$@"
