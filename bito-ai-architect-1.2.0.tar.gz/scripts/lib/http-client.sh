#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
# CIS Platform CLI - HTTP Client
# Handles HTTP requests with retry logic and error handling

# Source core functions if not already loaded
if [ -z "$SCRIPT_DIR" ]; then
    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && cd ../.. && pwd)"
    source "${SCRIPT_DIR}/scripts/lib/cli-core.sh"
fi

# HTTP client settings
HTTP_TIMEOUT=30
HTTP_MAX_RETRIES=3
HTTP_RETRY_DELAY=2

# Make HTTP request with retry logic
http_request() {
    local method="$1"
    local url="$2"
    local auth_header="$3"
    local data="$4"
    local content_type="${5:-application/json}"
    
    require_command curl || return 1
    
    local attempt=1
    local response=""
    local http_code=""
    local temp_file=$(mktemp)
    
    while [ $attempt -le $HTTP_MAX_RETRIES ]; do
        # Build curl command
        local curl_cmd="curl -s -w '\n%{http_code}' -X $method"
        curl_cmd="$curl_cmd --connect-timeout $HTTP_TIMEOUT"
        curl_cmd="$curl_cmd -H 'Content-Type: $content_type'"
        
        if [ -n "$auth_header" ]; then
            curl_cmd="$curl_cmd -H '$auth_header'"
        fi
        
        if [ -n "$data" ] && [ "$method" != "GET" ]; then
            curl_cmd="$curl_cmd -d '$data'"
        fi
        
        curl_cmd="$curl_cmd '$url'"
        
        # Execute request
        response=$(eval $curl_cmd 2>"$temp_file")
        local curl_exit=$?
        
        # Extract HTTP code from last line
        http_code=$(echo "$response" | tail -1)
        response=$(echo "$response" | sed '$d')
        
        # Check for success
        if [ $curl_exit -eq 0 ] && [ "$http_code" -ge 200 ] && [ "$http_code" -lt 300 ]; then
            rm -f "$temp_file"
            echo "$response"
            return 0
        fi
        
        # Handle errors
        if [ $curl_exit -ne 0 ]; then
            if [ $attempt -lt $HTTP_MAX_RETRIES ]; then
                [ "$VERBOSE" = "true" ] && print_warning "Connection failed, retrying... (attempt $attempt/$HTTP_MAX_RETRIES)"
                sleep $HTTP_RETRY_DELAY
                attempt=$((attempt + 1))
                continue
            fi
        fi
        
        # Non-retriable error or max retries reached
        case "$http_code" in
            000)
                print_error "Connection failed: Unable to connect to $url"
                ;;
            401)
                print_error "Authentication failed: Invalid or missing token"
                ;;
            403)
                print_error "Authorization failed: Access denied"
                ;;
            404)
                print_error "Not found: Resource does not exist"
                ;;
            429)
                print_error "Rate limited: Too many requests"
                ;;
            5*)
                print_error "Server error: $http_code"
                ;;
            *)
                print_error "HTTP error: $http_code"
                ;;
        esac
        
        [ "$VERBOSE" = "true" ] && echo "Response: $response" >&2
        rm -f "$temp_file"
        return 1
    done
    
    rm -f "$temp_file"
    return 1
}

# Make generic MCP JSON-RPC request
# Takes the full JSON-RPC request as input to avoid shell escaping issues
mcp_request() {
    local request="$1"
    
    # Make request
    local auth_header="Authorization: Bearer $PROVIDER_TOKEN"
    local response=$(http_request "POST" "${PROVIDER_URL}/mcp" "$auth_header" "$request")
    local exit_code=$?
    
    if [ $exit_code -ne 0 ]; then
        return 1
    fi
    
    # Check for JSON-RPC error
    if require_command jq; then
        local error=$(echo "$response" | jq -r '.error // empty')
        if [ -n "$error" ]; then
            local error_message=$(echo "$error" | jq -r '.message')
            print_error "MCP Error: $error_message"
            [ "$VERBOSE" = "true" ] && echo "$error" | jq '.' >&2
            return 1
        fi
        
        # Extract result
        echo "$response" | jq -r '.result'
        return 0
    else
        # Fallback without jq
        echo "$response"
        return 0
    fi
}

# Make MCP tool call (wraps mcp_request for tools/call)
mcp_call() {
    local tool_name="$1"
    local arguments="${2:-{}}"
    
    # Build complete JSON-RPC request for tools/call
    local request
    if require_command jq; then
        request=$(jq -n --arg name "$tool_name" --argjson args "$arguments" \
            '{jsonrpc: "2.0", method: "tools/call", id: 1, params: {name: $name, arguments: $args}}')
    else
        request="{\"jsonrpc\":\"2.0\",\"method\":\"tools/call\",\"id\":1,\"params\":{\"name\":\"$tool_name\",\"arguments\":$arguments}}"
    fi
    
    # Use generic mcp_request
    mcp_request "$request"
}

# Make REST API call to CIS Config
config_api_call() {
    local method="$1"
    local endpoint="$2"
    local data="$3"
    
    local auth_header="X-API-Key: $CONFIG_API_KEY"
    local url="${CONFIG_URL}${endpoint}"
    
    http_request "$method" "$url" "$auth_header" "$data"
}

# Make REST API call to CIS Manager
manager_api_call() {
    local method="$1"
    local endpoint="$2"
    local data="$3"
    
    local auth_header="X-API-Key: $MANAGER_API_KEY"
    local url="${MANAGER_URL}${endpoint}"
    
    http_request "$method" "$url" "$auth_header" "$data"
}

# Health check for a service
health_check() {
    local service_url="$1"
    
    local response=$(http_request "GET" "${service_url}/health" "" "" "" 2>/dev/null)
    local exit_code=$?
    
    if [ $exit_code -eq 0 ]; then
        if require_command jq; then
            local status=$(echo "$response" | jq -r '.status // "ok"')
            if [ "$status" = "ok" ] || [ "$status" = "healthy" ]; then
                return 0
            fi
        else
            # Simple check without jq
            if echo "$response" | grep -q '"status".*"ok"'; then
                return 0
            fi
        fi
    fi
    
    return 1
}

# Export functions
export -f http_request
export -f mcp_request
export -f mcp_call
export -f config_api_call
export -f manager_api_call
export -f health_check
