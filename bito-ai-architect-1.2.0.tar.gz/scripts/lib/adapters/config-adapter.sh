#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
# Bito's AI Architect CLI - Config Adapter
# Handles AI Architect Config service commands

# Helper function to encrypt secrets for config payload
config_encrypt_secrets() {
    local bito_key="$1"
    local git_json="$2"
    
    # Get encryption key from environment
    if [ -z "$SECRETS_ENCRYPTION_KEY" ]; then
        print_error "SECRETS_ENCRYPTION_KEY not found in environment"
        return 1
    fi
    
    # Set LOG_FILE if not already set (required by setup-utils.sh)
    if [ -z "$LOG_FILE" ]; then
        export LOG_FILE="/dev/null"
    fi
    
    # Source encryption function from setup-utils
    if [ -f "${SCRIPT_DIR}/setup-utils.sh" ]; then
        source "${SCRIPT_DIR}/setup-utils.sh"
    elif [ -f "./scripts/setup-utils.sh" ]; then
        source "./scripts/setup-utils.sh"
    else
        print_error "setup-utils.sh not found"
        return 1
    fi
    
    # Encrypt BITO API key
    local encrypted_bito=$(encrypt_secret "$bito_key" "$SECRETS_ENCRYPTION_KEY")
    if [ $? -ne 0 ] || [ -z "$encrypted_bito" ]; then
        print_error "Failed to encrypt Bito API key"
        return 1
    fi
    
    # Extract and encrypt git access token
    local git_token=$(echo "$git_json" | jq -r '.access_token')
    if [ -z "$git_token" ] || [ "$git_token" = "null" ]; then
        print_error "Git access token not found"
        return 1
    fi
    
    local encrypted_token=$(encrypt_secret "$git_token" "$SECRETS_ENCRYPTION_KEY")
    if [ $? -ne 0 ] || [ -z "$encrypted_token" ]; then
        print_error "Failed to encrypt git access token"
        return 1
    fi
    
    # Update git JSON with encrypted token
    local encrypted_git=$(echo "$git_json" | jq --arg token "$encrypted_token" '.access_token = $token')
    
    # Output encrypted values as JSON for easy parsing
    jq -n \
        --arg bito "$encrypted_bito" \
        --argjson git "$encrypted_git" \
        '{bito_key: $bito, git_json: $git}'
}

# Config command handler
handle_config() {
    local command="$1"
    shift
    
    # Check for help
    if [ "$command" = "--help" ] || [ "$command" = "-h" ] || [ -z "$command" ]; then
        show_config_help
        return 0
    fi
    
    # Route to command
    case "$command" in
        repo)
            handle_config_repo "$@"
            ;;
        *)
            print_error "Unknown config command: $command"
            echo ""
            echo "Available commands: repo"
            echo "Use 'bitoarch --help' for more information"
            return 1
            ;;
    esac
}

# Repository configuration commands
handle_config_repo() {
    local command="$1"
    shift
    
    case "$command" in
        get)
            config_repo_get "$@"
            ;;
        add)
            # Check if argument looks like a namespace or a file
            if [ -n "$1" ] && [ ! -f "$1" ] && [[ "$1" =~ ^[a-zA-Z0-9_-]+/[a-zA-Z0-9_.-]+$ ]]; then
                # It's a namespace pattern (org/repo)
                config_repo_add_namespace "$@"
            elif [ -n "$1" ] && [ -f "$1" ]; then
                # It's a file
                config_repo_add_from_file "$@"

            else
                print_error "Invalid argument. Expected namespace (org/repo) or YAML file path"
                echo ""
                echo "Usage:"
                echo "  bitoarch add-repo <namespace>        # Add single repository"
                echo "  bitoarch add-repos <yaml-file>        # Add from YAML file"
                echo ""
                echo "Examples:"
                echo "  bitoarch add-repo myorg/myrepo"
                echo "  bitoarch add-repos .bitoarch-config.yaml"
                return 1
            fi
            ;;
        remove)
            config_repo_remove_namespace "$@"
            ;;
        update)
            config_repo_update_from_file "$@"
            ;;
        validate)
            config_repo_validate "$@"
            ;;
        --help|-h|"")
            cat << 'EOF'
REPOSITORY CONFIGURATION

COMMANDS:
  get                Get current configuration
  add <namespace>    Add single repository by namespace
  add <yaml-file>    Add repositories from YAML file
  remove <namespace> Remove repository by namespace
  update             Update configuration from YAML file
  validate           Validate configuration

Use 'bitoarch <command> --help' for command details
EOF
            ;;
        *)
            print_error "Unknown repo config command: $command"
            return 1
            ;;
    esac
}

# Get current configuration from cis-config
config_repo_get() {
    local show_raw=false
    
    # Parse options
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --help|-h)
                cat << 'EOF'
USAGE:
  bitoarch show-config [OPTIONS]

DESCRIPTION:
  Retrieve the current configuration from AI Architect Config service.
  Returns the complete workspace configuration including Git integration and repository settings.

OPTIONS:
  --raw    Show raw API response with secrets masked

EXAMPLES:
  bitoarch show-config
  bitoarch show-config --raw
  bitoarch show-config | jq '.repository'

NOTES:
  - Requires BITO_API_KEY to be set in environment
  - Connects to AI Architect Config service using CONFIG_URL from .env-bitoarch
  - Output is in JSON format
  - Secrets are automatically masked in output
EOF
                return 0
                ;;
            --raw)
                show_raw=true
                shift
                ;;
            *)
                shift
                ;;
        esac
    done
    
    # Get BITO API key from environment
    if [ -z "$BITO_API_KEY" ]; then
        print_error "BITO_API_KEY not found in environment"
        return 1
    fi
    
    # Get config external port from environment (default to 5003)
    local CONFIG_PORT="${CIS_CONFIG_EXTERNAL_PORT:-5003}"
    local CONFIG_URL="${CONFIG_URL:-http://localhost:${CONFIG_PORT}}"
    
    print_info "Fetching configuration from ${CONFIG_URL}..."
    
    # Make API call directly with curl
    local response=$(curl -s -w '\n%{http_code}' \
        -X GET \
        -H "Authorization: Bearer ${BITO_API_KEY}" \
        "${CONFIG_URL}/api/v1/config" 2>&1)
    
    # Extract HTTP code from last line
    local http_code=$(echo "$response" | tail -1)
    local body=$(echo "$response" | sed '$d')
    
    # Check HTTP code
    if [ "$http_code" -ge 200 ] && [ "$http_code" -lt 300 ]; then
        # Use appropriate render function based on --raw flag
        if [ "$show_raw" = "true" ]; then
            render_config_get_raw_block "$body"
        else
            render_config_get_summary_block "$body"
        fi
        return 0
    else
        render_config_get_failure_block "$http_code" "$body"
        return 1
    fi
}

# Update configuration from YAML file (generic YAML to JSON conversion with PUT method)
config_repo_update_from_file() {
    local yaml_file=""
    local show_raw=false
    
    # Parse options
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --help|-h)
                yaml_file="--help"
                shift
                ;;
            --raw)
                show_raw=true
                shift
                ;;
            *)
                if [ -z "$yaml_file" ] || [ "$yaml_file" = "--help" ]; then
                    yaml_file="$1"
                fi
                shift
                ;;
        esac
    done
    
    if [ "$yaml_file" = "--help" ] || [ -z "$yaml_file" ]; then
        cat << 'EOF'
USAGE:
  bitoarch update-repos <yaml-file>

DESCRIPTION:
  Update the configuration with settings from a YAML file.
  The entire YAML file is converted to JSON and sent to the Config API.

YAML FILE FORMAT:
  bito_access_key: ${BITO_API_KEY}
  integration:
    git:
      provider: ${GIT_PROVIDER}
      access_token: ${GIT_ACCESS_TOKEN}
  repository:
    repo_limit: 200
    repo_size_limit: "2GB"
    configured_repos:
      - namespace: "your-org/your-repo"
      - namespace: "another-org/another-repo"
  # Optional: LLM configuration
  # llm:
  #   providers:
  #     openai:
  #       model: "gpt-4"
  #       api_key: "${OPENAI_KEY}"

EXAMPLES:
  bitoarch update-repos .bitoarch-config.yaml 

NOTES:
  - This is a PUT operation - performs full configuration update
  - Entire YAML file is converted to JSON generically 
  - Environment variables are automatically substituted from .env-bitoarch
  - API accepts JSON with Content-Type: application/json
  - Requires 'jq' and 'yq' (or python3 with PyYAML) for parsing
  - See .bitoarch-config.yaml for format reference
EOF
        return 0
    fi
    
    if [ ! -f "$yaml_file" ]; then
        print_error "YAML file not found: $yaml_file"
        return 1
    fi
    
    # Verify we have jq for JSON processing
#    if ! require_command jq; then
#        print_error "jq is required for this operation"
#        print_info "Install jq: brew install jq (macOS) or apt-get install jq (Ubuntu)"
#        return 1
#    fi

    local json_data
#    json_data=$(build_cis_config_json  "$yaml_file")

    # ---- ENV validation --------------------------------------------------
    if [ -z "$BITO_API_KEY" ]; then
        print_error "BITO_API_KEY missing in environment"
        return 1
    fi

    # ---- Git integration JSON -------------------------------------------
    local git_raw_json
    git_raw_json=$(create_git_integration_json)
    if [ $? -ne 0 ] || [ -z "$git_raw_json" ]; then
        print_error "Failed generating Git integration JSON"
        return 1
    fi

    local git_json
    git_json=$(echo "$git_raw_json" | jq '.integration.git')


    # ---- LLM integration JSON -------------------------------------------
    local llm_raw_json
    llm_raw_json=$(create_llm_integration_json)
    if [ $? -ne 0 ] || [ -z "$llm_raw_json" ]; then
        print_error "Failed generating LLM provider JSON"
        return 1
    fi

    local llm_json
    llm_json=$(echo "$llm_raw_json" | jq '.llm')

    # ---- Extract configured repos ---------------------------------------
    local repos_json
    
    # Try yq first, fallback to python if not available
    if command -v yq >/dev/null 2>&1; then
        repos_json=$(yq -o=json '.repository.configured_repos // []' "$yaml_file")
    elif command -v python3 >/dev/null 2>&1 && python3 -c "import yaml" 2>/dev/null; then
        repos_json=$(python3 -c "import yaml, json; data=yaml.safe_load(open('$yaml_file')); print(json.dumps(data.get('repository', {}).get('configured_repos', [])))" 2>/dev/null)
    else
        print_error "YAML processing tool not found"
        print_error "Please install either:"
        print_info "  • yq: https://github.com/mikefarah/yq#install"
        print_info "  • python3 with PyYAML: pip3 install PyYAML"
        return 1
    fi
    
    if [ -z "$repos_json" ] || [ "$repos_json" = "null" ]; then
        print_error "Failed reading repository.configured_repos from $yaml_file"
        return 1
    fi

    # Normalize: convert plain string → {"namespace": "..."}
    repos_json=$(echo "$repos_json" | jq '
        map(
            if type=="string" then { "namespace": . }
            else .
            end
        )
    ')

    # ---- Build final JSON payload ----------------------------------------
    local json_data=$(jq -n \
        --arg access "$BITO_API_KEY" \
        --argjson git "$git_json" \
        --argjson llm "$llm_json" \
        --argjson repos "$repos_json" \
        '
        {
            bito_access_key: $access,
            integration: { git: $git },
            repository: { configured_repos: $repos },
            llm: $llm
        }
        '
    )

    if [ $? -ne 0 ] || [ -z "$json_data" ]; then
        print_error "Failed to build repository configuration JSON"
        return 1
    fi
    
    # Get config external port from environment (default to 5003)
    local CONFIG_PORT="${CIS_CONFIG_EXTERNAL_PORT:-5003}"
    local CONFIG_URL="${CONFIG_URL:-http://localhost:${CONFIG_PORT}}"
    
    print_info "Updating configuration at ${CONFIG_URL}..."
    
    # Send JSON to API with Bearer authentication using PUT method
    local response=$(curl -s -w '\n%{http_code}' \
        -X PUT \
        -H "Authorization: Bearer $BITO_API_KEY" \
        -H "Content-Type: application/json" \
        -d "$json_data" \
        "${CONFIG_URL}/api/v1/config" 2>&1)
    
    # Extract HTTP code from last line
    local http_code=$(echo "$response" | tail -1)
    local body=$(echo "$response" | sed '$d')
    
    # Use render functions for output
    if [ "$http_code" -ge 200 ] && [ "$http_code" -lt 300 ]; then
        render_config_add_success_block "$body" "$show_raw"
        render_config_add_next_steps
        return 0
    else
        render_config_add_failure_block "$http_code" "$body"
        return 1
    fi
}


# Validate repository configuration
config_repo_validate() {
    local repo_name="$1"
    
    if [ -z "$repo_name" ]; then
        print_error "Usage: bitoarch validate-repo <repo-name>"
        return 1
    fi
    
    print_info "Validating configuration for '$repo_name'..."
    
    # Make API call
    local response=$(config_api_call "POST" "/api/v1/config/repositories/${repo_name}/validate")
    if [ $? -ne 0 ]; then
        return 1
    fi
    
    # Parse validation result
    if require_command jq; then
        local valid=$(echo "$response" | jq -r '.valid // false')
        if [ "$valid" = "true" ]; then
            print_success "Configuration is valid"
        else
            print_error "Configuration validation failed"
            echo "$response" | jq -r '.errors[] | "  • \(.)"'
            return 1
        fi
    else
        echo "$response"
    fi
}

# Add repositories from YAML file (generic YAML to JSON conversion)
config_repo_add_from_file() {
    local yaml_file=""
    local show_raw=false

    # Parse options
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --help|-h)
                yaml_file="--help"
                shift
                ;;
            --raw)
                show_raw=true
                shift
                ;;
            *)
                if [ -z "$yaml_file" ] || [ "$yaml_file" = "--help" ]; then
                    yaml_file="$1"
                fi
                shift
                ;;
        esac
    done

    if [ "$yaml_file" = "--help" ] || [ -z "$yaml_file" ]; then
        cat << 'EOF'
USAGE:
  bitoarch add-repos <yaml-file>

DESCRIPTION:
  Configure AI Architect with repository settings from a YAML file.
  The entire YAML file is converted to JSON and sent to the Config API.
  Environment variables in the YAML file (${VARIABLE}) are automatically replaced.

YAML FILE FORMAT:
  repository:
    configured_repos:
      - namespace: "your-org/your-repo"
      - namespace: "another-org/another-repo"

ENV PROPERTIES:
  - Update git properties from env file
  - Update llm propertied from llm config env file

EXAMPLES:
  bitoarch add-repos .bitoarch-config.yaml
  bitoarch add-repos /path/to/custom-config.yaml

NOTES:
  - Entire YAML file is converted to JSON generically (no field-specific code)
  - Environment variables are automatically substituted from .env-bitoarch
  - API accepts JSON with Content-Type: application/json
  - Requires 'jq' and 'yq' (or python3 with PyYAML) for parsing
  - See .bitoarch-config.yaml for complete example
EOF
        return 0
    fi

    if [ ! -f "$yaml_file" ]; then
        print_error "YAML file not found: $yaml_file"
        return 1
    fi

#    Verify we have jq for JSON processing
#    if ! require_command jq; then
#        print_error "jq is required for this operation"
#        print_info "Install jq: brew install jq (macOS) or apt-get install jq (Ubuntu)"
#        return 1
#    fi

    local json_data
#    json_data=$(build_cis_config_json  "$yaml_file")

    # ---- ENV validation --------------------------------------------------
    if [ -z "$BITO_API_KEY" ]; then
        print_error "BITO_API_KEY missing in environment"
        return 1
    fi

    # ---- Git integration JSON -------------------------------------------
    local git_raw_json
    git_raw_json=$(create_git_integration_json)
    if [ $? -ne 0 ] || [ -z "$git_raw_json" ]; then
        print_error "Failed generating Git integration JSON"
        return 1
    fi

    local git_json
    git_json=$(echo "$git_raw_json" | jq '.integration.git')

    # ---- LLM integration JSON -------------------------------------------
    local llm_raw_json
    llm_raw_json=$(create_llm_integration_json)
    if [ $? -ne 0 ] || [ -z "$llm_raw_json" ]; then
        print_error "Failed generating LLM provider JSON"
        return 1
    fi

    local llm_json
    llm_json=$(echo "$llm_raw_json" | jq '.llm')

    # ---- Extract configured repos ---------------------------------------
    local repos_json
    
    # Try yq first, fallback to python if not available
    if command -v yq >/dev/null 2>&1; then
        repos_json=$(yq -o=json '.repository.configured_repos // []' "$yaml_file")
    elif command -v python3 >/dev/null 2>&1 && python3 -c "import yaml" 2>/dev/null; then
        repos_json=$(python3 -c "import yaml, json; data=yaml.safe_load(open('$yaml_file')); print(json.dumps(data.get('repository', {}).get('configured_repos', [])))" 2>/dev/null)
    else
        print_error "YAML processing tool not found"
        print_error "Please install either:"
        print_info "  • yq: https://github.com/mikefarah/yq#install"
        print_info "  • python3 with PyYAML: pip3 install PyYAML"
        return 1
    fi
    
    if [ -z "$repos_json" ] || [ "$repos_json" = "null" ]; then
        print_error "Failed reading repository.configured_repos from $yaml_file"
        return 1
    fi

    # Normalize: convert plain string → {"namespace": "..."}
    repos_json=$(echo "$repos_json" | jq '
        map(
            if type=="string" then { "namespace": . }
            else .
            end
        )
    ')

    # ---- Build final JSON payload ----------------------------------------
    local json_data=$(jq -n \
        --arg access "$BITO_API_KEY" \
        --argjson git "$git_json" \
        --argjson llm "$llm_json" \
        --argjson repos "$repos_json" \
        '
        {
            bito_access_key: $access,
            integration: { git: $git },
            repository: { configured_repos: $repos },
            llm: $llm
        }
        '
    )

    if [ $? -ne 0 ] || [ -z "$json_data" ]; then
        print_error "Failed to build repository configuration JSON"
        return 1
    fi

    local CONFIG_PORT="${CIS_CONFIG_EXTERNAL_PORT:-5003}"
    local CONFIG_URL="${CONFIG_URL:-http://localhost:${CONFIG_PORT}}"

    log_silent "Sending configuration to ${CONFIG_URL}..."

    # Send JSON to API with Bearer authentication
    local response=$(curl -s -w '\n%{http_code}' \
        -X POST \
        -H "Authorization: Bearer $BITO_API_KEY" \
        -H "Content-Type: application/json" \
        -d "$json_data" \
        "${CONFIG_URL}/api/v1/config" 2>&1)

    # Extract HTTP code from last line
    local http_code=$(echo "$response" | tail -1)
    local body=$(echo "$response" | sed '$d')

    # Use render functions for output
    if [ "$http_code" -ge 200 ] && [ "$http_code" -lt 300 ]; then
        render_config_add_success_block "$body" "$show_raw"
        render_config_add_next_steps
        return 0
    else
        render_config_add_failure_block "$http_code" "$body"
        return 1
    fi
}

# Add repositories from YAML file (generic YAML to JSON conversion)
config_repo_add_from_file_from_setup() {
    local yaml_file=""
    local show_raw=false
    
    # Parse options
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --help|-h)
                yaml_file="--help"
                shift
                ;;
            --raw)
                show_raw=true
                shift
                ;;
            *)
                if [ -z "$yaml_file" ] || [ "$yaml_file" = "--help" ]; then
                    yaml_file="$1"
                fi
                shift
                ;;
        esac
    done
    
    if [ "$yaml_file" = "--help" ] || [ -z "$yaml_file" ]; then
        cat << 'EOF'
USAGE:
  bitoarch add-repos <yaml-file>

DESCRIPTION:
  Configure AI Architect with repository settings from a YAML file.
  The entire YAML file is converted to JSON and sent to the Config API.
  Environment variables in the YAML file (${VARIABLE}) are automatically replaced.

YAML FILE FORMAT:
  repository:
    configured_repos:
      - namespace: "your-org/your-repo"
      - namespace: "another-org/another-repo"

ENV PROPERTIES:
  - Update git properties from env file
  - Update llm propertied from llm config env file

EXAMPLES:
  bitoarch add-repos .bitoarch-config.yaml 
  bitoarch add-repos /path/to/custom-config.yaml

NOTES:
  - Entire YAML file is converted to JSON generically (no field-specific code)
  - Environment variables are automatically substituted from .env-bitoarch
  - API accepts JSON with Content-Type: application/json
  - Requires 'jq' and 'yq' (or python3 with PyYAML) for parsing
  - See .bitoarch-config.yaml for complete example
EOF
        return 0
    fi
    
    if [ ! -f "$yaml_file" ]; then
        print_error "YAML file not found: $yaml_file"
        return 1
    fi
    
#    Verify we have jq for JSON processing
#    if ! require_command jq; then
#        print_error "jq is required for this operation"
#        print_info "Install jq: brew install jq (macOS) or apt-get install jq (Ubuntu)"
#        return 1
#    fi
    
    local json_data
#    json_data=$(build_cis_config_json  "$yaml_file")

    # ---- ENV validation --------------------------------------------------
    if [ -z "$BITO_API_KEY" ]; then
        log_silent "BITO_API_KEY missing in environment"
        return 1
    fi

    # ---- Git integration JSON -------------------------------------------
    local git_raw_json
    git_raw_json=$(create_git_integration_json)
    if [ $? -ne 0 ] || [ -z "$git_raw_json" ]; then
        log_silent "Failed generating Git integration JSON"
        return 1
    fi

    local git_json
    git_json=$(echo "$git_raw_json" | jq '.integration.git')


    # ---- LLM integration JSON -------------------------------------------
    local llm_raw_json
    llm_raw_json=$(create_llm_integration_json)
    if [ $? -ne 0 ] || [ -z "$llm_raw_json" ]; then
        log_silent "Failed generating LLM provider JSON"
        return 1
    fi

    local llm_json
    llm_json=$(echo "$llm_raw_json" | jq '.llm')



    # ---- Extract configured repos ---------------------------------------
    local repos_json
    
    # Try yq first, fallback to python if not available
    if command -v yq >/dev/null 2>&1; then
        repos_json=$(yq -o=json '.repository.configured_repos // []' "$yaml_file")
    elif command -v python3 >/dev/null 2>&1 && python3 -c "import yaml" 2>/dev/null; then
        repos_json=$(python3 -c "import yaml, json; data=yaml.safe_load(open('$yaml_file')); print(json.dumps(data.get('repository', {}).get('configured_repos', [])))" 2>/dev/null)
    else
        log_silent "YAML processing tool not found - need yq or python3+PyYAML"
        return 1
    fi
    
    if [ -z "$repos_json" ] || [ "$repos_json" = "null" ]; then
        log_silent "Failed reading repository.configured_repos from $yaml_file"
        return 1
    fi

    # Normalize: convert plain string → {"namespace": "..."}
    repos_json=$(echo "$repos_json" | jq '
        map(
            if type=="string" then { "namespace": . }
            else .
            end
        )
    ')
    log_silent "Configured repo details: $repos_json"

    # ---- Build final JSON payload ----------------------------------------
    local json_data=$(jq -n \
        --arg access "$BITO_API_KEY" \
        --argjson git "$git_json" \
        --argjson llm "$llm_json" \
        --argjson repos "$repos_json" \
        '
        {
            bito_access_key: $access,
            integration: { git: $git },
            repository: { configured_repos: $repos },
            llm: $llm
        }
        '
    )

    if [ $? -ne 0 ] || [ -z "$json_data" ]; then
        print_error "Failed to build repository configuration JSON"
        return 1
    fi
    
    local CONFIG_PORT="${CIS_CONFIG_EXTERNAL_PORT:-5003}"
    local CONFIG_URL="${CONFIG_URL:-http://localhost:${CONFIG_PORT}}"
    
    log_silent "Sending configuration to ${CONFIG_URL}..."
    
    # Send JSON to API with Bearer authentication
    local response=$(curl -s -w '\n%{http_code}' \
        -X POST \
        -H "Authorization: Bearer $BITO_API_KEY" \
        -H "Content-Type: application/json" \
        -d "$json_data" \
        "${CONFIG_URL}/api/v1/config" 2>&1)
    
    # Extract HTTP code from last line
    local http_code=$(echo "$response" | tail -1)
    local body=$(echo "$response" | sed '$d')

    log_silent "Successfully configuration to ${CONFIG_URL}..."
    
    # Use render functions for output
    if [ "$http_code" -ge 200 ] && [ "$http_code" -lt 300 ]; then
        render_config_add_success_block "$body" "$show_raw"
        return 0
    else
        render_config_add_failure_block "$http_code" "$body"
        return 1
    fi
}

# Add single repository by namespace
config_repo_add_namespace() {
    local namespace="$1"
    
    # Parse options
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --help|-h)
                cat << 'EOF'
USAGE:
  bitoarch add-repo <namespace>

DESCRIPTION:
  Add a single repository to the configured repositories list.
  Uses the API endpoint to add the repository by namespace and updates the local .bitoarch-config.yaml file.

ARGUMENTS:
  namespace    Repository namespace in format: org/repo

EXAMPLE:
  bitoarch add-repo myorg/myrepo

NOTES:
  - Requires BITO_API_KEY to be set in environment
  - Repository will be added to existing configuration
  - Updates both API and local .bitoarch-config.yaml file
  - Use 'bitoarch show-config' to verify changes
EOF
                return 0
                ;;
            *)
                namespace="$1"
                shift
                ;;
        esac
    done
    
    if [ -z "$namespace" ]; then
        print_error "Usage: bitoarch add-repo <namespace>"
        echo ""
        echo "Example: bitoarch add-repo myorg/myrepo"
        return 1
    fi
    
    # Validate namespace format
    if ! [[ "$namespace" =~ ^[a-zA-Z0-9_-]+/[a-zA-Z0-9_.-]+$ ]]; then
        print_error "Invalid namespace format. Expected: org/repo"
        echo ""
        echo "Example: myorg/myrepo"
        return 1
    fi
    
    # Get required environment variables
    if [ -z "$BITO_API_KEY" ]; then
        print_error "BITO_API_KEY not found in environment"
        return 1
    fi
    
    # Get config external port from environment (default to 5003 which maps to internal 9910)
    local CONFIG_PORT="${CIS_CONFIG_EXTERNAL_PORT:-5003}"
    local CONFIG_URL="${CONFIG_URL:-http://localhost:${CONFIG_PORT}}"
    
    print_info "Adding repository '${namespace}'..."
    
    # Create JSON payload
    local json_payload=$(jq -n \
        --arg ns "$namespace" \
        '{repositories: [{namespace: $ns}]}')
    
    # Make API call (uses raw token without Bearer prefix)
    local response=$(curl -s -w '\n%{http_code}' \
        -X POST \
        -H "accept: application/json" \
        -H "Content-Type: application/json" \
        -H "Authorization: ${BITO_API_KEY}" \
        -d "$json_payload" \
        "${CONFIG_URL}/api/v1/config/repository/add" 2>&1)
    
    # Extract HTTP code from last line
    local http_code=$(echo "$response" | tail -1)
    local body=$(echo "$response" | sed '$d')
    
    # Check HTTP code and render appropriate output
    if [ "$http_code" -ge 200 ] && [ "$http_code" -lt 300 ]; then
        # API call succeeded, now update local .bitoarch-config.yaml 
        local config_file=".bitoarch-config.yaml"
        if [ -f "$config_file" ]; then
            print_info "Updating local .bitoarch-config.yaml file..."
            
            # Check if namespace already exists in .bitoarch-config.yaml 
            local exists=false
            if command -v yq >/dev/null 2>&1; then
                if yq eval ".repository.configured_repos[] | select(.namespace == \"${namespace}\")" "$config_file" 2>/dev/null | grep -q "namespace"; then
                    exists=true
                fi
            elif command -v python3 >/dev/null 2>&1; then
                if python3 -c "import yaml; data=yaml.safe_load(open('$config_file')); print(any(r.get('namespace') == '$namespace' for r in data.get('repository', {}).get('configured_repos', [])))" 2>/dev/null | grep -q "True"; then
                    exists=true
                fi
            fi
            
            if [ "$exists" = "false" ]; then
                # Add namespace to .bitoarch-config.yaml 
                if command -v yq >/dev/null 2>&1; then
                    # Use yq to add the namespace
                    yq eval ".repository.configured_repos += [{\"namespace\": \"${namespace}\"}]" -i "$config_file" 2>/dev/null
                    if [ $? -eq 0 ]; then
                        print_success "Updated .bitoarch-config.yaml with new repository"
                    else
                        print_warning "API call succeeded but failed to update .bitoarch-config.yaml automatically"
                        print_info "Please manually add '- namespace: ${namespace}' to .bitoarch-config.yaml "
                    fi
                elif command -v python3 >/dev/null 2>&1; then
                    # Use python to add the namespace
                    python3 << EOF
import yaml
try:
    with open('$config_file', 'r') as f:
        data = yaml.safe_load(f)
    
    if 'repository' not in data:
        data['repository'] = {}
    if 'configured_repos' not in data['repository']:
        data['repository']['configured_repos'] = []
    
    data['repository']['configured_repos'].append({'namespace': '$namespace'})
    
    with open('$config_file', 'w') as f:
        yaml.dump(data, f, default_flow_style=False, sort_keys=False)
    
    print("SUCCESS")
except Exception as e:
    print(f"ERROR: {e}")
EOF
                    if [ $? -eq 0 ]; then
                        print_success "Updated .bitoarch-config.yaml with new repository"
                    else
                        print_warning "API call succeeded but failed to update .bitoarch-config.yaml automatically"
                        print_info "Please manually add '- namespace: ${namespace}' to .bitoarch-config.yaml "
                    fi
                else
                    print_warning "yq or python3 not available - .bitoarch-config.yaml not updated"
                    print_info "Please manually add '- namespace: ${namespace}' to .bitoarch-config.yaml under repository.configured_repos"
                fi
            else
                print_info "Repository already exists in .bitoarch-config.yaml "
            fi
        else
            print_warning ".bitoarch-config.yaml not found - only API updated"
            print_info "Repository added to API but .bitoarch-config.yaml not found for local update"
        fi
        
        render_repo_add_success_block "$namespace" "$body"
        return 0
    else
        render_repo_add_failure_block "$namespace" "$http_code" "$body"
        return 1
    fi
}

# Remove repository by namespace
config_repo_remove_namespace() {
    local namespace="$1"
    
    # Parse options
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --help|-h)
                cat << 'EOF'
USAGE:
  bitoarch remove-repo <namespace>

DESCRIPTION:
  Remove a repository from the configured repositories list.
  Uses the API endpoint to remove the repository by namespace and updates the local .bitoarch-config.yaml file.

ARGUMENTS:
  namespace    Repository namespace in format: org/repo

EXAMPLE:
  bitoarch remove-repo myorg/myrepo

NOTES:
  - Requires BITO_API_KEY to be set in environment
  - Repository will be removed from configuration
  - Updates both API and local .bitoarch-config.yaml file
  - Use 'bitoarch show-config' to verify changes
EOF
                return 0
                ;;
            *)
                namespace="$1"
                shift
                ;;
        esac
    done
    
    if [ -z "$namespace" ]; then
        print_error "Usage: bitoarch remove-repo <namespace>"
        echo ""
        echo "Example: bitoarch remove-repo myorg/myrepo"
        return 1
    fi
    
    # Validate namespace format
    if ! [[ "$namespace" =~ ^[a-zA-Z0-9_-]+/[a-zA-Z0-9_.-]+$ ]]; then
        print_error "Invalid namespace format. Expected: org/repo"
        echo ""
        echo "Example: myorg/myrepo"
        return 1
    fi
    
    # Get required environment variables
    if [ -z "$BITO_API_KEY" ]; then
        print_error "BITO_API_KEY not found in environment"
        return 1
    fi
    
    # Get config external port from environment (default to 5003 which maps to internal 9910)
    local CONFIG_PORT="${CIS_CONFIG_EXTERNAL_PORT:-5003}"
    local CONFIG_URL="${CONFIG_URL:-http://localhost:${CONFIG_PORT}}"
    
    print_info "Removing repository '${namespace}'..."
    
    # Create JSON payload
    local json_payload=$(jq -n \
        --arg ns "$namespace" \
        '{repositories: [{namespace: $ns}]}')
    
    # Make API call (uses raw token without Bearer prefix)
    local response=$(curl -s -w '\n%{http_code}' \
        -X POST \
        -H "accept: application/json" \
        -H "Content-Type: application/json" \
        -H "Authorization: ${BITO_API_KEY}" \
        -d "$json_payload" \
        "${CONFIG_URL}/api/v1/config/repository/remove" 2>&1)
    
    # Extract HTTP code from last line
    local http_code=$(echo "$response" | tail -1)
    local body=$(echo "$response" | sed '$d')
    
    # Check HTTP code and render appropriate output
    if [ "$http_code" -ge 200 ] && [ "$http_code" -lt 300 ]; then
        # API call succeeded, now update local .bitoarch-config.yaml 
        local config_file=".bitoarch-config.yaml"
        if [ -f "$config_file" ]; then
            print_info "Updating local .bitoarch-config.yaml file..."
            
            # Check if namespace exists in .bitoarch-config.yaml 
            local exists=false
            if command -v yq >/dev/null 2>&1; then
                if yq eval ".repository.configured_repos[] | select(.namespace == \"${namespace}\")" "$config_file" 2>/dev/null | grep -q "namespace"; then
                    exists=true
                fi
            elif command -v python3 >/dev/null 2>&1; then
                if python3 -c "import yaml; data=yaml.safe_load(open('$config_file')); print(any(r.get('namespace') == '$namespace' for r in data.get('repository', {}).get('configured_repos', [])))" 2>/dev/null | grep -q "True"; then
                    exists=true
                fi
            fi
            
            if [ "$exists" = "true" ]; then
                # Remove namespace from .bitoarch-config.yaml 
                if command -v yq >/dev/null 2>&1; then
                    # Use yq to remove the namespace
                    yq eval "del(.repository.configured_repos[] | select(.namespace == \"${namespace}\"))" -i "$config_file" 2>/dev/null
                    if [ $? -eq 0 ]; then
                        print_success "Updated .bitoarch-config.yaml - removed repository"
                    else
                        print_warning "API call succeeded but failed to update .bitoarch-config.yaml automatically"
                        print_info "Please manually remove '- namespace: ${namespace}' from .bitoarch-config.yaml "
                    fi
                elif command -v python3 >/dev/null 2>&1; then
                    # Use python to remove the namespace
                    python3 << EOF
import yaml
try:
    with open('$config_file', 'r') as f:
        data = yaml.safe_load(f)
    
    if 'repository' in data and 'configured_repos' in data['repository']:
        data['repository']['configured_repos'] = [
            r for r in data['repository']['configured_repos']
            if r.get('namespace') != '$namespace'
        ]
    
    with open('$config_file', 'w') as f:
        yaml.dump(data, f, default_flow_style=False, sort_keys=False)
    
    print("SUCCESS")
except Exception as e:
    print(f"ERROR: {e}")
EOF
                    if [ $? -eq 0 ]; then
                        print_success "Updated .bitoarch-config.yaml - removed repository"
                    else
                        print_warning "API call succeeded but failed to update .bitoarch-config.yaml automatically"
                        print_info "Please manually remove '- namespace: ${namespace}' from .bitoarch-config.yaml "
                    fi
                else
                    print_warning "yq or python3 not available - .bitoarch-config.yaml not updated"
                    print_info "Please manually remove '- namespace: ${namespace}' from .bitoarch-config.yaml under repository.configured_repos"
                fi
            else
                print_info "Repository not found in .bitoarch-config.yaml "
            fi
        else
            print_warning ".bitoarch-config.yaml not found - only API updated"
            print_info "Repository removed from API but .bitoarch-config.yaml not found for local update"
        fi
        
        render_repo_remove_success_block "$namespace" "$body"
        return 0
    else
        render_repo_remove_failure_block "$namespace" "$http_code" "$body"
        return 1
    fi
}

build_cis_config_json() {
    local yaml_file="$1"

    # ---- ENV validation --------------------------------------------------
    if [ -z "$BITO_API_KEY" ]; then
        log_silent "BITO_API_KEY missing in environment"
        return 1
    fi

    # ---- Git integration JSON -------------------------------------------
    local git_raw_json
    git_raw_json=$(create_git_integration_json)
    if [ $? -ne 0 ] || [ -z "$git_raw_json" ]; then
        log_silent "Failed generating Git integration JSON"
        return 1
    fi

    local git_json
    git_json=$(echo "$git_raw_json" | jq '.integration.git')


    # ---- LLM integration JSON -------------------------------------------
    local llm_raw_json
    llm_raw_json=$(create_llm_integration_json)
    if [ $? -ne 0 ] || [ -z "$llm_raw_json" ]; then
        log_silent "Failed generating LLM provider JSON"
        return 1
    fi

    local llm_json
    llm_json=$(echo "$llm_raw_json" | jq '.llm')



    # ---- Extract configured repos ---------------------------------------
    local repos_json
    
    # Try yq first, fallback to python if not available
    if command -v yq >/dev/null 2>&1; then
        repos_json=$(yq -o=json '.repository.configured_repos // []' "$yaml_file")
    elif command -v python3 >/dev/null 2>&1 && python3 -c "import yaml" 2>/dev/null; then
        repos_json=$(python3 -c "import yaml, json; data=yaml.safe_load(open('$yaml_file')); print(json.dumps(data.get('repository', {}).get('configured_repos', [])))" 2>/dev/null)
    else
        log_silent "YAML processing tool not found - need yq or python3+PyYAML"
        return 1
    fi
    
    if [ -z "$repos_json" ] || [ "$repos_json" = "null" ]; then
        log_silent "Failed reading repository.configured_repos from $yaml_file"
        return 1
    fi

    # Normalize: convert plain string → {"namespace": "..."}
    repos_json=$(echo "$repos_json" | jq '
        map(
            if type=="string" then { "namespace": . }
            else .
            end
        )
    ')
    log_silent "Configured repo details: $repos_json"

    # ---- Build final JSON payload ----------------------------------------
    local final_json=$(jq -n \
            --arg access "$BITO_API_KEY" \
            --argjson git $git_json \
            --argjson llm $llm_json \
            --argjson repos $repos_json \
            '
            {
                bito_access_key: $access,
                integration: { git: $git },
                repository: { configured_repos: $repos },
                llm: $llm
            }
            '
    )

    echo $final_json
}

# Utility function to create Git integration JSON from environment variables
create_git_integration_json() {
    # Get Git configuration from environment variables
    local git_provider="${GIT_PROVIDER:-}"
    local git_token="${GIT_ACCESS_TOKEN:-}"
    local git_domain="${GIT_DOMAIN_URL:-}"
    local git_user="${GIT_USER:-}"

    # Validate required environment variables
    if [ -z "$git_provider" ]; then
        print_error "GIT_PROVIDER not found in environment"
        return 1
    fi
    
    if [ -z "$git_token" ]; then
        print_error "GIT_ACCESS_TOKEN not found in environment"
        return 1
    fi
    
    # Create JSON structure using jq
#    if ! require_command jq; then
#        print_error "jq is required for JSON creation"
#        print_info "Install jq: brew install jq (macOS) or apt-get install jq (Ubuntu)"
#        return 1
#    fi
    
    # Build the Git integration JSON
    local git_json
    if [ -n "$git_domain" ]; then
        # Include domain URL if provided
        git_json=$(jq -n \
            --arg provider "$git_provider" \
            --arg token "$git_token" \
            --arg domain "$git_domain" \
            --arg user "$git_user" \
            '{
                "integration": {
                    "git": {
                        "provider": $provider,
                        "access_token": $token,
                        "domain": $domain,
                        "auth_type": "personal_access_token",
                        "username": $user
                    }
                }
            }')
    else
        # Standard structure without domain URL
        git_json=$(jq -n \
            --arg provider "$git_provider" \
            --arg token "$git_token" \
            --arg user "$git_user" \
            '{
                "integration": {
                    "git": {
                        "provider": $provider,
                        "access_token": $token,
                        "auth_type": "personal_access_token",
                        "username": $user
                    }
                }
            }')
    fi
    
    # Validate JSON creation
    if [ $? -ne 0 ] || [ -z "$git_json" ] || [ "$git_json" = "null" ]; then
        log_silent "Failed to create Git integration JSON"
        return 1
    fi
    
    # Output the JSON
    echo "$git_json"
    return 0
}

# Creates LLM integration JSON from environment variables
# Reads LLM_DEFAULT_PROVIDER, ANTHROPIC_API_TOKEN, OPENAI_API_TOKEN, GROK_API_TOKEN
# Returns JSON structure with provider configuration
create_llm_integration_json() {

    # Get LLM configuration from environment
    local default_provider="${LLM_DEFAULT_PROVIDER:-bito}"
    local anthropic_token="${ANTHROPIC_API_TOKEN}"
    local openai_token="${OPENAI_API_TOKEN}"
    local xai_grok_token="${XAI_API_TOKEN}"
    
#    print_info "Creating LLM integration JSON with default provider: $default_provider"

    # Start building the providers object
    local providers_json="{}"
    
    # Add Anthropic provider if token exists
    if [ -n "$anthropic_token" ]; then
#        print_info "Adding Anthropic provider configuration"
        providers_json=$(echo "$providers_json" | jq --arg token "$anthropic_token" '. + {"anthropic": {"api_key": $token}}')
    fi
    
    # Add OpenAI provider if token exists
    if [ -n "$openai_token" ]; then
#        print_info "Adding OpenAI provider configuration"
        providers_json=$(echo "$providers_json" | jq --arg token "$openai_token" '. + {"openai": {"api_key": $token}}')
    fi
    
    # Add Grok provider if token exists
    if [ -n "$xai_grok_token" ]; then
#        print_info "Adding Grok provider configuration"
        providers_json=$(echo "$providers_json" | jq --arg token "$xai_grok_token" '. + {"xai": {"api_key": $token}}')
    fi
    
    # Create the final LLM JSON structure
    local llm_json
    llm_json=$(jq -n \
        --arg default_provider "$default_provider" \
        --argjson providers "$providers_json" \
        '{
            "llm": {
                "provider_configured": $default_provider,
                "providers": $providers
            }
        }')
    
    # Validate JSON creation
    if [ $? -ne 0 ] || [ -z "$llm_json" ] || [ "$llm_json" = "null" ]; then
        log_silent "Failed to create LLM integration JSON"
        return 1
    fi
    
    # Output the JSON
    echo "$llm_json"
    return 0
}



# Export functions
# Git Repositories API call
# Calls the /api/v1/git/repositories endpoint with environment variables
# TODO: not using it, due to log and console print message.
git_repositories_api() {
    log_silent "Calling Git Repositories API..."
    
    # Source environment variables
#    source_env_file
    
    # Check for required environment variables
    if [ -z "$GIT_PROVIDER" ]; then
        print_error "GIT_PROVIDER environment variable is required"
        return 1
    fi
    
    if [ -z "$GIT_ACCESS_TOKEN" ]; then
        print_error "GIT_ACCESS_TOKEN environment variable is required"
        return 1
    fi
    
    if [ -z "$BITO_API_KEY" ]; then
        print_error "BITO_API_KEY environment variable is required"
        return 1
    fi
    
    # Check if jq is available
    if ! command -v jq >/dev/null 2>&1; then
        print_error "jq is required but not installed. Please install jq first."
        print_error "Install with: brew install jq (macOS) or apt-get install jq (Ubuntu)"
        return 1
    fi
    
    # Build configuration URL
    local CONFIG_PORT="${CIS_CONFIG_EXTERNAL_PORT:-5003}"
    local CONFIG_URL="${CONFIG_URL:-http://localhost:${CONFIG_PORT}}"
    local API_ENDPOINT="${CONFIG_URL}/api/v1/git/repositories"
    
    # Set domain (empty string if not provided)
    local GIT_DOMAIN="${GIT_DOMAIN_URL:-}"
    
    log_silent "Calling API endpoint: $API_ENDPOINT"
    log_silent "Using provider: $GIT_PROVIDER"
    
    # Build JSON payload using jq
    local json_payload
    json_payload=$(jq -n \
        --arg provider "$GIT_PROVIDER" \
        --arg domain "$GIT_DOMAIN" \
        --arg token "$GIT_ACCESS_TOKEN" \
        --arg username "" \
        '{
            "provider": $provider,
            "domain": $domain,
            "token": $token,
            "username": $username
        }')
    
    if [ $? -ne 0 ]; then
        log_silent "Failed to create JSON payload"
        return 1
    fi
    
    # Make the API call
    local response
    local http_code
    
    response=$(curl -s -w '\n%{http_code}' \
        --location "$API_ENDPOINT" \
        --header "Authorization: $BITO_API_KEY" \
        --header "Content-Type: application/json" \
        --data "$json_payload" 2>/dev/null)
    
    if [ $? -ne 0 ]; then
        log_silent "Failed to make API call to $API_ENDPOINT"
        return 1
    fi
    
    # Extract HTTP code and response body
    log_silent "Raw response: $response"

    http_code="${response: -3}"
    response_body="${response:0:${#response}-3}"

    log_silent "Body extracted: ${#response_body} bytes"
    
    # Check HTTP status code
    case "$http_code" in
        2*)
            log_silent "Git repositories API call successful (HTTP $http_code) Response: $response_body"
            echo "$response_body" >&2
            return 0
            ;;
        4*)
            log_silent "Client error (HTTP $http_code): $response_body"
            return 1
            ;;
        5*)
            log_silent "Server error (HTTP $http_code): $response_body"
            return 1
            ;;
        *)
            log_silent "Unexpected HTTP status code: $http_code"
            log_silent "Response: $response_body"
            return 1
            ;;
    esac
}


# Create repository configuration YAML from Git repositories API response
create_repo_config_from_api() {
    set +e
    log_silent "Creating repository configuration from Git repositories API..."
    
    # Source environment variables
#    source_env_file

    log_silent "Calling Git Repositories API..."

    # Check for required environment variables
    if [ -z "$GIT_PROVIDER" ]; then
        log_silent "GIT_PROVIDER environment variable is required"
        return 1
    fi

    if [ -z "$GIT_ACCESS_TOKEN" ]; then
        log_silent "GIT_ACCESS_TOKEN environment variable is required"
        return 1
    fi

    if [ -z "$BITO_API_KEY" ]; then
        log_silent "BITO_API_KEY environment variable is required"
        return 1
    fi

    # Check if jq is available
    if ! command -v jq >/dev/null 2>&1; then
        log_silent "jq is required but not installed. Please install jq first."
        log_silent "Install with: brew install jq (macOS) or apt-get install jq (Ubuntu)"
        return 1
    fi

    # Build configuration URL
    local CONFIG_PORT="${CIS_CONFIG_EXTERNAL_PORT:-5003}"
    local CONFIG_URL="${CONFIG_URL:-http://localhost:${CONFIG_PORT}}"
    local API_ENDPOINT="${CONFIG_URL}/api/v1/git/repositories"

    # Set domain (empty string if not provided)
    local GIT_DOMAIN="${GIT_DOMAIN_URL:-}"

    log_silent "Calling API endpoint: $API_ENDPOINT"
    log_silent "Using provider: $GIT_PROVIDER"

    # Build JSON payload using jq
    local json_payload
    json_payload=$(jq -n \
        --arg provider "$GIT_PROVIDER" \
        --arg domain "$GIT_DOMAIN" \
        --arg token "$GIT_ACCESS_TOKEN" \
        --arg username "$GIT_USER" \
        '{
            "provider": $provider,
            "domain": $domain,
            "token": $token,
            "username": $username
        }')

    if [ $? -ne 0 ]; then
        log_silent "Failed to create JSON payload"
        return 1
    fi

    # Make the API call
    local response
    local http_code

    response=$(curl -s -w '\n%{http_code}' \
        --location "$API_ENDPOINT" \
        --header "Authorization: $BITO_API_KEY" \
        --header "Content-Type: application/json" \
        --data "$json_payload" 2>/dev/null)

    if [ $? -ne 0 ]; then
        log_silent "Failed to make API call to $API_ENDPOINT"
        return 1
    fi

    # Extract HTTP code and response body
    log_silent "Raw response: $response"

    http_code="${response: -3}"
    response_body="${response:0:${#response}-3}"

    log_silent "Body extracted: ${#response_body} bytes"

    # Check HTTP status code
    case "$http_code" in
        2*)
            log_silent "Git repositories API call successful (HTTP $http_code) Response: $response_body"
            ;;
        4*)
            log_silent "Client error (HTTP $http_code): $response_body"
            ;;
        5*)
            log_silent "Server error (HTTP $http_code): $response_body"
            ;;
        *)
            log_silent "Unexpected HTTP status code: $http_code"
            log_silent "Response: $response_body"
            ;;
    esac
    
    # Call the Git repositories API
    local api_response
#    api_response=$(git_repositories_api)
    api_response=$response_body


    log_silent "API response: $api_response"
    
    if [ $? -ne 0 ]; then
        print_error "Failed to get repositories from API"
        return 1
    fi
    
    # Check if jq is available
    if ! command -v jq >/dev/null 2>&1; then
        log_silent "jq is required but not installed. Please install jq first."
        log_silent "Install with: brew install jq (macOS) or apt-get install jq (Ubuntu)"
        return 1
    fi
    
    # Parse the API response and validate structure
    local success
    success=$(echo "$api_response" | jq -r '.success // false' 2>/dev/null)
    
    if [ "$success" != "true" ]; then
        log_silent "API response indicates failure or invalid JSON structure"
        log_silent "Response: $api_response"
        return 1
    fi

    log_silent "API response indicates success"

    # Extract repositories array
    local repositories
    repositories=$(echo "$api_response" | jq -r '.repositories // []' 2>/dev/null)
    
    if [ "$repositories" = "[]" ] || [ "$repositories" = "null" ]; then
        log_warn "No repositories found in API response"
        repositories="[]"
    fi
    
    # Count repositories
    local repo_count
    repo_count=$(echo "$repositories" | jq 'length' 2>/dev/null)
    
    log_silent "Found $repo_count repositories to configure"
    
    # Create the .bitoarch-config.yaml file
    local config_file=".bitoarch-config.yaml"
    
    # Start building the YAML content
    cat > "$config_file" << 'EOF'
repository:
  configured_repos:
EOF
    
    # Add each repository namespace
    if [ "$repo_count" -gt 0 ]; then
        echo "$repositories" | jq -r '.[] | select(.full_name != null) | .full_name' | while read -r full_name; do
            if [ -n "$full_name" ]; then
                echo "    - namespace: $full_name" >> "$config_file"
                log_silent "Added repository: $full_name"
            fi
        done
    else
        # Add empty array if no repositories
        echo "    []" >> "$config_file"
    fi
    
    # Verify file was created successfully
    if [ -f "$config_file" ]; then
        log_silent "Successfully created $config_file with $repo_count repositories"
        echo ""
        print_info "📝 $repo_count repositories have been added for indexing. You can review your configuration file here: $(pwd)/$config_file."
        echo ""

        # Show the generated content
        log_silent "Generated configuration:"
#        cat "$config_file"

        return 0
    else
        log_silent "Failed to create $config_file"
        return 1
    fi
    set -e
}

export -f handle_config
export -f handle_config_repo
export -f config_repo_get
export -f config_repo_add_from_file
export -f config_repo_update_from_file
export -f config_repo_add_namespace
export -f config_repo_remove_namespace
export -f create_git_integration_json
export -f create_llm_integration_json
export -f git_repositories_api
export -f create_repo_config_from_api
