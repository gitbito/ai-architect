#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
set -e

# Usage: ./replace-env-key.sh <env-file> <KEY> <VALUE>

ENV_FILE="$1"
KEY="$2"
VALUE="$3"

# Validate inputs
if [ -z "$ENV_FILE" ] || [ -z "$KEY" ] || [ -z "$VALUE" ]; then
  echo "Usage: $0 <env-file> <KEY> <VALUE>"
  exit 1
fi

if [ ! -f "$ENV_FILE" ]; then
  echo "Error: File '$ENV_FILE' does not exist."
  exit 1
fi

# If key exists: replace it
if grep -q -E "^${KEY}=" "$ENV_FILE"; then
  sed -i "s|^${KEY}=.*|${KEY}=${VALUE}|" "$ENV_FILE"
  echo "Updated: ${KEY}=${VALUE}"
else
  # Key doesn't exist: append at end
  echo "${KEY}=${VALUE}" >> "$ENV_FILE"
  echo "Added: ${KEY}=${VALUE}"
fi