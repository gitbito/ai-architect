#!/bin/bash
set -e
# Helm Chart Cleanup Script
# Usage: ./helm-cleanup.sh

RELEASE_NAME="bito-ai-architect"
NAMESPACE="bito-ai-architect"

# Colors
BLUE='\033[0;34m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

echo -e "${BLUE}=== CIS Platform Helm Cleanup ===${NC}"
echo ""
echo -e "${YELLOW}WARNING: This will delete all resources!${NC}"
echo "Release: $RELEASE_NAME"
echo "Namespace: $NAMESPACE"
echo ""
read -p "Are you sure? (y/n) " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo -e "${RED}Cancelled${NC}"
    exit 1
fi
echo ""

# Uninstall Helm release
echo -e "${BLUE}[1/3] Uninstalling Helm release...${NC}"
helm uninstall "$RELEASE_NAME" -n "$NAMESPACE"
echo -e "${GREEN}✓ Release uninstalled${NC}"
echo ""

# Delete PVCs
echo -e "${BLUE}[2/3] Deleting PersistentVolumeClaims...${NC}"
kubectl delete pvc --all -n "$NAMESPACE" --ignore-not-found=true
echo -e "${GREEN}✓ PVCs deleted${NC}"
echo ""

# Delete namespace
echo -e "${BLUE}[3/3] Deleting namespace...${NC}"
kubectl delete namespace "$NAMESPACE" --ignore-not-found=true
echo -e "${GREEN}✓ Namespace deleted${NC}"
echo ""

echo -e "${GREEN}=== Cleanup Complete ===${NC}"
