# Bito's AI Architect CLI - Command Reference

Quick reference for managing your Bito's AI Architect installation.

**Note:** After installation, the `bitoarch` command is available globally. You can also use `./scripts/bitoarch-cli.sh` if needed.

---

## Core Operations

| Command | Description | Example                                    |
|---------|-------------|--------------------------------------------|
| `bitoarch index-repos` | Trigger workspace repository indexing | Simple index without parameters            |
| `bitoarch index-status` | Check indexing status | View progress and state                    |
| `bitoarch index-repo-list` | List all repositories | `bitoarch index-repo-list --status active` |
| `bitoarch show-config` | Show current configuration | `bitoarch show-config --raw`               |

**Examples:**
```bash
# Trigger repository indexing
bitoarch index-repos

# Check indexing status (default summary)
bitoarch index-status

# Full API response for debugging
bitoarch index-status --raw

# Machine-readable filtered JSON
bitoarch index-status --output json

# List all repositories
bitoarch index-repo-list
```

---

## Repository Management

| Command | Description | Example |
|---------|-------------|---------|
| `bitoarch add-repo <namespace>` | Add single repository | `bitoarch add-repo myorg/myrepo` |
| `bitoarch remove-repo <namespace>` | Remove repository | `bitoarch remove-repo myorg/myrepo` |
| `bitoarch add-repos <file>` | Load configuration from YAML | `bitoarch add-repos .bitoarch-config.yaml` |
| `bitoarch update-repos <file>` | Update configuration from YAML | `bitoarch update-repos .bitoarch-config.yaml` |
| `bitoarch repo-info <name>` | Get detailed repository info | `bitoarch repo-info myrepo --dependencies` |

**Examples:**
```bash
# Add a single repository
bitoarch add-repo myorg/myrepo

# Remove a repository
bitoarch remove-repo myorg/myrepo

# Load multiple repositories from YAML
bitoarch add-repos .bitoarch-config.yaml

# Update configuration
bitoarch update-repos .bitoarch-config.yaml

# Get repository details
bitoarch repo-info myrepo
```

---

## Service Operations

| Command | Description | Example |
|---------|-------------|---------|
| `bitoarch status` | View all services status | Docker ps-like output |
| `bitoarch health` | Check health of all services | `bitoarch health` |
| `bitoarch info` | Get platform information | Version, ports, resources |

**Examples:**
```bash
# Check service status (docker ps-like)
bitoarch status

# Health check
bitoarch health

# Platform information
bitoarch info
```

---

## Configuration

| Command | Description | Example |
|---------|-------------|---------|
| `bitoarch update-api-key` | Update Bito API key | Interactive or with `--api-key` flag |
| `bitoarch update-git-creds` | Update Git provider credentials | Interactive or with flags |
| `bitoarch rotate-mcp-token` | Rotate MCP access token | `bitoarch rotate-mcp-token <new-token>` |

**Examples:**
```bash
# Update API key (interactive)
bitoarch update-api-key

# Update API key with flag
bitoarch update-api-key --api-key <key> --restart

# Update Git credentials (interactive)
bitoarch update-git-creds

# Update Git credentials with flags
bitoarch update-git-creds --provider github --token <token> --restart

# Rotate MCP token
bitoarch rotate-mcp-token <new-token>
```

---

## MCP Operations

| Command | Description | Example |
|---------|-------------|---------|
| `bitoarch mcp-test` | Test MCP connection | Verify server connectivity |
| `bitoarch mcp-tools` | List available MCP tools | `bitoarch mcp-tools --details` |
| `bitoarch mcp-capabilities` | Show MCP server capabilities | `bitoarch mcp-capabilities --output caps.json` |
| `bitoarch mcp-resources` | List MCP resources | View available data sources |
| `bitoarch mcp-info` | Show MCP configuration | Display URL and token info |

**Examples:**
```bash
# Test MCP connection
bitoarch mcp-test

# List MCP tools
bitoarch mcp-tools

# Show detailed tool information
bitoarch mcp-tools --details

# Get server capabilities
bitoarch mcp-capabilities

# Save capabilities to file
bitoarch mcp-capabilities --output capabilities.json

# List resources
bitoarch mcp-resources

# Show MCP configuration
bitoarch mcp-info
```

---

---

## Common Workflows

### Initial Setup
```bash
# 1. Check services are running
bitoarch status

# 2. Add repositories
bitoarch add-repos .bitoarch-config.yaml

# 3. Trigger indexing
bitoarch index-repos

# 4. Monitor progress
bitoarch index-status
```

### Daily Operations
```bash
# Check health
bitoarch health

# View repositories
bitoarch index-repo-list

# Check index status
bitoarch index-status
```

### Adding New Repositories
```bash
# Single repository
bitoarch add-repo myorg/newrepo

# Multiple repositories from file
bitoarch add-repos new-repos.yaml

# Trigger re-indexing
bitoarch index-repos
```

### Troubleshooting
```bash
# Check all services
bitoarch status
bitoarch health

# View full configuration
bitoarch show-config --raw

# Test MCP connection
bitoarch mcp-test

# Check indexing status with details
bitoarch index-status --raw
```

---

---

## Getting Help

| Command | Shows |
|---------|-------|
| `bitoarch --help` | Main menu with all commands |
| `bitoarch <command> --help` | Command-specific help |

**Examples:**
```bash
# Main help
bitoarch --help

# Command help
bitoarch index-repos --help
bitoarch add-repo --help
bitoarch mcp-tools --help
```

---

## Environment

Configuration is loaded from `.env-bitoarch` file. Key variables:

- `BITO_API_KEY` - API key for authentication
- `GIT_PROVIDER` - Git provider (github, gitlab, bitbucket)
- `GIT_ACCESS_TOKEN` - Git access token
- `BITO_MCP_ACCESS_TOKEN` - MCP server access token
- `CIS_*_EXTERNAL_PORT` - Service external ports

---

## Version

Check CLI version:
```bash
bitoarch --version
