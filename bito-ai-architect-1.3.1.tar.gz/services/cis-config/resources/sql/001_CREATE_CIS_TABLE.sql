--
-- Copyright (c) 2023-2025 Bito Inc.
-- All rights reserved.
--
-- This source code is proprietary and confidential to Bito Inc.
-- Unauthorized copying, modification, distribution, or use is strictly prohibited.
--
-- For licensing information, see the COPYRIGHT file in the root directory.
--
-- @company Bito Inc.
-- @website https://bito.ai
--
-- Database: code_intelligence
-- Description: Creates the configuration table for Code Intelligence Service

CREATE DATABASE IF NOT EXISTS code_intelligence;
USE code_intelligence;

-- Table: cis_config
-- Description: Saves the cis configuration details
CREATE TABLE IF NOT EXISTS cis_config
(
    id           BIGINT AUTO_INCREMENT PRIMARY KEY,
    workspace_id BIGINT NOT NULL,
    config_json  JSON   NOT NULL,
    created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    is_deleted   BOOLEAN   DEFAULT FALSE,

    -- Indexes for better performance
    INDEX idx_workspace_id (workspace_id),
    INDEX idx_workspace_active (workspace_id, is_deleted),
    INDEX idx_created_at (created_at),
    INDEX idx_updated_at (updated_at),

    -- Unique constraint to ensure one active config per workspace
    UNIQUE KEY uk_workspace_active (workspace_id, is_deleted)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4
  COLLATE = utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS config_audit
(
    event_id     VARCHAR(255) PRIMARY KEY,
    event_type   VARCHAR(128) NOT NULL,
    workspace_id BIGINT       NOT NULL,
    created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    request_id   VARCHAR(255) NULL,
    event_data   JSON         NOT NULL,

    -- Indexes for better performance
    INDEX idx_workspace_id (workspace_id),
    INDEX idx_created_at (created_at),
    INDEX idx_event_type (event_type),
    INDEX idx_request_id (request_id)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4
  COLLATE = utf8mb4_unicode_ci;
