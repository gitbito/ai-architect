#!/bin/bash

#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
# Bito's AI Architect CLI - Tracker Adapter

# Source http-client for K8s port-forward support
if [ -z "$SCRIPT_DIR" ]; then
    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && cd ../.. && pwd)"
fi
source "${SCRIPT_DIR}/scripts/lib/http-client.sh" 2>/dev/null || true

# Ensure tracker service is accessible (handles K8s port-forward automatically)
ensure_tracker_service_accessible() {
    local TRACKER_PORT="${CIS_TRACKING_PORT:-9920}"
    ensure_service_accessible "ai-architect-tracker" "$TRACKER_PORT" 2>/dev/null || true
}

check_indexing_enabled() {
    local base_url="$1"
    local api_key="$2"

    if [[ -z "$base_url" ]]; then
        print_error "TRACKING_SERVICE_BASE_URL is not set"
        return 1
    fi
    if [[ -z "$api_key" ]]; then
        echo "ERROR: Bito API Key is not set"
        return 1
    fi

    local url="${base_url}/v1/project-info/context"
    
    # Ensure tracker service is accessible (sets up port-forward for K8s if needed)
    ensure_tracker_service_accessible

    # Call API
    local response
    response=$(curl -s -X GET "$url" \
        -H "ws-api-key: Bearer ${api_key}")

    # If curl failed
    if [[ $? -ne 0 || -z "$response" ]]; then
        echo "ERROR: API call failed"
        return 1
    fi

    # Extract indexing_enabled (can be true/false/null)
    local indexing_enabled
    indexing_enabled=$(echo "$response" | jq -r '.indexing_enabled')

    # Debug print (optional)
    # echo "API response: $response"
    # echo "indexing_enabled: $indexing_enabled"

    # Logic:
    # success => indexing_enabled == true
    # failure => null or false
    if [[ "$indexing_enabled" == "true" ]]; then
        return 0
    else
        return 1
    fi
}

export -f check_indexing_enabled

################################################################################
# Tracker Adapter - Centralized tracking functions for Bito Architect setup
################################################################################

################################################################################
# Function: call_tracking_endpoint_event
# Purpose: Send tracking events to the tracking service
# Parameters:
#   1. base_url - TRACKING_SERVICE_BASE_URL
#   2. api_key - BITO_API_KEY for Authorization header
#   3. event_type - Type of event (architect_install_started, etc.)
#   4. data_json - JSON string with event data
# Returns: HTTP status code
################################################################################
call_tracking_endpoint_event() {
    local base_url="$1"
    local api_key="$2"
    local event_type="$3"
    local data_json="$4"
    
    # Validate required parameters
    if [ -z "$base_url" ] || [ -z "$api_key" ] || [ -z "$event_type" ]; then
        return 1
    fi
   
    # Build the tracking payload
    local payload=$(cat <<EOF
{
    "event_type": "$event_type",
    "data": $data_json
}
EOF
)
    
    # Ensure tracker service is accessible (sets up port-forward for K8s if needed)
    ensure_tracker_service_accessible
    
    # Make the API call with curl, capturing HTTP status
    local response
    local http_status
    
    response=$(curl -s -w "\n%{http_code}" \
        -X POST \
        -H "Content-Type: application/json" \
        -H "Authorization: Bearer $api_key" \
        -d "$payload" \
        "$base_url/v1/project-info/analytics/events" 2>/dev/null)
   #echo "Tracking : $response"
    # Extract HTTP status code (last line)
    http_status=$(echo "$response" | tail -n1)
    
    # Store status in a global variable and return appropriate exit code
    TRACKING_HTTP_STATUS="$http_status"
   
    #echo "Tracking endpoint response status: $TRACKING_HTTP_STATUS"
    if [ "$http_status" = "200" ] || [ "$http_status" = "201" ]; then
        return 0
    elif [ "$http_status" = "403" ]; then
        echo "$http_status"
        return 1  # Return 1 instead of 403 (bash can only return 0-255)
    else
        return 1
    fi
}

################################################################################
# Function: send_deployment_tracking
# Purpose: Send deployment/setup tracking events
# Parameters:
#   1. indexing_mode - "auto" or "manual"
#   2. architect_status - Status of architect (configuration_saved, manual_setup_started, failed, etc.)
#   3. architect_error - Error message if any
# Uses globals: TRACKING_SERVICE_BASE_URL, BITO_API_KEY
################################################################################
send_deployment_tracking() {
    local indexing_mode="$1"
    local architect_status="$2"
    local architect_error="$3"
    # Skip if tracking credentials not available
    if [ -z "$TRACKING_SERVICE_BASE_URL" ] || [ -z "$BITO_API_KEY" ]; then
        return 0
    fi
    
    # Get repo count from config file
    local repo_count=0
    local config_file="${SCRIPT_DIR}/.bitoarch-config.yaml"
    
     if [  -f "$config_file" ]; then
        repo_count=$(grep -c "^\s*- namespace:" "$config_file" 2>/dev/null || echo "0")
    
    fi
    
    # Count the number of repository entries (lines starting with '- namespace:')
   
    # Build tracking data
    local tracking_data=$(cat <<EOF
{
    "deployment_mode": "self_hosted",
    "indexing_mode": "$indexing_mode",
    "num_repos": $repo_count,
    "architect_status": "$architect_status",
    "architect_error": "$architect_error"
}
EOF
)
    
    
    # Send tracking event
    call_tracking_endpoint_event "$TRACKING_SERVICE_BASE_URL" "$BITO_API_KEY" "architect_install_ended" "$tracking_data"
    
    # Non-blocking - don't fail if tracking fails
    return 0
}

################################################################################
# Function: send_git_integration_tracking
# Purpose: Send git integration tracking events
# Parameters:
#   1. git_provider - Provider name (gitlab, github, bitbucket)
#   2. is_enterprise - Boolean (true/false)
#   3. enterprise_domain - Domain URL if enterprise
# Uses globals: TRACKING_SERVICE_BASE_URL, BITO_API_KEY
################################################################################
send_git_integration_tracking() {
    local git_provider="$1"
    local is_enterprise="$2"
    local enterprise_domain="$3"
    
    # Skip if tracking credentials not available
    if [ -z "$TRACKING_SERVICE_BASE_URL" ] || [ -z "$BITO_API_KEY" ]; then
        return 0
    fi
    
    # Build tracking data
    local tracking_data=$(cat <<EOF
{
    "deployment_mode": "self_hosted",
    "git_provider": "$git_provider",
    "is_enterprise": $is_enterprise,
    "enterprise_domain": "$enterprise_domain"
}
EOF
)
    
    # Send tracking event
    call_tracking_endpoint_event "$TRACKING_SERVICE_BASE_URL" "$BITO_API_KEY" "architect_git_integration" "$tracking_data"
    
    # Non-blocking - don't fail if tracking fails
    return 0
}

################################################################################
# Function: send_llm_provider_tracking
# Purpose: Send LLM provider tracking events
# Parameters:
#   1. llm_providers - Comma-separated list of providers
# Uses globals: TRACKING_SERVICE_BASE_URL, BITO_API_KEY
################################################################################
send_llm_provider_tracking() {
    local llm_providers="$1"
    
    # Skip if tracking credentials not available
    if [ -z "$TRACKING_SERVICE_BASE_URL" ] || [ -z "$BITO_API_KEY" ]; then
        return 0
    fi
    
    # Build tracking data
    local tracking_data=$(cat <<EOF
{
    "deployment_mode": "self_hosted",
    "llm_providers": "$llm_providers"
}
EOF
)
    
    # Send tracking event
    call_tracking_endpoint_event "$TRACKING_SERVICE_BASE_URL" "$BITO_API_KEY" "architect_llm_key_entered" "$tracking_data"
    
    # Non-blocking - don't fail if tracking fails
    return 0
}

# Export functions so they can be called from other scripts
export -f call_tracking_endpoint_event
export -f send_deployment_tracking
export -f send_git_integration_tracking
export -f send_llm_provider_tracking
