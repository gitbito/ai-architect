#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
# Bito's AI Architect CLI - Manager Adapter
# Provides manager_sync_simple (used by index-repos) and manager_status (used by index-status)

# Source http-client for K8s port-forward support
if [ -z "$SCRIPT_DIR" ]; then
    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && cd ../.. && pwd)"
fi
source "${SCRIPT_DIR}/scripts/lib/http-client.sh" 2>/dev/null || true
source "${SCRIPT_DIR}/scripts/lib/output-fields.sh" 2>/dev/null || true

# Ensure manager service is accessible (handles K8s port-forward automatically)
ensure_manager_service_accessible() {
    # Get port from environment
    local MANAGER_PORT="${CIS_MANAGER_EXTERNAL_PORT:-5002}"
    
    # Ensure service is accessible (no-op for Docker, sets up port-forward for K8s)
    ensure_service_accessible "ai-architect-manager" "$MANAGER_PORT" 2>/dev/null || true
}

# Simple repository indexing (no parameters)
manager_sync_simple() {
    # Check for help first
    if [ "$1" = "--help" ] || [ "$1" = "-h" ]; then
        cat << 'EOF'
USAGE:
  bitoarch index-repos

DESCRIPTION:
  Trigger repository indexing. This command initiates the indexing
  process for all configured repositories. Indexing typically takes 3-10 minutes
  per repository depending on size.

OPTIONS:
  --help, -h    Show this help

EXAMPLES:
  # Start indexing all configured repositories
  bitoarch index-repos
  
  # Check indexing progress
  bitoarch index-status

NOTES:
  - Requires BITO_API_KEY to be configured in environment
  - Repositories must be configured first (use 'bitoarch add-repo')
  - Multiple calls will queue additional indexing requests
EOF
        return 0
    fi
    
    # Get BITO API key from environment
    if [ -z "$BITO_API_KEY" ]; then
        print_error "BITO_API_KEY not found in environment"
        return 1
    fi
    
    # Get manager external port from environment (default to 5002)
    local MANAGER_PORT="${CIS_MANAGER_EXTERNAL_PORT:-5002}"
    local MANAGER_URL="${CIS_MANAGER_URL:-http://localhost:${MANAGER_PORT}}"
    
    # Ensure manager service is accessible (sets up port-forward for K8s if needed)
    ensure_manager_service_accessible
    
    print_info "Initiating repository indexing..."
    
    # Make API call directly with curl
    local response=$(curl -s -w '\n%{http_code}' \
        -X POST \
        -H "Authorization: $BITO_API_KEY" \
        "${MANAGER_URL}/api/v2/sync-workspace" 2>/dev/null)
    
    # Extract HTTP code from last line
    local http_code=$(echo "$response" | tail -1)
    local body=$(echo "$response" | sed '$d')
    
    # Use field-based rendering
    if [ "$http_code" -ge 200 ] && [ "$http_code" -lt 300 ]; then
        echo ""
        echo -e "${GREEN}✅ Repository Indexing Initiated${NC}"
        echo ""
        
        # Extract message from response
        if command -v jq >/dev/null 2>&1; then
            local message=$(echo "$body" | jq -r '.message // "repository enqueued for processing"')
            echo -e "${BLUE}Status:${NC}"
            echo "  • $message"
        else
            echo "$body"
        fi
        
        # Show indexing information
        echo ""
        echo -e "${CYAN}${BOLD}📊 Note:${NC}"
        echo -e "${BOLD}Indexing has started, and will take approximately 3-10 minutes per repo. Smaller repos take less time${NC}"
        echo -e "${BOLD}You can check the status of your indexing by typing ${YELLOW}bitoarch index-status${NC}${BOLD} from your CLI${NC}"
        
        return 0
    else
        render_command_error "Repository Indexing Failed" "$body" "$MANAGER_SYNC_ERROR_OUTPUT"
        
        # Special handling for QUEUE_FULL error
        if command -v jq >/dev/null 2>&1; then
            local error_type=$(echo "$body" | jq -r '.error // ""' 2>/dev/null)
            if [ "$error_type" = "QUEUE_FULL" ]; then
                echo -e "${BLUE}Note:${NC}"
                echo "  Indexing is already in progress for your current repositories."
                echo "  New repositories can only be indexed after the ongoing process completes."
                echo ""
                echo -e "${YELLOW}Next Steps:${NC}"
                echo -e "  1. Wait for current indexing to finish (check with: ${YELLOW}bitoarch index-status${NC})"
                echo -e "  2. Once complete, run ${YELLOW}bitoarch index-repos${NC} again to index newly added repos"
                echo ""
            fi
        fi
        
        return 1
    fi
}

# Get sync status
manager_status() {
    local view_mode="default"
    
    # Parse flags
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --help|-h)
                cat << 'EOF'
STATUS COMMAND

USAGE:
  bitoarch index-status [OPTIONS]

DESCRIPTION:
  Retrieves the current indexing status from the CIS Manager service.
  Uses BITO_API_KEY from environment for authentication.

OPTIONS:
  --raw                 Show raw unfiltered JSON response
  --output json         Machine-readable filtered JSON output
  --help, -h           Show this help

OUTPUT MODES:
  default       Minimal summary (state, progress, key metrics)
  --raw         Complete API response (for debugging)
  --output json Filtered JSON for automation/scripting

EXAMPLES:
  # Quick status check
  bitoarch index-status

  # Detailed view
  bitoarch index-status --details

  # Raw API response
  bitoarch index-status --raw

  # For automation
  bitoarch index-status --output json | jq '.state'

NOTES:
  - Requires BITO_API_KEY to be set in environment
  - Connects to CIS Manager service using CIS_MANAGER_PORT from .env
EOF
                return 0
                ;;
            --raw)
                view_mode="raw"
                shift
                ;;
            --output)
                if [ "$2" = "json" ]; then
                    view_mode="json"
                    shift 2
                else
                    print_error "Unknown output format: $2"
                    return 1
                fi
                ;;
            *)
                print_warning "Unknown option: $1"
                shift
                ;;
        esac
    done
    
    # Get BITO API key from environment
    if [ -z "$BITO_API_KEY" ]; then
        print_error "BITO_API_KEY not found in environment"
        return 1
    fi
    
    # Get manager external port from environment (default to 5002)
    local MANAGER_PORT="${CIS_MANAGER_EXTERNAL_PORT:-5002}"
    local MANAGER_URL="http://localhost:${MANAGER_PORT}"
    local ENDPOINT="${MANAGER_URL}/api/v2/indexing-status"
    
    # Ensure manager service is accessible (sets up port-forward for K8s if needed)
    ensure_manager_service_accessible
    
    # Only show progress message in non-JSON modes
    if [ "$view_mode" != "json" ]; then
        print_info "Fetching index status..."
    fi
    
    # Make API call with timeout
    local response=$(curl -s -w '\n%{http_code}' --max-time 30 \
        -X GET \
        -H "Authorization: Bearer ${BITO_API_KEY}" \
        "$ENDPOINT" 2>/dev/null)
    
    local curl_exit=$?
    
    # Handle curl errors (timeout, connection refused, etc.)
    if [ $curl_exit -ne 0 ]; then
        if [ "$view_mode" = "json" ]; then
            echo '{"error": "connection_failed", "message": "Failed to connect to CIS Manager"}'
        else
            render_manager_status_error "connection_failed" "Failed to connect to CIS Manager" "$ENDPOINT"
        fi
        return 1
    fi
    
    # Extract HTTP code from last line
    local http_code=$(echo "$response" | tail -1)
    local body=$(echo "$response" | sed '$d')
    
    # Handle HTTP errors
    if [ "$http_code" -lt 200 ] || [ "$http_code" -ge 300 ]; then
        if [ "$view_mode" = "json" ]; then
            echo "{\"error\": \"http_$http_code\", \"message\": \"API request failed\"}"
        else
            render_manager_status_error "$http_code" "$body" "$ENDPOINT"
        fi
        return 1
    fi
    
    # Render based on view mode
    case "$view_mode" in
        default)
            render_manager_status_default "$body"
            ;;
        raw)
            render_manager_status_raw "$body"
            ;;
        json)
            render_manager_status_json "$body"
            ;;
    esac
    
    return 0
}

# Render functions for manager status
render_manager_status_default() {
    local response="$1"
    
    if ! command -v jq >/dev/null 2>&1; then
        print_error "jq is required for parsing"
        echo "$response"
        return 1
    fi
    
    echo ""
    echo -e "${BLUE}Index Status${NC}"
    echo ""
    
    # Extract key fields - map from actual API response
    local state=$(echo "$response" | jq -r '.status // "unknown"')
    local completed=$(echo "$response" | jq -r '.completed_repos // 0')
    local total=$(echo "$response" | jq -r '.total_repos // 0')
    local in_progress=$(echo "$response" | jq -r '.in_progress_repos // 0')
    local failed=$(echo "$response" | jq -r '.failed_repos // 0')
    
    # Determine actual state considering failures
    local display_state="$state"
    if [ "$failed" -gt 0 ]; then
        if [ "$state" = "running" ] || [ "$state" = "indexing" ] || [ "$state" = "in_progress" ]; then
            display_state="running (with failures)"
        elif [ "$state" = "completed" ] || [ "$state" = "success" ]; then
            display_state="completed with errors"
        fi
    fi
    
    # Show status with appropriate emoji
    case "$display_state" in
        "indexing"|"running"|"in_progress")
            echo -e "  State: ${YELLOW}⏳ $display_state${NC}"
            ;;
        "running (with failures)")
            echo -e "  State: ${YELLOW}⚠️  $display_state${NC}"
            ;;
        "completed"|"success")
            echo -e "  State: ${GREEN}✓ $display_state${NC}"
            ;;
        "completed with errors")
            echo -e "  State: ${YELLOW}⚠️  $display_state${NC}"
            ;;
        "failed"|"error")
            echo -e "  State: ${RED}✗ $display_state${NC}"
            ;;
        "idle"|"waiting")
            echo -e "  State: ${BLUE}• $display_state${NC}"
            ;;
        *)
            echo -e "  State: $display_state"
            ;;
    esac
    
    echo "  Progress: $completed / $total completed"
    if [ "$in_progress" -gt 0 ]; then
        echo "  In Progress: $in_progress"
    fi
    if [ "$failed" -gt 0 ]; then
        echo -e "  ${RED}Failed: $failed${NC}"
    fi
    
    # Show failed repository details if available
    if [ "$failed" -gt 0 ]; then
        echo ""
        echo -e "${RED}❌ Failed Repositories:${NC}"
        
        # Try to extract failed repo details from the response
        local failed_details=$(echo "$response" | jq -r '.failed_repo_details[]? | "  • \(.namespace // .repository_name): \(.error // .failure_reason // "Unknown error")"' 2>/dev/null)
        
        if [ -n "$failed_details" ]; then
            echo "$failed_details"
        else
            # Fallback: Try alternate field names
            failed_details=$(echo "$response" | jq -r '.failures[]? | "  • \(.repo // .name): \(.message // .error)"' 2>/dev/null)
            if [ -n "$failed_details" ]; then
                echo "$failed_details"
            else
                echo "  • $failed repository(ies) failed (use --raw for details)"
            fi
        fi
    fi
    
    # If indexing is complete, show MCP setup guide
    if [ "$state" = "completed" ] || [ "$state" = "success" ]; then
        # Source constants if not already loaded
        if [ -z "$MCP_SETUP_DOCS_URL" ]; then
            local SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && cd ../.. && pwd)"
            source "${SCRIPT_DIR}/scripts/lib/constants.sh" 2>/dev/null || true
        fi
        
        echo ""
        echo -e "${GREEN}✅ Indexing Complete!${NC}"
        echo ""
        echo -e "${BLUE}📖 Next Steps:${NC}"
        echo -e "  Set up your MCP server to access the indexed repositories"
        echo -e "  ${YELLOW}Guide: ${MCP_SETUP_DOCS_URL:-https://docs.bito.ai/ai-architect/install-ai-architect-self-hosted#setting-up-ai-architect-mcp-in-coding-agents}${NC}"
        echo ""
    else
        echo ""
        echo -e "${BLUE}💡 Options:${NC}"
        echo -e "  • ${YELLOW}--raw${NC}      Show complete API response with full error details"
        echo ""
        
        # Add note if state is running or if there are repos
        if [ "$total" -gt 0 ]; then
            echo -e "${BLUE}Note:${NC}"
            echo "  Repository count reflects the index session that was initiated."
            echo "  If config was updated after index started, run indexing again to refresh:"
            echo -e "  ${YELLOW}bitoarch index-repos${NC}"
            echo ""
        fi
    fi
}

render_manager_status_raw() {
    local response="$1"
    
    echo "# Raw API Response (unfiltered)"
    echo ""
    
    if command -v jq >/dev/null 2>&1; then
        echo "$response" | jq '.'
    else
        echo "$response"
    fi
}

render_manager_status_json() {
    local response="$1"
    
    # Filtered JSON for machine consumption - map from actual API fields
    if command -v jq >/dev/null 2>&1; then
        echo "$response" | jq '{
            status: .status,
            total_repos: .total_repos,
            completed_repos: .completed_repos,
            in_progress_repos: .in_progress_repos,
            failed_repos: .failed_repos,
            percentage_completion: .percentage_completion
        }'
    else
        echo '{"error": "jq required for JSON output"}'
    fi
}

render_manager_status_error() {
    local error_type="$1"
    local error_msg="$2"
    local endpoint="$3"
    
    echo ""
    echo -e "${RED}✗ Failed to retrieve index status${NC}"
    echo ""
    echo -e "${BLUE}Error Details:${NC}"
    
    if [ "$error_type" = "connection_failed" ]; then
        echo "  • Type: Connection Error"
        echo "  • Endpoint: $endpoint"
        echo "  • Message: $error_msg"
    else
        echo "  • HTTP Status: $error_type"
        echo "  • Endpoint: $endpoint"
        echo "  • Response: $error_msg"
    fi
    
    echo ""
    echo -e "${BLUE}Troubleshooting:${NC}"
    echo -e "  • Check if CIS Manager is running: ${YELLOW}bitoarch status${NC}"
    echo -e "  • Verify BITO_API_KEY in .env"
    echo -e "  • Check logs: ${YELLOW}./setup.sh --logs${NC}"
    echo ""
}

# Export functions
export -f manager_sync_simple
export -f manager_status
