#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai

create_log_directories() {
    print_info "Creating centralized log directories..."
    
    local log_dirs=(
        "var/logs"
        "var/logs/mysql"
        "var/logs/cis-manager"
        "var/logs/cis-config"
        "var/logs/cis-provider"
    )
    
    local root_owned_dirs=()
    local could_not_detect_user=false
    # Get the actual user (not root if using sudo or su)
    local current_user="${SUDO_USER:-$(whoami)}"
    
    if [ "$current_user" = "root" ]; then
        local dir_owner=""
        if [[ "$OSTYPE" == "darwin"* ]]; then
            dir_owner=$(stat -f '%Su' "$SCRIPT_DIR" 2>/dev/null || echo "")
        else
            dir_owner=$(stat -c '%U' "$SCRIPT_DIR" 2>/dev/null || echo "")
        fi
        
        if [ -n "$dir_owner" ] && [ "$dir_owner" != "root" ]; then
            current_user="$dir_owner"
        else
            # Cannot reliably detect the actual user
            could_not_detect_user=true
        fi
    fi
    
    # First pass: check for root-owned directories
    for dir in "${log_dirs[@]}"; do
        local full_path="$SCRIPT_DIR/$dir"
        
        if [ -d "$full_path" ]; then
            # Check directory ownership
            local owner=""
            if [[ "$OSTYPE" == "darwin"* ]]; then
                owner=$(stat -f '%Su' "$full_path" 2>/dev/null || echo "")
            else
                owner=$(stat -c '%U' "$full_path" 2>/dev/null || echo "")
            fi
            
            if [ "$owner" = "root" ]; then
                root_owned_dirs+=("$full_path")
            fi
        fi
    done
    
    if [ ${#root_owned_dirs[@]} -gt 0 ]; then
        if [ "$(whoami)" = "root" ]; then
            log_silent "Found root-owned directories, fixing permissions (running as root)"
            for dir in "${root_owned_dirs[@]}"; do
                chmod 777 "$dir" 2>/dev/null || true
                log_silent "  - Fixed: $dir"
            done
        elif [[ "${SERVICES_WERE_RUNNING:-false}" == "true" ]]; then
            # Services exist - just warn, don't block restart
            log_silent "Warning: Found root-owned log directories (not blocking restart)"
            for dir in "${root_owned_dirs[@]}"; do
                log_silent "  - $dir"
            done
            log_silent "Directories are functional despite root ownership"
            # Continue without error - services can restart
        else
            echo ""
            print_error "Cannot set permissions: Some log directories are owned by root"
            echo ""
            print_info "This typically happens after a previous Docker deployment"
            print_info "Root-owned directories found:"
            for dir in "${root_owned_dirs[@]}"; do
                echo "  - $dir"
            done
            echo ""
            print_info "To fix this, run one of the following commands:"
            echo ""
            if [ "$could_not_detect_user" = true ]; then
                echo -e "  ${YELLOW}Option 1:${NC} Change ownership to your user:"
                echo -e "    ${BLUE}sudo chown -R \$USER:\$USER ${SCRIPT_DIR}/var/logs${NC}"
                echo -e "    ${YELLOW}Note:${NC} Replace \$USER with your actual username (run as non-root user)"
            else
                echo -e "  ${YELLOW}Option 1:${NC} Change ownership to your user:"
                echo -e "    ${BLUE}sudo chown -R $current_user:$current_user ${SCRIPT_DIR}/var/logs${NC}"
            fi
            echo ""
            echo -e "  ${YELLOW}Option 2:${NC} Run the full cleanup (removes all data):"
            echo -e "    ${BLUE}./setup.sh --clean${NC}"
            echo ""
            return 1
        fi
    fi
    
    # Second pass: create directories and set permissions
    for dir in "${log_dirs[@]}"; do
        local full_path="$SCRIPT_DIR/$dir"
        mkdir -p "$full_path"
        
        # Use 777 for better Docker compatibility
        if ! chmod 777 "$full_path" 2>/dev/null; then
            # Try with sudo if regular chmod fails
            if command -v sudo >/dev/null 2>&1; then
                if sudo chmod 777 "$full_path" 2>/dev/null; then
                    log_silent "Set permissions with sudo on $full_path"
                else
                    print_warning "Failed to set permissions on $full_path"
                fi
            else
                print_warning "Failed to set permissions on $full_path (continuing anyway)"
            fi
        fi
    done
    
    print_status "Log directories created at ./var/logs/"
}

show_container_progress() {
    local container_name="$1"
    local display_name="$2"
    local timeout="${3:-120}"
    
    if is_arm64_mac; then
        timeout=$((timeout * 2))
    fi
    
    printf "   %-20s " "$display_name"
    
    local elapsed=0
    local spinner="⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏"
    local i=0
    
    while [ $elapsed -lt $timeout ]; do
        local status=$(docker inspect --format='{{.State.Status}}' "$container_name" 2>/dev/null || echo "not_found")
        local health=$(docker inspect --format='{{.State.Health.Status}}' "$container_name" 2>/dev/null || echo "no_health")
        
        case "$status" in
            "running")
                if [[ "$health" == "healthy" ]] || [[ "$health" == "no_health" ]]; then
                    printf "\r   %-25s ${GREEN}✅ Ready${NC}            \n" "$display_name"
                    return 0
                elif [[ "$health" == "starting" ]]; then
                    # During start_period, check actual health endpoint
                    local port=$(docker inspect --format='{{range $p, $conf := .NetworkSettings.Ports}}{{if eq $p "8080/tcp"}}8080{{else if eq $p "8081/tcp"}}8081{{else if eq $p "9090/tcp"}}9090{{end}}{{end}}' "$container_name" 2>/dev/null)
                    if [ -n "$port" ] && curl -sf "http://localhost:$port/health" >/dev/null 2>&1; then
                        printf "\r   %-25s ${GREEN}✅ Ready${NC}            \n" "$display_name"
                        return 0
                    fi
                    printf "\r   %-20s ${YELLOW}⏳ %s Initializing...${NC}" "$display_name" "${spinner:$i:1}"
                else
                    printf "\r   %-20s ${YELLOW}⏳ %s Starting...${NC}" "$display_name" "${spinner:$i:1}"
                fi
                ;;
            "restarting")
                printf "\r   %-20s ${YELLOW}🔄 %s Restarting...${NC}" "$display_name" "${spinner:$i:1}"
                ;;
            "exited"|"dead")
                printf "\r   %-20s ${RED}❌ Failed${NC}           \n" "$display_name"
                return 1
                ;;
            "not_found")
                printf "\r   %-20s ${YELLOW}📦 %s Creating...${NC}" "$display_name" "${spinner:$i:1}"
                ;;
            *)
                printf "\r   %-20s ${YELLOW}⏳ %s Starting...${NC}" "$display_name" "${spinner:$i:1}"
                ;;
        esac
        
        i=$(((i + 1) % ${#spinner}))
        sleep 0.3
        elapsed=$((elapsed + 1))
    done
    
    printf "\r   %-20s ${RED}⏱️  Timeout${NC}          \n" "$display_name"
    return 1
}

deploy_mysql() {
    eval "${DOCKER_COMPOSE_CMD} --env-file .env-bitoarch up -d ai-architect-mysql" >> "$LOG_FILE" 2>&1
}

deploy_cis_config() {
    eval "${DOCKER_COMPOSE_CMD} --env-file .env-bitoarch up -d ai-architect-config" >> "$LOG_FILE" 2>&1
}

deploy_cis_manager() {
    eval "${DOCKER_COMPOSE_CMD} --env-file .env-bitoarch up -d ai-architect-manager" >> "$LOG_FILE" 2>&1
}

deploy_cis_tracker() {
    eval "${DOCKER_COMPOSE_CMD} --env-file .env-bitoarch up -d ai-architect-tracker" >> "$LOG_FILE" 2>&1
}

deploy_cis_provider() {
    eval "${DOCKER_COMPOSE_CMD} --env-file .env-bitoarch up -d ai-architect-provider" >> "$LOG_FILE" 2>&1
}

deploy_sequential() {
    print_info "Using sequential deployment..."
    
    # MySQL always first
    deploy_mysql || return 1
    
    # Deploy other services in configured order
    local service_order="${SERVICE_DEPLOY_ORDER:-ai-architect-config,ai-architect-manager,ai-architect-provider}"
    IFS=',' read -ra SERVICES <<< "$service_order"
    
    for service in "${SERVICES[@]}"; do
        local service_clean=$(echo "$service" | xargs)  # Trim whitespace
        case "$service_clean" in
            "ai-architect-config")
                deploy_cis_config || return 1
                ;;
            "ai-architect-manager")
                deploy_cis_manager || return 1
                ;;
            "ai-architect-provider")
                deploy_cis_provider || return 1
                ;;
            "ai-architect-tracker")
                deploy_cis_tracker || return 1
                ;;
            *)
                print_warning "Unknown service in SERVICE_DEPLOY_ORDER: $service_clean"
                ;;
        esac
    done
    
    return 0
}

deploy_parallel() {
    print_info "Using parallel deployment..."
    
    deploy_mysql || return 1
    
    {
        deploy_cis_config &
        local pid_config=$!
        
        deploy_cis_manager &
        local pid_manager=$!
        
        wait $pid_config || return 1
        wait $pid_manager || return 1
    }
    
    deploy_cis_provider || return 1
    deploy_cis_tracker || return 1
    
    return 0
}

deploy_services() {
    DEPLOYMENT_STARTED=true
    
    log_service_lifecycle_banner "Starting"
    
    echo ""
    print_info "Starting Bito's AI Architect deployment..."
    echo ""
    
    cd "$SCRIPT_DIR"
    
    SETUP_IN_PROGRESS=true
    
    # Clean up any old CIS containers to avoid name conflicts
    # This handles exited containers from previous deployments (especially init-dirs)
    log_silent "Checking for old CIS containers..."
    local old_containers=$(docker ps -a --filter "name=ai-architect-" --format '{{.Names}}' 2>/dev/null || true)
    
    if [ -n "$old_containers" ]; then
        log_silent "Found old containers, removing: $(echo "$old_containers" | tr '\n' ' ')"
        echo "$old_containers" | while read -r container; do
            [ -n "$container" ] && docker rm -f "$container" >> "$LOG_FILE" 2>&1 || true
        done
        log_silent "Container cleanup completed"
    fi
    
    log_silent "Creating log directories..."
    create_log_directories >> "$LOG_FILE" 2>&1
    log_silent "Log directories created successfully"
    
    log_silent "Pulling Docker images..."
    printf "   %-25s" "Pulling Images"
    (
        eval "${DOCKER_COMPOSE_CMD} --env-file .env-bitoarch pull --quiet" >> "$LOG_FILE" 2>&1
    ) &
    show_spinner $! "   Pulling Images"
    log_silent "Docker images pulled successfully"
    
    log_silent "Building Docker images..."
    local services_to_build=("ai-architect-mysql" "ai-architect-provider")
    
    for service in "${services_to_build[@]}"; do
        log_silent "Building $service..."
        printf "   %-25s" "Building $service"
        
        if eval "${DOCKER_COMPOSE_CMD} --env-file .env-bitoarch build $service" >> "$LOG_FILE" 2>&1; then
            printf "\r   %-25s ${GREEN}✅ ${NC}\n" "Building $service"
            log_silent "$service built successfully"
        else
            printf "\r   %-25s ${RED}❌ Failed${NC}\n" "Building $service"
            print_error "$service build failed. Check $LOG_FILE for details"
            return 1
        fi
    done
    
    log_silent "Starting services..."
    source "$ENV_FILE"
    
    if [[ "${PARALLEL_SERVICE_DEPLOY:-true}" == "true" ]]; then
        log_silent "Using parallel deployment strategy"
        deploy_parallel || return 1
    else
        log_silent "Using sequential deployment strategy"
        deploy_sequential || return 1
    fi
    
    # Start log streaming AFTER deploying services so it tails the correct containers
    log_silent "Configuring log streaming..."
    # SCRIPT_DIR already points to the project root, no need to add /scripts again
    local logging_manager="${SCRIPT_DIR}/scripts/logging-manager.sh"
    # Handle both cases: when sourced from setup.sh (SCRIPT_DIR=project root) or run standalone
    if [ ! -f "$logging_manager" ]; then
        # If not found, try without the extra scripts/ prefix (for when SCRIPT_DIR is scripts/)
        logging_manager="$(dirname "$0")/logging-manager.sh"
    fi
    
    if [ -f "$logging_manager" ] && [ -x "$logging_manager" ]; then
        # Run logging-manager in background without nohup (it handles nohup internally)
        "$logging_manager" start > /dev/null 2>&1
        sleep 1
        log_silent "Log streaming enabled"
    else
        log_silent "Log streaming not available"
    fi
}

wait_for_services() {
    local services=("ai-architect-mysql:MySQL Database" "ai-architect-config:AI Architect Config" "ai-architect-manager:AI Architect Manager" "ai-architect-provider:AI Architect Provider" "ai-architect-tracker:AI Architect Tracker")
    local all_healthy=true
    
    echo -e "${BLUE}📋 Service Startup Progress:${NC}"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    
    for service_info in "${services[@]}"; do
        local container_name=$(echo "$service_info" | cut -d: -f1)
        local display_name=$(echo "$service_info" | cut -d: -f2)
        
        if ! show_container_progress "$container_name" "$display_name" 150; then
            all_healthy=false
            echo -e "   ${RED}💡 Troubleshooting $display_name:${NC}"
            echo -e "     • Check logs: docker logs $container_name"
            echo -e "     • Check status: docker inspect $container_name"
        fi
    done
    
    if [ "$all_healthy" = false ]; then
        echo ""
        echo -e "${RED}❌ Some services failed to start${NC}"
        return 1
    fi
    
    echo ""
    echo -e "${GREEN}✅ All services ready!${NC}"
    echo ""
    
    extract_all_service_sql_scripts
    verify_flyway_tables
    
    return 0
}

batch_validate_database() {
    local script='
    mysqladmin ping --silent || exit 1
    mysql -h localhost -u "${MYSQL_USER}" -p"${MYSQL_PASSWORD}" -e "SELECT 1;" "${MYSQL_DATABASE}" >/dev/null 2>&1 || exit 2
    mysql -h localhost -u root -p"${MYSQL_ROOT_PASSWORD}" -e "SELECT 1;" >/dev/null 2>&1 || exit 3
    '
    
    docker exec -i ai-architect-mysql bash -c "$script" >/dev/null 2>&1
}

validate_deployment() {
    log_technical "Validating deployment..."
    
    source "$ENV_FILE"
    
    log_technical "Waiting for database to initialize..."
    local db_max_wait=90
    local db_wait_time=0
    
    while [ $db_wait_time -lt $db_max_wait ]; do
        local health_status=$(docker inspect --format='{{.State.Health.Status}}' ai-architect-mysql 2>/dev/null || echo "no-health")
        
        if [[ "$health_status" == "healthy" ]]; then
            log_technical "Database is healthy and ready"
            break
        elif [[ "$health_status" == "starting" ]]; then
            # Silent wait
            true
        else
            if batch_validate_database >/dev/null 2>&1; then
                log_technical "Database is responding"
                break
            fi
        fi
        
        sleep 3
        db_wait_time=$((db_wait_time + 3))
    done
    
    if [ $db_wait_time -ge $db_max_wait ]; then
        print_error "Database failed to become healthy within 90 seconds"
        return 1
    fi
    
    log_technical "Testing database connections..."
    
    if batch_validate_database; then
        msg_success "Database scripts validated and connections established"
    else
        log_technical "Some database checks failed, but services may still work"
    fi
    
    local services=("ai-architect-config:$CIS_CONFIG_EXTERNAL_PORT" "ai-architect-manager:$CIS_MANAGER_EXTERNAL_PORT" "ai-architect-provider:$CIS_PROVIDER_EXTERNAL_PORT" "ai-architect-tracker:$CIS_TRACKER_EXTERNAL_PORT")
    
    for service in "${services[@]}"; do
        local name=$(echo "$service" | cut -d: -f1)
        local port=$(echo "$service" | cut -d: -f2)
        
        # Always use localhost for validation during setup
        if curl -f -s "http://localhost:$port/health" >/dev/null; then
            log_technical "$name service is responding"
        else
            print_error "$name service is not responding on port $port"
            return 1
        fi
    done
    
    log_technical "Deployment validation completed"
#    msg_success "${MSG_PLATFORM_READY}"
}

check_existing_services() {
    # Use docker-compose to check services managed by this project
    local compose_services=$(eval "${DOCKER_COMPOSE_CMD:-docker compose} --env-file .env-bitoarch ps -q" 2>/dev/null || true)
    
    if [ -n "$compose_services" ]; then
        SERVICES_WERE_RUNNING=true
        
        echo ""
        print_warning "⚠ Previous Bito's AI Architect deployment detected"
        echo "   The following services are running:"
        eval "${DOCKER_COMPOSE_CMD:-docker compose} --env-file .env-bitoarch ps --format table" 2>/dev/null || true
        echo ""
        
        if [[ "${AUTO_SETUP:-}" != "true" ]]; then
            read -p "Restart existing services? [Y/n]: " -r REPLY
            if [[ $REPLY =~ ^[Nn]$ ]]; then
                print_info "Setup cancelled. Services remain running."
                exit 0
            fi
        else
            print_info "Auto-setup mode: Restarting existing services automatically"
        fi
        
        print_info "Restarting existing Bito's AI Architect services..."
        
        if eval "${DOCKER_COMPOSE_CMD:-docker-compose} --env-file .env-bitoarch restart" >/dev/null 2>&1; then
            print_status "Services restarted successfully"
            
            print_info "Validating restarted services..."
            if validate_deployment; then
                display_success
                exit 0
            else
                print_warning "Validation failed after restart, proceeding with full deployment..."
            fi
        else
            print_warning "Graceful restart failed, performing full restart..."
            cleanup_on_interrupt 0
        fi
    fi
}
