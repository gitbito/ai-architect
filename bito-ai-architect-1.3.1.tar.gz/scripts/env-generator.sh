#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai

set -e

# Use SCRIPT_DIR from caller if already set (when sourced), otherwise calculate it
if [ -z "${SCRIPT_DIR:-}" ]; then
    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
fi
ENV_EXAMPLE="${SCRIPT_DIR}/.env-bitoarch.default"

# Source setup utilities for helper functions
if [ -f "${SCRIPT_DIR}/scripts/setup-utils.sh" ]; then
    source "${SCRIPT_DIR}/scripts/setup-utils.sh"
else
    generate_secret() {
        openssl rand -base64 32 2>/dev/null || head -c 32 /dev/urandom | base64
    }
    
    generate_encryption_key() {
        openssl rand -base64 32 2>/dev/null || head -c 32 /dev/urandom | base64 | tr -d '=' | tr '+/' '-_'
    }
fi

set_env_key_value() {
    local key="$1"
    local value="$2"
    local file="$3"

    # Create file if missing
    touch "$file"

    # If key exists → replace value
    if grep -q "^${key}=" "$file"; then
        # Use sed to replace entire line where KEY=...
        sed -i.bak "s|^${key}=.*|${key}=${value}|" "$file"
    else
        # Append new entry
        echo "${key}=${value}" >> "$file"
    fi
}

# Function to refresh service versions from service-versions.json to .env-bitoarch
# This is used by ./setup.sh --update to sync versions before pulling images
refresh_versions_from_service_json() {
    local env_file="${1:-.env-bitoarch}"
    local versions_file="${SCRIPT_DIR}/versions/service-versions.json"
    
    if [ ! -f "$env_file" ]; then
        echo "Error: Environment file not found: $env_file"
        return 1
    fi
    
    if [ ! -f "$versions_file" ]; then
        echo "Error: Service versions file not found: $versions_file"
        return 1
    fi
    
    if ! command -v jq >/dev/null 2>&1; then
        echo "Warning: jq not found, using fallback grep parsing"
        # Fallback parsing without jq
        local config_ver=$(grep -A 10 '"cis-config"' "$versions_file" | grep '"version"' | head -1 | cut -d'"' -f4 || echo "latest")
        local config_img=$(grep -A 10 '"cis-config"' "$versions_file" | grep '"image"' | head -1 | cut -d'"' -f4 || echo "docker.io/bitoai/cis-config")
        
        local manager_ver=$(grep -A 10 '"cis-manager"' "$versions_file" | grep '"version"' | head -1 | cut -d'"' -f4 || echo "latest")
        local manager_img=$(grep -A 10 '"cis-manager"' "$versions_file" | grep '"image"' | head -1 | cut -d'"' -f4 || echo "docker.io/bitoai/cis-manager")
        
        local provider_ver=$(grep -A 10 '"cis-provider"' "$versions_file" | grep '"version"' | head -1 | cut -d'"' -f4 || echo "latest")
        local provider_img=$(grep -A 10 '"cis-provider"' "$versions_file" | grep '"image"' | head -1 | cut -d'"' -f4 || echo "docker.io/bitoai/xmcp")
        
        local tracker_ver=$(grep -A 10 '"cis-tracker"' "$versions_file" | grep '"version"' | head -1 | cut -d'"' -f4 || echo "latest")
        local tracker_img=$(grep -A 10 '"cis-tracker"' "$versions_file" | grep '"image"' | head -1 | cut -d'"' -f4 || echo "docker.io/bitoai/cis-tracking")
        
        local mysql_ver=$(grep -A 10 '"mysql"' "$versions_file" | grep '"version"' | head -1 | cut -d'"' -f4 || echo "8.0")
        local mysql_img=$(grep -A 10 '"mysql"' "$versions_file" | grep '"image"' | head -1 | cut -d'"' -f4 || echo "mysql")
    else
        # Use jq for reliable JSON parsing
        local config_ver=$(jq -r '.services."cis-config".version' "$versions_file" 2>/dev/null || echo "latest")
        local config_img=$(jq -r '.services."cis-config".image' "$versions_file" 2>/dev/null || echo "docker.io/bitoai/cis-config")
        
        local manager_ver=$(jq -r '.services."cis-manager".version' "$versions_file" 2>/dev/null || echo "latest")
        local manager_img=$(jq -r '.services."cis-manager".image' "$versions_file" 2>/dev/null || echo "docker.io/bitoai/cis-manager")
        
        local provider_ver=$(jq -r '.services."cis-provider".version' "$versions_file" 2>/dev/null || echo "latest")
        local provider_img=$(jq -r '.services."cis-provider".image' "$versions_file" 2>/dev/null || echo "docker.io/bitoai/xmcp")
        
        local tracker_ver=$(jq -r '.services."cis-tracker".version' "$versions_file" 2>/dev/null || echo "latest")
        local tracker_img=$(jq -r '.services."cis-tracker".image' "$versions_file" 2>/dev/null || echo "docker.io/bitoai/cis-tracking")
        
        local mysql_ver=$(jq -r '.services."mysql".version' "$versions_file" 2>/dev/null || echo "8.0")
        local mysql_img=$(jq -r '.services."mysql".image' "$versions_file" 2>/dev/null || echo "mysql")
    fi
    
    # Update VERSION variables
    sed -i.bak "s|^CIS_CONFIG_VERSION=.*|CIS_CONFIG_VERSION=${config_ver}|" "$env_file"
    sed -i.bak "s|^CIS_MANAGER_VERSION=.*|CIS_MANAGER_VERSION=${manager_ver}|" "$env_file"
    sed -i.bak "s|^CIS_PROVIDER_VERSION=.*|CIS_PROVIDER_VERSION=${provider_ver}|" "$env_file"
    sed -i.bak "s|^CIS_TRACKER_VERSION=.*|CIS_TRACKER_VERSION=${tracker_ver}|" "$env_file"
    
    # Update complete IMAGE paths (image:version)
    sed -i.bak "s|^CIS_CONFIG_IMAGE=.*|CIS_CONFIG_IMAGE=${config_img}:${config_ver}|" "$env_file"
    sed -i.bak "s|^CIS_MANAGER_IMAGE=.*|CIS_MANAGER_IMAGE=${manager_img}:${manager_ver}|" "$env_file"
    sed -i.bak "s|^CIS_PROVIDER_IMAGE=.*|CIS_PROVIDER_IMAGE=${provider_img}:${provider_ver}|" "$env_file"
    sed -i.bak "s|^CIS_TRACKER_IMAGE=.*|CIS_TRACKER_IMAGE=${tracker_img}:${tracker_ver}|" "$env_file"
    sed -i.bak "s|^MYSQL_IMAGE=.*|MYSQL_IMAGE=${mysql_img}:${mysql_ver}|" "$env_file"
    
    # Clean up backup files
    rm -f "${env_file}.bak"
    
    echo "✓ Refreshed service versions from $versions_file to $env_file"
    return 0
}

to_int_floor() {
    awk -v v="$1" 'BEGIN { printf "%d", v }'
}

round_cpu_band() {
    local v
    v="$(to_int_floor "$1")"
    if (( v < 2 )); then echo 1
    elif (( v < 4 )); then echo 2
    elif (( v < 8 )); then echo 4
    else echo 8
    fi
}

detect_resource_caps() {

    local output_file="$1"
    log_silent "env file path details: $output_file"

    local OS
    OS="$(uname -s)"

    # -------------------------------
    # Detect CPU cores
    # -------------------------------
    local TOTAL_CORES
    if [[ "$OS" == "Darwin" ]]; then
        TOTAL_CORES="$(sysctl -n hw.ncpu)"
    else
        TOTAL_CORES="$(nproc)"
    fi

    # -------------------------------
    # Detect total memory (GB)
    # -------------------------------
    local TOTAL_MEM_GB
    if [[ "$OS" == "Darwin" ]]; then
        TOTAL_MEM_GB="$(($(sysctl -n hw.memsize) / 1024 / 1024 / 1024))"
    else
        TOTAL_MEM_GB="$(free -g | awk '/^Mem:/ {print $2}')"
    fi

    # Safety fallback
    TOTAL_CORES="${TOTAL_CORES:-4}"
    TOTAL_MEM_GB="${TOTAL_MEM_GB:-8}"

    # -------------------------------
    # Baseline (4 cores / 8 GB)
    # -------------------------------
    local BASE_CORES=4
    local BASE_MEM=8

    local BASE_PROVIDER_MEM=1
    local BASE_MANAGER_MEM=2

    local BASE_PROVIDER_CPU=1.0
    local BASE_MANAGER_CPU=2.0

    # -------------------------------
    # Scale factors
    # -------------------------------
    local CPU_SCALE MEM_SCALE
    CPU_SCALE=$(awk "BEGIN {print $TOTAL_CORES / $BASE_CORES}")
    MEM_SCALE=$(awk "BEGIN {print $TOTAL_MEM_GB / $BASE_MEM}")

    # -------------------------------
    # OS-specific tuning
    # -------------------------------
    local CPU_FACTOR MEM_FACTOR
    if [[ "$OS" == "Darwin" ]]; then
        # macOS – conservative
        CPU_FACTOR=0.6
        MEM_FACTOR=0.6
    else
        # Linux – aggressive but safe
        CPU_FACTOR=0.85
        MEM_FACTOR=0.8
    fi

    # -------------------------------
    # Final calculations
    # -------------------------------
    CIS_PROVIDER_CPU_LIMIT=$(awk "BEGIN {
        v=$BASE_PROVIDER_CPU * $CPU_SCALE * $CPU_FACTOR;
        if (v < 1.0) v=1.0;
        printf \"%.2f\", v
    }")

    CIS_MANAGER_CPU_LIMIT=$(awk "BEGIN {
        v=$BASE_MANAGER_CPU * $CPU_SCALE * $CPU_FACTOR;
        if (v < 2.0) v=2.0;
        printf \"%.2f\", v
    }")

    CIS_PROVIDER_MEMORY_LIMIT=$(awk "BEGIN {
        v=$BASE_PROVIDER_MEM * $MEM_SCALE * $MEM_FACTOR;
        if (v < 1) v=1;
        printf \"%dg\", int(v)
    }")

    CIS_MANAGER_MEMORY_LIMIT=$(awk "BEGIN {
        v=$BASE_MANAGER_MEM * $MEM_SCALE * $MEM_FACTOR;
        if (v < 2) v=2;
        printf \"%dg\", int(v)
    }")

    CIS_PROVIDER_CPU_LIMIT="$(round_cpu_band "${CIS_PROVIDER_CPU_LIMIT}")"
    CIS_MANAGER_CPU_LIMIT="$(round_cpu_band "${CIS_MANAGER_CPU_LIMIT}")"

    log_silent ""
    log_silent "🖥 System detected:"
    log_silent "   OS:        $OS"
    log_silent "   CPU cores: $TOTAL_CORES"
    log_silent "   Memory:    ${TOTAL_MEM_GB}GB"
    log_silent ""
    log_silent "🚀 Resource caps applied:"
    log_silent "   CIS_PROVIDER_CPU_LIMIT=$CIS_PROVIDER_CPU_LIMIT"
    log_silent "   CIS_MANAGER_CPU_LIMIT=$CIS_MANAGER_CPU_LIMIT"
    log_silent "   CIS_PROVIDER_MEMORY_LIMIT=$CIS_PROVIDER_MEMORY_LIMIT"
    log_silent "   CIS_MANAGER_MEMORY_LIMIT=$CIS_MANAGER_MEMORY_LIMIT"

    set_env_key_value "CIS_PROVIDER_CPU_LIMIT" "${CIS_PROVIDER_CPU_LIMIT}" "${output_file}"
    set_env_key_value "CIS_MANAGER_CPU_LIMIT" "${CIS_MANAGER_CPU_LIMIT}" "${output_file}"
    set_env_key_value "CIS_PROVIDER_MEMORY_LIMIT" "${CIS_PROVIDER_MEMORY_LIMIT}" "${output_file}"
    set_env_key_value "CIS_MANAGER_MEMORY_LIMIT" "${CIS_MANAGER_MEMORY_LIMIT}" "${output_file}"

}


# Function to generate .env-bitoarch with all parameters
# Called by setup.sh with collected values, or standalone with auto-generated values
generate_env_with_params() {
    local output_file="$1"
    local bito_api_key="$2"
    local db_root_pass="$3"
    local db_user_pass="$4"
    local jwt_secret="$5"
    local cis_manager_api_key="$6"
    local cis_config_api_key="$7"
    local cis_provider_api_key="$8"
    local bito_mcp_access_token="$9"
    local secrets_encryption_key="${10}"
    local cis_config_version="${11}"
    local cis_manager_version="${12}"
    local cis_provider_version="${13}"
    local cis_provider_external_port="${14:-8080}"
    local cis_manager_external_port="${15:-9090}"
    local cis_config_external_port="${16:-8081}"
    local mysql_external_port="${17:-3306}"
    local git_provider="${18:-gitlab}"
    local git_access_token="${19}"
    local git_domain="${20}"
    local git_user="${21}"
    local cis_tracker_external_port="${22}"
    local cis_tracker_version="${23}"
    
    [ ! -f "$ENV_EXAMPLE" ] && echo "Error: $ENV_EXAMPLE not found" && return 1
    
    # Copy template (gets ALL properties with defaults)
    log_silent "Data: $output_file"
    cp "$ENV_EXAMPLE" "$output_file"
    
    # Replace generated values
    sed -i.bak "s/# Generated on .*/# Generated on $(date)/" "$output_file"
    sed -i.bak "s|MYSQL_ROOT_PASSWORD=.*|MYSQL_ROOT_PASSWORD=${db_root_pass}|" "$output_file"
    sed -i.bak "s|MYSQL_PASSWORD=.*|MYSQL_PASSWORD=${db_user_pass}|" "$output_file"
    sed -i.bak "s|JWT_SECRET=.*|JWT_SECRET=${jwt_secret}|" "$output_file"
    sed -i.bak "s|BITO_API_KEY=.*|BITO_API_KEY=${bito_api_key}|" "$output_file"
    sed -i.bak "s|BITO_MCP_ACCESS_TOKEN=.*|BITO_MCP_ACCESS_TOKEN=${bito_mcp_access_token}|" "$output_file"
    sed -i.bak "s|CIS_MANAGER_API_KEY=.*|CIS_MANAGER_API_KEY=${cis_manager_api_key}|" "$output_file"
    sed -i.bak "s|CIS_CONFIG_API_KEY=.*|CIS_CONFIG_API_KEY=${cis_config_api_key}|" "$output_file"
    sed -i.bak "s|CIS_PROVIDER_API_KEY=.*|CIS_PROVIDER_API_KEY=${cis_provider_api_key}|" "$output_file"
    sed -i.bak "s|SECRETS_ENCRYPTION_KEY=.*|SECRETS_ENCRYPTION_KEY=${secrets_encryption_key}|" "$output_file"
    sed -i.bak "s|CIS_CONFIG_VERSION=.*|CIS_CONFIG_VERSION=${cis_config_version}|" "$output_file"
    sed -i.bak "s|CIS_MANAGER_VERSION=.*|CIS_MANAGER_VERSION=${cis_manager_version}|" "$output_file"
    sed -i.bak "s|CIS_PROVIDER_VERSION=.*|CIS_PROVIDER_VERSION=${cis_provider_version}|" "$output_file"
    sed -i.bak "s|CIS_PROVIDER_EXTERNAL_PORT=.*|CIS_PROVIDER_EXTERNAL_PORT=${cis_provider_external_port}|" "$output_file"
    sed -i.bak "s|CIS_MANAGER_EXTERNAL_PORT=.*|CIS_MANAGER_EXTERNAL_PORT=${cis_manager_external_port}|" "$output_file"
    sed -i.bak "s|CIS_CONFIG_EXTERNAL_PORT=.*|CIS_CONFIG_EXTERNAL_PORT=${cis_config_external_port}|" "$output_file"
    sed -i.bak "s|MYSQL_EXTERNAL_PORT=.*|MYSQL_EXTERNAL_PORT=${mysql_external_port}|" "$output_file"
    sed -i.bak "s|GIT_PROVIDER=.*|GIT_PROVIDER=${git_provider}|" "$output_file"
    sed -i.bak "s|GIT_ACCESS_TOKEN=.*|GIT_ACCESS_TOKEN=${git_access_token}|" "$output_file"
    sed -i.bak "s|GIT_DOMAIN_URL=.*|GIT_DOMAIN_URL=${git_domain}|" "$output_file"
    sed -i.bak "s|GIT_USER=.*|GIT_USER=${git_user}|" "$output_file"
    sed -i.bak "s|CIS_TRACKER_EXTERNAL_PORT=.*|CIS_TRACKER_EXTERNAL_PORT=${cis_tracker_external_port}|" "$output_file"
    sed -i.bak "s|CIS_TRACKER_VERSION=.*|CIS_TRACKER_VERSION=${cis_tracker_version}|" "$output_file"
    
    # Update complete image paths from service-versions.json
    local versions_file="${SCRIPT_DIR}/versions/service-versions.json"
    if [ -f "$versions_file" ] && command -v jq >/dev/null 2>&1; then
        local config_img=$(jq -r '.services."cis-config".image' "$versions_file" 2>/dev/null || echo "docker.io/bitoai/cis-config")
        local config_ver=$(jq -r '.services."cis-config".version' "$versions_file" 2>/dev/null || echo "latest")
        sed -i.bak "s|CIS_CONFIG_IMAGE=.*|CIS_CONFIG_IMAGE=${config_img}:${config_ver}|" "$output_file"
        
        local manager_img=$(jq -r '.services."cis-manager".image' "$versions_file" 2>/dev/null || echo "docker.io/bitoai/cis-manager")
        local manager_ver=$(jq -r '.services."cis-manager".version' "$versions_file" 2>/dev/null || echo "latest")
        sed -i.bak "s|CIS_MANAGER_IMAGE=.*|CIS_MANAGER_IMAGE=${manager_img}:${manager_ver}|" "$output_file"
        
        local provider_img=$(jq -r '.services."cis-provider".image' "$versions_file" 2>/dev/null || echo "docker.io/bitoai/xmcp")
        local provider_ver=$(jq -r '.services."cis-provider".version' "$versions_file" 2>/dev/null || echo "latest")
        sed -i.bak "s|CIS_PROVIDER_IMAGE=.*|CIS_PROVIDER_IMAGE=${provider_img}:${provider_ver}|" "$output_file"
        
        local tracker_img=$(jq -r '.services."cis-tracker".image' "$versions_file" 2>/dev/null || echo "docker.io/bitoai/cis-tracking")
        local tracker_ver=$(jq -r '.services."cis-tracker".version' "$versions_file" 2>/dev/null || echo "latest")
        sed -i.bak "s|CIS_TRACKER_IMAGE=.*|CIS_TRACKER_IMAGE=${tracker_img}:${tracker_ver}|" "$output_file"
        
        local mysql_img=$(jq -r '.services."mysql".image' "$versions_file" 2>/dev/null || echo "mysql")
        local mysql_ver=$(jq -r '.services."mysql".version' "$versions_file" 2>/dev/null || echo "8.0")
        sed -i.bak "s|MYSQL_IMAGE=.*|MYSQL_IMAGE=${mysql_img}:${mysql_ver}|" "$output_file"
    fi

    detect_resource_caps ${output_file}

    rm -f "${output_file}.bak"
    chmod 600 "$output_file"
    
    echo "✓ Environment file generated successfully: $output_file"
    return 0
}

# Simplified function for standalone use (auto-generates everything)
generate_env_file() {
    local output_file="${1:-.env-bitoarch}"
    
    [ ! -f "$ENV_EXAMPLE" ] && echo "Error: $ENV_EXAMPLE not found" && return 1
    
    # Auto-generate all secrets
    local DB_ROOT_PASS=$(generate_secret)
    local DB_USER_PASS=$(generate_secret)
    local JWT_SECRET=$(generate_secret)
    local BITO_API_KEY=$(generate_secret)
    local CIS_MANAGER_API_KEY=$(generate_secret)
    local CIS_CONFIG_API_KEY=$(generate_secret)
    local CIS_PROVIDER_API_KEY=$(generate_secret)
    local BITO_MCP_ACCESS_TOKEN=$(generate_secret)
    local SECRETS_ENCRYPTION_KEY=$(generate_encryption_key)
    
    # Load complete image paths from service-versions.json
    local CIS_CONFIG_IMAGE="docker.io/bitoai/cis-config:latest"
    local CIS_MANAGER_IMAGE="docker.io/bitoai/cis-manager:latest"
    local CIS_PROVIDER_IMAGE="docker.io/bitoai/xmcp:latest"
    local CIS_TRACKER_IMAGE="docker.io/bitoai/cis-tracking:latest"
    local MYSQL_IMAGE="mysql:8.0"
    
    local versions_file="${SCRIPT_DIR}/versions/service-versions.json"
    if [ -f "$versions_file" ] && command -v jq >/dev/null 2>&1; then
        # Build complete image paths: registry/org/image:version
        local config_img=$(jq -r '.services."cis-config".image' "$versions_file" 2>/dev/null || echo "docker.io/bitoai/cis-config")
        local config_ver=$(jq -r '.services."cis-config".version' "$versions_file" 2>/dev/null || echo "latest")
        CIS_CONFIG_IMAGE="${config_img}:${config_ver}"
        
        local manager_img=$(jq -r '.services."cis-manager".image' "$versions_file" 2>/dev/null || echo "docker.io/bitoai/cis-manager")
        local manager_ver=$(jq -r '.services."cis-manager".version' "$versions_file" 2>/dev/null || echo "latest")
        CIS_MANAGER_IMAGE="${manager_img}:${manager_ver}"
        
        local provider_img=$(jq -r '.services."cis-provider".image' "$versions_file" 2>/dev/null || echo "docker.io/bitoai/xmcp")
        local provider_ver=$(jq -r '.services."cis-provider".version' "$versions_file" 2>/dev/null || echo "latest")
        CIS_PROVIDER_IMAGE="${provider_img}:${provider_ver}"
        
        local tracker_img=$(jq -r '.services."cis-tracker".image' "$versions_file" 2>/dev/null || echo "docker.io/bitoai/cis-tracking")
        local tracker_ver=$(jq -r '.services."cis-tracker".version' "$versions_file" 2>/dev/null || echo "latest")
        CIS_TRACKER_IMAGE="${tracker_img}:${tracker_ver}"
        
        local mysql_img=$(jq -r '.services."mysql".image' "$versions_file" 2>/dev/null || echo "mysql")
        local mysql_ver=$(jq -r '.services."mysql".version' "$versions_file" 2>/dev/null || echo "8.0")
        MYSQL_IMAGE="${mysql_img}:${mysql_ver}"
    fi
    
    # Call shared function
    generate_env_with_params "$output_file" \
        "$BITO_API_KEY" "$DB_ROOT_PASS" "$DB_USER_PASS" "$JWT_SECRET" \
        "$CIS_MANAGER_API_KEY" "$CIS_CONFIG_API_KEY" "$CIS_PROVIDER_API_KEY" \
        "$BITO_MCP_ACCESS_TOKEN" "$SECRETS_ENCRYPTION_KEY" \
        "$CIS_CONFIG_VERSION" "$CIS_MANAGER_VERSION" "$CIS_PROVIDER_VERSION"
    
    return $?
}

# Main
if [ "${BASH_SOURCE[0]}" == "${0}" ]; then
    generate_env_file "${1:-.env-bitoarch-test}"
fi
