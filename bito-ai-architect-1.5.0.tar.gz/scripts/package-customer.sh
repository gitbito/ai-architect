#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
# Bito's AI Architect Unified Customer Package Builder
# Securely creates production-ready packages for customer distribution
# Supports Docker registry binaries (CI/CD) and dummy binaries (local development)

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[1;34m'
NC='\033[0m' # No Color

# Configuration
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PLATFORM_DIR="$(dirname "$SCRIPT_DIR")"
RELEASES_DIR="${PLATFORM_DIR}/releases"
VERSIONS_DIR="${PLATFORM_DIR}/versions"
TEMP_DIR="/tmp/bito-ai-architect-build-$$"
DATE=$(date +%Y%m%d_%H%M%S)

# Default settings
PLATFORM_ENV="production"
VERSION_OVERRIDE=""   # Manual version override
CI_MODE=false        # CI/CD environment detection

# Service versions (loaded from JSON)
PLATFORM_VERSION=""
CIS_CONFIG_VERSION=""
CIS_MANAGER_VERSION=""
CIS_PROVIDER_VERSION=""

# Logging functions
log() {
    local message="$1"
    local timestamp="[$(date +'%Y-%m-%d %H:%M:%S')]"
    
    echo "$timestamp $message" | tee -a "$RELEASES_DIR/packaging.log" 2>/dev/null || echo "$timestamp $message"
}

print_status() {
    echo -e "${GREEN}✓${NC} $1"
    log "SUCCESS: $1"
}

print_error() {
    echo -e "${RED}✗${NC} $1"
    log "ERROR: $1"
}

print_info() {
    echo -e "${BLUE}ℹ${NC} $1"
    log "INFO: $1"
}

print_warning() {
    echo -e "${YELLOW}⚠${NC} $1"
    log "WARNING: $1"
}

# Load service versions from JSON configuration
load_service_versions() {
    local versions_file="${VERSIONS_DIR}/service-versions.json"
    
    if [ ! -f "$versions_file" ]; then
        print_error "Service versions file not found: $versions_file"
        exit 1
    fi
    
    print_info "Loading service versions from: $versions_file"
    
    # Extract platform version using basic parsing (no jq dependency)
    PLATFORM_VERSION=$(grep -m1 '"version":' "$versions_file" | cut -d'"' -f4)
    
    # Extract service versions
    CIS_CONFIG_VERSION=$(grep -A 10 '"cis-config"' "$versions_file" | grep '"version"' | head -1 | cut -d'"' -f4)
    CIS_MANAGER_VERSION=$(grep -A 10 '"cis-manager"' "$versions_file" | grep '"version"' | head -1 | cut -d'"' -f4)
    CIS_PROVIDER_VERSION=$(grep -A 10 '"cis-provider"' "$versions_file" | grep '"version"' | head -1 | cut -d'"' -f4)
    
    # Use version override if provided
    if [ -n "$VERSION_OVERRIDE" ]; then
        PLATFORM_VERSION="$VERSION_OVERRIDE"
        print_info "Using version override: $PLATFORM_VERSION"
    fi
    
    print_info "Platform Version: $PLATFORM_VERSION"
    print_info "Service Versions: config=$CIS_CONFIG_VERSION, manager=$CIS_MANAGER_VERSION, provider=$CIS_PROVIDER_VERSION"
}

# Detect if running in CI/CD environment
detect_environment() {
    if [[ "$CI" == "true" ]] || [[ -n "$GITLAB_CI" ]] || [[ -n "$JENKINS_URL" ]] || [[ "$CI_MODE" == "true" ]]; then
        CI_MODE=true
        print_info "Detected CI/CD environment"
    else
        print_info "Detected local environment"
    fi
    
    print_info "Binary Source: $([ "$CI_MODE" == "true" ] && echo "Docker Registry (Production)" || echo "Dummy Binaries (Development)")"
}

# Configure Docker for insecure registry (required for Nexus)
configure_docker_registry() {
    local registry="$1"
    
    print_info "Configuring Docker for insecure registry: $registry"
    
    # Check if Docker daemon is running
    if ! docker info >/dev/null 2>&1; then
        print_error "Docker daemon is not running"
        return 1
    fi
    
    # For macOS/Windows Docker Desktop, we need to configure insecure registries
    # This typically requires manual configuration in Docker Desktop settings
    print_warning "Ensure Docker Desktop is configured with insecure registry: $registry"
    print_info "Docker Desktop → Settings → Docker Engine → Add to 'insecure-registries': [\"$registry\"]"
    
    return 0
}

# Docker login to registry with secure credential handling
docker_registry_login() {
    local registry="$1"
    
    # Check for required environment variables
    if [ -z "$DOCKER_REGISTRY_USERNAME" ] || [ -z "$DOCKER_REGISTRY_PASSWORD" ]; then
        print_error "Docker registry credentials not found in environment"
        print_error "Required: DOCKER_REGISTRY_USERNAME and DOCKER_REGISTRY_PASSWORD"
        print_info "In GitLab CI/CD: Set these as masked variables in project settings"
        return 1
    fi
    
    print_info "Logging into Docker registry: $registry"
    
    # Use stdin to avoid exposing password in process list
    if echo "$DOCKER_REGISTRY_PASSWORD" | docker login "$registry" -u "$DOCKER_REGISTRY_USERNAME" --password-stdin >/dev/null 2>&1; then
        print_status "Successfully logged into registry: $registry"
        return 0
    else
        print_error "Failed to login to registry: $registry"
        print_error "Check credentials and registry accessibility"
        return 1
    fi
}

# Extract binary from Docker image
extract_binary_from_docker_image() {
    local service="$1"
    local image="$2" 
    local version="$3"
    local binary_path_in_container="$4"
    local target_path="$5"
    
    local full_image="${image}:${version}"
    
    print_info "Extracting binary for $service from image: $full_image"
    
    # Create target directory
    mkdir -p "$(dirname "$target_path")"
    
    # Pull the image
    if ! docker pull "$full_image" >/dev/null 2>&1; then
        print_error "Failed to pull Docker image: $full_image"
        return 1
    fi
    
    # Create temporary container and copy binary
    local container_id=$(docker create "$full_image" 2>/dev/null)
    if [ -z "$container_id" ]; then
        print_error "Failed to create temporary container from: $full_image"
        return 1
    fi
    
    # Copy binary from container
    if docker cp "${container_id}:${binary_path_in_container}" "$target_path" >/dev/null 2>&1; then
        # Cleanup container
        docker rm "$container_id" >/dev/null 2>&1
        
        # Make binary executable
        chmod +x "$target_path"
        print_status "Successfully extracted $service binary"
        return 0
    else
        # Cleanup container on failure
        docker rm "$container_id" >/dev/null 2>&1
        print_error "Failed to extract binary from container: $binary_path_in_container"
        return 1
    fi
}

# Download binary from Docker registry (CI/CD mode)
download_service_binary() {
    local service="$1"
    local version="$2"
    local target_path="$3"
    
    # Extract registry configuration from versions file
    local versions_file="${VERSIONS_DIR}/service-versions.json"
    local registry=$(grep -A 20 "\"$service\"" "$versions_file" | grep '"registry"' | cut -d'"' -f4)
    local image=$(grep -A 20 "\"$service\"" "$versions_file" | grep '"image"' | cut -d'"' -f4) 
    local binary_path_in_container=$(grep -A 20 "\"$service\"" "$versions_file" | grep '"binary_path_in_container"' | cut -d'"' -f4)
    
    if [ -z "$registry" ] || [ -z "$image" ] || [ -z "$binary_path_in_container" ]; then
        print_warning "Incomplete Docker registry configuration for $service"
        return 1
    fi
    
    print_info "Downloading $service $version from Docker registry"
    
    # Configure Docker for insecure registry
    if ! configure_docker_registry "$registry"; then
        print_warning "Docker registry configuration may need manual setup"
    fi
    
    # Login to registry
    if ! docker_registry_login "$registry"; then
        return 1
    fi
    
    # Extract binary from Docker image
    if extract_binary_from_docker_image "$service" "$image" "$version" "$binary_path_in_container" "$target_path"; then
        return 0
    else
        return 1
    fi
}

# Validate dummy binary exists and works
validate_dummy_binary() {
    local service="$1"
    local binary_path="$PLATFORM_DIR/services/$service/bin/$service"
    
    if [ ! -f "$binary_path" ]; then
        print_warning "Dummy binary not found: $binary_path"
        print_info "To build real $service binary:"
        print_info "  1. Clone $service repository"
        print_info "  2. Build binary and copy to: $binary_path"
        return 1
    fi
    
    if [ ! -x "$binary_path" ]; then
        chmod +x "$binary_path" 2>/dev/null || true
    fi
    
    print_info "Using dummy binary for $service: $binary_path"
    return 0
}

# Prepare service binaries (Docker registry or dummy)
prepare_service_binaries() {
    print_info "Preparing service binaries..."
    
    # Check if we should use registry binaries based on CI detection and configuration
    local use_registry="$CI_MODE"
    
    # Handle cis-config
    if [[ "$use_registry" == "true" ]]; then
        if download_service_binary "cis-config" "$CIS_CONFIG_VERSION" "$TEMP_DIR/services/cis-config/bin/cis-config"; then
            print_status "Using production binary for cis-config"
        else
            print_warning "Failed to download cis-config binary, falling back to dummy"
            validate_dummy_binary "cis-config" || true
        fi
    else
        validate_dummy_binary "cis-config" || print_warning "cis-config dummy binary not available"
    fi
    
    # Handle cis-manager
    if [[ "$use_registry" == "true" ]]; then
        if download_service_binary "cis-manager" "$CIS_MANAGER_VERSION" "$TEMP_DIR/services/cis-manager/bin/cis-manager"; then
            print_status "Using production binary for cis-manager"
        else
            print_warning "Failed to download cis-manager binary, falling back to dummy"
            validate_dummy_binary "cis-manager" || true
        fi
    else
        validate_dummy_binary "cis-manager" || print_warning "cis-manager dummy binary not available"
    fi
    
    print_status "Service binaries prepared"
}

# Get version information 
get_version_info() {
    if [ -n "$VERSION_OVERRIDE" ]; then
        echo "$VERSION_OVERRIDE"
        return
    fi
    
    # Both modes use platform version from service-versions.json
    echo "$PLATFORM_VERSION"
}

# Create clean build directory
create_build_directory() {
    print_info "Creating clean build directory..."
    
    rm -rf "$TEMP_DIR"
    mkdir -p "$TEMP_DIR"
    
    # Copy entire platform directory
    cp -r "$PLATFORM_DIR"/* "$TEMP_DIR/" 2>/dev/null || true
    cp -r "$PLATFORM_DIR"/.[^.]* "$TEMP_DIR/" 2>/dev/null || true
    
    print_status "Build directory created: $TEMP_DIR"
}

# Clean development files from build directory
clean_development_files() {
    print_info "Removing development files from customer package..."
    
    cd "$TEMP_DIR"
    
    # Files and directories to remove
    local exclude_patterns=(
        ".git"
        "*.log"
        "setup.log"
        ".env-bitoarch"
        ".env-bitoarch.local"
        ".env-bitoarch.development"
        ".env-bitoarch.staging"
        ".env-bitoarch.production"
        ".env-bitoarch-test"
        "temp"
        "*.tmp"
        "*.pid"
        ".DS_Store"
        "Thumbs.db"
        ".vscode"
        ".idea"
        "*.swp"
        "*.swo"
        "docker-volumes"
        "backups"
        "node_modules"
        "npm-debug.log"
        "releases"
        ".packageignore"
        ".gitignore"
    )
    
    # Use .packageignore if it exists for additional exclusions
    if [ -f "${PLATFORM_DIR}/.packageignore" ]; then
        print_info "Using .packageignore for additional exclusions"
        while IFS= read -r pattern; do
            # Skip empty lines and comments
            if [[ -n "$pattern" && ! "$pattern" =~ ^[[:space:]]*# ]]; then
                exclude_patterns+=("$pattern")
            fi
        done < "${PLATFORM_DIR}/.packageignore"
    fi
    
    # Remove excluded files and directories
    for pattern in "${exclude_patterns[@]}"; do
        if [[ "$pattern" == *"*"* ]]; then
            find . -name "$pattern" -type f -delete 2>/dev/null || true
        else
            if [ -e "$pattern" ]; then
                rm -rf "$pattern" 2>/dev/null || true
            fi
        fi
    done
    
    print_status "Development files cleaned"
}

# Ensure executable permissions on scripts
ensure_executable_permissions() {
    print_info "Ensuring executable permissions on scripts..."
    
    cd "$TEMP_DIR"
    
    # Make all shell scripts executable in key directories
    find scripts -name "*.sh" -type f -exec chmod +x {} \; 2>/dev/null || true
    find tests -name "*.sh" -type f -exec chmod +x {} \; 2>/dev/null || true
    find services -name "*.sh" -type f -exec chmod +x {} \; 2>/dev/null || true
    
    # Explicitly ensure critical scripts are executable
    chmod +x setup.sh 2>/dev/null || true
    chmod +x build-services.sh 2>/dev/null || true
    chmod +x bitoarch 2>/dev/null || true
    
    print_status "Executable permissions set on all scripts"
}

# Create version manifest
create_version_manifest() {
    local version="$1"
    local manifest_file="$TEMP_DIR/version-manifest.json"
    
    print_info "Creating version manifest..."
    
    # Get binary source information
    local binary_source="dummy"
    if [[ "$CI_MODE" == "true" ]]; then
        binary_source="docker-registry"
    fi
    
    # Create version manifest
    cat > "$manifest_file" << EOF
{
  "platform_info": {
    "name": "Bito's AI Architect",
    "version": "${version}",
    "build_timestamp": "$(date -u +%Y-%m-%dT%H:%M:%SZ)",
    "build_date": "$(date)",
    "package_type": "customer-release",
    "platform_env": "${PLATFORM_ENV}",
    "binary_source": "${binary_source}"
  },
  "services": {
    "cis-config": {
      "version": "${CIS_CONFIG_VERSION}",
      "type": "Go binary",
      "port": 8081,
      "health_endpoint": "/health",
      "description": "Configuration management service",
      "status": "production-ready"
    },
    "cis-manager": {
      "version": "${CIS_MANAGER_VERSION}",
      "type": "Go binary",
      "port": 9090,
      "health_endpoint": "/health", 
      "description": "Repository analysis and management service",
      "status": "production-ready"
    },
    "cis-provider": {
      "version": "${CIS_PROVIDER_VERSION}",
      "type": "Node.js application",
      "port": 8080,
      "health_endpoint": "/health",
      "description": "MCP server providing repository intelligence APIs",
      "status": "production-ready"
    },
    "mysql": {
      "version": "8.0",
      "type": "Docker container",
      "port": 3306,
      "description": "MySQL database for persistent storage",
      "status": "production-ready"
    }
  },
  "system_requirements": {
    "docker": "20.10+",
    "docker_compose": "2.0+", 
    "memory": "4GB minimum, 8GB recommended",
    "storage": "20GB minimum, 50GB recommended",
    "cpu": "2 cores minimum, 4+ cores recommended"
  },
  "installation": {
    "setup_script": "./setup.sh",
    "quick_start": "Run './setup.sh' and follow prompts",
    "documentation": ["README.md"]
  }
}
EOF
    
    print_status "Version manifest created"
}


# Create package with FIXED checksum verification (fixes Comment #13)
create_customer_package() {
    local version="$1"
    local package_name="bito-ai-architect-${version}"
    local package_path="${RELEASES_DIR}/${package_name}.tar.gz"
    
    print_info "Creating customer package..."
    
    # Ensure releases directory exists
    mkdir -p "$RELEASES_DIR"
    
    # Create compressed package
    cd "$(dirname "$TEMP_DIR")"
    tar -czf "$package_path" -C "$TEMP_DIR" .
    
    # Verify package was created
    if [ ! -f "$package_path" ]; then
        print_error "Failed to create customer package"
        exit 1
    fi
    
    
    # Get package info
    local size_bytes=$(stat -f%z "$package_path" 2>/dev/null || stat -c%s "$package_path" 2>/dev/null || echo "0")
    local size_mb=$((size_bytes / 1024 / 1024))
    
    print_status "Customer package created successfully"
    print_info "Package: $(basename "$package_path")"
    print_info "Size: ${size_mb}MB"
    
    echo "$package_path"
}

# Cleanup function
cleanup() {
    if [ -d "$TEMP_DIR" ]; then
        rm -rf "$TEMP_DIR"
        print_info "Cleaned up temporary files"
    fi
    
    # Logout from Docker registry if we logged in
    if [[ "$CI_MODE" == "true" ]] && [ -n "$DOCKER_REGISTRY_USERNAME" ]; then
        docker logout nexus.bito.ops:5000 >/dev/null 2>&1 || true
    fi
}

# Trap cleanup on exit
trap cleanup EXIT

# Parse command line arguments
parse_arguments() {
    while [[ $# -gt 0 ]]; do
        case $1 in
            --version=*)
                VERSION_OVERRIDE="${1#--version=}"
                shift
                ;;
            *)
                print_error "Unknown option: $1"
                print_error "Usage: $0 [--version=X.Y.Z]"
                exit 1
                ;;
        esac
    done
}

# Main function
main() {
    echo -e "${BLUE}Bito's AI Architect Unified Customer Package Builder${NC}"
    echo "====================================================="
    echo ""
    
    # Parse arguments
    parse_arguments "$@"
    
    # Create releases directory and ensure logging works
    mkdir -p "$RELEASES_DIR"
    
    # Load service versions
    load_service_versions
    detect_environment
    
    # Get final version
    local final_version=$(get_version_info)
    print_info "Building customer package for version: $final_version"
    
    # Execute packaging workflow
    create_build_directory
    clean_development_files
    ensure_executable_permissions
    prepare_service_binaries
    create_version_manifest "$final_version"
    
    # Create final package
    local package_path=$(create_customer_package "$final_version")
    
    # Success summary
    echo ""
    print_status "✅ Customer package build completed successfully!"
    echo -e "${BLUE}📦 Package Details:${NC}"
    echo "   Location: $package_path"
    echo "   Version: $final_version"
    echo "   Platform Environment: $PLATFORM_ENV"
    echo "   Binary Source: $([ "$CI_MODE" == "true" ] && echo "Docker Registry (Production)" || echo "Dummy Binaries (Development)")"
    echo ""
    echo -e "${GREEN}📋 Next Steps:${NC}"
    echo "   1. Test package: Extract and run ./setup.sh"
    echo "   2. Upload to release artifacts for customer download"
    echo ""
}

# Run main function with all arguments
main "$@"
