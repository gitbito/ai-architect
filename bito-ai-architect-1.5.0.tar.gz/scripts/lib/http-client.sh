#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
# CIS Platform CLI - HTTP Client
# Handles HTTP requests with retry logic and error handling

# Source core functions if not already loaded
if [ -z "$SCRIPT_DIR" ]; then
    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && cd ../.. && pwd)"
    source "${SCRIPT_DIR}/scripts/lib/cli-core.sh"
fi

# HTTP client settings
HTTP_TIMEOUT=30
HTTP_MAX_RETRIES=3
HTTP_RETRY_DELAY=2

# Make HTTP request with retry logic
http_request() {
    local method="$1"
    local url="$2"
    local auth_header="$3"
    local data="$4"
    local content_type="${5:-application/json}"
    
    require_command curl || return 1
    
    local attempt=1
    local response=""
    local http_code=""
    local temp_file=$(mktemp)
    
    while [ $attempt -le $HTTP_MAX_RETRIES ]; do
        # Build curl command - don't use -X for GET as it can cause issues
        if [ "$method" = "GET" ]; then
            local curl_cmd="curl -s -w '\n%{http_code}'"
        else
            local curl_cmd="curl -s -w '\n%{http_code}' -X $method"
        fi
        curl_cmd="$curl_cmd --connect-timeout $HTTP_TIMEOUT"
        
        # Only add Content-Type for non-GET requests (GET doesn't have request body)
        if [ "$method" != "GET" ]; then
            curl_cmd="$curl_cmd -H 'Content-Type: $content_type'"
        fi
        
        if [ -n "$auth_header" ]; then
            curl_cmd="$curl_cmd -H '$auth_header'"
        fi
        
        if [ -n "$data" ] && [ "$method" != "GET" ]; then
            curl_cmd="$curl_cmd -d '$data'"
        fi
        
        curl_cmd="$curl_cmd '$url'"
        
        # Execute request
        response=$(eval $curl_cmd 2>"$temp_file")
        local curl_exit=$?
        
        # Extract HTTP code from last line
        http_code=$(echo "$response" | tail -1)
        response=$(echo "$response" | sed '$d')
        
        # Check for success
        if [ $curl_exit -eq 0 ] && [ "$http_code" -ge 200 ] && [ "$http_code" -lt 300 ]; then
            rm -f "$temp_file"
            echo "$response"
            return 0
        fi
        
        # Handle errors
        if [ $curl_exit -ne 0 ]; then
            if [ $attempt -lt $HTTP_MAX_RETRIES ]; then
                [ "$VERBOSE" = "true" ] && print_warning "Connection failed, retrying... (attempt $attempt/$HTTP_MAX_RETRIES)"
                sleep $HTTP_RETRY_DELAY
                attempt=$((attempt + 1))
                continue
            fi
        fi
        
        # Non-retriable error or max retries reached
        case "$http_code" in
            000)
                print_error "Connection failed: Unable to connect to $url"
                ;;
            401)
                print_error "Authentication failed: Invalid or missing token"
                ;;
            403)
                print_error "Authorization failed: Access denied"
                ;;
            404)
                print_error "Not found: Resource does not exist"
                ;;
            429)
                print_error "Rate limited: Too many requests"
                ;;
            5*)
                print_error "Server error: $http_code"
                ;;
            *)
                print_error "HTTP error: $http_code"
                ;;
        esac
        
        [ "$VERBOSE" = "true" ] && echo "Response: $response" >&2
        rm -f "$temp_file"
        return 1
    done
    
    rm -f "$temp_file"
    return 1
}

# Make generic MCP JSON-RPC request
# Takes the full JSON-RPC request as input to avoid shell escaping issues
mcp_request() {
    local request="$1"
    
    # Make request
    local auth_header="Authorization: Bearer $PROVIDER_TOKEN"
    local response=$(http_request "POST" "${PROVIDER_URL}/mcp" "$auth_header" "$request")
    local exit_code=$?
    
    if [ $exit_code -ne 0 ]; then
        return 1
    fi
    
    # Check for JSON-RPC error
    if require_command jq; then
        local error=$(echo "$response" | jq -r '.error // empty')
        if [ -n "$error" ]; then
            local error_message=$(echo "$error" | jq -r '.message')
            print_error "MCP Error: $error_message"
            [ "$VERBOSE" = "true" ] && echo "$error" | jq '.' >&2
            return 1
        fi
        
        # Extract result
        echo "$response" | jq -r '.result'
        return 0
    else
        # Fallback without jq
        echo "$response"
        return 0
    fi
}

# Make MCP tool call (wraps mcp_request for tools/call)
mcp_call() {
    local tool_name="$1"
    local arguments="${2:-{}}"
    
    # Build complete JSON-RPC request for tools/call
    local request
    if require_command jq; then
        request=$(jq -n --arg name "$tool_name" --argjson args "$arguments" \
            '{jsonrpc: "2.0", method: "tools/call", id: 1, params: {name: $name, arguments: $args}}')
    else
        request="{\"jsonrpc\":\"2.0\",\"method\":\"tools/call\",\"id\":1,\"params\":{\"name\":\"$tool_name\",\"arguments\":$arguments}}"
    fi
    
    # Use generic mcp_request
    mcp_request "$request"
}

# Make REST API call to CIS Config
config_api_call() {
    local method="$1"
    local endpoint="$2"
    local data="$3"
    
    local auth_header="X-API-Key: $CONFIG_API_KEY"
    local url="${CONFIG_URL}${endpoint}"
    
    http_request "$method" "$url" "$auth_header" "$data"
}

# Make REST API call to CIS Manager
manager_api_call() {
    local method="$1"
    local endpoint="$2"
    local data="$3"
    
    local auth_header="X-API-Key: $MANAGER_API_KEY"
    local url="${MANAGER_URL}${endpoint}"
    
    http_request "$method" "$url" "$auth_header" "$data"
}

# Health check for a service
health_check() {
    local service_url="$1"
    
    local response=$(http_request "GET" "${service_url}/health" "" "" "" 2>/dev/null)
    local exit_code=$?
    
    if [ $exit_code -eq 0 ]; then
        if require_command jq; then
            local status=$(echo "$response" | jq -r '.status // "ok"' 2>/dev/null)
            local jq_exit=$?
            
            # If jq succeeded and status is ok/healthy
            if [ $jq_exit -eq 0 ]; then
                if [ "$status" = "ok" ] || [ "$status" = "healthy" ]; then
                    return 0
                fi
            else
                # jq failed, try simple grep fallback
                if echo "$response" | grep -qi '"status".*"healthy"' || echo "$response" | grep -qi '"status".*"ok"'; then
                    return 0
                fi
            fi
        else
            # Simple check without jq
            if echo "$response" | grep -qi '"status".*"healthy"' || echo "$response" | grep -qi '"status".*"ok"'; then
                return 0
            fi
        fi
    fi
    
    return 1
}

# ==============================================================================
# Kubernetes Port-Forward Management for ALL Services
# Provides transparent access to ClusterIP services via automatic port-forwarding
# Supports: provider, manager, config, tracker, mysql
# ==============================================================================

# Array to track port-forward PIDs for cleanup
declare -a PORT_FORWARD_PIDS=()

# Service to internal port mapping (Bash 3.2 compatible for macOS)
# These are the INTERNAL ClusterIP ports that services listen on
# Using function instead of associative arrays (requires Bash 4+)
get_service_internal_port() {
    local service="$1"
    case "$service" in
        "ai-architect-provider") echo "${XMCP_HTTP_PORT:-8080}" ;;
        "ai-architect-manager") echo "${CIS_MANAGER_PORT:-9090}" ;;
        "ai-architect-config") echo "${CIS_CONFIG_PORT:-8081}" ;;
        "ai-architect-tracker") echo "${CIS_TRACKING_PORT:-9920}" ;;
        "ai-architect-mysql") echo "${MYSQL_PORT:-3306}" ;;
        *) echo "" ;;
    esac
}

# Detect if running in Kubernetes
is_kubernetes_deployment() {
    # Source path-manager if not already loaded
    if ! type get_deployment_type_file >/dev/null 2>&1; then
        source "${SCRIPT_DIR}/scripts/lib/path-manager.sh" 2>/dev/null || true
    fi
    
    # Get deployment type file path
    local deployment_file
    if type get_deployment_type_file >/dev/null 2>&1; then
        deployment_file=$(get_deployment_type_file)
    else
        deployment_file="${SCRIPT_DIR}/.deployment-type"
    fi
    
    # Check .deployment-type file (created during setup)
    if [ -f "$deployment_file" ]; then
        local deployment_type=$(cat "$deployment_file" 2>/dev/null | tr -d '[:space:]')
        if [ "$deployment_type" = "kubernetes" ]; then
            return 0
        fi
    fi
    return 1
}

# Check if port-forward is already active on a port
port_forward_active() {
    local port="$1"
    if command -v lsof >/dev/null 2>&1; then
        lsof -i :"$port" -sTCP:LISTEN >/dev/null 2>&1
        return $?
    elif command -v nc >/dev/null 2>&1; then
        # Fallback: try to connect with netcat
        nc -z localhost "$port" >/dev/null 2>&1
        return $?
    else
        # Last resort: try curl
        curl -s --connect-timeout 1 "http://localhost:$port" >/dev/null 2>&1
        return 0  # Assume it works if we can't check
    fi
}

# Wait for port to become available
wait_for_port() {
    local port="$1"
    local max_wait=20  # Increased from 10 to 20 for 0.0.0.0 port-forward bindings
    local count=0
    
    while [ $count -lt $max_wait ]; do
        if port_forward_active "$port"; then
            return 0
        fi
        sleep 0.5
        count=$((count + 1))
    done
    
    return 1
}

# Start port-forward for a service
start_port_forward() {
    local service="$1"
    local local_port="$2"
    local namespace="${3:-bito-ai-architect}"
    
    # Check if already running
    if port_forward_active "$local_port"; then
        [ "$VERBOSE" = "true" ] && echo "Port $local_port already forwarded" >&2
        return 0
    fi
    
    # Verify kubectl is available
    if ! command -v kubectl >/dev/null 2>&1; then
        print_error "kubectl not found - required for Kubernetes deployments"
        return 1
    fi
    
    # Get the internal service port from the service name
    local internal_port=$(get_service_internal_port "$service")
    if [ -z "$internal_port" ]; then
        [ "$VERBOSE" = "true" ] && echo "Warning: Unknown internal port for $service, using $local_port" >&2
        internal_port="$local_port"
    fi
    
    # Start port-forward with proper daemonization for stability
    # Use: nohup + stdin from /dev/null + disown to fully detach from shell
    # This prevents port-forwards from dying when the parent shell or bitoarch command exits
    [ "$VERBOSE" = "true" ] && echo "Starting port-forward for $service: localhost:$local_port -> $service:$internal_port" >&2

    nohup kubectl port-forward --address 0.0.0.0 "svc/$service" "${local_port}:${internal_port}" -n "$namespace" </dev/null >/dev/null 2>&1 &
    disown 2>/dev/null || true
    
    # Note: We intentionally do NOT store the PID in PORT_FORWARD_PIDS
    # This allows port-forwards to persist after bitoarch commands exit
    
    # Wait for port to be ready
    if wait_for_port "$local_port"; then
        [ "$VERBOSE" = "true" ] && echo "✓ Port-forward ready: $service on localhost:$local_port" >&2
        return 0
    else
        log_silent "Port-forward may not be ready on port $local_port"
        return 1
    fi
}

# Ensure ALL services are accessible (batch setup)
ensure_all_services_accessible() {
    if ! is_kubernetes_deployment; then
        return 0  # Docker mode - services already accessible
    fi
    
    [ "$VERBOSE" = "true" ] && echo "Setting up port-forwards for all services..." >&2
    
    # Start port-forwards for all services (Bash 3.2 compatible)
    local services=("ai-architect-provider" "ai-architect-manager" "ai-architect-config" "ai-architect-tracker" "ai-architect-mysql")
    for service in "${services[@]}"; do
        local port=$(get_service_port "$service")
        if [ -n "$port" ]; then
            ensure_service_accessible "$service" "$port"
        fi
    done
}

# Ensure specific service is accessible (main entry point)
ensure_service_accessible() {
    local service="$1"
    local port="$2"
    
    # If not Kubernetes, services are already accessible via Docker
    if ! is_kubernetes_deployment; then
        return 0
    fi
    
    # For Kubernetes, ensure port-forward is running
    if ! port_forward_active "$port"; then
        start_port_forward "$service" "$port"
    fi
}

# Cleanup all port-forwards
cleanup_port_forwards() {
    if [ ${#PORT_FORWARD_PIDS[@]} -gt 0 ]; then
        [ "$VERBOSE" = "true" ] && echo "Cleaning up port-forwards..." >&2
        for pid in "${PORT_FORWARD_PIDS[@]}"; do
            if kill -0 "$pid" 2>/dev/null; then
                kill "$pid" 2>/dev/null || true
            fi
        done
        PORT_FORWARD_PIDS=()
    fi
}

# Register cleanup handler
trap cleanup_port_forwards EXIT INT TERM

# Enhanced API call functions with automatic port-forward

# Make REST API call to CIS Config (with auto port-forward)
config_api_call_k8s() {
    local method="$1"
    local endpoint="$2"
    local data="$3"
    
    # Use the EXTERNAL_PORT for localhost access (port-forward maps this to internal port)
    local CONFIG_PORT="${CIS_CONFIG_EXTERNAL_PORT:-5003}"
    
    # Ensure config service is accessible
    ensure_service_accessible "ai-architect-config" "$CONFIG_PORT"
    
    local auth_header="X-API-Key: $CONFIG_API_KEY"
    local url="http://localhost:${CONFIG_PORT}${endpoint}"
    
    http_request "$method" "$url" "$auth_header" "$data"
}

# Make REST API call to CIS Manager (with auto port-forward)
manager_api_call_k8s() {
    local method="$1"
    local endpoint="$2"
    local data="$3"
    
    # Use the EXTERNAL_PORT for localhost access (port-forward maps this to internal port)
    local MANAGER_PORT="${CIS_MANAGER_EXTERNAL_PORT:-5002}"
    
    # Ensure manager service is accessible
    ensure_service_accessible "ai-architect-manager" "$MANAGER_PORT"
    
    local auth_header="X-API-Key: $MANAGER_API_KEY"
    local url="http://localhost:${MANAGER_PORT}${endpoint}"
    
    http_request "$method" "$url" "$auth_header" "$data"
}

# Make MCP request to Provider (with auto port-forward)
mcp_request_k8s() {
    local request="$1"
    
    # Use the EXTERNAL_PORT for localhost access (port-forward maps this to internal port)
    local PROVIDER_PORT="${CIS_PROVIDER_EXTERNAL_PORT:-5001}"
    
    # Ensure provider service is accessible
    ensure_service_accessible "ai-architect-provider" "$PROVIDER_PORT"
    
    # Make request to localhost
    local auth_header="Authorization: Bearer $PROVIDER_TOKEN"
    local url="http://localhost:${PROVIDER_PORT}/mcp"
    local response=$(http_request "POST" "$url" "$auth_header" "$request")
    local exit_code=$?
    
    if [ $exit_code -ne 0 ]; then
        return 1
    fi
    
    # Check for JSON-RPC error
    if require_command jq; then
        local error=$(echo "$response" | jq -r '.error // empty')
        if [ -n "$error" ]; then
            local error_message=$(echo "$error" | jq -r '.message')
            print_error "MCP Error: $error_message"
            [ "$VERBOSE" = "true" ] && echo "$error" | jq '.' >&2
            return 1
        fi
        
        # Extract result
        echo "$response" | jq -r '.result'
        return 0
    else
        # Fallback without jq
        echo "$response"
        return 0
    fi
}

# Export functions
export -f http_request
export -f mcp_request
export -f mcp_call
export -f config_api_call
export -f manager_api_call
export -f health_check
export -f is_kubernetes_deployment
export -f port_forward_active
export -f wait_for_port
export -f start_port_forward
export -f ensure_service_accessible
export -f ensure_all_services_accessible
export -f cleanup_port_forwards
export -f config_api_call_k8s
export -f manager_api_call_k8s
export -f mcp_request_k8s
