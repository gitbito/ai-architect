#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
# Bito's AI Architect CLI - Platform Adapter
# Handles platform-wide operations (health, status)

# Source tracker adapter for tracking functions (in same directory)
ADAPTER_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [ -f "${ADAPTER_DIR}/tracker-adapter.sh" ]; then
    source "${ADAPTER_DIR}/tracker-adapter.sh"
elif [ -n "${SCRIPT_DIR:-}" ] && [ -f "${SCRIPT_DIR}/lib/adapters/tracker-adapter.sh" ]; then
    # Fallback: use SCRIPT_DIR if set by parent (bitoarch.sh)
    source "${SCRIPT_DIR}/lib/adapters/tracker-adapter.sh"
fi

# Source setup-utils for shared Git credentials function
if [ -n "${SCRIPT_DIR:-}" ] && [ -f "${SCRIPT_DIR}/setup-utils.sh" ]; then
    source "${SCRIPT_DIR}/setup-utils.sh"
elif [ -f "${ADAPTER_DIR}/../../setup-utils.sh" ]; then
    source "${ADAPTER_DIR}/../../setup-utils.sh"
fi

# Source config-backup-manager for centralized backup utility
if [ -n "${SCRIPT_DIR:-}" ] && [ -f "${SCRIPT_DIR}/lib/config-backup-manager.sh" ]; then
    source "${SCRIPT_DIR}/lib/config-backup-manager.sh"
elif [ -f "${ADAPTER_DIR}/../config-backup-manager.sh" ]; then
    source "${ADAPTER_DIR}/../config-backup-manager.sh"
fi

# Platform command handler
handle_platform() {
    local command="$1"
    shift
    
    # Check for help
    if [ "$command" = "--help" ] || [ "$command" = "-h" ] || [ -z "$command" ]; then
        show_platform_help
        return 0
    fi
    
    # Route to command
    case "$command" in
        health)
            platform_health "$@"
            ;;
        status)
            platform_status "$@"
            ;;
        info)
            platform_info "$@"
            ;;
        rotate-token)
            platform_rotate_token "$@"
            ;;
        update-api-key)
            platform_update_api_key "$@"
            ;;
        update-git-creds)
            platform_update_git_creds "$@"
            ;;
        mcp)
            platform_mcp "$@"
            ;;
        *)
            print_error "Unknown platform command: $command"
            echo ""
            echo "Available commands: health, status, info, rotate-token, update-api-key, update-git-creds, mcp"
            echo "Use 'bitoarch --help' for more information"
            return 1
            ;;
    esac
}

# Check health of all services
platform_health() {
    # Check for help first
    if [ "$1" = "--help" ] || [ "$1" = "-h" ]; then
        cat << 'EOF'
USAGE:
  bitoarch health

DESCRIPTION:
  Check health status of all AI Architect services

OPTIONS:
  --help, -h       Show this help

EXAMPLES:
  bitoarch health
EOF
        return 0
    fi
    
    local verbose=false
    
    # Parse options
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --verbose|-v)
                verbose=true
                shift
                ;;
            *)
                shift
                ;;
        esac
    done
    
    print_header "Bito's AI Architect Health Check"
    echo ""
    
    local services=(
        "provider|${PROVIDER_URL}|AI Architect Provider (MCP)"
        "config|${CONFIG_URL}|AI Architect Config"
        "manager|${MANAGER_URL}|AI Architect Manager"
        "mysql|mysql://localhost:${MYSQL_PORT}|MySQL Database"
    )
    
    local healthy_count=0
    local total_count=${#services[@]}
    
    for service_info in "${services[@]}"; do
        IFS='|' read -r name url display <<< "$service_info"
        
        printf "%-30s " "$display"
        
        if [ "$name" = "mysql" ]; then
            # Check MySQL - try HTTP health endpoint first (works for both Docker and K8s)
            local mysql_port=$(echo "$url" | sed -n 's/.*:\([0-9]*\)$/\1/p')
            if curl -sf "http://localhost:${mysql_port}/health" >/dev/null 2>&1; then
                echo -e "$(format_status "healthy")"
                healthy_count=$((healthy_count + 1))
            else
                # Fallback: check if MySQL port is listening
                if nc -z localhost "${mysql_port}" 2>/dev/null || timeout 1 bash -c "cat < /dev/null > /dev/tcp/localhost/${mysql_port}" 2>/dev/null; then
                    echo -e "$(format_status "healthy")"
                    healthy_count=$((healthy_count + 1))
                else
                    echo -e "$(format_status "down")"
                fi
            fi
            
            if [ "$verbose" = "true" ]; then
                echo "    Port: ${mysql_port}"
            fi
        else
            # Check HTTP services
            if health_check "$url"; then
                echo -e "$(format_status "healthy")"
                healthy_count=$((healthy_count + 1))
                
                if [ "$verbose" = "true" ]; then
                    local port=$(echo "$url" | sed -n 's/.*:\([0-9]*\)$/\1/p')
                    echo "    URL: $url"
                    echo "    Port: $port"
                    
                    # Get additional info from health endpoint
                    local health_info=$(http_request "GET" "${url}/health" "" "" "" 2>/dev/null)
                    if require_command jq && [ -n "$health_info" ]; then
                        local uptime=$(echo "$health_info" | jq -r '.uptime // "N/A"')
                        echo "    Uptime: ${uptime}s"
                    fi
                fi
            else
                echo -e "$(format_status "down")"
            fi
        fi
        echo ""
    done
    
    # Summary
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    
    if [ $healthy_count -eq $total_count ]; then
        print_success "All services healthy ($healthy_count/$total_count)"
        return 0
    elif [ $healthy_count -gt 0 ]; then
        print_warning "Some services unhealthy ($healthy_count/$total_count)"
        return 1
    else
        print_error "All services down ($healthy_count/$total_count)"
        return 1
    fi
}

# Get platform status
platform_status() {
    # Check for help first
    if [ "$1" = "--help" ] || [ "$1" = "-h" ]; then
        cat << 'EOF'
USAGE:
  bitoarch status

DESCRIPTION:
  Show the current status of all AI Architect services including containers,
  health status, uptime, and port mappings.

OPTIONS:
  --help    Show this help

EXAMPLES:
  # Check service status
  bitoarch status

NOTES:
  - Automatically detects Docker Compose or Kubernetes deployment
  - Displays service health and uptime
  - Lists port mappings for each service
EOF
        return 0
    fi
    
    print_header "Bito's AI Architect Status"
    echo ""
    
    # Detect deployment type using path-manager
    local deployment_type="docker-compose"
    local deployment_file=$(get_deployment_type_file)
    if [ -f "$deployment_file" ]; then
        deployment_type=$(cat "$deployment_file")
    fi
    
    if [ "$deployment_type" = "kubernetes" ]; then
        # Kubernetes deployment
        local namespace="bito-ai-architect"
        
        # Check if namespace exists
        if ! kubectl get namespace "$namespace" >/dev/null 2>&1; then
            print_warning "Kubernetes namespace '$namespace' not found"
            echo ""
            print_info "Services may not be deployed yet"
            return 1
        fi
        
        # Check if any deployments exist and are running (not scaled to 0)
        deployment_count=$(kubectl get deployment -n "$namespace" -l "app.kubernetes.io/name=bitoarch" 2>/dev/null | wc -l | xargs)
        
        if [ "$deployment_count" -le 1 ]; then
            # No deployments found (only header line or namespace doesn't exist)
            echo ""
            print_warning "No AI Architect services are currently running"
            echo ""
            print_info "To start services, run: ./setup.sh"
            return 1
        fi
        
        # Check if deployments are scaled to 0 (stopped)
        running_replicas=$(kubectl get deployment -n "$namespace" -l "app.kubernetes.io/name=bitoarch" -o jsonpath='{.items[*].spec.replicas}' 2>/dev/null | tr ' ' '+' | bc 2>/dev/null || echo "0")
        
        if [ "$running_replicas" -eq 0 ]; then
            # Deployments exist but are scaled to 0 (stopped)
            echo ""
            print_warning "No AI Architect services are currently running"
            echo ""
            print_info "To start services, run: ./setup.sh"
            return 1
        fi
        
        # Get pod status
        local pods=$(kubectl get pods -n "$namespace" -o json 2>/dev/null)
        
        if [ -z "$pods" ] || [ "$pods" = "null" ]; then
            print_warning "No pods found in namespace: $namespace"
            return 1
        fi
        
        # Parse and display pod status
        echo "$pods" | jq -r '.items[] | 
            "\(.metadata.labels."app.kubernetes.io/component" // "unknown")|\(.status.phase)|\([.status.conditions[]? | select(.type=="Ready")] | if length > 0 then .[0].status else "Unknown" end)|\(.status.startTime)"' | \
        while IFS='|' read -r component phase ready start_time; do
            local display_name=$(echo "$component" | awk '{print toupper(substr($0,1,1)) tolower(substr($0,2))}')
            
            printf "%-15s " "$display_name"
            
            if [ "$phase" = "Running" ] && [ "$ready" = "True" ]; then
                echo -e "$(format_status "running")"
            elif [ "$phase" = "Running" ] && [ "$ready" = "False" ]; then
                echo -e "$(format_status "starting")"
            elif [ "$phase" = "Pending" ]; then
                echo -e "$(format_status "pending")"
            else
                echo -e "$(format_status "$phase")"
            fi
            
            if [ -n "$start_time" ] && [ "$start_time" != "null" ]; then
                echo "  Started: $start_time"
            fi
            echo ""
        done
        
        echo ""
        print_info "Deployment: Kubernetes (namespace: $namespace)"
        print_info "View logs: ./setup.sh --logs"
        
    else
        # Docker Compose deployment
        
        # Check if any services are running
        running_services=$(docker ps -q --filter "name=ai-architect-" 2>/dev/null | wc -l)
        if [ "$running_services" -eq 0 ]; then
            echo ""
            print_warning "No AI Architect services are currently running"
            echo ""
            print_info "To start services, run: ./setup.sh"
            return 1
        fi
        
        local services=("ai-architect-mysql" "ai-architect-provider" "ai-architect-config" "ai-architect-manager")
        
        for container in "${services[@]}"; do
            
            local display_name=$(echo "$container" | sed 's/ai-architect-//' | tr '[:lower:]' '[:upper:]')
            
            if docker ps --format '{{.Names}}' | grep -q "^${container}$"; then
                local status=$(docker inspect --format='{{.State.Status}}' "$container" 2>/dev/null)
                local health=$(docker inspect --format='{{.State.Health.Status}}' "$container" 2>/dev/null)
                local uptime=$(docker inspect --format='{{.State.StartedAt}}' "$container" 2>/dev/null)
                
                printf "%-15s " "$display_name"
                
                if [ "$status" = "running" ]; then
                    if [ "$health" = "healthy" ] || [ "$health" = "" ]; then
                        echo -e "$(format_status "running")"
                    elif [ "$health" = "starting" ]; then
                        # During start_period, check actual health endpoint
                        local port=$(docker inspect --format='{{range $p, $conf := .NetworkSettings.Ports}}{{if eq $p "8080/tcp"}}8080{{else if eq $p "8081/tcp"}}8081{{else if eq $p "9090/tcp"}}9090{{end}}{{end}}' "$container" 2>/dev/null)
                        if [ -n "$port" ] && curl -sf "http://localhost:$port/health" >/dev/null 2>&1; then
                            echo -e "$(format_status "running")"
                        else
                            echo -e "$(format_status "$health")"
                        fi
                    else
                        echo -e "$(format_status "$health")"
                    fi
                    
                    echo "  Started: $uptime"
                    
                    # Get port mapping
                    local ports=$(docker port "$container" 2>/dev/null | head -1)
                    if [ -n "$ports" ]; then
                        echo "  Ports: $ports"
                    fi
                else
                    echo -e "$(format_status "$status")"
                fi
                echo ""
            else
                printf "%-15s " "$display_name"
                echo -e "$(format_status "stopped")"
                echo ""
            fi
        done
        
        echo ""
        print_info "Deployment: Docker Compose"
        print_info "View logs: ./setup.sh --logs"
    fi
}

# Get platform information
platform_info() {
    # Check for help first
    if [ "$1" = "--help" ] || [ "$1" = "-h" ]; then
        cat << 'EOF'
USAGE:
  bitoarch info

DESCRIPTION:
  Display comprehensive platform information including version, configuration,
  service endpoints, and resource usage statistics.

OPTIONS:
  --help, -h    Show this help

EXAMPLES:
  # Get platform information
  bitoarch info
  
  # Check service status
  bitoarch status

SHOWS:
  - Platform version
  - Service endpoints and ports
  - Active service count
  - Resource usage (CPU, memory)
EOF
        return 0
    fi
    
    print_header "Bito's AI Architect Information"
    echo ""
    
    # Platform version
    if [ -f "$SCRIPT_DIR/versions/service-versions.json" ]; then
        if require_command jq; then
            local platform_version=$(jq -r '.platform_version // "1.0.0"' "$SCRIPT_DIR/versions/service-versions.json")
            format_key_value "Platform Version" "$platform_version"
        fi
    fi
    
    # Configuration
    format_key_value "Configuration" "$ENV_FILE"
    
    # Detect deployment type using path-manager
    local deployment_type="docker-compose"
    local deployment_file=$(get_deployment_type_file)
    if [ -f "$deployment_file" ]; then
        deployment_type=$(cat "$deployment_file")
    fi
    format_key_value "Deployment Type" "$deployment_type"
    
    echo ""
    print_subheader "Service Endpoints:"
    format_key_value "  Provider" "$PROVIDER_URL"
    format_key_value "  Config" "$CONFIG_URL"
    format_key_value "  Manager" "$MANAGER_URL"
    format_key_value "  MySQL" "localhost:$MYSQL_PORT"
    
    echo ""
    print_subheader "Running Services:"
    
    if [ "$deployment_type" = "kubernetes" ]; then
        # Kubernetes deployment
        local namespace="bito-ai-architect"
        local running_count=0
        local total_services=5
        
        if kubectl get namespace "$namespace" >/dev/null 2>&1; then
            running_count=$(kubectl get pods -n "$namespace" --field-selector=status.phase=Running 2>/dev/null | grep -c "Running" || echo "0")
        fi
        
        format_key_value "  Active" "$running_count / $total_services"
        
        # List running pods
        if [ $running_count -gt 0 ]; then
            kubectl get pods -n "$namespace" --no-headers 2>/dev/null | awk '{printf "  • %s (%s)\n", $1, $3}' || true
        fi
    else
        # Docker Compose deployment
        local running_count=$(docker ps --filter "name=ai-architect-" --format '{{.Names}}' | wc -l | tr -d ' ')
        local total_services=5
        
        format_key_value "  Active" "$running_count / $total_services"
        
        # List running services
        if [ $running_count -gt 0 ]; then
            docker ps --filter "name=ai-architect-" --format "  • {{.Names}} ({{.Status}})"
        fi
    fi
    
    echo ""
    print_subheader "Resource Usage:"
    
    if [ "$deployment_type" = "kubernetes" ]; then
        # Kubernetes resource usage
        local namespace="bito-ai-architect"
        if kubectl get namespace "$namespace" >/dev/null 2>&1; then
            if command -v kubectl >/dev/null 2>&1 && kubectl top pods -n "$namespace" >/dev/null 2>&1; then
                echo "  Per Pod:"
                kubectl top pods -n "$namespace" --no-headers 2>/dev/null | awk '{printf "    %s: CPU=%s, Memory=%s\n", $1, $2, $3}' || echo "  Resource metrics not available"
            else
                echo "  Resource metrics not available (requires metrics-server)"
            fi
        fi
    else
        # Docker Compose resource usage
        if command -v docker >/dev/null 2>&1; then
            local container_ids=$(docker ps -q --filter "name=ai-architect-" 2>/dev/null)
            
            if [ -n "$container_ids" ]; then
                # Calculate total CPU usage
                local cpu_usage=$(docker stats --no-stream --format "{{.CPUPerc}}" $container_ids 2>/dev/null | \
                                  sed 's/%$//' | \
                                  awk '{s+=$1} END {printf "%.2f%%", s}')
                
                # Get first container's memory usage as sample
                local mem_usage=$(docker stats --no-stream --format "{{.MemUsage}}" $container_ids 2>/dev/null | head -1)
                
                if [ -n "$cpu_usage" ] && [ "$cpu_usage" != "%" ]; then
                    format_key_value "  Total CPU" "$cpu_usage"
                fi
                if [ -n "$mem_usage" ]; then
                    format_key_value "  Memory (sample)" "$mem_usage"
                fi
            fi
        fi
    fi
    
    echo ""
}

# Rotate MCP access token
platform_rotate_token() {
    local new_token="$1"
    
    if [ "$1" = "--help" ] || [ "$1" = "-h" ] || [ -z "$new_token" ]; then
        cat << 'EOF'
USAGE:
  bitoarch rotate-mcp-token <new-token>

DESCRIPTION:
  Rotate the Bito MCP access token and restart cis-provider service

ARGUMENTS:
  <new-token>    New MCP access token (required)

EXAMPLES:
  # Rotate to a new token
  bitoarch rotate-mcp-token "new-secure-token-abc123"
  
  # This will:
  # 1. Update token in .env file
  # 2. Update MCP server configuration
  # 3. Restart cis-provider service only
  # 4. Display new MCP connection details

NOTE:
  - Only cis-provider is restarted (minimal downtime ~2 seconds)
  - Other services remain running
  - Token takes effect immediately

EOF
        return 0
    fi
    
    print_info "Rotating MCP access token..."
    
    # Validate token is provided
    if [ -z "$new_token" ]; then
        print_error "Token cannot be empty"
        return 1
    fi
    
    if [ -f "$ENV_FILE" ]; then
        sed -i.bak "s/^BITO_MCP_ACCESS_TOKEN=.*/BITO_MCP_ACCESS_TOKEN=${new_token}/" "$ENV_FILE"
        print_success "Updated token in .env"
    else
        print_error ".env file not found: $ENV_FILE"
        return 1
    fi
    
    # Reload environment
    load_env_config
    export BITO_MCP_ACCESS_TOKEN="$new_token"
    
    # Update MCP config
    local mcp_config_file="${PROJECT_ROOT}/services/cis-provider/config/default.json"
    
    if [ -f "$mcp_config_file" ]; then
        if command -v jq >/dev/null 2>&1; then
            local temp_config=$(mktemp)
            jq --arg token "$new_token" \
               '.auth.bearer_token = $token' \
               "$mcp_config_file" > "$temp_config"
            mv "$temp_config" "$mcp_config_file"
            print_success "MCP configuration updated using jq"
        else
            cp "$mcp_config_file" "${mcp_config_file}.backup"
            sed -i.tmp "s/\"bearer_token\"[[:space:]]*:[[:space:]]*\"[^\"]*\"/\"bearer_token\": \"$new_token\"/g" "$mcp_config_file"
            rm -f "${mcp_config_file}.tmp"
            print_success "MCP configuration updated using sed"
        fi
    else
        print_warning "MCP config file not found, skipping config update"
    fi
    
    # Restart only cis-provider
    print_info "Restarting ai-architect-provider service..."
    
    # Detect deployment type
    local deployment_type="docker-compose"
    if [ -f "${PROJECT_ROOT}/.deployment-type" ]; then
        deployment_type=$(cat "${PROJECT_ROOT}/.deployment-type")
    fi
    
    if [ "$deployment_type" = "kubernetes" ]; then
        # Kubernetes deployment - restart provider pod
        local namespace="bito-ai-architect"
        if kubectl rollout restart deployment -n "$namespace" -l "app.kubernetes.io/component=provider" 2>/dev/null; then
            echo ""
            print_success "MCP token rotated successfully"
            echo ""
            print_info "New MCP URL: ${PROVIDER_URL}/mcp"
            print_info "New Token: ${new_token}"
            echo ""
            return 0
        else
            print_error "Failed to restart ai-architect-provider"
            print_warning "Try manually: kubectl rollout restart deployment -n $namespace -l app.kubernetes.io/component=provider"
            return 1
        fi
    else
        # Docker Compose deployment
        local orig_dir=$(pwd)
        cd "$PROJECT_ROOT" 2>/dev/null || {
            print_error "Failed to change to project directory: $PROJECT_ROOT"
            return 1
        }
        
        # Try docker compose restart
        if docker compose restart ai-architect-provider 2>/dev/null; then
            cd "$orig_dir"
            echo ""
            print_success "MCP token rotated successfully"
            echo ""
            print_info "New MCP URL: ${PROVIDER_URL}/mcp"
            print_info "New Token: ${new_token}"
            echo ""
            return 0
        elif docker-compose restart ai-architect-provider 2>/dev/null; then
            cd "$orig_dir"
            echo ""
            print_success "MCP token rotated successfully"
            echo ""
            print_info "New MCP URL: ${PROVIDER_URL}/mcp"
            print_info "New Token: ${new_token}"
            echo ""
            return 0
        else
            cd "$orig_dir"
            print_error "Failed to restart ai-architect-provider"
            print_warning "Try manually: cd $PROJECT_ROOT && docker compose restart ai-architect-provider"
            return 1
        fi
    fi
}

# Update Bito API key
platform_update_api_key() {
    local new_api_key=""
    local restart_services=false
    
    # Parse options
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --help|-h)
                cat << 'EOF'
USAGE:
  bitoarch update-api-key [OPTIONS]

DESCRIPTION:
  Update the Bito API key in the .env-bitoarch file.
  Optionally update Git credentials in the same session.

OPTIONS:
  --api-key <key>    The new Bito API key
  --restart          Restart services after updating
  --help, -h         Show this help

NOTES:
  - Interactive mode will prompt for API key and optionally Git credentials
  - Services must be restarted for changes to take effect
  - Use --restart flag to automatically restart services
EOF
                return 0
                ;;
            --api-key)
                new_api_key="$2"
                shift 2
                ;;
            --restart)
                restart_services=true
                shift
                ;;
            *)
                print_error "Unknown option: $1"
                return 1
                ;;
        esac
    done
    
    # If no API key provided, prompt securely
    if [ -z "$new_api_key" ]; then
        echo ""
        echo -e "${BLUE}${BOLD}Update Bito API Key${NC}"
        echo ""
        echo "Enter new Bito API key (input hidden):"
        read -s new_api_key
        echo ""
        if [ -z "$new_api_key" ]; then
            print_error "API key cannot be empty"
            return 1
        fi
        echo ""  # Newline after hidden input
    fi
    
    # Load current .env-bitoarch to get TRACKING_SERVICE_BASE_URL
    if [ -f "$ENV_FILE" ]; then
        source "$ENV_FILE"
    fi
    
    # Validate API key using shared function (strict mode for CLI)
    if [[ -n "$TRACKING_SERVICE_BASE_URL" ]]; then
        if ! validate_and_print_bito_api_key_status "$new_api_key" "architect_api_key_update" "$TRACKING_SERVICE_BASE_URL" "API key validated successfully" "true"; then
            return 1
        fi
    fi
    
    echo ""
    
    # Create backup using centralized utility
    local backup_file=$(backup_config_file "$ENV_FILE" "env")
    
    # Update .env file using # as delimiter to avoid conflicts with @ in values
    sed -i.bak "s#^BITO_API_KEY=.*#BITO_API_KEY=$new_api_key#" "$ENV_FILE"
    rm -f "${ENV_FILE}.bak"
    
    log_silent "Bito API key updated successfully"
    if [ -n "$backup_file" ]; then
        log_silent "Backup created: $(basename "$backup_file")"
    fi
    
    # Ask if they want to update Git credentials too
    read -r -p "Do you want to update Git credentials as well? (y/N): " update_git
    
    if [[ "$update_git" =~ ^[Yy]$ ]]; then
        echo ""
        # Use shared utility function 
        update_git_credentials_in_env "$ENV_FILE"
        
        # Add CLI-specific success message
        print_success "Git credentials updated successfully"
        echo ""
    fi
    
    # Ask about restarting services if not explicitly set
    if [ "$restart_services" != true ]; then
        read -r -p "Restart services to apply changes? (y/N): " restart_choice
        if [[ "$restart_choice" =~ ^[Yy]$ ]]; then
            restart_services=true
        fi
    fi
    
    # Restart services
    if [ "$restart_services" = true ]; then
        echo ""
        print_info "Restarting services to apply changes..."
        
        # Detect deployment type using path-manager
        local deployment_type="docker-compose"
        local deployment_file=$(get_deployment_type_file)
        if [ -f "$deployment_file" ]; then
            deployment_type=$(cat "$deployment_file")
        fi
        
        if [ "$deployment_type" = "kubernetes" ]; then
            # Kubernetes deployment - restart pods
            local namespace="bito-ai-architect"
            if kubectl rollout restart deployment -n "$namespace" -l "app.kubernetes.io/name=bitoarch" >/dev/null 2>&1; then
                print_success "Services restarted successfully"
                echo ""
            else
                print_error "Failed to restart services"
                print_info "Try manually: kubectl rollout restart deployment -n $namespace -l app.kubernetes.io/name=bitoarch"
                echo ""
                return 1
            fi
        else
            # Docker Compose deployment
            local orig_dir=$(pwd)
            cd "$PROJECT_ROOT" 2>/dev/null || {
                print_error "Failed to change to project directory"
                return 1
            }
            
            if docker compose restart ai-architect-config ai-architect-manager ai-architect-provider ai-architect-tracker 2>/dev/null || \
               docker-compose restart ai-architect-config ai-architect-manager ai-architect-provider ai-architect-tracker 2>/dev/null; then
                cd "$orig_dir"
                print_success "Services restarted successfully"
                echo ""
            else
                cd "$orig_dir"
                print_error "Failed to restart services"
                print_info "Try manually: docker compose restart ai-architect-config ai-architect-manager ai-architect-provider ai-architect-tracker"
                echo ""
                return 1
            fi
        fi
    else
        echo ""
        print_warning "Services not restarted. Changes will take effect after restart."
        echo ""
        print_info "To restart services, run:"
        echo -e "  ${BLUE}./setup.sh --force-restart${NC}"
        echo ""
    fi
}

# Update Git credentials
platform_update_git_creds() {
    local restart_services=false
    
    # Parse options
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --help|-h)
                cat << 'EOF'
USAGE:
  bitoarch update-git-creds

DESCRIPTION:
  Update Git provider credentials in the .env-bitoarch file.
  Supported providers: GitLab, GitHub, Bitbucket
  
  After updating credentials, use bitoarch add-repos or update-repos to configure repositories.

OPTIONS:
  --help, -h         Show this help

TOKEN TYPES:
  GitHub: Personal Access Token (ghp_xxx or github_pat_xxx)
  GitLab: Personal/Project Access Token (glpat-xxx)
  Bitbucket: App Password

NOTES:
  - Use 'bitoarch add-repos <file>' or 'bitoarch update-repos <file>' after updating credentials
  - Ensure token has appropriate repository access permissions
  - For Bitbucket, username/email will be collected based on enterprise status
EOF
                return 0
                ;;
            *)
                print_error "Unknown option: $1"
                return 1
                ;;
        esac
    done
    
    # Create backup using centralized utility
    local backup_file=$(backup_config_file "$ENV_FILE" "env")
    if [ -n "$backup_file" ]; then
        log_silent "Backup created: $(basename "$backup_file")"
    fi
    echo ""
    
    # Use shared utility function 
    update_git_credentials_in_env "$ENV_FILE"
    
    # Add CLI-specific success message
    print_success "Git credentials updated successfully"
    echo ""
    
    # Direct user to apply changes
    print_info "To apply changes, run:"
    echo -e "  ${YELLOW}bitoarch add-repos <config-file>${NC}    (if config not added yet)"
    echo -e "  ${YELLOW}bitoarch update-repos <config-file>${NC} (if config already exists)"
    echo ""
}

# Show MCP configuration
platform_mcp() {
    # Check for help
    if [ "$1" = "--help" ] || [ "$1" = "-h" ]; then
        cat << 'EOF'
USAGE:
  bitoarch mcp-info

DESCRIPTION:
  Display MCP server configuration details including URL and access token.
  Use this information to configure MCP clients like Cursor, Cline, or Windsurf.

NOTES:
  - Test connection with: bitoarch mcp-test
EOF
        return 0
    fi
    
    # Get MCP URL and token from environment
    local mcp_url="${PROVIDER_URL:-http://localhost:${CIS_PROVIDER_EXTERNAL_PORT:-5001}}/mcp"
    local mcp_token="${BITO_MCP_ACCESS_TOKEN:-not-set}"
    
    # Use render function for consistent output
    render_mcp_config_block "$mcp_url" "$mcp_token"
}

# Export functions
export -f handle_platform
export -f platform_health
export -f platform_status
export -f platform_info
export -f platform_update_api_key
export -f platform_update_git_creds
export -f platform_rotate_token
export -f platform_mcp
