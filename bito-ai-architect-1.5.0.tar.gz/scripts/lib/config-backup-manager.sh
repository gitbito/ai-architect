#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
#
# Config Backup Manager - Centralized configuration file backup utility
# Provides consistent backup location, naming, and retention management

# Prevent multiple sourcing
if [ -n "${BITOARCH_CONFIG_BACKUP_MANAGER_LOADED:-}" ]; then
    return 0
fi
BITOARCH_CONFIG_BACKUP_MANAGER_LOADED=1

# Determine SCRIPT_DIR if not already set
if [ -z "${SCRIPT_DIR:-}" ]; then
    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && cd ../.. && pwd)"
fi

# Source path-manager for standard paths
if [ -f "${SCRIPT_DIR}/scripts/lib/path-manager.sh" ]; then
    source "${SCRIPT_DIR}/scripts/lib/path-manager.sh"
fi

# Source output utilities for logging
if [ -f "${SCRIPT_DIR}/scripts/lib/output-blocks.sh" ]; then
    source "${SCRIPT_DIR}/scripts/lib/output-blocks.sh"
elif [ -f "${SCRIPT_DIR}/scripts/setup-utils.sh" ]; then
    source "${SCRIPT_DIR}/scripts/setup-utils.sh"
fi

# ============================================================================
# BACKUP FUNCTIONS
# ============================================================================

# Backup a configuration file with automatic retention management
# Usage: backup_config_file <source_file> <category>
# Example: backup_config_file "/path/to/.env-bitoarch" "env"
backup_config_file() {
    local source_file="$1"
    local backup_category="$2"
    local retention="${CONFIG_BACKUP_RETENTION:-5}"
    
    # Validate inputs
    if [ -z "$source_file" ] || [ ! -f "$source_file" ]; then
        echo "Error: Source file does not exist: $source_file" >&2
        return 1
    fi
    
    if [ -z "$backup_category" ]; then
        echo "Error: Backup category not specified" >&2
        return 1
    fi
    
    # Get backup directory from path-manager (uses BITOARCH_VAR_DIR)
    local backup_base_dir="${BITOARCH_VAR_DIR:-./var}/backups/configs"
    local backup_dir="${backup_base_dir}/${backup_category}"
    local timestamp=$(date +%Y%m%d_%H%M%S)
    local filename=$(basename "$source_file")
    local backup_file="${backup_dir}/${filename}.backup.${timestamp}"
    
    # Create backup directory if it doesn't exist
    mkdir -p "$backup_dir" 2>/dev/null || {
        echo "Error: Failed to create backup directory: $backup_dir" >&2
        return 1
    }
    
    # Copy file to backup location
    if cp "$source_file" "$backup_file" 2>/dev/null; then
        # Successfully backed up
        if command -v log_silent >/dev/null 2>&1; then
            log_silent "Config backup created: $backup_file"
        fi
    else
        echo "Error: Failed to create backup: $backup_file" >&2
        return 1
    fi
    
    # Rotate old backups (keep only latest N)
    local backup_pattern="${backup_dir}/${filename}.backup.*"
    local existing_backups=$(ls -t $backup_pattern 2>/dev/null | wc -l | tr -d ' ')
    
    if [ "$existing_backups" -gt "$retention" ]; then
        # Remove oldest backups beyond retention limit
        ls -t $backup_pattern 2>/dev/null | \
            tail -n +$((retention + 1)) | \
            xargs rm -f 2>/dev/null || true
        
        if command -v log_silent >/dev/null 2>&1; then
            log_silent "Rotated old backups (keeping latest ${retention})"
        fi
    fi
    
    # Return the backup file path
    echo "$backup_file"
    return 0
}

# List all backups for a specific category
# Usage: list_config_backups <category>
list_config_backups() {
    local backup_category="$1"
    
    if [ -z "$backup_category" ]; then
        echo "Error: Backup category not specified" >&2
        return 1
    fi
    
    local backup_base_dir="${BITOARCH_VAR_DIR:-./var}/backups/configs"
    local backup_dir="${backup_base_dir}/${backup_category}"
    
    if [ ! -d "$backup_dir" ]; then
        echo "No backups found for category: $backup_category" >&2
        return 1
    fi
    
    ls -1t "${backup_dir}"/*.backup.* 2>/dev/null || {
        echo "No backup files found in: $backup_dir" >&2
        return 1
    }
}

# Get the latest backup for a specific file and category
# Usage: get_latest_backup <filename> <category>
get_latest_backup() {
    local filename="$1"
    local backup_category="$2"
    
    if [ -z "$filename" ] || [ -z "$backup_category" ]; then
        echo "Error: Filename and category required" >&2
        return 1
    fi
    
    local backup_base_dir="${BITOARCH_VAR_DIR:-./var}/backups/configs"
    local backup_dir="${backup_base_dir}/${backup_category}"
    
    ls -t "${backup_dir}/${filename}.backup."* 2>/dev/null | head -1 || {
        echo "No backups found for: $filename in category: $backup_category" >&2
        return 1
    }
}

# Restore a config file from backup
# Usage: restore_config_file <backup_file> <destination>
restore_config_file() {
    local backup_file="$1"
    local destination="$2"
    
    if [ -z "$backup_file" ] || [ ! -f "$backup_file" ]; then
        echo "Error: Backup file does not exist: $backup_file" >&2
        return 1
    fi
    
    if [ -z "$destination" ]; then
        echo "Error: Destination not specified" >&2
        return 1
    fi
    
    # Create backup of current file before restoring
    if [ -f "$destination" ]; then
        local temp_backup="${destination}.pre-restore.$(date +%Y%m%d_%H%M%S)"
        cp "$destination" "$temp_backup" 2>/dev/null || {
            echo "Warning: Could not create pre-restore backup" >&2
        }
    fi
    
    # Restore from backup
    if cp "$backup_file" "$destination" 2>/dev/null; then
        echo "Successfully restored: $destination from $backup_file"
        return 0
    else
        echo "Error: Failed to restore from backup: $backup_file" >&2
        return 1
    fi
}

# Export functions
export -f backup_config_file
export -f list_config_backups
export -f get_latest_backup
export -f restore_config_file
