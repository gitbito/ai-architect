#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
# CIS Platform CLI - Core Functions
# Handles configuration loading, environment setup, and shared utilities

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[1;34m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m' # No Color

# Project root directory (scripts/../ = project root)
if [ -z "$SCRIPT_DIR" ]; then
    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && cd ../.. && pwd)"
fi
PROJECT_ROOT="$(cd "$SCRIPT_DIR" && cd .. && pwd)"

# Use path-manager to get config files (already sourced in bitoarch.sh)
# These functions check system-wide, user-local, and legacy paths in order
if type get_config_file >/dev/null 2>&1; then
    ENV_FILE=$(get_config_file)
    ENV_LLM_FILE=$(get_llm_config_file)
else
    # Fallback to legacy paths if path-manager not available
    ENV_FILE="${PROJECT_ROOT}/.env-bitoarch"
    ENV_LLM_FILE="${PROJECT_ROOT}/.env-llm-bitoarch"
fi


# Global configuration variables
PROVIDER_URL=""
CONFIG_URL=""
MANAGER_URL=""
MYSQL_HOST=""
MYSQL_PORT=""
PROVIDER_TOKEN=""
CONFIG_API_KEY=""
MANAGER_API_KEY=""

# Load environment configuration
load_env_config() {
    if [ ! -f "$ENV_FILE" ]; then
        echo -e "${RED}Error: Configuration file not found: $ENV_FILE${NC}" >&2
        echo -e "${YELLOW}Please run './setup.sh' first to configure the platform.${NC}" >&2
        return 1
    fi
    
    # Source environment variables
    set -a
    source "$ENV_FILE"
    if [ -f "$ENV_LLM_FILE" ]; then
       source "$ENV_LLM_FILE"
    fi
    set +a
    
    # Set service endpoints using external ports
    PROVIDER_URL="http://localhost:${CIS_PROVIDER_EXTERNAL_PORT:-5001}"
    CONFIG_URL="http://localhost:${CIS_CONFIG_EXTERNAL_PORT:-5003}"
    MANAGER_URL="http://localhost:${CIS_MANAGER_EXTERNAL_PORT:-5002}"
    MYSQL_HOST="localhost"
    MYSQL_PORT="${MYSQL_EXTERNAL_PORT:-5004}"
    
    # Set auth tokens
    PROVIDER_TOKEN="${BITO_MCP_ACCESS_TOKEN}"
    CONFIG_API_KEY="${CIS_CONFIG_API_KEY}"
    MANAGER_API_KEY="${CIS_MANAGER_API_KEY}"
    
    return 0
}

# Print colored output
print_error() {
    echo -e "${RED}✗${NC} $1" >&2
}

print_success() {
    echo -e "${GREEN}✓${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}⚠${NC} $1"
}

print_info() {
    echo -e "${BLUE}ℹ${NC} $1"
}

print_header() {
    echo -e "${BOLD}${BLUE}$1${NC}"
}

print_subheader() {
    echo -e "${CYAN}$1${NC}"
}

# Check if required command exists
require_command() {
    local cmd="$1"
    if ! command -v "$cmd" >/dev/null 2>&1; then
        print_error "Required command not found: $cmd"
        echo "Please install $cmd to use this feature."
        return 1
    fi
    return 0
}

# Check if services are running
check_service_running() {
    local service_name="$1"
    
    if ! command -v docker >/dev/null 2>&1; then
        print_error "Docker not found"
        return 1
    fi
    
    if docker ps --format '{{.Names}}' | grep -q "^${service_name}$"; then
        return 0
    else
        return 1
    fi
}

# Check if all required services are running
check_platform_services() {
    local required_services=("cis-mysql" "cis-provider")
    local missing_services=()
    
    for service in "${required_services[@]}"; do
        if ! check_service_running "$service"; then
            missing_services+=("$service")
        fi
    done
    
    if [ ${#missing_services[@]} -gt 0 ]; then
        print_error "Required services not running: ${missing_services[*]}"
        echo ""
        echo "Start services with: ./setup.sh"
        return 1
    fi
    
    return 0
}


# Export functions for use in other modules
export -f load_env_config
export -f print_error
export -f print_success
export -f print_warning
export -f print_info
export -f print_header
export -f print_subheader
export -f require_command
export -f check_service_running
export -f check_platform_services
