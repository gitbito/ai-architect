#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
#
# Path Manager - Central path resolution for Bito AI Architect
# Provides standard Unix paths with automatic fallback to user-local installation
#
# Usage: source "${SCRIPT_DIR}/lib/path-manager.sh"
# Then use: get_config_file, get_log_dir, etc.

# Prevent multiple sourcing
if [ -n "${BITOARCH_PATH_MANAGER_LOADED:-}" ]; then
    return 0
fi
BITOARCH_PATH_MANAGER_LOADED=1

# Source logging functions if available (for log_silent calls)
if [ -z "$SCRIPT_DIR" ]; then
    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && cd ../.. && pwd)"
fi

# Source setup-utils for logging functions (log_silent, print_info, etc.)
if [ -f "${SCRIPT_DIR}/scripts/setup-utils.sh" ]; then
    source "${SCRIPT_DIR}/scripts/setup-utils.sh" 2>/dev/null || true
fi

# ============================================================================
# STANDARD PATHS (Industry Standard)
# ============================================================================
BITOARCH_SYSTEM_PREFIX="/usr/local"
BITOARCH_USER_PREFIX="${HOME}/.local"

# Standard directories (FHS compliant)
BITOARCH_SYSTEM_CONFIG_DIR="${BITOARCH_SYSTEM_PREFIX}/etc/bitoarch"
BITOARCH_SYSTEM_VAR_DIR="${BITOARCH_SYSTEM_PREFIX}/var/bitoarch"
BITOARCH_SYSTEM_LIB_DIR="${BITOARCH_SYSTEM_PREFIX}/lib/bitoarch"

BITOARCH_USER_CONFIG_DIR="${BITOARCH_USER_PREFIX}/bitoarch/etc"
BITOARCH_USER_VAR_DIR="${BITOARCH_USER_PREFIX}/bitoarch/var"
BITOARCH_USER_LIB_DIR="${BITOARCH_USER_PREFIX}/bitoarch/lib"

# ============================================================================
# DETECTION & INITIALIZATION
# ============================================================================

# Detect which layout is in use
detect_layout() {
    # Priority 1: System-wide installation (check if already exists)
    if [ -f "${BITOARCH_SYSTEM_CONFIG_DIR}/.env-bitoarch" ] || \
       [ -d "${BITOARCH_SYSTEM_LIB_DIR}/current" ]; then
        echo "system"
        return 0
    fi
    
    # Priority 2: User-local installation (check if already exists)
    if [ -f "${BITOARCH_USER_CONFIG_DIR}/.env-bitoarch" ] || \
       [ -d "${BITOARCH_USER_LIB_DIR}/current" ]; then
        echo "user"
        return 0
    fi
    
    # Priority 3: Legacy installation directory
    if [ -n "${SCRIPT_DIR:-}" ] && [ -f "${SCRIPT_DIR}/.env-bitoarch" ]; then
        echo "legacy"
        return 0
    fi
    
    # Priority 4: For fresh installs, determine based on system capabilities
    # Enhanced: More robust checking with validation
    if can_use_system_wide; then
        # Verify we can actually create the directory (test run)
        local test_dir="${BITOARCH_SYSTEM_PREFIX}/etc/bitoarch"
        if mkdir -p "$test_dir" 2>/dev/null; then
            # Successfully created without sudo
            rmdir "$test_dir" 2>/dev/null || true
            log_silent "Validated system-wide path creation (no sudo needed)"
            echo "system"
            return 0
        elif command -v sudo >/dev/null 2>&1 && [ -t 0 ]; then
            # Try with sudo
            if sudo mkdir -p "$test_dir" 2>/dev/null; then
                sudo rmdir "$test_dir" 2>/dev/null || true
                log_silent "Validated system-wide path creation (with sudo)"
                echo "system"
                return 0
            else
                log_silent "Cannot create system directories even with sudo, falling back to user"
            fi
        else
            log_silent "Cannot create system directories (no sudo or non-interactive), falling back to user"
        fi
    fi
    
    # Fallback: User-local (always works, no sudo required)
    log_silent "Falling back to user-local installation (~/.local/bitoarch)"
    echo "user"
    return 0
}

# Check if system-wide installation is possible
can_use_system_wide() {
    # Check if /usr/local exists first
    if [ ! -d "${BITOARCH_SYSTEM_PREFIX}" ]; then
        # Try to create /usr/local with sudo
        if command -v sudo >/dev/null 2>&1 && [ -t 0 ]; then
            if sudo mkdir -p "${BITOARCH_SYSTEM_PREFIX}" 2>/dev/null; then
                log_silent "Created ${BITOARCH_SYSTEM_PREFIX} with sudo"
            else
                log_silent "/usr/local doesn't exist and cannot be created"
                return 1
            fi
        else
            log_silent "/usr/local doesn't exist and sudo not available"
            return 1
        fi
    fi
    
    # Check if we have sudo or already have write permissions
    if [ -w "${BITOARCH_SYSTEM_PREFIX}/etc" ] 2>/dev/null; then
        return 0
    fi
    
    # Check if sudo is available and works
    if command -v sudo >/dev/null 2>&1; then
        if sudo -n true 2>/dev/null; then
            return 0  # Passwordless sudo works
        elif [ -t 0 ]; then
            # Interactive terminal - TEST if sudo actually works
            if sudo -v 2>/dev/null; then
                return 0  # Sudo validated
            else
                log_silent "sudo available but authentication failed"
                return 1
            fi
        fi
    fi
    
    return 1
}

# Initialize path variables based on detected layout
init_paths() {
    local layout="$(detect_layout)"
    
    case "$layout" in
        system)
            export BITOARCH_LAYOUT="system"
            export BITOARCH_CONFIG_DIR="${BITOARCH_SYSTEM_CONFIG_DIR}"
            export BITOARCH_VAR_DIR="${BITOARCH_SYSTEM_VAR_DIR}"
            export BITOARCH_LIB_DIR="${BITOARCH_SYSTEM_LIB_DIR}"
            export BITOARCH_LOG_DIR="${BITOARCH_SYSTEM_VAR_DIR}/logs"
            export BITOARCH_PREFIX="${BITOARCH_SYSTEM_PREFIX}"
            ;;
        user)
            export BITOARCH_LAYOUT="user"
            export BITOARCH_CONFIG_DIR="${BITOARCH_USER_CONFIG_DIR}"
            export BITOARCH_VAR_DIR="${BITOARCH_USER_VAR_DIR}"
            export BITOARCH_LIB_DIR="${BITOARCH_USER_LIB_DIR}"
            export BITOARCH_LOG_DIR="${BITOARCH_USER_VAR_DIR}/logs"
            export BITOARCH_PREFIX="${BITOARCH_USER_PREFIX}/bitoarch"
            ;;
        legacy)
            export BITOARCH_LAYOUT="legacy"
            export BITOARCH_CONFIG_DIR="${SCRIPT_DIR}"
            export BITOARCH_VAR_DIR="${SCRIPT_DIR}/var"
            export BITOARCH_LIB_DIR="${SCRIPT_DIR}"
            export BITOARCH_LOG_DIR="${SCRIPT_DIR}/var/logs"
            export BITOARCH_PREFIX="${SCRIPT_DIR}"
            ;;
    esac
    
    # Set HOST_LOG_DIR for docker-compose volume mounts
    # CRITICAL: Docker Compose requires relative paths for volume mounts
    # Use ./var/logs for Docker Compose, absolute paths for everything else
    if [ "${BITOARCH_LAYOUT}" = "legacy" ]; then
        # Legacy mode: use relative path (backward compatible)
        export HOST_LOG_DIR="./var/logs"
    else
        # Standard paths: Docker Compose still needs relative path for volumes
        # but logs are actually written to the standard location via symlink
        export HOST_LOG_DIR="./var/logs"
    fi
}

# Initialize on source
init_paths

# ============================================================================
# DOCKER COMPOSE COMPATIBILITY
# ============================================================================

# For Docker Compose, HOST_LOG_DIR must be a relative path (./var/logs)
# because docker-compose.yml volume mounts require paths relative to the compose file
# For Kubernetes and system operations, use absolute paths from BITOARCH_LOG_DIR
get_docker_log_dir() {
    # Always return relative path for Docker Compose volume mounts
    echo "./var/logs"
}

# ============================================================================
# PATH ACCESSOR FUNCTIONS
# ============================================================================

# Get root prefix
get_bitoarch_prefix() {
    echo "${BITOARCH_PREFIX}"
}

# Get configuration directory
get_config_dir() {
    echo "${BITOARCH_CONFIG_DIR}"
}

# Get main configuration file
get_config_file() {
    echo "${BITOARCH_CONFIG_DIR}/.env-bitoarch"
}

# Get LLM configuration file
get_llm_config_file() {
    echo "${BITOARCH_CONFIG_DIR}/.env-llm-bitoarch"
}

# Get repository configuration file
get_repo_config_file() {
    echo "${BITOARCH_CONFIG_DIR}/.bitoarch-config.yaml"
}

get_repo_list_file() {
    echo "${BITOARCH_CONFIG_DIR}/.git-repo-list.yaml"
}

# Get deployment type file
get_deployment_type_file() {
    echo "${BITOARCH_CONFIG_DIR}/.deployment-type"
}

# Get repository config file
get_repo_config_file() {
    echo "${BITOARCH_CONFIG_DIR}/.bitoarch-config.yaml"
}

# Get Kubernetes values file (for Helm deployments)
get_k8s_values_file() {
    echo "${BITOARCH_CONFIG_DIR}/.bitoarch-values.yaml"
}

# Get config templates directory
get_config_templates_dir() {
    echo "${BITOARCH_CONFIG_DIR}/templates"
}

# Get variable data directory
get_var_dir() {
    echo "${BITOARCH_VAR_DIR}"
}

# Get log directory
get_log_dir() {
    echo "${BITOARCH_LOG_DIR}"
}

# Get setup log file
get_setup_log() {
    echo "${BITOARCH_LOG_DIR}/setup.log"
}

# Get upgrade log file
get_upgrade_log() {
    echo "${BITOARCH_LOG_DIR}/upgrade.log"
}

# Get library directory
get_lib_dir() {
    echo "${BITOARCH_LIB_DIR}"
}

# Get current version directory
get_current_version_dir() {
    local lib_dir="$(get_lib_dir)"
    if [ -L "${lib_dir}/current" ]; then
        readlink -f "${lib_dir}/current" 2>/dev/null || \
        python -c "import os; print(os.path.realpath('${lib_dir}/current'))" 2>/dev/null || \
        echo "${lib_dir}/current"
    else
        echo ""
    fi
}

# Get versions directory
get_versions_dir() {
    echo "$(get_lib_dir)/versions"
}

# ============================================================================
# LAYOUT DETECTION FUNCTIONS
# ============================================================================

# Check if using standard layout
is_standard_layout() {
    [ "${BITOARCH_LAYOUT}" = "system" ] || [ "${BITOARCH_LAYOUT}" = "user" ]
}

# Check if using system-wide layout
is_system_layout() {
    [ "${BITOARCH_LAYOUT}" = "system" ]
}

# Check if using user-local layout
is_user_layout() {
    [ "${BITOARCH_LAYOUT}" = "user" ]
}

# Check if using legacy layout
is_legacy_layout() {
    [ "${BITOARCH_LAYOUT}" = "legacy" ]
}

# Get current layout
get_layout() {
    echo "${BITOARCH_LAYOUT}"
}

# ============================================================================
# DIRECTORY CREATION HELPERS
# ============================================================================

# Create standard directories (with appropriate permissions)
create_standard_dirs() {
    local layout="$1"
    
    case "$layout" in
        system)
            # System-wide requires sudo
            sudo mkdir -p "${BITOARCH_SYSTEM_CONFIG_DIR}/templates"
            sudo mkdir -p "${BITOARCH_SYSTEM_VAR_DIR}/logs"
            sudo mkdir -p "${BITOARCH_SYSTEM_LIB_DIR}/versions"
            
            # Set ownership to current user for configs
            sudo chown -R "$USER:$(id -gn)" "${BITOARCH_SYSTEM_CONFIG_DIR}"
            sudo chown -R "$USER:$(id -gn)" "${BITOARCH_SYSTEM_VAR_DIR}"
            
            # lib directory can stay root-owned (only modified during upgrades)
            ;;
        user)
            # User-local doesn't need sudo
            mkdir -p "${BITOARCH_USER_CONFIG_DIR}/templates"
            mkdir -p "${BITOARCH_USER_VAR_DIR}/logs"
            mkdir -p "${BITOARCH_USER_LIB_DIR}/versions"
            
            chmod -R 755 "${BITOARCH_USER_PREFIX}/bitoarch"
            ;;
    esac
}

# Create service-specific log directories
create_log_dirs() {
    local log_dir="$(get_log_dir)"
    local services=("cis-config" "cis-manager" "cis-provider" "mysql" "cis-tracker")
    
    # Create directories in the standard/absolute path location
    for service in "${services[@]}"; do
        mkdir -p "${log_dir}/${service}"
    done
    
    chmod -R 755 "$log_dir"
    
    # CRITICAL: For Docker Compose, also create ./var/logs relative directory structure
    # This is needed because docker-compose.yml volume mounts use ${HOST_LOG_DIR:-./var/logs}
    if [ -n "${SCRIPT_DIR:-}" ]; then
        local relative_log_dir="${SCRIPT_DIR}/var/logs"
        mkdir -p "$relative_log_dir"
        
        for service in "${services[@]}"; do
            mkdir -p "${relative_log_dir}/${service}"
        done
        
        chmod -R 777 "$relative_log_dir"
        
        # If using standard paths (not legacy), log to both locations
        # The relative path is for Docker Compose volumes, absolute path for system logs
        if [ "${BITOARCH_LAYOUT}" != "legacy" ]; then
            # Note: Docker containers will write to ./var/logs via volume mount
            # which is separate from the system logs in /usr/local/var/bitoarch/logs
            : # Both directories exist and serve different purposes
        fi
    fi
}

# ============================================================================
# MIGRATION HELPERS
# ============================================================================

# Check if migration is needed
needs_migration() {
    # If using legacy layout and standard paths don't exist, migration needed
    if is_legacy_layout; then
        if [ ! -f "$(get_config_file)" ]; then
            return 0  # True - needs migration
        fi
    fi
    return 1  # False - no migration needed
}

# Get legacy installation directory (if exists)
get_legacy_dir() {
    if [ -n "${SCRIPT_DIR:-}" ] && [ -f "${SCRIPT_DIR}/.env-bitoarch" ]; then
        echo "${SCRIPT_DIR}"
    else
        echo ""
    fi
}

# ============================================================================
# UTILITY FUNCTIONS
# ============================================================================

# Print current path configuration (for debugging)
print_path_config() {
    echo "Bito AI Architect - Path Configuration"
    echo "========================================"
    echo "Layout:          ${BITOARCH_LAYOUT}"
    echo "Prefix:          ${BITOARCH_PREFIX}"
    echo "Config Dir:      ${BITOARCH_CONFIG_DIR}"
    echo "Log Dir:         ${BITOARCH_LOG_DIR}"
    echo "Lib Dir:         ${BITOARCH_LIB_DIR}"
    echo "Config File:     $(get_config_file)"
    echo "Setup Log:       $(get_setup_log)"
    echo ""
}

# Validate paths (check if critical files exist)
validate_paths() {
    local errors=0
    
    if [ ! -f "$(get_config_file)" ]; then
        echo "ERROR: Config file not found: $(get_config_file)" >&2
        errors=$((errors + 1))
    fi
    
    if [ ! -d "$(get_log_dir)" ]; then
        echo "ERROR: Log directory not found: $(get_log_dir)" >&2
        errors=$((errors + 1))
    fi
    
    return $errors
}
