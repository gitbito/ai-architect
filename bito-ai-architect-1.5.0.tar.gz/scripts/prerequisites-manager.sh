#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai

get_available_memory_mb() {
    case "$OSTYPE" in
        darwin*)
            vm_stat | grep "Pages free" | awk '{print int($3*4096/1024/1024)}'
            ;;
        linux*)
            free -m | awk 'NR==2{print $7}'
            ;;
        *)
            echo "0"
            ;;
    esac
}

get_disk_space_gb() {
    local path="$1"
    case "$OSTYPE" in
        darwin*)
            df -h "$path" | awk 'NR==2{print $4}' | sed 's/Gi*//' | sed 's/G.*//'
            ;;
        linux*)
            df -BG "$path" | awk 'NR==2{print $4}' | sed 's/G//'
            ;;
        *)
            echo "0"
            ;;
    esac
}

install_packages_common() {
    local package_manager="$1"
    local manager_name="$2"
    local SUDO_CMD="$3"
    local packages="curl wget ca-certificates"
    
    if [[ "$package_manager" == "apt-get" ]]; then
        packages="$packages gnupg lsb-release"
        print_info "Updating package lists..."
        $SUDO_CMD apt-get update >/dev/null 2>&1 || true
    fi
    
    print_info "Installing prerequisites with $manager_name..."
    if $SUDO_CMD $package_manager install -y $packages >/dev/null 2>&1; then
        print_status "Prerequisites installed successfully"
        return 0
    else
        print_warning "Package installation had issues, trying curl only..."
        if $SUDO_CMD $package_manager install -y curl >/dev/null 2>&1; then
            print_status "curl installed successfully"
            return 0
        elif [[ "$package_manager" == "apt-get" ]]; then
            print_info "Attempting alternative curl installation..."
            if $SUDO_CMD apt-get install -y curl-minimal >/dev/null 2>&1; then
                print_status "curl-minimal installed successfully"
                return 0
            fi
        fi
        return 1
    fi
}

install_prerequisites() {
    print_info "Installing basic prerequisites for one-command setup..."
    
    if [[ "$OSTYPE" == "linux-gnu"* ]] || \
       [[ -f "/etc/redhat-release" ]] || \
       [[ -f "/etc/debian_version" ]]; then
        
        if command -v curl >/dev/null 2>&1; then
            print_status "Prerequisites already available"
            return 0
        fi
        
        print_info "Installing curl and other essential packages..."
        
        local SUDO_CMD=""
        if [ "$EUID" -ne 0 ]; then
            SUDO_CMD="sudo"
        fi
        
        local installation_success=false
        if command -v apt-get >/dev/null 2>&1; then
            install_packages_common "apt-get" "Ubuntu/Debian" "$SUDO_CMD" && installation_success=true
        elif command -v yum >/dev/null 2>&1; then
            install_packages_common "yum" "CentOS/RHEL" "$SUDO_CMD" && installation_success=true
        elif command -v dnf >/dev/null 2>&1; then
            install_packages_common "dnf" "Fedora/RHEL 8+" "$SUDO_CMD" && installation_success=true
        else
            print_warning "Cannot automatically install prerequisites"
            print_info "Please ensure curl and wget are available"
            print_info "On Ubuntu/Debian: apt-get install -y curl wget"
            print_info "On CentOS/RHEL: yum install -y curl wget"
            print_info "On Fedora: dnf install -y curl wget"
        fi
        
        if command -v curl >/dev/null 2>&1; then
            print_status "curl is now available for Docker installation"
            if curl --version >/dev/null 2>&1; then
                print_status "curl is working correctly"
            else
                print_warning "curl installed but may not be fully functional"
            fi
        else
            if [[ "$installation_success" == "false" ]]; then
                print_error "Failed to install curl - required for Docker installation"
                print_info "Manual installation required. In your container, try:"
                print_command "apt update && apt install -y curl"
                print_info "Then run the setup script again."
                exit 1
            fi
        fi
    else
        print_status "Prerequisites check not needed for this platform"
    fi
}

check_prerequisites() {
    print_info "Checking system requirements..."
    
    log_silent "Starting prerequisites check..."
    install_prerequisites
    
    local SUDO_CMD=""
    if [ "$EUID" -ne 0 ]; then
        SUDO_CMD="sudo"
    fi
    
    # Docker check
    if ! command -v docker >/dev/null 2>&1; then
        print_warning "Docker is not installed"
        read -p "Would you like to install Docker automatically? [Y/n]: " -r REPLY
        if [[ ! $REPLY =~ ^[Nn]$ ]]; then
            install_docker
        else
            print_error "Docker is required to continue"
            print_info "Please install Docker and try again"
            exit 1
        fi
    fi
    
    # Docker Compose check
    if docker compose version >/dev/null 2>&1; then
        DOCKER_COMPOSE_CMD="docker compose"
        log_silent "Docker Compose v2 detected"
    elif docker-compose version >/dev/null 2>&1; then
        DOCKER_COMPOSE_CMD="docker-compose"
        log_silent "Docker Compose v1 detected"
    else
        print_warning "Docker Compose not found, installing..."
        if [[ "$OSTYPE" == "darwin"* ]] && command -v brew >/dev/null 2>&1; then
            brew install docker-compose >/dev/null 2>&1
            if docker-compose version >/dev/null 2>&1; then
                DOCKER_COMPOSE_CMD="docker-compose"
                log_silent "Docker Compose installed successfully"
            else
                print_error "Failed to install Docker Compose"
                exit 1
            fi
        else
            print_error "Docker Compose is not available"
            print_info "Please install Docker Compose manually"
            exit 1
        fi
    fi
    
    # Docker daemon check
    if ! docker info >/dev/null 2>&1; then
        print_error "Docker daemon is not running"
        echo ""
        if [[ "$OSTYPE" == "darwin"* ]]; then
            print_info "To start Docker on macOS:"
            print_info "  • Colima: colima start --cpu 2 --memory 4 --disk 20"
            print_info "  • Docker Desktop: Open Docker Desktop application"
        else
            print_info "To start Docker on Linux:"
            print_info "  • Run: sudo systemctl start docker"
        fi
        echo ""
        print_info "Then run this script again"
        exit 1
    fi
    
    # Resource checks (warnings only)
    log_silent "Checking system resources..."
    local available_space=$(get_disk_space_gb "$SCRIPT_DIR")
    if [ -n "$available_space" ] && [ "$available_space" -lt 10 ] 2>/dev/null; then
        print_warning "Low disk space detected (less than 10GB available)"
        log_silent "Available disk space: ${available_space}GB"
    fi
    
    if command -v free >/dev/null 2>&1; then
        local available_mem=$(free -g | awk 'NR==2{print $7}')
        if [ "$available_mem" -lt 4 ]; then
            log_silent "Available memory: ${available_mem}GB"
        fi
    elif [[ "$OSTYPE" == "darwin"* ]]; then
        local available_mem=$(get_available_memory_mb)
        local available_mem_gb=$((available_mem / 1024))
        if [ "$available_mem_gb" -lt 4 ]; then
            log_silent "Available memory: ${available_mem_gb}GB"
        fi
    fi

    # Check and optionally install CLI tools (jq, yq)
    check_cli_tools
    
    print_status "System requirements verified"
}

check_ports() {
    log_silent "Checking port availability..."
    
    PORTS=(8080 8081 9090 3306)
    local ports_in_use=()
    
    for PORT in "${PORTS[@]}"; do
        if command -v netstat >/dev/null 2>&1; then
            if netstat -an | grep -q ":$PORT "; then
                ports_in_use+=($PORT)
                log_silent "Port $PORT is in use"
            fi
        elif command -v lsof >/dev/null 2>&1; then
            if lsof -i ":$PORT" >/dev/null 2>&1; then
                ports_in_use+=($PORT)
                log_silent "Port $PORT is in use"
            fi
        fi
    done
    
    if [ ${#ports_in_use[@]} -gt 0 ]; then
        print_warning "Ports in use: ${ports_in_use[*]} (automatic port assignment will handle this)"
        log_silent "Ports requiring reassignment: ${ports_in_use[*]}"
    fi
    
    log_silent "Port availability check completed"
}

# Install jq for JSON processing
install_jq() {
    if command -v jq >/dev/null 2>&1; then
        log_silent "jq is already installed"
        return 0
    fi
    
    print_info "Installing jq..."
    
    local SUDO_CMD=""
    if [ "$EUID" -ne 0 ]; then
        SUDO_CMD="sudo"
    fi
    
    if [[ "$OSTYPE" == "darwin"* ]]; then
        # macOS - use Homebrew
        if command -v brew >/dev/null 2>&1; then
            if brew install jq >/dev/null 2>&1; then
                print_status "jq installed successfully"
                return 0
            else
                print_error "Failed to install jq via Homebrew"
                return 1
            fi
        else
            print_error "Homebrew not found. Please install jq manually:"
            print_info "  brew install jq"
            return 1
        fi
    elif [[ "$OSTYPE" == "linux-gnu"* ]]; then
        # Linux - use package manager
        if command -v apt-get >/dev/null 2>&1; then
            if $SUDO_CMD apt-get update >/dev/null 2>&1 && $SUDO_CMD apt-get install -y jq >/dev/null 2>&1; then
                print_status "jq installed successfully"
                return 0
            fi
        elif command -v yum >/dev/null 2>&1; then
            if $SUDO_CMD yum install -y jq >/dev/null 2>&1; then
                print_status "jq installed successfully"
                return 0
            fi
        elif command -v dnf >/dev/null 2>&1; then
            if $SUDO_CMD dnf install -y jq >/dev/null 2>&1; then
                print_status "jq installed successfully"
                return 0
            fi
        fi
        print_error "Failed to install jq"
        return 1
    fi
}

# Install yq for YAML processing
install_yq() {
    if command -v yq >/dev/null 2>&1; then
        log_silent "yq is already installed"
        return 0
    fi
    
    print_info "Installing yq..."
    
    local SUDO_CMD=""
    if [ "$EUID" -ne 0 ]; then
        SUDO_CMD="sudo"
    fi
    
    if [[ "$OSTYPE" == "darwin"* ]]; then
        # macOS - use Homebrew
        if command -v brew >/dev/null 2>&1; then
            if brew install yq >/dev/null 2>&1; then
                print_status "yq installed successfully"
                return 0
            else
                print_error "Failed to install yq via Homebrew"
                return 1
            fi
        else
            print_error "Homebrew not found. Please install yq manually:"
            print_info "  brew install yq"
            return 1
        fi
    elif [[ "$OSTYPE" == "linux-gnu"* ]]; then
        # Linux - download binary directly
        local YQ_VERSION="v4.35.1"
        local YQ_BINARY="yq_linux_amd64"
        
        # Detect architecture
        local ARCH=$(uname -m)
        if [[ "$ARCH" == "aarch64" ]] || [[ "$ARCH" == "arm64" ]]; then
            YQ_BINARY="yq_linux_arm64"
        fi
        
        print_info "Downloading yq ${YQ_VERSION} for Linux..."
        
        if command -v wget >/dev/null 2>&1; then
            if wget -q "https://github.com/mikefarah/yq/releases/download/${YQ_VERSION}/${YQ_BINARY}" -O /tmp/yq 2>/dev/null; then
                if $SUDO_CMD mv /tmp/yq /usr/local/bin/yq 2>/dev/null && $SUDO_CMD chmod +x /usr/local/bin/yq 2>/dev/null; then
                    print_status "yq installed successfully"
                    return 0
                fi
            fi
        elif command -v curl >/dev/null 2>&1; then
            if curl -sL "https://github.com/mikefarah/yq/releases/download/${YQ_VERSION}/${YQ_BINARY}" -o /tmp/yq 2>/dev/null; then
                if $SUDO_CMD mv /tmp/yq /usr/local/bin/yq 2>/dev/null && $SUDO_CMD chmod +x /usr/local/bin/yq 2>/dev/null; then
                    print_status "yq installed successfully"
                    return 0
                fi
            fi
        fi
        
        # Fallback: try package managers
        if command -v apt-get >/dev/null 2>&1; then
            # Add repository for yq
            if $SUDO_CMD add-apt-repository -y ppa:rmescandon/yq >/dev/null 2>&1; then
                if $SUDO_CMD apt-get update >/dev/null 2>&1 && $SUDO_CMD apt-get install -y yq >/dev/null 2>&1; then
                    print_status "yq installed successfully"
                    return 0
                fi
            fi
        elif command -v snap >/dev/null 2>&1; then
            if $SUDO_CMD snap install yq >/dev/null 2>&1; then
                print_status "yq installed successfully via snap"
                return 0
            fi
        fi
        
        print_error "Failed to install yq"
        print_info "As a fallback, the CLI will use python3 with PyYAML if available"
        return 1
    fi
}

# Install Python PyYAML package
install_python_pyyaml() {
    if ! command -v python3 >/dev/null 2>&1; then
        return 1
    fi
    
    # Check if PyYAML is already installed
    if python3 -c "import yaml" 2>/dev/null; then
        log_silent "PyYAML is already installed"
        return 0
    fi
    
    print_info "Installing Python PyYAML package..."
    
    # Try pip3 first
    if command -v pip3 >/dev/null 2>&1; then
        if pip3 install --user PyYAML >/dev/null 2>&1; then
            print_status "PyYAML installed successfully"
            return 0
        fi
    fi
    
    # Try python3 -m pip
    if python3 -m pip install --user PyYAML >/dev/null 2>&1; then
        print_status "PyYAML installed successfully"
        return 0
    fi
    
    return 1
}

# Check and install CLI tools (jq and yq) - MANDATORY
check_cli_tools() {
    print_info "Checking required CLI tools..."
    
    # ===== JQ CHECK (MANDATORY) =====
    if ! command -v jq >/dev/null 2>&1; then
        print_warning "jq is not installed (required for JSON processing)"
        print_info "Attempting to install jq..."
        
        if ! install_jq; then
            print_error "Failed to install jq"
            print_error "jq is required for this platform to function"
            echo ""
            print_info "Please install jq manually:"
            print_info "  • macOS: brew install jq"
            print_info "  • Ubuntu/Debian: apt-get install jq"
            print_info "  • CentOS/RHEL: yum install jq"
            echo ""
            exit 1
        fi
    fi
    
    # ===== YAML PROCESSING CHECK (MANDATORY - yq OR python3+PyYAML) =====
    local yaml_tool_available=false
    
    # Try 1: Check if yq is available
    if command -v yq >/dev/null 2>&1; then
        yaml_tool_available=true
        log_silent "yq is available"
    # Try 2: Check if python3 with PyYAML is available
    elif command -v python3 >/dev/null 2>&1 && python3 -c "import yaml" 2>/dev/null; then
        yaml_tool_available=true
        log_silent "python3 with PyYAML is available"
        print_info "Using python3 with PyYAML for YAML processing"
    fi
    
    # If neither available, try to install
    if [ "$yaml_tool_available" = false ]; then
        print_warning "YAML processing tool not found (need yq or python3+PyYAML)"
        echo ""
        
        # Try installing yq first
        print_info "Attempting to install yq..."
        if install_yq; then
            yaml_tool_available=true
        else
            print_warning "yq installation failed, trying python3+PyYAML fallback..."
            
            # If yq failed, try python3 + PyYAML
            if command -v python3 >/dev/null 2>&1; then
                if install_python_pyyaml; then
                    yaml_tool_available=true
                fi
            else
                print_warning "python3 is not available"
            fi
        fi
        
        # If both failed, exit
        if [ "$yaml_tool_available" = false ]; then
            echo ""
            print_error "Failed to install YAML processing tools"
            print_error "At least one of these is required: yq OR python3+PyYAML"
            echo ""
            print_info "Please install manually:"
            print_info "  Option 1 - Install yq:"
            print_info "    • macOS: brew install yq"
            print_info "    • Linux: https://github.com/mikefarah/yq#install"
            print_info "  Option 2 - Install Python PyYAML:"
            print_info "    • pip3 install PyYAML"
            echo ""
            exit 1
        fi
    fi
    
    print_status "CLI tools verified (jq + YAML processor available)"
}
