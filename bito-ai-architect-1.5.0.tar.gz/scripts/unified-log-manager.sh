#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
# 
# ======================================================================================
# Unified Log Manager - Works for both Docker and Kubernetes
# Handles log rotation, compression, and cleanup for all services
# ======================================================================================

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[1;34m'
NC='\033[0m' # No Color

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PLATFORM_DIR="$(dirname "$SCRIPT_DIR")"

# Source path manager for standard Unix paths
if [ -f "${SCRIPT_DIR}/lib/path-manager.sh" ]; then
    source "${SCRIPT_DIR}/lib/path-manager.sh"
fi

# Get log directory from path-manager (handles standard vs legacy paths)
LOG_BASE_DIR="$(get_log_dir)"
SETUP_LOG="$(get_setup_log)"

# Load configuration from env file if available
if [ -f "$(get_config_file)" ]; then
    source "$(get_config_file)"
fi

# Default configuration (can be overridden in .env-bitoarch)
LOG_MAX_SIZE="${LOG_MAX_SIZE:-100M}"
LOG_MAX_FILES="${LOG_MAX_FILES:-10}"
SERVICE_LOG_MAX_SIZE="${SERVICE_LOG_MAX_SIZE:-50M}"
SERVICE_LOG_MAX_FILES="${SERVICE_LOG_MAX_FILES:-3}"

# Services to manage  
SERVICES=("mysql" "cis-config" "cis-manager" "cis-provider" "cis-tracker")

# Print functions
print_status() {
    echo -e "${GREEN}✓${NC} $1"
}

print_error() {
    echo -e "${RED}✗${NC} $1"
}

print_info() {
    echo -e "${BLUE}ℹ${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}⚠${NC} $1"
}

# Convert size to bytes for comparison
size_to_bytes() {
    local size="$1"
    local value="${size%[A-Za-z]*}"
    local unit="${size#${value}}"
    
    # Convert to uppercase (compatible with bash 3.x and zsh)
    unit=$(echo "$unit" | tr '[:lower:]' '[:upper:]')
    
    case "$unit" in
        K|KB) echo "$((value * 1024))" ;;
        M|MB) echo "$((value * 1024 * 1024))" ;;
        G|GB) echo "$((value * 1024 * 1024 * 1024))" ;;
        *) echo "$value" ;;
    esac
}

# Get file size in bytes
get_file_size() {
    local file="$1"
    if [ ! -f "$file" ]; then
        echo "0"
        return
    fi
    
    if [[ "$OSTYPE" == "darwin"* ]]; then
        stat -f%z "$file" 2>/dev/null || echo "0"
    else
        stat -c%s "$file" 2>/dev/null || echo "0"
    fi
}

# Rotate a log file with timestamp
rotate_log_file() {
    local log_file="$1"
    local max_files="${2:-3}"
    
    if [ ! -f "$log_file" ]; then
        return 0
    fi
    
    local file_size=$(get_file_size "$log_file")
    if [ "$file_size" -eq 0 ]; then
        return 0
    fi
    
    # Create timestamp for rotation
    local timestamp=$(date +%Y-%m-%d_%H-%M-%S)
    local rotated_file="${log_file}.${timestamp}.gz"
    
    # Compress and rotate
    gzip -c "$log_file" > "$rotated_file" 2>/dev/null || return 1
    
    # Truncate original log
    > "$log_file"
    
    # Clean up old rotations (keep only max_files)
    local log_dir=$(dirname "$log_file")
    local log_name=$(basename "$log_file")
    local rotated_count=$(find "$log_dir" -name "${log_name}.*.gz" 2>/dev/null | wc -l | tr -d ' ')
    
    if [ "$rotated_count" -gt "$max_files" ]; then
        # Remove oldest rotations
        find "$log_dir" -name "${log_name}.*.gz" -type f 2>/dev/null | \
            sort | \
            head -n $((rotated_count - max_files)) | \
            xargs rm -f 2>/dev/null || true
    fi
    
    return 0
}

# Check and rotate setup.log if needed
rotate_setup_log() {
    if [ ! -f "$SETUP_LOG" ]; then
        return 0
    fi
    
    local file_size=$(get_file_size "$SETUP_LOG")
    local max_bytes=$(size_to_bytes "$LOG_MAX_SIZE")
    
    if [ "$file_size" -ge "$max_bytes" ]; then
        print_info "Rotating setup.log (size: $((file_size / 1024 / 1024))MB)"
        if rotate_log_file "$SETUP_LOG" "$LOG_MAX_FILES"; then
            print_status "Setup log rotated successfully"
        else
            print_warning "Failed to rotate setup log"
        fi
    fi
}

# Check and rotate service log if needed
rotate_service_log() {
    local service="$1"
    local log_file="${LOG_BASE_DIR}/${service}/${service}.log"
    
    if [ ! -f "$log_file" ]; then
        return 0
    fi
    
    local file_size=$(get_file_size "$log_file")
    local max_bytes=$(size_to_bytes "$SERVICE_LOG_MAX_SIZE")
    
    if [ "$file_size" -ge "$max_bytes" ]; then
        if rotate_log_file "$log_file" "$SERVICE_LOG_MAX_FILES"; then
            print_status "Rotated ${service} log"
            return 0
        else
            print_warning "Failed to rotate ${service} log"
            return 1
        fi
    fi
    
    return 0
}

# Create service log directories
create_service_log_dirs() {
    log_silent "Creating service log directories..."
    
    for service in "${SERVICES[@]}"; do
        local service_log_dir="${LOG_BASE_DIR}/${service}"
        mkdir -p "$service_log_dir" 2>/dev/null || {
            if command -v sudo >/dev/null 2>&1; then
                sudo mkdir -p "$service_log_dir"
                sudo chown -R "$USER:$(id -gn)" "$service_log_dir"
            fi
        }
        chmod 755 "$service_log_dir" 2>/dev/null || true
    done
    
    log_silent "Service log directories created at ${LOG_BASE_DIR}/"
}

# Capture Docker logs to compressed file on restart
capture_docker_logs_to_gz() {
    local service="$1"
    # Convert cis-manager to manager for container name
    local service_short="${service#cis-}"
    local container_name="ai-architect-${service_short}"
    local service_log_dir="${LOG_BASE_DIR}/${service}"
    local timestamp=$(date +%Y-%m-%d_%H-%M-%S)
    local gz_file="${service_log_dir}/${service}.${timestamp}.gz"
    
    # Ensure log directory exists
    mkdir -p "$service_log_dir" 2>/dev/null || true
    
    # Check if container exists and is running
    if ! docker ps --format '{{.Names}}' | grep -q "^${container_name}$" 2>/dev/null; then
        # Container not running, check if it existed recently
        if ! docker ps -a --format '{{.Names}}' | grep -q "^${container_name}$" 2>/dev/null; then
            return 0  # Container never existed
        fi
    fi
    
    # Capture logs directly to .gz file
    if docker logs --tail 50000 "$container_name" 2>&1 | gzip > "$gz_file" 2>/dev/null; then
        # Successfully captured logs
        chmod 644 "$gz_file" 2>/dev/null || true
        
        # Clean up old logs (keep only max_files)
        local log_count=$(find "$service_log_dir" -name "${service}.*.gz" 2>/dev/null | wc -l | tr -d ' ')
        
        if [ "$log_count" -gt "$SERVICE_LOG_MAX_FILES" ]; then
            find "$service_log_dir" -name "${service}.*.gz" -type f 2>/dev/null | \
                sort | \
                head -n $((log_count - SERVICE_LOG_MAX_FILES)) | \
                xargs rm -f 2>/dev/null || true
        fi
        return 0
    else
        # Failed to capture logs, remove empty file if created
        rm -f "$gz_file" 2>/dev/null || true
        return 1
    fi
}

# Capture K8s logs to compressed file on restart
capture_k8s_logs_to_gz() {
    local service="$1"
    # Convert cis-manager to manager for K8s label selector
    local service_short="${service#cis-}"
    local namespace="${2:-bito-ai-architect}"
    local service_log_dir="${LOG_BASE_DIR}/${service}"
    local timestamp=$(date +%Y-%m-%d_%H-%M-%S)
    local gz_file="${service_log_dir}/${service}.${timestamp}.gz"
    
    # Ensure log directory exists
    mkdir -p "$service_log_dir" 2>/dev/null || true
    
    # Get pod name for this service using short name (matches K8s labels)
    local pod=$(kubectl get pods -n "$namespace" \
        -l "app.kubernetes.io/component=${service_short}" \
        -o jsonpath='{.items[0].metadata.name}' 2>/dev/null || echo "")
    
    if [ -z "$pod" ]; then
        return 0
    fi
    
    # Capture logs directly to .gz file (use --tail to limit size)
    kubectl logs "$pod" -n "$namespace" --tail=50000 2>&1 | gzip > "$gz_file" || return 1
    
    # Clean up old logs (keep only max_files)
    local log_count=$(find "$service_log_dir" -name "${service}.*.gz" 2>/dev/null | wc -l | tr -d ' ')
    
    if [ "$log_count" -gt "$SERVICE_LOG_MAX_FILES" ]; then
        find "$service_log_dir" -name "${service}.*.gz" -type f 2>/dev/null | \
            sort | \
            head -n $((log_count - SERVICE_LOG_MAX_FILES)) | \
            xargs rm -f 2>/dev/null || true
    fi
}

# Capture all service logs to .gz files (auto-detect deployment type)
# Runs silently by default - only shows errors
sync_all_logs() {
    local deployment_type="$1"
    
    if [ -z "$deployment_type" ]; then
        # Auto-detect
        if [ -f "${PLATFORM_DIR}/.deployment-type" ]; then
            deployment_type=$(cat "${PLATFORM_DIR}/.deployment-type")
        elif type get_deployment_type >/dev/null 2>&1; then
            deployment_type=$(get_deployment_type)
        else
            deployment_type="docker-compose"
        fi
    fi
    
    # Capture logs silently
    for service in "${SERVICES[@]}"; do
        if [ "$deployment_type" = "kubernetes" ]; then
            capture_k8s_logs_to_gz "$service" 2>/dev/null || true
        else
            capture_docker_logs_to_gz "$service" 2>/dev/null || true
        fi
    done
}

# Capture all logs on --clean command
rotate_all_on_clean() {
    log_silent "Capturing all logs before clean..."
    
    # Rotate setup.log (keeps .gz files in same directory as setup.log)
    if [ -f "$SETUP_LOG" ]; then
        rotate_log_file "$SETUP_LOG" "$LOG_MAX_FILES"
    fi
    
    # Capture service logs to .gz files
    sync_all_logs
    
    log_silent "All logs captured and compressed"
}

# Show log status
show_status() {
    echo -e "${BLUE}Log Status${NC}"
    echo "===================="
    echo ""
    
    # Setup log status
    if [ -f "$SETUP_LOG" ]; then
        local size=$(get_file_size "$SETUP_LOG")
        local size_mb=0
        [ "$size" -gt 0 ] && size_mb=$((size / 1024 / 1024))
        local max_bytes=$(size_to_bytes "$LOG_MAX_SIZE")
        local max_mb=0
        [ "$max_bytes" -gt 0 ] && max_mb=$((max_bytes / 1024 / 1024))
        local rotations=$(find "$(dirname "$SETUP_LOG")" -name "setup.log.*.gz" 2>/dev/null | wc -l | tr -d ' ')
        printf "%-25s %s MB / %s MB (%s rotations)\n" "setup.log:" "$size_mb" "$max_mb" "$rotations"
    fi
    
    echo ""
    echo -e "${BLUE}Service Logs (.gz files)${NC}"
    echo "────────────────────────"
    
    # Service log status (show .gz files)
    for service in "${SERVICES[@]}"; do
        local service_log_dir="${LOG_BASE_DIR}/${service}"
        if [ -d "$service_log_dir" ]; then
            local gz_count=$(find "$service_log_dir" -name "${service}.*.gz" 2>/dev/null | wc -l | tr -d ' ')
            printf "%-25s %s .gz files (max: %s)\n" "${service}:" "$gz_count" "$SERVICE_LOG_MAX_FILES"
        fi
    done
    
    echo ""
    print_info "Log directory: ${LOG_BASE_DIR}/"
    print_info "Service logs captured to .gz on each restart"
}

# Show usage
show_usage() {
    echo "Unified Log Manager - Docker & Kubernetes"
    echo ""
    echo "Usage: $0 <command> [options]"
    echo ""
    echo "Commands:"
    echo "  init                   Create log directories"
    echo "  sync [type]            Sync logs from containers/pods (auto-detects type)"
    echo "  rotate-setup           Rotate setup.log if size exceeded"
    echo "  rotate-service <name>  Rotate specific service log"
    echo "  rotate-all             Rotate all logs that exceed size limit"
    echo "  clean-archive          Archive all logs (used before --clean)"
    echo "  status                 Show log status and sizes"
    echo ""
    echo "Examples:"
    echo "  $0 init                # Create log directories"
    echo "  $0 sync                # Sync logs (auto-detect deployment)"
    echo "  $0 sync docker         # Sync Docker logs"
    echo "  $0 sync kubernetes     # Sync Kubernetes logs"
    echo "  $0 rotate-setup        # Rotate setup.log"
    echo "  $0 clean-archive       # Archive before clean"
    echo ""
}

# Main command dispatcher
main() {
    local command="${1:-status}"
    
    case "$command" in
        init)
            create_service_log_dirs
            ;;
        sync)
            create_service_log_dirs
            sync_all_logs "${2:-}"
            ;;
        rotate-setup)
            rotate_setup_log
            ;;
        rotate-service)
            if [ -z "$2" ]; then
                print_error "Service name required"
                exit 1
            fi
            rotate_service_log "$2"
            ;;
        rotate-all)
            rotate_setup_log
            for service in "${SERVICES[@]}"; do
                rotate_service_log "$service"
            done
            ;;
        clean-archive)
            rotate_all_on_clean
            ;;
        status)
            show_status
            ;;
        --help|-h|help)
            show_usage
            ;;
        *)
            print_error "Unknown command: $command"
            show_usage
            exit 1
            ;;
    esac
}

# Run main
main "$@"
