#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
# CIS Provider Config Extraction and Transformation Script
# Extracts default.json from XMCP Docker image and transforms it for cis-platform deployment
#
# Key Features:
# - Extracts complete config from Docker image (preserves all tools, resources, etc.)
# - Replaces specific values with environment variable placeholders
# - Supports deployment.mode transformation for single/multi-tenant deployments

set -e

# Script directory and paths
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PLATFORM_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
CONFIG_DIR="${PLATFORM_DIR}/services/cis-provider/config"
CONFIG_FILE="${CONFIG_DIR}/default.json"
BACKUP_DIR="${CONFIG_DIR}/.backups"

# Source output utilities if available
if [ -f "${PLATFORM_DIR}/scripts/lib/output-blocks.sh" ]; then
    source "${PLATFORM_DIR}/scripts/lib/output-blocks.sh"
else
    # Fallback output functions
    RED='\033[0;31m'
    GREEN='\033[0;32m'
    YELLOW='\033[1;33m'
    BLUE='\033[1;34m'
    NC='\033[0m'
    msg_success() { echo -e "${GREEN}✓${NC} $1"; }
    msg_info() { echo -e "${BLUE}ℹ${NC} $1"; }
    msg_warn() { echo -e "${YELLOW}⚠${NC} $1"; }
    msg_error() { echo -e "${RED}✗${NC} $1"; }
fi

# Source config-backup-manager for centralized backup utility
if [ -f "${PLATFORM_DIR}/scripts/lib/config-backup-manager.sh" ]; then
    source "${PLATFORM_DIR}/scripts/lib/config-backup-manager.sh"
fi

# Check prerequisites
check_prerequisites() {
    echo -e "${BLUE}ℹ${NC} Checking prerequisites..."
    
    # Check for Docker
    if ! command -v docker &> /dev/null; then
        echo -e "${RED}✗${NC} Docker is not installed or not in PATH"
        exit 1
    fi
    
    # Check for jq
    if ! command -v jq &> /dev/null; then
        echo -e "${RED}✗${NC} jq is not installed. Please install it: brew install jq"
        exit 1
    fi
    
    echo -e "${GREEN}✓${NC} Prerequisites check passed"
}

# Load environment configuration
load_env_config() {
    local env_file="${PLATFORM_DIR}/.env-bitoarch"
    
    if [ -f "$env_file" ]; then
        # Source the environment file to get CIS_PROVIDER_VERSION
        set -a
        source "$env_file"
        set +a
        echo -e "${BLUE}ℹ${NC} Loaded configuration from .env-bitoarch"
        echo -e "${BLUE}ℹ${NC} CIS_PROVIDER_VERSION=${CIS_PROVIDER_VERSION:-not set}"
    else
        echo -e "${YELLOW}⚠${NC} .env-bitoarch not found, using default version"
        echo -e "${BLUE}ℹ${NC} CIS_PROVIDER_VERSION will default to 'latest'"
    fi
}

# Get Docker image information from docker-compose.yml
get_docker_image_info() {
    local compose_file="${PLATFORM_DIR}/docker-compose.yml"
    
    if [ ! -f "$compose_file" ]; then
        echo -e "${RED}✗${NC} docker-compose.yml not found at: $compose_file" >&2
        return 1
    fi
    
    local image_line=$(grep "cis-provider-image:" "$compose_file" | grep -v "^[[:space:]]*#" | tail -1)
    
    if [ -z "$image_line" ]; then
        echo -e "${RED}✗${NC} Could not find cis-provider-image definition in docker-compose.yml" >&2
        return 1
    fi
    
    local full_image=$(echo "$image_line" | sed 's/.*&provider-image[[:space:]]*//' | sed 's/[[:space:]]*$//')
    
    local version="${CIS_PROVIDER_VERSION:-latest}"
    full_image=$(echo "$full_image" | sed "s/\${CIS_PROVIDER_VERSION:-[^}]*}/$version/")
    
    echo "$full_image"
    return 0
}

# Extract config from Docker image and create template with placeholders
extract_config_from_image() {
    local image_name="$1"
    local version="$2"
    local full_image="${image_name}:${version}"
    
    echo -e "${BLUE}ℹ${NC} Extracting config from Docker image: $full_image" >&2
    
    # Check if image exists locally, if not pull it
    if ! docker image inspect "$full_image" &> /dev/null; then
        echo -e "${BLUE}ℹ${NC} Pulling Docker image: $full_image" >&2
        if ! docker pull "$full_image" 2>&1 | grep -v "Pulling from"; then
            echo -e "${RED}✗${NC} Failed to pull Docker image: $full_image" >&2
            return 1
        fi
    fi
    
    # Path to config in XMCP container
    local config_path_in_container="/opt/bito/xmcp/config/default.json"
    
    echo -e "${BLUE}ℹ${NC} Extracting config from Docker image..." >&2

    if ! docker run --rm "$full_image" cat "${config_path_in_container}" | \
      jq \
        --arg mcp_oauth_enabled "${MCP_OAUTH_ENABLED}" \
        --arg cis_provider_port "${CIS_PROVIDER_PORT}" \
        --arg cis_server_host "${CIS_SERVER_HOST}" \
        --arg cis_provider_api_key "${CIS_PROVIDER_API_KEY}" \
        --arg bito_mcp_access_token "${BITO_MCP_ACCESS_TOKEN}" \
        --arg xmcp_data_dir "${XMCP_DATA_DIR}" \
        --arg xmcp_metadata_dir "${XMCP_METADATA_DIR}" \
        --arg cis_clone_dir "${CIS_CLONE_DIR}" \
        --arg zoekt_binary_path "${ZOEKT_BINARY_PATH}" \
        --arg cis_config_url "${CIS_CONFIG_URL}" \
        --arg cis_manager_url "${CIS_MANAGER_URL}" \
        --arg jwt_secret "${JWT_SECRET}" \
        --arg log_level "${LOG_LEVEL}" '
          .transport.http.port = ($cis_provider_port | tonumber) |
          .transport.http.host = $cis_server_host |
          .transport.http.internalApiKey = $cis_provider_api_key |
          .transport.http.bearerToken = $bito_mcp_access_token |
          .transport.http.oauth.enabled = ($mcp_oauth_enabled == "true") |
          .transport.https.host = $cis_server_host |
          .transport.https.internalApiKey = $cis_provider_api_key |
          .transport.https.bearerToken = $bito_mcp_access_token |
          .transport.https.oauth.enabled = ($mcp_oauth_enabled == "true") |
          .data.dataDir = $xmcp_data_dir |
          .data.metadataDir = $xmcp_metadata_dir |
          .data.reposDir = $cis_clone_dir |
          .zoekt.binaryPath = $zoekt_binary_path |
          .services.cis_config_url = $cis_config_url |
          .services.cis_manager_url = $cis_manager_url |
          .auth.jwt_secret = $jwt_secret |
          .auth.bearer_token = $bito_mcp_access_token |
          .logging.level = $log_level
        ' > "$CONFIG_FILE" 2>&1; then
        echo -e "${RED}✗${NC} Failed to extract and process config" >&2
        rm -f "$CONFIG_FILE" 2>/dev/null
        return 1
    fi
    
    # Validate final config
    if ! jq empty "$CONFIG_FILE" 2>/dev/null; then
        echo -e "${RED}✗${NC} Failed to create valid config template" >&2
        rm -f "$CONFIG_FILE" 2>/dev/null
        return 1
    fi
    
    echo "$CONFIG_FILE"
    return 0
}

# Backup existing config if present
backup_existing_config() {
    if [ -f "$CONFIG_FILE" ]; then
        # Use centralized backup utility
        local backup_file=$(backup_config_file "$CONFIG_FILE" "provider-config")
        if [ -n "$backup_file" ]; then
            echo -e "${BLUE}ℹ${NC} Backed up existing config to: $(basename "$backup_file")"
        fi
    fi
}

# Render success block
render_config_extract_success_block() {
    local config_file="$1"
    local image_name="$2"
    local version="$3"
    local config_size="$4"
    
    echo ""
    echo -e "${GREEN}✅ Config Extraction Complete${NC}"
    echo ""
    echo -e "${BLUE}📋 Details${NC}"
    echo -e "   • Config file: ${config_file}"
    echo -e "   • Source image: ${image_name}:${version}"
    echo -e "   • File size: ${config_size} bytes"
    echo ""
    echo -e "${BLUE}🔧 Runtime Transformations${NC}"
    echo -e "   Config will be processed at container startup by provider-startup.sh"
    echo -e "   Field mappings to environment variables:"
    echo -e "   • .transport.http.port → CIS_PROVIDER_PORT"
    echo -e "   • .transport.http/https.internalApiKey → CIS_PROVIDER_API_KEY"
    echo -e "   • .transport.http/https.bearerToken → BITO_MCP_ACCESS_TOKEN"
    echo -e "   • .data.dataDir → XMCP_DATA_DIR"
    echo -e "   • .data.metadataDir → XMCP_METADATA_DIR"
    echo -e "   • .data.cloneDir → CIS_CLONE_DIR"
    echo -e "   • .services.cis_config_url → Built from CIS_CONFIG_PORT"
    echo -e "   • .services.cis_manager_url → Built from CIS_MANAGER_PORT"
    echo -e "   • .services.cis_tracker_url → Built from CIS_TRACKING_PORT"
    echo -e "   • .auth.jwt_secret → JWT_SECRET"
    echo -e "   • .logging.level → LOG_LEVEL"
    echo ""
    echo -e "${GREEN}💡 Config extracted AS-IS from Docker image. Transformations happen at container startup.${NC}"
    echo ""
}

# Main execution
main() {
    echo -e "${BLUE}CIS Provider Config Extraction & Transformation${NC}"
    echo "=================================================="
    echo ""
    
    # Check prerequisites
    check_prerequisites
    
    # Load environment configuration to get version
    load_env_config
    
    # Get Docker image info from docker-compose.yml
    local full_image=$(get_docker_image_info)
    if [ $? -ne 0 ] || [ -z "$full_image" ]; then
        echo -e "${RED}✗${NC} Failed to get Docker image information from docker-compose.yml" >&2
        exit 1
    fi
    
    echo -e "${BLUE}ℹ${NC} Target Docker image: ${full_image}"
    
    local image_name="${full_image%:*}"   
    local version="${full_image##*:}"      
    
    # Create config directory if it doesn't exist
    mkdir -p "$CONFIG_DIR"
    
    # Backup existing config
    backup_existing_config
    
    # Extract config from image and create template with placeholders
    local extracted_config=$(extract_config_from_image "$image_name" "$version")
    if [ $? -ne 0 ] || [ -z "$extracted_config" ]; then
        echo -e "${RED}✗${NC} Failed to extract config from Docker image" >&2
        exit 1
    fi
    
    echo -e "${GREEN}✓${NC} Config template created successfully with environment variable placeholders"
    
    # Get config size for summary
    local config_size=$(wc -c < "$CONFIG_FILE" 2>/dev/null || echo "0")
    
    # Render success block
    render_config_extract_success_block "$CONFIG_FILE" "$full_image" "" "$config_size"
    
    # Verify config can be read
    if [ -f "$CONFIG_FILE" ]; then
        echo -e "${BLUE}ℹ${NC} Sample transformed values:"
        echo "   - Port: $(jq -r '.transport.http.port' "$CONFIG_FILE")"
        echo "   - Host: $(jq -r '.transport.http.host' "$CONFIG_FILE")"
        echo "   - Log Level: $(jq -r '.transport.http.level' "$CONFIG_FILE")"
        echo ""
    fi
}

# Run main function
main "$@"
