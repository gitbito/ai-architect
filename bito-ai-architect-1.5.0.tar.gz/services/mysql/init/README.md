# MySQL Initialization Scripts

## Overview

These SQL scripts run automatically when MySQL container is first created. They are executed in alphabetical order.

## Script Execution Order

1. **00-create-users.sql** - Create database users
2. **02-schema.sql** - Create database schema and tables

## Adding New Service Users

### Example: Adding a New Analytics Service

#### 1. Add Environment Variables

In `docker-compose.yml` for the new service:
```yaml
environment:
  - DB_ANALYTICS_USER=cis_analytics_user
  - DB_ANALYTICS_PASSWORD=${CIS_ANALYTICS_DB_PASSWORD}
```

In `.env`:
```bash
CIS_ANALYTICS_DB_PASSWORD=secure_password_here
```

#### 2. Add User Creation

In `00-create-users.sql`, add:
```sql
-- Analytics Service User
CREATE USER IF NOT EXISTS 'cis_analytics_user'@'%' IDENTIFIED BY '${CIS_ANALYTICS_DB_PASSWORD}';
CREATE USER IF NOT EXISTS 'cis_analytics_user'@'localhost' IDENTIFIED BY '${CIS_ANALYTICS_DB_PASSWORD}';
CREATE USER IF NOT EXISTS 'cis_analytics_user'@'172.20.%' IDENTIFIED BY '${CIS_ANALYTICS_DB_PASSWORD}';

-- Grant permissions
GRANT SELECT, INSERT, UPDATE, DELETE ON `cis_platform`.`analytics_*` TO 'cis_analytics_user'@'%';
GRANT SELECT, INSERT, UPDATE, DELETE ON `cis_platform`.`analytics_*` TO 'cis_analytics_user'@'localhost';
GRANT SELECT, INSERT, UPDATE, DELETE ON `cis_platform`.`analytics_*` TO 'cis_analytics_user'@'172.20.%';
```

#### 3. Recreate MySQL Container

```bash
docker-compose down
docker volume rm cis-platform_mysql_data
docker-compose up -d mysql
```

## Permission Levels

### Full Access (Current Services)
```sql
GRANT ALL PRIVILEGES ON `database`.* TO 'user'@'host';
```

### Read/Write Access
```sql
GRANT SELECT, INSERT, UPDATE, DELETE ON `database`.* TO 'user'@'host';
```

### Read-Only Access
```sql
GRANT SELECT ON `database`.* TO 'user'@'host';
```

### Specific Tables
```sql
GRANT SELECT, INSERT ON `database`.`table_prefix_*` TO 'user'@'host';
```

## Host Patterns

- `'user'@'%'` - Allow from any host
- `'user'@'localhost'` - Only localhost
- `'user'@'172.20.%'` - Only Docker network (172.20.0.0/16)
- `'user'@'172.20.0.5'` - Specific IP

## MySQL 8.0 Compatibility

✅ **Do**: Use CREATE USER IF NOT EXISTS, then GRANT
✅ **Do**: Specify database explicitly in GRANT
❌ **Don't**: Use GRANT to implicitly create users (deprecated)
❌ **Don't**: Grant `*.*` unless needed (security)

## Testing User Access

```bash
# From within MySQL container
docker exec -it cis-mysql mysql -u cis_user -p${DB_PASSWORD} -e "SHOW GRANTS;"

# Test connection from service
docker exec -it cis-config mysql -h mysql -u cis_user -p${DB_PASSWORD} -e "SELECT 1;"
```

## Troubleshooting

### Access Denied Errors
```sql
-- Check if user exists
SELECT user, host FROM mysql.user WHERE user='cis_user';

-- Check grants
SHOW GRANTS FOR 'cis_user'@'%';
SHOW GRANTS FOR 'cis_user'@'172.20.%';
```

### User Already Exists
Docker creates `cis_user@%` automatically. Our scripts just add network-specific permissions.

### Script Execution Failed
Check container logs:
```bash
docker logs cis-mysql | grep ERROR
```

## Notes

- Scripts run only on **first container creation** (when volume is empty)
- To re-run: Remove volume with `docker volume rm cis-platform_mysql_data`
- File naming: Use 00-99 prefixes for execution order
- Keep scripts idempotent (safe to run multiple times)
