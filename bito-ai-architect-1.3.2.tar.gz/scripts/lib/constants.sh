#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
# Bito's AI Architect - Static URLs and Constants
# Centralized location for all documentation links and static resources

# Documentation URLs
export BITO_API_KEY_URL="https://alpha.bito.ai/home/advanced"
export GIT_TOKEN_DOCS_URL="https://docs.bito.ai/ai-architect/install-ai-architect-self-hosted#git-provider"
export MCP_SETUP_DOCS_URL="https://docs.bito.ai/ai-architect/install-ai-architect-self-hosted#setting-up-ai-architect-mcp-in-coding-agents"
export AI_ARCHITECT_DOCS_URL="https://docs.bito.ai/ai-architect/install-ai-architect-self-hosted"

# Product Branding
export PRODUCT_NAME="Bito's AI Architect"
export PRODUCT_SHORT_NAME="AI Architect"

# Service Display Names
export SERVICE_CONFIG_DISPLAY="AI Architect Config"
export SERVICE_MANAGER_DISPLAY="AI Architect Manager"
export SERVICE_PROVIDER_DISPLAY="AI Architect Provider"
export SERVICE_TRACKER_DISPLAY="AI Architect Tracker"
export SERVICE_MYSQL_DISPLAY="MySQL Database"
