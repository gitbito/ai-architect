#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
# Bito's AI Architect Logging Manager
# Handles realtime log streaming from Docker containers to var/logs/
# Supports log rotation, cleanup, and monitoring

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[1;34m'
NC='\033[0m' # No Color

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PLATFORM_DIR="$(dirname "$SCRIPT_DIR")"
LOG_BASE_DIR="${PLATFORM_DIR}/var/logs"
PID_DIR="${LOG_BASE_DIR}/.pids"

# Services to monitor
SERVICES=("ai-architect-mysql" "ai-architect-config" "ai-architect-manager" "ai-architect-provider" "ai-architect-tracker")

# Print functions
print_status() {
    echo -e "${GREEN}✓${NC} $1"
}

print_error() {
    echo -e "${RED}✗${NC} $1"
}

print_info() {
    echo -e "${BLUE}ℹ${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}⚠${NC} $1"
}

# Detect Docker Compose command
detect_docker_compose() {
    if docker compose version >/dev/null 2>&1; then
        echo "docker compose"
    elif docker-compose version >/dev/null 2>&1; then
        echo "docker-compose"
    else
        print_error "Docker Compose not found"
        exit 1
    fi
}

# Create log directories
create_log_directories() {
    print_info "Creating log directories..."
    
    mkdir -p "$PID_DIR"
    
    for service in "${SERVICES[@]}"; do
        mkdir -p "${LOG_BASE_DIR}/${service}"
        chmod 755 "${LOG_BASE_DIR}/${service}"
    done
    
    print_status "Log directories created at ${LOG_BASE_DIR}/"
}

# Start log streaming for a single service
start_service_log_stream() {
    local service="$1"
    local log_file="${LOG_BASE_DIR}/${service}/docker-stdout.log"
    local pid_file="${PID_DIR}/${service}.pid"
    local docker_compose_cmd=$(detect_docker_compose)
    
    # Check if already running
    if [ -f "$pid_file" ] && kill -0 $(cat "$pid_file") 2>/dev/null; then
        print_warning "Log streaming already running for $service (PID: $(cat $pid_file))"
        return 0
    fi
    
    # Start tailing in background
    cd "$PLATFORM_DIR"
    nohup bash -c "eval '$docker_compose_cmd logs -f --tail=100 $service 2>&1' | tee -a '$log_file'" > /dev/null 2>&1 &
    local tailer_pid=$!
    
    echo "$tailer_pid" > "$pid_file"
    print_status "Started log streaming for $service (PID: $tailer_pid)"
}

# Stop log streaming for a single service
stop_service_log_stream() {
    local service="$1"
    local pid_file="${PID_DIR}/${service}.pid"
    
    if [ -f "$pid_file" ]; then
        local pid=$(cat "$pid_file")
        if kill -0 "$pid" 2>/dev/null; then
            kill "$pid" 2>/dev/null || true
            # Also kill child processes
            pkill -P "$pid" 2>/dev/null || true
            print_status "Stopped log streaming for $service"
        fi
        rm -f "$pid_file"
    fi
}

# Start all log streams
start_all_streams() {
    print_info "Starting realtime log streaming for all services..."
    create_log_directories
    
    for service in "${SERVICES[@]}"; do
        start_service_log_stream "$service"
    done
    
    echo ""
    print_status "✅ Realtime log streaming enabled for all services"
    print_info "Logs location: ${LOG_BASE_DIR}/"
    print_info "View logs: tail -f ${LOG_BASE_DIR}/*/docker-stdout.log"
}

# Stop all log streams
stop_all_streams() {
    print_info "Stopping all log streams..."
    
    for service in "${SERVICES[@]}"; do
        stop_service_log_stream "$service"
    done
    
    print_status "All log streams stopped"
}

# Show status of log streaming
show_status() {
    echo -e "${BLUE}Log Streaming Status${NC}"
    echo "===================="
    echo ""
    
    for service in "${SERVICES[@]}"; do
        local pid_file="${PID_DIR}/${service}.pid"
        local log_file="${LOG_BASE_DIR}/${service}/docker-stdout.log"
        
        printf "%-15s " "$service:"
        
        if [ -f "$pid_file" ] && kill -0 $(cat "$pid_file") 2>/dev/null; then
            local pid=$(cat "$pid_file")
            local log_size="0"
            if [ -f "$log_file" ]; then
                if [[ "$OSTYPE" == "darwin"* ]]; then
                    log_size=$(du -h "$log_file" | awk '{print $1}')
                else
                    log_size=$(du -h "$log_file" | awk '{print $1}')
                fi
            fi
            echo -e "${GREEN}●${NC} Streaming (PID: $pid, Size: $log_size)"
        else
            echo -e "${RED}○${NC} Not streaming"
        fi
    done
    
    echo ""
    print_info "Log directory: ${LOG_BASE_DIR}/"
}

# Rotate logs manually
rotate_logs() {
    print_info "Rotating logs for all services..."
    
    for service in "${SERVICES[@]}"; do
        local log_file="${LOG_BASE_DIR}/${service}/docker-stdout.log"
        
        if [ -f "$log_file" ]; then
            # Rotate existing logs
            for i in {4..1}; do
                local prev=$((i-1))
                if [ -f "${log_file}.${prev}.gz" ]; then
                    mv "${log_file}.${prev}.gz" "${log_file}.${i}.gz"
                fi
            done
            
            # Compress current log and create new one
            if [ -s "$log_file" ]; then
                gzip -c "$log_file" > "${log_file}.1.gz"
                > "$log_file"  # Truncate current log
                print_status "Rotated logs for $service"
            fi
        fi
    done
    
    print_status "Log rotation completed"
}

# Cleanup old logs
cleanup_old_logs() {
    local days="${1:-30}"
    print_info "Cleaning up logs older than $days days..."
    
    local count=0
    for service in "${SERVICES[@]}"; do
        local service_log_dir="${LOG_BASE_DIR}/${service}"
        if [ -d "$service_log_dir" ]; then
            # Find and delete old compressed logs
            local found=$(find "$service_log_dir" -name "*.gz" -mtime +$days 2>/dev/null | wc -l | tr -d ' ')
            if [ "$found" -gt 0 ]; then
                find "$service_log_dir" -name "*.gz" -mtime +$days -delete 2>/dev/null || true
                count=$((count + found))
            fi
        fi
    done
    
    if [ $count -gt 0 ]; then
        print_status "Cleaned up $count old log file(s)"
    else
        print_info "No old logs to clean up"
    fi
}

# Show recent logs
show_logs() {
    local service="${1:-all}"
    local lines="${2:-50}"
    
    if [ "$service" == "all" ]; then
        for svc in "${SERVICES[@]}"; do
            local log_file="${LOG_BASE_DIR}/${svc}/docker-stdout.log"
            if [ -f "$log_file" ]; then
                echo -e "\n${BLUE}=== $svc (last $lines lines) ===${NC}"
                tail -n "$lines" "$log_file"
            fi
        done
    else
        local log_file="${LOG_BASE_DIR}/${service}/docker-stdout.log"
        if [ -f "$log_file" ]; then
            tail -n "$lines" "$log_file"
        else
            print_error "Log file not found for $service"
        fi
    fi
}

# Show usage
show_usage() {
    echo "Bito's AI Architect Logging Manager"
    echo ""
    echo "Usage: $0 <command> [options]"
    echo ""
    echo "Commands:"
    echo "  start              Start log streaming for all services"
    echo "  stop               Stop log streaming for all services"
    echo "  restart            Restart log streaming"
    echo "  status             Show log streaming status"
    echo "  rotate             Manually rotate logs"
    echo "  cleanup [days]     Remove logs older than N days (default: 30)"
    echo "  show [service]     Show recent logs (default: all services)"
    echo "  tail [service]     Follow logs in realtime"
    echo ""
    echo "Examples:"
    echo "  $0 start           # Start streaming all services"
    echo "  $0 status          # Check if streaming is active"
    echo "  $0 show cis-config # Show recent cis-config logs"
    echo "  $0 tail mysql      # Follow MySQL logs in realtime"
    echo "  $0 cleanup 7       # Remove logs older than 7 days"
    echo ""
}

# Follow logs in realtime
tail_logs() {
    local service="${1:-}"
    
    if [ -z "$service" ]; then
        print_error "Service name required"
        print_info "Available services: ${SERVICES[*]}"
        exit 1
    fi
    
    local log_file="${LOG_BASE_DIR}/${service}/docker-stdout.log"
    
    if [ ! -f "$log_file" ]; then
        print_warning "Log file not yet created: $log_file"
        print_info "Creating file and starting tail..."
        touch "$log_file"
    fi
    
    print_info "Following logs for $service (Ctrl+C to exit)"
    echo ""
    tail -f "$log_file"
}

# Main command dispatcher
main() {
    local command="${1:-start}"
    
    case "$command" in
        start)
            start_all_streams
            ;;
        stop)
            stop_all_streams
            ;;
        restart)
            stop_all_streams
            sleep 1
            start_all_streams
            ;;
        status)
            show_status
            ;;
        rotate)
            rotate_logs
            ;;
        cleanup)
            cleanup_old_logs "${2:-30}"
            ;;
        show)
            show_logs "${2:-all}" "${3:-50}"
            ;;
        tail)
            tail_logs "$2"
            ;;
        --help|-h|help)
            show_usage
            ;;
        *)
            print_error "Unknown command: $command"
            show_usage
            exit 1
            ;;
    esac
}

# Run main
main "$@"
