#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
#
# LLM Configuration Functions
# Shared functions for configuring LLM providers

# Global array to track configured providers
CONFIGURED_PROVIDERS=()

# Function: get_provider_metadata
# Maps user selection → provider details
# Returns provider_name, url_key, token_key, example_url
# -------------------------------------------------------------------
get_provider_metadata() {
    case "$1" in
        1)
            provider_name="anthropic"
            url_key="ANTHROPIC_API_URL"
            token_key="ANTHROPIC_API_TOKEN"
            example_url="https://api.anthropic.com"
            ;;
        2)
            provider_name="openai"
            url_key="OPENAI_API_URL"
            token_key="OPENAI_API_TOKEN"
            example_url="https://api.openai.com/v1"
            ;;
        3)
            provider_name="portkey"
            url_key="PORTKEY_API_URL"
            token_key="PORTKEY_API_TOKEN"
            model_key="PORTKEY_MODEL_NAME"
            example_url="https://api.portkey.ai/v1"
            ;;
        4)
            provider_name="vertex-ai"
            url_key=""
            token_key="VERTEX_SERVICE_ACCOUNT_KEY_JSON"
            example_url=""
            ;;
        5)
            provider_name="azure-ai"
            url_key="AZURE_AI_ENDPOINT"
            token_key="AZURE_AI_API_KEY"
            example_url="https://<your-resource>.openai.azure.com"
            ;;
        6)
            provider_name="novita"
            url_key=""
            token_key="NOVITA_API_TOKEN"
            example_url=""
            ;;
        7)
            provider_name="bedrock"
            url_key=""
            token_key="AWS_ACCESS_KEY_ID"
            example_url=""
            ;;
        *)
            return 1
            ;;
    esac
}

# Function: configure_llm
# Interactive LLM provider configuration
# -------------------------------------------------------------------
configure_llm() {

    CONFIGURED_PROVIDERS=()
    local continue_config="y"

    while [[ "$continue_config" =~ ^[Yy]$ ]]; do

        # Auto-stop if all providers are configured
        if [[ ${#CONFIGURED_PROVIDERS[@]} -eq 7 ]]; then
            echo -e "${GREEN}💡 All LLM providers have been configured.${NC}"
            break
        fi

        local provider_choice
        echo ""
        read -r -p "Configure LLM: 1) Anthropic 2) OpenAI 3) Portkey 4) Google Vertex AI 5) Azure AI 6) Novita 7) AWS Bedrock [1-7]: " provider_choice

        get_provider_metadata "$provider_choice" || {
            echo "✗ Invalid option. Please select 1–7."
            continue
        }

        # Skip duplicates
        if [[ " ${CONFIGURED_PROVIDERS[*]} " =~ " ${provider_name} " ]]; then
            echo -e "${YELLOW}⚠ $provider_name is already configured.${NC}"
        else
            echo -e "\n${BLUE}=== Configuring ${provider_name} ===${NC}\n"

            # Special handling for Portkey (requires model and optional URL)
            if [[ "$provider_name" == "portkey" ]]; then
                local url=""
                local default_url="https://api.portkey.ai/v1"
                while true; do
                    read -r -p "Enter Portkey API URL (press Enter to use default: $default_url): " url

                    # If user pressed Enter without input, set to empty
                    if [[ -z "$url" ]]; then
                        url=""
                        break
                    fi

                    # Remove trailing slash if present
                    url="${url%/}"

                    # If user entered the default value, set to empty
                    if [[ "$url" == "$default_url" ]]; then
                        url=""
                        break
                    fi

                    # Validate URL format (must start with http:// or https://)
                    if [[ "$url" =~ ^https?://[a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*(/.*)?$ ]]; then
                        break
                    else
                        echo -e "${RED}⚠ Invalid URL format. URL must start with http:// or https://${NC}"
                    fi
                done

                set_env_key_value "PORTKEY_API_URL" "$url" "$ENV_LLM_FILE"

                local model=""
                while [[ -z "$model" ]]; do
                    read -r -p "Enter Portkey model (format: @provider/model-name): " model

                    if [[ -z "$model" ]]; then
                        echo -e "${RED}⚠ Model name is required. Please enter a value.${NC}"
                    elif ! [[ "$model" =~ ^@[^/]+/[^/]+$ ]]; then
                        echo -e "${RED}⚠ Invalid model format. Expected: @provider/model-name (e.g. @slug/claude-haiku).${NC}"
                        model=""
                    fi
                done

                set_env_key_value "PORTKEY_MODEL_NAME" "$model" "$ENV_LLM_FILE"
            fi

            # Special handling for Vertex AI (service-account JSON file + project + region).
            # The SA JSON is base64-encoded before persisting so it fits in a single .env
            # line (set_env_key_value writes plain KEY=VALUE\n). Decoded later in
            # create_llm_integration_json before inlining into the cis-config PUT body.
            if [[ "$provider_name" == "vertex-ai" ]]; then
                local sa_path=""
                while true; do
                    read -r -p "Enter path to your GCP service-account JSON file: " sa_path
                    [[ -z "$sa_path" ]] && { echo "Path cannot be empty."; continue; }
                    [[ ! -f "$sa_path" ]] && { echo "File not found: $sa_path"; continue; }
                    if ! jq empty "$sa_path" >/dev/null 2>&1; then
                        echo "File is not valid JSON: $sa_path"
                        continue
                    fi
                    break
                done
                local sa_b64
                sa_b64=$(base64 < "$sa_path" | tr -d '\n')
                set_env_key_value "VERTEX_SERVICE_ACCOUNT_KEY_JSON" "$sa_b64" "$ENV_LLM_FILE"

                local project=""
                while [[ -z "$project" ]]; do
                    read -r -p "Enter GCP Project ID: " project
                    [[ -z "$project" ]] && echo "Project cannot be empty."
                done
                set_env_key_value "VERTEX_PROJECT" "$project" "$ENV_LLM_FILE"

                local region=""
                while [[ -z "$region" ]]; do
                    read -r -p "Enter GCP Region (e.g. us-central1): " region
                    [[ -z "$region" ]] && echo "Region cannot be empty."
                done
                set_env_key_value "VERTEX_REGION" "$region" "$ENV_LLM_FILE"
            fi

            # Special handling for Azure AI (endpoint; the primary AZURE_AI_API_KEY
            # is set via the generic token prompt below)
            if [[ "$provider_name" == "azure-ai" ]]; then
                local endpoint=""
                while [[ -z "$endpoint" ]]; do
                    read -r -p "Enter Azure AI endpoint (e.g. https://<resource>.openai.azure.com): " endpoint
                    if [[ -z "$endpoint" ]]; then
                        echo "Endpoint cannot be empty."
                    elif ! [[ "$endpoint" =~ ^https?:// ]]; then
                        echo "Endpoint must start with http:// or https://"
                        endpoint=""
                    fi
                done
                set_env_key_value "AZURE_AI_ENDPOINT" "$endpoint" "$ENV_LLM_FILE"
            fi

            # Special handling for AWS Bedrock (access key + secret + region).
            # All three fields are collected here; the generic token prompt below
            # is skipped. The access key ID is not a secret, so it is read in the
            # clear like the region.
            if [[ "$provider_name" == "bedrock" ]]; then
                local aws_access_key=""
                while [[ -z "$aws_access_key" ]]; do
                    read -r -p "Enter AWS Access Key ID: " aws_access_key
                    [[ -z "$aws_access_key" ]] && echo "Access Key ID cannot be empty."
                done
                set_env_key_value "AWS_ACCESS_KEY_ID" "$aws_access_key" "$ENV_LLM_FILE"

                local aws_secret=""
                while [[ -z "$aws_secret" ]]; do
                    read -s -r -p "Enter AWS Secret Access Key (input hidden): " aws_secret
                    stty echo; echo ""
                    [[ -z "$aws_secret" ]] && echo "Secret Access Key cannot be empty."
                done
                set_env_key_value "AWS_SECRET_ACCESS_KEY" "$aws_secret" "$ENV_LLM_FILE"

                local aws_region=""
                while [[ -z "$aws_region" ]]; do
                    read -r -p "Enter AWS Bedrock Region (e.g. us-east-1): " aws_region
                    [[ -z "$aws_region" ]] && echo "Region cannot be empty."
                done
                set_env_key_value "AWS_BEDROCK_REGION" "$aws_region" "$ENV_LLM_FILE"
            fi

            # Vertex AI's primary token (VERTEX_SERVICE_ACCOUNT_KEY_JSON) is set
            # above via the file-read path, not via the generic API-token prompt;
            # Bedrock collects all three AWS fields in its own block above.
            # Skip the generic prompt for both so it doesn't overwrite them.
            if [[ "$provider_name" != "vertex-ai" && "$provider_name" != "bedrock" ]]; then
                local token=""
                while [[ -z "$token" ]]; do
                    read -s -r -p "Enter ${provider_name} API token (input hidden): " token
                    stty echo; echo ""
                    [[ -z "$token" ]] && echo "Token cannot be empty."
                done

                set_env_key_value "${token_key}" "${token}" "$ENV_LLM_FILE"
            fi

            CONFIGURED_PROVIDERS+=("$provider_name")
            print_status " ${provider_name} configured successfully"
        fi

        # Ask whether to configure another provider only if some remain
        # Skip asking for more providers if Portkey is selected (it's a gateway)
        if [[ " ${CONFIGURED_PROVIDERS[*]} " =~ " portkey " ]]; then
            continue_config="n"
        elif [[ ${#CONFIGURED_PROVIDERS[@]} -lt 7 ]]; then
            read -r -p "Do you also want to add an API token for another LLM? (y/N): " continue_config
        else
            continue_config="n"
        fi
    done

    _restrict_llm_env_file
    return 0
}

# Function: _restrict_llm_env_file
# Restricts the LLM env file to the owner (0600). It holds provider API keys and
# the AWS secret access key, but set_env_key_value creates it at the default
# umask (typically 0644) and in-place rewrites keep an existing file's mode, so
# this is also what tightens a file left 0644 by an older install. No-op when
# the file does not exist; never fails the caller.
# -------------------------------------------------------------------
_restrict_llm_env_file() {
    if [ -f "$ENV_LLM_FILE" ]; then
        chmod 600 "$ENV_LLM_FILE" 2>/dev/null || true
    fi
}

# Function: reset_all_llm_keys
# Clears all LLM provider keys to ensure clean state
# -------------------------------------------------------------------
reset_all_llm_keys() {
    # Clear all LLM provider keys
    set_env_key_value "ANTHROPIC_API_URL" "" "$ENV_LLM_FILE"
    set_env_key_value "ANTHROPIC_API_TOKEN" "" "$ENV_LLM_FILE"
    set_env_key_value "OPENAI_API_URL" "" "$ENV_LLM_FILE"
    set_env_key_value "OPENAI_API_TOKEN" "" "$ENV_LLM_FILE"
    set_env_key_value "PORTKEY_API_URL" "" "$ENV_LLM_FILE"
    set_env_key_value "PORTKEY_API_TOKEN" "" "$ENV_LLM_FILE"
    set_env_key_value "PORTKEY_MODEL_NAME" "" "$ENV_LLM_FILE"
    # Vertex AI
    set_env_key_value "VERTEX_SERVICE_ACCOUNT_KEY_JSON" "" "$ENV_LLM_FILE"
    set_env_key_value "VERTEX_PROJECT" "" "$ENV_LLM_FILE"
    set_env_key_value "VERTEX_REGION" "" "$ENV_LLM_FILE"
    # Azure AI
    set_env_key_value "AZURE_AI_API_KEY" "" "$ENV_LLM_FILE"
    set_env_key_value "AZURE_AI_ENDPOINT" "" "$ENV_LLM_FILE"
    # Novita
    set_env_key_value "NOVITA_API_TOKEN" "" "$ENV_LLM_FILE"
    # AWS Bedrock
    set_env_key_value "AWS_ACCESS_KEY_ID" "" "$ENV_LLM_FILE"
    set_env_key_value "AWS_SECRET_ACCESS_KEY" "" "$ENV_LLM_FILE"
    set_env_key_value "AWS_BEDROCK_REGION" "" "$ENV_LLM_FILE"
    set_env_key_value "LLM_DEFAULT_PROVIDER" "" "$ENV_LLM_FILE"
}

# Returns 0 when any LLM token is pre-exported (yaml-driven install bypass).
_llm_tokens_preset() {
    [ -n "${ANTHROPIC_API_TOKEN:-}" ]              && return 0
    [ -n "${OPENAI_API_TOKEN:-}" ]                 && return 0
    [ -n "${PORTKEY_API_TOKEN:-}" ]                && return 0
    [ -n "${VERTEX_SERVICE_ACCOUNT_KEY_JSON:-}" ]  && return 0
    [ -n "${AZURE_AI_API_KEY:-}" ]                 && return 0
    [ -n "${NOVITA_API_TOKEN:-}" ]                 && return 0
    # Bedrock needs its full triple before the preset path may fire:
    # AWS_ACCESS_KEY_ID/AWS_SECRET_ACCESS_KEY are ambient on many hosts (AWS
    # CLI/SDK tooling) and alone must not bypass the interactive prompt.
    [ -n "${AWS_ACCESS_KEY_ID:-}" ] && [ -n "${AWS_SECRET_ACCESS_KEY:-}" ] && [ -n "${AWS_BEDROCK_REGION:-}" ] && return 0
    return 1
}

# Writes pre-exported LLM tokens to $ENV_LLM_FILE and populates
# CONFIGURED_PROVIDERS so LLM_DEFAULT_PROVIDER resolution still works.
# Clears all LLM keys first so stale values from a previous install do not
# linger if the new yaml defines a smaller provider set.
_llm_persist_preset_tokens() {
    CONFIGURED_PROVIDERS=()
    reset_all_llm_keys

    # Portkey is an exclusive gateway: when its token is preset it owns the
    # configuration and direct providers are ignored (mirrors the interactive
    # flow, which stops after Portkey).
    if [ -n "${PORTKEY_API_TOKEN:-}" ]; then
        set_env_key_value "PORTKEY_API_TOKEN" "${PORTKEY_API_TOKEN}" "$ENV_LLM_FILE"
        if [ -n "${PORTKEY_API_URL:-}" ]; then
            set_env_key_value "PORTKEY_API_URL" "${PORTKEY_API_URL}" "$ENV_LLM_FILE"
        fi
        if [ -n "${PORTKEY_MODEL_NAME:-}" ]; then
            set_env_key_value "PORTKEY_MODEL_NAME" "${PORTKEY_MODEL_NAME}" "$ENV_LLM_FILE"
        fi
        CONFIGURED_PROVIDERS+=("portkey")
        return 0
    fi

    if [ -n "${ANTHROPIC_API_TOKEN:-}" ]; then
        set_env_key_value "ANTHROPIC_API_TOKEN" "${ANTHROPIC_API_TOKEN}" "$ENV_LLM_FILE"
        CONFIGURED_PROVIDERS+=("anthropic")
    fi
    if [ -n "${OPENAI_API_TOKEN:-}" ]; then
        set_env_key_value "OPENAI_API_TOKEN" "${OPENAI_API_TOKEN}" "$ENV_LLM_FILE"
        CONFIGURED_PROVIDERS+=("openai")
    fi
    # vertex_service_account_key_json accepts a file PATH (enterprise parity) or
    # inline base64. _resolve_vertex_sa_value (install-yaml.sh) turns a readable
    # JSON file into base64, rejects a path-like value that doesn't resolve, and
    # passes inline base64 through unchanged. install-yaml.sh is always sourced
    # before this runs (it is what exported the preset tokens). Shared with the
    # restart --force reload lane so install and reload behave identically.
    if [ -n "${VERTEX_SERVICE_ACCOUNT_KEY_JSON:-}" ]; then
        if _resolve_vertex_sa_value "${VERTEX_SERVICE_ACCOUNT_KEY_JSON}"; then
            VERTEX_SERVICE_ACCOUNT_KEY_JSON="${_VERTEX_SA_RESOLVED}"
        else
            VERTEX_SERVICE_ACCOUNT_KEY_JSON=""
        fi
    fi
    # Vertex AI needs all three fields; a partial set would be marked "configured"
    # yet silently dropped from the cis-config PUT (create_llm_integration_json
    # emits it only when all three are present), so require the full set here.
    if [ -n "${VERTEX_SERVICE_ACCOUNT_KEY_JSON:-}" ]; then
        if [ -n "${VERTEX_PROJECT:-}" ] && [ -n "${VERTEX_REGION:-}" ]; then
            set_env_key_value "VERTEX_SERVICE_ACCOUNT_KEY_JSON" "${VERTEX_SERVICE_ACCOUNT_KEY_JSON}" "$ENV_LLM_FILE"
            set_env_key_value "VERTEX_PROJECT" "${VERTEX_PROJECT}" "$ENV_LLM_FILE"
            set_env_key_value "VERTEX_REGION" "${VERTEX_REGION}" "$ENV_LLM_FILE"
            CONFIGURED_PROVIDERS+=("vertex-ai")
        else
            print_warning "Vertex AI not configured: requires VERTEX_SERVICE_ACCOUNT_KEY_JSON, VERTEX_PROJECT and VERTEX_REGION"
        fi
    fi
    # Azure AI needs both api_key and endpoint (same PUT-emission rule as above).
    if [ -n "${AZURE_AI_API_KEY:-}" ]; then
        if [ -n "${AZURE_AI_ENDPOINT:-}" ]; then
            set_env_key_value "AZURE_AI_API_KEY" "${AZURE_AI_API_KEY}" "$ENV_LLM_FILE"
            set_env_key_value "AZURE_AI_ENDPOINT" "${AZURE_AI_ENDPOINT}" "$ENV_LLM_FILE"
            CONFIGURED_PROVIDERS+=("azure-ai")
        else
            print_warning "Azure AI not configured: requires both AZURE_AI_API_KEY and AZURE_AI_ENDPOINT"
        fi
    fi
    # Novita is a single-token provider (same persistence rule as anthropic/openai).
    if [ -n "${NOVITA_API_TOKEN:-}" ]; then
        set_env_key_value "NOVITA_API_TOKEN" "${NOVITA_API_TOKEN}" "$ENV_LLM_FILE"
        CONFIGURED_PROVIDERS+=("novita")
    fi
    # AWS Bedrock needs all three fields; a partial set would be marked
    # "configured" yet silently dropped from the cis-config PUT, so require
    # the full set here.
    if [ -n "${AWS_ACCESS_KEY_ID:-}" ]; then
        if [ -n "${AWS_SECRET_ACCESS_KEY:-}" ] && [ -n "${AWS_BEDROCK_REGION:-}" ]; then
            set_env_key_value "AWS_ACCESS_KEY_ID" "${AWS_ACCESS_KEY_ID}" "$ENV_LLM_FILE"
            set_env_key_value "AWS_SECRET_ACCESS_KEY" "${AWS_SECRET_ACCESS_KEY}" "$ENV_LLM_FILE"
            set_env_key_value "AWS_BEDROCK_REGION" "${AWS_BEDROCK_REGION}" "$ENV_LLM_FILE"
            CONFIGURED_PROVIDERS+=("bedrock")
        else
            print_warning "AWS Bedrock not configured: requires AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY and AWS_BEDROCK_REGION"
        fi
    fi

    _restrict_llm_env_file
}

# Function: configure_llm_provider
# Main entry point for LLM provider configuration
# Pass "force_interactive" to bypass preset-token detection (e.g. when called
# from `bitoarch update-llm-config` where load_env_config has already exported
# the existing tokens into the caller's shell).
# -------------------------------------------------------------------
configure_llm_provider() {
    local mode="${1:-}"

    if [ "$mode" = "force_interactive" ]; then
        reset_all_llm_keys
        configure_llm
    elif _llm_tokens_preset; then
        # Yaml-driven install: persist pre-exported tokens, skip prompt.
        _llm_persist_preset_tokens
    else
        reset_all_llm_keys
        configure_llm
    fi

    # Build final selection list (configured providers + bito)
    local options=("${CONFIGURED_PROVIDERS[@]}" "bito")
    local prefer_order=("portkey" "openai" "anthropic" "vertex-ai" "azure-ai" "bedrock" "novita" "bito")

    selected_provider=""

    for preferred in "${prefer_order[@]}"; do
        for p in "${options[@]}"; do
            if [[ "$p" == "$preferred" ]]; then
                selected_provider="$preferred"
                break 2
            fi
        done
    done
    set_env_key_value "LLM_DEFAULT_PROVIDER" "${selected_provider}" "$ENV_LLM_FILE"

    # Send LLM provider tracking event (suppress output to prevent HTTP status leakage)
    if [[ ${#CONFIGURED_PROVIDERS[@]} -gt 0 ]]; then
        local providers_csv=$(IFS=,; echo "${CONFIGURED_PROVIDERS[*]}")
        send_llm_provider_tracking "$providers_csv" >/dev/null 2>&1
    fi

    # Guarantee the secrets file is owner-only after the final write above, so
    # the postcondition holds at the entry point regardless of how the sub-paths
    # or set_env_key_value touch the mode.
    _restrict_llm_env_file
}

# Export functions
export -f _llm_tokens_preset
export -f _restrict_llm_env_file
export -f _llm_persist_preset_tokens
export -f get_provider_metadata
export -f configure_llm
export -f reset_all_llm_keys
export -f configure_llm_provider
