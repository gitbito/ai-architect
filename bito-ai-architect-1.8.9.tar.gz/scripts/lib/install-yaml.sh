#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
#
# scripts/lib/install-yaml.sh
# YAML <-> env translation for $HOME/.bitoarch/install.yaml.
# Parsers: yq (preserves comments on writeback) or python3+PyYAML (read-only).
# Mapping: _install_yaml_mapping_pairs — single source of truth for yaml <-> env.

if [ -n "${_BITOARCH_INSTALL_YAML_LOADED:-}" ]; then
    return 0
fi
_BITOARCH_INSTALL_YAML_LOADED=1

if [ -z "${SCRIPT_DIR:-}" ]; then
    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
fi

# Defensive sourcing so callers that bypass install.sh orchestration
# (restart --force, setup.sh --force-restart) still have print_* / log_silent
# / get_install_yaml_file. Load guards make this a no-op when already sourced.
if [ -f "${SCRIPT_DIR}/scripts/lib/path-manager.sh" ]; then
    # shellcheck disable=SC1091
    source "${SCRIPT_DIR}/scripts/lib/path-manager.sh"
fi
if [ -f "${SCRIPT_DIR}/scripts/lib/cli-core.sh" ]; then
    # shellcheck disable=SC1091
    source "${SCRIPT_DIR}/scripts/lib/cli-core.sh"
fi
if [ -f "${SCRIPT_DIR}/scripts/setup-utils.sh" ]; then
    # shellcheck disable=SC1091
    source "${SCRIPT_DIR}/scripts/setup-utils.sh"
fi

# Pre-fill setup.sh env from yaml. Silent when yaml absent; exits on parse failure.
_install_apply_yaml_if_present() {
    local yaml="$1"
    if [ ! -f "$yaml" ]; then
        log_silent "No install yaml at $yaml; prompts will run interactively"
        return 0
    fi

    local exports
    exports=$(_install_yaml_to_env "$yaml") || {
        if command -v print_error >/dev/null 2>&1; then
            print_error "Failed to parse ${yaml}"
        else
            echo "ERROR: Failed to parse ${yaml}" >&2
        fi
        exit 1
    }

    if [ -n "$exports" ]; then
        # shellcheck disable=SC1090
        eval "$exports"
        log_silent "Loaded install values from ${yaml}"
    fi
}

# yaml_path <-> env_key pairs, one per line.
_install_yaml_mapping_pairs() {
    cat <<'EOF'
.bito_api_key              BITO_API_KEY
.user_email                MCP_USER_EMAIL
.git.provider              GIT_PROVIDER
.git.access_token          GIT_ACCESS_TOKEN
.git.domain_url            GIT_DOMAIN_URL
.git.user                  GIT_USER
.git.organization          GIT_AZURE_ORG
.llm.anthropic_api_token               ANTHROPIC_API_TOKEN
.llm.openai_api_token                  OPENAI_API_TOKEN
.llm.portkey_api_token                 PORTKEY_API_TOKEN
.llm.portkey_api_url                   PORTKEY_API_URL
.llm.portkey_model_name                PORTKEY_MODEL_NAME
.llm.vertex_service_account_key_json   VERTEX_SERVICE_ACCOUNT_KEY_JSON
.llm.vertex_project                    VERTEX_PROJECT
.llm.vertex_region                     VERTEX_REGION
.llm.azure_ai_api_key                  AZURE_AI_API_KEY
.llm.azure_ai_endpoint                 AZURE_AI_ENDPOINT
.llm.novita_api_token                  NOVITA_API_TOKEN
.llm.aws_access_key_id                 AWS_ACCESS_KEY_ID
.llm.aws_secret_access_key             AWS_SECRET_ACCESS_KEY
.llm.aws_bedrock_region                AWS_BEDROCK_REGION
.resources.mysql_memory    MYSQL_MEMORY_LIMIT
.resources.mysql_cpu       MYSQL_CPU_LIMIT
.resources.cis_manager_cpu CIS_MANAGER_CPU_LIMIT
.ports.cis_provider        CIS_PROVIDER_EXTERNAL_PORT
.ports.cis_manager         CIS_MANAGER_EXTERNAL_PORT
.ports.cis_config          CIS_CONFIG_EXTERNAL_PORT
.ports.mysql               MYSQL_EXTERNAL_PORT
.ports.cis_tracker         CIS_TRACKER_EXTERNAL_PORT
.insights.git                          INSIGHTS_GIT_ENABLED
.insights.ticket_tracker.enabled       INSIGHTS_TICKET_TRACKER_ENABLED
.insights.ticket_tracker.provider      INSIGHTS_TICKET_TRACKER_PROVIDER
.insights.ticket_tracker.base_url      INSIGHTS_TICKET_TRACKER_BASE_URL
.insights.ticket_tracker.email         INSIGHTS_TICKET_TRACKER_EMAIL
.insights.ticket_tracker.api_token     INSIGHTS_TICKET_TRACKER_API_TOKEN
.insights.ticket_tracker.host_type     INSIGHTS_TICKET_TRACKER_HOST_TYPE
.insights.ticket_tracker.auth_type     INSIGHTS_TICKET_TRACKER_AUTH_TYPE
.insights.docs.enabled                 INSIGHTS_DOCS_ENABLED
.insights.docs.provider                INSIGHTS_DOCS_PROVIDER
.insights.docs.url                     INSIGHTS_DOCS_URL
.insights.docs.email                   INSIGHTS_DOCS_EMAIL
.insights.docs.api_token               INSIGHTS_DOCS_API_TOKEN
.insights.docs.auth_type               INSIGHTS_DOCS_AUTH_TYPE
.insights.ticket_tracker.project_keys  INSIGHTS_TICKET_TRACKER_PROJECT_KEYS
.insights.git_lookback_days            INSIGHTS_GIT_LOOKBACK_DAYS
.insights.jira_lookback_days           INSIGHTS_JIRA_LOOKBACK_DAYS
EOF
}

# Read yaml value at <path>. Prefers yq, falls back to python3. Empty on miss.
_install_yaml_read_value() {
    local yaml="$1" path="$2"
    if command -v yq >/dev/null 2>&1; then
        yq eval "$path" "$yaml" 2>/dev/null
    elif command -v python3 >/dev/null 2>&1; then
        python3 -c "
import yaml
with open('$yaml') as f: data = yaml.safe_load(f) or {}
cur = data
for k in '$path'.lstrip('.').split('.'):
    if isinstance(cur, dict) and k in cur: cur = cur[k]
    else: cur = None; break
print(cur if cur is not None else '')
" 2>/dev/null
    fi
}

# YAML -> `export KEY='value'` lines. Returns 1 if no parser available.
_install_yaml_to_env() {
    local yaml="$1"
    if ! command -v yq >/dev/null 2>&1 && ! command -v python3 >/dev/null 2>&1; then
        print_error "Neither yq nor python3 available; cannot parse YAML"
        return 1
    fi

    while IFS= read -r line || [ -n "$line" ]; do
        [ -z "$line" ] && continue
        case "$line" in \#*) continue ;; esac
        local path envkey value
        path=$(echo "$line" | awk '{print $1}')
        envkey=$(echo "$line" | awk '{print $2}')
        [ -z "$envkey" ] && continue
        value=$(_install_yaml_read_value "$yaml" "$path")
        if [ -n "$value" ] && [ "$value" != "null" ] && [ "$value" != "~" ]; then
            local escaped=${value//\'/\'\\\'\'}
            echo "export ${envkey}='${escaped}'"
        fi
    done < <(_install_yaml_mapping_pairs)
}

# Validate yaml's bito_api_key against tracking endpoint when it differs from env.
# Strict: unreachable endpoint returns 1 (user explicitly changed credentials).
validate_install_yaml_api_key() {
    local env_file="$1"
    local yaml
    yaml=$(get_install_yaml_file)
    [ -f "$yaml" ] || return 0
    [ -f "$env_file" ] || return 0

    local yaml_key cur_key
    yaml_key=$(_install_yaml_read_value "$yaml" '.bito_api_key')
    case "$yaml_key" in ''|null|~) return 0 ;; esac

    cur_key=$(grep -E '^BITO_API_KEY=' "$env_file" 2>/dev/null \
        | cut -d= -f2- | head -1 | tr -d '"' | tr -d "'")

    [ "$yaml_key" = "$cur_key" ] && return 0

    # Resolve deps relative to this file so restart --force works without install.sh orchestration.
    local lib_root scripts_root
    lib_root="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    scripts_root="$(cd "$lib_root/.." && pwd)"
    if ! command -v validate_and_print_bito_api_key_status >/dev/null 2>&1 \
       && [ -f "$scripts_root/setup-utils.sh" ]; then
        source "$scripts_root/setup-utils.sh" 2>/dev/null || true
    fi
    if ! command -v call_tracking_endpoint_event >/dev/null 2>&1 \
       && [ -f "$lib_root/adapters/tracker-adapter.sh" ]; then
        source "$lib_root/adapters/tracker-adapter.sh" 2>/dev/null || true
    fi
    if ! command -v validate_and_print_bito_api_key_status >/dev/null 2>&1; then
        return 0
    fi

    local tracking_url
    tracking_url=$(grep -E '^TRACKING_SERVICE_BASE_URL=' "$env_file" 2>/dev/null \
        | cut -d= -f2- | head -1 | tr -d '"' | tr -d "'")
    if [ -z "$tracking_url" ]; then
        print_error "Cannot validate new API key: TRACKING_SERVICE_BASE_URL not set in env file"
        return 1
    fi

    echo ""
    print_info "New Bito API Key detected in ~/.bitoarch/install.yaml -- validating..."
    if validate_and_print_bito_api_key_status "$yaml_key" "architect_api_key_update" \
            "$tracking_url" "New API key validated" "true"; then
        return 0
    fi
    echo ""
    print_error "Aborting: new API key failed validation. Existing deployment left running."
    print_info "Edit ${YELLOW}~/.bitoarch/install.yaml${NC} and re-run ${YELLOW}bitoarch restart --force${NC}."
    return 1
}

# Resolve a Vertex service-account key field value into the form persisted to
# the LLM env file. Sets _VERTEX_SA_RESOLVED and returns:
#   - readable JSON file path  -> base64 of its contents          (return 0)
#   - inline base64 / non-path -> the value unchanged             (return 0)
#   - path-like value that is not a readable JSON file -> "" + warn (return 1)
# A leading ~ is expanded to $HOME. Shared by the install preset lane
# (_llm_persist_preset_tokens) and the restart --force reload lane
# (apply_install_yaml_to_env_file) so both behave identically.
_resolve_vertex_sa_value() {
    local raw="$1"
    _VERTEX_SA_RESOLVED=""
    [ -z "$raw" ] && return 1
    local f="${raw/#\~/$HOME}"
    if [ -f "$f" ]; then
        if jq empty "$f" >/dev/null 2>&1; then
            _VERTEX_SA_RESOLVED="$(base64 < "$f" | tr -d '\n')"
            return 0
        fi
        print_warning "Vertex AI not configured: file is not valid JSON: ${f}"
        return 1
    fi
    # A value that looks like a path but isn't a readable file is a mistake
    # (typo, unmounted volume); reject it rather than persist it verbatim.
    case "$raw" in
        /*|'~/'*|'./'*|'../'*)
            print_warning "Vertex AI not configured: service-account file not found: ${f}"
            return 1
            ;;
    esac
    _VERTEX_SA_RESOLVED="$raw"
    return 0
}

# Reload mapped KEY=VALUE lines from yaml into their target env file (restart
# --force). Routing: .llm.* keys are written to the separate LLM env file
# (.env-llm-bitoarch) -- never the main env file, where they don't belong and
# break downstream parsing; all other keys go to the main env_file. Existing
# keys are replaced in place; a key not yet present is appended on its own
# line (newline-safe). No-op if yaml/env absent or no parser.
apply_install_yaml_to_env_file() {
    local env_file="$1"
    local yaml llm_file
    yaml=$(get_install_yaml_file)
    [ -f "$yaml" ] || return 0
    [ -f "$env_file" ] || return 0
    if ! command -v yq >/dev/null 2>&1 && ! command -v python3 >/dev/null 2>&1; then
        return 0
    fi
    # LLM credentials live in a sibling file (co-located by design; mirrors
    # get_llm_config_file). Deriving it from env_file keeps both writes in the
    # same config dir without depending on global path state.
    llm_file="$(dirname "$env_file")/.env-llm-bitoarch"

    local tmp_main tmp_llm
    tmp_main=$(mktemp) || return 1
    cp "$env_file" "$tmp_main" || { rm -f "$tmp_main"; return 1; }
    tmp_llm=$(mktemp) || { rm -f "$tmp_main"; return 1; }
    [ -f "$llm_file" ] && { cp "$llm_file" "$tmp_llm" || { rm -f "$tmp_main" "$tmp_llm"; return 1; }; }

    local updated_main=0 updated_llm=0
    while IFS= read -r line || [ -n "$line" ]; do
        [ -z "$line" ] && continue
        case "$line" in \#*) continue ;; esac
        local path envkey value target
        path=$(echo "$line" | awk '{print $1}')
        envkey=$(echo "$line" | awk '{print $2}')
        [ -z "$envkey" ] && continue
        value=$(_install_yaml_read_value "$yaml" "$path")
        if [ -z "$value" ] || [ "$value" = "null" ] || [ "$value" = "~" ]; then
            continue
        fi
        # Newlines would break the single-line sed substitution; reject and log.
        case "$value" in
            *$'\n'*|*$'\r'*)
                log_silent "install-yaml: rejecting ${path}: value contains newline"
                continue
                ;;
        esac
        # vertex_service_account_key_json may carry a file path; resolve it to
        # base64 here too so restart --force matches the install lane. A path
        # that doesn't resolve is rejected (skip) rather than persisted raw.
        if [ "$path" = ".llm.vertex_service_account_key_json" ]; then
            if _resolve_vertex_sa_value "$value"; then
                value="$_VERTEX_SA_RESOLVED"
            else
                continue
            fi
        fi
        # Route .llm.* secrets to the LLM env file; everything else to main.
        case "$path" in
            .llm.*) target="$tmp_llm" ;;
            *)      target="$tmp_main" ;;
        esac
        # Escape for sed replacement: backslash, slash, ampersand.
        local esc=${value//\\/\\\\}
        esc=${esc//\//\\\/}
        esc=${esc//&/\\&}
        if grep -q "^${envkey}=" "$target" 2>/dev/null; then
            sed -i.bak "s/^${envkey}=.*/${envkey}=${esc}/" "$target" && rm -f "${target}.bak"
        else
            # Append on its own line: ensure the file ends with a newline first
            # so the new key can't be concatenated onto the previous last line.
            if [ -s "$target" ] && [ -n "$(tail -c1 "$target")" ]; then
                printf '\n' >> "$target"
            fi
            echo "${envkey}=${value}" >> "$target"
        fi
        if [ "$target" = "$tmp_llm" ]; then updated_llm=1; else updated_main=1; fi
    done < <(_install_yaml_mapping_pairs)

    if [ "$updated_main" -eq 1 ]; then
        mv "$tmp_main" "$env_file"
    else
        rm -f "$tmp_main"
    fi
    if [ "$updated_llm" -eq 1 ]; then
        mv "$tmp_llm" "$llm_file" && chmod 600 "$llm_file" 2>/dev/null
    else
        rm -f "$tmp_llm"
    fi
    return 0
}

# Seed home yaml from template at repo root (idempotent).
_install_ensure_yaml_exists() {
    local yaml="$1"
    [ -f "$yaml" ] && return 0
    # Prefer $SCRIPT_DIR from caller; else climb two levels from this file.
    local template
    if [ -n "${SCRIPT_DIR:-}" ] && [ -f "${SCRIPT_DIR}/install.yaml.default" ]; then
        template="${SCRIPT_DIR}/install.yaml.default"
    else
        template="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)/install.yaml.default"
    fi
    if [ ! -f "$template" ]; then
        log_silent "Install yaml template missing at $template; skipping seed"
        return 0
    fi
    local dir
    dir=$(dirname "$yaml")
    mkdir -p "$dir" 2>/dev/null || return 1
    cp "$template" "$yaml" 2>/dev/null && \
        log_silent "Seeded install yaml at $yaml from template"
}

# Writeback env values to home yaml. yq-only (preserves comments); silent if yq absent.
_install_persist_yaml_from_env() {
    local yaml="$1"
    [ -f "$yaml" ] || return 0
    if ! command -v yq >/dev/null 2>&1; then
        log_silent "yq not available; skipping yaml writeback"
        return 0
    fi
    while IFS= read -r line || [ -n "$line" ]; do
        [ -z "$line" ] && continue
        case "$line" in \#*) continue ;; esac
        local path envkey value
        path=$(echo "$line" | awk '{print $1}')
        envkey=$(echo "$line" | awk '{print $2}')
        [ -z "$envkey" ] && continue
        value="${!envkey:-}"
        [ -z "$value" ] && continue
        local esc=${value//\"/\\\"}
        yq eval -i "$path = \"$esc\"" "$yaml" 2>/dev/null || true
    done < <(_install_yaml_mapping_pairs)
    log_silent "Persisted install values to $yaml"
}
