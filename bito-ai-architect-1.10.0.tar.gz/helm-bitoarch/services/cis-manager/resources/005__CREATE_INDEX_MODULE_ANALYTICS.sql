-- Per-run analytics for index modules (repo-level-info is the first producer).
-- Common + LLM columns are shared across modules; module-specific numbers ride
-- in the `metrics` JSON payload so new modules never change the envelope.
-- Append-only: one row per run (no unique key), so run history is preserved.
--
-- Standalone deploy copy of the cis-manager migration, applied by
-- sql-migration-manager.sh under the "manager" service. (Source copy lives
-- in cis-manager/resources/sql/005_.)

CREATE TABLE IF NOT EXISTS index_module_analytics (
    -- common layer
    id             BIGINT       NOT NULL AUTO_INCREMENT,
    workspace_id   BIGINT       NOT NULL,
    module         VARCHAR(64)  NOT NULL COMMENT 'repo_level_info | edges_extraction | basic_index | git_insights | jira_insights | ...',
    entity_type    VARCHAR(32)  NOT NULL COMMENT 'git_repo | jira_project | workspace | cluster',
    entity_key     VARCHAR(512) NOT NULL COMMENT 'repo namespace, jira project key, or workspace scope',
    session_id     VARCHAR(64)  NOT NULL,
    run_mode       VARCHAR(32)  NULL COMMENT 'basic | incremental | full',
    status         VARCHAR(32)  NOT NULL DEFAULT 'success' COMMENT 'success | failed | partial',
    commit_id      VARCHAR(64)  NULL,
    started_at     TIMESTAMP    NULL,
    finished_at    TIMESTAMP    NULL,
    duration_ms    BIGINT       NULL,
    created_at     TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    -- llm layer (0/NULL for non-LLM modules)
    llm_provider   VARCHAR(64)  NULL,
    llm_model      VARCHAR(128) NULL,
    llm_calls      INT          NOT NULL DEFAULT 0,
    tokens_input   BIGINT       NOT NULL DEFAULT 0,
    tokens_output  BIGINT       NOT NULL DEFAULT 0,
    tool_calls     INT          NOT NULL DEFAULT 0,
    sub_agents     INT          NOT NULL DEFAULT 0,
    cost_usd       DECIMAL(10,4) NULL,
    -- module-owned shape + artifacts
    metrics        JSON         NULL COMMENT 'module-specific metrics; repo_level_info: {files_total, files_explored, dirs_total, dirs_explored, hit_ratio, dir_hit_ratio, ...}',
    artifact_path  TEXT         NULL COMMENT 'e.g. wingman session-log path',
    PRIMARY KEY (id),
    INDEX idx_ima_ws_module_created (workspace_id, module, created_at),
    INDEX idx_ima_session (session_id),
    INDEX idx_ima_entity (workspace_id, entity_type, entity_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
