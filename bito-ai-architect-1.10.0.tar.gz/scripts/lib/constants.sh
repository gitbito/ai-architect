#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
# Bito's AI Architect - Static URLs and Constants
# Centralized location for all documentation links and static resources

# Prevent multiple sourcing
if [ -n "${_BITOARCH_CONSTANTS_LOADED:-}" ]; then
    return 0
fi
_BITOARCH_CONSTANTS_LOADED=1

# Documentation URLs
export BITO_API_KEY_URL="https://alpha.bito.ai/home/advanced"
export BITO_WORKSPACE_ID_URL="https://alpha.bito.ai/home/advance-settings"
export GIT_TOKEN_DOCS_URL="https://docs.bito.ai/ai-architect/install-ai-architect-self-hosted#git-provider"
export MCP_SETUP_DOCS_URL="https://docs.bito.ai/ai-architect/install-ai-architect-self-hosted#setting-up-ai-architect-mcp-in-coding-agents"
export BITO_STANDALONE_MCP_DOCS_URL="https://docs.bito.ai/ai-architect/standalone-mcp-coding-agents"
export AI_ARCHITECT_DOCS_URL="https://docs.bito.ai/ai-architect/install-ai-architect-self-hosted"
# Canonical landing page for all AI Architect docs (index of sub-pages).
# Prefer this over deep-links in user-facing CLI output so readers can
# navigate to the latest-indexed version of any page.
export AI_ARCHITECT_DOCS_HOME_URL="https://docs.bito.ai/ai-architect"
# Plugin framework docs. PLACEHOLDER — repoint when the plugins page is published.
export PLUGINS_DOCS_URL="https://docs.bito.ai/ai-architect/plugins"
export ATLASSIAN_API_TOKEN_URL="https://id.atlassian.com/manage-profile/security/api-tokens"

# bitointtools/BitoMCPinstall CDN base. Override via env (e.g. for prod or
# air-gapped mirrors). install/uninstall URLs are built from this base.
export MCP_INSTALLER_BASE_URL="${MCP_INSTALLER_BASE_URL:-https://mcp-setup.bito.ai}"

export MCP_CALLER_PLATFORM="${MCP_CALLER_PLATFORM:-BITOARCH_CLI}"

# Product Branding
export PRODUCT_NAME="Bito's AI Architect"
export PRODUCT_SHORT_NAME="AI Architect"

# Service Display Names (human-readable, for UI output)
export SERVICE_CONFIG_DISPLAY="AI Architect Config"
export SERVICE_MANAGER_DISPLAY="AI Architect Manager"
export SERVICE_PROVIDER_DISPLAY="AI Architect Provider"
export SERVICE_TRACKER_DISPLAY="AI Architect Tracker"
export SERVICE_MYSQL_DISPLAY="MySQL Database"

# Service Container Names (Docker Compose service identifiers -- also the
# Kubernetes deployment names). New code referencing a service by literal
# name should use these constants. NOTE: the codebase has many legacy
# literal references; do not mass-rewrite without a separate validation
# pass (container names appear in helm chart YAML, kubectl selectors,
# docker ps queries, etc.).
export SERVICE_MYSQL_NAME="ai-architect-mysql"
export SERVICE_CONFIG_NAME="ai-architect-config"
export SERVICE_MANAGER_NAME="ai-architect-manager"
export SERVICE_PROVIDER_NAME="ai-architect-provider"
export SERVICE_TRACKER_NAME="ai-architect-tracker"
export SERVICE_TEMPORAL_NAME="ai-architect-temporal"
export SERVICE_WORKER_NAME="ai-architect-worker"
export SERVICE_INGRESS_NAME="ai-architect-ingress"

# Service Lists
# -------------
# Two distinct lists, intentionally separate -- they answer different
# questions and must NOT be merged.
#
# BITOARCH_USER_SERVICES: the user-facing display/health enumeration list.
#   Used for status UI, "N of M failed" counts, and the running-state
#   verification in lifecycle success/failure banners. Background and
#   infrastructure services (tracker, temporal, worker) are intentionally
#   excluded so they don't appear in user-facing failure enumeration.
#
# BITOARCH_LIFECYCLE_SERVICES: the operand list for compose lifecycle
#   commands (pull / up -d / stop / force-recreate) and K8s rollout
#   iteration. Includes ALL services that lifecycle ops must touch --
#   add a service here to make `bitoarch restart`, `bitoarch update`,
#   etc. operate on it. Order matches setup.sh's lists for parity.
BITOARCH_USER_SERVICES=(
    "$SERVICE_MYSQL_NAME"
    "$SERVICE_CONFIG_NAME"
    "$SERVICE_MANAGER_NAME"
    "$SERVICE_PROVIDER_NAME"
    "$SERVICE_WORKER_NAME"
)
export BITOARCH_USER_SERVICES

BITOARCH_LIFECYCLE_SERVICES=(
    "$SERVICE_MYSQL_NAME"
    "$SERVICE_TEMPORAL_NAME"
    "$SERVICE_CONFIG_NAME"
    "$SERVICE_TRACKER_NAME"
    "$SERVICE_MANAGER_NAME"
    "$SERVICE_WORKER_NAME"
    "$SERVICE_PROVIDER_NAME"
    "$SERVICE_INGRESS_NAME"
)
export BITOARCH_LIFECYCLE_SERVICES

# Count of user-facing services (used by output-blocks for "N of M failed").
bitoarch_user_service_count() {
    echo "${#BITOARCH_USER_SERVICES[@]}"
}
export -f bitoarch_user_service_count

