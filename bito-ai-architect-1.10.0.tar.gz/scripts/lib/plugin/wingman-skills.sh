#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
#
# Shared Wingman skills + promote orchestrator (ref-counted on the shelf).

if [ -n "${_BITOARCH_PLUGIN_WINGMAN_SKILLS_LOADED:-}" ]; then
    return 0
fi
_BITOARCH_PLUGIN_WINGMAN_SKILLS_LOADED=1

_BITOARCH_PLUGIN_WMS_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if ! type get_wingman_skills_dir >/dev/null 2>&1; then
    # shellcheck source=scripts/lib/path-manager.sh
    . "${_BITOARCH_PLUGIN_WMS_DIR}/../path-manager.sh" 2>/dev/null || true
fi
if ! type journal_skill_incref >/dev/null 2>&1; then
    # shellcheck source=scripts/lib/plugin/state-journal.sh
    . "${_BITOARCH_PLUGIN_WMS_DIR}/state-journal.sh" 2>/dev/null || true
fi
if ! type manifest_wingman_skills >/dev/null 2>&1; then
    # shellcheck source=scripts/lib/plugin/manifest-parser.sh
    . "${_BITOARCH_PLUGIN_WMS_DIR}/manifest-parser.sh" 2>/dev/null || true
fi
if ! type _wingman_fs_apply >/dev/null 2>&1; then
    # shellcheck source=scripts/lib/wingman-shelf.sh
    . "${_BITOARCH_PLUGIN_WMS_DIR}/../wingman-shelf.sh" 2>/dev/null || true
fi

_wms_err() { if type print_error >/dev/null 2>&1; then print_error "$1" >&2; else printf 'ERROR: %s\n' "$1" >&2; fi; type log_silent >/dev/null 2>&1 && log_silent "wingman skills: $1"; }
_wms_log() { type log_silent >/dev/null 2>&1 && log_silent "wingman skills: $1"; }

# Stage under a temp sibling, then rename over any existing dir (atomic swap).
# Runs in-container via _wingman_fs_apply (the skills shelf is on the data volume
# / PVC the host cannot write directly); $SRC is the skill source dir, read-only.
# 0 when <dir> exists on the shelf (checked in-container: host cannot see the volume).
_wingman_shelf_has() { _wingman_fs_apply "" "[ -d '$1' ]" >/dev/null 2>&1; }

_wms_copy_skill() {
    local src="$1" dest="$2" tmp script
    tmp="${dest}.promote.$$"
    script="$(cat <<EOSH
set -e
rm -rf "${tmp}"
mkdir -p "$(dirname "${dest}")"
cp -R "\$SRC" "${tmp}"
rm -rf "${dest}"
mv "${tmp}" "${dest}"
EOSH
)"
    if ! _wingman_fs_apply "$src" "$script"; then
        _wms_err "failed promoting the skill dir"; return 1
    fi
    return 0
}

# Copy into the shelf if absent or newer (highest-wins), then incref.
wingman_skill_promote() {
    local staged="$1" plugin="$2" name="$3" version="$4" rel="$5"
    local src shelf dest cur cmp
    src="${staged}/${rel}"
    if [ ! -d "$src" ]; then
        _wms_err "skill '${name}' directory not found in package: ${rel}"
        return 1
    fi
    shelf="$(get_wingman_skills_dir)"
    dest="${shelf}/${name}"

    if journal_skill_exists "$name"; then
        cur="$(journal_skill_field "$name" version)"
        if [ -n "$cur" ] && [ -n "$version" ] && [ "$(_semver_cmp "$version" "$cur")" -gt 0 ] 2>/dev/null; then
            _wms_copy_skill "$src" "$dest" || return 1
            journal_skill_set_version "$name" "$version"
            _wms_log "skill '${name}' upgraded on the shelf ${cur} -> ${version}"
        elif ! _wingman_shelf_has "$dest"; then
            # Recorded but the bits are missing (e.g. shelf relocation): restore.
            _wms_copy_skill "$src" "$dest" || return 1
            [ -n "$version" ] && journal_skill_set_version "$name" "$version"
            _wms_log "skill '${name}' restored to the shelf"
        else
            _wms_log "skill '${name}' present at ${cur:-?} (>= ${version:-?}); reusing"
        fi
    else
        _wms_copy_skill "$src" "$dest" || return 1
        journal_skill_put "$name" "$(jq -n --arg v "$version" '{version:$v}')"
        _wms_log "skill '${name}' ${version} promoted to the shared shelf"
    fi
    journal_skill_incref "$name" "$plugin"
}

# Refresh the shared shelf from the CDN, then enforce requires.wingman against the
# resulting shelf version (fail-closed) and promote the plugin's carried skills.
wingman_resolve() {
    local staged="$1" manifest="$2" plugin="$3" name version dir constraint eff
    # Populate the shelf (binary + tools + base skills) synchronously so the gate below sees the result.
    type wingman_shelf_populate >/dev/null 2>&1 && wingman_shelf_populate wait
    constraint="$(manifest_wingman_constraint "$manifest")"
    if [ -n "$constraint" ]; then
        eff="$(wingman_shelf_current_version 2>/dev/null)"
        if [ -z "$eff" ]; then
            _wms_err "plugin requires Wingman ${constraint}, but no shared Wingman is on the shelf yet. Ensure the platform can reach the Wingman CDN."
            return 1
        fi
        if ! plugin_version_satisfies "$eff" "$constraint"; then
            _wms_err "plugin requires Wingman ${constraint}, but the shared Wingman is ${eff}; the platform could not update it to a matching version."
            return 1
        fi
    fi
    while IFS='|' read -r name version dir; do
        [ -z "$name" ] && continue
        wingman_skill_promote "$staged" "$plugin" "$name" "$version" "$dir" || return 1
    done <<EOF
$(manifest_wingman_skills "$manifest")
EOF
    return 0
}

# Engine-owned Wingman paths: force-set on install/upgrade so a shelf relocation propagates.
plugin_inject_wingman_env() {   # <env_file>
    local shelf
    shelf="$(get_wingman_shared_dir 2>/dev/null)"
    { [ -z "$1" ] || [ -z "$shelf" ]; } && return 0
    type plugin_env_set >/dev/null 2>&1 || return 0
    plugin_env_set "$1" WINGMAN_SHARED_DIR "$shelf"
    plugin_env_set "$1" WINGMAN_HOME "$shelf"
    plugin_env_set "$1" WINGMAN_CLI_PATH "${shelf}/current/${WINGMAN_BINARY_NAME:-bito-wingman}"
    plugin_env_set "$1" WINGMAN_TOOLS_DIR "${shelf}/current/tools"
    plugin_env_set "$1" WINGMAN_SKILLS_DIR "$(get_wingman_skills_dir 2>/dev/null)"
    # Plugins never fetch their own binary -- the base populate owns the shelf. Force-set
    # false so it holds on k8s too, where the pod env comes only from the plugin values
    # (the base .env-bitoarch default is not merged on the helm path).
    plugin_env_set "$1" WINGMAN_AUTO_UPDATE "false"
    return 0
}

# Drop <plugin>'s skill refs; purge=1 removes bits when unreferenced and not floor.
wingman_skill_teardown() {
    local plugin="$1" purge="${2:-0}" name refs
    while IFS= read -r name; do
        [ -z "$name" ] && continue
        if journal_skill_required_by "$name" | grep -qx "$plugin"; then
            journal_skill_decref "$name" "$plugin"
            if [ "$purge" = "1" ]; then
                refs="$(journal_skill_refcount "$name")"
                if [ "${refs:-0}" -eq 0 ]; then
                    _wingman_fs_apply "" "rm -rf \"$(get_wingman_skills_dir)/${name}\"" 2>/dev/null || true
                    journal_skill_remove "$name"
                    _wms_log "removed unreferenced skill '${name}'"
                fi
            fi
        fi
    done <<EOF
$(journal_list_skills)
EOF
    return 0
}