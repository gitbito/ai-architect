#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
#
# `bitoarch plugin` CLI surface (verb dispatcher + help).

if [ -n "${_BITOARCH_PLUGIN_CLI_LOADED:-}" ]; then
    return 0
fi
_BITOARCH_PLUGIN_CLI_LOADED=1

_BITOARCH_PLUGIN_CLI_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

_plugin_cli_error() { if type print_error >/dev/null 2>&1; then print_error "$1" >&2; else printf '%s\n' "$1" >&2; fi; }

# Graceful Ctrl-C for prompting verbs: print a verb-aware message + the re-run command, exit 130 (verbs are idempotent/resumable).
_plugin_cli_interrupt() {   # <verb> <name>
    trap - INT
    printf '\n' >&2
    printf '\n' >&2
    local op
    case "$1" in
        install) op="Installation" ;;
        config)  op="Configuration" ;;
        start)   op="Start" ;;
        upgrade) op="Upgrade" ;;
        *)       op="Operation" ;;
    esac
    _plugin_cli_error "${op} canceled."
    if [ -n "${2:-}" ]; then
        # Prefer the plugin NAME (CDN re-install form) over a local source path; command highlighted in yellow.
        local _arg="$2" _nm
        if [ "$1" = "install" ] && [ -d "$_arg" ] && [ -f "$_arg/plugin.yaml" ] && type manifest_name >/dev/null 2>&1; then
            _nm="$(manifest_name "$_arg/plugin.yaml" 2>/dev/null)"; [ -n "$_nm" ] && _arg="$_nm"
        fi
        # Install registers + deploys before the setup prompts, so a cancel here leaves a
        # partial install (resumable by design). Say so plainly and offer both paths.
        if [ "$1" = "install" ] && type journal_plugin_exists >/dev/null 2>&1 && journal_plugin_exists "$_arg" 2>/dev/null; then
            printf '   %s is partially installed.\n' "$_arg" >&2
            printf '   Finish it:  %bbitoarch plugin install %s%b\n' "${YELLOW:-}" "$_arg" "${NC:-}" >&2
            printf '   Remove it:  %bbitoarch plugin uninstall %s --purge%b\n' "${YELLOW:-}" "$_arg" "${NC:-}" >&2
        else
            printf '   Run again when ready: %bbitoarch plugin %s %s%b\n' "${YELLOW:-}" "$1" "$_arg" "${NC:-}" >&2
        fi
    fi
    exit 130
}

_plugin_cli_help() {
    cat <<'EOF'
USAGE:
  bitoarch plugin <verb> [options]

VERBS:
  install <name|path|url>          Install a plugin (resolves shared deps, provisions, deploys)
  start <name>                     Set up (prompts for anything missing) + (re)start the plugin
  stop <name>                      Stop the plugin (keeps it installed; start brings it back)
  restart <name>                   Recreate the containers (re-applies the current config)
  list                             List installed plugins and versions
  status [<name>]                  Plugin health + services + resolved STORAGE_MODE + shared dependency packs
  upgrade <name> [--check] [--source <path>]
                                   Upgrade a plugin (--check reports versions; holds on a missing credential)
  config <name> [--set k=v ...]    View or change a plugin's configuration (changes apply immediately)
  config edit <name>               Open the plugin's config (.env) in $EDITOR
                                   Plugin-specific options: bitoarch plugin config <name> --help
  uninstall <name> [--purge]       Remove a plugin (keeps its data; --purge deletes it)
  deps <list | install <capability> | uninstall <capability> --if-unused>
                                   Manage shared dependency packs by capability (event-bus | cache)

EXAMPLES:
  bitoarch plugin list
  bitoarch plugin install ./my-plugin
  bitoarch plugin status
  bitoarch plugin deps list
EOF
}

# Lazily source the engine; each module guards against re-sourcing.
# jq/yq are internal tooling: auto-provision them via the base installer
# (prerequisites-manager.sh handles brew/apt/yum/dnf + sudo). The operator is
# never asked to install internal tools; loud only if auto-install itself fails.
_plugin_cli_prereqs() {
    command -v jq >/dev/null 2>&1 && command -v yq >/dev/null 2>&1 && return 0
    if ! type install_jq >/dev/null 2>&1 || ! type install_yq >/dev/null 2>&1; then
        # shellcheck source=/dev/null
        . "${_BITOARCH_PLUGIN_CLI_DIR}/../../prerequisites-manager.sh" 2>/dev/null || true
    fi
    command -v jq >/dev/null 2>&1 || { type install_jq >/dev/null 2>&1 && install_jq >&2 || true; }
    command -v yq >/dev/null 2>&1 || { type install_yq >/dev/null 2>&1 && install_yq >&2 || true; }
    local missing=""
    command -v jq >/dev/null 2>&1 || missing="${missing} jq"
    command -v yq >/dev/null 2>&1 || missing="${missing} yq"
    if [ -n "$missing" ]; then
        _plugin_cli_error "Could not prepare the required tooling automatically (${missing# })."
        printf '   Re-run with sudo/network available, or install%s manually and retry.\n' "$missing" >&2
        return 1
    fi
    return 0
}

_plugin_cli_source() {   # <path> <component>
    # shellcheck source=/dev/null
    . "$1" || { _plugin_cli_error "Could not load the plugin engine."; printf '   %bComponent: %s%b\n' "${CYAN:-}" "$2" "${NC:-}" >&2; return 1; }
}

_plugin_cli_load_engine() {
    local d="${_BITOARCH_PLUGIN_CLI_DIR}"
    _plugin_cli_prereqs || return 1
    if ! type get_plugin_install_dir >/dev/null 2>&1; then
        # shellcheck source=/dev/null
        . "${d}/../path-manager.sh" 2>/dev/null || true
    fi
    # Load the base docker-manager so the engine resolves the host's Compose form for deploy/provisioning (guarded against re-source).
    if ! type get_docker_compose_cmd >/dev/null 2>&1; then
        # shellcheck source=/dev/null
        . "${d}/../../docker-manager.sh" 2>/dev/null || true
    fi
    # Base progress loader so deploys render the same [+] ... done (Ns) line as the platform.
    if ! type progress_run >/dev/null 2>&1; then
        # shellcheck source=/dev/null
        . "${d}/../progress-output.sh" 2>/dev/null || true
    fi
    # Insights helpers so plugin hooks can enumerate ticket-tracker projects (validation +
    # --list-projects); best-effort — hooks type-guard and degrade without them.
    if ! type _insights_fetch_jira_projects >/dev/null 2>&1; then
        # shellcheck source=/dev/null
        . "${d}/../insights-prompts.sh" 2>/dev/null || true
    fi
    _plugin_cli_source "${d}/install-flow.sh"        install-flow   || return 1
    _plugin_cli_source "${d}/upgrade-flow.sh"        upgrade-flow   || return 1
    _plugin_cli_source "${d}/uninstall-flow.sh"      uninstall-flow || return 1
    _plugin_cli_source "${d}/plugin-status.sh"       plugin-status  || return 1
    _plugin_cli_source "${d}/dependency-manager.sh"  dependency-manager || return 1
    return 0
}

_plugin_cli_deps() {
    local action="${1:-list}"; shift 2>/dev/null || true
    case "$action" in
        ""|list) deps_list ;;
        install)
            [ -n "${1:-}" ] || { _plugin_cli_error "Usage: bitoarch plugin deps install <event-bus|cache>"; return 1; }   # M1
            deps_install "$1" ;;
        uninstall)
            local cap="" ifu=0 a
            for a in "$@"; do
                case "$a" in --if-unused) ifu=1 ;; *) [ -z "$cap" ] && cap="$a" ;; esac
            done
            [ -n "$cap" ] || { _plugin_cli_error "Usage: bitoarch plugin deps uninstall <event-bus|cache> --if-unused"; return 1; }   # M1
            if [ "$ifu" -ne 1 ]; then
                _plugin_cli_error "'${cap}' is a shared dependency pack."         # M2
                printf '   %bSafe removal: bitoarch plugin deps uninstall %s --if-unused%b\n' "${YELLOW:-}" "$cap" "${NC:-}" >&2
                return 1
            fi
            deps_uninstall_if_unused "$cap" ;;
        *) _plugin_cli_error "Unknown deps action: ${action}"                     # M3
           printf '   %bExpected: list, install, or uninstall.%b\n' "${CYAN:-}" "${NC:-}" >&2
           return 1 ;;
    esac
}

handle_plugin() {
    local sub="${1:-}"
    shift 2>/dev/null || true
    case "$sub" in
        ""|-h|--help|help)
            _plugin_cli_help
            return 0
            ;;
        install|start|stop|restart|list|status|upgrade|config|uninstall|deps) ;;
        *)
            _plugin_cli_error "Unknown plugin command: ${sub}"                    # L4
            printf '   %bExpected: install, start, stop, restart, config, uninstall, deps, or upgrade.%b\n' "${CYAN:-}" "${NC:-}" >&2
            echo "" >&2
            _plugin_cli_help >&2
            return 1
            ;;
    esac

    _plugin_cli_load_engine || return 1

    # Graceful Ctrl-C on the prompting verbs (see _plugin_cli_interrupt).
    local _pi_name="${1:-}"
    case "$sub" in
        install|start|config|upgrade) trap '_plugin_cli_interrupt "'"$sub"'" "'"$_pi_name"'"' INT ;;
    esac

    case "$sub" in
        install)   local _prc=0; plugin_install "$@" || _prc=$?
                   # Single concise failure line (details are in the log / printed by the failing step).
                   if [ "$_prc" -ne 0 ] && [ -n "$_pi_name" ]; then
                       type print_warning >/dev/null 2>&1 && print_warning "could not install '${_pi_name}'" >&2
                   fi
                   return $_prc ;;
        start)     plugin_start "$@" ;;
        stop)      plugin_stop "$@" ;;
        restart)   plugin_restart "$@" ;;
        list)      plugin_list "$@" ;;
        status)    plugin_status "$@" ;;
        upgrade)   plugin_upgrade "$@" ;;
        config)    plugin_config "$@" ;;
        uninstall) plugin_uninstall "$@" ;;
        deps)      _plugin_cli_deps "$@" ;;
    esac
}
export -f handle_plugin 2>/dev/null || true
