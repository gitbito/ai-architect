#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
#
# Per-plugin MySQL provisioner.

if [ -n "${_BITOARCH_PLUGIN_MYSQL_PROVISIONER_LOADED:-}" ]; then
    return 0
fi
_BITOARCH_PLUGIN_MYSQL_PROVISIONER_LOADED=1

_mysqlp_err() {
    if type print_error >/dev/null 2>&1; then print_error "$1" >&2; else printf 'ERROR: %s\n' "$1" >&2; fi
    type log_silent >/dev/null 2>&1 && log_silent "mysql provisioner: $1"
}

# Resolve the MySQL root password: loaded env if present, else read it from the running MySQL container (so deprovision works without the base env).
_plugin_mysql_root_pw() {
    if [ -n "${MYSQL_ROOT_PASSWORD:-}" ]; then printf '%s' "$MYSQL_ROOT_PASSWORD"; return 0; fi
    if [ "$(get_deployment_type 2>/dev/null || echo docker-compose)" = "kubernetes" ]; then
        kubectl exec -n "${BITOARCH_K8S_NAMESPACE:-bito-ai-architect}" deployment/ai-architect-mysql -- \
            printenv MYSQL_ROOT_PASSWORD 2>/dev/null
    else
        docker exec ai-architect-mysql printenv MYSQL_ROOT_PASSWORD 2>/dev/null
    fi
}

_plugin_mysql_exec() {
    local deploy ns pw
    deploy="$(get_deployment_type 2>/dev/null || echo docker-compose)"
    ns="${BITOARCH_K8S_NAMESPACE:-bito-ai-architect}"
    pw="$(_plugin_mysql_root_pw)"
    # Pass the password via MYSQL_PWD, not -p, to suppress the insecure-password warning and keep the secret out of process args.
    if [ "$deploy" = "kubernetes" ]; then
        kubectl exec -i -n "$ns" deployment/ai-architect-mysql -- \
            env MYSQL_PWD="${pw}" mysql -u root "$@"
    else
        docker exec -i -e MYSQL_PWD="${pw}" ai-architect-mysql \
            mysql -u root "$@"
    fi
}

# Hex output is safe in both a SQL string and an .env value.
plugin_mysql_generate_password() {
    if command -v openssl >/dev/null 2>&1; then
        openssl rand -hex 24
    else
        LC_ALL=C tr -dc 'a-f0-9' < /dev/urandom | head -c 48; echo
    fi
}

# Never let a non-identifier reach an interpolated SQL statement.
_plugin_mysql_valid_ident() {
    case "$1" in
        ''|*[!a-zA-Z0-9_]*) return 1 ;;
        *) return 0 ;;
    esac
}


plugin_mysql_provision() {
    local db="$1" user="$2" pass="$3"
    if ! _plugin_mysql_valid_ident "$db" || ! _plugin_mysql_valid_ident "$user"; then
        _mysqlp_err "invalid MySQL identifier (db='${db}', user='${user}')"
        return 1
    fi
    if [ -z "$pass" ]; then
        _mysqlp_err "refusing to provision plugin MySQL user '${user}' with an empty password"
        return 1
    fi
    # The password is interpolated into IDENTIFIED BY '<pass>'; reject quote/backslash.
    case "$pass" in
        *\'*|*\\*)
            _mysqlp_err "refusing to provision plugin MySQL user '${user}': password contains an unsupported character (single-quote or backslash)"
            return 1 ;;
    esac
    if [ -z "$(_plugin_mysql_root_pw)" ]; then
        _mysqlp_err "MYSQL_ROOT_PASSWORD is not set and could not be read from the MySQL container; cannot provision plugin database"
        return 1
    fi
    log_silent "provisioning plugin MySQL db='${db}' user='${user}' (scoped grant)" 2>/dev/null || true
    _plugin_mysql_exec <<SQL
CREATE DATABASE IF NOT EXISTS \`${db}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER IF NOT EXISTS '${user}'@'%' IDENTIFIED BY '${pass}';
ALTER USER '${user}'@'%' IDENTIFIED BY '${pass}';
GRANT ALL PRIVILEGES ON \`${db}\`.* TO '${user}'@'%';
FLUSH PRIVILEGES;
SQL
}

plugin_mysql_deprovision() {
    local db="$1" user="$2"
    if ! _plugin_mysql_valid_ident "$db" || ! _plugin_mysql_valid_ident "$user"; then
        _mysqlp_err "invalid MySQL identifier (db='${db}', user='${user}')"
        return 1
    fi
    log_silent "deprovisioning plugin MySQL db='${db}' user='${user}'" 2>/dev/null || true
    _plugin_mysql_exec <<SQL
DROP DATABASE IF EXISTS \`${db}\`;
DROP USER IF EXISTS '${user}'@'%';
FLUSH PRIVILEGES;
SQL
}
