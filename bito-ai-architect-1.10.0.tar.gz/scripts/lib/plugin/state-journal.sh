#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
#
# State journal. Schema: scripts/lib/plugin/schemas/state.schema.json.

if [ -n "${_BITOARCH_PLUGIN_STATE_JOURNAL_LOADED:-}" ]; then
    return 0
fi
_BITOARCH_PLUGIN_STATE_JOURNAL_LOADED=1

_BITOARCH_PLUGIN_JOURNAL_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if ! type get_plugin_state_file >/dev/null 2>&1; then
    # shellcheck source=scripts/lib/path-manager.sh
    . "${_BITOARCH_PLUGIN_JOURNAL_DIR}/../path-manager.sh" 2>/dev/null || true
fi

# Bump only with a migration.
BITOARCH_JOURNAL_SCHEMA_VERSION=1

_journal_err() {
    if type print_error >/dev/null 2>&1; then print_error "$1" >&2; else printf 'ERROR: %s\n' "$1" >&2; fi
    type log_silent >/dev/null 2>&1 && log_silent "state journal: $1"
}

_journal_require_jq() {
    if ! command -v jq >/dev/null 2>&1; then
        _journal_err "jq is required to read/write the plugin state journal but was not found."
        return 1
    fi
    return 0
}

_journal_now() { date -u +%Y-%m-%dT%H:%M:%SZ; }

_journal_sha256() {
    if command -v sha256sum >/dev/null 2>&1; then
        sha256sum | awk '{print $1}'
    else
        shasum -a 256 | awk '{print $1}'
    fi
}

_journal_skeleton() {
    jq -n --argjson v "$BITOARCH_JOURNAL_SCHEMA_VERSION" \
        '{schema_version: $v, updated_at: null, plugins: {}, dependency_packs: {}, skills: {}, wingman: {}, checksum: null}'
}

_journal_path() {
    if type get_plugin_state_file >/dev/null 2>&1; then
        get_plugin_state_file
    else
        echo "${BITOARCH_VAR_DIR:-/usr/local/var/bitoarch}/plugins/state.json"
    fi
}

journal_ensure() {
    _journal_require_jq || return 1
    local f; f="$(_journal_path)"
    [ -f "$f" ] && return 0
    mkdir -p "$(dirname "$f")" 2>/dev/null || {
        _journal_err "cannot create journal directory: $(dirname "$f")"; return 1; }
    _journal_with_lock _journal_ensure_write
}

# Runs under the lock; re-checks existence to avoid clobbering a concurrent create.
_journal_ensure_write() {
    local f; f="$(_journal_path)"
    [ -f "$f" ] && return 0
    _journal_skeleton | _journal_save
}

journal_read() {
    _journal_require_jq || return 1
    local f; f="$(_journal_path)"
    [ -f "$f" ] || { _journal_skeleton; return 0; }
    # Integrity gate: a stored checksum that no longer matches means a corrupted or
    # hand-edited journal -- refuse it (fail closed) rather than trust bad state.
    # Files without a checksum (legacy/tests) are tolerated. Warn once per process.
    local stored
    stored="$(jq -r '.checksum // ""' "$f" 2>/dev/null)"
    if [ -n "$stored" ] && [ "$stored" != "$(jq -S 'del(.checksum, .updated_at)' "$f" 2>/dev/null | _journal_sha256)" ]; then
        if [ "${_BITOARCH_JOURNAL_BAD_WARNED:-0}" != "1" ]; then
            _BITOARCH_JOURNAL_BAD_WARNED=1
            _journal_err "plugin state journal failed checksum verification: ${f} (restore it from backups, or remove it to reset plugin state)"
        fi
        return 1
    fi
    cat "$f"
}

# Checksum covers the body with checksum/updated_at removed, so it is stable.
_journal_save() {
    _journal_require_jq || return 1
    local f tmp body sum
    f="$(_journal_path)"
    mkdir -p "$(dirname "$f")" 2>/dev/null || true
    body="$(cat)"
    if ! printf '%s' "$body" | jq -e . >/dev/null 2>&1; then
        _journal_err "refusing to write malformed journal JSON"
        return 1
    fi
    sum="$(printf '%s' "$body" | jq -S 'del(.checksum, .updated_at)' | _journal_sha256)"
    tmp="${f}.tmp.$$"
    if printf '%s' "$body" \
        | jq --arg s "$sum" --arg t "$(_journal_now)" '.checksum=$s | .updated_at=$t' > "$tmp" 2>/dev/null \
        && mv "$tmp" "$f"; then
        return 0
    fi
    rm -f "$tmp" 2>/dev/null
    _journal_err "failed to write journal: $f"
    return 1
}

# 0 = intact, 1 = checksum mismatch, 2 = missing.
journal_verify() {
    _journal_require_jq || return 1
    local f; f="$(_journal_path)"
    [ -f "$f" ] || return 2
    local stored recomputed
    stored="$(jq -r '.checksum // ""' "$f" 2>/dev/null)"
    [ -n "$stored" ] || return 1
    recomputed="$(jq -S 'del(.checksum, .updated_at)' "$f" 2>/dev/null | _journal_sha256)"
    [ "$stored" = "$recomputed" ]
}

# mkdir lock (flock is not on macOS); a dead holder's lock is reclaimed.
_journal_with_lock() {
    local lockdir holder attempts=0 timeout="${BITOARCH_JOURNAL_LOCK_TIMEOUT:-10}" max_attempts
    max_attempts=$((timeout * 10))
    lockdir="$(_journal_path).lock"
    mkdir -p "$(dirname "$lockdir")" 2>/dev/null || true
    while ! mkdir "$lockdir" 2>/dev/null; do
        if [ -f "$lockdir/pid" ]; then
            holder="$(cat "$lockdir/pid" 2>/dev/null)"
            if [ -n "$holder" ] && ! kill -0 "$holder" 2>/dev/null; then
                # Re-read pid, then mv-to-reclaim: only one waiter wins the rename.
                if [ "$(cat "$lockdir/pid" 2>/dev/null)" = "$holder" ] \
                   && mv "$lockdir" "${lockdir}.dead.$$" 2>/dev/null; then
                    rm -rf "${lockdir}.dead.$$" 2>/dev/null
                fi
                continue
            fi
        fi
        attempts=$((attempts + 1))
        if [ "$attempts" -ge "$max_attempts" ]; then
            _journal_err "could not acquire journal lock at ${lockdir} after ${timeout}s"
            return 1
        fi
        sleep 0.1
    done
    echo "$$" > "$lockdir/pid" 2>/dev/null || true
    "$@"
    local rc=$?
    rm -rf "$lockdir" 2>/dev/null || true
    return $rc
}

_journal_apply() {
    local prog="$1"; shift
    # Read first and abort on failure -- piping a failed read into jq would feed
    # _journal_save empty input and truncate the journal (destroying the evidence).
    local cur; cur="$(journal_read)" || return 1
    printf '%s' "$cur" | jq "$@" "$prog" | _journal_save
}

# Locked read-modify-write that every journal mutation goes through.
_journal_mutate() {
    _journal_with_lock _journal_apply "$@"
}

journal_list_plugins() { journal_read | jq -r '.plugins | keys[]' 2>/dev/null; }

journal_plugin_exists() {
    [ "$(journal_read | jq -r --arg n "$1" '.plugins | has($n)' 2>/dev/null)" = "true" ]
}

journal_get_plugin() {
    journal_read | jq -e --arg n "$1" '.plugins[$n] // empty' 2>/dev/null
}

# journal_plugin_field <name> <jq-path-without-leading-dot>
journal_plugin_field() {
    journal_read | jq -r --arg n "$1" ".plugins[\$n].$2 // empty" 2>/dev/null
}

journal_put_plugin() {
    local name="$1" obj="$2"
    _journal_mutate '.plugins[$n] = ($o + {updated_at: $t})' --arg n "$name" --argjson o "$obj" --arg t "$(_journal_now)"
}

journal_set_plugin_status() {
    _journal_mutate '.plugins[$n].status = $s | .plugins[$n].updated_at = $t' --arg n "$1" --arg s "$2" --arg t "$(_journal_now)"
}

journal_remove_plugin() {
    _journal_mutate 'del(.plugins[$n])' --arg n "$1"
}

journal_list_packs() { journal_read | jq -r '.dependency_packs | keys[]' 2>/dev/null; }

journal_pack_exists() {
    [ "$(journal_read | jq -r --arg p "$1" '.dependency_packs | has($p)' 2>/dev/null)" = "true" ]
}

journal_pack_get() {
    journal_read | jq -e --arg p "$1" '.dependency_packs[$p] // empty' 2>/dev/null
}

journal_pack_refcount() {
    journal_read | jq -r --arg p "$1" '(.dependency_packs[$p].required_by // []) | length' 2>/dev/null
}

journal_pack_required_by() {
    journal_read | jq -r --arg p "$1" '(.dependency_packs[$p].required_by // [])[]' 2>/dev/null
}

# ref_count is kept consistent with required_by length on every write.
journal_pack_put() {
    local pack="$1" obj="$2"
    _journal_mutate \
        '.dependency_packs[$p] = ($o + {updated_at: $t})
         | .dependency_packs[$p].required_by //= []
         | .dependency_packs[$p].ref_count = (.dependency_packs[$p].required_by | length)' \
        --arg p "$pack" --argjson o "$obj" --arg t "$(_journal_now)"
}

journal_pack_incref() {
    local pack="$1" plugin="$2"
    _journal_mutate \
        '.dependency_packs[$p].required_by = (((.dependency_packs[$p].required_by // []) + [$n]) | unique)
         | .dependency_packs[$p].ref_count = (.dependency_packs[$p].required_by | length)
         | .dependency_packs[$p].updated_at = $t' \
        --arg p "$pack" --arg n "$plugin" --arg t "$(_journal_now)"
}

journal_pack_decref() {
    local pack="$1" plugin="$2"
    _journal_mutate \
        '(.dependency_packs[$p].required_by) |= (map(select(. != $n)))
         | .dependency_packs[$p].ref_count = ((.dependency_packs[$p].required_by // []) | length)
         | .dependency_packs[$p].updated_at = $t' \
        --arg p "$pack" --arg n "$plugin" --arg t "$(_journal_now)"
}

# Live-health reconciliation for packs (lifecycle heal owns calling this).
journal_set_pack_health() {
    _journal_mutate '.dependency_packs[$p].health = $h | .dependency_packs[$p].updated_at = $t' \
        --arg p "$1" --arg h "$2" --arg t "$(_journal_now)"
}

journal_pack_remove() {
    _journal_mutate 'del(.dependency_packs[$p])' --arg p "$1"
}

journal_list_skills() { journal_read | jq -r '.skills | keys[]' 2>/dev/null; }

journal_skill_exists() {
    [ "$(journal_read | jq -r --arg s "$1" '.skills | has($s)' 2>/dev/null)" = "true" ]
}


# journal_skill_field <skill> <jq-path-without-leading-dot>
journal_skill_field() {
    journal_read | jq -r --arg s "$1" ".skills[\$s].$2 // empty" 2>/dev/null
}

journal_skill_refcount() {
    journal_read | jq -r --arg s "$1" '(.skills[$s].required_by // []) | length' 2>/dev/null
}

journal_skill_required_by() {
    journal_read | jq -r --arg s "$1" '(.skills[$s].required_by // [])[]' 2>/dev/null
}

# ref_count is kept consistent with required_by length on every write.
journal_skill_put() {
    local skill="$1" obj="$2"
    _journal_mutate \
        '.skills[$s] = $o
         | .skills[$s].required_by //= []
         | .skills[$s].ref_count = (.skills[$s].required_by | length)' \
        --arg s "$skill" --argjson o "$obj"
}

journal_skill_incref() {
    local skill="$1" plugin="$2"
    _journal_mutate \
        '.skills[$s].required_by = (((.skills[$s].required_by // []) + [$n]) | unique)
         | .skills[$s].ref_count = (.skills[$s].required_by | length)' \
        --arg s "$skill" --arg n "$plugin"
}

journal_skill_decref() {
    local skill="$1" plugin="$2"
    _journal_mutate \
        '(.skills[$s].required_by) |= (map(select(. != $n)))
         | .skills[$s].ref_count = ((.skills[$s].required_by // []) | length)' \
        --arg s "$skill" --arg n "$plugin"
}

journal_skill_set_version() {
    _journal_mutate '.skills[$s].version = $v' --arg s "$1" --arg v "$2"
}

journal_skill_remove() {
    _journal_mutate 'del(.skills[$s])' --arg s "$1"
}


# Plugins not in the terminal 'installed' state.
journal_inflight_plugins() {
    journal_read | jq -r '.plugins | to_entries[] | select(.value.status != "installed") | .key' 2>/dev/null
}
