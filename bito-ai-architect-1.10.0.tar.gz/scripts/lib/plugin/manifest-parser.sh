#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
#
# Manifest field accessors + version compatibility.

if [ -n "${_BITOARCH_PLUGIN_MANIFEST_PARSER_LOADED:-}" ]; then
    return 0
fi
_BITOARCH_PLUGIN_MANIFEST_PARSER_LOADED=1

_BITOARCH_PLUGIN_MP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

_mp_err() {
    if type print_error >/dev/null 2>&1; then print_error "$1" >&2; else printf 'ERROR: %s\n' "$1" >&2; fi
    type log_silent >/dev/null 2>&1 && log_silent "manifest parser: $1"
}
_mp_warn() {
    if type print_warning >/dev/null 2>&1; then print_warning "$1" >&2; else printf 'WARNING: %s\n' "$1" >&2; fi
    type log_silent >/dev/null 2>&1 && log_silent "manifest parser: $1"
}

_mp_yq() { yq eval "$2" "$1" 2>/dev/null; }
_mp_scalar() {
    local v; v="$(_mp_yq "$1" "$2")"
    [ "$v" = "null" ] && v=""
    printf '%s' "$v"
}

manifest_name()         { _mp_scalar "$1" '.name'; }
manifest_version()      { _mp_scalar "$1" '.version'; }
manifest_display_name() { _mp_scalar "$1" '.displayName'; }
manifest_description()  { _mp_scalar "$1" '.description'; }

# Generic scalar reader for a yq path (full '.a.b' expression); "" when absent/null.
manifest_config_scalar() { _mp_scalar "$1" "$2"; }
manifest_platform_constraint() { _mp_scalar "$1" '.requires.platform'; }
manifest_db_name()      { _mp_scalar "$1" '.db.name'; }
manifest_db_user()      { _mp_scalar "$1" '.db.user'; }
manifest_compose()      { _mp_scalar "$1" '.services.compose'; }
manifest_helm_chart()   { _mp_scalar "$1" '.services.helm.chart'; }
manifest_helm_release() { _mp_scalar "$1" '.services.helm.release'; }
manifest_storage_mode() { _mp_scalar "$1" '.storage.mode'; }
# Flags marked `prompt: false` (engine-managed/internal): never asked interactively.
manifest_flags_noprompt()  { _mp_yq "$1" '.flags[] | select(.prompt == false) | .key' 2>/dev/null | grep -v '^null$' || true; }
manifest_env_template() { _mp_scalar "$1" '.env.template'; }
# Optional install-time entitlement: the mgmt-api feature-access key a plugin requires. Empty => not gated.
manifest_entitlement_features() {
    # Entitlement feature key(s) gating install: a scalar (one) or a sequence (ALL required — AND).
    # Emits one key per line; empty when the plugin declares no entitlement.
    case "$(_mp_yq "$1" '.entitlement.feature | tag' 2>/dev/null)" in
        '!!seq') _mp_yq "$1" '.entitlement.feature[]' 2>/dev/null ;;
        '!!str') _mp_yq "$1" '.entitlement.feature' 2>/dev/null ;;
        *) : ;;
    esac
}

manifest_hook() { _mp_scalar "$1" ".hooks.$2"; }
manifest_hook_timeout() {
    local t; t="$(_mp_scalar "$1" '.hooks.timeoutSeconds')"
    [ -n "$t" ] && printf '%s' "$t" || printf '60'
}

manifest_capabilities()    { _mp_yq "$1" '.requires.capabilities[]' 2>/dev/null | grep -v '^null$' || true; }
manifest_redis_prefixes()  { _mp_yq "$1" '.creates.redisPrefixes[]' 2>/dev/null | grep -v '^null$' || true; }
manifest_mcp_tools()       { _mp_yq "$1" '.creates.mcpTools[]' 2>/dev/null | grep -v '^null$' || true; }

# A topic entry may be a bare string or a {name, dlq} map.
manifest_topics() {
    _mp_yq "$1" '.creates.topics[] | (if type == "!!map" then [.name, .dlq] else [.] end) | .[]' 2>/dev/null \
        | grep -vE '^(null|)$' || true
}

manifest_pack_version() { _mp_scalar "$1" ".requires.packVersions[\"$2\"]"; }

manifest_wingman_constraint()     { _mp_scalar "$1" '.requires.wingman'; }

# Carried skills as records (NAME|VERSION|DIR), one per line.
manifest_wingman_skills() {
    local f="$1" n i name ver dir
    n="$(_mp_yq "$f" '.wingman.skills | length' 2>/dev/null)"
    case "$n" in ''|null|0) return 0 ;; esac
    i=0
    while [ "$i" -lt "$n" ]; do
        name="$(_mp_scalar "$f" ".wingman.skills[$i].name")"
        ver="$(_mp_scalar "$f" ".wingman.skills[$i].version")"
        dir="$(_mp_scalar "$f" ".wingman.skills[$i].dir")"
        [ -n "$name" ] && printf '%s|%s|%s\n' "$name" "$ver" "$dir"
        i=$((i + 1))
    done
}

manifest_required_config_keys() {
    local n i k
    n="$(_mp_yq "$1" '.config.required | length' 2>/dev/null)"
    [ -z "$n" ] || [ "$n" = "null" ] && return 0
    i=0
    while [ "$i" -lt "$n" ]; do
        k="$(_mp_scalar "$1" ".config.required[$i].key")"
        [ -n "$k" ] && printf '%s\n' "$k"
        i=$((i + 1))
    done
}

# Non-secret deploy values to confirm at setup, as KEY|LABEL|HINT records (e.g. PUBLIC_URL). Optional.
manifest_config_prompt() {
    local n i key label hint
    n="$(_mp_yq "$1" '.config.prompt | length' 2>/dev/null)"
    case "$n" in ''|null|0) return 0 ;; esac
    i=0
    while [ "$i" -lt "$n" ]; do
        key="$(_mp_scalar "$1" ".config.prompt[$i].key")"
        label="$(_mp_scalar "$1" ".config.prompt[$i].label")"
        hint="$(_mp_scalar "$1" ".config.prompt[$i].hint")"
        [ -n "$key" ] && printf '%s|%s|%s\n' "$key" "$label" "$hint"
        i=$((i + 1))
    done
}

# Operator-facing config-view rows as KEY|LABEL records; optional (view falls back to prompt + required keys).
manifest_config_display() {
    local n i key label
    n="$(_mp_yq "$1" '.config.display | length' 2>/dev/null)"
    case "$n" in ''|null|0) return 0 ;; esac
    i=0
    while [ "$i" -lt "$n" ]; do
        key="$(_mp_scalar "$1" ".config.display[$i].key")"
        label="$(_mp_scalar "$1" ".config.display[$i].label")"
        [ -n "$key" ] && printf '%s|%s\n' "$key" "$label"
        i=$((i + 1))
    done
}

# Interactive-setup steps as TITLE|EMOJI|ACTION records (built-in action or `hook:<rel>`); optional, engine has a default flow.
manifest_setup_steps() {
    local n i title emoji action
    n="$(_mp_yq "$1" '.setup.steps | length' 2>/dev/null)"
    case "$n" in ''|null|0) return 0 ;; esac
    i=0
    while [ "$i" -lt "$n" ]; do
        title="$(_mp_scalar "$1" ".setup.steps[$i].title")"
        emoji="$(_mp_scalar "$1" ".setup.steps[$i].emoji")"
        action="$(_mp_scalar "$1" ".setup.steps[$i].action")"
        [ -n "$action" ] && printf '%s|%s|%s\n' "$title" "$emoji" "$action"
        i=$((i + 1))
    done
}

# Human provider noun for generic messages so the base avoids hardcoding plugin names. Optional.
manifest_display_provider() { _mp_scalar "$1" '.displayProvider'; }

# App-manifest plugin: framework renders config.appManifest.template and points the operator at createUrl.
manifest_config_app_manifest_template() { _mp_scalar "$1" '.config.appManifest.template'; }
manifest_config_app_manifest_url()      { _mp_scalar "$1" '.config.appManifest.createUrl'; }

# The cis-config integration a required key resolves from; empty for a plain value/secret.
manifest_config_required_integration() {
    local v; v="$(_mp_yq "$1" ".config.required[] | select(.key == \"$2\") | .integration")"
    [ "$v" = "null" ] && v=""
    printf '%s' "$v"
}

# "1" when a required key is engine-managed (has resolve: or generate:) -> auto-filled
# (inherited from the platform env / generated), so it is NEVER interactively prompted,
# on fresh install OR reconfigure. Empty for a genuinely user-facing value.
manifest_config_required_managed() {
    local r g
    r="$(_mp_yq "$1" ".config.required[] | select(.key == \"$2\") | .resolve")";  [ "$r" = "null" ] && r=""
    g="$(_mp_yq "$1" ".config.required[] | select(.key == \"$2\") | .generate")"; [ "$g" = "null" ] && g=""
    if [ -n "$r" ] || [ -n "$g" ]; then printf '1'; fi
}

# Required keys that declare an integration, as KEY|INTEGRATION records (connected via cis-config, not prompted).
manifest_config_required_integrations() {
    local n i key integ
    n="$(_mp_yq "$1" '.config.required | length' 2>/dev/null)"
    [ -z "$n" ] || [ "$n" = "null" ] && return 0
    i=0
    while [ "$i" -lt "$n" ]; do
        key="$(_mp_scalar "$1" ".config.required[$i].key")"
        integ="$(_mp_scalar "$1" ".config.required[$i].integration")"
        [ -n "$key" ] && [ -n "$integ" ] && printf '%s|%s\n' "$key" "$integ"
        i=$((i + 1))
    done
}

# Read one field ($2) from the webhook descriptor (config.webhook.*); "" when absent.
manifest_config_webhook() {
    local v; v="$(_mp_scalar "$1" ".config.webhook.$2")"
    printf '%s' "$v"
}
# True (rc 0) when the manifest declares a config.webhook block.
manifest_has_webhook() {
    local n; n="$(_mp_yq "$1" '.config.webhook | length' 2>/dev/null)"
    case "$n" in ''|null|0) return 1 ;; *) return 0 ;; esac
}

# Public ingress routes the plugin exposes, as PATH|HOST|PORT records (host = in-network service the path forwards to).
manifest_routes() {
    local n i path host port
    n="$(_mp_yq "$1" '.routes | length' 2>/dev/null)"
    case "$n" in ''|null|0) return 0 ;; esac
    i=0
    while [ "$i" -lt "$n" ]; do
        path="$(_mp_scalar "$1" ".routes[$i].path")"
        host="$(_mp_scalar "$1" ".routes[$i].host")"
        port="$(_mp_scalar "$1" ".routes[$i].port")"
        [ -n "$path" ] && [ -n "$host" ] && printf '%s|%s|%s\n' "$path" "$host" "${port:-8080}"
        i=$((i + 1))
    done
}

# Host ports the plugin binds, declared platform-independently in `.ports` as {env, default},
# emitted as ENV|DEFAULT records. The pre-flight resolves ENV from the plugin env (falling back to
# DEFAULT) and checks the port is free before deploying; k8s binds no host ports, so it's skipped there.
manifest_ports() {
    local n i env def
    n="$(_mp_yq "$1" '.ports | length' 2>/dev/null)"
    case "$n" in ''|null|0) return 0 ;; esac
    i=0
    while [ "$i" -lt "$n" ]; do
        env="$(_mp_scalar "$1" ".ports[$i].env")"
        def="$(_mp_scalar "$1" ".ports[$i].default")"
        [ -n "$def" ] && printf '%s|%s\n' "$env" "$def"
        i=$((i + 1))
    done
}

# config.required keys with a `generate` method (e.g. hex32), as KEY|METHOD records (filled randomly, not prompted).
manifest_config_generated_keys() {
    local n i key gen
    n="$(_mp_yq "$1" '.config.required | length' 2>/dev/null)"
    [ -z "$n" ] || [ "$n" = "null" ] && return 0
    i=0
    while [ "$i" -lt "$n" ]; do
        key="$(_mp_scalar "$1" ".config.required[$i].key")"
        gen="$(_mp_scalar "$1" ".config.required[$i].generate")"
        [ -n "$key" ] && [ -n "$gen" ] && printf '%s|%s\n' "$key" "$gen"
        i=$((i + 1))
    done
}

# Friendly prompt label for a required-config key; empty -> caller humanizes the key.
manifest_config_required_label() {
    local v; v="$(_mp_yq "$1" ".config.required[] | select(.key == \"$2\") | .label")"
    [ "$v" = "null" ] && v=""
    printf '%s' "$v"
}

# Free-text offline-setup steps shown before prompting for required config. Optional.
manifest_config_setup() { _mp_scalar "$1" '.config.setup'; }

# Optional one-line heading shown above the endpoint list; engine falls back to a generic line.
manifest_config_endpoints_hint() { _mp_scalar "$1" '.config.endpointsHint'; }

# External endpoints to register with the provider after start, as LABEL|URL-TEMPLATE records (url resolved at display). Optional.
manifest_config_endpoints() {
    local n i label url
    n="$(_mp_yq "$1" '.config.endpoints | length' 2>/dev/null)"
    case "$n" in ''|null|0) return 0 ;; esac
    i=0
    while [ "$i" -lt "$n" ]; do
        label="$(_mp_scalar "$1" ".config.endpoints[$i].label")"
        url="$(_mp_scalar "$1" ".config.endpoints[$i].url")"
        [ -n "$url" ] && printf '%s|%s\n' "$label" "$url"
        i=$((i + 1))
    done
}

# Emit flags as registry records: KEY|DEFAULT|<owner>|SOURCE|DESCRIPTION.
manifest_flags() {
    local f="$1" owner="$2" n i key def src desc
    n="$(_mp_yq "$f" '.flags | length' 2>/dev/null)"
    case "$n" in ''|null|0) return 0 ;; esac
    i=0
    while [ "$i" -lt "$n" ]; do
        key="$(_mp_scalar "$f" ".flags[$i].key")"
        def="$(_mp_scalar "$f" ".flags[$i].default")"
        src="$(_mp_scalar "$f" ".flags[$i].source")"
        desc="$(_mp_scalar "$f" ".flags[$i].description")"
        [ -z "$src" ] && src="env"
        [ -n "$key" ] && printf '%s|%s|%s|%s|%s\n' "$key" "$def" "$owner" "$src" "$desc"
        i=$((i + 1))
    done
}

installed_platform_version() {
    if [ -n "${BITOARCH_PLATFORM_VERSION:-}" ]; then
        printf '%s' "$BITOARCH_PLATFORM_VERSION"; return 0
    fi
    local c candidates
    candidates="
${_BITOARCH_PLUGIN_MP_DIR}/../../../versions/service-versions.json
$(type get_versions_dir >/dev/null 2>&1 && get_versions_dir)/service-versions.json
"
    for c in $candidates; do
        if [ -f "$c" ] && command -v jq >/dev/null 2>&1; then
            jq -r '.platform_info.version // empty' "$c" 2>/dev/null && return 0
        fi
    done
    return 0
}

# Compare dotted versions on MAJOR.MINOR.PATCH; prints -1, 0, or 1.
_semver_cmp() {
    local a="${1%%[-+]*}" b="${2%%[-+]*}"
    local A B i av bv
    IFS=. read -r -a A <<EOF
$a
EOF
    IFS=. read -r -a B <<EOF
$b
EOF
    i=0
    while [ "$i" -lt 3 ]; do
        av="${A[$i]:-0}"; bv="${B[$i]:-0}"
        case "$av" in ''|*[!0-9]*) av=0 ;; esac
        case "$bv" in ''|*[!0-9]*) bv=0 ;; esac
        if [ "$av" -lt "$bv" ]; then echo -1; return 0; fi
        if [ "$av" -gt "$bv" ]; then echo 1; return 0; fi
        i=$((i + 1))
    done
    echo 0
}

# <constraint> is comparator + version (e.g. ">=3.7.0"); bare version means ">=".
plugin_version_satisfies() {
    local installed="$1" constraint="$2" op want cmp want_minor
    [ -z "$constraint" ] && return 0
    op="${constraint%%[0-9]*}"
    want="${constraint#"$op"}"
    [ -z "$op" ] && op=">="
    [ -z "$installed" ] && return 0
    cmp="$(_semver_cmp "$installed" "$want")"
    case "$op" in
        ">=") [ "$cmp" -ge 0 ] ;;
        ">")  [ "$cmp" -gt 0 ] ;;
        "<=") [ "$cmp" -le 0 ] ;;
        "<")  [ "$cmp" -lt 0 ] ;;
        "="|"==") [ "$cmp" -eq 0 ] ;;
        # ^1.2.0 == >=1.2.0 <2.0.0
        "^")  [ "$cmp" -ge 0 ] && [ "$(_semver_cmp "$installed" "$(( ${want%%.*} + 1 )).0.0")" -lt 0 ] ;;
        # ~1.2.0 == >=1.2.0 <1.3.0
        "~")  want_minor="${want#*.}"; want_minor="${want_minor%%.*}"
              [ "$cmp" -ge 0 ] && [ "$(_semver_cmp "$installed" "${want%%.*}.$(( want_minor + 1 )).0")" -lt 0 ] ;;
        *)    [ "$cmp" -ge 0 ] ;;
    esac
}

manifest_check_platform() {
    local f="$1" constraint installed
    constraint="$(manifest_platform_constraint "$f")"
    [ -z "$constraint" ] && return 0

    installed="$(installed_platform_version)"
    if [ -z "$installed" ]; then
        _mp_warn "cannot determine installed platform version; skipping requires.platform '$constraint' check"
        return 0
    fi

    if ! plugin_version_satisfies "$installed" "$constraint"; then
        _mp_err "plugin requires platform ${constraint}, but the installed platform is ${installed}. Upgrade the platform first."
        return 1
    fi
    return 0
}
