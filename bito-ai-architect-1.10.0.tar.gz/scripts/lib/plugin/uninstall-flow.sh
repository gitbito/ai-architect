#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
#
# Uninstall flow (preserve-by-default; --purge drops DB/data/config).

if [ -n "${_BITOARCH_PLUGIN_UNINSTALL_FLOW_LOADED:-}" ]; then
    return 0
fi
_BITOARCH_PLUGIN_UNINSTALL_FLOW_LOADED=1

_BITOARCH_PLUGIN_UNINSTALL_SELF="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if ! type _plugin_undeploy >/dev/null 2>&1; then
    . "${_BITOARCH_PLUGIN_UNINSTALL_SELF}/deploy.sh" 2>/dev/null || true
fi
if ! type journal_get_plugin >/dev/null 2>&1; then
    . "${_BITOARCH_PLUGIN_UNINSTALL_SELF}/state-journal.sh" 2>/dev/null || true
fi
if ! type dep_release_requires >/dev/null 2>&1; then
    . "${_BITOARCH_PLUGIN_UNINSTALL_SELF}/dependency-manager.sh" 2>/dev/null || true
fi
if ! type wingman_skill_teardown >/dev/null 2>&1; then
    . "${_BITOARCH_PLUGIN_UNINSTALL_SELF}/wingman-skills.sh" 2>/dev/null || true
fi
if ! type plugin_mysql_deprovision >/dev/null 2>&1; then
    . "${_BITOARCH_PLUGIN_UNINSTALL_SELF}/mysql-provisioner.sh" 2>/dev/null || true
fi
if ! type plugin_run_hook >/dev/null 2>&1; then
    . "${_BITOARCH_PLUGIN_UNINSTALL_SELF}/hooks-runner.sh" 2>/dev/null || true
fi
if ! type render_plugin_uninstalled_block >/dev/null 2>&1; then
    . "${_BITOARCH_PLUGIN_UNINSTALL_SELF}/plugin-blocks.sh" 2>/dev/null || true
fi
if ! type ingress_sync >/dev/null 2>&1; then
    . "${_BITOARCH_PLUGIN_UNINSTALL_SELF}/ingress.sh" 2>/dev/null || true
fi

_un_err()  { if type print_error >/dev/null 2>&1; then print_error "$1" >&2; else printf 'ERROR: %s\n' "$1" >&2; fi; type log_silent >/dev/null 2>&1 && log_silent "plugin uninstall: $1"; }
_un_warn() { if type print_warning >/dev/null 2>&1; then print_warning "$1" >&2; else printf 'WARNING: %s\n' "$1" >&2; fi; type log_silent >/dev/null 2>&1 && log_silent "plugin uninstall: $1"; }
_un_info() { if type print_info >/dev/null 2>&1; then print_info "$1"; else printf '%s\n' "$1"; fi; }
_un_log()  { type log_silent >/dev/null 2>&1 && log_silent "plugin uninstall: $1"; }

# plugin_uninstall <name> [--purge] [--yes]
plugin_uninstall() {
    local name="" purge=0 assume_yes=0 a
    for a in "$@"; do
        case "$a" in
            --purge) purge=1 ;;
            --yes|-y) assume_yes=1 ;;
            --*) _un_err "unknown option: $a"; return 1 ;;
            *) [ -z "$name" ] && name="$a" ;;
        esac
    done
    [ -z "$name" ] && { _un_err "usage: bitoarch plugin uninstall <name> [--purge]"; return 1; }

    if ! journal_plugin_exists "$name"; then
        _un_info "Plugin '${name}' is not installed."
        return 0
    fi

    local install_dir config_dir data_dir env_file manifest db dbuser
    install_dir="$(get_plugin_install_dir "$name")"
    config_dir="$(get_plugin_config_dir "$name")"
    data_dir="$(get_plugin_data_dir "$name")"
    env_file="$(get_plugin_env_file "$name")"
    manifest="$install_dir/plugin.yaml"
    db="$(journal_plugin_field "$name" db.name)"
    dbuser="$(journal_plugin_field "$name" db.user)"

    # Light confirm on both paths (skipped under --yes / no TTY); wording differs since --purge deletes the data.
    if [ "$assume_yes" -ne 1 ] && [ -t 0 ]; then
        local reply
        if [ "$purge" -eq 1 ]; then
            printf "Are you sure you want to uninstall '%s' and delete its data? [y/N] " "$name"
        else
            printf "Are you sure you want to uninstall '%s'? [y/N] " "$name"
        fi
        read -r reply
        case "$reply" in y|Y|yes|YES) ;; *) _un_info "Aborted."; return 1 ;; esac
    fi

    journal_set_plugin_status "$name" "uninstalling"

    # Last log capture before the units are torn down (post-mortem debugging).
    local _ulm="${_BITOARCH_PLUGIN_UNINSTALL_SELF}/../../unified-log-manager.sh"
    [ -x "$_ulm" ] && "$_ulm" sync-plugin "$name" >/dev/null 2>&1 || true

    # A hook failure is logged but never blocks teardown.
    if [ -f "$manifest" ]; then
        local pre_hook timeout
        pre_hook="$(manifest_hook "$manifest" preUninstall)"
        timeout="$(manifest_hook_timeout "$manifest")"
        if [ -n "$pre_hook" ]; then
            plugin_run_hook "$install_dir" "$pre_hook" "$timeout" || _un_warn "pre-uninstall hook failed (continuing teardown)"
        fi
    fi

    # On --purge, run the plugin's declared onPurge hook (if any) while the service is still up,
    # sourced with base helpers + env in scope so it can do teardown that needs the running
    # service. The base stays plugin-agnostic — the plugin owns what purge means for it. A plain
    # uninstall skips it. Best-effort — a failure warns and never blocks teardown.
    if [ "$purge" -eq 1 ] && [ -f "$manifest" ]; then
        local purge_hook
        purge_hook="$(manifest_hook "$manifest" onPurge)"
        if [ -n "$purge_hook" ] && [ -f "$install_dir/$purge_hook" ]; then
            ( PLUGIN_NAME="$name" PLUGIN_DIR="$install_dir" PLUGIN_MANIFEST="$manifest" \
              PLUGIN_ENV_FILE="$(get_plugin_env_file "$name")" \
              BITOARCH_DEPLOY_TYPE="$(get_deployment_type 2>/dev/null || echo docker-compose)"
              [ -f "${_BITOARCH_PLUGIN_UNINSTALL_SELF}/plugin-http.sh" ] && . "${_BITOARCH_PLUGIN_UNINSTALL_SELF}/plugin-http.sh" 2>/dev/null || true
              . "$install_dir/$purge_hook" ) || _un_warn "purge hook reported an issue (continuing teardown)"
        fi
    fi

    # Teardown must succeed before we delete anything. On failure the plugin's containers
    # may still be up, so leave it registered and its DB/data/config intact, surface the
    # failure, and stop -- do not report a clean uninstall over orphaned services.
    if ! _plugin_undeploy "$name" "$install_dir" "$manifest" $([ "$purge" -eq 1 ] && echo --purge) 2>/dev/null; then
        journal_set_plugin_status "$name" "installed" 2>/dev/null || true
        _un_err "Could not remove '${name}' services -- it is still deployed. Nothing was deleted; retry: bitoarch plugin uninstall ${name}$([ "$purge" -eq 1 ] && echo ' --purge')"
        return 1
    fi

    type _plugin_deregister_mcp >/dev/null 2>&1 && _plugin_deregister_mcp "$name" || true

    dep_release_requires "$name" 2>/dev/null || true

    # Default keeps the bits; --purge removes a skill unreferenced and not floor.
    wingman_skill_teardown "$name" "$purge" 2>/dev/null || true

    if [ "$purge" -eq 1 ]; then
        if [ -n "$db" ] && [ "$db" != "null" ]; then
            plugin_mysql_deprovision "$db" "$dbuser" 2>/dev/null || _un_warn "could not drop plugin DB '${db}' (continuing)"
        fi
        [ -d "$data_dir" ] && rm -rf "$data_dir" 2>/dev/null || true
    fi

    if [ -f "$manifest" ]; then
        local post_hook timeout2
        post_hook="$(manifest_hook "$manifest" postUninstall)"
        timeout2="$(manifest_hook_timeout "$manifest")"
        if [ -n "$post_hook" ]; then
            plugin_run_hook "$install_dir" "$post_hook" "$timeout2" || _un_warn "post-uninstall hook failed (continuing)"
        fi
    fi

    # Config (.env) is kept unless --purge, so the preserved DB stays reachable.
    rm -rf "$install_dir" 2>/dev/null || true
    if [ "$purge" -eq 1 ]; then
        rm -rf "$config_dir" 2>/dev/null || true
    fi

    journal_remove_plugin "$name"

    # Rebuild the shared ingress so the removed plugin's routes are dropped.
    if type ingress_sync >/dev/null 2>&1; then ingress_sync >/dev/null 2>&1 || true
    elif type plugin_ingress_sync >/dev/null 2>&1; then plugin_ingress_sync >/dev/null 2>&1 || true; fi

    # Auto-update schedule stays only while plugins remain installed.
    if [ -f "$(dirname "${BASH_SOURCE[0]}")/../scheduler.sh" ]; then
        # shellcheck source=/dev/null
        . "$(dirname "${BASH_SOURCE[0]}")/../scheduler.sh" 2>/dev/null || true
        type scheduler_sync >/dev/null 2>&1 && scheduler_sync >/dev/null 2>&1 || true
    fi

    _un_log "uninstalled '${name}' (purge=${purge})"
    if [ "$purge" -eq 1 ]; then
        render_plugin_uninstalled_purged_block "$name"
    else
        render_plugin_uninstalled_block "$name"
    fi
    return 0
}
