#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
#
# Reserved base env keys.

if [ -n "${_BITOARCH_PLUGIN_RESERVED_KEYS_LOADED:-}" ]; then
    return 0
fi
_BITOARCH_PLUGIN_RESERVED_KEYS_LOADED=1

BITOARCH_PLUGIN_RESERVED_KEYS=(
    MYSQL_ROOT_PASSWORD
    MYSQL_PASSWORD
    MYSQL_USER
    MYSQL_DATABASE
    MYSQL_HOST
    MYSQL_PORT
    TEMPORAL_MYSQL_USER
    TEMPORAL_MYSQL_PASSWORD
    BITO_API_KEY
    BITO_MCP_ACCESS_TOKEN
    JWT_SECRET
    TRACKING_SERVICE_BASE_URL
    APP_DEPLOYMENT_MODE
    STORAGE_PATH
)
export BITOARCH_PLUGIN_RESERVED_KEYS

BITOARCH_PLUGIN_RESERVED_PREFIXES=(
    BITOARCH_
)
export BITOARCH_PLUGIN_RESERVED_PREFIXES

plugin_key_is_reserved() {
    local key="$1"
    [ -n "$key" ] || return 1

    local reserved
    for reserved in "${BITOARCH_PLUGIN_RESERVED_KEYS[@]}"; do
        [ "$key" = "$reserved" ] && return 0
    done

    local prefix
    for prefix in "${BITOARCH_PLUGIN_RESERVED_PREFIXES[@]}"; do
        case "$key" in
            "${prefix}"*) return 0 ;;
        esac
    done

    return 1
}
export -f plugin_key_is_reserved 2>/dev/null || true

# A config key whose value must be hidden at the prompt (masked) and in views.
# Lives here (a shared leaf module) so EVERY install path masks identically:
# install-flow (prompt collection) and plugin-status (config view) both source this.
_plugin_key_is_secret() {
    case "$1" in
        *SECRET*|*TOKEN*|*PASSWORD*|*_KEY|*APIKEY*|*SIGNING*) return 0 ;;
        *) return 1 ;;
    esac
}
export -f _plugin_key_is_secret 2>/dev/null || true
