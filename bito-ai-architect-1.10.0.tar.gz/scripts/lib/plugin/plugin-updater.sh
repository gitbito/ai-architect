#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
#
# Standalone plugin auto-updater. For each installed plugin it resolves the
# latest published version from the distribution CDN, and when a newer version
# exists: downloads the tarball, verifies it (SHA-256 + GPG detached signature),
# STAGES it under ${BITOARCH_VAR_DIR}/plugins/<name>/staged-<ver>/, runs a
# credential pre-flight diff, and records availability in the state journal.
# It NEVER applies the upgrade, restarts containers, or touches base (apply is
# the operator-run `bitoarch plugin upgrade <name> --source <staged-tarball>`).
# Idempotent and best-effort: every failure is logged and skipped, never fatal.
#
# Output policy: routine progress is written to the log file only (log_silent);
# the terminal stays quiet. Errors are logged AND emitted on stderr so a manual
# run still surfaces failures.
#
# Download base = BITOARCH_PLUGIN_DOWNLOAD_URL (mirrors UPGRADE_DOWNLOAD_URL,
# default https://aiarch.bito.ai); an air-gap mirror is one env override. The
# per-plugin tarball path is a fixed convention, so no plugin catalogue is
# baked into the platform (that lives with the distribution / plugin packages).

if [ -n "${_BITOARCH_PLUGIN_UPDATER_LOADED:-}" ]; then
    return 0
fi
_BITOARCH_PLUGIN_UPDATER_LOADED=1

_PU_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# Source each dep (all load-guarded, so re-sourcing is a no-op).
for _dep in state-journal.sh manifest-parser.sh; do
    # shellcheck source=/dev/null
    . "${_PU_DIR}/${_dep}" 2>/dev/null || true
done
unset _dep
if ! type get_var_dir >/dev/null 2>&1; then
    # shellcheck source=/dev/null
    . "${_PU_DIR}/../path-manager.sh" 2>/dev/null || true
fi

# Logging: routine output -> log file only; errors -> log file + stderr. Keeps
# the terminal clean (this runs unattended under the scheduler).
_pu_log()  { type log_silent >/dev/null 2>&1 && log_silent "plugin update: $1"; return 0; }
_pu_info() { _pu_log "$1"; }
_pu_warn() { _pu_log "WARN: $1"; }
_pu_err()  { _pu_log "ERROR: $1"; printf 'plugin update: %s\n' "$1" >&2; }

# Repo root (scripts/lib/plugin -> up 3). Used to locate the bundled publisher key.
_pu_repo_root() { cd "${_PU_DIR}/../../.." 2>/dev/null && pwd; }
# BITOARCH_PLUGIN_PUBLISHER_KEY overrides the bundled key location (air-gap
# operators who manage the key out-of-band; tests).
_pu_publisher_key() { echo "${BITOARCH_PLUGIN_PUBLISHER_KEY:-$(_pu_repo_root)/share/keys/bitoco-publisher.asc}"; }

# Returns 0 (opted out) when BITOARCH_PLUGIN_AUTO_UPDATE is explicitly false/0,
# in the process env or .env-bitoarch. Default (unset) = enabled.
plugin_update_opted_out() {
    case "${BITOARCH_PLUGIN_AUTO_UPDATE:-}" in
        false|FALSE|0|no|NO) return 0 ;;
        '') ;;
        *) return 1 ;;
    esac
    local env_file
    type get_config_file >/dev/null 2>&1 && env_file="$(get_config_file 2>/dev/null)"
    [ -n "${env_file:-}" ] && [ -f "$env_file" ] || return 1
    grep -qE '^[[:space:]]*BITOARCH_PLUGIN_AUTO_UPDATE[[:space:]]*=[[:space:]]*("?(false|0|no)"?)[[:space:]]*$' "$env_file" 2>/dev/null
}

# Distribution base URL for a plugin, derived purely by convention from the
# download root. PLUGINS_CDN_BASE_URL (full base incl. path, shared with the
# install flow) wins; else the root knob BITOARCH_PLUGIN_DOWNLOAD_URL.
_pu_base_url() {
    local name="$1"
    printf '%s/%s' \
        "${PLUGINS_CDN_BASE_URL:-${BITOARCH_PLUGIN_DOWNLOAD_URL:-https://aiarch.bito.ai}/ai-architect-plugins}" \
        "$name"
}

_pu_curl_to() {  # <url> <out-file> -> 0 on success
    command -v curl >/dev/null 2>&1 || { _pu_err "curl not available; cannot fetch ${1}"; return 1; }
    curl -fsSL -o "$2" "$1" 2>/dev/null
}
_pu_curl_text() { command -v curl >/dev/null 2>&1 && curl -fsSL "$1" 2>/dev/null; }

# Echo "<version> <sha256> <asc(true|false)>" from <base>/<name>-latest.json.
_pu_latest() {
    local name="$1" base json
    base="$(_pu_base_url "$name")"
    json="$(_pu_curl_text "${base}/${name}-latest.json")" || return 1
    [ -n "$json" ] || return 1
    command -v jq >/dev/null 2>&1 || return 1
    printf '%s' "$json" | jq -er '"\(.version) \(.sha256 // "") \(.asc // false)"' 2>/dev/null
}

# Strict "a > b" semver-ish compare via sort -V (no external deps).
_pu_version_gt() {
    local a="$1" b="$2"
    [ -n "$a" ] || return 1
    [ "$a" = "$b" ] && return 1
    [ "$(printf '%s\n%s\n' "$a" "$b" | sort -V 2>/dev/null | tail -1)" = "$a" ]
}

_pu_staged_dir() {  # <name> <ver>
    echo "$(get_var_dir)/plugins/$1/staged-$2"
}

_pu_sha256() {
    if command -v sha256sum >/dev/null 2>&1; then sha256sum "$1" | awk '{print $1}'
    elif command -v shasum >/dev/null 2>&1; then shasum -a 256 "$1" | awk '{print $1}'
    else return 1; fi
}

# Verify a detached GPG signature against the bundled publisher key.
# rc 0 = verified; rc 2 = skipped (no key bundled yet);
# rc 1 = key present but verification could not be completed (REJECT).
_pu_verify_gpg() {
    local tarball="$1" asc="$2" key
    key="$(_pu_publisher_key)"
    if [ ! -f "$key" ]; then
        _pu_warn "publisher key not bundled at ${key} (provided by the release pipeline); skipping GPG verification (SHA-256 still enforced)."
        return 2
    fi
    if ! command -v gpg >/dev/null 2>&1; then
        _pu_warn "gpg not installed; cannot verify the detached signature. Refusing to stage an unverified tarball."
        return 1
    fi
    if [ ! -f "$asc" ]; then
        _pu_err "publisher key is present but the detached signature (.asc) is missing; refusing to stage (possible tampering / incomplete publish)."
        return 1
    fi
    local home; home="$(mktemp -d)"
    local rc=1
    if gpg --homedir "$home" --batch --quiet --import "$key" 2>/dev/null \
       && gpg --homedir "$home" --batch --quiet --verify "$asc" "$tarball" 2>/dev/null; then
        rc=0
    fi
    rm -rf "$home" 2>/dev/null
    [ "$rc" -eq 0 ] || _pu_err "GPG signature verification FAILED for $(basename "$tarball")."
    return "$rc"
}

# Credential pre-flight: which required config keys would still be missing if
# this staged version were applied now. Writes PREFLIGHT.txt; never fatal.
_pu_preflight() {
    local name="$1" staged_dir="$2" tarball="$3" manifest="${2}/plugin.yaml"
    local out="${staged_dir}/PREFLIGHT.txt" env_file missing="" key v
    type get_plugin_env_file >/dev/null 2>&1 && env_file="$(get_plugin_env_file "$name" 2>/dev/null)"
    {
        echo "Pre-flight for ${name} staged upgrade ($(date '+%Y-%m-%d %H:%M:%S %Z'))"
        # Point at the verified tarball, not the staging dir: upgrade extracts a
        # tarball into a clean temp, whereas a dir source is copied verbatim
        # (which would drag PREFLIGHT.txt + the tarball into the install dir).
        echo "Apply with: bitoarch plugin upgrade ${name} --source ${tarball}"
        echo ""
    } > "$out"
    while IFS= read -r key; do
        [ -z "$key" ] && continue
        v="$(printenv "$key" 2>/dev/null)"
        [ -z "$v" ] && [ -n "${env_file:-}" ] && [ -f "$env_file" ] && v="$(sed -n "s/^${key}=//p" "$env_file" 2>/dev/null | head -1)"
        [ -z "$v" ] && missing="${missing} ${key}"
    done <<EOF
$(manifest_required_config_keys "$manifest" 2>/dev/null)
EOF
    if [ -n "$missing" ]; then
        {
            echo "HOLD RISK -- these required credential(s) are not yet set; the"
            echo "upgrade will be HELD at apply time until provided:"
            echo "  ${missing# }"
            echo ""
            echo "Provide them: bitoarch plugin config ${name} --set KEY=VALUE"
        } >> "$out"
    else
        echo "All required credentials present; upgrade can be applied cleanly." >> "$out"
    fi
    printf '%s' "${missing# }"
}

_pu_journal_set_update() {  # <name> <jq-object>
    local pname="$1" obj="$2"
    type _journal_mutate >/dev/null 2>&1 || return 0
    [ -n "$obj" ] || return 0
    # Single locked mutate (read+merge+write inside one lock) so concurrent updaters
    # can't clobber each other's update field; mirrors journal_set_plugin_status.
    _journal_mutate '.plugins[$n].update = $u | .plugins[$n].updated_at = $t' \
        --arg n "$pname" --argjson u "$obj" --arg t "$(_journal_now)" 2>/dev/null || true
}

# Check + stage (if newer) a single installed plugin. Best-effort.
plugin_update_check() {
    local name="$1"
    journal_plugin_exists "$name" 2>/dev/null || { _pu_warn "'${name}' is not installed; skipping"; return 0; }

    local cur latest version sha asc base
    cur="$(journal_plugin_field "$name" version 2>/dev/null)"
    if ! latest="$(_pu_latest "$name")"; then
        _pu_warn "could not resolve the latest version for '${name}' (offline, or no -latest.json at the mirror); skipping."
        return 0
    fi
    version="${latest%% *}"; latest="${latest#* }"
    sha="${latest%% *}"; asc="${latest##* }"
    base="$(_pu_base_url "$name")"

    local now; now="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
    if ! _pu_version_gt "$version" "$cur"; then
        _pu_log "'${name}' is up to date (installed ${cur}, latest ${version})."
        _pu_journal_set_update "$name" "$(jq -n --arg v "$version" --arg t "$now" '{available:false, latest:$v, checked_at:$t}')"
        return 0
    fi
    _pu_info "'${name}': new version ${version} available (installed ${cur}); downloading + verifying."

    local staged_dir tmp asc_tmp
    staged_dir="$(_pu_staged_dir "$name" "$version")"
    mkdir -p "$staged_dir" 2>/dev/null || { _pu_err "cannot create staging dir ${staged_dir}"; return 0; }
    tmp="${staged_dir}/${name}-${version}.tar.gz.tmp"
    if ! _pu_curl_to "${base}/${version}/${name}-${version}.tar.gz" "$tmp"; then
        _pu_err "download failed for '${name}' ${version} from ${base}/${version}/"
        rm -f "$tmp"; return 0
    fi

    # SHA-256 (mirror mcp-cert.sh): mandatory when the pointer advertises one.
    if [ -n "$sha" ]; then
        local actual; actual="$(_pu_sha256 "$tmp")"
        if [ -z "$actual" ] || [ "$actual" != "$sha" ]; then
            _pu_err "SHA-256 mismatch for '${name}' ${version} (expected ${sha}, got ${actual:-none}); discarding."
            rm -f "$tmp"; return 0
        fi
    else
        _pu_warn "no SHA-256 in the latest pointer for '${name}'; relying on GPG only."
    fi

    # GPG detached signature.
    asc_tmp=""
    if [ "$asc" = "true" ]; then
        asc_tmp="${tmp}.asc"
        _pu_curl_to "${base}/${version}/${name}-${version}.tar.gz.asc" "$asc_tmp" || asc_tmp=""
    fi
    _pu_verify_gpg "$tmp" "$asc_tmp"
    local grc=$?
    if [ "$grc" -eq 1 ]; then
        rm -f "$tmp" "$asc_tmp"; return 0   # verification failed -> never stage
    fi
    local gpg_state="verified"; [ "$grc" -eq 2 ] && gpg_state="skipped(no key)"

    # Promote the verified tarball + extract for the pre-flight manifest read.
    local final="${staged_dir}/${name}-${version}.tar.gz"
    mv "$tmp" "$final" 2>/dev/null || { _pu_err "could not finalize staged tarball"; rm -f "$tmp" "$asc_tmp"; return 0; }
    [ -n "$asc_tmp" ] && mv "$asc_tmp" "${final}.asc" 2>/dev/null || true
    tar -xzf "$final" -C "$staged_dir" 2>/dev/null || true
    # The manifest may be at the staged root or one level down (tarball top dir).
    if [ ! -f "${staged_dir}/plugin.yaml" ]; then
        local top; top="$(find "$staged_dir" -mindepth 1 -maxdepth 2 -name plugin.yaml 2>/dev/null | head -1)"
        [ -n "$top" ] && cp "$top" "${staged_dir}/plugin.yaml" 2>/dev/null || true
    fi

    local missing; missing="$(_pu_preflight "$name" "$staged_dir" "$final")"
    _pu_journal_set_update "$name" "$(jq -n \
        --arg v "$version" --arg s "$staged_dir" --arg g "$gpg_state" --arg t "$now" \
        --argjson miss "$(printf '%s' "$missing" | tr ' ' '\n' | grep -v '^$' | jq -R . | jq -s . 2>/dev/null || echo '[]')" \
        '{available:true, latest:$v, staged:$s, gpg:$g, preflight_missing:$miss, checked_at:$t}')"

    if [ -n "$missing" ]; then
        _pu_warn "'${name}' ${version} staged at ${staged_dir} (GPG: ${gpg_state}). HOLD RISK at apply: missing ${missing}. See PREFLIGHT.txt."
    else
        _pu_info "'${name}' ${version} staged + verified (GPG: ${gpg_state}). Apply: bitoarch plugin upgrade ${name} --source ${final}"
    fi
    return 0
}

# Check every installed plugin. Honors the opt-out. Best-effort, never fatal.
plugin_update_all() {
    if plugin_update_opted_out; then
        _pu_log "auto-update is disabled (BITOARCH_PLUGIN_AUTO_UPDATE); skipping the plugin update-check."
        return 0
    fi
    type journal_list_plugins >/dev/null 2>&1 || { _pu_warn "state journal unavailable; nothing to check."; return 0; }
    local p any=0
    while IFS= read -r p; do
        [ -z "$p" ] && continue
        any=1
        plugin_update_check "$p"
    done <<EOF
$(journal_list_plugins 2>/dev/null)
EOF
    [ "$any" -eq 0 ] && _pu_log "no plugins installed; nothing to check."
    return 0
}

export -f plugin_update_opted_out plugin_update_check plugin_update_all 2>/dev/null || true
