#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
#
# Upgrade flow (atomic-swap + credential pre-flight).

if [ -n "${_BITOARCH_PLUGIN_UPGRADE_FLOW_LOADED:-}" ]; then
    return 0
fi
_BITOARCH_PLUGIN_UPGRADE_FLOW_LOADED=1

_BITOARCH_PLUGIN_UPGRADE_SELF="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if ! type plugin_install >/dev/null 2>&1; then
    . "${_BITOARCH_PLUGIN_UPGRADE_SELF}/install-flow.sh" 2>/dev/null || true
fi

_up_err()  { if type print_error >/dev/null 2>&1; then print_error "$1" >&2; else printf 'ERROR: %s\n' "$1" >&2; fi; type log_silent >/dev/null 2>&1 && log_silent "plugin upgrade: $1"; }
_up_warn() { if type print_warning >/dev/null 2>&1; then print_warning "$1" >&2; else printf 'WARNING: %s\n' "$1" >&2; fi; type log_silent >/dev/null 2>&1 && log_silent "plugin upgrade: $1"; }
_up_info() { if type print_info >/dev/null 2>&1; then print_info "$1"; else printf '%s\n' "$1"; fi; }
_up_ok()   { if type print_success >/dev/null 2>&1; then print_success "$1"; else printf '%s\n' "$1"; fi; type log_silent >/dev/null 2>&1 && log_silent "plugin upgrade: $1"; }

# 0 if <key> cannot be resolved (unset/empty in process env and plugin .env).
_plugin_cred_missing() {
    local env_file="$1" key="$2" v
    # Reject non-identifier keys; printenv looks up by name, no shell evaluation.
    case "$key" in
        ''|*[!A-Za-z0-9_]*) return 0 ;;
    esac
    v="$(printenv "$key" 2>/dev/null)"
    [ -n "$v" ] && return 1
    if [ -f "$env_file" ]; then
        v="$(sed -n "s/^${key}=//p" "$env_file" 2>/dev/null | head -1)"
        [ -n "$v" ] && return 1
    fi
    return 0
}

# plugin_upgrade <name> [--check] --source <path>
plugin_upgrade() {
    local name="" check=0 source="" a expect_source=0
    for a in "$@"; do
        if [ "$expect_source" -eq 1 ]; then source="$a"; expect_source=0; continue; fi
        case "$a" in
            --check) check=1 ;;
            --source) expect_source=1 ;;
            --source=*) source="${a#--source=}" ;;
            --*) _up_err "unknown option: $a"; return 1 ;;
            *) [ -z "$name" ] && name="$a" ;;
        esac
    done
    [ -z "$name" ] && { _up_err "usage: bitoarch plugin upgrade <name> [--check] [--source <path>]"; return 1; }

    if ! journal_plugin_exists "$name"; then
        if type _pm_not_installed >/dev/null 2>&1; then _pm_not_installed "$name"
        else _up_err "plugin '${name}' is not installed"; fi
        return 1
    fi
    local cur_version; cur_version="$(journal_plugin_field "$name" version)"

    # No --source: default to the plugin's own name so _plugin_stage_source resolves
    # the latest package from the configured CDN — the SAME resolution `plugin install
    # <name>` and the catalog/list use (<name>-latest.json → tarball). An explicit
    # --source <path> overrides for offline / pinned-version upgrades.
    [ -z "$source" ] && source="$name"

    local staged new_manifest
    staged="$(_plugin_stage_source "$source")" || return 1
    new_manifest="$(_plugin_locate_manifest "$staged")" || return 1
    validate_manifest "$new_manifest" || return 1
    manifest_check_platform "$new_manifest" || return 1

    local new_name new_version
    new_name="$(manifest_name "$new_manifest")"
    new_version="$(manifest_version "$new_manifest")"
    if [ "$new_name" != "$name" ]; then
        _up_err "source package is plugin '${new_name}', not '${name}'"
        return 1
    fi

    if [ "$check" -eq 1 ]; then
        _up_info "Plugin '${name}': installed v${cur_version}, source v${new_version}."
        return 0
    fi

    local install_dir env_file
    install_dir="$(get_plugin_install_dir "$name")"
    env_file="$(get_plugin_env_file "$name")"

    # Hold the upgrade (do not apply) on a missing required credential.
    local missing="" key intg
    while IFS= read -r key; do
        [ -z "$key" ] && continue
        # Integration-bound keys (e.g. jira) are satisfied via the cis-config connection, not the env; don't hold on them.
        intg="$(manifest_config_required_integration "$new_manifest" "$key" 2>/dev/null)"
        [ -n "$intg" ] && continue
        if _plugin_cred_missing "$env_file" "$key"; then missing="${missing} ${key}"; fi
    done <<EOF
$(manifest_required_config_keys "$new_manifest")
EOF
    if [ -n "$missing" ]; then
        journal_put_plugin "$name" "$(journal_get_plugin "$name" | jq \
            --arg v "$new_version" --arg src "$staged" --arg miss "${missing# }" \
            '.upgrade_hold = {version:$v, source:$src, missing:($miss|split(" "))}')"
        _up_err "Upgrade of '${name}' to v${new_version} HELD: missing required credential(s):${missing}. Provide them (bitoarch plugin config ${name} --set KEY=VALUE) then re-run the upgrade. Flagged in 'bitoarch plugin status'."
        return 2
    fi

    # Before the swap, so an arch mismatch on the carried binary fails loud ahead of any change.
    if ! wingman_resolve "$staged" "$new_manifest" "$name"; then
        _up_err "Upgrade of '${name}' aborted: shared Wingman promotion failed (e.g. architecture mismatch). No changes applied."
        return 1
    fi

    # Provision any capability the NEW version requires (a version can add e.g. cache);
    # install and lifecycle-start already do this, upgrade must too. Idempotent for
    # already-provisioned packs; fails loud before any change is applied.
    if type dep_resolve_requires >/dev/null 2>&1 && ! dep_resolve_requires "$new_manifest" "$name" >/dev/null; then
        _up_err "Upgrade of '${name}' aborted: a required dependency pack could not be provisioned. No changes applied."
        return 1
    fi

    # Snapshot current package + env for rollback.
    local snap; snap="$(mktemp -d)"
    cp -R "$install_dir/." "$snap/pkg/" 2>/dev/null || mkdir -p "$snap/pkg"
    [ -f "$env_file" ] && cp "$env_file" "$snap/env" 2>/dev/null || true

    local pre_hook timeout
    pre_hook="$(manifest_hook "$install_dir/plugin.yaml" preUpgrade 2>/dev/null)"
    timeout="$(manifest_hook_timeout "$new_manifest")"
    if [ -n "$pre_hook" ] && ! plugin_run_hook "$install_dir" "$pre_hook" "$timeout"; then
        _up_err "pre-upgrade hook failed; upgrade aborted (no changes applied)"
        rm -rf "$snap"; return 1
    fi

    # Stage new beside the live dir, then rename(2)-swap on the same filesystem.
    local parent base newdir bakdir
    parent="$(dirname "$install_dir")"; base="$(basename "$install_dir")"
    newdir="${parent}/.${base}.new.$$"; bakdir="${parent}/.${base}.bak.$$"
    rm -rf "$newdir"; mkdir -p "$newdir"
    if ! cp -R "$staged/." "$newdir/" 2>/dev/null; then
        _up_err "failed to stage new package"; rm -rf "$newdir" "$snap"; return 1
    fi
    journal_set_plugin_status "$name" "upgrading"
    if ! mv "$install_dir" "$bakdir" || ! mv "$newdir" "$install_dir"; then
        _up_err "atomic swap failed; restoring previous package"
        [ -d "$bakdir" ] && [ ! -d "$install_dir" ] && mv "$bakdir" "$install_dir"
        rm -rf "$newdir" "$bakdir" "$snap"
        journal_set_plugin_status "$name" "installed"
        return 1
    fi

    local tpl_rel; tpl_rel="$(manifest_env_template "$install_dir/plugin.yaml")"
    [ -n "$tpl_rel" ] && [ -f "$install_dir/$tpl_rel" ] && plugin_env_merge "$env_file" "$install_dir/$tpl_rel" >/dev/null 2>&1

    # Image tags (*_IMAGE) are package-owned but live in env.template, and the merge above is
    # additive (never overrides an existing key) -- so an upgrade would otherwise keep the OLD
    # image. Force-update ONLY the *_IMAGE keys from the new template so the new version's
    # images actually deploy; operator values (creds, PUBLIC_URL) stay preserved by the merge.
    if [ -n "$tpl_rel" ] && [ -f "$install_dir/$tpl_rel" ] && type plugin_env_set >/dev/null 2>&1; then
        local _imgline
        while IFS= read -r _imgline; do
            [ -z "$_imgline" ] && continue
            plugin_env_set "$env_file" "${_imgline%%=*}" "${_imgline#*=}"
        done <<EOF
$(grep -E '^[A-Za-z_][A-Za-z0-9_]*_IMAGE=' "$install_dir/$tpl_rel" 2>/dev/null)
EOF
    fi

    # Re-derive MCP wiring (URL/CA) so an upgrade picks up any change in the
    # platform's transport/ports and refreshes the published CA. See mcp-env.sh.
    type plugin_inject_mcp_env >/dev/null 2>&1 && plugin_inject_mcp_env "$env_file"
    type plugin_inject_wingman_env >/dev/null 2>&1 && plugin_inject_wingman_env "$env_file"

    local rolled_back=0
    # Force-recreate + re-pull ("Always"): an upgrade must relaunch EVERY container on the new
    # package/images even when a tag is reused or only scripts/env changed -- a plain `up -d`
    # would leave unchanged containers running the old code. The rollback deploy below stays a
    # plain deploy on purpose -- the node's cached previous-tag image IS the known-good rollback
    # artifact, and the restored old package/env makes `up -d` revert.
    if ! _plugin_recreate "$name" "$install_dir" "$install_dir/plugin.yaml" "Always" || ! _plugin_wait_health "$name"; then
        _up_warn "new version unhealthy; rolling back to v${cur_version}"
        rm -rf "$install_dir"
        if ! mv "$bakdir" "$install_dir"; then _up_err "rollback restore failed; previous package preserved at ${bakdir}"; rm -rf "$newdir" "$snap"; return 1; fi
        [ -f "$snap/env" ] && cp "$snap/env" "$env_file" 2>/dev/null || true
        _plugin_deploy "$name" "$install_dir" "$install_dir/plugin.yaml" >/dev/null 2>&1 || true
        journal_set_plugin_status "$name" "installed"
        rm -rf "$newdir" "$snap"
        rolled_back=1
    fi
    if [ "$rolled_back" -eq 1 ]; then
        _up_err "Upgrade rolled back; '${name}' remains at v${cur_version}."
        return 1
    fi

    rm -rf "$bakdir"
    # Refresh the shared ingress: the new package may change route hosts or paths.
    type ingress_sync >/dev/null 2>&1 && ingress_sync >/dev/null 2>&1
    local post_hook
    post_hook="$(manifest_hook "$install_dir/plugin.yaml" postUpgrade)"
    [ -n "$post_hook" ] && plugin_run_hook "$install_dir" "$post_hook" "$timeout" || true

    local _rel _reqs
    _rel="$(manifest_helm_release "$install_dir/plugin.yaml" 2>/dev/null)"
    _reqs="$(manifest_capabilities "$install_dir/plugin.yaml" 2>/dev/null | jq -R . | jq -s . 2>/dev/null)"; [ -z "$_reqs" ] && _reqs="[]"
    journal_put_plugin "$name" "$(journal_get_plugin "$name" | jq \
        --arg v "$new_version" --arg t "$(date -u +%Y-%m-%dT%H:%M:%SZ)" --arg rel "$_rel" --argjson reqs "$_reqs" \
        '.version=$v | .status="installed" | .health="healthy" | .installed_at=$t | .helm_release=$rel | .requires=$reqs | del(.upgrade_hold)')"
    rm -rf "$snap"
    _up_ok "Plugin '${name}' upgraded ${cur_version} -> ${new_version}."
    return 0
}
