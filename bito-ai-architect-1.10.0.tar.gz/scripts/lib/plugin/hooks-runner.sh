#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
#
# Lifecycle hooks runner.

if [ -n "${_BITOARCH_PLUGIN_HOOKS_RUNNER_LOADED:-}" ]; then
    return 0
fi
_BITOARCH_PLUGIN_HOOKS_RUNNER_LOADED=1

_BITOARCH_PLUGIN_HOOKS_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

_hook_err() {
    if type print_error >/dev/null 2>&1; then print_error "$1" >&2; else printf 'ERROR: %s\n' "$1" >&2; fi
    type log_silent >/dev/null 2>&1 && log_silent "hooks runner: $1"
}

# Falls back to a bash watchdog where timeout/gtimeout are absent (stock macOS).
_hook_run_with_timeout() {
    local secs="$1"; shift
    if command -v timeout >/dev/null 2>&1; then timeout "$secs" "$@"; return $?; fi
    if command -v gtimeout >/dev/null 2>&1; then gtimeout "$secs" "$@"; return $?; fi

    # Watchdog writes the marker before killing, so wait() can't race the kill.
    local marker; marker="$(mktemp)"
    "$@" &
    local cmd_pid=$!
    ( sleep "$secs"
      printf 'timeout' > "$marker"
      command -v pkill >/dev/null 2>&1 && pkill -TERM -P "$cmd_pid" 2>/dev/null
      kill -TERM "$cmd_pid" 2>/dev/null
      sleep 3
      command -v pkill >/dev/null 2>&1 && pkill -KILL -P "$cmd_pid" 2>/dev/null
      kill -KILL "$cmd_pid" 2>/dev/null
    ) &
    local watch_pid=$!
    wait "$cmd_pid" 2>/dev/null
    local rc=$?
    [ -s "$marker" ] && rc=124
    kill "$watch_pid" 2>/dev/null
    wait "$watch_pid" 2>/dev/null
    rm -f "$marker"
    return $rc
}

plugin_run_hook() {
    local plugin_dir="$1" hook_rel="$2" timeout="${3:-60}"
    shift 3 2>/dev/null || true

    [ -z "$hook_rel" ] && return 0

    local hook="${plugin_dir}/${hook_rel}"
    if [ ! -f "$hook" ]; then
        _hook_err "declared hook not found (broken package): ${hook}"
        return 1
    fi
    [ -x "$hook" ] || chmod +x "$hook" 2>/dev/null || true

    BITOARCH_HELPERS="$(cd "${_BITOARCH_PLUGIN_HOOKS_DIR}/.." && pwd)"
    export BITOARCH_HELPERS

    type log_silent >/dev/null 2>&1 && log_silent "hooks runner: running ${hook} (timeout ${timeout}s)"
    _hook_run_with_timeout "$timeout" bash -c '
        unset MYSQL_ROOT_PASSWORD MYSQL_PASSWORD MYSQL_PWD BITO_API_KEY CIS_PROVIDER_API_KEY CIS_MANAGER_API_KEY CIS_CONFIG_API_KEY BITO_MCP_ACCESS_TOKEN JWT_SECRET 2>/dev/null
        for _v in $(env | sed -n "s/^\(TEMPORAL_MYSQL_[A-Za-z0-9_]*\)=.*/\1/p"); do unset "$_v" 2>/dev/null; done
        exec bash "$0" "$@"
    ' "$hook" "$@"
    local rc=$?

    if [ "$rc" -eq 124 ] || [ "$rc" -ge 143 ]; then
        _hook_err "hook timed out or was killed after ${timeout}s: ${hook} (rc=${rc})"
        return "$rc"
    fi
    if [ "$rc" -ne 0 ]; then
        _hook_err "hook failed (rc=${rc}): ${hook}"
        return "$rc"
    fi
    return 0
}
