#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
#
# plugin.yaml manifest validator.

if [ -n "${_BITOARCH_PLUGIN_SCHEMA_LOADED:-}" ]; then
    return 0
fi
_BITOARCH_PLUGIN_SCHEMA_LOADED=1

_BITOARCH_PLUGIN_SCHEMA_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=scripts/lib/plugin/reserved-keys.sh
. "${_BITOARCH_PLUGIN_SCHEMA_DIR}/reserved-keys.sh"

BITOARCH_PLUGIN_API_VERSION="bitoarch.plugin/v1"
BITOARCH_PLUGIN_CAPABILITIES="event-bus cache"
BITOARCH_PLUGIN_RESOLVE_SOURCES="env cis-config"
export BITOARCH_PLUGIN_API_VERSION BITOARCH_PLUGIN_CAPABILITIES BITOARCH_PLUGIN_RESOLVE_SOURCES

_plugin_schema_err() {
    if type print_error >/dev/null 2>&1; then
        print_error "$1" >&2
    else
        printf 'ERROR: %s\n' "$1" >&2
    fi
    type log_silent >/dev/null 2>&1 && log_silent "manifest validation: $1"
}

_plugin_yq() {
    yq eval "$1" "$2" 2>/dev/null
}

_plugin_yq_type() {
    yq eval "$1 | type" "$2" 2>/dev/null
}

# Fails closed (returns 1) if yq is unavailable.
validate_manifest() {
    local f="$1"

    if [ -z "$f" ] || [ ! -f "$f" ]; then
        _plugin_schema_err "manifest not found: ${f:-<empty path>}"
        return 1
    fi

    if ! command -v yq >/dev/null 2>&1; then
        _plugin_schema_err "yq is required to validate plugin manifests but was not found. Install yq (https://github.com/mikefarah/yq) and retry."
        return 1
    fi

    if ! yq eval '.' "$f" >/dev/null 2>&1; then
        _plugin_schema_err "invalid YAML syntax in manifest: $f"
        return 1
    fi

    local k
    for k in apiVersion name version; do
        if [ "$(_plugin_yq "has(\"$k\")" "$f")" != "true" ]; then
            _plugin_schema_err "manifest is missing the required field '${k}'"
            return 1
        fi
    done

    local api_version
    api_version="$(_plugin_yq '.apiVersion' "$f")"
    if [ "$api_version" != "$BITOARCH_PLUGIN_API_VERSION" ]; then
        _plugin_schema_err "apiVersion: expected '${BITOARCH_PLUGIN_API_VERSION}', found '${api_version}'"
        return 1
    fi

    local name
    name="$(_plugin_yq '.name' "$f")"
    # Reject empty and the literal "null" (a YAML null passes the regex but maps to "" downstream).
    if [ -z "$name" ] || [ "$name" = "null" ] || ! printf '%s' "$name" | grep -Eq '^[a-z][a-z0-9-]*$'; then
        _plugin_schema_err "name: '${name}' is invalid (must match ^[a-z][a-z0-9-]*$ -- lowercase, digits, hyphens)"
        return 1
    fi

    local version
    version="$(_plugin_yq '.version' "$f")"
    if ! printf '%s' "$version" | grep -Eq '^[0-9]+\.[0-9]+\.[0-9]+([-+.][0-9A-Za-z.-]+)?$'; then
        _plugin_schema_err "version: '${version}' is not a valid semantic version (expected MAJOR.MINOR.PATCH)"
        return 1
    fi

    if [ "$(_plugin_yq 'has("requires")' "$f")" = "true" ]; then
        local plat_type plat
        plat_type="$(_plugin_yq_type '.requires.platform' "$f")"
        if [ "$plat_type" != "!!null" ]; then
            plat="$(_plugin_yq '.requires.platform' "$f")"
            if ! printf '%s' "$plat" | grep -Eq '^(>=|<=|>|<|=|\^|~)?[0-9]+\.[0-9]+\.[0-9]+$'; then
                _plugin_schema_err "requires.platform: '${plat}' is not a valid version constraint (e.g. '>=1.8.4')"
                return 1
            fi
        fi

        local wm_type wm
        wm_type="$(_plugin_yq_type '.requires.wingman' "$f")"
        if [ "$wm_type" != "!!null" ]; then
            wm="$(_plugin_yq '.requires.wingman' "$f")"
            if ! printf '%s' "$wm" | grep -Eq '^(>=|<=|>|<|=|\^|~)?[0-9]+\.[0-9]+\.[0-9]+$'; then
                _plugin_schema_err "requires.wingman: '${wm}' is not a valid version constraint (e.g. '>=1.4.0')"
                return 1
            fi
        fi

        local caps_type
        caps_type="$(_plugin_yq_type '.requires.capabilities' "$f")"
        if [ "$caps_type" != "!!null" ]; then
            if [ "$caps_type" != "!!seq" ]; then
                _plugin_schema_err "requires.capabilities: must be a list (found ${caps_type})"
                return 1
            fi
            local cap
            while IFS= read -r cap; do
                [ -z "$cap" ] && continue
                case " $BITOARCH_PLUGIN_CAPABILITIES " in
                    *" $cap "*) ;;
                    *)
                        _plugin_schema_err "requires.capabilities: unknown capability '${cap}' (allowed: ${BITOARCH_PLUGIN_CAPABILITIES})"
                        return 1
                        ;;
                esac
            done <<EOF
$(_plugin_yq '.requires.capabilities[]' "$f")
EOF
        fi

        local pv_type
        pv_type="$(_plugin_yq_type '.requires.packVersions' "$f")"
        if [ "$pv_type" != "!!null" ]; then
            if [ "$pv_type" != "!!map" ]; then
                _plugin_schema_err "requires.packVersions: must be a mapping of capability to version constraint"
                return 1
            fi
            local pvk pvv
            while IFS= read -r pvk; do
                [ -z "$pvk" ] && continue
                case " $BITOARCH_PLUGIN_CAPABILITIES " in
                    *" $pvk "*) ;;
                    *) _plugin_schema_err "requires.packVersions: '${pvk}' is not a known capability (allowed: ${BITOARCH_PLUGIN_CAPABILITIES})"; return 1 ;;
                esac
                pvv="$(_plugin_yq ".requires.packVersions[\"$pvk\"]" "$f")"
                if ! printf '%s' "$pvv" | grep -Eq '^(>=|<=|>|<|=|\^|~)?[0-9]+\.[0-9]+\.[0-9]+$'; then
                    _plugin_schema_err "requires.packVersions.${pvk}: '${pvv}' is not a valid version constraint (e.g. '>=3.7.0')"
                    return 1
                fi
            done <<EOF
$(_plugin_yq '.requires.packVersions | keys | .[]' "$f")
EOF
        fi
    fi

    if [ "$(_plugin_yq 'has("wingman")' "$f")" = "true" ]; then
        if [ "$(_plugin_yq_type '.wingman' "$f")" != "!!map" ]; then
            _plugin_schema_err "wingman: must be a mapping"
            return 1
        fi

        local wsk_type scount sidx sname sver sdir
        wsk_type="$(_plugin_yq_type '.wingman.skills' "$f")"
        if [ "$wsk_type" != "!!null" ]; then
            if [ "$wsk_type" != "!!seq" ]; then
                _plugin_schema_err "wingman.skills: must be a list"
                return 1
            fi
            scount="$(_plugin_yq '.wingman.skills | length' "$f")"
            sidx=0
            while [ "$sidx" -lt "${scount:-0}" ]; do
                sname="$(_plugin_yq ".wingman.skills[$sidx].name" "$f")"
                sver="$(_plugin_yq ".wingman.skills[$sidx].version" "$f")"
                sdir="$(_plugin_yq ".wingman.skills[$sidx].dir" "$f")"
                if [ -z "$sname" ] || [ "$sname" = "null" ]; then
                    _plugin_schema_err "wingman.skills[$sidx]: each skill must declare a 'name'"
                    return 1
                fi
                if ! printf '%s' "$sname" | grep -Eq '^[a-z][a-z0-9-]*$'; then
                    _plugin_schema_err "wingman.skills[$sidx].name: '${sname}' is invalid (must match ^[a-z][a-z0-9-]*$)"
                    return 1
                fi
                if [ -z "$sver" ] || [ "$sver" = "null" ]; then
                    _plugin_schema_err "wingman.skills[$sidx].version: required (exact version; higher wins a same-name collision)"
                    return 1
                fi
                if ! printf '%s' "$sver" | grep -Eq '^[0-9]+\.[0-9]+\.[0-9]+([-+.][0-9A-Za-z.-]+)?$'; then
                    _plugin_schema_err "wingman.skills[$sidx].version: '${sver}' is not a valid semantic version"
                    return 1
                fi
                if [ -z "$sdir" ] || [ "$sdir" = "null" ]; then
                    _plugin_schema_err "wingman.skills[$sidx].dir: required (the SKILL.md directory within the tarball)"
                    return 1
                fi
                sidx=$((sidx + 1))
            done
        fi
    fi

    if [ "$(_plugin_yq 'has("creates")' "$f")" = "true" ]; then
        if [ "$(_plugin_yq_type '.creates' "$f")" != "!!map" ]; then
            _plugin_schema_err "creates: must be a mapping"
            return 1
        fi
        local sub
        for sub in topics consumerGroups redisPrefixes secrets mcpTools; do
            local t
            t="$(_plugin_yq_type ".creates.${sub}" "$f")"
            if [ "$t" != "!!null" ] && [ "$t" != "!!seq" ]; then
                _plugin_schema_err "creates.${sub}: must be a list (found ${t})"
                return 1
            fi
        done
        local secret
        while IFS= read -r secret; do
            [ -z "$secret" ] && continue
            if plugin_key_is_reserved "$secret"; then
                _plugin_schema_err "creates.secrets: '${secret}' is a reserved base key and cannot be declared by a plugin"
                return 1
            fi
        done <<EOF
$(_plugin_yq '.creates.secrets[]' "$f")
EOF
    fi

    if [ "$(_plugin_yq 'has("db")' "$f")" = "true" ]; then
        local dbk dbv
        for dbk in name user; do
            dbv="$(_plugin_yq ".db.${dbk}" "$f")"
            if [ -z "$dbv" ] || [ "$dbv" = "null" ]; then
                _plugin_schema_err "db.${dbk}: required when 'db' is present"
                return 1
            fi
            if ! printf '%s' "$dbv" | grep -Eq '^[a-z][a-z0-9_]*$'; then
                _plugin_schema_err "db.${dbk}: '${dbv}' is invalid (must match ^[a-z][a-z0-9_]*$)"
                return 1
            fi
        done
    fi

    # hooks.timeoutSeconds (optional) is consumed as an integer by the hook runner.
    if [ "$(_plugin_yq_type '.hooks.timeoutSeconds' "$f")" != "!!null" ]; then
        local hto
        hto="$(_plugin_yq '.hooks.timeoutSeconds' "$f")"
        if ! printf '%s' "$hto" | grep -Eq '^[1-9][0-9]*$'; then
            _plugin_schema_err "hooks.timeoutSeconds: '${hto}' is not a positive integer (seconds)"
            return 1
        fi
    fi

    if [ "$(_plugin_yq_type '.config.required' "$f")" != "!!null" ]; then
        if [ "$(_plugin_yq_type '.config.required' "$f")" != "!!seq" ]; then
            _plugin_schema_err "config.required: must be a list"
            return 1
        fi
        local count i key src
        count="$(_plugin_yq '.config.required | length' "$f")"
        i=0
        while [ "$i" -lt "${count:-0}" ]; do
            key="$(_plugin_yq ".config.required[$i].key" "$f")"
            if [ -z "$key" ] || [ "$key" = "null" ]; then
                _plugin_schema_err "config.required[$i]: each entry must declare a 'key'"
                return 1
            fi
            # Key is resolved by name, so constrain it to an env-var identifier.
            if ! printf '%s' "$key" | grep -Eq '^[A-Za-z_][A-Za-z0-9_]*$'; then
                _plugin_schema_err "config.required[$i].key: '${key}' is not a valid environment-variable name (^[A-Za-z_][A-Za-z0-9_]*$)"
                return 1
            fi
            # resolve order (optional) must be a subset of the allowed sources.
            if [ "$(_plugin_yq_type ".config.required[$i].resolve" "$f")" != "!!null" ]; then
                while IFS= read -r src; do
                    [ -z "$src" ] && continue
                    case " $BITOARCH_PLUGIN_RESOLVE_SOURCES " in
                        *" $src "*) ;;
                        *)
                            _plugin_schema_err "config.required[$i].resolve: unknown source '${src}' (allowed: ${BITOARCH_PLUGIN_RESOLVE_SOURCES})"
                            return 1
                            ;;
                    esac
                done <<EOF
$(_plugin_yq ".config.required[$i].resolve[]" "$f")
EOF
            fi
            i=$((i + 1))
        done
    fi

    # --- config.prompt: (optional) operator-facing values; key + label both drive the UI ---
    if [ "$(_plugin_yq_type '.config.prompt' "$f")" != "!!null" ]; then
        if [ "$(_plugin_yq_type '.config.prompt' "$f")" != "!!seq" ]; then
            _plugin_schema_err "config.prompt: must be a list"
            return 1
        fi
        local pcount pi pkey plabel
        pcount="$(_plugin_yq '.config.prompt | length' "$f")"
        pi=0
        while [ "$pi" -lt "${pcount:-0}" ]; do
            pkey="$(_plugin_yq ".config.prompt[$pi].key" "$f")"
            plabel="$(_plugin_yq ".config.prompt[$pi].label" "$f")"
            if [ -z "$pkey" ] || [ "$pkey" = "null" ]; then
                _plugin_schema_err "config.prompt[$pi]: each entry must declare a 'key'"
                return 1
            fi
            if ! printf '%s' "$pkey" | grep -Eq '^[A-Za-z_][A-Za-z0-9_]*$'; then
                _plugin_schema_err "config.prompt[$pi].key: '${pkey}' is not a valid environment-variable name (^[A-Za-z_][A-Za-z0-9_]*$)"
                return 1
            fi
            if [ -z "$plabel" ] || [ "$plabel" = "null" ]; then
                _plugin_schema_err "config.prompt[$pi]: each entry must declare a 'label' (shown at the prompt)"
                return 1
            fi
            pi=$((pi + 1))
        done
    fi

    # --- services: (optional, but shape-checked when present) ---------------
    if [ "$(_plugin_yq 'has("services")' "$f")" = "true" ]; then
        # At least one deployment surface (compose or helm) must be declared.
        local has_compose has_helm
        has_compose="$(_plugin_yq_type '.services.compose' "$f")"
        has_helm="$(_plugin_yq_type '.services.helm' "$f")"
        if [ "$has_compose" = "!!null" ] && [ "$has_helm" = "!!null" ]; then
            _plugin_schema_err "services: declare at least one of 'compose' or 'helm'"
            return 1
        fi
        if [ "$has_helm" != "!!null" ]; then
            local rel
            rel="$(_plugin_yq '.services.helm.release' "$f")"
            if [ -z "$rel" ] || [ "$rel" = "null" ]; then
                _plugin_schema_err "services.helm.release: required when 'services.helm' is present (own release, e.g. ai-architect-<name>)"
                return 1
            fi
        fi
    fi

    # --- flags: (optional) -- operator feature flags this plugin declares.
    if [ "$(_plugin_yq_type '.flags' "$f")" != "!!null" ]; then
        if [ "$(_plugin_yq_type '.flags' "$f")" != "!!seq" ]; then
            _plugin_schema_err "flags: must be a list"
            return 1
        fi
        local fcount fidx fkey fsrc
        fcount="$(_plugin_yq '.flags | length' "$f")"
        fidx=0
        while [ "$fidx" -lt "${fcount:-0}" ]; do
            fkey="$(_plugin_yq ".flags[$fidx].key" "$f")"
            if [ -z "$fkey" ] || [ "$fkey" = "null" ]; then
                _plugin_schema_err "flags[$fidx]: each flag must declare a 'key'"
                return 1
            fi
            if ! printf '%s' "$fkey" | grep -Eq '^[A-Za-z_][A-Za-z0-9_]*$'; then
                _plugin_schema_err "flags[$fidx].key: '${fkey}' is not a valid environment-variable name"
                return 1
            fi
            if [ "$(_plugin_yq_type ".flags[$fidx].source" "$f")" != "!!null" ]; then
                fsrc="$(_plugin_yq ".flags[$fidx].source" "$f")"
                case "$fsrc" in
                    env|env-new|framework) ;;
                    *) _plugin_schema_err "flags[$fidx].source: '${fsrc}' is invalid (env | env-new | framework)"; return 1 ;;
                esac
            fi
            fidx=$((fidx + 1))
        done
    fi

    return 0
}
export -f validate_manifest 2>/dev/null || true
