#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
#
# Canonical docker-compose command resolver shared by the plugin modules.

if [ -n "${_BITOARCH_PLUGIN_COMPOSE_CMD_LOADED:-}" ]; then
    return 0
fi
_BITOARCH_PLUGIN_COMPOSE_CMD_LOADED=1

# Reuse the base resolver so compose v1 (docker-compose) is supported, not just v2.
_plugin_compose_cmd() {
    local c
    if type get_docker_compose_cmd >/dev/null 2>&1 && c="$(get_docker_compose_cmd 2>/dev/null)" && [ -n "$c" ]; then
        printf '%s' "$c"
    else
        printf 'docker compose'
    fi
}
export -f _plugin_compose_cmd 2>/dev/null || true
