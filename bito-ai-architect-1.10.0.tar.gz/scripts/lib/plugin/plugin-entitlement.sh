#!/usr/bin/env bash
#
# Copyright (c) 2023-2026 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# @company Bito Inc.
# @website https://bito.ai
#
# Install-time entitlement pre-flight (manifest-driven): if a plugin declares `entitlement.feature`, ask mgmt-api whether it's enabled.
# FAIL-OPEN — only an explicit {"enabled":false} blocks; any other failure proceeds with a warning. Mirrors the platform feature-access contract.
# BITOARCH_ENTITLEMENT_STRICT=1 flips every unverifiable case to fail-closed (regulated deployments).

if [ -n "${_BITOARCH_PLUGIN_ENTITLEMENT_LOADED:-}" ]; then return 0 2>/dev/null || true; fi
_BITOARCH_PLUGIN_ENTITLEMENT_LOADED=1

_pe_warn() { type log_silent >/dev/null 2>&1 && log_silent "plugin entitlement: $1"; }
_pe_log()  { type log_silent >/dev/null 2>&1 && log_silent "plugin entitlement: $1"; }
_pe_err()  { if type print_error >/dev/null 2>&1; then print_error "$1" >&2; else printf 'ERROR: %s\n' "$1" >&2; fi; }

# Best-effort workspace id from the BITO_API_KEY JWT (data field, 4th underscore segment); "" if unparseable (-> fail-open).
_pe_workspace_from_jwt() {                                        # <jwt>
    local jwt="$1" payload data
    [ -n "$jwt" ] || return 0
    payload="$(printf '%s' "$jwt" | cut -d. -f2 | tr '_-' '/+')"
    case $(( ${#payload} % 4 )) in 2) payload="${payload}==" ;; 3) payload="${payload}=" ;; esac
    data="$(printf '%s' "$payload" | base64 -d 2>/dev/null | { if command -v jq >/dev/null 2>&1; then jq -r '.data // empty' 2>/dev/null; else sed -n 's/.*"data"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p'; fi; })"
    printf '%s' "$data" | cut -d_ -f4 | grep -E '^[0-9]+$' || true
}

# Extract a boolean field from a JSON object: prints "true"/"false"/"" .
_pe_json_bool() {                                                 # <json> <key>
    if command -v jq >/dev/null 2>&1; then
        printf '%s' "$1" | jq -r --arg k "$2" '.[$k] | if type=="boolean" then tostring else empty end' 2>/dev/null
    else
        printf '%s' "$1" | sed -n "s/.*\"$2\"[[:space:]]*:[[:space:]]*\(true\|false\).*/\1/p" | head -1
    fi
}

# 0 when the workspace runs on Bito's LLM/service (tracking-service indexing_enabled = true),
# reusing the platform's existing check_indexing_enabled. 1 otherwise — BYOK / custom LLM (Bito LLM
# off), or the check is unavailable/unreachable (treated as "not on Bito LLM" so the entitlement
# gate is skipped, fail-open, matching the entitlement contract).
_pe_bito_llm_enabled() {
    if ! type check_indexing_enabled >/dev/null 2>&1; then
        # Best-effort: the tracker adapter (sibling adapters/ dir) owns the check; source it if the
        # caller didn't already. Guarded below, so a failed source just yields "not on Bito LLM".
        local _ta; _ta="$(dirname "${BASH_SOURCE[0]}")/../adapters/tracker-adapter.sh"
        [ -f "$_ta" ] && . "$_ta" 2>/dev/null || true
    fi
    type check_indexing_enabled >/dev/null 2>&1 || return 1
    local _turl="${TRACKING_SERVICE_BASE_URL:-}" _tkey="${BITO_API_KEY:-}"
    [ -n "$_turl" ] && [ -n "$_tkey" ] || return 1
    check_indexing_enabled "$_turl" "$_tkey" >/dev/null 2>&1
}

# plugin_check_entitlement <manifest> <name>  ->  0 proceed | 1 not entitled (blocked)
plugin_check_entitlement() {
    local manifest="$1" name="$2" features
    features="$(manifest_entitlement_features "$manifest" 2>/dev/null)"
    [ -n "$features" ] || return 0   # plugin declares no entitlement -> not gated

    # Gate on Bito LLM (reusing the platform's tracking-service check): plugin entitlement applies
    # ONLY when the workspace runs on Bito's LLM/service. With BYOK / custom LLM (Bito LLM off) — or
    # when the Bito-LLM state can't be verified — skip the entitlement check and allow the install.
    if ! _pe_bito_llm_enabled; then
        _pe_log "Bito LLM not in use (BYOK/custom LLM or unverifiable) — skipping the entitlement gate for ${name}"
        return 0
    fi

    local url ws key
    url="${XMCP_SSO_MGMT_API_URL:-}"
    key="${BITO_API_KEY:-}"
    ws="${XMCP_SSO_DEFAULT_WORKSPACE_ID:-}"
    [ -n "$ws" ] || ws="$(_pe_workspace_from_jwt "$key")"

    if [ -z "$url" ] || [ -z "$key" ] || [ -z "$ws" ]; then
        _pe_unverifiable "$name" "mgmt-api URL/API key/workspace id not configured"
        return $?
    fi

    # ALL declared features must be enabled (AND). An explicit {"enabled":false} on any one blocks
    # the install; an unverifiable result funnels through _pe_unverifiable (fail-open unless strict).
    local feature resp enabled
    while IFS= read -r feature; do
        [ -n "$feature" ] || continue
        resp="$(plugin_http GET "$url" "/api/work-space/${ws}/feature-access?feature=${feature}&type=config&onprem=true" "$key" 2>/dev/null)"
        if [ -z "$resp" ]; then
            _pe_unverifiable "$name" "mgmt-api unreachable" || return 1
            continue
        fi
        enabled="$(_pe_json_bool "$resp" enabled)"
        case "$enabled" in
            true)  _pe_log "entitlement ok: ${name} feature=${feature} workspace=${ws}" ;;
            false) _pe_render_denied "$name" "$feature" "$ws"; return 1 ;;
            *)     _pe_unverifiable "$name" "unexpected entitlement response (feature=${feature})" || return 1 ;;
        esac
    done <<EOF
$(printf '%s\n' "$features")
EOF
    return 0
}

# Every unverifiable case funnels here: warn-and-proceed by default, blocked under strict mode.
_pe_unverifiable() {   # <name> <reason>
    if [ "${BITOARCH_ENTITLEMENT_STRICT:-0}" = "1" ]; then
        _pe_err "cannot verify '$1' entitlement ($2) and BITOARCH_ENTITLEMENT_STRICT=1 is set — blocking the install."
        return 1
    fi
    _pe_warn "cannot verify '$1' entitlement ($2) — proceeding (fail-open)."
    return 0
}

# Operator-facing block when an install is denied; the raw config-flag key stays in logs only, never shown.
_pe_render_denied() {                                             # <name> <feature> <ws>
    local name="$1" feature="$2" ws="$3"
    _pe_log "entitlement denied: ${name} feature=${feature} workspace=${ws}"
    _pe_err "'${name}' is not enabled for your Bito workspace."
    printf '   Ask your Bito administrator to enable it for workspace %s, then re-run:\n' "$ws" >&2
    printf '     %bbitoarch plugin install %s%b\n' "${YELLOW:-}" "$name" "${NC:-}" >&2
}
