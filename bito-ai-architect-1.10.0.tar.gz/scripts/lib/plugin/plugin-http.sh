#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
#
# Shared HTTP helper for plugin hooks -- quiet, in-network calls to a plugin's own
# service API without reinventing curl or hardcoding the host.

if [ -n "${_BITOARCH_PLUGIN_HTTP_LOADED:-}" ]; then
    return 0
fi
_BITOARCH_PLUGIN_HTTP_LOADED=1

# Resolve a plugin service base URL: an explicit override (full URL) wins; else
# 127.0.0.1:<port> — published by docker, tunneled on demand on k8s when the
# caller names the ClusterIP service.
plugin_service_base() {   # <port> [override-url] [k8s-service]
    local port="$1" override="${2:-}" svc="${3:-}"
    if [ -n "$override" ]; then printf '%s' "${override%/}"; return 0; fi
    [ -n "$svc" ] && type ensure_service_accessible >/dev/null 2>&1 \
        && ensure_service_accessible "$svc" "$port" >/dev/null 2>&1 || true
    printf 'http://127.0.0.1:%s' "$port"
}

# Call a plugin service, print the response body; rc = curl's (0 = request completed).
# Quiet by design -- the caller decides what a non-2xx body means.
#   plugin_http <method> <base-url> <path> [auth-token] [json-body]
plugin_http() {
    local method="$1" base="$2" path="$3" auth="${4:-}" body="${5:-}"
    command -v curl >/dev/null 2>&1 || return 2
    local args=(-s --max-time "${BITOARCH_PLUGIN_HTTP_TIMEOUT:-8}")
    [ "$method" != "GET" ] && args+=(-X "$method")
    [ -n "$auth" ] && args+=(-H "Authorization: ${auth}")
    [ -n "$body" ] && args+=(-H "Content-Type: application/json" -d "$body")
    # HTTPS: verify against the published root CA when present; plain -k needs an explicit opt-in.
    case "$base" in
        https://*)
            if [ -n "${MCP_CA_CERT:-}" ] && [ -f "${MCP_CA_CERT:-}" ]; then
                args+=(--cacert "$MCP_CA_CERT")
            elif [ "${BITOARCH_PLUGIN_HTTP_INSECURE:-0}" = "1" ]; then
                args+=(-k)
            fi
            ;;
    esac
    curl "${args[@]}" "${base%/}${path}" 2>/dev/null
}
