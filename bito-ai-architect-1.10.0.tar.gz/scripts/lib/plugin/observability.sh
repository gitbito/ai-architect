#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
#
# Plugin observability probes. Shared by the live status surface and the
# diagnose collector (collect-plugins.sh): resolved STORAGE_MODE, live health,
# Kafka DLQ depth, data-dir disk usage, and janitor state. Every probe is
# read-only and NEVER fails the caller -- it prints a value (or a clear
# "n/a ..." reason) and returns 0.

if [ -n "${_BITOARCH_PLUGIN_OBSERVABILITY_LOADED:-}" ]; then
    return 0
fi
_BITOARCH_PLUGIN_OBSERVABILITY_LOADED=1

_BITOARCH_PLUGIN_OBS_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# Source each dep (all load-guarded, so re-sourcing is a no-op).
for _dep in state-journal.sh manifest-parser.sh dependency-manager.sh compose-cmd.sh; do
    # shellcheck source=/dev/null
    . "${_BITOARCH_PLUGIN_OBS_DIR}/${_dep}" 2>/dev/null || true
done
unset _dep
if ! type get_plugin_data_dir >/dev/null 2>&1; then
    # shellcheck source=/dev/null
    . "${_BITOARCH_PLUGIN_OBS_DIR}/../path-manager.sh" 2>/dev/null || true
fi

# The docker-compose resolver is the shared _plugin_compose_cmd (compose-cmd.sh,
# sourced above) -- one definition for every plugin module.

# Canonical compose project name comes from deploy.sh; keep a literal fallback
# so a standalone source (a plugin's own collect.sh) still resolves it.
_obs_compose_project() {
    if type plugin_compose_project >/dev/null 2>&1; then
        plugin_compose_project "$1"
    else
        printf 'ai-architect-%s' "$1"
    fi
}

_obs_manifest() { echo "$(get_plugin_install_dir "$1" 2>/dev/null)/plugin.yaml"; }

# Helm release for a plugin (pods are labeled by instance=release, not name).
_obs_helm_release() {
    local name="$1" rel
    rel="$(manifest_helm_release "$(_obs_manifest "$name")" 2>/dev/null)"
    printf '%s' "${rel:-$name}"
}

_obs_k8s_ns() { printf '%s' "${BITOARCH_K8S_NAMESPACE:-bito-ai-architect}"; }

# Resolved STORAGE_MODE for a plugin. The manifest value is typically
# "${STORAGE_MODE:-local}", so resolve it against the live env: an exported
# STORAGE_MODE wins, else the manifest's :- default, else a literal, else local.
plugin_storage_mode() {
    local name="$1" man raw
    if [ -n "${STORAGE_MODE:-}" ]; then printf '%s' "$STORAGE_MODE"; return 0; fi
    man="$(_obs_manifest "$name")"
    [ -f "$man" ] && raw="$(manifest_storage_mode "$man" 2>/dev/null)"
    case "$raw" in
        *':-'*'}'*) raw="${raw##*:-}"; printf '%s' "${raw%\}}" ;;
        ''|*'$'*)   printf 'local' ;;
        *)          printf '%s' "$raw" ;;
    esac
    return 0
}

# DLQ topic names a plugin declares (creates.topics[].dlq), one per line.
_obs_plugin_dlq_topics() {
    local man="$1"
    [ -f "$man" ] || return 0
    if type _mp_yq >/dev/null 2>&1; then
        # awk filter (not grep '^(null|)$') -- portable across grep variants.
        _mp_yq "$man" '.creates.topics[] | select(type == "!!map") | .dlq' 2>/dev/null \
            | awk 'NF && $0 != "null"'
    fi
}

# Locate the running unit backing a shared dependency pack capability.
# Packs pin their docker container_name (and k8s deployment name) to
# PACK_RELEASE, so both lookups go by that one field.
_obs_pack_container() {
    local cap="$1" release
    release="$(_dep_field "$cap" PACK_RELEASE 2>/dev/null)"
    [ -n "$release" ] || return 1
    if [ "$(get_deployment_type 2>/dev/null || echo docker-compose)" = "kubernetes" ]; then
        command -v kubectl >/dev/null 2>&1 || return 1
        kubectl get pods -n "$(_obs_k8s_ns)" -o name 2>/dev/null \
            | sed 's|^pod/||' | grep "^${release}-" | head -1
        return 0
    fi
    command -v docker >/dev/null 2>&1 || return 1
    docker ps -q -f "name=^${release}$" 2>/dev/null | head -1
}

# Run a command inside the broker unit (docker exec / kubectl exec).
_obs_pack_exec() {
    local unit="$1"; shift
    if [ "$(get_deployment_type 2>/dev/null || echo docker-compose)" = "kubernetes" ]; then
        kubectl exec -n "$(_obs_k8s_ns)" "$unit" -- "$@" 2>/dev/null
    else
        docker exec "$unit" "$@" 2>/dev/null
    fi
}

# Kafka DLQ depth for a plugin: sum of latest offsets across each declared DLQ
# topic. Gracefully degrades:
#   - plugin declares no DLQ topics         -> "n/a (no dlq topics)"
#   - no event-bus pack provisioned         -> "n/a (no event-bus pack)"
#   - broker/CLI unreachable                -> "unknown"
#   - topic not yet created                 -> counts as 0
# Output: one "<topic>=<depth>" token per topic, space-joined (or a reason).
plugin_dlq_depth() {
    local name="$1" man topics unit port total topic out depth
    man="$(_obs_manifest "$name")"
    topics="$(_obs_plugin_dlq_topics "$man")"
    [ -z "$topics" ] && { printf 'n/a (no dlq topics)'; return 0; }
    if ! type dep_pack_installed >/dev/null 2>&1 || ! dep_pack_installed "event-bus"; then
        printf 'n/a (no event-bus pack)'; return 0
    fi
    unit="$(_obs_pack_container event-bus)"
    if [ -z "$unit" ]; then printf 'unknown (broker not running)'; return 0; fi
    port="$(_dep_port event-bus 2>/dev/null)"; port="${port:-9092}"
    out=""
    while IFS= read -r topic; do
        [ -z "$topic" ] && continue
        # Kafka topic charset only -- the name is interpolated into the sh -c below,
        # so anything else (quotes, metachars) is skipped rather than executed.
        case "$topic" in *[!A-Za-z0-9._-]*) continue ;; esac
        # topic:partition:offset per line; sum offsets = produced count. The
        # PATH extension covers images that keep kafka bin off the default PATH.
        depth="$(_obs_pack_exec "$unit" sh -c \
                    "PATH=\$PATH:/opt/kafka/bin kafka-get-offsets.sh --bootstrap-server localhost:${port} --topic '${topic}'" \
                 | awk -F: '{s += $3} END {print s + 0}')"
        [ -z "$depth" ] && depth=0
        out="${out} ${topic}=${depth}"
    done <<EOF
$topics
EOF
    printf '%s' "${out# }"
    return 0
}

# Data-dir disk usage for a plugin (host-side df on the data subtree). The data
# path is an in-container path by default; when it isn't present on the host
# (k8s / named volume) we say so rather than guessing.
plugin_disk_usage() {
    local name="$1" dir pct
    dir="$(get_plugin_data_dir "$name" 2>/dev/null)"
    if [ -z "$dir" ] || [ ! -d "$dir" ]; then
        printf 'n/a (data dir not on host: %s)' "${dir:-unset}"; return 0
    fi
    pct="$(df -P "$dir" 2>/dev/null | awk 'NR==2 {print $5}')"
    [ -z "$pct" ] && { printf 'unknown'; return 0; }
    printf '%s used (%s)' "$pct" "$dir"
    return 0
}

# Janitor state for a plugin. The janitor runs INSIDE the consumer plugin, not
# in base; by convention a plugin writes a one-line/JSON status to
# <data_dir>/janitor/state.json. Surface it when present, else say it's
# plugin-reported. This is the base-side plumbing; consumer plugins populate it.
plugin_janitor_state() {
    local name="$1" dir f
    dir="$(get_plugin_data_dir "$name" 2>/dev/null)"
    f="${dir}/janitor/state.json"
    if [ -n "$dir" ] && [ -f "$f" ]; then
        if command -v jq >/dev/null 2>&1 && jq -e . "$f" >/dev/null 2>&1; then
            jq -r '"last_sweep=\(.last_sweep // "?") evictions=\(.evictions // 0) write_errors=\(.write_errors // 0)"' "$f" 2>/dev/null
        else
            head -1 "$f" 2>/dev/null
        fi
        return 0
    fi
    printf 'n/a (reported by plugin)'
    return 0
}

# Single-shot live health of a plugin's units (no polling). One of:
#   healthy | unhealthy | unknown | stopped
# "unknown" = running but no declared healthcheck; "stopped" = nothing up.
plugin_health_now() {
    local name="$1" deploy cc proj ids id run st total=0 healthy=0 unhealthy=0 nohc=0 running=0
    deploy="$(get_deployment_type 2>/dev/null || echo docker-compose)"
    if [ "$deploy" = "kubernetes" ]; then
        local release ready desired
        command -v kubectl >/dev/null 2>&1 || { printf 'unknown'; return 0; }
        release="$(_obs_helm_release "$name")"
        ready="$(kubectl get deployment -n "$(_obs_k8s_ns)" -l "app.kubernetes.io/instance=${release}" \
                 -o jsonpath='{.items[*].status.readyReplicas}' 2>/dev/null | tr ' ' '+' )"
        desired="$(kubectl get deployment -n "$(_obs_k8s_ns)" -l "app.kubernetes.io/instance=${release}" \
                   -o jsonpath='{.items[*].status.replicas}' 2>/dev/null | tr ' ' '+' )"
        [ -z "$desired" ] && { printf 'stopped'; return 0; }
        ready="$(( ${ready:-0} ))"; desired="$(( ${desired:-0} ))"
        if [ "$desired" -eq 0 ]; then printf 'stopped';
        elif [ "$ready" -ge "$desired" ]; then printf 'healthy';
        else printf 'unhealthy'; fi
        return 0
    fi
    command -v docker >/dev/null 2>&1 || { printf 'unknown'; return 0; }
    cc="$(_plugin_compose_cmd)"
    proj="$(_obs_compose_project "$name")"
    ids="$($cc -p "$proj" ps -q 2>/dev/null)"
    # The compose plugin can be unavailable in non-login contexts (diagnose,
    # cron) and silently yields nothing; the compose project label on the
    # containers is authoritative either way.
    [ -z "$ids" ] && ids="$(docker ps -aq --filter "label=com.docker.compose.project=${proj}" 2>/dev/null)"
    [ -z "$ids" ] && { printf 'stopped'; return 0; }
    for id in $ids; do
        # One-shot init helpers (restart:"no") exit after seeding dirs; don't let them gate health.
        [ "$(docker inspect --format '{{.HostConfig.RestartPolicy.Name}}' "$id" 2>/dev/null)" = "no" ] && continue
        total=$((total + 1))
        run="$(docker inspect --format '{{.State.Running}}' "$id" 2>/dev/null)"
        [ "$run" = "true" ] && running=$((running + 1))
        st="$(docker inspect --format '{{if .State.Health}}{{.State.Health.Status}}{{else}}none{{end}}' "$id" 2>/dev/null)"
        case "$st" in
            healthy)   healthy=$((healthy + 1)) ;;
            unhealthy) unhealthy=$((unhealthy + 1)) ;;
            *)         nohc=$((nohc + 1)) ;;
        esac
    done
    if [ "$unhealthy" -gt 0 ]; then printf 'unhealthy';
    elif [ "$running" -eq 0 ]; then printf 'stopped';   # containers exist but none running (contract above)
    elif [ "$total" -gt 0 ] && [ "$healthy" -eq "$total" ]; then printf 'healthy';
    elif [ "$total" -gt 0 ] && [ "$running" -eq "$total" ]; then printf 'unknown';
    else printf 'unhealthy'; fi
    return 0
}

# Inherited-vs-override env keys for a plugin. A key set in the plugin .env that
# ALSO exists in the base .env is an OVERRIDE; base keys absent from the plugin
# .env are INHERITED. Prints two summary lines. Used by `info`/status.
plugin_env_provenance() {
    local name="$1" base plug bk pk overrides="" plugin_only="" inherited_count=0 k
    base="$(get_config_file 2>/dev/null)"
    plug="$(get_plugin_env_file "$name" 2>/dev/null)"
    [ -f "$plug" ] || { printf 'overrides: (none)\ninherited: all base keys (no plugin .env)\n'; return 0; }
    bk="$(mktemp)"; pk="$(mktemp)"
    [ -f "$base" ] && cut -d= -f1 "$base" 2>/dev/null | grep -E '^[A-Za-z_][A-Za-z0-9_]*$' | sort -u > "$bk"
    cut -d= -f1 "$plug" 2>/dev/null | grep -E '^[A-Za-z_][A-Za-z0-9_]*$' | sort -u > "$pk"
    while IFS= read -r k; do
        [ -z "$k" ] && continue
        if grep -qxF -- "$k" "$bk" 2>/dev/null; then overrides="${overrides} ${k}"; else plugin_only="${plugin_only} ${k}"; fi
    done < "$pk"
    if [ -f "$base" ]; then
        while IFS= read -r k; do
            [ -z "$k" ] && continue
            grep -qxF -- "$k" "$pk" 2>/dev/null || inherited_count=$((inherited_count + 1))
        done < "$bk"
    fi
    rm -f "$bk" "$pk"
    overrides="${overrides# }"; plugin_only="${plugin_only# }"
    printf 'overrides: %s\n' "${overrides:-(none)}"
    printf 'plugin-only: %s\n' "${plugin_only:-(none)}"
    printf 'inherited: %s base key(s)\n' "$inherited_count"
    return 0
}

export -f plugin_storage_mode plugin_dlq_depth plugin_disk_usage \
    plugin_janitor_state plugin_health_now plugin_env_provenance 2>/dev/null || true
