#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
#
# Rollback engine (idempotent teardown of a failed install).

if [ -n "${_BITOARCH_PLUGIN_ROLLBACK_LOADED:-}" ]; then
    return 0
fi
_BITOARCH_PLUGIN_ROLLBACK_LOADED=1

_rb_log() { type log_silent >/dev/null 2>&1 && log_silent "plugin rollback: $1"; }

plugin_rollback_install() {
    local name="$1" dir="${2:-}" manifest="${3:-}"
    local rec db user
    rec="$(journal_get_plugin "$name" 2>/dev/null)"
    _rb_log "rolling back install of '${name}'"

    if type _plugin_undeploy >/dev/null 2>&1 && [ -n "$dir" ] && [ -n "$manifest" ]; then
        _plugin_undeploy "$name" "$dir" "$manifest" --purge 2>/dev/null || true
    fi

    if [ -n "$rec" ] && type plugin_mysql_deprovision >/dev/null 2>&1; then
        db="$(printf '%s' "$rec" | jq -r '.db.name // ""' 2>/dev/null)"
        user="$(printf '%s' "$rec" | jq -r '.db.user // ""' 2>/dev/null)"
        if [ -n "$db" ] && [ "$db" != "null" ]; then
            plugin_mysql_deprovision "$db" "$user" 2>/dev/null || true
        fi
    fi

    # Pack teardown progress goes to the log, not the terminal (spinner prints on stdout).
    local _rblog; _rblog="$(get_setup_log 2>/dev/null || echo /dev/null)"
    type dep_release_requires >/dev/null 2>&1 && dep_release_requires "$name" >>"$_rblog" 2>&1 || true

    # purge=1 removes skills this failed install promoted fresh; the binary is forward-only.
    type wingman_skill_teardown >/dev/null 2>&1 && wingman_skill_teardown "$name" 1 2>/dev/null || true

    local install_dir data_dir
    install_dir="$(get_plugin_install_dir "$name" 2>/dev/null)"
    data_dir="$(get_plugin_data_dir "$name" 2>/dev/null)"
    [ -n "$install_dir" ] && rm -rf "$install_dir" 2>/dev/null || true
    # Keep the config dir: operator-entered values (PUBLIC_URL, creds) survive a
    # failed install so the retry reuses them — same contract as non-purge uninstall.
    [ -n "$data_dir" ] && [ -d "$data_dir" ] && rm -rf "$data_dir" 2>/dev/null || true

    # Drop the journal entry last, so a crash during rollback still has a record.
    journal_remove_plugin "$name" 2>/dev/null || true
    _rb_log "rollback of '${name}' complete"
}
