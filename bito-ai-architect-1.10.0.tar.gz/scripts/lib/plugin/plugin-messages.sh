#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
#
# User-facing copy + prompt labels for `bitoarch plugin`, kept out of engine logic in one place.
# Renders through platform primitives (print_*/colors/glyphs). Add a message = add one `_pm_*` function.

if [ -n "${_BITOARCH_PLUGIN_MESSAGES_LOADED:-}" ]; then
    return 0
fi
_BITOARCH_PLUGIN_MESSAGES_LOADED=1

# Render helpers — platform print_* when present, else a plain fallback (errors/warnings to stderr, info/success to stdout).
_pm_ok()   { if type print_success >/dev/null 2>&1; then print_success "$1"; else printf '%s\n' "$1"; fi; }
_pm_info() { if type print_info    >/dev/null 2>&1; then print_info "$1";    else printf '%s\n' "$1"; fi; }
_pm_warn() { if type print_warning >/dev/null 2>&1; then print_warning "$1" >&2; else printf '%s\n' "$1" >&2; fi; }
_pm_err()  { if type print_error   >/dev/null 2>&1; then print_error "$1" >&2; else printf '%s\n' "$1" >&2; fi; }
# Indented command/next-step line under a message (cyan, like the platform).
_pm_step() { printf '   %b%s%b\n' "${CYAN:-}" "$1" "${NC:-}" >&2; }

# ── install / activation ─────────────────────────────────────────────────────
_pm_installed()         { _pm_ok "Plugin '$1' installed."; }             # <name>
_pm_applying()    { printf '   ⏳ Starting '"'"'%s'"'"'... %b(takes under a minute)%b\n' "$1" "${DIM:-}" "${NC:-}" >&2; }  # <name>
_pm_restarting()  { printf '⏳ Restarting '"'"'%s'"'"'... %b(takes under a minute)%b\n' "$1" "${DIM:-}" "${NC:-}" >&2; }  # <name> (flush-left: standalone restart/config-apply only)
_pm_stopped()     { _pm_ok "'$1' stopped."; _pm_step "bitoarch plugin start $1   # bring it back"; }  # <name>



# Docs link from the centralized constant (never a hardcoded URL). Optional.
_pm_docs() { [ -n "${PLUGINS_DOCS_URL:-}" ] && printf '   %bDocs: %s%b\n' "${CYAN:-}" "${PLUGINS_DOCS_URL}" "${NC:-}"; }
_pm_setup_skipped() { _pm_info "Skipped. Start '$1' when you are ready:"; _pm_step "bitoarch plugin start $1"; }

# Print "LABEL<TAB>URL" lines from stdin, column-aligned under a heading (endpoints to register with the provider). No-op when none.
_pm_endpoints() {
    local heading="$1" label url i max=0
    local -a labels=() urls=()
    while IFS="$(printf '\t')" read -r label url; do
        [ -n "$url" ] || continue
        labels+=("$label"); urls+=("$url")
        [ "${#label}" -gt "$max" ] && max="${#label}"
    done
    [ "${#urls[@]}" -gt 0 ] || return 0
    echo ""
    _pm_info "${heading:-Endpoints to register with your integration provider:}"
    for i in "${!urls[@]}"; do
        printf '   %b%-*s%b  %s\n' "${CYAN:-}" "$max" "${labels[$i]}" "${NC:-}" "${urls[$i]}"
    done
}

# ── prompt labels (for `read -p`) ────────────────────────────────────────────
_pm_pause_prompt() { printf '\n   › Press Enter when done — or '"'"'s'"'"' to skip and finish setup later: '; }
_pm_generated()    { type log_silent >/dev/null 2>&1 && log_silent "generated $1 secret(s) automatically"; return 0; }   # silent (count)
_pm_cred_prompt()  { printf '   › %s: ' "$1"; }                   # <label>
_pm_value_prompt() { if [ -n "$2" ]; then printf '   › %s [%s]: ' "$1" "$2"; else printf '   › %s: ' "$1"; fi; }   # <label> <current>
_pm_add_plugin_prompt()    { printf 'Add a plugin now? [y/N]: '; }
_pm_plugin_source_prompt() { printf '  Plugin source (path or .tar.gz, blank to finish): '; }

# ── not-installed / start guidance ───────────────────────────────────────────
_pm_not_installed() {                                             # <name>
    _pm_err "Plugin '$1' is not installed."
    printf '%b💡%b To install, run: %bbitoarch plugin install %s%b\n' \
        "${BLUE:-}" "${NC:-}" "${YELLOW:-}" "$1" "${NC:-}" >&2
}

# ── UX revamp: section heading + numbered phases (plugin-install-ux-final) ─────
# All render to STDERR (interactive progress) and re-read color vars at call time, so the module is safe sourced standalone.

# _pm_section "<title>" — the 🔌 plugin heading: bold+blue title + one thin rule line. Top-level only.
_pm_section() {                                                   # <title>
    # Rule width matches the heading's display width: "🔌 Setting up: " spans 15 cells
    # (🔌 renders 2-wide) plus the title (ASCII plugin names are one cell per char).
    local title="$1" rule="" i=0 width=$(( 15 + ${#1} ))
    while [ "$i" -lt "$width" ]; do rule="${rule}━"; i=$((i + 1)); done
    printf '\n%b🔌 Setting up: %s%b\n' "${BOLD:-}${BLUE:-}" "$title" "${NC:-}" >&2
    printf '%b%s%b\n' "${BLUE:-}" "$rule" "${NC:-}" >&2
}

# _pm_phase <n> <total> <title> [emoji] — "Step n of total — Title", bold white.
# Manifest-declared step emojis render when provided: "Step n of total — <emoji> Title".
_pm_phase() {                                                     # <n> <total> <title> [emoji]
    local n="$1" total="$2" title="$3" emoji="${4:-}"
    # ⚙️ renders one cell narrower than other emoji, so it alone needs an extra space to align.
    if [ -n "$emoji" ]; then
        case "$emoji" in "⚙️") title="$emoji  $title" ;; *) title="$emoji $title" ;; esac
    fi
    printf '\n%bStep %s of %s — %s%b\n' "${BOLD:-}" "$n" "$total" "$title" "${NC:-}" >&2
}

# Closing rule + banner before a plugin's own finish/next-steps block.
_pm_closing() {                                                   # <banner-text>
    local rule="━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    printf '\n%b%s%b\n' "${BLUE:-}" "$rule" "${NC:-}" >&2
    printf '%b✅ %s%b\n' "${GREEN:-}" "$1" "${NC:-}" >&2
}

# Amber close when a setup step reported a problem: installed, but not complete.
_pm_closing_warn() {                                              # <name>
    local rule="━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    printf '\n%b%s%b\n' "${BLUE:-}" "$rule" "${NC:-}" >&2
    printf '%b⚠️  %s installation is not complete%b\n' "${YELLOW:-}" "$1" "${NC:-}" >&2
    printf '%b💡%b To complete, run: %bbitoarch plugin install %s%b\n' "${BLUE:-}" "${NC:-}" "${YELLOW:-}" "$1" "${NC:-}" >&2
    printf '\n' >&2   # separate consecutive plugin blocks in multi-plugin onboarding
}



