#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
#
# Wire a plugin to the on-prem MCP server (cis-provider).
#
# Wingman inside a plugin container just needs to reach the provider, which runs
# in BOTH deployment modes, so both reach it the SAME way -- directly in-network
# by service name -- and only the scheme/port differ, derived from the base
# platform config:
#   standalone (MCP_TRANSPORT=https): https://<provider>:<XMCP_HTTPS_PORT>/mcp
#   enterprise (MCP_TRANSPORT=http) : http://<provider>:<XMCP_HTTP_PORT>/mcp
# The provider's TLS cert carries the service name in its SAN (see mcp-cert.sh),
# so the name validates; Standalone additionally needs the mkcert root CA trusted
# by the container, which we publish onto the shared data volume and point the
# plugin's NODE_EXTRA_CA_CERTS at (via the injected MCP_CA_CERT). Enterprise is
# plain HTTP and needs neither.

if [ -n "${_BITOARCH_PLUGIN_MCP_ENV_LOADED:-}" ]; then
    return 0
fi
_BITOARCH_PLUGIN_MCP_ENV_LOADED=1

_BITOARCH_PLUGIN_MCPENV_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if ! type get_config_file >/dev/null 2>&1; then
    # shellcheck source=scripts/lib/path-manager.sh
    . "${_BITOARCH_PLUGIN_MCPENV_DIR}/../path-manager.sh" 2>/dev/null || true
fi
if ! type plugin_env_set >/dev/null 2>&1; then
    # shellcheck source=scripts/lib/plugin/env-merger.sh
    . "${_BITOARCH_PLUGIN_MCPENV_DIR}/env-merger.sh" 2>/dev/null || true
fi
if ! type _wingman_fs_apply >/dev/null 2>&1; then
    # shellcheck source=scripts/lib/wingman-shelf.sh
    . "${_BITOARCH_PLUGIN_MCPENV_DIR}/../wingman-shelf.sh" 2>/dev/null || true
fi

_mcpenv_log() { type log_silent >/dev/null 2>&1 && log_silent "plugin mcp-env: $1"; }

# Resolve the mkcert ROOT CA path on the host -- what NODE_EXTRA_CA_CERTS must
# point at to validate the provider's HTTPS leaf in Standalone. Echoes a path
# that may not exist when mkcert was never run; the caller tests -f before use.
_plugin_mcp_ca_path() {
    local mkcert_bin="" caroot=""
    if command -v mkcert >/dev/null 2>&1; then
        mkcert_bin="$(command -v mkcert)"
    elif command -v get_user_cache_dir >/dev/null 2>&1 && \
         [ -x "$(get_user_cache_dir)/bin/mkcert" ]; then
        mkcert_bin="$(get_user_cache_dir)/bin/mkcert"
    fi
    if [ -n "$mkcert_bin" ]; then
        caroot="$("$mkcert_bin" -CAROOT 2>/dev/null)"
        if [ -n "$caroot" ] && [ -f "$caroot/rootCA.pem" ]; then
            echo "$caroot/rootCA.pem"
            return 0
        fi
    fi
    case "$(uname -s)" in
        Darwin) echo "${HOME}/Library/Application Support/mkcert/rootCA.pem" ;;
        Linux)  echo "${XDG_DATA_HOME:-${HOME}/.local/share}/mkcert/rootCA.pem" ;;
        *)      echo "${HOME}/.local/share/mkcert/rootCA.pem" ;;
    esac
}

# Read one key from the base .env-bitoarch (values there are not exported into
# the install shell). Strips surrounding quotes; empty when unset/absent.
_plugin_mcp_cfg_get() {
    local key="$1" f
    f="$(get_config_file 2>/dev/null)"
    [ -n "$f" ] && [ -f "$f" ] || return 0
    sed -n "s/^${key}=//p" "$f" 2>/dev/null | head -1 \
        | sed -e 's/^"//' -e 's/"$//' -e "s/^'//" -e "s/'\$//"
}

# Echo the in-network MCP URL for this deployment, derived from the base config.
# Same host (the provider service name) in both modes; scheme + port differ.
plugin_mcp_url() {
    local transport host port
    transport="$(_plugin_mcp_cfg_get MCP_TRANSPORT)"; transport="${transport:-http}"
    host="$(_plugin_mcp_cfg_get MCP_SERVER_NAME)";     host="${host:-ai-architect-provider}"
    if [ "$transport" = "https" ]; then
        port="$(_plugin_mcp_cfg_get XMCP_HTTPS_PORT)"; port="${port:-3443}"
        echo "https://${host}:${port}/mcp"
    else
        port="$(_plugin_mcp_cfg_get XMCP_HTTP_PORT)";  port="${port:-8080}"
        echo "http://${host}:${port}/mcp"
    fi
}

# Standalone only: copy the mkcert root CA onto the shared data volume (in-
# container, via the write-bridge -- the host cannot write the volume directly)
# so plugin containers can trust the provider's HTTPS cert. Echoes the in-
# container CA path on success, empty otherwise. Best-effort: never fails the
# caller (enterprise needs no CA; a missing CA just leaves it to system trust).
plugin_publish_mcp_ca() {
    local transport ca_host target tmp script
    transport="$(_plugin_mcp_cfg_get MCP_TRANSPORT)"; transport="${transport:-http}"
    [ "$transport" = "https" ] || return 0

    ca_host="$(_plugin_mcp_ca_path 2>/dev/null)"
    if [ -z "$ca_host" ] || [ ! -f "$ca_host" ]; then
        _mcpenv_log "no mkcert root CA found; skipping CA publish (the container will rely on system trust)"
        return 0
    fi

    target="$(get_mcp_ca_shared_path)"

    # Stage just the public CA into its own dir so the write-bridge never mounts
    # the mkcert CAROOT (which also holds rootCA-key.pem) into the one-shot. Stage
    # under the user cache (a host path the container runtime already shares --
    # the provider bind-mounts certs from here); system temp dirs (/var/folders,
    # /tmp) are not mounted into Colima/Docker Desktop VMs, so a bind-mount there
    # would be empty.
    local base
    base="$(type get_user_cache_dir >/dev/null 2>&1 && get_user_cache_dir)"
    [ -n "$base" ] || base="${HOME}/.cache/bitoarch"
    tmp="${base}/.mcp-ca-publish.$$"
    if ! mkdir -p "$tmp" 2>/dev/null || ! cp "$ca_host" "${tmp}/rootCA.pem" 2>/dev/null; then
        rm -rf "$tmp"; return 0
    fi

    script="$(cat <<EOSH
set -e
mkdir -p '$(dirname "$target")'
cp "\$SRC/rootCA.pem" '${target}'
chmod 0644 '${target}'
EOSH
)"
    if _wingman_fs_apply "$tmp" "$script"; then
        rm -rf "$tmp"
        _mcpenv_log "published MCP root CA to ${target}"
        echo "$target"
        return 0
    fi
    rm -rf "$tmp"
    _mcpenv_log "failed publishing MCP root CA to the shared volume"
    return 0
}

# Inject the derived MCP wiring into the plugin's env file. LOCAL_MCP_URL is the
# in-network endpoint; MCP_CA_CERT is the in-container CA path (empty in
# enterprise / when no CA is available) which the plugin maps to
# NODE_EXTRA_CA_CERTS. Always sets both so a re-inject clears stale values.
plugin_inject_mcp_env() {
    local env_file="$1" url ca
    [ -n "$env_file" ] || return 0
    url="$(plugin_mcp_url)"
    [ -n "$url" ] && plugin_env_set "$env_file" LOCAL_MCP_URL "$url"
    ca="$(plugin_publish_mcp_ca)"
    plugin_env_set "$env_file" MCP_CA_CERT "$ca"
    _mcpenv_log "injected LOCAL_MCP_URL=${url} MCP_CA_CERT=${ca:-<none>}"
    return 0
}
