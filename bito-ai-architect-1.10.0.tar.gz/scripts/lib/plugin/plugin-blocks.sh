#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
#
# Rich RESULT/summary blocks for `bitoarch plugin` (verb outcomes), mirroring the base output-blocks.sh render_* style.
# Render to stdout using the platform color vars with empty fallbacks, so the module is safe sourced standalone.

if [ -n "${_BITOARCH_PLUGIN_BLOCKS_LOADED:-}" ]; then
    return 0
fi
_BITOARCH_PLUGIN_BLOCKS_LOADED=1

# Local color aliases default to the platform vars and degrade to empty; never redefine the platform vars.
_PB_GREEN="${GREEN:-}"; _PB_BLUE="${BLUE:-}"; _PB_YELLOW="${YELLOW:-}"
_PB_RED="${RED:-}"; _PB_BOLD="${BOLD:-}"; _PB_NC="${NC:-}"

# Re-resolve at call time so a color var set AFTER this file is sourced is honored.
_pb_c() { eval "printf '%b' \"\${$1:-}\""; }


# 📊 / 📁 section header. _pb_section_data "<title>" ; _pb_section_list "<title>".
_pb_section_data() { printf '%b📊 %s%b\n' "$(_pb_c BLUE)" "$1" "$(_pb_c NC)"; }
_pb_section_list() { printf '%b📁 %s%b\n' "$(_pb_c BLUE)" "$1" "$(_pb_c NC)"; }


# ── install ──────────────────────────────────────────────────────────────────
# Healthy install: one green ✅ line; details belong in `plugin status`. <version>/<health> kept for call-site compat.
render_plugin_install_success_block() {   # <name> <version> <health>
    local name="$1"
    printf '\n%b✅ %s is installed and running successfully%b\n' "$(_pb_c GREEN)" "$name" "$(_pb_c NC)"
}

# Installed but not yet running and recoverable. Amber warning (not a hard fail). <reason>: needs-setup | unhealthy.
# needs-setup (missing required config): terse two-liner -- `plugin config` collects the
# missing values and restarts. unhealthy: containers exist but did not go healthy -- `plugin start`.
render_plugin_install_needs_attention_block() {   # <name> <version> <reason>
    local name="$1" reason="${3:-unhealthy}"
    echo ""
    if [ "$reason" = "needs-setup" ]; then
        printf '%b⚠️  %s installation incomplete%b\n' "$(_pb_c YELLOW)" "$name" "$(_pb_c NC)"
        printf '   To continue, run:  %bbitoarch plugin config %s%b\n' "$(_pb_c YELLOW)" "$name" "$(_pb_c NC)"
    else
        printf '%b⚠️  %s is installed, but not running yet%b\n' "$(_pb_c YELLOW)" "$name" "$(_pb_c NC)"
        printf '   It did not become healthy in time.\n'
        printf '   Check and start it:  %bbitoarch plugin start %s%b\n' "$(_pb_c YELLOW)" "$name" "$(_pb_c NC)"
    fi
    echo ""
}

# ── uninstall ────────────────────────────────────────────────────────────────
# Default uninstall keeps data + config (a reinstall reuses them); customer-facing copy.
render_plugin_uninstalled_block() {   # <name>
    local name="$1"
    echo ""
    printf "%b✅ Plugin '%s' uninstalled.%b\n" "$(_pb_c GREEN)" "$name" "$(_pb_c NC)"
    echo ""
}
# --purge: the data + config were removed too.
render_plugin_uninstalled_purged_block() {   # <name>
    local name="$1"
    echo ""
    printf "%b✅ Plugin '%s' uninstalled and its data removed.%b\n" "$(_pb_c GREEN)" "$name" "$(_pb_c NC)"
    echo ""
}

