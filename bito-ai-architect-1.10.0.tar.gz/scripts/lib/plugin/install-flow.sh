#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
#
# Install flow.

if [ -n "${_BITOARCH_PLUGIN_INSTALL_FLOW_LOADED:-}" ]; then
    return 0
fi
_BITOARCH_PLUGIN_INSTALL_FLOW_LOADED=1

_BITOARCH_PLUGIN_INSTALL_DIR_SELF="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
for _m in path-manager.sh:get_plugin_install_dir \
          plugin/plugin-messages.sh:_pm_installed \
          plugin/plugin-blocks.sh:render_plugin_install_success_block \
          plugin/ingress.sh:ingress_sync \
          plugin/state-journal.sh:journal_put_plugin \
          plugin/manifest-parser.sh:manifest_name \
          plugin/plugin-http.sh:plugin_http \
          plugin/plugin-entitlement.sh:plugin_check_entitlement \
          plugin/plugin-schema.sh:validate_manifest \
          plugin/env-merger.sh:plugin_env_merge \
          plugin/reserved-keys.sh:_plugin_key_is_secret \
          plugin/mysql-provisioner.sh:plugin_mysql_provision \
          plugin/dependency-manager.sh:dep_resolve_requires \
          plugin/wingman-skills.sh:wingman_resolve \
          plugin/mcp-env.sh:plugin_inject_mcp_env \
          plugin/hooks-runner.sh:plugin_run_hook \
          plugin/deploy.sh:_plugin_deploy \
          plugin/rollback.sh:plugin_rollback_install; do
    _fn="${_m##*:}"; _rel="${_m%%:*}"
    if ! type "$_fn" >/dev/null 2>&1; then
        case "$_rel" in
            path-manager.sh) . "${_BITOARCH_PLUGIN_INSTALL_DIR_SELF}/../path-manager.sh" 2>/dev/null || true ;;
            plugin/*)        . "${_BITOARCH_PLUGIN_INSTALL_DIR_SELF}/${_rel#plugin/}" 2>/dev/null || true ;;
        esac
    fi
done
unset _m _fn _rel

_if_err()  { if type print_error >/dev/null 2>&1; then print_error "$1" >&2; else printf 'ERROR: %s\n' "$1" >&2; fi; type log_silent >/dev/null 2>&1 && log_silent "plugin install: $1"; }
_if_info() { if type print_info  >/dev/null 2>&1; then print_info "$1"; else printf '%s\n' "$1"; fi; }
_if_log()  { type log_silent >/dev/null 2>&1 && log_silent "plugin install: $1"; }

# Verify a CDN-downloaded tarball against the pointer's SHA-256 + GPG signature,
# mirroring the auto-updater (same trust rules, one shared implementation). Covers
# BOTH `plugin install <name>` and `plugin upgrade` (both route through the CDN
# branch below). Operator-provided local paths/tarballs are NOT verified — that is
# an explicit trust decision by whoever passes the file. rc 0 = ok to stage; 1 = reject.
_plugin_verify_cdn_tarball() {   # <tarball> <meta-json> <cdn-base> <name> <version>
    local tb="$1" meta="$2" cdn="$3" name="$4" ver="$5" sha asc asc_tmp grc actual
    type _pu_verify_gpg >/dev/null 2>&1 || . "$(dirname "${BASH_SOURCE[0]}")/plugin-updater.sh" 2>/dev/null || true
    sha="$(printf '%s' "$meta" | jq -r '.sha256 // empty' 2>/dev/null)"
    asc="$(printf '%s' "$meta" | jq -r '.asc // false'  2>/dev/null)"
    # SHA-256: mandatory when the pointer advertises one.
    if [ -n "$sha" ] && type _pu_sha256 >/dev/null 2>&1; then
        actual="$(_pu_sha256 "$tb")"
        if [ -z "$actual" ] || [ "$actual" != "$sha" ]; then
            _if_err "SHA-256 mismatch for ${name} v${ver} (expected ${sha}, got ${actual:-none}); refusing to install."
            return 1
        fi
    fi
    # GPG detached signature (fetch .asc when the pointer says it is signed).
    asc_tmp=""
    if [ "$asc" = "true" ]; then
        asc_tmp="${tb}.asc"
        curl -sfL -m 60 "${cdn}/${name}/${ver}/${name}-${ver}.tar.gz.asc" -o "$asc_tmp" 2>/dev/null || asc_tmp=""
    fi
    if type _pu_verify_gpg >/dev/null 2>&1; then
        _pu_verify_gpg "$tb" "$asc_tmp"; grc=$?
        rm -f "$asc_tmp" 2>/dev/null
        if [ "$grc" -eq 1 ]; then
            _if_err "signature verification failed for ${name} v${ver}; refusing to install."
            return 1
        fi
    fi
    return 0
}

# Resolve a source (dir or .tar.gz) to a staging directory (printed on stdout — keep all UX on stderr).
_plugin_stage_source() {
    local src="$1" staged top
    # Log once per install (setup.log, not the terminal): the CDN name path recurses with the downloaded tarball.
    if [ -z "${_PLUGIN_STAGE_BANNERED:-}" ]; then
        _PLUGIN_STAGE_BANNERED=1
        type log_silent >/dev/null 2>&1 && log_silent "plugin install: preparing the plugin package"
    fi
    if [ -d "$src" ]; then printf '%s' "$src"; return 0; fi
    if [ -f "$src" ]; then
        case "$src" in
            *.tar.gz|*.tgz)
                staged="$(mktemp -d)"
                # Capture tar's own error to the log; keep the terminal message clean.
                local _tar_err
                if ! _tar_err="$(tar -xzf "$src" -C "$staged" 2>&1)"; then
                    type log_silent >/dev/null 2>&1 && log_silent "plugin install: tar extract failed for '$src': ${_tar_err}"
                    _if_err "failed to extract plugin tarball: $src"; return 1
                fi
                if [ ! -f "$staged/plugin.yaml" ]; then
                    top="$(find "$staged" -mindepth 1 -maxdepth 1 -type d | head -1)"
                    [ -n "$top" ] && [ -f "$top/plugin.yaml" ] && staged="$top"
                fi
                printf '%s' "$staged"; return 0 ;;
            *) _if_err "unrecognized plugin source file (expected a directory or .tar.gz): $src"; return 1 ;;
        esac
    fi
    # Bare plugin name: resolve the published build from the plugins CDN.
    if printf '%s' "$src" | grep -Eq '^[a-z][a-z0-9-]*$' && ! command -v curl >/dev/null 2>&1; then
        _if_err "installing '${src}' by name needs curl. Install curl."
        return 1
    fi
    # A bare name resolves to a LOCAL package first (BITOARCH_PLUGIN_PACKAGES_DIR
    # or the bundled samples): air-gap native, and the CDN is only consulted when
    # no local package exists.
    if printf '%s' "$src" | grep -Eq '^[a-z][a-z0-9-]*$'; then
        local _lpd=""
        if type _plugin_bundled_packages_dir >/dev/null 2>&1; then _lpd="$(_plugin_bundled_packages_dir)"
        else
            . "$(dirname "${BASH_SOURCE[0]}")/preseed.sh" 2>/dev/null || true
            type _plugin_bundled_packages_dir >/dev/null 2>&1 && _lpd="$(_plugin_bundled_packages_dir)"
        fi
        if [ -n "$_lpd" ] && [ -f "$_lpd/$src/plugin.yaml" ]; then
            type log_silent >/dev/null 2>&1 && log_silent "plugin install: '$src' resolved from the local packages dir (${_lpd})"
            printf '%s' "$_lpd/$src"; return 0
        fi
    fi
    if printf '%s' "$src" | grep -Eq '^[a-z][a-z0-9-]*$' && command -v curl >/dev/null 2>&1 && command -v jq >/dev/null 2>&1; then
        local _cdn="${PLUGINS_CDN_BASE_URL:-${BITOARCH_PLUGIN_DOWNLOAD_URL:-https://aiarch.bito.ai}/ai-architect-plugins}" _meta _rver _tb
        _meta="$(curl -sfL -m 10 "${_cdn}/${src}/${src}-latest.json" 2>/dev/null)"
        _rver="$(printf '%s' "$_meta" | jq -r '.version // empty' 2>/dev/null)"
        if [ -n "$_rver" ]; then
            _tb="$(mktemp -d)/${src}-${_rver}.tar.gz"
            # Loader UI on stderr: this function's stdout is the staging dir.
            local _dl_rc
            if type progress_run >/dev/null 2>&1; then
                progress_run "Downloading ${src} v${_rver}" -- \
                    curl -sfL -m 300 "${_cdn}/${src}/${_rver}/${src}-${_rver}.tar.gz" -o "$_tb" >&2
                _dl_rc=$?
            else
                _if_info "Downloading ${src} v${_rver}..." >&2
                curl -sfL -m 300 "${_cdn}/${src}/${_rver}/${src}-${_rver}.tar.gz" -o "$_tb" 2>/dev/null
                _dl_rc=$?
            fi
            if [ "$_dl_rc" -eq 0 ]; then
                _plugin_verify_cdn_tarball "$_tb" "$_meta" "$_cdn" "$src" "$_rver" || return 1
                _plugin_stage_source "$_tb"
                return $?
            fi
            _if_err "download failed for ${src} v${_rver} from ${_cdn}."
            return 1
        fi
        # Well-formed name but no metadata: the CDN answered nothing — say so, not "not found".
        _if_err "could not resolve '${src}' from the plugin CDN (${_cdn}). Check network/proxy access."
        printf '   See available plugin names: %bbitoarch plugin list%b\n' "${YELLOW:-}" "${NC:-}" >&2
        return 1
    fi
    _if_err "plugin source '${src}' not found. Provide a published plugin name."
    printf '   See available plugin names: %bbitoarch plugin list%b\n' "${YELLOW:-}" "${NC:-}" >&2
    return 1
}

_plugin_locate_manifest() {
    local dir="$1"
    if [ -f "$dir/plugin.yaml" ]; then printf '%s' "$dir/plugin.yaml"; return 0; fi
    _if_err "no plugin.yaml found in: $dir"; return 1
}

_plugin_install_preflight() {
    [ "${BITOARCH_PLUGIN_SKIP_PREFLIGHT:-0}" = "1" ] && return 0
    if [ -z "${MYSQL_ROOT_PASSWORD:-}" ]; then
        _if_err "pre-flight failed: MYSQL_ROOT_PASSWORD is not set (base MySQL admin credential required to provision the plugin database)"
        return 1
    fi
    _plugin_preflight_workspace || return 1
    return 0
}

# Plugins resolve workspace context and credentials from cis-config. A box where the
# initial deployment stopped before `add-repos` (for example an image-pull timeout)
# has no workspace entry yet: fail up front with recovery steps, not a broken install.
_plugin_preflight_workspace() {
    local url resp _cfg_port
    type plugin_http >/dev/null 2>&1 || . "${_BITOARCH_PLUGIN_INSTALL_DIR_SELF}/plugin-http.sh" 2>/dev/null || return 0
    _cfg_port="${CIS_CONFIG_EXTERNAL_PORT:-5003}"
    # K8s: the config service is ClusterIP-only — establish the on-demand port-forward
    # first (the same path every other CLI call uses); a node IP has no NodePort.
    # The CLI env derives CONFIG_URL=http://localhost:<port> by default, so a
    # localhost value still needs the tunnel; only a real remote override skips it.
    # The helper lives outside the plugin dir, so load it lazily here.
    local _cfg_is_local=1
    case "${CONFIG_URL:-}" in
        ''|*"://localhost"*|*"://127.0.0.1"*) _cfg_is_local=1 ;;
        *)                                    _cfg_is_local=0 ;;
    esac
    if [ "$_cfg_is_local" -eq 1 ] && [ "$(get_deployment_type 2>/dev/null)" = "kubernetes" ]; then
        type ensure_service_accessible >/dev/null 2>&1 \
            || . "${_BITOARCH_PLUGIN_INSTALL_DIR_SELF}/../k8s-port-forward.sh" 2>/dev/null || true
        type ensure_service_accessible >/dev/null 2>&1 \
            && { ( ensure_service_accessible "ai-architect-config" "$_cfg_port" ) >/dev/null 2>&1 || true; }
    fi
    # CONFIG_URL (set by load_env_config) wins; else the shared resolver builds the local URL.
    url="$(plugin_service_base "$_cfg_port" "${CONFIG_URL:-}")"
    # Short bounded retry: the on-demand port-forward needs a moment to bind.
    local _try=0
    while :; do
        resp="$(plugin_http GET "$url" "/api/v1/config" "${BITO_API_KEY:-}" 2>/dev/null)"
        [ -n "$resp" ] && break
        _try=$((_try + 1)); [ "$_try" -ge 4 ] && break
        sleep 1
    done
    if [ -z "$resp" ]; then
        _if_err "AI Architect is not running — start the platform before managing plugins."
        printf '   %b💡%b Check: %bbitoarch status%b · Start: %bbitoarch start%b\n' \
            "${BLUE:-}" "${NC:-}" "${YELLOW:-}" "${NC:-}" "${YELLOW:-}" "${NC:-}" >&2
        return 1
    fi
    case "$resp" in *'"workspace_id"'*) return 0 ;; esac
    _if_err "pre-flight failed: no repositories configured yet — add at least one, then retry."
    printf '   Choose repositories:  %bbitoarch config edit repos%b\n' "${YELLOW:-}" "${NC:-}" >&2
    printf '   Load them:            %bbitoarch add-repos%b\n' "${YELLOW:-}" "${NC:-}" >&2
    return 1
}

_plugin_create_namespaces() {
    local manifest="$1" name="$2" item
    while IFS= read -r item; do [ -n "$item" ] && _if_log "topic for '${name}': ${item}"; done <<EOF
$(manifest_topics "$manifest" 2>/dev/null)
EOF
    while IFS= read -r item; do [ -n "$item" ] && _if_log "redis prefix for '${name}': ${item}"; done <<EOF
$(manifest_redis_prefixes "$manifest" 2>/dev/null)
EOF
    return 0
}

_plugin_existing_db_password() {
    local env_file="$1"
    [ -f "$env_file" ] || return 0
    sed -n 's/^PLUGIN_MYSQL_PASSWORD=//p' "$env_file" 2>/dev/null | head -1
}

_plugin_install_fail() {
    local name="$1" dir="$2" manifest="$3" msg="$4"
    _if_err "$msg"
    plugin_rollback_install "$name" "$dir" "$manifest"
    return 1
}

# Prompt only with a real terminal, not in a preseeded / CI install.
_if_interactive() { [ -t 0 ] && [ "${AUTO_SETUP:-}" != "true" ] && [ "${BITOARCH_NONINTERACTIVE:-0}" != "1" ]; }

# Humanize an ENV_KEY into a prompt-label fallback (API_BASE_URL -> "Api Base Url").
# ENV_KEY -> "Env Key" prompt label; well-known acronyms keep their casing (BITO_API_KEY -> "Bito API Key").
_plugin_humanize_key() {
    printf '%s' "$1" | tr '_' ' ' | awk '{
        for(i=1;i<=NF;i++){
            w=toupper($i)
            if (w=="API"||w=="URL"||w=="ID"||w=="MCP"||w=="LLM"||w=="DB"||w=="HTTP"||w=="HTTPS"||w=="SSO") $i=w
            else $i=toupper(substr($i,1,1)) tolower(substr($i,2))
        }
        print}'
}

# Accept a config value only if it has non-whitespace content (never store an empty required value).
_plugin_value_ok() { case "$1" in *[![:space:]]*) return 0 ;; *) return 1 ;; esac; }

# Generate a secret: hex32/hex16 -> 2N hex chars; base64-32 -> 32 bytes base64 (AES-256, openssl else /dev/urandom).
_plugin_gen_value() {
    local bytes
    case "$1" in
        hex32) bytes=32 ;;
        hex16) bytes=16 ;;
        base64-32)
            openssl rand -base64 32 2>/dev/null && return 0
            # Portable fallback (no GNU-isms): base64-encode 32 urandom bytes.
            if command -v base64 >/dev/null 2>&1; then
                head -c 32 /dev/urandom 2>/dev/null | base64 2>/dev/null | tr -d '\n' && { echo; return 0; }
            fi
            # Last resort: openssl enc, else a hex string (still non-empty; consumer's decode is authority).
            openssl enc -base64 < /dev/urandom 2>/dev/null | head -c 44 && { echo; return 0; }
            od -An -tx1 -N 32 /dev/urandom 2>/dev/null | tr -d ' \n'
            return 0 ;;
        *) return 1 ;;
    esac
    openssl rand -hex "$bytes" 2>/dev/null && return 0
    od -An -tx1 -N "$bytes" /dev/urandom 2>/dev/null | tr -d ' \n'
}

# Fill each unset config.required key with a `generate` method (so secrets aren't prompted). Idempotent.
_plugin_autogenerate_secrets() {
    local manifest="$1" env_file="$2" key method v n=0
    while IFS='|' read -r key method; do
        [ -z "$key" ] && continue
        [ -n "$(plugin_env_get "$env_file" "$key" 2>/dev/null)" ] && continue
        v="$(_plugin_gen_value "$method")" || continue
        [ -n "$v" ] && { plugin_env_set "$env_file" "$key" "$v"; n=$((n + 1)); }
    done <<EOF
$(manifest_config_generated_keys "$manifest" 2>/dev/null)
EOF
    [ "$n" -gt 0 ] && _pm_generated "$n"
    return 0
}

# ── UX-revamp helpers (phase-based install; unit-testable, no TTY required) ────

# Resolve the public ingress port for hint/URL display: INGRESS_PORT env, else the docker default host port.
_plugin_ingress_port() { echo "${INGRESS_PORT:-5080}"; }

# The k8s front-door address to expose, read from the LIVE controller Service so
# the guidance matches the actual exposure (bundled NodePort 30080/30443, hostPort
# 80/443, LoadBalancer, or a BYO controller) instead of a hardcoded guess. One
# quick kubectl read; falls back to the node's 80/443 when it can't be resolved.
_plugin_k8s_frontdoor() {
    [ -n "${BITOARCH_INGRESS_CLASS:-}" ] && { echo "your ingress controller (usually 80/443)"; return; }
    local ns="${BITOARCH_K8S_NAMESPACE:-bito-ai-architect}" t nph nps
    t="$(kubectl get svc ai-architect-ingress-controller -n "$ns" -o jsonpath='{.spec.type}' 2>/dev/null)"
    case "$t" in
        NodePort)
            nph="$(kubectl get svc ai-architect-ingress-controller -n "$ns" -o jsonpath='{.spec.ports[?(@.name=="http")].nodePort}' 2>/dev/null)"
            nps="$(kubectl get svc ai-architect-ingress-controller -n "$ns" -o jsonpath='{.spec.ports[?(@.name=="https")].nodePort}' 2>/dev/null)"
            echo "the ingress NodePort (<nodeIP>:${nph:-30080} / ${nps:-30443})" ;;
        LoadBalancer) echo "the ingress LoadBalancer address" ;;
        *)            echo "the node's 80/443 (bundled ingress controller)" ;;
    esac
}

# The port NUMBER substituted into "... forward it to port ${INGRESS_PORT}": the
# docker host port, or (k8s) the controller's http port — the live NodePort when
# exposed as one, else the node's 80 (hostPort / a customer controller).
_plugin_ingress_hint_port() {
    if [ "$(get_deployment_type 2>/dev/null)" = "kubernetes" ]; then
        local ns="${BITOARCH_K8S_NAMESPACE:-bito-ai-architect}" nph
        nph="$(kubectl get svc ai-architect-ingress-controller -n "$ns" -o jsonpath='{.spec.ports[?(@.name=="http")].nodePort}' 2>/dev/null)"
        echo "${nph:-80}"
    else
        _plugin_ingress_port
    fi
}

# Resolve a plugin's PUBLIC_URL (from its env, then process env). Empty when unset.
_plugin_public_url() {   # <env_file>
    local v; v="$(plugin_env_get "$1" PUBLIC_URL 2>/dev/null)"
    [ -z "$v" ] && v="$(printenv PUBLIC_URL 2>/dev/null)"
    printf '%s' "$v"
}

# Silent PUBLIC_URL -> ingress reachability probe: rc 0 when the ingress /healthz
# answers 200 through the public address; rc 2 when unverifiable (no curl / no URL).
# Probes the ingress's own endpoint, not plugin health.
_plugin_public_url_ok() {   # <url>
    local url="$1" code path="/healthz"
    [ -n "$url" ] || return 2
    command -v curl >/dev/null 2>&1 || return 2
    # k8s has no shared-nginx /healthz; the durable probe is the provider route
    # served by the base Ingress.
    [ "$(get_deployment_type 2>/dev/null)" = "kubernetes" ] \
        && path="${BITOARCH_INGRESS_PATH_PROVIDER:-/api/provider}/health"
    code="$(curl -s -o /dev/null -w '%{http_code}' --max-time 4 "${url%/}${path}" 2>/dev/null)"
    [ "$code" = "200" ]
}

# Start-step acknowledgement: one line carrying container health AND
# public reachability; degrades to a loud, actionable warning when the URL check
# fails so the customer fixes it before the provider-side steps.
_plugin_start_ack() {   # <name> <env_file> <manifest>
    local name="$1" env_file="$2" manifest="$3" url prov
    url="$(_plugin_public_url "$env_file" 2>/dev/null)"
    if [ -z "$url" ]; then
        # Warn only when the plugin's config contract includes PUBLIC_URL;
        # plugins without public endpoints stay silent here.
        if manifest_config_prompt "$manifest" 2>/dev/null | grep -q '^PUBLIC_URL|'; then
            prov="$(manifest_display_provider "$manifest" 2>/dev/null)"; [ -n "$prov" ] || prov="provider"
            _BITOARCH_SETUP_WARNED=1
            printf '   %b✓%b Service is healthy\n' "${GREEN:-}" "${NC:-}" >&2
            printf '   %b⚠%b Public URL is not set — %s callbacks cannot reach this install.\n' "${YELLOW:-}" "${NC:-}" "$prov" >&2
            printf '     Set it, then re-run:  %bbitoarch plugin config %s --set PUBLIC_URL=<https-url>%b\n' "${YELLOW:-}" "$name" "${NC:-}" >&2
        else
            printf '   %b✓%b Service is healthy\n' "${GREEN:-}" "${NC:-}" >&2
        fi
        return 0
    fi
    if _plugin_public_url_ok "$url"; then
        printf '   %b✓%b Service is up · public URL reaches the ingress\n' "${GREEN:-}" "${NC:-}" >&2
        return 0
    fi
    prov="$(manifest_display_provider "$manifest" 2>/dev/null)"; [ -n "$prov" ] || prov="provider"
    _BITOARCH_SETUP_WARNED=1
    printf '   %b✓%b Service is up\n' "${GREEN:-}" "${NC:-}" >&2
    printf '   %b⚠%b Your public URL did not reach the ingress — %s callbacks will fail.\n' "${YELLOW:-}" "${NC:-}" "$prov" >&2
    printf '     Route your public URL to port %b%s%b, then re-run:  %bbitoarch plugin start %s%b\n' "${YELLOW:-}" "$(_plugin_ingress_hint_port)" "${NC:-}" "${YELLOW:-}" "$name" "${NC:-}" >&2
    if [ "$(get_deployment_type 2>/dev/null)" = "kubernetes" ]; then
        type log_silent >/dev/null 2>&1 && log_silent "plugin ${name}: public URL ${url} unreachable through the ingress — route your public HTTPS host to $(_plugin_k8s_frontdoor), then re-run: bitoarch plugin start ${name}"
    else
        type log_silent >/dev/null 2>&1 && log_silent "plugin ${name}: public URL ${url} unreachable — forward it to port $(_plugin_ingress_port) on this server, then re-run: bitoarch plugin start ${name}"
    fi
    return 0
}

# Render a plugin template, substituting ${VAR} refs against the plugin env (no eval), to a file beside its config; echo the path.
_plugin_render_template() {   # <name> <dir> <tpl-rel> <env_file>
    local name="$1" dir="$2" tpl_rel="$3" env_file="$4" tpl out line
    [ -n "$tpl_rel" ] || return 0
    tpl="$dir/$tpl_rel"
    [ -f "$tpl" ] || return 0
    # Source is <name>.default.yaml (one file serves the auto-render + the GitHub/manual copy); the
    # rendered file written here drops the ".default" marker -> plain <name>.yaml.
    local _outname="${tpl_rel##*/}"; _outname="${_outname/.default./.}"
    out="$(get_plugin_config_dir "$name")/${_outname}"
    mkdir -p "$(dirname "$out")" 2>/dev/null || true
    : > "$out"
    # Customer-facing templates use the human-friendly YOUR_PUBLIC_URL placeholder (the same single
    # file is published to GitHub for manual editing). Alias it to the framework's ${PUBLIC_URL}${BASE_PATH}
    # before resolving, so one source serves both the auto-render here and the manual copy.
    local _ppl='${PUBLIC_URL}${BASE_PATH}'
    while IFS= read -r line || [ -n "$line" ]; do
        line="${line//YOUR_PUBLIC_URL/$_ppl}"
        _plugin_resolve_env_template "$line" "$env_file" >> "$out"
        printf '\n' >> "$out"
    done < "$tpl"
    chmod 600 "$out" 2>/dev/null || true
    printf '%s' "$out"
}

# True (0) when TCP <port> is bound/LISTENing on the host. Best-effort: lsof, then netstat; if
# neither tool exists we can't tell, so return 1 (treat as free) — never block on an unprobeable host.
_port_in_use() {
    local _p="$1"
    case "$_p" in ''|*[!0-9]*) return 1 ;; esac
    if command -v lsof >/dev/null 2>&1; then
        lsof -iTCP:"$_p" -sTCP:LISTEN -Pn >/dev/null 2>&1
        return $?
    fi
    if command -v netstat >/dev/null 2>&1; then
        netstat -an 2>/dev/null | grep -Eq "[:.]${_p}[[:space:]].*LISTEN"
        return $?
    fi
    return 1
}

# Pre-flight: the host ports this plugin binds (plugin.yaml `ports:`, resolved against the plugin
# env, falling back to the declared default) must be free before we deploy. Docker only — k8s
# services don't bind host ports. Prints the busy ports ("5007, 5008") and returns 1 when any are
# taken, else 0.
_plugin_check_ports() {   # <manifest> <env_file> [<plugin-name>]
    local manifest="$1" env_file="$2" pname="${3:-}"
    [ -f "$manifest" ] || return 0
    type manifest_ports >/dev/null 2>&1 || return 0
    if type get_deployment_type >/dev/null 2>&1 && [ "$(get_deployment_type 2>/dev/null)" = "kubernetes" ]; then
        return 0
    fi
    local _ports; _ports="$(manifest_ports "$manifest")"
    [ -n "$_ports" ] || return 0
    local _busy="" _envk _def _val
    while IFS='|' read -r _envk _def; do
        [ -n "$_def" ] || continue
        _val=""
        [ -n "$_envk" ] && [ -f "$env_file" ] && _val="$(plugin_env_get "$env_file" "$_envk" 2>/dev/null)"
        [ -n "$_val" ] || _val="$_def"
        if _port_in_use "$_val"; then
            # A port held by THIS plugin's own containers is not a conflict: a
            # resume/re-install recreates that compose project, rebinding it.
            _plugin_port_self_held "$pname" "$_val" || _busy="${_busy:+$_busy, }$_val"
        fi
    done <<PORTS
$(printf '%s\n' "$_ports")
PORTS
    [ -z "$_busy" ] && return 0
    printf '%s' "$_busy"
    return 1
}

# 0 when <port> is published by a container of <plugin-name>'s own compose project.
_plugin_port_self_held() {   # <plugin-name> <port>
    [ -n "$1" ] || return 1
    command -v docker >/dev/null 2>&1 || return 1
    type plugin_compose_project >/dev/null 2>&1 || return 1
    local _proj; _proj="$(plugin_compose_project "$1" 2>/dev/null)"; [ -n "$_proj" ] || return 1
    docker ps --filter "label=com.docker.compose.project=${_proj}" --format '{{.Ports}}' 2>/dev/null | grep -q ":${2}->"
}

# 0 when Insights actively USES the shared ticket-tracker connection (feature
# enabled in the base env) — overriding it from a plugin flow is then unsafe.
_plugin_insights_tt_active() {
    local env_file=""
    type get_config_file >/dev/null 2>&1 && env_file="$(get_config_file 2>/dev/null)"
    [ -n "$env_file" ] && [ -f "$env_file" ] || return 1
    grep -q '^INSIGHTS_TICKET_TRACKER_ENABLED=true' "$env_file" 2>/dev/null
}

# Connect a required ticket-tracker integration: show any existing creds and ask reuse (Y) / reconfigure (n), else capture fresh. Non-fatal.
_plugin_connect_integration() {   # <name> <key> <integration>
    local name="$1" key="$2" integ="$3"
    [ "$integ" = "ticket-tracker" ] || return 0
    # Provider noun for the messages, from the manifest (generic); neutral fallback.
    local _prov; _prov="$(manifest_display_provider "$(get_plugin_install_dir "$name" 2>/dev/null)/plugin.yaml" 2>/dev/null)"
    [ -n "$_prov" ] || _prov="the integration"

    # Existing shared connection -> the SAME reuse/reconfigure ack `insights enable` shows (one
    # shared helper in insights-prompts.sh). It resolves the creds into _tt_base_url for the reuse
    # line, prints the shared notice, and asks keep/reconfigure. rc 0 = keep -> reuse.
    local _tt_base_url="" _tt_email="" _tt_token="" _tt_host_type=""
    if type _insights_tt_confirm_reuse >/dev/null 2>&1 && _insights_tt_confirm_reuse "$_prov"; then
        _pm_ok "Connected to ${_prov}: ${_tt_base_url}"
        printf '\n' >&2   # BLANK line after the reuse outcome (spec D)
        return 0
    fi
    # Reconfigure (operator chose 'n') OR no existing connection. When Insights actively uses the
    # shared record, route the change through the insights flow (it re-syncs the other plugins); this
    # plugin re-registers its own webhook in its Start/Register steps, so exclude it from that fan-out.
    if _plugin_insights_tt_active && type insights_update_ticket_tracker >/dev/null 2>&1; then
        # Defer the Insights project selection: the plugin's own picker (next step)
        # renders the shared list once; the hook completes the Insights ask after it.
        BITOARCH_TT_SKIP_PLUGIN="$name" _TT_SKIP_PROJECT_KEYS=1 insights_update_ticket_tracker || true
        _BITOARCH_TT_PROJECTS_DEFERRED=1
        printf '\n' >&2
        return 0
    fi

    if type ask_ticket_tracker_config >/dev/null 2>&1; then
        _TT_CONNECT_MODE=1 ask_ticket_tracker_config || true
    fi
    if [ "${INSIGHTS_TICKET_TRACKER_ENABLED:-}" = "true" ]; then
        # Push only the captured creds to cis-config (no apply_tuning) so the consumer gets them without enabling the Insights feature.
        if type config_apply_ticket_tracker >/dev/null 2>&1; then
            config_apply_ticket_tracker >/dev/null 2>&1 \
                || { type log_silent >/dev/null 2>&1 && log_silent "plugin: ${_prov} cis-config credential write failed (non-fatal)"; }
        fi
        # Persist the captured connection to the base .env-bitoarch so `bitoarch insights enable`
        # finds it. Keep INSIGHTS_TICKET_TRACKER_ENABLED at its current value — capturing the
        # connection must not enable the Insights ticket-tracker feature.
        if type insights_persist_env >/dev/null 2>&1 && type get_config_file >/dev/null 2>&1; then
            local _base_env _prev_enabled
            _base_env="$(get_config_file 2>/dev/null)"
            if [ -n "$_base_env" ] && [ -f "$_base_env" ]; then
                _prev_enabled="$(plugin_env_get "$_base_env" INSIGHTS_TICKET_TRACKER_ENABLED 2>/dev/null)"
                INSIGHTS_TICKET_TRACKER_ENABLED="${_prev_enabled:-false}"; export INSIGHTS_TICKET_TRACKER_ENABLED
                insights_persist_env "$_base_env" >/dev/null 2>&1 || true
            fi
        fi
        # Connector already printed its own success line; just keep layout spacing.
        type log_silent >/dev/null 2>&1 && log_silent "plugin: ${_prov} connected for '$name'"
        printf '\n' >&2
        return 0
    fi
    printf '  %bℹ %s is not connected yet.%b\n' "${BLUE:-}" "$_prov" "${NC:-}" >&2
    printf '     Connect it later: %bbitoarch plugin config %s%b\n' "${YELLOW:-}" "$name" "${NC:-}" >&2
    return 0
}

# Read one prompted line from fd 0 into the named variable. Hidden input for secrets; rc!=0 on EOF/Ctrl-D.
_plugin_prompt_read() {   # <var-name> <prompt> <hidden:0|1>
    if [ "$3" = "1" ]; then
        # Hidden read: WHOLE-LINE `read -s` so echo is off for the entire read and
        # restored by the shell (incl. on interrupt). A per-character `read -s -n1`
        # loop re-enables echo BETWEEN characters and leaks a PASTED secret on many
        # terminals (Windows Terminal / WSL). Fixed-width mask (no length leak);
        # empty EOF returns 1.
        local _val="" _rc=0
        printf '%s' "$2" >&2
        IFS= read -r -s _val || _rc=1
        [ -n "$_val" ] && printf '********' >&2
        printf '\n' >&2
        printf -v "$1" '%s' "$_val"
        [ "$_rc" -eq 1 ] && [ -z "$_val" ] && return 1
        return 0
    else
        read -r -p "$2" "$1" || return 1
    fi
}

# Echo the config.required keys still unset in the plugin env (value resolved from plugin .env then process env).
# 0 when the shared integration already has a stored connection in cis-config.
_plugin_integration_connected() {
    [ "$1" = "ticket-tracker" ] || return 0
    type _insights_resolve_tt_creds >/dev/null 2>&1 || return 1
    local _tt_base_url="" _tt_email="" _tt_token="" _tt_host_type=""
    _insights_resolve_tt_creds 2>/dev/null && [ -n "${_tt_base_url:-}" ]
}

_plugin_unset_required_config() {
    local manifest="$1" env_file="$2" k v intg
    while IFS= read -r k; do
        [ -z "$k" ] && continue
        # Integration-bound keys (e.g. jira) are satisfied via the cis-config connection, not the env.
        intg="$(manifest_config_required_integration "$manifest" "$k" 2>/dev/null)"
        if [ -n "$intg" ]; then
            _plugin_integration_connected "$intg" || printf '%s\n' "$k"
            continue
        fi
        # Engine-managed keys (resolve:/generate:) are the platform's to fill -- some only
        # later in the install (e.g. the MCP token) -- and are never prompted, so they must
        # not block the start gate either. Mirrors the collect flow's managed-key skip.
        if [ -n "$(manifest_config_required_managed "$manifest" "$k" 2>/dev/null)" ]; then
            continue
        fi
        v="$(sed -n "s/^${k}=//p" "$env_file" 2>/dev/null | head -1)"
        [ -z "$v" ] && v="$(printenv "$k" 2>/dev/null)"
        [ -z "$v" ] && printf '%s\n' "$k"
    done <<EOF
$(manifest_required_config_keys "$manifest" 2>/dev/null)
EOF
    # PUBLIC_URL is mandatory for any plugin that declares it (provider callbacks
    # cannot reach the install without it) — same contract as required credentials,
    # so every gate (start step, health short-circuit, needs-setup) covers it.
    if manifest_config_prompt "$manifest" 2>/dev/null | grep -q '^PUBLIC_URL|'; then
        v="$(sed -n "s/^PUBLIC_URL=//p" "$env_file" 2>/dev/null | head -1)"
        [ -z "$v" ] && v="$(printenv PUBLIC_URL 2>/dev/null)"
        [ -z "$v" ] && printf '%s\n' "PUBLIC_URL"
    fi
    return 0
}

# Resolve ${VAR} refs in a template against the plugin env then process env (literal substitution, no eval; unknown -> empty).
_plugin_resolve_env_template() {
    local tpl="$1" env_file="$2" rest="$1" var val seen=" "
    local re='\$\{([A-Za-z_][A-Za-z0-9_]*)\}'
    while [[ "$rest" =~ $re ]]; do
        var="${BASH_REMATCH[1]}"
        rest="${rest#*\}}"
        case "$seen" in *" $var "*) continue ;; esac
        seen="$seen$var "
        val="$(plugin_env_get "$env_file" "$var" 2>/dev/null)"
        [ -z "$val" ] && val="$(printenv "$var" 2>/dev/null)"
        tpl="${tpl//\$\{$var\}/$val}"
    done
    printf '%s' "$tpl"
}

# Show the external endpoints the plugin declares (manifest config.endpoints), each url resolved against its env. No-op when none.
_plugin_show_endpoints() {
    local manifest="$1" env_file="$2" hint label tpl
    hint="$(manifest_config_endpoints_hint "$manifest" 2>/dev/null)"
    {
        while IFS='|' read -r label tpl; do
            [ -n "$tpl" ] || continue
            printf '%s\t%s\n' "$label" "$(_plugin_resolve_env_template "$tpl" "$env_file")"
        done <<EOF
$(manifest_config_endpoints "$manifest" 2>/dev/null)
EOF
    } | _pm_endpoints "$hint"
}

# Collect still-unset config.required creds (secrets hidden) into the plugin env; integration-bound keys connect via that
# flow, others prompt (re-asks once on blank, empty never stored). rc 1 = operator aborted. Idempotent. Runs in caller's shell.
_plugin_collect_required() {   # <name> <manifest> <env_file>
    local name="$1" manifest="$2" env_file="$3"
    local k val label is_secret tries pl intg cur
    local keys=()
    # Reconfigure walks every declared key (Enter keeps the current value); first-time setup only the unset ones.
    if [ "${BITOARCH_RECONFIGURE:-}" = "1" ]; then
        while IFS= read -r k; do [ -n "$k" ] && keys+=("$k"); done <<EOF
$(manifest_required_config_keys "$manifest" 2>/dev/null)
EOF
    else
        while IFS= read -r k; do [ -n "$k" ] && keys+=("$k"); done <<EOF
$(_plugin_unset_required_config "$manifest" "$env_file")
EOF
        # Always walk integration-bound keys — even when the shared connection already exists — so the
        # connect step acknowledges it and offers reuse/reconfigure instead of silently reusing (e.g.
        # after a plugin --purge left the shared connection, or Insights/another plugin set it).
        while IFS= read -r k; do
            [ -n "$k" ] || continue
            case " ${keys[*]:-} " in *" $k "*) continue ;; esac
            [ -n "$(manifest_config_required_integration "$manifest" "$k" 2>/dev/null)" ] && keys+=("$k")
        done <<EOF
$(manifest_required_config_keys "$manifest" 2>/dev/null)
EOF
    fi
    [ "${#keys[@]}" -gt 0 ] || return 0
    for k in "${keys[@]}"; do
        # A key bound to a cis-config integration is connected via that flow, not prompted.
        intg="$(manifest_config_required_integration "$manifest" "$k" 2>/dev/null)"
        if [ -n "$intg" ]; then
            _plugin_connect_integration "$name" "$k" "$intg"
            continue
        fi
        # Engine-managed keys (resolve:/generate:) are auto-filled (inherited from the platform
        # env, or generated) — never prompted, on fresh install OR reconfigure. This keeps
        # reconfigure to the plugin's own user-facing settings (e.g. it must not ask BITO_API_KEY).
        if [ -n "$(manifest_config_required_managed "$manifest" "$k" 2>/dev/null)" ]; then
            continue
        fi
        label="$(manifest_config_required_label "$manifest" "$k" 2>/dev/null)"
        [ -n "$label" ] || label="$(_plugin_humanize_key "$k")"
        is_secret=0
        if type _plugin_key_is_secret >/dev/null 2>&1 && _plugin_key_is_secret "$k"; then is_secret=1; fi
        cur="$(plugin_env_get "$env_file" "$k" 2>/dev/null)"
        val=""; tries=0
        while [ "$tries" -lt 2 ]; do
            pl="$label"
            [ -n "$cur" ] && pl="$label (Enter keeps current)"
            [ "$tries" -gt 0 ] && pl="$label (required)"
            _plugin_prompt_read val "$(_pm_cred_prompt "$pl")" "$is_secret" || return 1
            if [ -z "$val" ] && [ -n "$cur" ]; then val="$cur"; break; fi
            _plugin_value_ok "$val" && break
            tries=$((tries + 1))
        done
        _plugin_value_ok "$val" || return 1
        [ "$val" = "$cur" ] || plugin_env_set "$env_file" "$k" "$val"
    done
    return 0
}

# ── Generic interactive-setup engine (plugin-agnostic) ───────────────────────
# Built-in step: collect config.prompt deploy values (e.g. PUBLIC_URL); current value is the Enter-keeps default, ${INGRESS_PORT} filled in.
# rc 2 when a MANDATORY deploy value (PUBLIC_URL) ends up empty — callers land the
# install as pending (same contract as a skipped credentials step).
_plugin_collect_prompts() {   # <name> <manifest> <env_file>
    local name="$1" manifest="$2" env_file="$3" pk plabel phint pcur pval _iport i _op
    _iport="$(_plugin_ingress_hint_port)"
    # Read prompt defs into arrays FIRST so the prompts below read fd 0, not the heredoc (input-eating gate).
    local pkeys=() plabels=() phints=()
    while IFS='|' read -r pk plabel phint; do
        [ -n "$pk" ] && { pkeys+=("$pk"); plabels+=("$plabel"); phints+=("$phint"); }
    done <<EOF
$(manifest_config_prompt "$manifest" 2>/dev/null)
EOF
    for i in "${!pkeys[@]}"; do
        pk="${pkeys[$i]}"; plabel="${plabels[$i]}"; phint="${phints[$i]}"
        [ -n "$plabel" ] || plabel="$(_plugin_humanize_key "$pk")"
        pcur="$(plugin_env_get "$env_file" "$pk" 2>/dev/null)"
        # One PUBLIC_URL serves every plugin: borrow another installed plugin's
        # value as the Enter-keeps default when this plugin has none yet.
        if [ -z "$pcur" ] && [ "$pk" = "PUBLIC_URL" ]; then
            for _op in $(journal_list_plugins 2>/dev/null); do
                [ "$_op" = "$name" ] && continue
                pcur="$(plugin_env_get "$(get_plugin_env_file "$_op" 2>/dev/null)" PUBLIC_URL 2>/dev/null)"
                [ -n "$pcur" ] && break
            done
        fi
        # Shared onboarding: keep an already-seeded value (e.g. one shared PUBLIC_URL) silently, don't re-prompt per plugin.
        if [ "${BITOARCH_PLUGIN_SHARED_SETUP:-}" = "1" ] && [ -n "$pcur" ]; then continue; fi
        phint="${phint//\$\{INGRESS_PORT\}/$_iport}"
        # Dim hint with the routing requirement highlighted (dim again after it).
        local _hl="your nginx or load balancer must forward it to port ${_iport}"
        [ -n "$phint" ] && printf '   %b\n' "${DIM:-}${phint/$_hl/${NC:-}${YELLOW:-}${_hl}${NC:-}${DIM:-}}${NC:-}" >&2
        _plugin_prompt_read pval "$(_pm_value_prompt "$plabel" "$pcur")" 0 || break
        # Reject non-URL input instead of saving it; empty falls through to the
        # keep-default / mandatory handling below, same as entering nothing.
        if [ "$pk" = "PUBLIC_URL" ] && _plugin_value_ok "$pval" && ! _plugin_public_url_shape_ok "$pval"; then
            type log_silent >/dev/null 2>&1 && log_silent "plugin install: rejected invalid PUBLIC_URL for '${name}' (shape check)"
            printf '   %b⚠%b Not a valid URL — must start with http:// or https://\n' \
                "${YELLOW:-}" "${NC:-}" >&2
            pval=""
        fi
        if _plugin_value_ok "$pval"; then
            plugin_env_set "$env_file" "$pk" "$pval"
            [ "$pk" = "PUBLIC_URL" ] && type ingress_set_host_from_public_url >/dev/null 2>&1 \
                && ingress_set_host_from_public_url "$pval"
            printf '   %b✓%b Saved\n' "${GREEN:-}" "${NC:-}" >&2
        elif [ -n "$pcur" ]; then
            # Enter keeps the default — persist it (it may be borrowed from another plugin).
            plugin_env_set "$env_file" "$pk" "$pcur"
            [ "$pk" = "PUBLIC_URL" ] && type ingress_set_host_from_public_url >/dev/null 2>&1 \
                && ingress_set_host_from_public_url "$pcur"
            printf '   %b✓%b Using %s\n' "${GREEN:-}" "${NC:-}" "$pcur" >&2
        fi
        # PUBLIC_URL is mandatory: nothing entered and nothing to reuse ends the
        # setup as incomplete (provider callbacks can never reach this install).
        if [ "$pk" = "PUBLIC_URL" ] && [ -z "$(plugin_env_get "$env_file" PUBLIC_URL 2>/dev/null)" ]; then
            printf '   %b⚠%b A public URL is required — %s cannot go live without it.\n' \
                "${YELLOW:-}" "${NC:-}" "$name" >&2
            return 2
        fi
    done
    return 0
}

# Headless one-off install gate: a manifest-declared PUBLIC_URL that resolves to
# nothing can never go live and no operator is at a prompt -- fail up-front
# instead of deploying. The install.yaml preseed path (BITOARCH_NONINTERACTIVE=1)
# is exempt: declared installs land pending by design and the runbook completes them.
_plugin_headless_public_url_gate() {   # <name> <manifest> <env_file>
    local name="$1" manifest="$2" env_file="$3" _pub _op
    _if_interactive && return 0
    [ "${BITOARCH_NONINTERACTIVE:-0}" = "1" ] && return 0
    manifest_config_prompt "$manifest" 2>/dev/null | awk -F'|' '$1=="PUBLIC_URL"{f=1} END{exit f?0:1}' || return 0
    _pub="$(plugin_env_get "$env_file" PUBLIC_URL 2>/dev/null)"
    _plugin_public_url_shape_ok "$_pub" || _pub=""
    if [ -z "$_pub" ]; then
        # One PUBLIC_URL serves every plugin: adopt another installed plugin's value.
        for _op in $(journal_list_plugins 2>/dev/null); do
            [ "$_op" = "$name" ] && continue
            _pub="$(plugin_env_get "$(get_plugin_env_file "$_op" 2>/dev/null)" PUBLIC_URL 2>/dev/null)"
            _plugin_public_url_shape_ok "$_pub" || { _pub=""; continue; }
            plugin_env_set "$env_file" PUBLIC_URL "$_pub"; break
        done
    fi
    [ -n "$_pub" ] && return 0
    printf '   %b⚠%b A public URL is required — %s cannot go live without it.\n' \
        "${YELLOW:-}" "${NC:-}" "$name" >&2
    return 1
}

# Closing block after a successful setup: rule + ✅ banner (from the
# manifest's setup.successBanner, else "<displayName> is installed and running"),
# then the plugin's own hooks.summary for provider-side next steps.
_plugin_setup_closing() {   # <name> <dir> <manifest> <env_file>
    local name="$1" dir="$2" manifest="$3" env_file="$4" banner summary
    # Consume the warned flag: it describes ONE setup run, and closing ends it.
    local warned="${_BITOARCH_SETUP_WARNED:-0}"; _BITOARCH_SETUP_WARNED=0
    if [ "$warned" = "1" ]; then
        _pm_closing_warn "$name"
        return 0
    fi
    banner="$(_mp_scalar "$manifest" '.setup.successBanner' 2>/dev/null)"
    if [ -z "$banner" ]; then
        banner="$(manifest_display_name "$manifest" 2>/dev/null)"
        [ -n "$banner" ] || banner="$name"
        banner="${banner} is installed and running"
    fi
    _pm_closing "$banner"
    summary="$(manifest_hook "$manifest" summary 2>/dev/null)"
    if [ -n "$summary" ] && [ -f "$dir/$summary" ]; then
        ( PLUGIN_NAME="$name" PLUGIN_DIR="$dir" PLUGIN_MANIFEST="$manifest" PLUGIN_ENV_FILE="$env_file"
          # shellcheck source=/dev/null
          . "$dir/$summary" ) || true
    fi
    return 0
}

# Run a plugin's INTERACTIVE setup hook in a subshell (inherits TTY/helpers/env, isolates pollution); persists via files. rc!=0 -> caller skips.
_plugin_run_setup_hook() {   # <name> <dir> <manifest> <env_file> <rel-path>
    local name="$1" dir="$2" manifest="$3" env_file="$4" rel="$5" script
    script="${dir}/${rel}"
    if [ ! -f "$script" ]; then
        type log_silent >/dev/null 2>&1 && log_silent "plugin setup hook not found: $rel"
        return 0
    fi
    ( PLUGIN_NAME="$name" PLUGIN_DIR="$dir" PLUGIN_MANIFEST="$manifest" \
      PLUGIN_ENV_FILE="$env_file" \
      BITOARCH_DEPLOY_TYPE="$(get_deployment_type 2>/dev/null || echo docker-compose)" \
      BITOARCH_RECONFIGURE="${BITOARCH_RECONFIGURE:-0}"
      . "$script" )
}

# Generic phase engine: run each manifest-declared setup step (built-in actions or `hook:<rel>`); titles/order all from manifest + hooks.
# Step outcome contract: a hook exits 2 to report "completed with a problem" —
# setup continues, but the install lands as pending, not installed.
_plugin_run_steps() {   # <name> <dir> <manifest> <env_file>
    local name="$1" dir="$2" manifest="$3" env_file="$4"
    _BITOARCH_SETUP_WARNED=0; _BITOARCH_SETUP_ABORT=0
    local title cfg_setup i _t _e _a stitle semoji saction _ans
    title="$(manifest_display_name "$manifest" 2>/dev/null)"; [ -n "$title" ] || title="$name"
    # Read steps into arrays FIRST so the per-step actions below read fd 0, not the heredoc (input-eating gate).
    local stitles=() semojis=() sactions=()
    while IFS='|' read -r _t _e _a; do
        [ -n "$_a" ] && { stitles+=("$_t"); semojis+=("$_e"); sactions+=("$_a"); }
    done <<EOF
$(manifest_setup_steps "$manifest" 2>/dev/null)
EOF
    # Default flow when no setup.steps declared: configure then start, plus show-endpoints when declared.
    if [ "${#sactions[@]}" -eq 0 ]; then
        stitles=("Configure" "Start {{name}}"); semojis=("⚙️" "🚀"); sactions=("configure" "start")
        if [ -n "$(manifest_config_endpoints "$manifest" 2>/dev/null)" ]; then
            stitles+=("Connect"); semojis+=("🔗"); sactions+=("show-endpoints")
        fi
    fi
    local total="${#sactions[@]}"
    _pm_section "$title"
    cfg_setup="$(manifest_config_setup "$manifest" 2>/dev/null)"
    [ -n "$cfg_setup" ] && printf '%s\n' "$cfg_setup" >&2
    for i in "${!sactions[@]}"; do
        stitle="${stitles[$i]}"; semoji="${semojis[$i]}"; saction="${sactions[$i]}"
        stitle="${stitle//\{\{name\}\}/$title}"
        _pm_phase "$((i + 1))" "$total" "$stitle" "$semoji"
        case "$saction" in
            configure)        _plugin_collect_prompts "$name" "$manifest" "$env_file" || { _BITOARCH_SETUP_WARNED=1; _BITOARCH_SETUP_ABORT=1; return 0; }
                              _plugin_collect_required "$name" "$manifest" "$env_file" || { _pm_setup_skipped "$name"; return 0; } ;;
            collect-prompts)  _plugin_collect_prompts "$name" "$manifest" "$env_file" || { _BITOARCH_SETUP_WARNED=1; _BITOARCH_SETUP_ABORT=1; return 0; } ;;
            collect-required) _plugin_collect_required "$name" "$manifest" "$env_file" || { _pm_setup_skipped "$name"; return 0; } ;;
            start)            # A service missing required credentials cannot boot — starting it
                              # only produces a crash-loop. Skip; the pending hint completes it.
                              # Detection, not a decline: never aborts (a decline already aborted at
                              # its own step above) -- land pending so the install stays resumable.
                              local _missing_req
                              _missing_req="$(_plugin_unset_required_config "$manifest" "$env_file")" || true
                              if [ -n "$_missing_req" ]; then
                                  _BITOARCH_SETUP_WARNED=1
                                  # Name the keys in the log so a false skip is diagnosable.
                                  type log_silent >/dev/null 2>&1 && log_silent "plugin ${name}: start skipped, required config unset: $(printf '%s' "$_missing_req" | tr '\n' ' ')"
                                  printf '   %b⚠%b Service start skipped — required credentials are not set yet.\n' "${YELLOW:-}" "${NC:-}" >&2
                                  type log_silent >/dev/null 2>&1 && log_silent "plugin install: start step skipped for '$name' (required config unset)"
                              else
                                  # 4th arg is "Always" only when the install deferred its first
                                  # deploy to this step (dynamic scope from plugin_install); empty
                                  # on `plugin start`-driven setups, keeping starts pull-free.
                                  _pm_applying "$name"; _plugin_recreate "$name" "$dir" "$manifest" "${_BITOARCH_INSTALL_FORCE_PULL:-}" || return 1
                                  if type _plugin_wait_health >/dev/null 2>&1; then
                                      type log_silent >/dev/null 2>&1 && log_silent "plugin install: waiting for '$name' health"
                                      if _plugin_wait_health "$name"; then _plugin_start_ack "$name" "$env_file" "$manifest"; fi
                                  fi
                              fi ;;
            show-endpoints)   _plugin_show_endpoints "$manifest" "$env_file"; _pm_docs
                              _plugin_prompt_read _ans "$(_pm_pause_prompt)" 0 || true ;;
            hook:*)           local _hrc=0
                              _plugin_run_setup_hook "$name" "$dir" "$manifest" "$env_file" "${saction#hook:}" || _hrc=$?
                              if [ "$_hrc" -eq 2 ]; then
                                  _BITOARCH_SETUP_WARNED=1
                                  # rc 2 with required config STILL unset = the operator declined a
                                  # mandatory value -- abort here, don't run the remaining steps.
                                  # rc 2 with config set (e.g. webhook registration problem) stays
                                  # the completed-with-a-problem contract: continue, land pending.
                                  if [ -n "$(_plugin_unset_required_config "$manifest" "$env_file")" ]; then
                                      _BITOARCH_SETUP_ABORT=1; return 0
                                  fi
                              elif [ "$_hrc" -ne 0 ]; then _pm_setup_skipped "$name"; return 0; fi ;;
            *)                type log_silent >/dev/null 2>&1 && log_silent "unknown setup action: $saction" ;;
        esac
    done
    return 0
}

# Interactive setup dispatcher: runs the generic, manifest-driven step engine.
_plugin_interactive_setup() {
    _plugin_run_steps "$@"
}

# plugin_start <name> -- prompt for missing required config, (re)create to apply env, verify health. Idempotent.
plugin_start() {
    local name="${1:-}"
    _BITOARCH_SETUP_WARNED=0
    [ -n "$name" ] || { _if_err "usage: bitoarch plugin start <name>"; return 1; }
    journal_ensure || return 1
    if ! journal_plugin_exists "$name"; then _pm_not_installed "$name"; return 1; fi
    # Base must be up: plugins depend on the platform services (cis-config, MySQL,
    # event-bus) and only crash-loop without them. Same preflight install uses.
    _plugin_preflight_workspace || return 1
    local install_dir manifest env_file
    install_dir="$(get_plugin_install_dir "$name")"
    manifest="$install_dir/plugin.yaml"
    env_file="$(get_plugin_env_file "$name")"

    _plugin_autogenerate_secrets "$manifest" "$env_file"
    # Shared dependency packs may be gone after a keep-data uninstall; re-ensure them first.
    type dep_resolve_requires >/dev/null 2>&1 && dep_resolve_requires "$manifest" "$name" >/dev/null 2>&1 || true
    # Idempotent: everything already up and configured means there is nothing to do.
    if [ "$(_plugin_current_health "$name" 2>/dev/null)" = "healthy" ] \
       && [ -z "$(_plugin_unset_required_config "$manifest" "$env_file")" ]; then
        type ingress_sync >/dev/null 2>&1 && ingress_sync >/dev/null 2>&1
        _pm_info "'${name}' is already running."
        return 0
    fi
    local setup_ran=0
    if [ -n "$(_plugin_unset_required_config "$manifest" "$env_file")" ] && _if_interactive; then
        _plugin_interactive_setup "$name" "$install_dir" "$manifest" "$env_file"
        setup_ran=1   # endpoints already shown in the setup guidance
    else
        _pm_applying "$name"
        _plugin_recreate "$name" "$install_dir" "$manifest"
    fi

    if _plugin_wait_health "$name"; then
        journal_put_plugin "$name" "$(journal_get_plugin "$name" | jq --arg h "${BITOARCH_PLUGIN_HEALTH:-unknown}" '.health=$h')" >/dev/null 2>&1 || true
        type ingress_sync >/dev/null 2>&1 && ingress_sync >/dev/null 2>&1 || true
        _plugin_capture_logs "$name"
        # The interactive setup's start step already acked; only the direct-start branch needs one.
        if [ "$setup_ran" -eq 0 ]; then _plugin_start_ack "$name" "$env_file" "$manifest"; fi
        # Reflect the setup outcome in the install state: a warned step marks the
        # pending; a clean setup run completes a previously-pending one.
        if [ "${_BITOARCH_SETUP_WARNED:-}" = "1" ]; then
            journal_set_plugin_status "$name" "pending" 2>/dev/null || true
        elif [ "$setup_ran" -eq 1 ] && case "$(journal_plugin_field "$name" status)" in pending|install-incomplete) true ;; *) false ;; esac; then
            journal_set_plugin_status "$name" "installed" 2>/dev/null || true
        fi
        _plugin_sync_scheduler
        _plugin_setup_closing "$name" "$install_dir" "$manifest" "$env_file"
        return 0
    fi
    journal_put_plugin "$name" "$(journal_get_plugin "$name" | jq '.health="unhealthy"')" >/dev/null 2>&1 || true
    if [ -n "$(_plugin_unset_required_config "$manifest" "$env_file")" ]; then
        render_plugin_install_needs_attention_block "$name" "$(journal_plugin_field "$name" version)" needs-setup
    else
        render_plugin_install_needs_attention_block "$name" "$(journal_plugin_field "$name" version)" unhealthy
    fi
    return 1
}

# Reconcile the auto-update schedule after ANY terminal plugin state (installed
# OR pending). sync (not install) is idempotent: registers the host launchd/
# systemd/cron agent + additive k8s CronJob when >=1 plugin is installed and
# auto-update is on, removes it otherwise. Placed here (not only on the success
# path) so a pending install still schedules updates.
_plugin_sync_scheduler() {
    [ "${BITOARCH_PLUGIN_SKIP_SCHEDULER:-0}" = "1" ] && return 0
    [ -f "${_BITOARCH_PLUGIN_INSTALL_DIR_SELF}/../scheduler.sh" ] || return 0
    type scheduler_sync >/dev/null 2>&1 \
        || . "${_BITOARCH_PLUGIN_INSTALL_DIR_SELF}/../scheduler.sh" 2>/dev/null || return 0
    type scheduler_sync >/dev/null 2>&1 && scheduler_sync >/dev/null 2>&1 || true
}

# Best-effort log capture at plugin lifecycle points (stop/restart/uninstall):
# base services capture on THEIR restart; without this, a plugin installed after
# the last base restart has no .gz under logs/plugins until the next one.
_plugin_capture_logs() {   # <name>
    local ulm="${_BITOARCH_PLUGIN_INSTALL_DIR_SELF}/../../unified-log-manager.sh"
    [ -x "$ulm" ] && "$ulm" sync-plugin "$1" >/dev/null 2>&1 || true
}

# plugin_stop <name> -- pause a plugin's containers (keeps it installed + config/data; `plugin start` resumes).
plugin_stop() {
    local name="${1:-}"
    [ -n "$name" ] || { _if_err "usage: bitoarch plugin stop <name>"; return 1; }
    journal_ensure || return 1
    if ! journal_plugin_exists "$name"; then _pm_not_installed "$name"; return 1; fi
    _plugin_capture_logs "$name"
    _plugin_stop "$name" "$(get_plugin_install_dir "$name")" "$(get_plugin_install_dir "$name")/plugin.yaml"
    journal_put_plugin "$name" "$(journal_get_plugin "$name" | jq '.health="stopped"')" >/dev/null 2>&1 || true
    _pm_stopped "$name"
}

# plugin_restart <name> -- recreate so the containers re-read their env-files (current config re-applies).
plugin_restart() {
    local name="${1:-}"
    [ -n "$name" ] || { _if_err "usage: bitoarch plugin restart <name>"; return 1; }
    journal_ensure || return 1
    if ! journal_plugin_exists "$name"; then _pm_not_installed "$name"; return 1; fi
    # Base must be up: plugins depend on the platform services (cis-config, MySQL,
    # event-bus) and only crash-loop without them. Same preflight install uses.
    _plugin_preflight_workspace || return 1
    local install_dir manifest env_file
    install_dir="$(get_plugin_install_dir "$name")"
    manifest="$install_dir/plugin.yaml"
    env_file="$(get_plugin_env_file "$name")"
    _pm_restarting "$name"
    _plugin_capture_logs "$name"
    _plugin_recreate "$name" "$install_dir" "$manifest" || return 1
    if _plugin_wait_health "$name"; then
        journal_put_plugin "$name" "$(journal_get_plugin "$name" | jq --arg h "${BITOARCH_PLUGIN_HEALTH:-unknown}" '.health=$h')" >/dev/null 2>&1 || true
        type ingress_sync >/dev/null 2>&1 && ingress_sync >/dev/null 2>&1 || true
        _plugin_start_ack "$name" "$env_file" "$manifest"
        return 0
    fi
    journal_put_plugin "$name" "$(journal_get_plugin "$name" | jq '.health="unhealthy"')" >/dev/null 2>&1 || true
    render_plugin_install_needs_attention_block "$name" "$(journal_plugin_field "$name" version)" unhealthy
    return 1
}

# plugin_install <name|path|url> [--force]
# Failure detail from _plugin_prepare_runtime: the spinner path of progress_run
# forks the command, so the message must cross a process boundary — it goes to
# _PREP_FAIL_FILE (and to _PREP_FAIL_MSG for the same-shell path).
_prep_fail() {
    _PREP_FAIL_MSG="$1"
    [ -n "${_PREP_FAIL_FILE:-}" ] && printf '%s' "$1" > "$_PREP_FAIL_FILE" 2>/dev/null
    return 0
}

# Quiet pre-deploy stretch of plugin_install, extracted to run under ONE
# progress loader: shared packs, Wingman shelf, env wiring, DB provisioning,
# template merge, generated secrets, port preflight. Runs in the caller's
# scope; on failure records the reason via _prep_fail and returns 1.
_plugin_prepare_runtime() {
    if ! dep_resolve_requires "$imanifest" "$name" >/dev/null; then
        _prep_fail "could not resolve shared dependencies"; return 1
    fi

    if ! wingman_resolve "$install_dir" "$imanifest" "$name"; then
        _prep_fail "could not promote the shared Wingman runtime / skills"; return 1
    fi

    # Engine-owned Wingman shelf paths (WINGMAN_AUTO_UPDATE inherited from base).
    plugin_inject_wingman_env "$env_file"

    # Wire the plugin to the on-prem MCP server (in-network URL per mode; Standalone also publishes the root CA). See mcp-env.sh.
    plugin_inject_mcp_env "$env_file"

    _plugin_create_namespaces "$imanifest" "$name" || {
        _prep_fail "failed creating plugin namespaces"; return 1; }

    # Reuse a persisted password on re-run.
    if [ -n "$db" ]; then
        local pass
        pass="$(_plugin_existing_db_password "$env_file")"
        [ -z "$pass" ] && pass="$(plugin_mysql_generate_password)"
        if ! plugin_mysql_provision "$db" "$dbuser" "$pass"; then
            _prep_fail "MySQL provisioning failed for db '${db}'"; return 1
        fi
        plugin_env_set "$env_file" PLUGIN_MYSQL_HOST "ai-architect-mysql"
        plugin_env_set "$env_file" PLUGIN_MYSQL_DATABASE "$db"
        plugin_env_set "$env_file" PLUGIN_MYSQL_USER "$dbuser"
        plugin_env_set "$env_file" PLUGIN_MYSQL_PASSWORD "$pass"
    fi

    if [ -n "$tpl_rel" ] && [ -f "$install_dir/$tpl_rel" ]; then
        if ! plugin_env_merge "$env_file" "$install_dir/$tpl_rel"; then
            _prep_fail "failed merging plugin env template"; return 1
        fi
    fi

    # Inherit the base platform's LLM provider/keys so the plugin runs on the same LLM (Bito default when none set).
    type plugin_inherit_llm >/dev/null 2>&1 && plugin_inherit_llm "$env_file"

    # In-network cis-config wiring (declared-and-empty keys only; both runtimes).
    type plugin_inject_config_env >/dev/null 2>&1 && plugin_inject_config_env "$env_file"

    # Fill declared random secrets before the first deploy, so the operator is never asked to paste them.
    _plugin_autogenerate_secrets "$imanifest" "$env_file"

    # Pre-flight: fail fast (before deploy) if a required host port is already taken. Docker only.
    local _busy_ports=""
    _busy_ports="$(_plugin_check_ports "$imanifest" "$env_file" "$name")" || {
        _prep_fail "required host port(s) already in use: ${_busy_ports}. Free them, then run the install again"; return 1
    }
    return 0
}

plugin_install() {
    local src="" force=0 a
    _BITOARCH_SETUP_WARNED=0; _BITOARCH_SETUP_ABORT=0
    for a in "$@"; do
        case "$a" in
            --force) force=1 ;;
            --*) _if_err "unknown option: $a"; return 1 ;;
            *) [ -z "$src" ] && src="$a" ;;
        esac
    done
    [ -z "$src" ] && { _if_err "usage: bitoarch plugin install <name|path|url> [--force]"; return 1; }

    journal_ensure || return 1

    local staged manifest
    staged="$(_plugin_stage_source "$src")" || return 1
    manifest="$(_plugin_locate_manifest "$staged")" || return 1

    validate_manifest "$manifest" || return 1
    manifest_check_platform "$manifest" || return 1

    local name version
    name="$(manifest_name "$manifest")"
    version="$(manifest_version "$manifest")"

    if journal_plugin_exists "$name" && [ "$(journal_plugin_field "$name" status)" = "installed" ] && [ "$force" -ne 1 ]; then
        # Already installed -> "Next Steps" hint: reconfigure first, then change version.
        printf '%bℹ Plugin '\''%s'\'' is already installed (v%s).%b\n' "${BLUE:-}" "$name" "$(journal_plugin_field "$name" version)" "${NC:-}"
        printf '\n%b💡 Next Steps%b\n' "${BLUE:-}" "${NC:-}"
        printf '   • %-16s%bbitoarch plugin config %s%b\n'  "Reconfigure:"    "${YELLOW:-}" "$name" "${NC:-}"
        printf '   • %-16s%bbitoarch plugin upgrade %s%b\n' "Change version:" "${YELLOW:-}" "$name" "${NC:-}"
        return 0
    fi

    # RESUME an interrupted prior run rather than tearing it down. The prepare
    # steps are idempotent -- dependency packs use `helm upgrade --install` behind
    # a dep_pack_installed guard (refreshed, never removed+re-added), the DB uses
    # CREATE ... IF NOT EXISTS, and the env is additively merged -- so a re-install
    # skips or refreshes completed work instead of rolling packs/DB back and
    # rebuilding from scratch. (Genuine install FAILURES still roll back via
    # _plugin_install_fail.)
    if printf '%s\n' "$(journal_inflight_plugins 2>/dev/null)" | grep -qx "$name" 2>/dev/null; then
        _if_log "resuming an interrupted previous install of '${name}' (idempotent steps skip completed work)"
    fi

    # Validate the env template before any state change.
    local tpl_rel tpl=""
    tpl_rel="$(manifest_env_template "$manifest")"
    if [ -n "$tpl_rel" ]; then
        tpl="$staged/$tpl_rel"
        if [ ! -f "$tpl" ]; then _if_err "env template declared but missing: ${tpl_rel}"; return 1; fi
        plugin_env_validate_template "$tpl" || return 1
    fi

    _plugin_install_preflight "$manifest" || return 1

    # Entitlement pre-flight: block the install up front if the workspace is not
    # entitled to this plugin (fail-open; only an explicit deny stops it). Fail fast
    # here instead of letting the service silently skip events at runtime.
    plugin_check_entitlement "$manifest" "$name" || return 1

    # From here, failures roll back.
    local install_dir config_dir data_dir env_file db dbuser release reqs_json
    install_dir="$(get_plugin_install_dir "$name")"
    config_dir="$(get_plugin_config_dir "$name")"
    data_dir="$(get_plugin_data_dir "$name")"
    env_file="$(get_plugin_env_file "$name")"
    db="$(manifest_db_name "$manifest")"
    dbuser="$(manifest_db_user "$manifest")"
    release="$(manifest_helm_release "$manifest")"
    reqs_json="$(manifest_capabilities "$manifest" | jq -R . | jq -s . 2>/dev/null)"
    [ -z "$reqs_json" ] && reqs_json="[]"

    # Did a real prior config exist BEFORE this install writes derived values (base creds/MCP/DB)?
    # Distinguishes a preserved config (non-purge uninstall -> offer reuse) from a fresh/purged one,
    # where required keys can still resolve from base env + the shared cis-config connection even
    # though the plugin's own config (PUBLIC_URL, etc.) is gone. Captured before any env write below.
    local _had_prior_config=0
    [ -s "$env_file" ] && _had_prior_config=1

    journal_put_plugin "$name" "$(jq -n \
        --arg v "$version" --arg id "$install_dir" --arg dd "$data_dir" --arg cf "$env_file" \
        --arg db "$db" --arg dbu "$dbuser" --arg rel "$release" --argjson reqs "$reqs_json" \
        '{version:$v, status:"installing", install_dir:$id, data_dir:$dd, config_file:$cf,
          db:{name:$db, user:$dbu}, helm_release:$rel, requires:$reqs,
          health:"unknown", mcp_registered:false, installed_at:null}')" || return 1

    # The plugins root lives under BITOARCH_LIB_DIR. A fresh install chowns the
    # whole prefix to the invoking user, but an upgrade from a pre-plugin release
    # (<1.10.0, which had no plugins/ dir) can leave BITOARCH_LIB_DIR root-owned —
    # the staging mkdir below would then fail with "Permission denied". Reclaim
    # the plugins root once (sudo only when needed) so plugin install stays
    # rootless thereafter.
    type ensure_writable_dir >/dev/null 2>&1 && ensure_writable_dir "$(get_plugins_root)" 2>/dev/null || true

    # Defense-in-depth: never let an empty/malformed name collapse install_dir to
    # the plugins root -- the rm -rf below would then wipe every installed plugin.
    if [ -z "$name" ] || [ "$install_dir" = "$(get_plugins_root)" ]; then
        _plugin_install_fail "$name" "$install_dir" "$manifest" "refusing to install: resolved install dir '${install_dir}' is the plugins root or name is empty"; return 1
    fi

    # Clean re-stage via sibling-dir swap (mirrors upgrade): stale files from a
    # prior version must not survive a re-install.
    local newdir="${install_dir}.new.$$"
    rm -rf "$newdir"
    if ! mkdir -p "$newdir" || ! cp -R "$staged/." "$newdir/" 2>/dev/null; then
        rm -rf "$newdir"
        _plugin_install_fail "$name" "$install_dir" "$manifest" "failed to stage plugin into ${install_dir}"; return 1
    fi
    rm -rf "$install_dir"
    if ! mv "$newdir" "$install_dir"; then
        rm -rf "$newdir"
        _plugin_install_fail "$name" "$install_dir" "$manifest" "failed to stage plugin into ${install_dir}"; return 1
    fi
    local imanifest; imanifest="$install_dir/plugin.yaml"

    # Everything from shared-dependency resolution to the port preflight is
    # console-quiet and can take minutes (pack images, Wingman shelf sync) --
    # one loader line covers the whole stretch so the install never sits
    # silent; step detail goes to setup.log. Errors keep their per-step
    # message via _prep_fail (file bridge across progress_run's fork).
    local _PREP_FAIL_MSG="" _PREP_FAIL_FILE=""
    _PREP_FAIL_FILE="$(mktemp 2>/dev/null)" || _PREP_FAIL_FILE=""
    local _prep_rc=0
    if type progress_run >/dev/null 2>&1; then
        progress_run "Preparing ${name} v${version} (dependencies, runtime, database)" -- \
            _plugin_prepare_runtime || _prep_rc=$?
    else
        _plugin_prepare_runtime || _prep_rc=$?
    fi
    if [ "$_prep_rc" -ne 0 ]; then
        [ -z "$_PREP_FAIL_MSG" ] && [ -s "${_PREP_FAIL_FILE:-/nonexistent}" ] && _PREP_FAIL_MSG="$(cat "$_PREP_FAIL_FILE")"
        rm -f "$_PREP_FAIL_FILE" 2>/dev/null
        _plugin_install_fail "$name" "$install_dir" "$imanifest" "${_PREP_FAIL_MSG:-preparation failed}"; return 1
    fi
    rm -f "$_PREP_FAIL_FILE" 2>/dev/null

    # Services with mandatory operator credentials hard-fail at boot without
    # them — deploying first just crash-loops until the guided setup runs.
    # Interactive install with required config unset: defer the first start; the
    # setup's own start/recreate deploys once the credentials are in place.
    # Same outcome as the interactive mandatory-decline abort, decided up-front
    # (no operator will ever complete a headless one-off install's public URL).
    if ! _plugin_headless_public_url_gate "$name" "$imanifest" "$env_file"; then
        type log_silent >/dev/null 2>&1 && log_silent "plugin install: '${name}' aborted: required configuration not provided; rolled back (run the install again when ready)"
        plugin_rollback_install "$name" "$install_dir" "$imanifest"
        return 1
    fi

    local _defer_deploy=0 _BITOARCH_INSTALL_FORCE_PULL=""
    if _if_interactive && [ -n "$(_plugin_unset_required_config "$imanifest" "$env_file")" ]; then
        _defer_deploy=1
        # The setup's start step performs the first deploy instead: make that one
        # force-pull too (read via dynamic scope by the steps engine).
        _BITOARCH_INSTALL_FORCE_PULL="Always"
        type log_silent >/dev/null 2>&1 && log_silent "plugin install: deferring first deploy of '${name}' until required credentials are configured"
    fi
    if [ "$_defer_deploy" -eq 0 ] && ! _plugin_deploy "$name" "$install_dir" "$imanifest" "Always"; then
        _plugin_install_fail "$name" "$install_dir" "$imanifest" "deploy failed for plugin '${name}'"; return 1
    fi

    # Activation: with a terminal and unset required config, run guided one-time setup before the health gate.
    local setup_ran=0
    if _if_interactive; then
        # Always run the plugin's own setup steps -- never a whole-config skip. The ONLY
        # "reuse" decision is the shared ticket-tracker CONNECTION, offered inside the steps
        # ("Keep the current connection?"); keeping it still proceeds to the plugin's own
        # settings (projects) + webhook, so a reused connection never leaves the plugin
        # half-configured (e.g. a webhook unregistered against a freshly-recreated service).
        # When a prior config exists, run under reconfigure so each setting is re-shown with
        # its current value as the Enter-default -- identical to `bitoarch plugin config
        # <name>` reconfigure=yes; a fresh install asks each value once.
        if [ "$_had_prior_config" -eq 1 ] && [ -z "$(_plugin_unset_required_config "$imanifest" "$env_file")" ]; then
            BITOARCH_RECONFIGURE=1 _plugin_interactive_setup "$name" "$install_dir" "$imanifest" "$env_file"
        else
            _plugin_interactive_setup "$name" "$install_dir" "$imanifest" "$env_file"
        fi
        setup_ran=1
    else
        # Preseed / non-interactive: run the plugin's setup steps non-interactively so resolve-type
        # steps (e.g. task-analyzer's shared Jira-connection sync) populate the env before the container
        # reads it, and the webhook registers. Prompts self-skip under AUTO_SETUP; </dev/null guarantees
        # no step blocks on a stray read. Leave setup_ran unset so the concise stdout success block still
        # renders (the steps already surface any provider next-steps, e.g. the Jira webhook URL).
        AUTO_SETUP=true _plugin_run_steps "$name" "$install_dir" "$imanifest" "$env_file" </dev/null || true
    fi

    # An interactive fresh install where a MANDATORY config (public URL or
    # provider credentials) was declined aborts and rolls back, rather than leaving a
    # resumable half-install that a later `plugin start` would complete with a now-outdated
    # package. An ingress-reachability warning is NOT a decline (sets WARNED, never ABORT),
    # so it still lands pending below; non-interactive/preseed installs are unaffected.
    if _if_interactive && [ "${_BITOARCH_SETUP_ABORT:-0}" = "1" ]; then
        # Reason goes to the log; the caller prints the single concise terminal line.
        type log_silent >/dev/null 2>&1 && log_silent "plugin install: '${name}' aborted: required configuration not provided; rolled back (run the install again when ready)"
        plugin_rollback_install "$name" "$install_dir" "$imanifest"
        return 1
    fi

    # Required config still unset (creds step skipped): the service cannot boot — and on a
    # deferred deploy nothing is running at all. Short-circuit into the needs-setup path
    # (the k8s health probe trusts helm --wait and would otherwise report a false healthy).
    if [ -n "$(_plugin_unset_required_config "$imanifest" "$env_file")" ] || ! _plugin_wait_health "$name"; then
        # Deploy succeeded but unhealthy: keep the recoverable install (don't roll back a config/runtime issue).
        journal_put_plugin "$name" "$(journal_get_plugin "$name" | jq \
            --arg t "$(date -u +%Y-%m-%dT%H:%M:%SZ)" \
            '.status="installed" | .health="unhealthy" | .installed_at=$t')" >/dev/null 2>&1 || true
        # Routes must register even for a needs-setup install (nginx defers DNS via
        # variables+resolver, so a not-yet-ready upstream is safe) — otherwise the
        # plugin's public endpoints stay 404 until the next `plugin start`.
        type ingress_sync >/dev/null 2>&1 && ingress_sync >/dev/null 2>&1 || true
        # Amber needs-attention block (not a hard fail): `plugin start` collects missing creds AND starts.
        if [ -n "$(_plugin_unset_required_config "$imanifest" "$env_file")" ]; then
            render_plugin_install_needs_attention_block "$name" "$version" needs-setup
        else
            render_plugin_install_needs_attention_block "$name" "$version" unhealthy
        fi
        _plugin_sync_scheduler
        return 0
    fi

    local mcp_reg=false
    if _plugin_register_mcp "$name" "$imanifest"; then mcp_reg=true; fi

    local hook timeout
    hook="$(manifest_hook "$imanifest" postInstall)"
    timeout="$(manifest_hook_timeout "$imanifest")"
    if [ -n "$hook" ] && ! plugin_run_hook "$install_dir" "$hook" "$timeout"; then
        _plugin_install_fail "$name" "$install_dir" "$imanifest" "post-install hook failed"; return 1
    fi

    # A setup step that reported a problem (rc=2 / ingress-probe warn) means the
    # install is usable-but-incomplete: record pending, not installed.
    local final_status="installed"
    [ "${_BITOARCH_SETUP_WARNED:-0}" = "1" ] && final_status="pending"
    journal_put_plugin "$name" "$(journal_get_plugin "$name" | jq \
        --arg t "$(date -u +%Y-%m-%dT%H:%M:%SZ)" --arg h "${BITOARCH_PLUGIN_HEALTH:-unknown}" \
        --argjson m "$mcp_reg" --arg s "$final_status" \
        '.status=$s | .health=$h | .mcp_registered=$m | .installed_at=$t')" || return 1

    # Register the daily auto-update scheduler (best-effort, idempotent; honors
    # BITOARCH_PLUGIN_AUTO_UPDATE). One shared schedule covers all plugins.
    _plugin_sync_scheduler

    # Rebuild the shared ingress vhost so the plugin's public routes are served (no-op on k8s; best-effort).
    type ingress_sync >/dev/null 2>&1 && ingress_sync >/dev/null 2>&1 || true

    # Preseed can report a plugin "installed & running" while it is missing required config that only
    # guided setup collects (e.g. no Jira connection) -- surface that instead of a misleading success.
    # Interactive installs just ran guided setup (creds collected + validated), so this applies to the
    # non-interactive path only; re-checking there would false-negative on a freshly-configured plugin.
    if ! _if_interactive && [ -n "$(_plugin_unset_required_config "$imanifest" "$env_file")" ]; then
        render_plugin_install_needs_attention_block "$name" "$version" needs-setup
        return 0
    fi

    # First capture right after deploy (parity with base services, which sync at
    # deploy end): without this a fresh install has nothing under logs/plugins
    # until the first restart. Packs are captured by the same verb.
    _plugin_capture_logs "$name"

    # Single closing banner; details live in `plugin status`. The banner must
    # agree with the recorded state — never claim success for an incomplete install.
    if [ "$final_status" = "pending" ]; then
        _BITOARCH_SETUP_WARNED=0
        _pm_closing_warn "$name"
    elif [ "${setup_ran:-0}" -eq 1 ]; then
        _plugin_setup_closing "$name" "$install_dir" "$imanifest" "$env_file"
    else
        render_plugin_install_success_block "$name" "$version" "${BITOARCH_PLUGIN_HEALTH:-healthy}"
    fi
    return 0
}
