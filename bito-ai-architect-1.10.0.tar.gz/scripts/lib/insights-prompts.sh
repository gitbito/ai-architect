#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# scripts/lib/insights-prompts.sh — interactive prompts for insights features.

if [ -n "${_BITOARCH_INSIGHTS_PROMPTS_LOADED:-}" ]; then return 0 2>/dev/null || true; fi
_BITOARCH_INSIGHTS_PROMPTS_LOADED=1

ATLASSIAN_API_TOKEN_URL="${ATLASSIAN_API_TOKEN_URL:-https://id.atlassian.com/manage-profile/security/api-tokens}"

# Internal validators. Re-prompt on bad input; bail after 3 attempts.
_insights_validate_url() {
    # http(s)://, then a host (starting alphanumeric, host/port/path chars, no
    # whitespace) that must contain at least one dot OR a port colon. This both
    # accepts realistic self-hosted forms — FQDNs, IPs, and host:port like
    # https://jira:8080 / https://localhost:8080 — and rejects
    # bare dot-less words like https://gibberish, which the suite requires.
    # A bare port-less internal hostname is indistinguishable from gibberish, so add
    # a port or use the FQDN.
    local v="$1"
    [[ "$v" =~ ^https?://[A-Za-z0-9][A-Za-z0-9._:/-]*[.:][A-Za-z0-9._:/-]*$ ]]
}

_insights_validate_email() {
    local v="$1"
    [[ "$v" =~ ^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$ ]]
}

_insights_validate_uuid() {
    local v="$1"
    [[ "$v" =~ ^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$ ]]
}

# Live credential validation — hit the real API to confirm creds work.
_insights_normalize_jira_url() {
    local url="$1"
    url="${url%/}"
    url="${url%/browse}"
    url="${url%/jira}"
    url=$(echo "$url" | sed 's|/browse/.*$||')
    echo "$url"
}

# Print host-appropriate "create a new token" guidance. Cloud has a single
# well-known token page; self-hosted (Server/Data Center) creates Personal
# Access Tokens from the user profile on the instance itself, so derive the URL
# from the instance base URL rather than pointing at the Atlassian Cloud page
# (which is wrong for self-hosted).
_insights_jira_token_hint() {
    local base_url="$1" host_type="$2"
    if [ "$host_type" = "self" ]; then
        base_url=$(_insights_normalize_jira_url "$base_url")
        base_url="${base_url%/}"
        echo "  → For self-hosted Jira, create a Personal Access Token (PAT) at:"
        echo "    ${base_url}/secure/ViewProfile.jspa  (Profile → Personal Access Tokens)"
        echo "    If PATs are unavailable on your version, use your username/password instead."
    else
        echo "  → Generate a new API token at: ${ATLASSIAN_API_TOKEN_URL}"
    fi
}

_insights_validate_jira_creds() {
    local base_url="$1" email="$2" token="$3" host_type="$4"
    local api_path="/rest/api/3/myself"
    [ "$host_type" = "self" ] && api_path="/rest/api/2/myself"
    base_url=$(_insights_normalize_jira_url "$base_url")

    print_info "Validating Jira credentials..."
    local http_code
    if [ "$host_type" = "self" ]; then
        # Self-hosted: try Bearer token (PAT) first, fall back to Basic Auth
        http_code=$(curl -s -o /dev/null -w "%{http_code}" \
            -H "Authorization: Bearer ${token}" \
            --max-time 15 \
            "${base_url}${api_path}" 2>/dev/null)
        if [ "$http_code" != "200" ]; then
            http_code=$(curl -s -o /dev/null -w "%{http_code}" \
                -u "${email}:${token}" \
                --max-time 15 \
                "${base_url}${api_path}" 2>/dev/null)
        fi
    else
        http_code=$(curl -s -o /dev/null -w "%{http_code}" \
            -u "${email}:${token}" \
            --max-time 15 \
            "${base_url}${api_path}" 2>/dev/null)
    fi

    if [ "$http_code" = "200" ]; then
        print_success "Jira credentials validated successfully"
        return 0
    fi

    echo -e "${RED}✗${NC} Jira credential validation failed (HTTP ${http_code})"
    case "$http_code" in
        401) echo "  → Invalid credentials. Verify the email/username and token."
             _insights_jira_token_hint "$base_url" "$host_type" ;;
        403) echo "  → Token lacks required permissions. Ensure the account has project access." ;;
        404) echo "  → Base URL may be incorrect. Check the URL matches your instance." ;;
        000) echo "  → Could not connect. Check the URL and network/proxy settings." ;;
        *)   echo "  → Unexpected error. Verify URL, email, and token." ;;
    esac
    return 1
}

_insights_fetch_jira_projects() {
    local base_url email="$2" token="$3" host_type="$4"
    base_url=$(_insights_normalize_jira_url "$1")
    local api_path="/rest/api/3/project/search?maxResults=50&orderBy=key"
    [ "$host_type" = "self" ] && api_path="/rest/api/2/project"

    local response
    if [ "$host_type" = "self" ]; then
        response=$(curl -s \
            -H "Authorization: Bearer ${token}" \
            --max-time 15 \
            "${base_url}${api_path}" 2>/dev/null)
        if [ -z "$response" ] || echo "$response" | jq -e '.errorMessages? // empty' >/dev/null 2>&1; then
            response=$(curl -s \
                -u "${email}:${token}" \
                --max-time 15 \
                "${base_url}${api_path}" 2>/dev/null)
        fi
    else
        response=$(curl -s \
            -u "${email}:${token}" \
            --max-time 15 \
            "${base_url}${api_path}" 2>/dev/null)
    fi
    if [ -z "$response" ]; then
        log_silent "insights: project fetch failed (empty response from ${base_url})"
        return 1
    fi

    local projects_json total_projects=""
    if [ "$host_type" = "self" ]; then
        projects_json="$response"
    else
        total_projects=$(echo "$response" | jq -r '.total // empty' 2>/dev/null)
        projects_json=$(echo "$response" | jq '.values // empty' 2>/dev/null)
    fi
    if [ -z "$projects_json" ]; then
        log_silent "insights: Jira project fetch returned no projects"
        return 1
    fi

    if [ -n "$total_projects" ] && [ "$total_projects" -gt 50 ] 2>/dev/null; then
        print_info "Showing 50 of ${total_projects} projects. Use ${YELLOW}bitoarch insights tracker-projects add KEY${NC} for projects not listed."
    fi

    echo "$projects_json" | jq -r '.[] | "\(.key)|\(.name)"' 2>/dev/null
}

# Filters a comma-separated key list against the KEY|Name project lines, keeping only
# keys present in the list (order preserved). Used to drop configured project keys that
# don't exist on the now-connected Jira instance.
# $1 = KEY|Name project lines, $2 = comma-separated keys to filter.
_insights_filter_kept_keys() {
    local _proj_list="$1" _keys="$2"
    local _avail_keys _kept_keys="" _k
    _avail_keys=$(echo "$_proj_list" | cut -d'|' -f1)
    for _k in $(echo "$_keys" | tr ',' ' '); do
        echo "$_avail_keys" | grep -qx "$_k" && _kept_keys="${_kept_keys:+${_kept_keys},}${_k}"
    done
    echo "$_kept_keys"
}

# Displays a numbered list of Jira projects and handles interactive selection.
# Reads KEY|Name lines from stdin; outputs comma-separated selected keys.
# $1 = comma-separated currently-configured keys (marked with * in list).
# Shared Jira project picker (key-based, column-aligned) — the single source of the
# project-selection UX for Insights and the installed plugins. Renders the fetched
# KEY|Name list (passed as arg 3), reads one comma-separated line of project keys, and
# validates each against the fetched keys (unknown keys are rejected and re-prompted).
# Input comes from _plugin_prompt_read when the plugin engine provides it, else the TTY;
# display and prompts go to stderr and the result is returned in the named out-var:
#   __ALL__   the user chose every project ('all')
#   __NONE__  the current selection was already 'none' and kept on Enter
#   ""        nothing selected (Enter with no current selection)
#   KEY,KEY   the chosen keys, in the canonical casing from the list
# Args: <out-var> <current-csv> <project-list>. Enter keeps <current-csv>. Locals are
# _pp_-prefixed so a caller's out-var name never collides with printf -v below.
_jira_pick_projects() {
    local _pp_out="$1" _pp_current="${2:-}" _pp_projs
    _pp_projs="$(printf '%s\n' "${3:-}" | grep -E '^[A-Za-z0-9][A-Za-z0-9_-]*\|' || true)"

    if [ -n "$_pp_current" ]; then
        local _pp_cur_disp; if [ "$_pp_current" = "__NONE__" ]; then _pp_cur_disp="none"; else _pp_cur_disp="${_pp_current//,/, }"; fi
        printf '      %bEnter keeps the current selection (%s); type keys to change, or '"'"'all'"'"' for every project.%b\n' "${DIM:-}" "$_pp_cur_disp" "${NC:-}" >&2
    else
        printf '      %bType project keys separated by commas, or press Enter for all.%b\n' "${DIM:-}" "${NC:-}" >&2
    fi

    local _pp_valid="" _pp_listed=0
    if [ -n "$_pp_projs" ]; then
        local _pp_kw=0 _pp_pkey _pp_pname
        while IFS='|' read -r _pp_pkey _pp_pname; do
            [ -n "$_pp_pkey" ] || continue
            [ "${#_pp_pkey}" -gt "$_pp_kw" ] && _pp_kw="${#_pp_pkey}"
        done <<PICKW
$(printf '%s\n' "$_pp_projs")
PICKW
        # _JPP_LIST_SHOWN=1: the caller just rendered this same list (shared plugin +
        # Insights selection) -- keep validation, skip the duplicate render.
        if [ "${_JPP_LIST_SHOWN:-0}" != "1" ]; then
            while IFS='|' read -r _pp_pkey _pp_pname; do
                [ -n "$_pp_pkey" ] || continue
                printf '      %-*s  %s\n' "$_pp_kw" "$_pp_pkey" "$_pp_pname" >&2
            done <<PICKLIST
$(printf '%s\n' "$_pp_projs")
PICKLIST
        fi
        _pp_valid="$(printf '%s\n' "$_pp_projs" | cut -d'|' -f1 | tr '\n' ' ')"
        _pp_listed=1
    fi
    [ "$_pp_listed" -eq 1 ] || printf '   %b⚠%b Could not fetch your project list. Enter keys manually, or press Enter for all.\n' "${YELLOW:-}" "${NC:-}" >&2

    local _pp_ans _pp_csv=""
    while :; do
        _pp_ans=""
        if type _plugin_prompt_read >/dev/null 2>&1; then _plugin_prompt_read _pp_ans "   › " 0 || _pp_ans=""
        else read -r -p "   › " _pp_ans < /dev/tty || _pp_ans=""; fi
        # Enter: keep the current selection when there is one; with none, "Enter = all" (the prompt's
        # default). Returning __ALL__ (not "") lets each caller apply its own "all" semantics —
        # plugins store an empty filter, Insights expands it to the full key list.
        if [ -z "$_pp_ans" ]; then
            if [ -n "$_pp_current" ]; then _pp_csv="$_pp_current"; else _pp_csv="__ALL__"; fi
            break
        fi
        case "$_pp_ans" in [Aa][Ll][Ll]) _pp_csv="__ALL__"; break ;; esac
        local _pp_sel="" _pp_bad="" _pp_oldifs="$IFS" _pp_k _pp_match
        IFS=','
        for _pp_k in $_pp_ans; do
            _pp_k="$(printf '%s' "$_pp_k" | sed 's/^[[:space:]]*//; s/[[:space:]]*$//')"
            [ -z "$_pp_k" ] && continue
            if [ "$_pp_listed" -eq 1 ]; then
                _pp_match="$(printf '%s' "$_pp_valid" | tr ' ' '\n' | grep -ixm1 -- "$_pp_k" 2>/dev/null || true)"
                if [ -n "$_pp_match" ]; then _pp_sel="${_pp_sel:+$_pp_sel,}$_pp_match"; else _pp_bad="${_pp_bad:+$_pp_bad, }$_pp_k"; fi
            else
                _pp_sel="${_pp_sel:+$_pp_sel,}$_pp_k"
            fi
        done
        IFS="$_pp_oldifs"
        if [ -n "$_pp_bad" ]; then
            printf '   %b⚠%b Unknown project key(s): %s. Choose from: %s\n' "${YELLOW:-}" "${NC:-}" "$_pp_bad" \
                "$(printf '%s' "$_pp_valid" | sed 's/[[:space:]]\{1,\}/, /g; s/^, //; s/, $//')" >&2
            continue
        fi
        _pp_csv="$_pp_sel"; break
    done
    printf -v "$_pp_out" '%s' "$_pp_csv"
}

# Insights project picker: renders the fetched KEY|Name list (arg 3) via the shared picker
# and returns the chosen keys in the named out-var. Insights persists an explicit key list,
# so 'all' is expanded to every fetched key (empty means "not configured", not "all").
_insights_select_jira_projects() {
    local _sp_out="$1" _sp_current="${2:-}" _sp_list="${3:-}"
    [ -z "$_sp_list" ] && { printf -v "$_sp_out" '%s' ""; return 1; }
    local _sp_result=""
    _jira_pick_projects _sp_result "$_sp_current" "$_sp_list"
    if [ "$_sp_result" = "__ALL__" ]; then
        printf -v "$_sp_out" '%s' "$(printf '%s\n' "$_sp_list" | grep -E '^[A-Za-z0-9][A-Za-z0-9_-]*\|' | cut -d'|' -f1 | paste -sd, -)"
    else
        printf -v "$_sp_out" '%s' "$_sp_result"
    fi
}

# Deferred Insights project selection (plugin connect flow): the engine skipped the
# Insights ask so the plugin's own picker renders the shared list ONCE; complete the
# Insights selection here without re-rendering it. Storage mirrors
# insights_update_ticket_tracker (env + yaml sync + the same capture ack).
_insights_tt_deferred_project_ask() {
    { [ -t 0 ] || [ "${BITOARCH_PLUGIN_FORCE_PROMPT:-}" = "1" ]; } || return 0
    type _insights_fetch_jira_projects >/dev/null 2>&1 || return 0
    local _tt_base_url="" _tt_email="" _tt_token="" _tt_host_type=""
    _insights_resolve_tt_creds 2>/dev/null || true
    [ -n "$_tt_base_url" ] || return 0
    # Current selection: yaml wins over env (same as the update flow).
    local _cur="${INSIGHTS_TICKET_TRACKER_PROJECT_KEYS:-}" _cfg="" _yk
    if type _insights_tp_repo_config_path >/dev/null 2>&1; then
        _cfg=$(_insights_tp_repo_config_path 2>/dev/null)
        if [ -n "$_cfg" ] && [ -f "$_cfg" ]; then
            _yk=$(_insights_tp_read_keys "$_cfg" 2>/dev/null | paste -sd, -)
            [ -n "$_yk" ] && _cur="$_yk"
        fi
    fi
    [ -n "${_INSIGHTS_JIRA_INSTANCE_CHANGED:-}" ] && _cur=""
    local _list
    _list=$(_insights_fetch_jira_projects "$_tt_base_url" "$_tt_email" "$_tt_token" "${_tt_host_type:-cloud}" 2>/dev/null) || true
    [ -n "$_list" ] || return 0
    printf '\n   %b📁 Which projects should Insights analyze?%b\n' "${BLUE:-}" "${NC:-}" >&2
    local _sel=""
    _JPP_LIST_SHOWN=1 _insights_select_jira_projects _sel "$_cur" "$_list"
    INSIGHTS_TICKET_TRACKER_PROJECT_KEYS="$_sel"
    export INSIGHTS_TICKET_TRACKER_PROJECT_KEYS
    local _envf; _envf="$(get_config_file 2>/dev/null)"
    [ -n "$_envf" ] && [ -f "$_envf" ] && type insights_persist_env >/dev/null 2>&1 \
        && insights_persist_env "$_envf" >/dev/null 2>&1 || true
    if [ -n "$INSIGHTS_TICKET_TRACKER_PROJECT_KEYS" ] && [ -n "$_cfg" ] && [ -f "$_cfg" ] \
       && _insights_tp_has_yaml_tool 2>/dev/null; then
        echo "${INSIGHTS_TICKET_TRACKER_PROJECT_KEYS}" | tr ',' '\n' \
            | _insights_tp_write_keys "$_cfg" 2>/dev/null || true
    fi
    if [ -n "${INSIGHTS_TICKET_TRACKER_PROJECT_KEYS:-}" ]; then
        local _n; _n=$(echo "$INSIGHTS_TICKET_TRACKER_PROJECT_KEYS" | awk -F, '{print NF}')
        # This deferred ask ONLY runs from a plugin's connect hook (base already
        # deployed), so push the updated tracker config to cis-config now — the
        # store `insights config` reads. Without it the env + tracker-projects
        # yaml are current but `insights config` shows stale keys.
        if _insights_try_apply_captured "$_envf"; then
            if type print_status >/dev/null 2>&1; then print_status "Insights configuration applied"
            else print_info "Insights configuration applied"; fi
        else
            print_info "Captured ${_n} project key(s); will be applied when services start."
        fi
    fi
    return 0
}

# Best-effort push of the captured Ticket Tracker config to the live cis-config
# service (the source `insights config` displays). Only call where services are
# already up. Empty integration body (tracker not enabled) => no push, so this
# can never DELETE/disable the tracker; caller then shows the deferred message.
_insights_try_apply_captured() {
    local envf="$1"
    [ -n "$envf" ] && [ -f "$envf" ] || return 1
    if ! type config_apply_ticket_tracker >/dev/null 2>&1; then
        # shellcheck source=/dev/null
        . "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/adapters/config-adapter.sh" 2>/dev/null || return 1
        type config_apply_ticket_tracker >/dev/null 2>&1 || return 1
    fi
    ( set -a; . "$envf" 2>/dev/null; set +a
      [ -n "$(create_ticket_tracker_integration_json 2>/dev/null)" ] || exit 1
      config_apply_ticket_tracker >/dev/null 2>&1 )
}

_insights_validate_confluence_creds() {
    local base_url="$1" email="$2" token="$3"
    base_url="${base_url%/}"
    base_url="${base_url%/wiki}"

    print_info "Validating Confluence credentials..."
    local http_code
    http_code=$(curl -s -o /dev/null -w "%{http_code}" \
        -u "${email}:${token}" \
        --max-time 15 \
        "${base_url}/wiki/api/v2/spaces" 2>/dev/null)

    if [ "$http_code" = "200" ]; then
        print_success "Confluence credentials validated successfully"
        return 0
    fi

    echo -e "${RED}✗${NC} Confluence credential validation failed (HTTP ${http_code})"
    case "$http_code" in
        401|404) echo "  → Invalid API token, email, or URL. Verify the email address and URL,"
             echo "    and generate a new token at: ${ATLASSIAN_API_TOKEN_URL}" ;;
        403) echo "  → Token lacks Confluence access. Ensure the account has Confluence permissions." ;;
        000) echo "  → Could not connect. Check the URL and network/proxy settings." ;;
        *)   echo "  → Unexpected error. Verify URL, email, and token." ;;
    esac
    return 1
}

ask_git_insights_enabled() {
    if [ -n "${INSIGHTS_GIT_ENABLED:-}" ]; then
        return 0
    fi
    if [[ "${AUTO_SETUP:-}" == "true" ]] || [ ! -t 0 ]; then
        INSIGHTS_GIT_ENABLED="false"; export INSIGHTS_GIT_ENABLED; return 0
    fi
    echo ""
    echo -e "See documentation: ${BLUE}https://docs.bito.ai/ai-architect/installation/install-ai-architect-self-hosted#insights${NC}"
    echo ""
    echo -e "${BLUE}=== Git Insights (optional) ===${NC}"
    echo -e "Analyzes commit history to surface engineering activity insights."
    local ans=""
    read -r -p "Enable Git Insights? [Y/n]: " ans
    if [[ "$ans" =~ ^[Nn]$ ]]; then
        INSIGHTS_GIT_ENABLED="false"
    else
        INSIGHTS_GIT_ENABLED="true"
    fi
    export INSIGHTS_GIT_ENABLED
}

# Prompt for Jira project keys when they're missing. Tries the Jira projects API
# first for interactive selection; falls back to manual entry.
# Caller must have JIRA_DOMAIN, _EMAIL, _API_TOKEN,
# _HOST_TYPE already set.
_ask_ticket_tracker_project_keys() {
    # Resolve current project keys: yaml file takes precedence, env var as fallback.
    local _current_keys="${INSIGHTS_TICKET_TRACKER_PROJECT_KEYS:-}"
    if type _insights_tp_repo_config_path >/dev/null 2>&1; then
        local _pk_cfg
        _pk_cfg=$(_insights_tp_repo_config_path 2>/dev/null)
        if [ -n "$_pk_cfg" ] && [ -f "$_pk_cfg" ]; then
            local _yaml_keys
            _yaml_keys=$(_insights_tp_read_keys "$_pk_cfg" 2>/dev/null | paste -sd, -)
            [ -n "$_yaml_keys" ] && _current_keys="$_yaml_keys"
        fi
    fi
    # A Jira instance switch (recorded in ask_ticket_tracker_config) invalidates the old
    # instance's keys — start fresh so a stale selection can't survive the switch.
    [ -n "${_INSIGHTS_JIRA_INSTANCE_CHANGED:-}" ] && _current_keys=""
    [ -n "$_current_keys" ] && return 0
    if [ ! -t 0 ] || [[ "${AUTO_SETUP:-}" == "true" ]]; then
        return 0
    fi

    log_silent "insights: fetching available Jira projects"
    local _project_list=""
    _project_list=$(_insights_fetch_jira_projects \
        "$JIRA_DOMAIN" \
        "$JIRA_EMAIL" \
        "$JIRA_API_TOKEN" \
        "${JIRA_HOST_TYPE:-cloud}" 2>/dev/null) || true

    if [ -n "$_project_list" ]; then
        local _project_count
        _project_count=$(echo "$_project_list" | wc -l | tr -d ' ')
        log_silent "insights: found ${_project_count} accessible Jira projects"
        printf '\n   %b📁 Which projects should Insights analyze?%b\n' "${BLUE:-}" "${NC:-}" >&2
        # Drop configured keys not on the now-connected instance (e.g. after switching
        # the Jira URL), so "keep current" can't carry keys from a different instance.
        [ -n "$_current_keys" ] && _current_keys=$(_insights_filter_kept_keys "$_project_list" "$_current_keys")
        local _selected=""
        _insights_select_jira_projects _selected "$_current_keys" "$_project_list"
        INSIGHTS_TICKET_TRACKER_PROJECT_KEYS="$_selected"
    else
        echo -e "${YELLOW}⚠${NC}  Could not fetch project list from Jira. Falling back to manual entry."
        echo "Jira project keys to analyze (comma-separated, e.g. PROJ,INFRA)"
        echo "  Press Enter to skip and configure later."
        local _pk_raw=""
        local _pk_attempts=0
        while true; do
            read -r -p "  Project keys: " _pk_raw
            local _normalized=""
            _normalized=$(echo "$_pk_raw" | tr ',' '\n' | awk 'NF{gsub(/^ +| +$/,""); print}' | paste -sd, -)
            if [ -z "$_normalized" ]; then
                INSIGHTS_TICKET_TRACKER_PROJECT_KEYS=""
                break
            fi
            local _bad=""
            local _k
            for _k in $(echo "$_normalized" | tr ',' ' '); do
                if [[ ! "$_k" =~ ^[A-Z][A-Z0-9_]+$ ]]; then
                    _bad="$_k"
                    break
                fi
            done
            if [ -z "$_bad" ]; then
                INSIGHTS_TICKET_TRACKER_PROJECT_KEYS="$_normalized"
                break
            fi
            echo -e "${RED}✗${NC} \"$_bad\" doesn't look like a Jira project key (uppercase letters, digits, underscores)"
            _pk_attempts=$((_pk_attempts+1))
            [ "$_pk_attempts" -ge 3 ] && { print_error "Too many invalid attempts; aborting"; return 1; }
        done
    fi
    export INSIGHTS_TICKET_TRACKER_PROJECT_KEYS

    if [ -n "${INSIGHTS_TICKET_TRACKER_PROJECT_KEYS:-}" ]; then
        local _count
        _count=$(echo "$INSIGHTS_TICKET_TRACKER_PROJECT_KEYS" | awk -F, '{print NF}')
        print_info "Captured ${_count} project key(s); will be applied when services start."
    else
        print_info "No project keys configured. Add them later with:"
        echo -e "  ${YELLOW}bitoarch insights tracker-projects add KEY1 [KEY2 …]${NC}"
        echo -e "  ${YELLOW}bitoarch insights discover-tracker-projects${NC}  (list available projects)"
    fi
}

# Hidden secret read. Uses a WHOLE-LINE `read -s` so echo is disabled for the entire
# read and restored by the shell (including on interrupt) -- a per-character
# `read -s -n1` loop re-enables echo BETWEEN characters, which leaks a PASTED secret
# on many terminals (Windows Terminal / WSL, where a paste arrives as one burst).
# Prints a fixed-width mask on non-empty input (no length leak); empty = keep current.
_tt_read_secret() {   # <prompt> <var-name>
    local _val=""
    printf '%s' "$1" >&2
    IFS= read -r -s _val
    [ -n "$_val" ] && printf '********' >&2
    printf -v "$2" '%s' "$_val"
}

# One-line notice printed before a reuse/override decision: the ticket-tracker
# connection is a SINGLE shared cis-config record, so a change here applies to both
# Insights and every plugin that uses it. Keeps the operator aware of the blast radius.
_insights_tt_shared_notice() {
    printf '   %b⚠ This Jira connection is shared by Insights and installed plugins — a change here applies to all of them.%b\n' "${YELLOW:-}" "${NC:-}" >&2
}

# Shared existing-connection acknowledgement for the ONE ticket-tracker connection — the single
# source used by BOTH the plugin connect flow and `insights enable`. If a connection already exists,
# it prints "Found an existing <provider> connection: <url>" + the shared-blast notice, then asks
# keep/reconfigure. Resolves the creds into the caller's _tt_* vars (for reuse). Returns:
#   0  a connection exists AND the operator kept it (reuse — caller does nothing further)
#   1  no connection exists, OR the operator chose to reconfigure (caller should (re)capture)
# Non-interactive (no TTY / AUTO_SETUP) keeps an existing connection (rc 0). Reads via
# _plugin_prompt_read when the plugin engine provides it (test-stubbable), else a plain TTY read.
# Arg: [provider-noun] (default "Jira").
_insights_tt_confirm_reuse() {
    local _prov="${1:-Jira}"
    type _insights_resolve_tt_creds >/dev/null 2>&1 || return 1
    _tt_base_url="" _tt_email="" _tt_token="" _tt_host_type=""
    _insights_resolve_tt_creds 2>/dev/null && [ -n "${_tt_base_url:-}" ] || return 1
    # Indented directly (not print_info) so the line aligns with the setup block around it.
    printf '   %bℹ%b Found an existing %s connection: %s\n' "${BLUE:-}" "${NC:-}" "$_prov" "$_tt_base_url" >&2
    type _insights_tt_shared_notice >/dev/null 2>&1 && _insights_tt_shared_notice
    local _ans=""
    if { [ -t 0 ] && [ "${AUTO_SETUP:-}" != "true" ]; } || [ "${BITOARCH_PLUGIN_FORCE_PROMPT:-}" = "1" ]; then
        if type _plugin_prompt_read >/dev/null 2>&1; then
            _plugin_prompt_read _ans "   › Keep the current connection? [Y/n]: " 0 || _ans=""
        else
            read -r -p "   › Keep the current connection? [Y/n]: " _ans < /dev/tty || _ans=""
        fi
    fi
    case "$_ans" in [Nn]|[Nn][Oo]) return 1 ;; esac
    # Keeping the service-side connection: mirror it into the base env so the
    # keys hooks and service pods consume (JIRA_DOMAIN / JIRA_HOST_TYPE /
    # JIRA_IS_SELF_HOSTED / creds) match what the operator just kept. The two
    # stores CAN diverge -- a plugin uninstall restores an older env snapshot
    # while the cis-config store keeps the newer connection -- and a stale
    # JIRA_IS_SELF_HOSTED here misroutes the webhook registration.
    _insights_tt_sync_env_from_resolved
    return 0
}

# Upsert the resolved _tt_* connection into the base env (surgical, per-key --
# never rewrites unrelated keys) and export it for the rest of this run.
_insights_tt_sync_env_from_resolved() {
    local _envf _self
    case "$_tt_host_type" in self|self-hosted|server) _self=true ;; *) _self=false ;; esac
    export JIRA_DOMAIN="$_tt_base_url" JIRA_EMAIL="$_tt_email" \
           JIRA_API_TOKEN="$_tt_token" JIRA_HOST_TYPE="$_tt_host_type" \
           JIRA_IS_SELF_HOSTED="$_self"
    type get_config_file >/dev/null 2>&1 && _envf="$(get_config_file 2>/dev/null)"
    [ -n "${_envf:-}" ] && [ -f "$_envf" ] || return 0
    local _k
    for _k in JIRA_DOMAIN JIRA_EMAIL JIRA_API_TOKEN JIRA_HOST_TYPE JIRA_IS_SELF_HOSTED; do
        # Empty resolved piece (e.g. the token endpoint failed) must never blank
        # a value the file already has.
        [ -n "${!_k}" ] && _insights_tt_env_upsert "$_envf" "$_k" "${!_k}"
    done
    return 0
}

# Replace KEY=... in <file> (or append); value passed via ENVIRON so awk never
# interprets regex/escapes in tokens. Mirrors the plugin engine's env setter.
_insights_tt_env_upsert() {   # <file> <key> <value>
    local _file="$1" _key="$2" _val="$3" _tmp
    _tmp="$(mktemp)" || return 0
    if TT_ENV_KEY="$_key" TT_ENV_VALUE="$_val" awk '
        BEGIN { k = ENVIRON["TT_ENV_KEY"]; v = ENVIRON["TT_ENV_VALUE"]; done = 0 }
        index($0, k "=") == 1 { if (!done) { print k "=" v; done = 1 }; next }
        { print }
        END { if (!done) print k "=" v }
    ' "$_file" > "$_tmp" 2>/dev/null; then
        cat "$_tmp" > "$_file"
    fi
    rm -f "$_tmp"
    return 0
}

ask_ticket_tracker_config() {
    # Plugin "Connect Jira" mode (set by the plugin install flow). The plugin needs
    # a fresh ticket-tracker credential capture, NOT the full Insights onboarding:
    #   - force the credential prompt (don't short-circuit on existing values),
    #   - skip the Insights project-keys step (the plugin manages its own project
    #     selection via its manifest-declared selection key, separately),
    #   - frame the question as "Connect Jira now?".
    # A no-op outside the plugin flow (the var is unset there).
    if [ "${_TT_CONNECT_MODE:-0}" = "1" ]; then
        if [ ! -t 0 ] || [ "${AUTO_SETUP:-}" = "true" ]; then
            # Non-interactive: enable only if creds are pre-filled, mirroring below.
            if [ -n "${JIRA_DOMAIN:-}" ] \
               && [ -n "${JIRA_EMAIL:-}" ] \
               && [ -n "${JIRA_API_TOKEN:-}" ]; then
                INSIGHTS_TICKET_TRACKER_ENABLED="true"
            else
                INSIGHTS_TICKET_TRACKER_ENABLED="false"
            fi
            export INSIGHTS_TICKET_TRACKER_ENABLED
            return 0
        fi
        # Interactive: ask to connect, then fall through to the credential prompt
        # with the enable-prompt suppressed and the project-keys step skipped.
        if [ "${INSIGHTS_TICKET_TRACKER_ENABLED:-}" != "true" ]; then
            local _cc=""
            _TT_CONNECT_DECLINED=""
            read -r -p "   › Connect Jira now? [Y/n]: " _cc
            if [[ "$_cc" =~ ^[Nn]$ ]]; then
                # Flag the decline for the plugin hook: with a still-valid prior
                # connection it must end its step here, changing nothing.
                _TT_CONNECT_DECLINED=1
                INSIGHTS_TICKET_TRACKER_ENABLED="false"; export INSIGHTS_TICKET_TRACKER_ENABLED
                return 0
            fi
        fi
        unset INSIGHTS_TICKET_TRACKER_ENABLED
        _INSIGHTS_SKIP_ENABLE_PROMPT=1
        _TT_SKIP_PROJECT_KEYS=1
    fi
    if [ -n "${INSIGHTS_TICKET_TRACKER_ENABLED:-}" ]; then
        if [ "${INSIGHTS_TICKET_TRACKER_ENABLED}" = "true" ] \
           && [ -t 0 ] && [[ "${AUTO_SETUP:-}" != "true" ]]; then
            if [ -n "${JIRA_DOMAIN:-}" ] \
               && [ -n "${JIRA_EMAIL:-}" ] \
               && [ -n "${JIRA_API_TOKEN:-}" ]; then
                if ! _insights_validate_jira_creds "$JIRA_DOMAIN" \
                        "$JIRA_EMAIL" "$JIRA_API_TOKEN" \
                        "${JIRA_HOST_TYPE:-cloud}"; then
                    local _retry=""
                    read -r -p "Existing Jira credentials failed validation. Re-enter? [Y/n]: " _retry
                    if [[ ! "$_retry" =~ ^[Nn]$ ]]; then
                        _INSIGHTS_SKIP_ENABLE_PROMPT=1
                        unset INSIGHTS_TICKET_TRACKER_ENABLED
                        ask_ticket_tracker_config
                        return $?
                    fi
                    echo -e "${YELLOW}⚠${NC}  Proceeding with unvalidated credentials. Update later with: ${YELLOW}bitoarch insights update-ticket-tracker-config${NC}"
                fi
                _ask_ticket_tracker_project_keys
                return 0
            fi
            echo -e "\n${YELLOW}⚠${NC}  Ticket Tracker enabled but credentials incomplete — prompting now."
        else
            return 0
        fi
    fi

    # Non-interactive / AUTO_SETUP: enable if pre-filled, else disable
    if [ ! -t 0 ] || [[ "${AUTO_SETUP:-}" == "true" ]]; then
        if [ -n "${JIRA_DOMAIN:-}" ] && \
           [ -n "${JIRA_EMAIL:-}" ] && \
           [ -n "${JIRA_API_TOKEN:-}" ]; then
            INSIGHTS_TICKET_TRACKER_ENABLED="true"
            INSIGHTS_TICKET_TRACKER_PROVIDER="${INSIGHTS_TICKET_TRACKER_PROVIDER:-jira}"
            INSIGHTS_TICKET_TRACKER_AUTH_TYPE="${INSIGHTS_TICKET_TRACKER_AUTH_TYPE:-api-token}"
            JIRA_HOST_TYPE="${JIRA_HOST_TYPE:-cloud}"
            export INSIGHTS_TICKET_TRACKER_ENABLED INSIGHTS_TICKET_TRACKER_PROVIDER \
                INSIGHTS_TICKET_TRACKER_AUTH_TYPE JIRA_DOMAIN \
                JIRA_EMAIL \
                JIRA_API_TOKEN JIRA_HOST_TYPE \
                JIRA_CLOUD_ID INSIGHTS_TICKET_TRACKER_PROJECT_KEYS
            return 0
        fi
        INSIGHTS_TICKET_TRACKER_ENABLED="false"
        export INSIGHTS_TICKET_TRACKER_ENABLED
        return 0
    fi

    if [[ "${_INSIGHTS_SKIP_ENABLE_PROMPT:-}" != "1" ]] && [ "${INSIGHTS_TICKET_TRACKER_ENABLED:-}" != "true" ]; then
        echo ""
        echo -e "${BLUE}=== Ticket Tracker Insights (optional) ===${NC}"
        echo -e "Links Jira ticket activity to engineering work for richer insights."
        local ans=""
        read -r -p "Enable Ticket Tracker Insights? [Y/n]: " ans
        if [[ "$ans" =~ ^[Nn]$ ]]; then
            INSIGHTS_TICKET_TRACKER_ENABLED="false"
            export INSIGHTS_TICKET_TRACKER_ENABLED
            return 0
        fi
    fi

    INSIGHTS_TICKET_TRACKER_ENABLED="true"
    INSIGHTS_TICKET_TRACKER_PROVIDER="${INSIGHTS_TICKET_TRACKER_PROVIDER:-jira}"
    INSIGHTS_TICKET_TRACKER_AUTH_TYPE="${INSIGHTS_TICKET_TRACKER_AUTH_TYPE:-api-token}"

    # Show existing values as defaults (press Enter to keep).
    local _cur_url="${JIRA_DOMAIN:-}"
    local _cur_email="${JIRA_EMAIL:-}"
    local _cur_host="${JIRA_HOST_TYPE:-}"
    local _cur_cloud="${JIRA_CLOUD_ID:-}"

    local _attempts
    _attempts=0
    while true; do
        local _default_hint=""
        [ -n "$_cur_url" ] && _default_hint=" [${_cur_url}]"
        echo ""
        echo "   Atlassian site URL (the URL you visit in the browser):"
        echo "   e.g. https://acme.atlassian.net  (NOT the api.atlassian.com/ex/jira/... form)"
        local _input=""
        read -r -p "   › Jira URL${_default_hint}: " _input
        [ -z "$_input" ] && [ -n "$_cur_url" ] && _input="$_cur_url"
        if _insights_validate_url "$_input"; then
            JIRA_DOMAIN=$(_insights_normalize_jira_url "$_input")
            break
        fi
        echo -e "${RED}✗${NC} URL must look like https://your-tenant.atlassian.net (no spaces)"
        _attempts=$((_attempts+1))
        [ "$_attempts" -ge 3 ] && { print_error "Too many invalid attempts; aborting"; return 1; }
    done

    # Detect a Jira instance switch: if the entered URL differs from the previously
    # configured one (any cloud<->cloud, self<->self, or cross switch), only RECORD it
    # here (a plain global, so it survives the host-type re-loop below). The prior keys
    # are NOT cleared yet — that happens only once the new instance validates (at the
    # project step), so a mistyped URL or a new instance that fails to validate leaves
    # the previous instance + keys untouched. The plugin fan-out also reads this flag to
    # reset config derived from the old instance (watched projects, respond mode, webhook).
    if [ -n "$_cur_url" ] \
       && [ "$(_insights_normalize_jira_url "$_cur_url")" != "$(_insights_normalize_jira_url "$JIRA_DOMAIN")" ]; then
        _INSIGHTS_JIRA_INSTANCE_CHANGED=1
    fi

    _attempts=0
    while true; do
        local _default_hint=""
        [ -n "$_cur_email" ] && _default_hint=" [${_cur_email}]"
        local _input=""
        read -r -p "   › Email${_default_hint}: " _input
        [ -z "$_input" ] && [ -n "$_cur_email" ] && _input="$_cur_email"
        if _insights_validate_email "$_input"; then
            JIRA_EMAIL="$_input"
            break
        fi
        echo -e "${RED}✗${NC} Doesn't look like a valid email address"
        _attempts=$((_attempts+1))
        [ "$_attempts" -ge 3 ] && { print_error "Too many invalid attempts; aborting"; return 1; }
    done

    local _token_hint=""
    [ -n "${JIRA_API_TOKEN:-}" ] && _token_hint=" (press Enter to keep current)"
    local _input=""
    _tt_read_secret "   › API token (hidden)${_token_hint}: " _input
    echo ""
    [ -n "$_input" ] && JIRA_API_TOKEN="$_input"
    _attempts=0
    while [ -z "${JIRA_API_TOKEN:-}" ]; do
        _tt_read_secret "   › API token (hidden): " JIRA_API_TOKEN
        echo ""
        _attempts=$((_attempts+1))
        [ "$_attempts" -ge 3 ] && { print_error "Too many empty attempts; aborting"; return 1; }
    done

    echo ""
    local _host_default_hint=""
    if [ -n "$_cur_host" ]; then
        local _host_num="1"
        [ "$_cur_host" = "self" ] && _host_num="2"
        _host_default_hint=" [${_host_num} = ${_cur_host}]"
    fi
    local host_choice=""
    while [ -z "$host_choice" ]; do
        read -r -p "   › Host type (1) cloud  (2) self${_host_default_hint}  [1]: " host_choice
        if [ -z "$host_choice" ]; then
            if [ -n "$_cur_host" ]; then
                JIRA_HOST_TYPE="$_cur_host"
            else
                JIRA_HOST_TYPE="cloud"
            fi
            host_choice="done"
        else
            host_choice="${host_choice//[$'\r\n\t ']/}"   # tolerate stray CR/whitespace from the masked read so '2' still matches
            case "$host_choice" in
                1) JIRA_HOST_TYPE="cloud" ;;
                2) JIRA_HOST_TYPE="self" ;;
                *) echo -e "${RED}✗${NC} Invalid choice"; host_choice="" ;;
            esac
        fi
    done

    if [ "$JIRA_HOST_TYPE" = "self" ] \
       && echo "$JIRA_DOMAIN" | grep -qi '\.atlassian\.net'; then
        print_warning "URL looks like Atlassian Cloud (*.atlassian.net) but host type is 'self'."
        local _confirm=""
        read -r -p "  Switch to cloud? [Y/n]: " _confirm
        if [[ ! "$_confirm" =~ ^[Nn]$ ]]; then
            JIRA_HOST_TYPE="cloud"
            echo -e "  → Host type set to ${GREEN}cloud${NC}"
        else
            echo -e "${RED}✗${NC} Cloud URL (*.atlassian.net) cannot be used with host type 'self'."
            echo -e "  Change the URL or select host type (1) cloud."
            _INSIGHTS_SKIP_ENABLE_PROMPT=1
            unset INSIGHTS_TICKET_TRACKER_ENABLED
            ask_ticket_tracker_config
            return $?
        fi
    elif [ "$JIRA_HOST_TYPE" = "cloud" ] \
       && ! echo "$JIRA_DOMAIN" | grep -qi '\.atlassian\.net'; then
        print_warning "URL does not look like Atlassian Cloud (*.atlassian.net) but host type is 'cloud'."
        local _confirm=""
        read -r -p "  Switch to self-hosted? [Y/n]: " _confirm
        if [[ ! "$_confirm" =~ ^[Nn]$ ]]; then
            JIRA_HOST_TYPE="self"
            echo -e "  → Host type set to ${GREEN}self${NC}"
        else
            # Don't proceed to a validation that will fail: a non-Atlassian-Cloud URL
            # can't authenticate as Cloud. Re-loop so the user fixes the URL or picks
            # host type (2) self (mirrors the Cloud-URL + self-type case above).
            echo -e "${RED}✗${NC} A non-Atlassian-Cloud URL cannot be used with host type 'cloud'."
            echo -e "  Change the URL or select host type (2) self."
            _INSIGHTS_SKIP_ENABLE_PROMPT=1
            unset INSIGHTS_TICKET_TRACKER_ENABLED
            ask_ticket_tracker_config
            return $?
        fi
    fi

    if [ "$JIRA_HOST_TYPE" = "cloud" ] && [ "$INSIGHTS_TICKET_TRACKER_AUTH_TYPE" != "api-token" ]; then
        _attempts=0
        while true; do
            local _default_hint=""
            [ -n "$_cur_cloud" ] && _default_hint=" [${_cur_cloud}]"
            echo "Cloud ID — UUID only, no URL."
            echo "  Find it by visiting https://${JIRA_DOMAIN#*//}/_edge/tenant_info"
            echo "  Copy the \"cloudId\" value (format: 8-4-4-4-12 hex chars)"
            local _input=""
            read -r -p "  Cloud ID${_default_hint}: " _input
            [ -z "$_input" ] && [ -n "$_cur_cloud" ] && _input="$_cur_cloud"
            if _insights_validate_uuid "$_input"; then
                JIRA_CLOUD_ID="$_input"
                break
            fi
            echo -e "${RED}✗${NC} Not a valid UUID — expected format 8-4-4-4-12 hex chars (e.g. 88384793-8547-4ed1-adf9-492d6539b990)"
            _attempts=$((_attempts+1))
            [ "$_attempts" -ge 3 ] && { print_error "Too many invalid attempts; aborting"; return 1; }
        done
    fi

    export INSIGHTS_TICKET_TRACKER_ENABLED INSIGHTS_TICKET_TRACKER_PROVIDER \
        INSIGHTS_TICKET_TRACKER_AUTH_TYPE JIRA_DOMAIN \
        JIRA_EMAIL \
        JIRA_API_TOKEN JIRA_HOST_TYPE \
        JIRA_CLOUD_ID INSIGHTS_TICKET_TRACKER_PROJECT_KEYS

    echo ""
    if ! _insights_validate_jira_creds "$JIRA_DOMAIN" \
            "$JIRA_EMAIL" "$JIRA_API_TOKEN" \
            "$JIRA_HOST_TYPE"; then
        local _retry=""
        # _insights_validate_jira_creds already prints the token hint on HTTP 401;
        # don't print it again here.
        read -r -p "Credentials failed validation. Retry? [Y/n]: " _retry
        if [[ ! "$_retry" =~ ^[Nn]$ ]]; then
            _INSIGHTS_SKIP_ENABLE_PROMPT=1
            unset INSIGHTS_TICKET_TRACKER_ENABLED
            ask_ticket_tracker_config
            return $?
        fi
        # Declined retry on credentials that just failed validation — do NOT enable
        # ticket-tracker with invalid creds. Leave it disabled; configure later.
        INSIGHTS_TICKET_TRACKER_ENABLED="false"
        export INSIGHTS_TICKET_TRACKER_ENABLED
        # Clear the failed creds from this process: they were exported before the
        # validation ran, and a downstream "is Jira connected" check must not
        # mistake them for a live connection.
        unset JIRA_DOMAIN JIRA_EMAIL JIRA_API_TOKEN JIRA_HOST_TYPE JIRA_IS_SELF_HOSTED JIRA_CLOUD_ID
        print_error "Ticket Tracker not enabled — credentials could not be validated."
        echo -e "  Configure valid credentials later with: ${YELLOW}bitoarch insights update-ticket-tracker-config${NC}"
        return 1
    fi

    # Plugin connect mode: the credentials are captured; the plugin owns its own
    # project selection (its manifest-declared selection key), so skip the Insights
    # project-keys step entirely.
    if [ "${_TT_SKIP_PROJECT_KEYS:-0}" = "1" ]; then
        INSIGHTS_TICKET_TRACKER_ENABLED="true"
        export INSIGHTS_TICKET_TRACKER_ENABLED
        return 0
    fi

    # Resolve current project keys: yaml file takes precedence, env var as fallback.
    local _current_keys="${INSIGHTS_TICKET_TRACKER_PROJECT_KEYS:-}"
    if type _insights_tp_repo_config_path >/dev/null 2>&1; then
        local _pk_cfg
        _pk_cfg=$(_insights_tp_repo_config_path 2>/dev/null)
        if [ -n "$_pk_cfg" ] && [ -f "$_pk_cfg" ]; then
            local _yaml_keys
            _yaml_keys=$(_insights_tp_read_keys "$_pk_cfg" 2>/dev/null | paste -sd, -)
            [ -n "$_yaml_keys" ] && _current_keys="$_yaml_keys"
        fi
    fi
    # Instance switched (URL changed above) → the prior keys belong to a different Jira
    # instance; ignore them (env + yaml) so selection starts fresh. Leave the flag SET so the
    # plugin fan-out (after ask_ticket_tracker_config returns) still sees the switch; each flow
    # clears it up front before its own ask_ticket_tracker_config call.
    if [ -n "${_INSIGHTS_JIRA_INSTANCE_CHANGED:-}" ]; then
        _current_keys=""
    fi

    # Fetch accessible Jira projects and let the user pick (mirrors repo selection flow).
    # Falls back to manual entry if the API call fails.
    log_silent "insights: fetching available Jira projects"
    local _project_list=""
    _project_list=$(_insights_fetch_jira_projects \
        "$JIRA_DOMAIN" \
        "$JIRA_EMAIL" \
        "$JIRA_API_TOKEN" \
        "$JIRA_HOST_TYPE" 2>/dev/null) || true

    if [ -n "$_project_list" ]; then
        local _project_count
        _project_count=$(echo "$_project_list" | wc -l | tr -d ' ')
        log_silent "insights: found ${_project_count} accessible Jira projects"
        printf '\n   %b📁 Which projects should Insights analyze?%b\n' "${BLUE:-}" "${NC:-}" >&2
        # Drop configured keys not on the now-connected instance (e.g. after switching
        # the Jira URL), so "keep current" can't carry keys from a different instance.
        [ -n "$_current_keys" ] && _current_keys=$(_insights_filter_kept_keys "$_project_list" "$_current_keys")
        local _selected=""
        _insights_select_jira_projects _selected "$_current_keys" "$_project_list"
        INSIGHTS_TICKET_TRACKER_PROJECT_KEYS="$_selected"
    elif [ -z "$_current_keys" ]; then
        echo -e "${YELLOW}⚠${NC}  Could not fetch project list from Jira. Falling back to manual entry."
        echo "Jira project keys to analyze (comma-separated, e.g. PROJ,INFRA)"
        echo "  Press Enter to skip and configure later."
        local _pk_raw=""
        local _pk_attempts=0
        while true; do
            read -r -p "  Project keys: " _pk_raw
            local _normalized=""
            _normalized=$(echo "$_pk_raw" | tr ',' '\n' | awk 'NF{gsub(/^ +| +$/,""); print}' | paste -sd, -)
            if [ -z "$_normalized" ]; then
                INSIGHTS_TICKET_TRACKER_PROJECT_KEYS=""
                break
            fi
            local _bad=""
            local _k
            for _k in $(echo "$_normalized" | tr ',' ' '); do
                if [[ ! "$_k" =~ ^[A-Z][A-Z0-9_]+$ ]]; then
                    _bad="$_k"
                    break
                fi
            done
            if [ -z "$_bad" ]; then
                INSIGHTS_TICKET_TRACKER_PROJECT_KEYS="$_normalized"
                break
            fi
            echo -e "${RED}✗${NC} \"$_bad\" doesn't look like a Jira project key (uppercase letters, digits, underscores)"
            _pk_attempts=$((_pk_attempts+1))
            [ "$_pk_attempts" -ge 3 ] && { print_error "Too many invalid attempts; aborting"; return 1; }
        done
    fi
    export INSIGHTS_TICKET_TRACKER_PROJECT_KEYS

    if [ -n "${INSIGHTS_TICKET_TRACKER_PROJECT_KEYS:-}" ]; then
        local _count
        _count=$(echo "$INSIGHTS_TICKET_TRACKER_PROJECT_KEYS" | awk -F, '{print NF}')
        print_info "Captured ${_count} project key(s); will be applied when services start."
    else
        print_info "No project keys configured. Add them later with:"
        echo -e "  ${YELLOW}bitoarch insights tracker-projects add KEY1 [KEY2 …]${NC}"
        echo -e "  ${YELLOW}bitoarch insights discover-tracker-projects${NC}  (list available projects)"
    fi
}

_ask_lookback_for_feature() {
    local _label="$1" _var="$2"
    local _cur="${!_var:-}"
    local _default="${_cur:-180}"

    # Auto-accept when this feature's lookback is already set,
    # or when running non-interactively. Otherwise prompt.
    if [ -n "$_cur" ] \
       || [ ! -t 0 ] || [[ "${AUTO_SETUP:-}" == "true" ]]; then
        eval "$_var=\"${_default}\""
        export "$_var"
        # Confirm a preseeded value with an explicit label so it is unambiguous
        # which setting (Git vs Jira) it applied to — matching the API-key/Jira
        # "already validated" pattern; skip the interactive-looking prompt.
        [ -n "$_cur" ] && echo -e "${GREEN}✓${NC} ${_label} lookback: ${_default} days"
        return 0
    fi

    local _input=""
    read -r -p "${_label} lookback days [${_default}]: " _input
    _input="${_input:-${_default}}"
    if [[ "$_input" =~ ^[0-9]+$ ]] && [ "$_input" -ge 1 ] && [ "$_input" -le 730 ]; then
        eval "$_var=\"$_input\""
    else
        echo -e "${YELLOW}⚠${NC}  Invalid value; using default of 180 days"
        eval "$_var=\"180\""
    fi
    export "$_var"

    if [ -n "$_cur" ] && [ "$_cur" != "${!_var}" ]; then
        echo ""
        print_warning "${_label} lookback changed from ${_cur} to ${!_var} days."
        if [ -z "${_INSIGHTS_SUPPRESS_RUN_HINT:-}" ]; then
            echo -e "  Run ${YELLOW}bitoarch insights run --force${NC} to re-analyze with the new window."
        fi
    fi
}

ask_insights_lookback_days() {
    # Only prompt when at least one insights feature is being enabled.
    if [ "${INSIGHTS_GIT_ENABLED:-}" != "true" ] && \
       [ "${INSIGHTS_TICKET_TRACKER_ENABLED:-}" != "true" ]; then
        return 0
    fi

    # Print the interactive section header ONLY when at least one enabled feature
    # will actually prompt (interactive + no preseeded value). Fully preseeded runs
    # confirm each value inline (below) instead of rendering a prompt-style header
    # that never pauses — the API-key/Jira preseed behavior.
    local _will_prompt=0
    if [ -t 0 ] && [ "${AUTO_SETUP:-}" != "true" ]; then
        { [ "${INSIGHTS_GIT_ENABLED:-}" = "true" ] && [ -z "${INSIGHTS_GIT_LOOKBACK_DAYS:-}" ]; } && _will_prompt=1
        { [ "${INSIGHTS_TICKET_TRACKER_ENABLED:-}" = "true" ] && [ -z "${INSIGHTS_JIRA_LOOKBACK_DAYS:-}" ]; } && _will_prompt=1
    fi
    if [ "$_will_prompt" -eq 1 ]; then
        echo ""
        echo -e "${BLUE}=== Insights Lookback Period ===${NC}"
        echo -e "Number of days of history to analyze."
    fi

    # Git and Jira are SEPARATE lookback settings — always handle each enabled
    # feature independently (both prompt when unset, both confirm when preseeded).
    if [ "${INSIGHTS_GIT_ENABLED:-}" = "true" ]; then
        _ask_lookback_for_feature "Git" "INSIGHTS_GIT_LOOKBACK_DAYS"
    fi
    if [ "${INSIGHTS_TICKET_TRACKER_ENABLED:-}" = "true" ]; then
        _ask_lookback_for_feature "Jira" "INSIGHTS_JIRA_LOOKBACK_DAYS"
    fi
}

ask_docs_config() {
    if [ -n "${INSIGHTS_DOCS_ENABLED:-}" ]; then
        if [ "${INSIGHTS_DOCS_ENABLED}" = "true" ] \
           && [ -t 0 ] && [[ "${AUTO_SETUP:-}" != "true" ]]; then
            if [ -n "${INSIGHTS_DOCS_URL:-}" ] \
               && [ -n "${INSIGHTS_DOCS_EMAIL:-}" ] \
               && [ -n "${INSIGHTS_DOCS_API_TOKEN:-}" ]; then
                if ! _insights_validate_confluence_creds "$INSIGHTS_DOCS_URL" \
                        "$INSIGHTS_DOCS_EMAIL" "$INSIGHTS_DOCS_API_TOKEN"; then
                    local _retry=""
                    read -r -p "Existing Confluence credentials failed validation. Re-enter? [Y/n]: " _retry
                    if [[ ! "$_retry" =~ ^[Nn]$ ]]; then
                        _INSIGHTS_SKIP_ENABLE_PROMPT=1
                        unset INSIGHTS_DOCS_ENABLED
                        ask_docs_config
                        return $?
                    fi
                    echo -e "${YELLOW}⚠${NC}  Proceeding with unvalidated credentials. Update later with: ${YELLOW}bitoarch insights update-doc-config${NC}"
                fi
                return 0
            fi
            echo -e "\n${YELLOW}⚠${NC}  Docs enabled but credentials incomplete — prompting now."
        else
            return 0
        fi
    fi
    if [[ "${_INSIGHTS_SKIP_ENABLE_PROMPT:-}" != "1" ]] && [ "${INSIGHTS_TICKET_TRACKER_ENABLED:-}" != "true" ]; then
        INSIGHTS_DOCS_ENABLED="false"
        export INSIGHTS_DOCS_ENABLED
        [ -t 0 ] && echo -e "\n${BLUE}ℹ${NC}  Skipping docs setup — requires ticket tracker to be enabled first."
        return 0
    fi

    # Non-interactive / AUTO_SETUP: accept pre-filled values or skip
    if [ ! -t 0 ] || [[ "${AUTO_SETUP:-}" == "true" ]]; then
        if [ -n "${INSIGHTS_DOCS_URL:-}" ] && \
           [ -n "${INSIGHTS_DOCS_EMAIL:-}" ] && \
           [ -n "${INSIGHTS_DOCS_API_TOKEN:-}" ]; then
            INSIGHTS_DOCS_ENABLED="true"
            INSIGHTS_DOCS_PROVIDER="${INSIGHTS_DOCS_PROVIDER:-confluence}"
            INSIGHTS_DOCS_AUTH_TYPE="${INSIGHTS_DOCS_AUTH_TYPE:-api-token}"
            export INSIGHTS_DOCS_ENABLED INSIGHTS_DOCS_PROVIDER INSIGHTS_DOCS_AUTH_TYPE \
                INSIGHTS_DOCS_URL INSIGHTS_DOCS_EMAIL INSIGHTS_DOCS_API_TOKEN INSIGHTS_DOCS_CLOUD_ID
            return 0
        fi
        INSIGHTS_DOCS_ENABLED="false"
        export INSIGHTS_DOCS_ENABLED
        return 0
    fi

    if [[ "${_INSIGHTS_SKIP_ENABLE_PROMPT:-}" != "1" ]] && [ "${INSIGHTS_DOCS_ENABLED:-}" != "true" ]; then
        echo ""
        echo -e "${BLUE}=== Confluence Docs (optional) ===${NC}"
        echo -e "Adds Confluence as docs source for richer ticket-link context."
        local ans=""
        read -r -p "Enable Confluence integration? [Y/n]: " ans
        if [[ "$ans" =~ ^[Nn]$ ]]; then
            INSIGHTS_DOCS_ENABLED="false"
            export INSIGHTS_DOCS_ENABLED
            return 0
        fi
    fi

    INSIGHTS_DOCS_ENABLED="true"
    INSIGHTS_DOCS_PROVIDER="${INSIGHTS_DOCS_PROVIDER:-confluence}"
    INSIGHTS_DOCS_AUTH_TYPE="${INSIGHTS_DOCS_AUTH_TYPE:-api-token}"

    local default_url="${INSIGHTS_DOCS_URL:-${JIRA_DOMAIN%/}}"
    local _cur_email="${INSIGHTS_DOCS_EMAIL:-${JIRA_EMAIL}}"
    local _cur_cloud="${INSIGHTS_DOCS_CLOUD_ID:-${JIRA_CLOUD_ID}}"

    echo ""
    local _attempts=0
    while true; do
        local _input=""
        read -r -p "Confluence URL [${default_url}]: " _input
        _input="${_input:-$default_url}"
        if _insights_validate_url "$_input"; then
            INSIGHTS_DOCS_URL="${_input%/}"
            INSIGHTS_DOCS_URL="${INSIGHTS_DOCS_URL%/wiki}"
            break
        fi
        echo -e "${RED}✗${NC} URL must look like https://your-tenant.atlassian.net (with or without /wiki — we normalize)"
        _attempts=$((_attempts+1))
        [ "$_attempts" -ge 3 ] && { print_error "Too many invalid attempts; aborting"; return 1; }
    done

    _attempts=0
    while true; do
        local _input=""
        read -r -p "Confluence email [${_cur_email}]: " _input
        _input="${_input:-$_cur_email}"
        if _insights_validate_email "$_input"; then
            INSIGHTS_DOCS_EMAIL="$_input"
            break
        fi
        echo -e "${RED}✗${NC} Doesn't look like a valid email address"
        _attempts=$((_attempts+1))
        [ "$_attempts" -ge 3 ] && { print_error "Too many invalid attempts; aborting"; return 1; }
    done

    local _token_hint=""
    [ -n "${INSIGHTS_DOCS_API_TOKEN:-}" ] && _token_hint=" (press Enter to keep current)"
    local _input=""
    read -s -p "Confluence API token (input hidden)${_token_hint}: " _input
    echo ""
    [ -n "$_input" ] && INSIGHTS_DOCS_API_TOKEN="$_input"
    _attempts=0
    while [ -z "${INSIGHTS_DOCS_API_TOKEN:-}" ]; do
        read -s -p "Confluence API token (input hidden): " INSIGHTS_DOCS_API_TOKEN
        echo ""
        _attempts=$((_attempts+1))
        [ "$_attempts" -ge 3 ] && { print_error "Too many empty attempts; aborting"; return 1; }
    done

    if [ "$INSIGHTS_DOCS_AUTH_TYPE" != "api-token" ]; then
        _attempts=0
        while true; do
            local _input=""
            read -r -p "Cloud ID [${_cur_cloud}] (UUID only, no URL): " _input
            _input="${_input:-$_cur_cloud}"
            if _insights_validate_uuid "$_input"; then
                INSIGHTS_DOCS_CLOUD_ID="$_input"
                break
            fi
            echo -e "${RED}✗${NC} Not a valid UUID — expected format 8-4-4-4-12 hex chars"
            _attempts=$((_attempts+1))
            [ "$_attempts" -ge 3 ] && { print_error "Too many invalid attempts; aborting"; return 1; }
        done
    fi

    export INSIGHTS_DOCS_ENABLED INSIGHTS_DOCS_PROVIDER INSIGHTS_DOCS_AUTH_TYPE \
        INSIGHTS_DOCS_URL INSIGHTS_DOCS_EMAIL INSIGHTS_DOCS_API_TOKEN INSIGHTS_DOCS_CLOUD_ID

    echo ""
    if ! _insights_validate_confluence_creds "$INSIGHTS_DOCS_URL" \
            "$INSIGHTS_DOCS_EMAIL" "$INSIGHTS_DOCS_API_TOKEN"; then
        local _retry=""
        echo "  Generate a new token at: ${ATLASSIAN_API_TOKEN_URL}"
        read -r -p "Credentials failed validation. Retry? [Y/n]: " _retry
        if [[ ! "$_retry" =~ ^[Nn]$ ]]; then
            _INSIGHTS_SKIP_ENABLE_PROMPT=1
            unset INSIGHTS_DOCS_ENABLED
            ask_docs_config
            return $?
        fi
        # Declined retry on credentials that just failed validation — do NOT enable
        # docs with invalid creds. Leave it disabled; configure later.
        INSIGHTS_DOCS_ENABLED="false"
        export INSIGHTS_DOCS_ENABLED
        print_error "Confluence docs not enabled — credentials could not be validated."
        echo -e "  Configure valid credentials later with: ${YELLOW}bitoarch insights update-doc-config${NC}"
        return 1
    fi
}

export -f _insights_normalize_jira_url
export -f _insights_fetch_jira_projects
export -f _jira_pick_projects
export -f _insights_select_jira_projects
export -f ask_git_insights_enabled
export -f ask_ticket_tracker_config
export -f _insights_tt_shared_notice
export -f _insights_tt_confirm_reuse
export -f _ask_lookback_for_feature
export -f ask_insights_lookback_days
export -f ask_docs_config
