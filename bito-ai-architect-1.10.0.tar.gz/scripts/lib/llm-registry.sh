#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
#
# scripts/lib/llm-registry.sh
# -----------------------------------------------------------------------------
# Single source of truth for LLM provider metadata. Prompting, env-var
# persistence, the install.yaml<->env mapping, non-interactive preset detection,
# default-provider selection, and the cis-config payload are all derived from
# llm_registry() below — so adding a provider is one JSON object, not edits
# scattered across llm-config.sh, config-adapter.sh and install-yaml.sh.
#
# Each field flows through an optional two-hook pipeline:
#   prompt -> pre_process (validate+convert input->env) -> .env-llm-bitoarch
#          -> post_process (validate+convert env->config) -> cis-config payload
# pre_process runs on the interactive path and on preset/yaml values for direct
# providers; the exclusive gateway (Portkey) is persisted without hooks, so
# post_process always re-validates in the payload builder.
#
# Parsed with jq (a hard dependency). Stays bash-3.2 safe (no associative
# arrays / mapfile): registry rows are streamed via `jq | while read`.
# -----------------------------------------------------------------------------

if [ -n "${_LLM_REGISTRY_LOADED:-}" ]; then
    return 0
fi
_LLM_REGISTRY_LOADED=1

# -----------------------------------------------------------------------------
# Provider metadata registry.
# Provider keys : id, label, menu_order, rank, exclusive, detect_env_keys, fields,
#                 info_display (indexing-info block only: { order, default_model,
#                 cost_per_mb, message }; rows print sorted by order). When
#                 cost_per_mb is empty the message is shown instead of a figure
#                 -- e.g. gateways / routed providers whose cost depends on the
#                 model they route to. Order + messaging live here, not in code.
# Field keys    : env, kind(secret|text), config(payload path or omit),
#                 install_yaml_key, prompt, required(default true),
#                 pre_process / post_process (hook fn names, optional)
# -----------------------------------------------------------------------------
# Cached once at source time so accessors avoid re-spawning `cat` on every call.
_LLM_REGISTRY_JSON="$(cat <<'EOF'
{
  "providers": [
    { "id": "anthropic", "label": "Anthropic", "menu_order": 1, "rank": 3,
      "info_display": { "order": 1, "default_model": "Claude Haiku 4.5", "cost_per_mb": "1.00", "message": "" },
      "exclusive": false, "detect_env_keys": ["ANTHROPIC_API_TOKEN"],
      "fields": [
        { "env": "ANTHROPIC_API_TOKEN", "kind": "secret", "config": "api_key",
          "install_yaml_key": ".llm.anthropic_api_token",
          "prompt": "Enter Anthropic API token (input hidden):" }
      ] },
    { "id": "openai", "label": "OpenAI", "menu_order": 2, "rank": 2,
      "info_display": { "order": 2, "default_model": "o4-mini", "cost_per_mb": "1.20", "message": "" },
      "exclusive": false, "detect_env_keys": ["OPENAI_API_TOKEN"],
      "fields": [
        { "env": "OPENAI_API_TOKEN", "kind": "secret", "config": "api_key",
          "install_yaml_key": ".llm.openai_api_token",
          "prompt": "Enter OpenAI API token (input hidden):" }
      ] },
    { "id": "portkey", "label": "Portkey", "menu_order": 3, "rank": 1,
      "info_display": { "order": 8, "default_model": "Common models", "cost_per_mb": "", "message": "Refer to benchmark estimates above" },
      "exclusive": true, "detect_env_keys": ["PORTKEY_API_TOKEN"],
      "fields": [
        { "env": "PORTKEY_API_URL", "kind": "text", "required": false, "config": "api_url",
          "pre_process": "_pre_portkey_url",
          "install_yaml_key": ".llm.portkey_api_url",
          "prompt": "Enter Portkey API URL (press Enter to use default: https://api.portkey.ai/v1):" },
        { "env": "PORTKEY_MODEL_NAME", "kind": "text", "config": "model",
          "pre_process": "_pre_portkey_model",
          "install_yaml_key": ".llm.portkey_model_name",
          "prompt": "Enter Portkey model (format: @provider/model-name):" },
        { "env": "PORTKEY_API_TOKEN", "kind": "secret", "config": "api_key",
          "install_yaml_key": ".llm.portkey_api_token",
          "prompt": "Enter Portkey API token (input hidden):" }
      ] },
    { "id": "vertex-ai", "label": "Google Vertex AI", "menu_order": 4, "rank": 4,
      "info_display": { "order": 7, "default_model": "Common models", "cost_per_mb": "", "message": "Refer to benchmark estimates above" },
      "exclusive": false, "detect_env_keys": ["VERTEX_SERVICE_ACCOUNT_KEY_JSON"],
      "fields": [
        { "env": "VERTEX_SERVICE_ACCOUNT_KEY_JSON", "kind": "text",
          "config": "additional.service_account_key_json",
          "pre_process": "_pre_vertex_sa_file", "post_process": "_post_vertex_sa_json",
          "install_yaml_key": ".llm.vertex_service_account_key_json",
          "prompt": "Enter path to your GCP service-account JSON file:" },
        { "env": "VERTEX_PROJECT", "kind": "text", "config": "additional.project_id",
          "install_yaml_key": ".llm.vertex_project",
          "prompt": "Enter GCP Project ID:" },
        { "env": "VERTEX_REGION", "kind": "text", "config": "additional.region",
          "install_yaml_key": ".llm.vertex_region",
          "prompt": "Enter GCP Region (e.g. us-central1):" },
        { "env": "VERTEX_MODEL", "kind": "text", "required": false, "config": "model",
          "install_yaml_key": ".llm.vertex_model",
          "prompt": "Enter Vertex model (optional, press Enter to use the workspace default):" }
      ] },
    { "id": "azure-ai", "label": "Azure AI", "menu_order": 5, "rank": 5,
      "info_display": { "order": 3, "default_model": "o4-mini", "cost_per_mb": "1.20", "message": "" },
      "exclusive": false, "detect_env_keys": ["AZURE_AI_API_KEY"],
      "fields": [
        { "env": "AZURE_AI_ENDPOINT", "kind": "text", "config": "additional.endpoint",
          "pre_process": "_https_or_fail", "post_process": "_https_or_fail",
          "install_yaml_key": ".llm.azure_ai_endpoint",
          "prompt": "Enter Azure AI endpoint (e.g. https://<resource>.openai.azure.com):" },
        { "env": "AZURE_AI_API_KEY", "kind": "secret", "config": "api_key",
          "install_yaml_key": ".llm.azure_ai_api_key",
          "prompt": "Enter Azure AI API token (input hidden):" }
      ] },
    { "id": "novita", "label": "Novita", "menu_order": 6, "rank": 7,
      "info_display": { "order": 4, "default_model": "MiniMax-M2", "cost_per_mb": "0.50", "message": "" },
      "exclusive": false, "detect_env_keys": ["NOVITA_API_TOKEN"],
      "fields": [
        { "env": "NOVITA_API_TOKEN", "kind": "secret", "config": "api_key",
          "install_yaml_key": ".llm.novita_api_token",
          "prompt": "Enter Novita API token (input hidden):" }
      ] },
    { "id": "bedrock", "label": "AWS Bedrock", "menu_order": 7, "rank": 6,
      "info_display": { "order": 5, "default_model": "Claude Haiku 4.5", "cost_per_mb": "1.00", "message": "" },
      "exclusive": false,
      "detect_env_keys": ["AWS_ACCESS_KEY_ID", "AWS_SECRET_ACCESS_KEY", "AWS_BEDROCK_REGION"],
      "fields": [
        { "env": "AWS_ACCESS_KEY_ID", "kind": "text", "config": "additional.aws_access_key_id",
          "install_yaml_key": ".llm.aws_access_key_id",
          "prompt": "Enter AWS Access Key ID:" },
        { "env": "AWS_SECRET_ACCESS_KEY", "kind": "secret", "config": "additional.aws_secret_access_key",
          "install_yaml_key": ".llm.aws_secret_access_key",
          "prompt": "Enter AWS Secret Access Key (input hidden):" },
        { "env": "AWS_BEDROCK_REGION", "kind": "text", "config": "additional.aws_bedrock_region",
          "install_yaml_key": ".llm.aws_bedrock_region",
          "prompt": "Enter AWS Bedrock Region (e.g. us-east-1):" }
      ] },
    { "id": "gemini", "label": "Google Gemini", "menu_order": 8, "rank": 8,
      "info_display": { "order": 6, "default_model": "gemini-3-flash-preview", "cost_per_mb": "1.00", "message": "" },
      "exclusive": false, "detect_env_keys": ["GEMINI_API_KEY"],
      "fields": [
        { "env": "GEMINI_API_KEY", "kind": "secret", "config": "api_key",
          "install_yaml_key": ".llm.gemini_api_key",
          "prompt": "Enter Gemini API token (input hidden):" },
        { "env": "GEMINI_MODEL", "kind": "text", "required": false, "config": "model",
          "install_yaml_key": ".llm.gemini_model",
          "prompt": "Enter Gemini model (optional, press Enter to use the workspace default):" }
      ] },
    { "id": "localopenai", "label": "Local OpenAI-compatible", "menu_order": 9, "rank": 9,
      "info_display": { "order": 9, "default_model": "Common models", "cost_per_mb": "", "message": "Refer to benchmark estimates above" },
      "exclusive": false, "detect_env_keys": ["LOCALOPENAI_BASE_URL"],
      "description": "Connect any server that exposes the OpenAI-compatible /v1 API — e.g. vLLM,\nOllama, LM Studio, LocalAI, Text Generation Inference, or llama.cpp.\nDocs: https://docs.bito.ai/ai-architect/llm-providers/local-openai-compatible",
      "post_configure": "_localopenai_configure_check",
      "preset_check": "_localopenai_health_check",
      "fields": [
        { "env": "LOCALOPENAI_BASE_URL", "kind": "text", "config": "additional.base_url",
          "pre_process": "_pre_localopenai_url", "post_process": "_pre_localopenai_url",
          "install_yaml_key": ".llm.localopenai_base_url",
          "prompt": "Server URL including the /v1 path (required)\n  Use a DNS hostname reachable from the AI Architect containers (private-network or\n  VPN-resolvable), e.g. https://llm.internal:8000/v1 — not localhost, 127.0.0.1, or 0.0.0.0.\n  URL:" },
        { "env": "LOCALOPENAI_API_KEY", "kind": "secret", "required": false, "config": "api_key",
          "install_yaml_key": ".llm.localopenai_api_key",
          "prompt": "API token (optional — leave blank for keyless servers)\n  Token:" },
        { "env": "LOCALOPENAI_MODEL", "kind": "text", "config": "model",
          "install_yaml_key": ".llm.localopenai_model",
          "prompt": "Model (required — must match a model ID your server serves, e.g. claude-haiku-4.5)\n  Model:" },
        { "env": "LOCALOPENAI_CONNECTOR_TYPE", "kind": "text", "required": false, "config": "additional.connector_type",
          "pre_process": "_pre_localopenai_connector", "post_process": "_pre_localopenai_connector",
          "install_yaml_key": ".llm.localopenai_connector_type",
          "prompt": "Is the server a Copilot Bridge? (y/N):" }
      ] }
  ]
}
EOF
)"

llm_registry() { printf '%s\n' "$_LLM_REGISTRY_JSON"; }

# -----------------------------------------------------------------------------
# Accessors (all read from llm_registry via jq).
# -----------------------------------------------------------------------------

# Total number of providers.
_llm_total_providers() { llm_registry | jq -r '.providers | length'; }

# Highest menu_order (used to print the "[1-N]" hint).
_llm_menu_max() { llm_registry | jq -r '[.providers[].menu_order] | max'; }

# Provider id for a menu number (empty if out of range / non-numeric).
_llm_id_for_menu() {
    case "$1" in (*[!0-9]*|'') return 0 ;; esac
    llm_registry | jq -r --argjson n "$1" '.providers[] | select(.menu_order==$n) | .id'
}

# Human-readable label for a provider id (falls back to the id if unknown).
_llm_label() { llm_registry | jq -r --arg id "$1" '(.providers[] | select(.id==$id) | .label) // $id'; }

# "true"/"false" — is this provider an exclusive gateway?
_llm_is_exclusive() { llm_registry | jq -r --arg id "$1" '.providers[] | select(.id==$id) | .exclusive'; }

# First detect-env key — also the provider's persist "primary" field.
_llm_primary() { llm_registry | jq -r --arg id "$1" '.providers[] | select(.id==$id) | .detect_env_keys[0]'; }

# Provider's detect-env keys, one per line.
_llm_detect_keys() { llm_registry | jq -r --arg id "$1" '.providers[] | select(.id==$id) | .detect_env_keys[]'; }

# Provider's required field env names (required defaults to true).
_llm_required_envs() {
    llm_registry | jq -r --arg id "$1" \
        '.providers[] | select(.id==$id) | .fields[] | select(if has("required") then .required else true end) | .env'
}

# Provider's fields as compact JSON objects, one per line (registry order).
_llm_fields() { llm_registry | jq -c --arg id "$1" '.providers[] | select(.id==$id) | .fields[]'; }

# Provider's fields as one record per line (one jq pass instead of one-per-attribute).
# Columns are joined with the US control char (0x1f), NOT tab: a non-whitespace IFS
# stops bash from collapsing the empty pre_process/post_process columns (which would
# otherwise shift later columns). Columns, in order:
#   env | kind | required | config | pre_process | post_process | prompt
# Consumers read with: while IFS=$'\x1f' read -r env kind required config pre post prompt
_llm_fields_tsv() {
    llm_registry | jq -r --arg id "$1" '
        .providers[] | select(.id==$id) | .fields[] |
        [ .env, .kind, ((if has("required") then .required else true end) | tostring), (.config // ""),
          (.pre_process // ""), (.post_process // ""), (.prompt // "" | @base64) ] | join("\u001f")'
}

# Optional provider intro shown before its fields ("" when none); may be multi-line.
_llm_description() {
    llm_registry | jq -r --arg id "$1" '(.providers[] | select(.id==$id) | .description) // ""'
}

# Optional post-configure hook name ("" when none); run by configure_llm after the
# fields are persisted (e.g. a reachability check).
_llm_post_configure() {
    llm_registry | jq -r --arg id "$1" '(.providers[] | select(.id==$id) | .post_configure) // ""'
}

# Optional non-interactive advisory hook for the preset/yaml path ("" when none);
# reads its own keys from ENV_LLM_FILE and returns 0/non-zero without prompting.
_llm_preset_check() {
    llm_registry | jq -r --arg id "$1" '(.providers[] | select(.id==$id) | .preset_check) // ""'
}

# All field env names across all providers (used to clear state on reset).
_llm_all_env_keys() { llm_registry | jq -r '.providers[].fields[].env'; }

# Provider ids ordered by default-selection rank (lower wins).
_llm_ids_by_rank() { llm_registry | jq -r '.providers | sort_by(.rank)[] | .id'; }

# install.yaml "<path> <ENV>" rows for fields that declare an install_yaml_key.
_llm_yaml_pairs() {
    llm_registry | jq -r '.providers[].fields[] | select(.install_yaml_key) | "\(.install_yaml_key) \(.env)"'
}

# Interactive menu prompt string, e.g. "Configure LLM: 1) Anthropic ... [1-8]: ".
_llm_menu_string() {
    local line="Configure LLM:" mo label
    while IFS=$'\t' read -r mo label; do
        line="${line} ${mo}) ${label}"
    done < <(llm_registry | jq -r '.providers | sort_by(.menu_order)[] | "\(.menu_order)\t\(.label)"')
    printf '%s [1-%s]: ' "$line" "$(_llm_menu_max)"
}

# Per-provider info_display rows for render_indexing_information_block, one record
# per line, sorted by info_display.order. Only providers with an info_display appear.
# Columns joined with US (0x1f), matching _llm_fields_tsv:
#   id | label | default_model | cost_per_mb | message
# When cost_per_mb is empty the renderer shows message instead of a figure
# (e.g. gateways / routed providers like Portkey and Vertex AI).
_llm_cost_rows() {
    llm_registry | jq -r '
        .providers | map(select(.info_display != null)) | sort_by(.info_display.order // 999)[] |
        [ .id, .label,
          (.info_display.default_model // ""),
          (.info_display.cost_per_mb // "" | tostring),
          (.info_display.message // "") ] | join("\u001f")'
}

# -----------------------------------------------------------------------------
# Field hooks.
# pre_process  : prompt input -> value stored in env. Echo value + exit 0, or
#                exit non-zero to reject and re-prompt.
# post_process : env value -> value placed in the cis-config payload. Echo value
#                + exit 0, or exit non-zero to skip the provider in the payload.
# -----------------------------------------------------------------------------

# Azure endpoint: require an http(s):// scheme (used as both pre and post).
_https_or_fail() { [[ "$1" =~ ^https?:// ]] && printf '%s' "$1" || return 1; }

# LocalOpenAI base URL: require an http(s):// scheme AND reject non-resolvable
# loopback/wildcard hosts. The endpoint is dialed from INSIDE the container, where
# localhost/127.0.0.1/0.0.0.0/::1 resolve to the container itself — so those are
# rejected and the operator must supply a private-network / VPN-resolvable host.
# Used as both pre (interactive/preset input) and post (payload) hook. Diagnostic
# messages go to stderr so they surface without being captured as the field value.
_pre_localopenai_url() {
    local url="$1" host
    if [[ ! "$url" =~ ^https?:// ]]; then
        echo "  URL must start with http:// or https://" >&2
        return 1
    fi
    host="${url#*://}"; host="${host%%/*}"; host="${host%%:*}"
    host="${host#[}"; host="${host%]}"   # strip [ ] for bracketed IPv6
    case "$host" in
        localhost|0.0.0.0|::1|127.*)
            echo "  '${host}' is not reachable from inside the AI Architect containers. Use a resolvable DNS hostname (private-network or VPN-resolvable), e.g. https://llm.internal:8000/v1 — not localhost/127.0.0.1/0.0.0.0." >&2
            return 1 ;;
    esac
    printf '%s' "$url"
}

# LocalOpenAI connector type (pre+post hook): yes-ish answers and the canonical
# id map to "copilot-bridge" (cis-manager then reduces indexing concurrency);
# anything else maps to "" (field omitted). Never fails, so a stray value
# cannot drop the provider.
_pre_localopenai_connector() {
    local v
    v=$(printf '%s' "$1" | tr '[:upper:]' '[:lower:]' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
    case "$v" in
        y|yes|true|copilot-bridge) printf 'copilot-bridge' ;;
        *)                         printf '' ;;
    esac
}

# Portkey URL: empty stays empty; the default normalises to empty; trailing
# slash trimmed; otherwise require a valid http(s) URL.
_pre_portkey_url() {
    local url="$1"
    [ -z "$url" ] && { printf ''; return 0; }
    url="${url%/}"
    [ "$url" = "https://api.portkey.ai/v1" ] && { printf ''; return 0; }
    if [[ "$url" =~ ^https?://[a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*(/.*)?$ ]]; then
        printf '%s' "$url"; return 0
    fi
    return 1
}

# Portkey model: require @provider/model-name.
_pre_portkey_model() { [[ "$1" =~ ^@[^/]+/[^/]+$ ]] && printf '%s' "$1" || return 1; }

# Vertex SA: accepts a path to a JSON file (interactive prompt, or a yaml/env
# value that points at a file) or an already-inline value (base64 or raw JSON).
# A leading ~ is expanded. A readable JSON file is stored base64-encoded on one
# line (an env file can't hold multi-line JSON); an already-valid inline value is
# kept unchanged; anything else (a mistyped path, a non-JSON file) is rejected.
_pre_vertex_sa_file() {
    local v="$1" dec
    case "$v" in
        "~")   v="$HOME" ;;
        "~/"*) v="$HOME/${v#\~/}" ;;
    esac
    if [ -f "$v" ]; then
        jq empty "$v" >/dev/null 2>&1 || return 1
        base64 < "$v" | tr -d '\n'
        return 0
    fi
    # Not a file: pass an already-valid inline value (raw JSON or base64) through
    # unchanged; reject anything else (e.g. a mistyped path).
    if printf '%s' "$1" | jq empty >/dev/null 2>&1; then printf '%s' "$1"; return 0; fi
    dec=$(printf '%s' "$1" | base64 -d 2>/dev/null) || return 1
    printf '%s' "$dec" | jq empty >/dev/null 2>&1 || return 1
    printf '%s' "$1"
}

# Vertex SA: env value may be base64 (interactive) or raw JSON (yaml-pasted);
# emit raw JSON for the payload, or fail if neither.
_post_vertex_sa_json() {
    local s="$1"
    if printf '%s' "$s" | jq empty 2>/dev/null; then printf '%s' "$s"; return 0; fi
    s=$(printf '%s' "$s" | base64 -d 2>/dev/null) || return 1
    printf '%s' "$s" | jq empty 2>/dev/null || return 1
    printf '%s' "$s"
}

# Export so callers that invoke exported llm-config.sh functions in a child shell
# still have the registry available.
export -f llm_registry \
    _llm_total_providers _llm_menu_max _llm_id_for_menu _llm_is_exclusive \
    _llm_label _llm_primary _llm_detect_keys _llm_required_envs _llm_fields _llm_fields_tsv _llm_description _llm_post_configure _llm_preset_check _llm_all_env_keys \
    _llm_ids_by_rank _llm_yaml_pairs _llm_menu_string _llm_cost_rows \
    _https_or_fail _pre_localopenai_url _pre_localopenai_connector _pre_portkey_url _pre_portkey_model _pre_vertex_sa_file _post_vertex_sa_json
