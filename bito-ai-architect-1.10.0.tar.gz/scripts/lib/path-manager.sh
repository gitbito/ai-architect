#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
#
# Path Manager - Central path resolution for Bito AI Architect
# Provides standard Unix paths with automatic fallback to user-local installation
#
# Usage: source "${SCRIPT_DIR}/lib/path-manager.sh"
# Then use: get_config_file, get_log_dir, etc.

# Prevent multiple sourcing
if [ -n "${BITOARCH_PATH_MANAGER_LOADED:-}" ]; then
    return 0
fi
BITOARCH_PATH_MANAGER_LOADED=1

# Source logging functions if available (for log_silent calls)
if [ -z "$SCRIPT_DIR" ]; then
    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && cd ../.. && pwd)"
fi

# Source setup-utils for logging functions (log_silent, print_info, etc.)
if [ -f "${SCRIPT_DIR}/scripts/setup-utils.sh" ]; then
    source "${SCRIPT_DIR}/scripts/setup-utils.sh" 2>/dev/null || true
fi

# No-op fallback when setup-utils isn't reachable yet. Real log_silent from
# setup-utils overrides this when sourced later.
if ! type log_silent >/dev/null 2>&1; then
    log_silent() { :; }
fi

# ============================================================================
# STANDARD PATHS (Industry Standard)
# ============================================================================
BITOARCH_SYSTEM_PREFIX="/usr/local"
BITOARCH_USER_PREFIX="${HOME}/.local"

# Standard directories (FHS compliant)
BITOARCH_SYSTEM_CONFIG_DIR="${BITOARCH_SYSTEM_PREFIX}/etc/bitoarch"
BITOARCH_SYSTEM_VAR_DIR="${BITOARCH_SYSTEM_PREFIX}/var/bitoarch"
BITOARCH_SYSTEM_LIB_DIR="${BITOARCH_SYSTEM_PREFIX}/lib/bitoarch"

BITOARCH_USER_CONFIG_DIR="${BITOARCH_USER_PREFIX}/bitoarch/etc"
BITOARCH_USER_VAR_DIR="${BITOARCH_USER_PREFIX}/bitoarch/var"
# User-cache for runtime-fetched binaries (e.g. mkcert). Always user-writable
# regardless of system/user layout, since these are runtime tools, not
# components of the install itself.
BITOARCH_USER_CACHE_DIR="${HOME}/.cache/bitoarch"
BITOARCH_USER_LIB_DIR="${BITOARCH_USER_PREFIX}/bitoarch/lib"

# ============================================================================
# DETECTION & INITIALIZATION
# ============================================================================

# Detect which layout is in use
detect_layout() {
    # Priority 1: System-wide installation (check if already exists)
    if [ -f "${BITOARCH_SYSTEM_CONFIG_DIR}/.env-bitoarch" ] || \
       [ -d "${BITOARCH_SYSTEM_LIB_DIR}/current" ]; then
        echo "system"
        return 0
    fi
    
    # Priority 2: User-local installation (check if already exists)
    if [ -f "${BITOARCH_USER_CONFIG_DIR}/.env-bitoarch" ] || \
       [ -d "${BITOARCH_USER_LIB_DIR}/current" ]; then
        echo "user"
        return 0
    fi
    
    # Priority 3: Legacy installation directory
    if [ -n "${SCRIPT_DIR:-}" ] && [ -f "${SCRIPT_DIR}/.env-bitoarch" ]; then
        echo "legacy"
        return 0
    fi
    
    # Priority 4: For fresh installs, determine based on system capabilities
    # Enhanced: More robust checking with validation
    if can_use_system_wide; then
        # Verify we can actually create the directory (test run)
        local test_dir="${BITOARCH_SYSTEM_PREFIX}/etc/bitoarch"
        if mkdir -p "$test_dir" 2>/dev/null; then
            # Successfully created without sudo
            rmdir "$test_dir" 2>/dev/null || true
            log_silent "Validated system-wide path creation (no sudo needed)"
            echo "system"
            return 0
        elif command -v sudo >/dev/null 2>&1 && [ -t 0 ]; then
            # Try with sudo
            if sudo mkdir -p "$test_dir" 2>/dev/null; then
                sudo rmdir "$test_dir" 2>/dev/null || true
                log_silent "Validated system-wide path creation (with sudo)"
                echo "system"
                return 0
            else
                log_silent "Cannot create system directories even with sudo, falling back to user"
            fi
        else
            log_silent "Cannot create system directories (no sudo or non-interactive), falling back to user"
        fi
    fi
    
    # Fallback: User-local (always works, no sudo required)
    log_silent "Falling back to user-local installation (~/.local/bitoarch)"
    echo "user"
    return 0
}

# Check if system-wide installation is possible
can_use_system_wide() {
    # Check if /usr/local exists first
    if [ ! -d "${BITOARCH_SYSTEM_PREFIX}" ]; then
        # Try to create /usr/local with sudo
        if command -v sudo >/dev/null 2>&1 && [ -t 0 ]; then
            if sudo mkdir -p "${BITOARCH_SYSTEM_PREFIX}" 2>/dev/null; then
                log_silent "Created ${BITOARCH_SYSTEM_PREFIX} with sudo"
            else
                log_silent "/usr/local doesn't exist and cannot be created"
                return 1
            fi
        else
            log_silent "/usr/local doesn't exist and sudo not available"
            return 1
        fi
    fi
    
    # Check if we have sudo or already have write permissions
    if [ -w "${BITOARCH_SYSTEM_PREFIX}/etc" ] 2>/dev/null; then
        return 0
    fi
    
    # Check if sudo is available and works
    if command -v sudo >/dev/null 2>&1; then
        if sudo -n true 2>/dev/null; then
            return 0  # Passwordless sudo works
        elif [ -t 0 ]; then
            # Interactive terminal - TEST if sudo actually works
            if sudo -v 2>/dev/null; then
                return 0  # Sudo validated
            else
                log_silent "sudo available but authentication failed"
                return 1
            fi
        fi
    fi
    
    return 1
}

# Initialize path variables based on detected layout
init_paths() {
    local layout="$(detect_layout)"
    
    case "$layout" in
        system)
            export BITOARCH_LAYOUT="system"
            export BITOARCH_CONFIG_DIR="${BITOARCH_SYSTEM_CONFIG_DIR}"
            export BITOARCH_VAR_DIR="${BITOARCH_SYSTEM_VAR_DIR}"
            export BITOARCH_LIB_DIR="${BITOARCH_SYSTEM_LIB_DIR}"
            export BITOARCH_LOG_DIR="${BITOARCH_SYSTEM_VAR_DIR}/logs"
            export BITOARCH_PREFIX="${BITOARCH_SYSTEM_PREFIX}"
            ;;
        user)
            export BITOARCH_LAYOUT="user"
            export BITOARCH_CONFIG_DIR="${BITOARCH_USER_CONFIG_DIR}"
            export BITOARCH_VAR_DIR="${BITOARCH_USER_VAR_DIR}"
            export BITOARCH_LIB_DIR="${BITOARCH_USER_LIB_DIR}"
            export BITOARCH_LOG_DIR="${BITOARCH_USER_VAR_DIR}/logs"
            export BITOARCH_PREFIX="${BITOARCH_USER_PREFIX}/bitoarch"
            ;;
        legacy)
            export BITOARCH_LAYOUT="legacy"
            export BITOARCH_CONFIG_DIR="${SCRIPT_DIR}"
            export BITOARCH_VAR_DIR="${SCRIPT_DIR}/var"
            export BITOARCH_LIB_DIR="${SCRIPT_DIR}"
            export BITOARCH_LOG_DIR="${SCRIPT_DIR}/var/logs"
            export BITOARCH_PREFIX="${SCRIPT_DIR}"
            ;;
    esac
    
    # Set HOST_LOG_DIR for docker-compose volume mounts
    # CRITICAL: Docker Compose requires relative paths for volume mounts
    # Use ./var/logs for Docker Compose, absolute paths for everything else
    if [ "${BITOARCH_LAYOUT}" = "legacy" ]; then
        # Legacy mode: use relative path (backward compatible)
        export HOST_LOG_DIR="./var/logs"
    else
        # Standard paths: Docker Compose still needs relative path for volumes
        # but logs are actually written to the standard location via symlink
        export HOST_LOG_DIR="./var/logs"
    fi
}

# Initialize on source
init_paths

# ============================================================================
# DOCKER COMPOSE COMPATIBILITY
# ============================================================================

# For Docker Compose, HOST_LOG_DIR must be a relative path (./var/logs)
# because docker-compose.yml volume mounts require paths relative to the compose file
# For Kubernetes and system operations, use absolute paths from BITOARCH_LOG_DIR
get_docker_log_dir() {
    # Always return relative path for Docker Compose volume mounts
    echo "./var/logs"
}

# ============================================================================
# PATH ACCESSOR FUNCTIONS
# ============================================================================

# Get root prefix
get_bitoarch_prefix() {
    echo "${BITOARCH_PREFIX}"
}

# Get configuration directory
get_config_dir() {
    echo "${BITOARCH_CONFIG_DIR}"
}

# Get main configuration file
get_config_file() {
    echo "${BITOARCH_CONFIG_DIR}/.env-bitoarch"
}

# Get LLM configuration file
get_llm_config_file() {
    echo "${BITOARCH_CONFIG_DIR}/.env-llm-bitoarch"
}

# Get repository configuration file
get_repo_config_file() {
    echo "${BITOARCH_CONFIG_DIR}/.bitoarch-config.yaml"
}

get_repo_list_file() {
    echo "${BITOARCH_CONFIG_DIR}/.git-repo-list.yaml"
}

# Get deployment type file
get_deployment_type_file() {
    echo "${BITOARCH_CONFIG_DIR}/.deployment-type"
}

# User-owned install YAML. Lives in $HOME (not install-dir) so users can
# pre-place it before `curl | bash`. Read at install time and re-read on
# `bitoarch restart --force` for live config reload.
get_install_yaml_file() {
    echo "$HOME/.bitoarch/install.yaml"
}

# Read deployment type from the .deployment-type file. Returns "docker-compose",
# "kubernetes", or "unknown" when the file doesn't exist.
#
# NOTE: this is a universal deployment-type reader -- it is NOT K8s-specific and
# lives here (not in kubernetes-manager.sh) so Standalone dispatchers that only
# need to branch Docker-vs-K8s don't have to source kubernetes-manager.sh.
# scripts/kubernetes-manager.sh keeps a delegating copy for prod compatibility.
get_deployment_type() {
    local f
    f="$(get_deployment_type_file)"
    if [ -f "$f" ]; then
        cat "$f"
    else
        echo "unknown"
    fi
}

save_deployment_type() {
    local type="$1"

    local deployment_file
    deployment_file="$(get_deployment_type_file)"

    local deployment_dir
    deployment_dir="$(dirname "$deployment_file")"
    if [ ! -d "$deployment_dir" ]; then
        mkdir -p "$deployment_dir" 2>/dev/null || {
            if command -v sudo >/dev/null 2>&1 && [ -t 0 ]; then
                type print_info >/dev/null 2>&1 && \
                    print_info "Creating configuration directory (requires sudo)..."
                sudo mkdir -p "$deployment_dir"
                sudo chown -R "$USER:$(id -gn)" "$deployment_dir"
            else
                type print_error >/dev/null 2>&1 && \
                    print_error "Cannot create directory: $deployment_dir"
                type print_info >/dev/null 2>&1 && \
                    print_info "Falling back to legacy installation directory"
                deployment_file="${SCRIPT_DIR}/.deployment-type"
                mkdir -p "$(dirname "$deployment_file")" 2>/dev/null || true
            fi
        }
    fi

    echo "$type" > "$deployment_file"
    log_silent "Deployment type saved: $type to $deployment_file"
}

# Get Kubernetes values file (for Helm deployments)
get_k8s_values_file() {
    echo "${BITOARCH_CONFIG_DIR}/.bitoarch-values.yaml"
}

# Get config templates directory
get_config_templates_dir() {
    echo "${BITOARCH_CONFIG_DIR}/templates"
}

# Get variable data directory
get_var_dir() {
    echo "${BITOARCH_VAR_DIR}"
}

# Get log directory
get_log_dir() {
    echo "${BITOARCH_LOG_DIR}"
}

# Get setup log file
get_setup_log() {
    # Test/sandbox override: suites drive real engine code paths and must never
    # write into the live install's setup.log (every writer resolves via here).
    if [ -n "${BITOARCH_SETUP_LOG_OVERRIDE:-}" ]; then
        echo "$BITOARCH_SETUP_LOG_OVERRIDE"
        return 0
    fi
    echo "${BITOARCH_LOG_DIR}/setup.log"
}

# Get upgrade log file
get_upgrade_log() {
    echo "${BITOARCH_LOG_DIR}/upgrade.log"
}

# Get library directory
get_lib_dir() {
    echo "${BITOARCH_LIB_DIR}"
}

# Get user cache directory (always user-writable, layout-independent).
get_user_cache_dir() {
    echo "${BITOARCH_USER_CACHE_DIR}"
}

# Get current version directory
get_current_version_dir() {
    local lib_dir="$(get_lib_dir)"
    if [ -L "${lib_dir}/current" ]; then
        readlink -f "${lib_dir}/current" 2>/dev/null || \
        python -c "import os; print(os.path.realpath('${lib_dir}/current'))" 2>/dev/null || \
        echo "${lib_dir}/current"
    else
        echo ""
    fi
}

# Get versions directory
get_versions_dir() {
    echo "$(get_lib_dir)/versions"
}

# ============================================================================
# PLUGIN FRAMEWORK PATHS
# ============================================================================
# A plugin's files are split across the same three FHS-style locations the
# base platform uses, so mutable runtime state is separated from scripts and
# config:
#   install dir : ${BITOARCH_LIB_DIR}/plugins/<name>      (scripts + package)
#   config dir  : ${BITOARCH_CONFIG_DIR}/plugins/<name>   (plugin .env, 0600)
#   state file  : ${BITOARCH_VAR_DIR}/plugins/state.json  (the journal)
#   data subtree: <STORAGE_PATH>/plugins/<name>           (in-container volume)

# Root of all plugin install dirs.
get_plugins_root() {
    echo "${BITOARCH_LIB_DIR}/plugins"
}

# Install dir for a plugin (scripts, manifest, compose fragment, chart).
get_plugin_install_dir() {
    echo "${BITOARCH_LIB_DIR}/plugins/$1"
}

# Config dir for a plugin (holds its .env).
get_plugin_config_dir() {
    echo "${BITOARCH_CONFIG_DIR}/plugins/$1"
}

# A plugin's own config file. Uses the .env-bitoarch naming convention (an
# additive, plugin-scoped overlay over the base .env-bitoarch); mode 0600.
get_plugin_env_file() {
    echo "${BITOARCH_CONFIG_DIR}/plugins/$1/.env-bitoarch"
}

# A plugin's generated Helm values file (Kubernetes only). Mirrors the base
# get_k8s_values_file, scoped per plugin; carries the plugin's own config as
# .Values.env. Mode 0600 (may hold secrets); lives beside the plugin .env.
get_plugin_k8s_values_file() {
    echo "${BITOARCH_CONFIG_DIR}/plugins/$1/.bitoarch-values.yaml"
}

# The state journal -- one file for all plugins + shared dependency packs.
# Lives under VAR_DIR (mutable runtime state), not CONFIG_DIR.
get_plugin_state_file() {
    echo "${BITOARCH_VAR_DIR}/plugins/state.json"
}

# A plugin's data subtree on the shared ai_architect_data volume. This is an
# in-container path (the volume mounts at /opt/bito/ai-architect); STORAGE_PATH
# resolves it (.env-bitoarch), defaulting to the documented mount location.
get_plugin_data_dir() {
    local base="${STORAGE_PATH:-/opt/bito/ai-architect/data}"
    echo "${base}/plugins/$1"
}

# The compose project the running base stack belongs to. Base container names
# are fixed, so the project label can be read off any one that's up. Probe the
# full base-service set (canonical SERVICE_*_NAME when constants are loaded, else
# the fixed names) so this resolves as long as any single base service is
# running. Empty when none are (resolution then falls back to name matching).
_ai_architect_project() {
    local c p
    for c in "${SERVICE_PROVIDER_NAME:-ai-architect-provider}" \
             "${SERVICE_MYSQL_NAME:-ai-architect-mysql}" \
             "${SERVICE_MANAGER_NAME:-ai-architect-manager}" \
             "${SERVICE_CONFIG_NAME:-ai-architect-config}" \
             "${SERVICE_WORKER_NAME:-ai-architect-worker}" \
             "${SERVICE_TRACKER_NAME:-ai-architect-tracker}" \
             "${SERVICE_TEMPORAL_NAME:-ai-architect-temporal}"; do
        p="$(docker inspect "$c" --format '{{index .Config.Labels "com.docker.compose.project"}}' 2>/dev/null)"
        [ -n "$p" ] && { echo "$p"; return 0; }
    done
    return 1
}

# Resolve a shared base resource (network or data volume) to its REAL name. The
# base compose declares these WITHOUT a `name:`, so Compose creates them
# project-prefixed (`<project>_<base>`). Plugin and dependency-pack composes
# reference them as EXTERNAL, so they must use the real name, not the literal
# alias. Resolution order, most authoritative first:
#   1. explicit override
#   2. a resource named literally `<base>` (un-prefixed installs)
#   3. `<project>_<base>` for the running base stack's compose project (read from
#      a base container's label) -- disambiguates orphans from earlier installs
#   4. a single `*_<base>` match
#   5. the literal default
# Docker-only; on Kubernetes plugins use the namespace + PVC, not these.
_resolve_ai_architect_resource() {
    local kind="$1" base="$2" override="$3" names proj matches
    [ -n "$override" ] && { echo "$override"; return 0; }
    command -v docker >/dev/null 2>&1 || { echo "$base"; return 0; }
    case "$kind" in
        network) names="$(docker network ls --format '{{.Name}}' 2>/dev/null)" ;;
        volume)  names="$(docker volume ls  --format '{{.Name}}' 2>/dev/null)" ;;
        *) echo "$base"; return 0 ;;
    esac
    # Prefer the resource the CURRENT compose project actually uses, so a stale
    # bare leftover (e.g. an ai_architect_wingman from earlier testing) never
    # shadows the in-use project-prefixed one. Fall back to a bare name (legacy /
    # external installs), then a unique "_<base>" match, then the bare default.
    proj="$(_ai_architect_project)"
    if [ -n "$proj" ] && printf '%s\n' "$names" | grep -qx "${proj}_${base}"; then
        echo "${proj}_${base}"; return 0
    fi
    if printf '%s\n' "$names" | grep -qx "$base"; then echo "$base"; return 0; fi
    matches="$(printf '%s\n' "$names" | grep -E "_${base}\$")"
    if [ "$(printf '%s\n' "$matches" | grep -c . )" -eq 1 ]; then echo "$matches"; return 0; fi
    echo "$base"
}

# The shared network every plugin/pack container joins to reach base services.
get_ai_architect_network() {
    _resolve_ai_architect_resource network "ai-architect-network" "${AI_ARCHITECT_NETWORK:-}"
}

# The shared data volume (per-plugin data subtree) plugins mount.
get_ai_architect_data_volume() {
    _resolve_ai_architect_resource volume "ai_architect_data" "${AI_ARCHITECT_DATA_VOLUME:-}"
}

# The Wingman shelf volume (binary + tools + skills), separate from index data.
get_ai_architect_wingman_volume() {
    _resolve_ai_architect_resource volume "ai_architect_wingman" "${AI_ARCHITECT_WINGMAN_VOLUME:-}"
}

# ============================================================================
# SHARED WINGMAN RUNTIME PATHS
# ============================================================================
# One shared Wingman (binary + skills) backs base indexing and every plugin. It
# lives on the shared data volume -- the named volume `ai_architect_data` on
# Docker, the `bitoarch-data` PVC on k8s -- that every base service and plugin
# pod already mounts, under STORAGE_PATH, in the `.bitowingman` home the base init
# (the init-dirs container / the create-directories initContainer) already makes:
#   <shared>/<version>/             a promoted Wingman build
#   <shared>/<version>/config.json  read-only config template (copy-on-write)
#   <shared>/current -> <version>   the active build; flipped atomically on swap
#   <shared>/skills/                the shared, ref-counted skills shelf
# The shelf is populated from the CDN by a busybox helper container (see
# wingman-shelf.sh), because the host cannot write a named volume / PVC directly.

# Canonical filename the framework gives the promoted binary inside a version
# dir. Consumers read WINGMAN_CLI_PATH (a full path), so the basename is an
# internal convention -- overridable for an alternate published name.
WINGMAN_BINARY_NAME="${WINGMAN_BINARY_NAME:-bito-wingman}"

# Root of the shared Wingman location, on its own volume/PVC mounted here. This
# path is valid inside any container/pod that mounts the shelf; the populate helper
# writes it in-container (wingman-shelf.sh).
get_wingman_shared_dir() {
    echo "${WINGMAN_SHELF_DIR:-/opt/bito/ai-architect/wingman}"
}

# A specific promoted version dir.
get_wingman_version_dir() {
    echo "$(get_wingman_shared_dir)/$1"
}

# The 'current' pointer (symlink) flipped on an atomic swap.
get_wingman_current_link() {
    echo "$(get_wingman_shared_dir)/current"
}

# The shared, ref-counted skills shelf. WINGMAN_SKILLS_DIR resolves here. The
# shared dir is already the `.bitowingman` home, so the shelf is `<shared>/skills`
# (mirrors Wingman's own ~/.bitowingman/skills convention).
get_wingman_skills_dir() {
    echo "$(get_wingman_shared_dir)/skills"
}

# In-container path of the MCP root CA published onto the shared data volume, so
# plugin containers (which mount the volume) can point NODE_EXTRA_CA_CERTS at it
# and trust the provider's HTTPS cert in Standalone mode. Sibling of the Wingman
# shelf under the same data-dir; written in-container by the host via the same
# write-bridge (see plugin/mcp-env.sh).
get_mcp_ca_shared_path() {
    echo "${STORAGE_PATH:-/opt/bito/ai-architect/data}/data-dir/.mcp-certs/rootCA.pem"
}

# Resolve the active shared Wingman binary from the promoted 'current' symlink,
# else empty. Empty means "no shared binary yet" -- callers keep their existing
# default until the platform syncs one onto the shelf.
#
# 'current' is a RELATIVE symlink (current -> <version>) the promote logic flips
# in place, so the version dir is canonicalised here without readlink -f / stat
# (unavailable / non-portable on macOS bash 3.2 + BSD): read the relative target
# with plain readlink and rejoin it under the shared dir. A bare-name target
# (the only shape the promote logic writes) yields an absolute version path;
# otherwise fall back to the link path itself, which still resolves at exec time.
resolve_wingman_cli_path() {
    local cur shared tgt
    cur="$(get_wingman_current_link)"
    if [ -x "${cur}/${WINGMAN_BINARY_NAME}" ]; then
        shared="$(get_wingman_shared_dir)"
        tgt="$(readlink "$cur" 2>/dev/null)"
        case "$tgt" in
            /*)            echo "${tgt}/${WINGMAN_BINARY_NAME}" ;;
            */*|'')        echo "${cur}/${WINGMAN_BINARY_NAME}" ;;
            *)             echo "${shared}/${tgt}/${WINGMAN_BINARY_NAME}" ;;
        esac
        return 0
    fi
    echo ""
}

# Resolve the shared skills shelf, else empty (callers keep their existing default).
resolve_wingman_skills_dir() {
    local shared
    shared="$(get_wingman_skills_dir)"
    if [ -d "$shared" ]; then
        echo "$shared"
        return 0
    fi
    echo ""
}

# ============================================================================
# LAYOUT DETECTION FUNCTIONS
# ============================================================================

# Check if using standard layout
is_standard_layout() {
    [ "${BITOARCH_LAYOUT}" = "system" ] || [ "${BITOARCH_LAYOUT}" = "user" ]
}

# Check if using system-wide layout
is_system_layout() {
    [ "${BITOARCH_LAYOUT}" = "system" ]
}

# Check if using user-local layout
is_user_layout() {
    [ "${BITOARCH_LAYOUT}" = "user" ]
}

# Check if using legacy layout
is_legacy_layout() {
    [ "${BITOARCH_LAYOUT}" = "legacy" ]
}

# Get current layout
get_layout() {
    echo "${BITOARCH_LAYOUT}"
}

# ============================================================================
# DIRECTORY CREATION HELPERS
# ============================================================================

# Create standard directories (with appropriate permissions)
create_standard_dirs() {
    local layout="$1"
    
    case "$layout" in
        system)
            # System-wide requires sudo
            sudo mkdir -p "${BITOARCH_SYSTEM_CONFIG_DIR}/templates"
            sudo mkdir -p "${BITOARCH_SYSTEM_VAR_DIR}/logs"
            sudo mkdir -p "${BITOARCH_SYSTEM_LIB_DIR}/versions"
            
            # Hand the whole prefix to the invoking user in this one privileged
            # step so the steady-state CLI is rootless: lib/ holds plugin install
            # dirs that `plugin install` writes as the normal user, so it must be
            # user-owned like etc/ and var/. setgid keeps the group on files
            # created later.
            sudo chown -R "$USER:$(id -gn)" "${BITOARCH_SYSTEM_CONFIG_DIR}"
            sudo chown -R "$USER:$(id -gn)" "${BITOARCH_SYSTEM_VAR_DIR}"
            sudo chown -R "$USER:$(id -gn)" "${BITOARCH_SYSTEM_LIB_DIR}"
            sudo chmod g+s "${BITOARCH_SYSTEM_CONFIG_DIR}" \
                           "${BITOARCH_SYSTEM_VAR_DIR}" \
                           "${BITOARCH_SYSTEM_LIB_DIR}"
            
            ;;
        user)
            # User-local doesn't need sudo
            mkdir -p "${BITOARCH_USER_CONFIG_DIR}/templates"
            mkdir -p "${BITOARCH_USER_VAR_DIR}/logs"
            mkdir -p "${BITOARCH_USER_LIB_DIR}/versions"
            
            chmod -R 755 "${BITOARCH_USER_PREFIX}/bitoarch"
            ;;
    esac
}

# Ensure $dir exists and is writable by the current user, reclaiming ownership
# via sudo when a prior privileged step left it root-owned. A fresh install
# chowns the whole prefix to the invoking user, but an upgrade from a pre-plugin
# release (<1.10.0) leaves BITOARCH_LIB_DIR root-owned, and Docker creates
# bind-mount sources as root at compose-up — either way a later user-mode write
# fails with "Permission denied" until ownership is reclaimed. Returns 0 iff the
# dir is writable afterwards. Mirrors the sudo fallback used in setup.sh and
# unified-log-manager.sh.
ensure_writable_dir() {
    local dir="$1"
    mkdir -p "$dir" 2>/dev/null || true
    [ -w "$dir" ] && return 0
    if command -v sudo >/dev/null 2>&1; then
        sudo mkdir -p "$dir" 2>/dev/null || true
        sudo chown -R "$USER:$(id -gn)" "$dir" 2>/dev/null || true
    fi
    [ -w "$dir" ]
}

# Ensure a log base directory is writable, reclaiming a root-owned one (see
# ensure_writable_dir) and recording the outcome in setup.log.
_ensure_writable_log_dir() {
    local dir="$1"
    mkdir -p "$dir" 2>/dev/null || true
    [ -w "$dir" ] && return 0   # already writable — nothing to reclaim or log

    # Not writable — Docker likely created it as root at a prior compose-up.
    # `|| true`: a failed reclaim returns non-zero and must not abort a `set -e`
    # caller — the writability is judged below, not by this call's exit status.
    ensure_writable_dir "$dir" || true

    # Record the outcome in setup.log (file only, no console noise). log_silent
    # itself may be unable to write when the log lives under an unreclaimable
    # dir, so guard it to stay safe under the caller's `set -e`.
    if [ -w "$dir" ]; then
        log_silent "Reclaimed ownership of root-owned log directory: $dir" || true
    else
        log_silent "Log directory not writable and could not be reclaimed: $dir (Docker will recreate it on start; logs may be root-owned)" || true
    fi
}

# Create service-specific log directories
create_log_dirs() {
    local log_dir="$(get_log_dir)"
    local services=("cis-config" "cis-manager" "cis-provider" "mysql" "cis-tracker")

    # Reclaim ownership if a previous lifecycle left log_dir root-owned.
    _ensure_writable_log_dir "$log_dir"

    # Create directories in the standard/absolute path location
    for service in "${services[@]}"; do
        mkdir -p "${log_dir}/${service}" 2>/dev/null || true
    done

    chmod -R 755 "$log_dir" 2>/dev/null || true

    # CRITICAL: For Docker Compose, also create ./var/logs relative directory structure
    # This is needed because docker-compose.yml volume mounts use ${HOST_LOG_DIR:-./var/logs}
    if [ -n "${SCRIPT_DIR:-}" ]; then
        local relative_log_dir="${SCRIPT_DIR}/var/logs"
        _ensure_writable_log_dir "$relative_log_dir"

        for service in "${services[@]}"; do
            mkdir -p "${relative_log_dir}/${service}" 2>/dev/null || true
        done

        chmod -R 777 "$relative_log_dir" 2>/dev/null || true
        
        # If using standard paths (not legacy), log to both locations
        # The relative path is for Docker Compose volumes, absolute path for system logs
        if [ "${BITOARCH_LAYOUT}" != "legacy" ]; then
            # Note: Docker containers will write to ./var/logs via volume mount
            # which is separate from the system logs in /usr/local/var/bitoarch/logs
            : # Both directories exist and serve different purposes
        fi
    fi
}

# ============================================================================
# MIGRATION HELPERS
# ============================================================================

# Check if migration is needed
needs_migration() {
    # If using legacy layout and standard paths don't exist, migration needed
    if is_legacy_layout; then
        if [ ! -f "$(get_config_file)" ]; then
            return 0  # True - needs migration
        fi
    fi
    return 1  # False - no migration needed
}

# Get legacy installation directory (if exists)
get_legacy_dir() {
    if [ -n "${SCRIPT_DIR:-}" ] && [ -f "${SCRIPT_DIR}/.env-bitoarch" ]; then
        echo "${SCRIPT_DIR}"
    else
        echo ""
    fi
}

# ============================================================================
# UTILITY FUNCTIONS
# ============================================================================

# Print current path configuration (for debugging)
print_path_config() {
    echo "Bito AI Architect - Path Configuration"
    echo "========================================"
    echo "Layout:          ${BITOARCH_LAYOUT}"
    echo "Prefix:          ${BITOARCH_PREFIX}"
    echo "Config Dir:      ${BITOARCH_CONFIG_DIR}"
    echo "Log Dir:         ${BITOARCH_LOG_DIR}"
    echo "Lib Dir:         ${BITOARCH_LIB_DIR}"
    echo "Config File:     $(get_config_file)"
    echo "Setup Log:       $(get_setup_log)"
    echo ""
}

# Validate paths (check if critical files exist)
validate_paths() {
    local errors=0
    
    if [ ! -f "$(get_config_file)" ]; then
        echo "ERROR: Config file not found: $(get_config_file)" >&2
        errors=$((errors + 1))
    fi
    
    if [ ! -d "$(get_log_dir)" ]; then
        echo "ERROR: Log directory not found: $(get_log_dir)" >&2
        errors=$((errors + 1))
    fi
    
    return $errors
}
