#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
#
# Bito's AI Architect CLI - Diagnose / Central secret-masking pass
#
# Deny-by-default masking for the diagnose bundle. The CANONICAL masking
# implementation lives in common.sh (redact_env_file / redact_stream) and is
# shared with the base collectors -- this module is the single entry point the
# plugin collector (collect-plugins.sh) uses, so there is ONE masking pass for
# base AND plugin artifacts, never two divergent ones.
#
# Coverage (key- and value-based): OAuth / signing / AES, Jira/Linear/LLM
# provider keys, BITO_API_KEY, MySQL passwords, the *_SECRET / *_TOKEN / *_KEY /
# *_PASSWORD fallbacks, and full webhook URLs (Slack/Discord + any ?token= query).

if [ -n "${_DIAGNOSE_MASK_SECRETS_LOADED:-}" ]; then
    return 0
fi
_DIAGNOSE_MASK_SECRETS_LOADED=1

# Canonical redactors live in common.sh; source it if a caller pulled this in
# standalone (tests, a plugin's own collect.sh sourcing BITOARCH_HELPERS).
_MASK_SECRETS_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if ! type redact_env_file >/dev/null 2>&1; then
    # shellcheck source=/dev/null
    . "${_MASK_SECRETS_DIR}/common.sh" 2>/dev/null || true
fi

# Mask a .env-style file (key=value). Reads file, writes masked text to stdout.
mask_env_file() { redact_env_file "$@"; }

# Mask arbitrary text on stdin (logs, docker inspect, SQL, JSON).
mask_stream() { redact_stream; }

# Mask a file in place (used for docker-inspect.json, db-schema.sql, log copies).
# Atomic via temp + mv so a failure never leaves a half-masked file in the bundle.
mask_file_inplace() {
    local file="$1"
    [ -f "$file" ] || return 0
    local tmp; tmp="${file}.mask.$$"
    if redact_stream < "$file" > "$tmp" 2>/dev/null; then
        mv "$tmp" "$file" 2>/dev/null || rm -f "$tmp" 2>/dev/null
    else
        rm -f "$tmp" 2>/dev/null
    fi
}

# Deny-by-default leak scanner. Greps a file or directory tree for
# token-SHAPED values that must never appear unmasked in a bundle. Prints each
# offending "file:line" to stdout. Returns 0 when clean, 1 when a leak is found.
#
# Patterns are intentionally narrow (real credential shapes) so the masked
# placeholder ***REDACTED*** and ordinary prose never trip it.
mask_scan_for_leaks() {
    local target="$1"
    [ -e "$target" ] || return 0
    local pattern='xox[abprs]-[A-Za-z0-9-]{8,}|gh[pousr]_[A-Za-z0-9]{16,}|github_pat_[A-Za-z0-9_]{20,}|glpat-[A-Za-z0-9_-]{16,}|AKIA[A-Z0-9]{16}|eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+|sk-[A-Za-z0-9]{20,}|https?://hooks\.slack\.com/services/[A-Za-z0-9]'
    local hits
    if [ -d "$target" ]; then
        hits="$(grep -rEnI "$pattern" "$target" 2>/dev/null)"
    else
        hits="$(grep -EnI "$pattern" "$target" 2>/dev/null)"
    fi
    if [ -n "$hits" ]; then
        printf '%s\n' "$hits"
        return 1
    fi
    return 0
}

# Some callers run under `set -f`/exported-function contexts (a plugin's own
# collect.sh); export the masking entry points so they resolve there too.
export -f mask_env_file mask_stream mask_file_inplace mask_scan_for_leaks 2>/dev/null || true
