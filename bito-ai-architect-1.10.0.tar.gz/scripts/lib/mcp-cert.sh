#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
#
# scripts/lib/mcp-cert.sh
# -----------------------------------------------------------------------------
# mkcert-based HTTPS cert provisioning for the xmcp (cis-provider) container.
# Every caller goes through the five public functions here; no file outside
# this one invokes mkcert directly. Swapping cert tooling later means
# re-implementing these five functions; callers are unaffected.
# -----------------------------------------------------------------------------

if [ -n "${_BITOARCH_MCP_CERT_LIB_LOADED:-}" ]; then
    return 0
fi
_BITOARCH_MCP_CERT_LIB_LOADED=1

if [ -z "${SCRIPT_DIR:-}" ]; then
    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
fi

# Load-guarded; no-op if already sourced upstream.
if [ -f "${SCRIPT_DIR}/scripts/lib/path-manager.sh" ]; then
    # shellcheck disable=SC1091
    source "${SCRIPT_DIR}/scripts/lib/path-manager.sh"
fi
if [ -f "${SCRIPT_DIR}/scripts/lib/output-blocks.sh" ]; then
    # shellcheck disable=SC1091
    source "${SCRIPT_DIR}/scripts/lib/output-blocks.sh"
fi

# -----------------------------------------------------------------------------
# mkcert pin -- single source to bump. SHA256 values are verified against the
# published upstream release manifest at:
#   https://github.com/FiloSottile/mkcert/releases/tag/v1.4.4
# -----------------------------------------------------------------------------
_MCP_CERT_MKCERT_VERSION="v1.4.4"
_MCP_CERT_MKCERT_URL_BASE="https://github.com/FiloSottile/mkcert/releases/download"

_mcp_cert_expected_sha256() {
    case "$1" in
        darwin-amd64)  echo "a32dfab51f1845d51e810db8e47dcf0e6b51ae3422426514bf5a2b8302e97d4e" ;;
        darwin-arm64)  echo "c8af0df44bce04359794dad8ea28d750437411d632748049d08644ffb66a60c6" ;;
        linux-amd64)   echo "6d31c65b03972c6dc4a14ab429f2928300518b26503f58723e532d1b0a3bbb52" ;;
        linux-arm64)   echo "b98f2cc69fd9147fe4d405d859c57504571adec0d3611c3eefd04107c7ac00d0" ;;
    esac
}

# -----------------------------------------------------------------------------
# Path helpers
# -----------------------------------------------------------------------------

# Host dir containing server.{key,crt}. Mounted read-only into the xmcp
# container via docker-compose's ${HOST_MCP_CERT_DIR} volume entry.
# Lives under the user cache for the same reason as the mkcert binary:
# system-layout installs (root-owned $(get_lib_dir)) cannot write here.
mcp_cert_dir() {
    echo "$(get_user_cache_dir)/certs"
}

_mcp_cert_key_path()  { echo "$(mcp_cert_dir)/server.key"; }
_mcp_cert_crt_path()  { echo "$(mcp_cert_dir)/server.crt"; }

_mcp_cert_detect_platform() {
    local os arch
    os="$(uname -s | tr '[:upper:]' '[:lower:]')"
    arch="$(uname -m)"
    case "$arch" in
        x86_64|amd64)      arch="amd64" ;;
        arm64|aarch64)     arch="arm64" ;;
        *)                 return 1 ;;
    esac
    case "$os" in
        darwin|linux)      echo "${os}-${arch}" ;;
        *)                 return 1 ;;
    esac
}

_mcp_cert_valid_for_60d() {
    local crt="$1"
    [ -f "$crt" ] || return 1
    command -v openssl >/dev/null 2>&1 || return 1
    # -checkend arg is in seconds; 60d = 5184000s. Wider buffer than 30d so the
    # daily auto-renewer (cert-cron) gets at least one trigger window before
    # an at-risk cert silently lapses. Exit 0 means cert valid past that.
    openssl x509 -in "$crt" -noout -checkend 5184000 >/dev/null 2>&1
}

# True when $crt's SAN already covers DNS name $name (or $name is empty, i.e.
# nothing extra required). Lets the reuse gate force a re-sign when an older
# cert predates the in-network service SAN, so the change self-heals on the next
# compose-up instead of waiting for the 60-day renewal window.
_mcp_cert_covers_san() {
    local crt="$1" name="$2"
    [ -n "$name" ] || return 0
    command -v openssl >/dev/null 2>&1 || return 0
    openssl x509 -in "$crt" -noout -ext subjectAltName 2>/dev/null | grep -qE "(^|[, ])DNS:${name}(,|$)"
}

# Ensure mkcert on PATH (echo resolved path). Prefers system binary; else
# fetches the pinned release + SHA256-verifies into $(get_lib_dir)/bin/mkcert.
_mcp_cert_ensure_mkcert() {
    if command -v mkcert >/dev/null 2>&1; then
        command -v mkcert
        return 0
    fi

    # Cache mkcert in the user cache dir, not in $(get_lib_dir): when bitoarch
    # is installed system-wide (/usr/local/lib/bitoarch), the lib dir is root-
    # owned and a non-sudo install would fail to write the binary there.
    local cached="$(get_user_cache_dir)/bin/mkcert"
    if [ -x "$cached" ]; then
        echo "$cached"
        return 0
    fi

    local platform
    platform="$(_mcp_cert_detect_platform)" || {
        msg_error "Unsupported OS/arch for mkcert auto-download; install mkcert manually."
        return 1
    }

    local artifact="mkcert-${_MCP_CERT_MKCERT_VERSION}-${platform}"
    local url="${_MCP_CERT_MKCERT_URL_BASE}/${_MCP_CERT_MKCERT_VERSION}/${artifact}"
    local expected
    expected="$(_mcp_cert_expected_sha256 "$platform")"
    if [ -z "$expected" ]; then
        msg_error "No pinned mkcert checksum for platform: ${platform}"
        return 1
    fi

    mkdir -p "$(dirname "$cached")" || return 1
    msg_info "Fetching mkcert ${_MCP_CERT_MKCERT_VERSION} (${platform})..."
    if ! curl -fsSL -o "${cached}.tmp" "$url"; then
        msg_error "Failed to download mkcert from ${url}"
        rm -f "${cached}.tmp"
        return 1
    fi

    local actual
    if command -v sha256sum >/dev/null 2>&1; then
        actual="$(sha256sum "${cached}.tmp" | awk '{print $1}')"
    elif command -v shasum >/dev/null 2>&1; then
        actual="$(shasum -a 256 "${cached}.tmp" | awk '{print $1}')"
    else
        msg_error "No sha256sum/shasum available; cannot verify mkcert binary."
        rm -f "${cached}.tmp"
        return 1
    fi

    if [ "$actual" != "$expected" ]; then
        msg_error "mkcert checksum mismatch (expected ${expected}, got ${actual})."
        rm -f "${cached}.tmp"
        return 1
    fi

    mv "${cached}.tmp" "$cached" && chmod 0755 "$cached" || return 1
    echo "$cached"
}

# -----------------------------------------------------------------------------
# Public API
# -----------------------------------------------------------------------------

# Idempotent cert gen. Gated on MCP_TRANSPORT=https -- Enterprise no-ops.
# Exit 0 on success, 1 on failure. Safe to call before every compose up.
mcp_cert_generate() {
    [ "${MCP_TRANSPORT:-http}" = "https" ] || return 0

    local cert_dir crt key
    cert_dir="$(mcp_cert_dir)"
    crt="$(_mcp_cert_crt_path)"
    key="$(_mcp_cert_key_path)"

    # 0755 dir + 0644 key (below) so the provider container's appuser (UID
    # 1001) can read the bind-mounted cert on Linux/WSL where Docker has no
    # UID translation. Applied unconditionally (before reuse-early-return)
    # so existing certs from older installs get repaired in place. Cert is
    # localhost-only; leaked key can forge a localhost cert only.
    [ -d "$cert_dir" ] && chmod 0755 "$cert_dir" 2>/dev/null || true
    [ -f "$key" ] && chmod 0644 "$key" 2>/dev/null || true

    # In-network service name (default the provider's container/alias) so
    # containerized clients -- plugins, sibling services -- reach the provider
    # by name over TLS, not just host-side localhost. MCP_CERT_EXTRA_SANS allows
    # extra names (e.g. a k8s service FQDN), space-separated.
    local svc="${MCP_SERVER_NAME:-ai-architect-provider}"

    # have_valid: an existing 60d-valid cert is a working fallback. When it only
    # lacks the in-network SAN we try to re-sign, but treat every failure below
    # as non-blocking (keep the old cert) so the provider always starts -- e.g.
    # on an air-gapped host where re-fetching mkcert would fail.
    local have_valid=0
    if [ -f "$crt" ] && [ -f "$key" ] && _mcp_cert_valid_for_60d "$crt"; then
        if _mcp_cert_covers_san "$crt" "$svc"; then
            log_silent "mcp-cert: reusing valid cert at ${crt}"
            return 0
        fi
        have_valid=1
        log_silent "mcp-cert: cert lacks SAN '${svc}'; attempting in-place re-sign"
    fi

    local mkcert_bin
    if ! mkcert_bin="$(_mcp_cert_ensure_mkcert)"; then
        [ "$have_valid" -eq 1 ] && { log_silent "mcp-cert: mkcert unavailable; keeping existing cert (SAN upgrade deferred)"; return 0; }
        return 1
    fi

    mkdir -p "$cert_dir" || return 1
    chmod 0755 "$cert_dir" 2>/dev/null || true

    # mkcert stderr (sudo prompts, file-perm errors, CA issues) goes to
    # setup.log so future failures are diagnosable; stdout stays silent.
    local log
    if command -v get_setup_log >/dev/null 2>&1; then
        log="$(get_setup_log)"
    else
        log="${HOME}/.local/bitoarch/var/log/setup.log"
    fi
    mkdir -p "$(dirname "$log")" 2>/dev/null || true
    echo "--- $(date -u +%FT%TZ) mcp-cert: mkcert run ---" >> "$log" 2>/dev/null || true

    # -install is idempotent -- no-op when the local CA is already trusted.
    if ! "$mkcert_bin" -install >/dev/null 2>>"$log"; then
        msg_warn "mkcert -install failed; cert still generated but host trust may be incomplete. See ${log}."
    fi

    # shellcheck disable=SC2086 -- $svc / extra SANs are deliberately word-split.
    if ! "$mkcert_bin" -cert-file "$crt" -key-file "$key" \
            localhost bitoarch.local 127.0.0.1 ::1 "$svc" ${MCP_CERT_EXTRA_SANS:-} >/dev/null 2>>"$log"; then
        [ "$have_valid" -eq 1 ] && { log_silent "mcp-cert: re-sign failed; keeping existing cert (SAN upgrade deferred)"; return 0; }
        msg_error "mkcert failed to issue cert at ${crt}; see ${log} for details."
        return 1
    fi
    chmod 0644 "$key" 2>/dev/null || true
    log_silent "mcp-cert: issued cert at ${crt}"
}

# Force re-sign. Reuses the existing mkcert CA (no sudo re-prompt).
mcp_cert_regenerate() {
    rm -f "$(_mcp_cert_crt_path)" "$(_mcp_cert_key_path)" 2>/dev/null || true
    mcp_cert_generate
}

# Best-effort removal of mkcert root CA from host trust stores. Never blocks
# uninstall -- returns 0 even when mkcert is missing or -uninstall fails.
mcp_cert_trust_uninstall() {
    local mkcert_bin
    if command -v mkcert >/dev/null 2>&1; then
        mkcert_bin="$(command -v mkcert)"
    elif [ -x "$(get_lib_dir)/bin/mkcert" ]; then
        mkcert_bin="$(get_lib_dir)/bin/mkcert"
    else
        return 0
    fi
    "$mkcert_bin" -uninstall >/dev/null 2>&1 || true
    return 0
}

# One-shot pre-compose-up helper. Every lifecycle caller (install, start,
# restart, restart --force) sources this file and calls just this function.
mcp_cert_prepare_for_compose() {
    if [ "${MCP_TRANSPORT:-http}" = "https" ]; then
        mcp_cert_generate || return 1
        export HOST_MCP_CERT_DIR="$(mcp_cert_dir)"
        export XMCP_INTERNAL_PORT="${XMCP_HTTPS_PORT:-3443}"
    else
        # Enterprise / HTTP: do NOT export HOST_MCP_CERT_DIR so docker-compose
        # falls back to its default `./services/cis-provider/certs` mount
        # (matches release/1.7.1 Enterprise behavior on macOS + Linux).
        export XMCP_INTERNAL_PORT="${XMCP_HTTP_PORT:-8080}"
    fi
    return 0
}

# Cross-platform notAfter -> epoch parse (BSD `date -j -f` on macOS,
# GNU `date -d` on Linux). Echoes empty on failure.
_mcp_cert_epoch_from_notafter() {
    local s="$1" e
    [ -n "$s" ] || return 1
    if e=$(date -j -f "%b %e %T %Y %Z" "$s" +%s 2>/dev/null); then echo "$e"; return 0; fi
    if e=$(date -j -f "%b %d %T %Y %Z" "$s" +%s 2>/dev/null); then echo "$e"; return 0; fi
    if e=$(date -d "$s" +%s 2>/dev/null);                       then echo "$e"; return 0; fi
    return 1
}

# Echoes "VERDICT|DAYS_REMAINING|CERT_PATH". Always exits 0.
# VERDICT: ok | warn | expired | missing | unsupported
mcp_cert_status_summary() {
    local crt
    crt="$(_mcp_cert_crt_path)"
    if [ ! -f "$crt" ]; then
        echo "missing|0|${crt}"
        return 0
    fi
    if ! command -v openssl >/dev/null 2>&1; then
        echo "unsupported|-1|${crt}"
        return 0
    fi
    if ! openssl x509 -in "$crt" -noout -checkend 0 >/dev/null 2>&1; then
        echo "expired|0|${crt}"
        return 0
    fi

    local notafter epoch_after epoch_now diff_days verdict
    notafter="$(openssl x509 -in "$crt" -noout -enddate 2>/dev/null | cut -d= -f2-)"
    epoch_after="$(_mcp_cert_epoch_from_notafter "$notafter")"
    if [ -z "$epoch_after" ]; then
        if openssl x509 -in "$crt" -noout -checkend 5184000 >/dev/null 2>&1; then
            echo "ok|-1|${crt}"
        else
            echo "warn|-1|${crt}"
        fi
        return 0
    fi

    epoch_now=$(date +%s)
    diff_days=$(( (epoch_after - epoch_now) / 86400 ))
    if   [ "$diff_days" -lt 0 ];  then verdict="expired"
    elif [ "$diff_days" -lt 60 ]; then verdict="warn"
    else                               verdict="ok"
    fi
    echo "${verdict}|${diff_days}|${crt}"
    return 0
}

# Cron entry point. Always exits 0; scheduled tasks must never propagate
# non-zero or we trigger retry storms.
mcp_cert_renew_check() {
    [ "${MCP_TRANSPORT:-http}" = "https" ] || return 0

    local summary verdict days
    summary="$(mcp_cert_status_summary)"
    verdict="${summary%%|*}"
    days="$(echo "$summary" | cut -d'|' -f2)"

    if [ "$verdict" = "ok" ]; then
        log_silent "mcp-cert renew --check: cert valid for ${days} days; no action"
        return 0
    fi

    log_silent "mcp-cert renew --check: triggering renewal (verdict=${verdict}, days_remaining=${days})"

    if ! mcp_cert_regenerate >/dev/null 2>&1; then
        log_silent "mcp-cert renew --check: regenerate FAILED -- will retry on next schedule"
        return 0
    fi
    log_silent "mcp-cert renew --check: cert regenerated"

    # Make HOST_MCP_CERT_DIR + XMCP_INTERNAL_PORT visible to xmcp_restart_provider's
    # docker-compose call so the new cert volume + HTTPS port are picked up.
    mcp_cert_prepare_for_compose >/dev/null 2>&1 || true

    if [ -n "${SCRIPT_DIR:-}" ] && [ -f "${SCRIPT_DIR}/scripts/lib/adapters/xmcp-adapter.sh" ]; then
        # shellcheck disable=SC1091
        source "${SCRIPT_DIR}/scripts/lib/adapters/xmcp-adapter.sh"
        if command -v xmcp_restart_provider >/dev/null 2>&1; then
            if xmcp_restart_provider >/dev/null 2>&1; then
                log_silent "mcp-cert renew --check: provider restarted"
            else
                log_silent "mcp-cert renew --check: provider restart skipped/failed (cert will load on next start)"
            fi
        fi
    fi

    if [ -n "${SCRIPT_DIR:-}" ] && [ -f "${SCRIPT_DIR}/scripts/lib/node-trust.sh" ]; then
        # shellcheck disable=SC1091
        source "${SCRIPT_DIR}/scripts/lib/node-trust.sh"
        command -v node_trust_install >/dev/null 2>&1 && \
            node_trust_install >/dev/null 2>&1 || true
    fi

    log_silent "mcp-cert renew --check: renewal complete"
    return 0
}

export -f mcp_cert_dir
export -f mcp_cert_generate
export -f mcp_cert_regenerate
export -f mcp_cert_trust_uninstall
export -f mcp_cert_prepare_for_compose
export -f mcp_cert_status_summary
export -f mcp_cert_renew_check
