#!/bin/bash
#
# Copyright (c) 2023-2026 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# @company Bito Inc.
# @website https://bito.ai
#
# K8s on-demand port-forwards: opened by the command that needs one, verified
# end-to-end before reuse, recreated when stale. Every function no-ops on docker.

if [ -n "${_BITOARCH_K8S_PF_LOADED:-}" ]; then
    return 0
fi
_BITOARCH_K8S_PF_LOADED=1

# Namespace/context for every kubectl call in this file — the single multi-cluster seam.
_k8s_pf_kubectl_args() {
    printf -- '-n %s' "${BITOARCH_K8S_NAMESPACE:-bito-ai-architect}"
    [ -n "${BITOARCH_K8S_CONTEXT:-}" ] && printf -- ' --context %s' "$BITOARCH_K8S_CONTEXT"
}

# Internal ClusterIP port per service. Base services resolve from env; anything
# else (plugin/pack services) from its Service object. Empty when unresolvable.
get_service_internal_port() {
    local service="$1"
    case "$service" in
        "ai-architect-provider") echo "${XMCP_HTTP_PORT:-8080}" ;;
        "ai-architect-manager") echo "${CIS_MANAGER_PORT:-9090}" ;;
        "ai-architect-config") echo "${CIS_CONFIG_PORT:-8081}" ;;
        "ai-architect-tracker") echo "${CIS_TRACKING_PORT:-9920}" ;;
        # NOT $MYSQL_PORT: load_env_config remaps that global to the external port
        # for localhost access; the in-cluster mysql Service always listens on 3306.
        "ai-architect-mysql") echo "3306" ;;
        *)
            # shellcheck disable=SC2046
            kubectl get svc "$service" $(_k8s_pf_kubectl_args) \
                -o jsonpath='{.spec.ports[0].port}' 2>/dev/null
            ;;
    esac
}

# Detect if running against a Kubernetes deployment (.deployment-type from setup).
is_kubernetes_deployment() {
    if ! type get_deployment_type_file >/dev/null 2>&1; then
        source "${SCRIPT_DIR}/scripts/lib/path-manager.sh" 2>/dev/null || true
    fi
    local deployment_file
    if type get_deployment_type_file >/dev/null 2>&1; then
        deployment_file=$(get_deployment_type_file)
    else
        deployment_file="${SCRIPT_DIR}/.deployment-type"
    fi
    if [ -f "$deployment_file" ]; then
        local deployment_type=$(cat "$deployment_file" 2>/dev/null | tr -d '[:space:]')
        [ "$deployment_type" = "kubernetes" ] && return 0
    fi
    return 1
}

# Something is LISTENing on the local port (says nothing about tunnel health).
port_forward_active() {
    local port="$1"
    if command -v lsof >/dev/null 2>&1; then
        lsof -i :"$port" -sTCP:LISTEN >/dev/null 2>&1
        return $?
    elif command -v nc >/dev/null 2>&1; then
        nc -z localhost "$port" >/dev/null 2>&1
        return $?
    else
        curl -s --connect-timeout 1 "http://localhost:$port" >/dev/null 2>&1
        return 0  # assume reachable when no checker exists
    fi
}

# Wait for the local port to bind after starting a forward.
wait_for_port() {
    local port="$1"
    local max_wait=20  # generous cap; the local port usually binds in well under a second
    local count=0
    while [ $count -lt $max_wait ]; do
        if port_forward_active "$port"; then
            return 0
        fi
        sleep 0.5
        count=$((count + 1))
    done
    return 1
}

# Start a forward for a service. Detached (nohup+disown) so it persists after the
# command exits and later commands reuse it.
start_port_forward() {
    local service="$1"
    local local_port="$2"

    if port_forward_active "$local_port"; then
        [ "$VERBOSE" = "true" ] && echo "Port $local_port already forwarded" >&2
        return 0
    fi
    if ! command -v kubectl >/dev/null 2>&1; then
        print_error "kubectl not found - required for Kubernetes deployments"
        return 1
    fi

    local internal_port=$(get_service_internal_port "$service")
    if [ -z "$internal_port" ]; then
        [ "$VERBOSE" = "true" ] && echo "Warning: Unknown internal port for $service, using $local_port" >&2
        internal_port="$local_port"
    fi

    [ "$VERBOSE" = "true" ] && echo "Starting port-forward for $service: localhost:$local_port -> $service:$internal_port" >&2

    # Bind localhost-only: the CLI is the sole consumer; external access is via Ingress.
    # shellcheck disable=SC2046
    nohup kubectl port-forward --address 127.0.0.1 "svc/$service" "${local_port}:${internal_port}" $(_k8s_pf_kubectl_args) </dev/null >/dev/null 2>&1 &
    disown 2>/dev/null || true

    if wait_for_port "$local_port"; then
        [ "$VERBOSE" = "true" ] && echo "✓ Port-forward ready: $service on localhost:$local_port" >&2
        return 0
    else
        log_silent "Port-forward may not be ready on port $local_port"
        return 1
    fi
}

# Liveness probe for an existing forward: a live tunnel sends a greeting byte
# (mysql) or holds the connection open (HTTP); a stale one EOFs immediately.
port_forward_alive() {
    local port="$1" timeout=2 rc _b
    { exec 3<>"/dev/tcp/127.0.0.1/${port}"; } 2>/dev/null || return 1
    if read -r -t "$timeout" -n 1 _b <&3 2>/dev/null; then
        rc=0          # server-initiated byte → alive
    elif [ $? -gt 128 ]; then
        rc=0          # read timed out, connection held open → alive
    else
        rc=1          # EOF before timeout → stale forward
    fi
    { exec 3>&-; } 2>/dev/null
    return "$rc"
}

# Ensure a service is reachable on localhost:<port> (main entry point). Opens an
# on-demand forward if none is up, or recreates a stale one. No-op on docker.
ensure_service_accessible() {
    local service="$1"
    local port="$2"

    if ! is_kubernetes_deployment; then
        return 0
    fi

    if port_forward_active "$port"; then
        port_forward_alive "$port" && return 0
        # Stale forward — free the LISTENing local port, then reopen below.
        [ "$VERBOSE" = "true" ] && echo "Recreating stale port-forward on $port" >&2
        if command -v lsof >/dev/null 2>&1; then
            lsof -ti :"$port" -sTCP:LISTEN 2>/dev/null | xargs kill -9 2>/dev/null || true
            sleep 1
        fi
    fi
    start_port_forward "$service" "$port"
}

export -f is_kubernetes_deployment
export -f get_service_internal_port
export -f port_forward_active
export -f port_forward_alive
export -f wait_for_port
export -f start_port_forward
export -f ensure_service_accessible
