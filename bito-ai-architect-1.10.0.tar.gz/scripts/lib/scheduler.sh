#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
#
# Daily plugin auto-update scheduler. Mirrors cert-cron.sh:
# launchd (macOS) / systemd-user timer or crontab (Linux/WSL) / K8s CronJob,
# ~09:30 daily with a randomized delay, best-effort and idempotent. Invokes the
# standalone updater (scripts/bitoarch-updater.sh --scheduled), which only
# checks + stages — it never applies or restarts base. Decoupled from the MCP /
# cert schedulers; toggled by BITOARCH_PLUGIN_AUTO_UPDATE (default on).

if [ -n "${_BITOARCH_SCHEDULER_LOADED:-}" ]; then
    return 0
fi
_BITOARCH_SCHEDULER_LOADED=1

# scripts/lib -> repo root (../..). bitoarch.sh sets SCRIPT_DIR=scripts/,
# so derive independently from BASH_SOURCE.
_PS_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
if [ -f "${_PS_ROOT}/scripts/lib/path-manager.sh" ] && ! type get_log_dir >/dev/null 2>&1; then
    # shellcheck disable=SC1091
    . "${_PS_ROOT}/scripts/lib/path-manager.sh" 2>/dev/null || true
fi
if ! type plugin_update_opted_out >/dev/null 2>&1; then
    # shellcheck source=/dev/null
    . "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/plugin/plugin-updater.sh" 2>/dev/null || true
fi
if ! command -v log_silent >/dev/null 2>&1; then log_silent() { :; }; fi

_PS_LABEL="ai.bito.bitoarch-updater"
_PS_UNIT="bitoarch-updater"
_PS_SENTINEL="# BITOARCH_UPDATER"
_PS_DEFAULT_TIME="09:30"

_ps_platform() {
    case "$(uname -s)" in
        Darwin) echo "macos" ;;
        Linux)  grep -qiE 'microsoft|wsl' /proc/version 2>/dev/null && echo "wsl" || echo "linux" ;;
        *) echo "unknown" ;;
    esac
}

_ps_deployment() {
    if type get_deployment_type >/dev/null 2>&1; then get_deployment_type 2>/dev/null || echo docker-compose
    else echo docker-compose; fi
}

# The standalone updater entrypoint the schedule invokes.
_ps_updater_bin() {
    local c
    for c in "${_PS_ROOT}/scripts/bitoarch-updater.sh" "${_PS_ROOT}/scripts/bitoarch-plugin-update.sh"; do
        [ -f "$c" ] && { [ -x "$c" ] || chmod +x "$c" 2>/dev/null; echo "$c"; return 0; }
    done
    echo ""; return 1
}

_ps_log_dir() { if type get_log_dir >/dev/null 2>&1; then get_log_dir; else echo "${HOME}/.local/bitoarch/var/log"; fi; }
_ps_template_dir() { echo "${_PS_ROOT}/scripts/lib/scheduler"; }

# BITOARCH_PLUGIN_UPDATE_TIME (HH:MM) overrides 09:30. Process env first, then .env-bitoarch.
scheduler_time() {
    local t="${BITOARCH_PLUGIN_UPDATE_TIME:-}" env_file
    if [ -z "$t" ] && type get_config_file >/dev/null 2>&1; then
        env_file="$(get_config_file 2>/dev/null)"
        if [ -n "$env_file" ] && [ -f "$env_file" ]; then
            t="$(grep -E '^[[:space:]]*BITOARCH_PLUGIN_UPDATE_TIME[[:space:]]*=' "$env_file" 2>/dev/null | tail -1 \
                 | sed -E 's/^[[:space:]]*BITOARCH_PLUGIN_UPDATE_TIME[[:space:]]*=[[:space:]]*"?([^"]*)"?[[:space:]]*$/\1/')"
        fi
    fi
    scheduler_time_validate "$t" || t="$_PS_DEFAULT_TIME"
    echo "$t"
}
scheduler_time_validate() { [[ "${1:-}" =~ ^([0-1][0-9]|2[0-3]):[0-5][0-9]$ ]]; }

# \ and & are metacharacters in a sed s|..|REPL|g replacement -- escape them.
_ps_sed_escape() { printf '%s' "$1" | sed -e 's/\\/\\\\/g' -e 's/&/\\&/g'; }

_ps_render() {
    local template="$1" updater log_dir t hour minute image
    updater="$(_ps_updater_bin)" || return 1
    [ -n "$updater" ] || return 1
    log_dir="$(_ps_log_dir)"
    t="$(scheduler_time)"; hour=$((10#${t%%:*})); minute=$((10#${t##*:}))
    image="${BITOARCH_PLUGIN_UPDATER_IMAGE:-bitoarch/plugin-updater:latest}"
    updater="$(_ps_sed_escape "$updater")"; log_dir="$(_ps_sed_escape "$log_dir")"
    t="$(_ps_sed_escape "$t")"; hour="$(_ps_sed_escape "$hour")"; minute="$(_ps_sed_escape "$minute")"
    image="$(_ps_sed_escape "$image")"
    sed -e "s|{{UPDATER}}|${updater}|g" \
        -e "s|{{LOG_DIR}}|${log_dir}|g" \
        -e "s|{{HOUR}}|${hour}|g" \
        -e "s|{{MINUTE}}|${minute}|g" \
        -e "s|{{HHMM}}|${t}|g" \
        -e "s|{{UPDATER_IMAGE}}|${image}|g" \
        "$template"
}

# ── macOS launchd ──────────────────────────────────────────────────────────
_ps_install_macos() {
    local template plist log_dir
    template="$(_ps_template_dir)/${_PS_LABEL}.plist.template"
    plist="${HOME}/Library/LaunchAgents/${_PS_LABEL}.plist"
    log_dir="$(_ps_log_dir)"
    [ -f "$template" ] || { log_silent "scheduler: launchd template missing at $template"; return 1; }
    mkdir -p "$(dirname "$plist")" "$log_dir" 2>/dev/null || true
    # bootstrap (not legacy load): registers in the gui domain so operators can
    # trigger a run on demand with `launchctl kickstart gui/$UID/<label>`.
    launchctl bootout "gui/$(id -u)/${_PS_LABEL}" 2>/dev/null || launchctl unload "$plist" 2>/dev/null || true
    _ps_render "$template" > "$plist" 2>/dev/null || { log_silent "scheduler: failed to render plist"; return 1; }
    { launchctl bootstrap "gui/$(id -u)" "$plist" 2>/dev/null || launchctl load "$plist" 2>/dev/null; } \
        && log_silent "scheduler: scheduled via launchd (${_PS_LABEL}, daily $(scheduler_time))" \
        || log_silent "scheduler: launchctl load failed; plist in place at ${plist}"
    return 0
}
_ps_uninstall_macos() {
    local plist="${HOME}/Library/LaunchAgents/${_PS_LABEL}.plist"
    [ -f "$plist" ] || return 0
    launchctl bootout "gui/$(id -u)/${_PS_LABEL}" 2>/dev/null || launchctl unload "$plist" 2>/dev/null || true
    rm -f "$plist" 2>/dev/null
    log_silent "scheduler: removed launchd agent ${_PS_LABEL}"
    return 0
}

# ── Linux systemd-user + crontab fallback ──────────────────────────────────
_ps_systemd_available() { command -v systemctl >/dev/null 2>&1 && systemctl --user list-units --no-pager >/dev/null 2>&1; }
_ps_install_systemd() {
    local svc_t tmr_t dir svc tmr
    svc_t="$(_ps_template_dir)/${_PS_UNIT}.service.template"
    tmr_t="$(_ps_template_dir)/${_PS_UNIT}.timer.template"
    [ -f "$svc_t" ] && [ -f "$tmr_t" ] || return 1
    dir="${XDG_CONFIG_HOME:-${HOME}/.config}/systemd/user"
    mkdir -p "$dir" "$(_ps_log_dir)" 2>/dev/null || true
    svc="${dir}/${_PS_UNIT}.service"; tmr="${dir}/${_PS_UNIT}.timer"
    _ps_render "$svc_t" > "$svc" 2>/dev/null || return 1
    _ps_render "$tmr_t" > "$tmr" 2>/dev/null || return 1
    systemctl --user daemon-reload 2>/dev/null || return 1
    systemctl --user enable --now "${_PS_UNIT}.timer" 2>/dev/null || return 1
    log_silent "scheduler: scheduled via systemd-user timer (${_PS_UNIT}.timer, daily $(scheduler_time))"
    return 0
}
_ps_install_cron() {
    command -v crontab >/dev/null 2>&1 || return 1
    local updater tmp line t h m
    updater="$(_ps_updater_bin)" || return 1
    [ -n "$updater" ] || return 1
    t="$(scheduler_time)"; h=$((10#${t%%:*})); m=$((10#${t##*:}))
    line="${m} ${h} * * * ${updater} --scheduled ${_PS_SENTINEL}"
    tmp="$(mktemp)" || return 1
    crontab -l 2>/dev/null | grep -v "${_PS_SENTINEL}" > "$tmp" || true
    echo "$line" >> "$tmp"
    crontab "$tmp" 2>/dev/null && { rm -f "$tmp"; log_silent "scheduler: scheduled via crontab (daily ${t})"; return 0; }
    rm -f "$tmp"; return 1
}
_ps_install_linux() {
    if _ps_systemd_available && _ps_install_systemd; then return 0; fi
    log_silent "scheduler: systemd-user unavailable; trying crontab"
    _ps_install_cron && return 0
    log_silent "scheduler: neither systemd-user nor crontab available; skipped"
    return 0
}
_ps_uninstall_linux() {
    local dir tmp
    dir="${XDG_CONFIG_HOME:-${HOME}/.config}/systemd/user"
    if [ -f "${dir}/${_PS_UNIT}.timer" ] || [ -f "${dir}/${_PS_UNIT}.service" ]; then
        command -v systemctl >/dev/null 2>&1 && systemctl --user disable --now "${_PS_UNIT}.timer" 2>/dev/null || true
        rm -f "${dir}/${_PS_UNIT}.timer" "${dir}/${_PS_UNIT}.service" 2>/dev/null
        command -v systemctl >/dev/null 2>&1 && systemctl --user daemon-reload 2>/dev/null || true
        log_silent "scheduler: removed systemd-user timer"
    fi
    if command -v crontab >/dev/null 2>&1 && crontab -l 2>/dev/null | grep -q "${_PS_SENTINEL}"; then
        tmp="$(mktemp)" || return 0
        crontab -l 2>/dev/null | grep -v "${_PS_SENTINEL}" > "$tmp" || true
        if [ -s "$tmp" ]; then crontab "$tmp" 2>/dev/null || true; else crontab -r 2>/dev/null || true; fi
        rm -f "$tmp"; log_silent "scheduler: removed crontab entry"
    fi
    return 0
}

# ── Kubernetes CronJob ──────────────────────────────────────────────────────
# Render the CronJob manifest under VAR_DIR/scheduler (a bitoarch-level updater
# job, NOT plugin state — kept out of VAR_DIR/plugins). Apply it only when an
# updater image is configured (BITOARCH_PLUGIN_UPDATER_IMAGE) — the image is
# produced by the distribution pipeline; until then the manifest is staged.
_ps_k8s_manifest_path() {
    local base; base="$(type get_var_dir >/dev/null 2>&1 && get_var_dir || echo "${HOME}/.local/bitoarch/var")"
    echo "${base}/scheduler/${_PS_UNIT}.cronjob.yaml"
}
_ps_install_k8s() {
    local template out ns
    template="$(_ps_template_dir)/${_PS_UNIT}.cronjob.yaml.template"
    [ -f "$template" ] || { log_silent "scheduler: k8s CronJob template missing"; return 1; }
    out="$(_ps_k8s_manifest_path)"; mkdir -p "$(dirname "$out")" 2>/dev/null || true
    _ps_render "$template" > "$out" 2>/dev/null || { log_silent "scheduler: failed to render CronJob"; return 1; }
    ns="${BITOARCH_K8S_NAMESPACE:-bito-ai-architect}"
    if [ -n "${BITOARCH_PLUGIN_UPDATER_IMAGE:-}" ] && command -v kubectl >/dev/null 2>&1; then
        kubectl apply -n "$ns" -f "$out" 2>/dev/null \
            && log_silent "scheduler: applied K8s CronJob ${_PS_UNIT} (ns ${ns})" \
            || log_silent "scheduler: kubectl apply failed; manifest staged at ${out}"
    else
        log_silent "scheduler: auto-update runs from the HOST schedule (already installed); optional in-cluster CronJob staged at ${out} for host-less operation (activates via BITOARCH_PLUGIN_UPDATER_IMAGE)."
    fi
    return 0
}
_ps_uninstall_k8s() {
    local ns; ns="${BITOARCH_K8S_NAMESPACE:-bito-ai-architect}"
    command -v kubectl >/dev/null 2>&1 && kubectl delete cronjob "${_PS_UNIT}" -n "$ns" 2>/dev/null || true
    rm -f "$(_ps_k8s_manifest_path)" 2>/dev/null || true
    return 0
}

# ── Public API ──────────────────────────────────────────────────────────────
scheduler_install() {
    if plugin_update_opted_out; then
        log_silent "scheduler: BITOARCH_PLUGIN_AUTO_UPDATE disabled; removing any schedule"
        scheduler_uninstall
        return 0
    fi
    # The HOST CLI is the management plane for BOTH runtimes, so the schedule
    # always lives on the host (launchd / systemd / cron). On Kubernetes an
    # in-cluster CronJob is rendered ADDITIONALLY for host-less operation, and
    # applies only when an updater image is provided.
    case "$(_ps_platform)" in
        macos)     _ps_install_macos ;;
        linux|wsl) _ps_install_linux ;;
        *)         log_silent "scheduler: unsupported platform ($(uname -s)); skipping host schedule" ;;
    esac
    [ "$(_ps_deployment)" = "kubernetes" ] && _ps_install_k8s
    return 0
}

scheduler_uninstall() {
    [ "$(_ps_deployment)" = "kubernetes" ] && _ps_uninstall_k8s
    case "$(_ps_platform)" in
        macos)     _ps_uninstall_macos ;;
        linux|wsl) _ps_uninstall_linux ;;
    esac
    return 0
}

# Reconcile the schedule with current state: keep it while >=1 plugin is
# installed and auto-update is on; remove it otherwise. Called after uninstall.
scheduler_sync() {
    local has_plugins=0
    type journal_list_plugins >/dev/null 2>&1 && [ -n "$(journal_list_plugins 2>/dev/null)" ] && has_plugins=1
    if [ "$has_plugins" -eq 1 ] && ! plugin_update_opted_out; then
        scheduler_install
    else
        scheduler_uninstall
    fi
    return 0
}

export -f scheduler_install scheduler_uninstall scheduler_sync \
    scheduler_time scheduler_time_validate 2>/dev/null || true
