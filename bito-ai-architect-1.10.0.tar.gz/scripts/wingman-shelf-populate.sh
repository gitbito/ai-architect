#!/bin/sh
#
# Copyright (c) 2023-2026 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
#
# Populates the shared Wingman shelf (binary + tools + base skills) from the CDN.
# Runs INSIDE a container that mounts the shelf volume/PVC (docker one-shot / k8s
# Job), so it is POSIX sh + busybox-only (wget, unzip, tar, sed, grep, sort -V).
# Best-effort: any failure leaves the current shelf untouched and exits 0 so base
# start is never blocked. Highest-version-wins against the on-shelf `current`
# symlink for the binary and a `.manifest_version` marker for skills; no host state.

SHELF="${WINGMAN_SHELF_DIR:-/opt/bito/ai-architect/wingman}"
SKILLS_DIR="${SHELF}/skills"
BIN_NAME="${WINGMAN_BINARY_NAME:-bito-wingman}"
BASE="${WINGMAN_DOWNLOAD_BASE_URL:-https://wingman.bito.ai/}"; BASE="${BASE%/}"
# Skills live on the mcp-setup host — reuse the existing MCP_INSTALLER_BASE_URL (staging-aware) rather than a separate var.
SKILLS_BASE="${MCP_INSTALLER_BASE_URL:-https://mcp-setup.bito.ai}"; SKILLS_BASE="${SKILLS_BASE%/}"
ARCH="${WINGMAN_HOST_ARCH:-x86_64}"   # container arch; on-prem images are linux-x64

# Log to stderr so lines stream to `docker logs` immediately (stdout is block-buffered
# when not a TTY, which would hide all progress until the script exits).
log() { echo "[wingman-populate] $*" >&2; }

case "$ARCH" in
    x86_64|amd64)  PKEY="linux-x64" ;;
    arm64|aarch64) PKEY="linux-arm64" ;;
    *)             PKEY="linux-${ARCH}" ;;
esac

# First non-empty string value for a top-level "key": "value" pair in a manifest.
# Retention: keep the live `current` version plus WINGMAN_SHELF_KEEP previous
# versions (default 2), newest-first by mtime; prune older version dirs so the
# shared PVC does not grow unbounded. Immutable-versioned-artifact convention:
# the current symlink target and non-version entries (skills/, markers) are never
# touched, and rollback stays possible to the retained previous versions.
_prune_shelf() {
    [ -d "$SHELF" ] || return 0
    keep="${WINGMAN_SHELF_KEEP:-2}"
    case "$keep" in ''|*[!0-9]*) keep=2 ;; esac
    target=""; [ -L "$SHELF/current" ] && target="$(readlink "$SHELF/current" 2>/dev/null)"
    n=0
    for d in $(ls -1t "$SHELF" 2>/dev/null); do
        case "$d" in
            current|skills|.*) continue ;;   # symlink, skills tree, markers/staging
            "$target")         continue ;;   # never the live version
            [0-9]*)            ;;            # version-shaped only
            *)                 continue ;;
        esac
        [ -d "$SHELF/$d" ] || continue
        n=$((n + 1))
        if [ "$n" -gt "$keep" ]; then
            chmod -R u+w "$SHELF/$d" 2>/dev/null || true
            rm -rf "$SHELF/$d" 2>/dev/null && log "pruned old Wingman version ${d} (retention: current + ${keep})"
        fi
    done
}

_json_str() { grep -o "\"$1\"[[:space:]]*:[[:space:]]*\"[^\"]*\"" "$2" 2>/dev/null | head -1 | sed 's/.*:[[:space:]]*"\([^"]*\)".*/\1/'; }

# Make the shelf root writable so the manager/worker fallback can create and
# populate <shelf>/current when this CDN populate is skipped/unreachable — that
# offline case is exactly when the fallback runs. Root-owned by default and
# services may run non-root; on k8s the pod fsGroup covers this instead.
mkdir -p "$SHELF" 2>/dev/null || true
chmod 0777 "$SHELF" 2>/dev/null || true

command -v wget >/dev/null 2>&1 || { log "wget unavailable; skipped"; exit 0; }
tmp="$(mktemp -d 2>/dev/null)" || exit 0
trap 'rm -rf "$tmp"' EXIT

# wget wrapper: quiet on success; on failure logs wget's own last error line
# (DNS vs timeout vs TLS reset) so "CDN unreachable" is diagnosable from the log.
fetch() {   # <timeout> <dest> <url>
    wget -q -T "$1" -O "$2" "$3" 2>"$tmp/wget.err" && return 0
    log "fetch failed: $3 ($(tail -1 "$tmp/wget.err" 2>/dev/null | tr -d '\r'))"
    return 1
}
log "starting shelf populate for ${PKEY} (downloads run quietly; this can take a minute)"

# ---------------------------------------------------------------------------
# Binary + tools
# ---------------------------------------------------------------------------
if fetch 20 "$tmp/manifest.json" "$BASE/manifest.json"; then
    wver="$(_json_str wingman-version "$tmp/manifest.json")"
    tver="$(_json_str tools-version  "$tmp/manifest.json")"
    if [ -z "$wver" ]; then
        log "manifest has no wingman-version; skipping binary"
    else
        cur=""; [ -L "$SHELF/current" ] && cur="$(readlink "$SHELF/current" 2>/dev/null)"
        skip=0
        if [ -n "$cur" ] && [ "${BITOARCH_WINGMAN_SYNC_FORCE:-0}" != "1" ]; then
            if [ "$cur" = "$wver" ]; then skip=1; log "shelf already at ${wver}"; fi
            if [ "$skip" = "0" ] && [ "$(printf '%s\n%s\n' "$wver" "$cur" | sort -V 2>/dev/null | tail -1)" = "$cur" ]; then
                skip=1; log "shelf ${cur} >= manifest ${wver}; no binary sync"
            fi
        fi
        if [ "$skip" = "0" ]; then
            binfile="bitowingman-${wver}-${PKEY}"
            toolsfile="bitowingman-tools-${tver}-${PKEY}.zip"
            if ! grep -q "\"${binfile}\"" "$tmp/manifest.json" 2>/dev/null; then
                log "manifest ${wver} has no binary for ${PKEY}; skipping binary"
            elif log "downloading Wingman ${wver} binary (${PKEY})" && ! fetch 300 "$tmp/$BIN_NAME" "$BASE/$binfile"; then
                log "binary download failed (${binfile}); keeping the current shelf"
            else
                chmod 0755 "$tmp/$BIN_NAME" 2>/dev/null || true
                mkdir -p "$tmp/tools"
                if [ -n "$tver" ] && grep -q "\"${toolsfile}\"" "$tmp/manifest.json" 2>/dev/null \
                   && log "downloading Wingman tools ${tver}" \
                   && fetch 120 "$tmp/tools.zip" "$BASE/$toolsfile"; then
                    unzip -q -o "$tmp/tools.zip" -d "$tmp/tools" 2>/dev/null || { log "tools ${tver} unzip failed; binary only"; rm -rf "$tmp/tools"; mkdir -p "$tmp/tools"; }
                    inner="$(find "$tmp/tools" -mindepth 1 -maxdepth 1 2>/dev/null)"
                    if [ "$(printf '%s\n' "$inner" | grep -c . 2>/dev/null)" = "1" ] && [ -d "$inner" ]; then
                        ( cd "$inner" && tar -cf - . ) | ( cd "$tmp/tools" && tar -xf - ) 2>/dev/null && rm -rf "$inner"
                    fi
                else
                    [ -n "$tver" ] && log "tools ${tver} unavailable; publishing binary only"
                fi
                # Publish atomically: stage <ver>/, then flip current in place.
                mkdir -p "$SHELF"
                stage="$SHELF/.populate.$$"; rm -rf "$stage"
                if mkdir -p "$stage/$wver"; then
                    cp "$tmp/$BIN_NAME" "$stage/$wver/$BIN_NAME" && chmod 0555 "$stage/$wver/$BIN_NAME"
                    if [ -d "$tmp/tools" ] && [ -n "$(ls -A "$tmp/tools" 2>/dev/null)" ]; then
                        cp -R "$tmp/tools" "$stage/$wver/tools"
                        [ -n "$tver" ] && printf '%s' "$tver" > "$stage/$wver/.tools_version"
                    fi
                    chmod -R u+w "$SHELF/$wver" 2>/dev/null || true; rm -rf "$SHELF/$wver"
                    if mv "$stage/$wver" "$SHELF/$wver"; then
                        # Point current/ at the new version. current/ is a symlink
                        # when we own it, but a fallback self-download (go-common
                        # MkdirAll) leaves it a REAL dir — drop that so ln can't nest
                        # inside it; ln -sfn (-n) re-points an existing symlink in place.
                        [ -L "$SHELF/current" ] || rm -rf "$SHELF/current"
                        ln -sfn "$wver" "$SHELF/current"
                        log "published binary ${wver} (tools ${tver:-none}) for ${PKEY}"
                    else
                        log "publish move failed; keeping the current shelf"
                    fi
                    rm -rf "$stage"
                fi
            fi
        fi
    fi
else
    log "wingman CDN unreachable (${BASE}); keeping the current shelf"
fi

# ---------------------------------------------------------------------------
# Base skills (mirrors the binary flow: manifest-driven, highest-wins via marker)
# ---------------------------------------------------------------------------
sm="$tmp/skills.json"
if fetch 20 "$sm" "$SKILLS_BASE/skills/manifest.json"; then
    sver="$(_json_str version "$sm")"
    marker="$SKILLS_DIR/.manifest_version"
    cur_sver=""; [ -f "$marker" ] && cur_sver="$(cat "$marker" 2>/dev/null)"
    if [ -n "$sver" ] && [ "$sver" = "$cur_sver" ] && [ "${BITOARCH_WINGMAN_SYNC_FORCE:-0}" != "1" ]; then
        log "base skills already at ${sver}"
    elif [ -z "$sver" ]; then
        log "skills manifest has no version; skipping skills"
    else
        mkdir -p "$SKILLS_DIR"
        log "syncing base skills ${sver}"
        # Each skill: derive name from its SKILL.md path, download every file it references.
        grep -oE '"skills/[^"]*/SKILL\.md"' "$sm" | sed 's#"skills/\([^/]*\)/SKILL.md"#\1#' | sort -u | while IFS= read -r name; do
            [ -z "$name" ] && continue
            dest="$SKILLS_DIR/bito-${name}"
            grep -oE "\"skills/${name}/[^\"]*\"" "$sm" | tr -d '"' | sort -u | while IFS= read -r ref; do
                [ -z "$ref" ] && continue
                rel="${ref#skills/${name}/}"
                mkdir -p "$dest/$(dirname "$rel")" 2>/dev/null
                fetch 30 "$dest/$rel" "$SKILLS_BASE/$ref" || true
            done
        done
        # Retired base skills leave the shelf. Extract ONLY the removed_skills array
        # (flattened, bounded to its first ']') so active skill names are never captured.
        removed="$(tr -d '\n' < "$sm" | sed -n 's/.*"removed_skills"[[:space:]]*:[[:space:]]*\[\([^]]*\)\].*/\1/p')"
        for rname in $(printf '%s' "$removed" | grep -oE '"[a-zA-Z0-9_-]+"' | tr -d '"'); do
            rm -rf "$SKILLS_DIR/bito-${rname}"
        done
        printf '%s' "$sver" > "$marker" 2>/dev/null || true
        log "base skills synced to ${sver}"
    fi
else
    log "skills CDN unreachable (${SKILLS_BASE}); keeping the current skills"
fi

# Enforce binary retention last, whenever `current` is valid — self-heals any
# buildup from before retention existed, independent of whether we published today.
_prune_shelf

exit 0
