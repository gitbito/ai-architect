#!/bin/sh
#
# Tests for wingman-shelf-populate.sh. POSIX sh / busybox-compatible.
#
# Runs the REAL script against a fake local CDN via a `wget` shim, so there is no
# network dependency. Run it in the production runtime image to match behaviour:
#
#   docker run --rm -v "$PWD:/w" -w /w busybox:1.36 sh scripts/wingman-shelf-populate_test.sh
#
# or with any POSIX sh:  sh scripts/wingman-shelf-populate_test.sh
#
# Covers: fresh publish, current/ reconciliation (real dir left by a fallback
# self-download, prior symlink, none), writable-root prep, offline best-effort,
# and version retention.

set -u

REPO_ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
SCRIPT="$REPO_ROOT/scripts/wingman-shelf-populate.sh"
VER=1.6.0
TVER=1.5.0
PKEY=linux-x64

pass=0
fail=0
ok() { pass=$((pass + 1)); echo "ok   - $1"; }
no() { fail=$((fail + 1)); echo "FAIL - $1"; }

# setup builds a work area with a fake CDN (binary only; tools omitted so no real
# zip fixture is needed — the script then publishes binary-only) and a wget shim.
setup() {
	WORK=$(mktemp -d)
	CDN="$WORK/cdn"
	SHELF="$WORK/shelf"
	BINDIR="$WORK/bin"
	mkdir -p "$CDN" "$SHELF" "$BINDIR"
	printf '{ "wingman-version": "%s", "tools-version": "%s", "files": ["bitowingman-%s-%s"] }\n' \
		"$VER" "$TVER" "$VER" "$PKEY" >"$CDN/manifest.json"
	printf 'FAKE-WINGMAN-BINARY\n' >"$CDN/bitowingman-$VER-$PKEY"
	# wget shim: parse `-O <dest> <url>`, map the url path to $WGET_CDN/<path>.
	cat >"$BINDIR/wget" <<'SHIM'
#!/bin/sh
dest=""; url=""
while [ $# -gt 0 ]; do
  case "$1" in
    -O) dest=$2; shift 2 ;;
    -T) shift 2 ;;
    -*) shift ;;
    *)  url=$1; shift ;;
  esac
done
p=$(printf '%s' "$url" | sed 's#^[a-z][a-z]*://[^/]*/##')
[ -f "$WGET_CDN/$p" ] && cp "$WGET_CDN/$p" "$dest" || exit 1
SHIM
	chmod +x "$BINDIR/wget"
}

# run executes the real script against the fake CDN. $1 = WINGMAN_SHELF_KEEP.
run() {
	WGET_CDN="$CDN" \
		PATH="$BINDIR:$PATH" \
		WINGMAN_SHELF_DIR="$SHELF" \
		WINGMAN_DOWNLOAD_BASE_URL="http://cdn.local/" \
		MCP_INSTALLER_BASE_URL="http://cdn.local" \
		WINGMAN_HOST_ARCH="x86_64" \
		WINGMAN_BINARY_NAME="bito-wingman" \
		WINGMAN_SHELF_KEEP="${1:-2}" \
		sh "$SCRIPT" >/dev/null 2>&1
}

cleanup() { rm -rf "$WORK"; }

# current/ is a symlink to $VER with no nested link inside it.
current_is_clean_symlink() {
	[ -L "$SHELF/current" ] && [ "$(readlink "$SHELF/current")" = "$VER" ] && [ ! -e "$SHELF/current/$VER" ]
}

echo "# fresh publish (empty shelf)"
setup
run
if current_is_clean_symlink && [ -f "$SHELF/$VER/bito-wingman" ]; then
	ok "current -> $VER symlink; binary published; no nesting"
else
	no "fresh publish (current=$(ls -ld "$SHELF/current" 2>&1))"
fi
cleanup

echo "# reconciliation: fallback left a REAL dir at current/"
setup
mkdir -p "$SHELF/current"
printf 'stale\n' >"$SHELF/current/bito-wingman" # simulate go-common self-download
run
if current_is_clean_symlink; then
	ok "real-dir current/ replaced by symlink -> $VER (no nesting)"
else
	no "real-dir reconciliation (current=$(ls -ld "$SHELF/current" 2>&1))"
fi
cleanup

echo "# reconciliation: prior symlink current/ -> older version"
setup
mkdir -p "$SHELF/0.9.0"
ln -s 0.9.0 "$SHELF/current"
run
if current_is_clean_symlink; then
	ok "symlink current/ re-pointed to $VER (no nesting)"
else
	no "symlink reconciliation (current=$(ls -ld "$SHELF/current" 2>&1))"
fi
cleanup

echo "# writable-root prep: shelf root is chmod'd 0777 before the CDN work"
setup
run
mode=$(stat -c '%a' "$SHELF" 2>/dev/null || stat -f '%Lp' "$SHELF" 2>/dev/null)
if [ "$mode" = 777 ]; then
	ok "shelf root mode is 777"
else
	no "writable-root prep (mode=$mode)"
fi
cleanup

echo "# offline: CDN unreachable -> exit 0, existing current/ untouched"
setup
rm -f "$CDN/manifest.json" # make the binary manifest fetch fail
mkdir -p "$SHELF/current"
printf 'keep\n' >"$SHELF/current/bito-wingman" # a pre-existing install
run
ec=$?
if [ "$ec" = 0 ] && [ -f "$SHELF/current/bito-wingman" ] && [ ! -e "$SHELF/$VER" ]; then
	ok "offline: exit 0; pre-existing current/ untouched; nothing published"
else
	no "offline handling (ec=$ec)"
fi
cleanup

echo "# retention: keep current target + WINGMAN_SHELF_KEEP older versions"
setup
mkdir -p "$SHELF/0.7.0" "$SHELF/0.8.0" "$SHELF/0.9.0"
touch -t 202601010700 "$SHELF/0.7.0" 2>/dev/null || true
touch -t 202601010800 "$SHELF/0.8.0" 2>/dev/null || true
touch -t 202601010900 "$SHELF/0.9.0" 2>/dev/null || true
run 1 # WINGMAN_SHELF_KEEP=1
if [ -d "$SHELF/$VER" ] && [ -d "$SHELF/0.9.0" ] && [ ! -d "$SHELF/0.8.0" ] && [ ! -d "$SHELF/0.7.0" ]; then
	ok "kept $VER (current) + 0.9.0; pruned 0.8.0 and 0.7.0"
else
	no "retention (dirs: $(ls "$SHELF" 2>/dev/null | tr '\n' ' '))"
fi
cleanup

echo ""
echo "== $pass passed, $fail failed =="
[ "$fail" = 0 ]
