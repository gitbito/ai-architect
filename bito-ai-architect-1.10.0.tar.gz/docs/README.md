# AI Architect documentation

This folder holds the documentation for self-hosted AI Architect. It is split by
audience: **customer-facing** guides written for operators setting up and running
the product, and **internal** references written for developers building on the
platform.

## Customer-facing guides

| Document | For |
|---|---|
| [standalone-setup-guide.md](standalone-setup-guide.md) | Installing AI Architect in standalone mode (individuals / small teams). |
| [enterprise-setup-guide.md](enterprise-setup-guide.md) | Installing AI Architect in enterprise mode. |
| [CLI_REFERENCE.md](CLI_REFERENCE.md) | Full `bitoarch` command reference. |
| Installing and managing plugins (Slack AI Assistant, Bito Task Analyzer) | Lives with the plugins — see `docs/plugins.md` in the **`ai-architect-plugins`** repository. |

> These mirror the published documentation at
> [docs.bito.ai/ai-architect](https://docs.bito.ai/ai-architect). When publishing,
> adapt the Markdown to the site's format (GitBook stepper/hint components).

## Internal references (`internal/`)

For developers extending or maintaining the platform — not customer-facing.

| Document | Covers |
|---|---|
| [internal/PLUGIN_FRAMEWORK.md](internal/PLUGIN_FRAMEWORK.md) | The plugin framework: manifest contract, lifecycle, shared Wingman shelf, distribution & auto-update, dependency packs, ingress, install/uninstall internals. The authoring contract for `ai-architect-plugins`. |
| [internal/SETUP_AND_PACKAGING_GUIDE.md](internal/SETUP_AND_PACKAGING_GUIDE.md) | How the platform is set up and packaged for distribution. |
| [internal/SSO_ONPREM_OVERVIEW.md](internal/SSO_ONPREM_OVERVIEW.md) | On-prem SSO architecture and integration. |
| [internal/PLUGIN_OUTPUT_STYLE.md](internal/PLUGIN_OUTPUT_STYLE.md) | The CLI output style spec plugins and lifecycle commands follow. |
| [internal/STANDALONE_TEST_GUIDE.md](internal/STANDALONE_TEST_GUIDE.md) | Manual test guide for standalone mode. |
| [internal/ENTERPRISE_TEST_GUIDE.md](internal/ENTERPRISE_TEST_GUIDE.md) | Manual test guide for enterprise mode. |
| [internal/MANUAL_TESTING_GUIDE.md](internal/MANUAL_TESTING_GUIDE.md) | General manual testing procedures. |

## Plugins at a glance

Plugins are optional, independently installed services on top of the base
platform. Two ship today — **Slack AI Assistant** (`ai-assistant`) and **Bito
Task Analyzer** (`task-analyzer`). Installing, updating, or removing a plugin
never affects the base platform, its databases, or indexed repositories.

- **Operators:** the customer guide lives in the **`ai-architect-plugins`**
  repository at `docs/plugins.md` (published at
  [docs.bito.ai/ai-architect](https://docs.bito.ai/ai-architect)).
- **Developers building a plugin:** start with
  [internal/PLUGIN_FRAMEWORK.md](internal/PLUGIN_FRAMEWORK.md) (the authoring
  contract; the framework engine lives in this repository).
