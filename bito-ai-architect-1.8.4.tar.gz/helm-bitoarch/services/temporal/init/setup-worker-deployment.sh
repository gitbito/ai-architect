#!/bin/sh
#
# Mark the cis-worker's deployment version as "current" for the namespace.
#
# Must be invoked AFTER ai-architect-worker is up, otherwise the worker won't
# have registered its deployment version yet and there's nothing to promote.
#
# With system.enableDeploymentVersioning=true in dynamic config, this is the
# step that allows unversioned StartWorkflow calls from cis-manager to be
# auto-pinned to (and dispatched to) the versioned worker.
#
set -eu

: "${TEMPORAL_ADDRESS:=ai-architect-temporal:7233}"
: "${NAMESPACE:=${DEFAULT_NAMESPACE:-cis-onprem}}"
: "${DEPLOYMENT_NAME:=${TEMPORAL_WORKER_DEPLOYMENT_NAME:-cis-manager-workers}}"
: "${BUILD_ID:=${TEMPORAL_WORKER_BUILD_ID:-1.0.0}}"

echo "=========================================="
echo "Worker deployment version pairing"
echo "  namespace:  ${NAMESPACE}"
echo "  deployment: ${DEPLOYMENT_NAME}"
echo "  build-id:   ${BUILD_ID}"
echo "=========================================="

echo "Waiting for worker to self-register ${DEPLOYMENT_NAME}/${BUILD_ID}..."
attempts=0
max_attempts=36
while [ "${attempts}" -lt "${max_attempts}" ]; do
    if temporal worker deployment list \
            --address "${TEMPORAL_ADDRESS}" \
            --namespace "${NAMESPACE}" 2>/dev/null \
            | grep -q "${DEPLOYMENT_NAME}"; then
        echo "  deployment ${DEPLOYMENT_NAME} is registered"
        break
    fi
    attempts=$((attempts + 1))
    echo "  not registered yet, retrying in 10s (${attempts}/${max_attempts})..."
    sleep 10
done

if [ "${attempts}" -ge "${max_attempts}" ]; then
    echo "ERROR: worker deployment '${DEPLOYMENT_NAME}' never appeared in namespace '${NAMESPACE}'." >&2
    echo "       Check ai-architect-worker logs for registration errors." >&2
    exit 1
fi

echo "Setting ${DEPLOYMENT_NAME}/${BUILD_ID} as current version..."
if temporal worker deployment set-current-version \
        --address "${TEMPORAL_ADDRESS}" \
        --namespace "${NAMESPACE}" \
        --deployment-name "${DEPLOYMENT_NAME}" \
        --build-id "${BUILD_ID}" \
        --yes; then
    echo "${DEPLOYMENT_NAME}/${BUILD_ID} is now current"
else
    echo "WARNING: set-current-version failed (may already be current). Continuing." >&2
fi

echo ""
echo "Current deployment state:"
temporal worker deployment describe \
    --address "${TEMPORAL_ADDRESS}" \
    --namespace "${NAMESPACE}" \
    --name "${DEPLOYMENT_NAME}" || true
