#!/bin/sh
#
# Ensure required Temporal namespaces exist.
# Idempotent: describe-then-create per namespace.
#
set -eu

: "${TEMPORAL_ADDRESS:=ai-architect-temporal:7233}"
: "${NAMESPACES:=default cis-onprem}"

host=$(echo "${TEMPORAL_ADDRESS}" | cut -d: -f1)
port=$(echo "${TEMPORAL_ADDRESS}" | cut -d: -f2)

echo "Waiting for Temporal server port ${host}:${port}..."
max_port_attempts=60
port_attempt=0
until nc -z -w 10 "${host}" "${port}"; do
    port_attempt=$((port_attempt + 1))
    if [ "${port_attempt}" -ge "${max_port_attempts}" ]; then
        echo "ERROR: Temporal port ${host}:${port} not available after ${max_port_attempts} attempts" >&2
        exit 1
    fi
    echo "  port not available, retrying in 5s (${port_attempt}/${max_port_attempts})..."
    sleep 5
done
echo "Temporal server port is available"

echo "Waiting for Temporal server to be healthy..."
max_attempts=24
attempt=0
until temporal operator cluster health --address "${TEMPORAL_ADDRESS}" >/dev/null 2>&1; do
    attempt=$((attempt + 1))
    if [ "${attempt}" -ge "${max_attempts}" ]; then
        echo "ERROR: Temporal did not become healthy after ${max_attempts} attempts" >&2
        exit 1
    fi
    echo "  not ready, retrying in 5s (attempt ${attempt}/${max_attempts})..."
    sleep 10
done
echo "Server is healthy."

for NAMESPACE in ${NAMESPACES}; do
    echo "Ensuring namespace '${NAMESPACE}'..."
    if temporal operator namespace describe -n "${NAMESPACE}" --address "${TEMPORAL_ADDRESS}" >/dev/null 2>&1; then
        echo "  already exists"
    else
        temporal operator namespace create -n "${NAMESPACE}" --address "${TEMPORAL_ADDRESS}"
        echo "  created"
    fi
done

echo "All namespaces ready."
