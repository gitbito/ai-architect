#!/bin/sh
#
# Register the custom search attributes that cis-platform workflows expect.
# Idempotent: failures from "already exists" are ignored.
#
set -eu

: "${TEMPORAL_ADDRESS:=ai-architect-temporal:7233}"
: "${NAMESPACE:=cis-onprem}"

echo "================================================"
echo "Setting up Temporal Search Attributes"
echo "Address:   ${TEMPORAL_ADDRESS}"
echo "Namespace: ${NAMESPACE}"
echo "================================================"

# Probe the same API path as `create` so we don't race the operator namespace cache (~10s refresh).
echo "Waiting for namespace '${NAMESPACE}' to be visible to the operator API..."
max_attempts=30
attempt=0
until temporal operator search-attribute list \
        --address "${TEMPORAL_ADDRESS}" \
        --namespace "${NAMESPACE}" >/dev/null 2>&1; do
    attempt=$((attempt + 1))
    if [ "${attempt}" -ge "${max_attempts}" ]; then
        echo "ERROR: Namespace '${NAMESPACE}' not visible to operator API after ${max_attempts} attempts" >&2
        exit 1
    fi
    echo "Namespace '${NAMESPACE}' not ready, retrying in 10s (attempt ${attempt}/${max_attempts})..."
    sleep 10
done
echo "Namespace '${NAMESPACE}' is visible to the operator API"

create_sa() {
    name="$1"
    type="$2"
    echo "  creating search attribute ${name} (${type})..."
    sa_attempts=5
    sa_attempt=0
    while :; do
        sa_attempt=$((sa_attempt + 1))
        if out=$(temporal operator search-attribute create \
                    --address "${TEMPORAL_ADDRESS}" \
                    --namespace "${NAMESPACE}" \
                    --name "${name}" \
                    --type "${type}" 2>&1); then
            echo "    created"
            return 0
        fi
        case "${out}" in
            *"already exists"*|*"AlreadyExists"*)
                echo "    already exists — skipping"
                return 0
                ;;
            *"is not found"*|*"NamespaceNotFound"*|*"not found"*)
                if [ "${sa_attempt}" -ge "${sa_attempts}" ]; then
                    echo "ERROR: namespace cache never picked up '${NAMESPACE}' for ${name}" >&2
                    echo "${out}" >&2
                    exit 1
                fi
                echo "    namespace cache not ready (attempt ${sa_attempt}/${sa_attempts}), retrying in 5s..."
                sleep 5
                ;;
            *)
                echo "ERROR: failed to create search attribute ${name}" >&2
                echo "${out}" >&2
                exit 1
                ;;
        esac
    done
}

create_sa "workspace_id"         "Int"
create_sa "repository_namespace" "Keyword"
create_sa "session_id"           "Keyword"
create_sa "deployment_mode"      "Keyword"

echo ""
echo "Search attributes for namespace '${NAMESPACE}':"
temporal operator search-attribute list \
    --address "${TEMPORAL_ADDRESS}" \
    --namespace "${NAMESPACE}" || true

echo ""
echo "Search attributes setup complete"
