#!/bin/sh
#
# Verify that the cis-worker is polling the UNVERSIONED slot of the primary
# workflow task queue, i.e. that worker versioning is disabled end-to-end.
#
# Called when TEMPORAL_WORKER_VERSIONING_ENABLED is false.
#
# Exits 0 on success (>=1 unversioned poller detected), 1 otherwise.
#
set -eu

: "${TEMPORAL_ADDRESS:=ai-architect-temporal:7233}"
: "${NAMESPACE:=${DEFAULT_NAMESPACE:-cis-onprem}}"
: "${TASK_QUEUE:=cis-workflow-queue}"

echo "=========================================="
echo "Unversioned worker verification"
echo "  namespace:  ${NAMESPACE}"
echo "  task queue: ${TASK_QUEUE}"
echo "=========================================="

echo "Waiting for worker to attach as UNVERSIONED poller..."
attempts=0
max_attempts=36
while [ "${attempts}" -lt "${max_attempts}" ]; do
    out=$(temporal task-queue describe \
            --address "${TEMPORAL_ADDRESS}" \
            --namespace "${NAMESPACE}" \
            --task-queue "${TASK_QUEUE}" 2>/dev/null || true)

    if printf '%s\n' "$out" | awk '
        /^Pollers:/   { in_p=1; next }
        in_p && /UNVERSIONED/ && NF >= 3 { found=1 }
        END { exit(found?0:1) }
    '; then
        echo "  unversioned poller attached"
        printf '%s\n' "$out"
        exit 0
    fi

    attempts=$((attempts + 1))
    echo "  no unversioned poller yet, retrying in 10s (${attempts}/${max_attempts})..."
    sleep 10
done

echo "ERROR: no UNVERSIONED poller attached to ${TASK_QUEUE} in namespace ${NAMESPACE}." >&2
echo "       The cis-worker may still be starting up in versioned mode." >&2
exit 1
