#!/bin/sh
#
# Post-deploy worker version promotion orchestrator for Kubernetes.
# Mirrors the Docker deploy_cis_worker() post-deploy step from
# scripts/service-manager.sh.
#
# Branches on TEMPORAL_WORKER_VERSIONING_ENABLED:
#   true  -> runs setup-worker-deployment.sh to promote the worker's
#            build-id as the namespace's current deployment version.
#   false -> runs verify-unversioned-worker.sh to confirm the worker
#            is polling the UNVERSIONED slot.
#
set -eu

INIT_DIR="$(cd "$(dirname "$0")" && pwd)"

: "${TEMPORAL_WORKER_VERSIONING_ENABLED:=true}"

versioning=$(echo "${TEMPORAL_WORKER_VERSIONING_ENABLED}" | tr '[:upper:]' '[:lower:]')

if [ "${versioning}" = "true" ]; then
    echo "Worker versioning ENABLED - promoting deployment version..."
    sh "${INIT_DIR}/setup-worker-deployment.sh"
else
    echo "Worker versioning DISABLED - verifying unversioned poller..."
    sh "${INIT_DIR}/verify-unversioned-worker.sh"
fi
