#!/bin/sh
#
# Single post-deploy orchestrator for Temporal in Kubernetes.
# Mirrors the Docker deploy_temporal() + deploy_cis_worker() flow:
#
#   Phase 1 (bootstrap):
#     1. create-namespaces.sh       (idempotent)
#     2. setup-search-attributes.sh (idempotent)
#     3. validate.sh                (non-fatal)
#
#   Phase 2 (worker version promotion):
#     4. promote-worker-version.sh  (versioned or unversioned)
#
set -eu

INIT_DIR="$(cd "$(dirname "$0")" && pwd)"

: "${TEMPORAL_ADDRESS:=ai-architect-temporal:7233}"
: "${NAMESPACE:=${DEFAULT_NAMESPACE:-cis-onprem}}"
: "${NAMESPACES:=default ${NAMESPACE}}"

export TEMPORAL_ADDRESS NAMESPACE NAMESPACES

echo "=========================================="
echo "Temporal post-deploy starting"
echo "  address:   ${TEMPORAL_ADDRESS}"
echo "  namespace: ${NAMESPACE}"
echo "=========================================="

# Phase 1: Bootstrap (namespaces, search attributes, validation)
echo ""
echo "--- Phase 1: Bootstrap ---"
sh "${INIT_DIR}/create-namespaces.sh"
sh "${INIT_DIR}/setup-search-attributes.sh"

if ! sh "${INIT_DIR}/validate.sh"; then
    echo "WARNING: validate.sh reported failures (continuing)" >&2
fi

# Phase 2: Worker version promotion
echo ""
echo "--- Phase 2: Worker version promotion ---"
sh "${INIT_DIR}/promote-worker-version.sh"

echo "=========================================="
echo "Temporal post-deploy complete"
echo "=========================================="
