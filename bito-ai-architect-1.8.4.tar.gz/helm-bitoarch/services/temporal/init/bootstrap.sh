#!/bin/sh
#
# One-shot bootstrap orchestrator for Temporal in Kubernetes.
# Runs as a Helm post-install/post-upgrade Job.
#
# Order:
#   1. create-namespaces.sh       (idempotent)
#   2. setup-search-attributes.sh (idempotent)
#   3. validate.sh                (non-fatal on failure)
#
set -eu

INIT_DIR="$(cd "$(dirname "$0")" && pwd)"

: "${TEMPORAL_ADDRESS:=ai-architect-temporal:7233}"
: "${NAMESPACE:=${DEFAULT_NAMESPACE:-cis-onprem}}"
: "${NAMESPACES:=default ${NAMESPACE}}"

export TEMPORAL_ADDRESS NAMESPACE NAMESPACES

echo "=========================================="
echo "Temporal bootstrap starting"
echo "  address:   ${TEMPORAL_ADDRESS}"
echo "  namespace: ${NAMESPACE}"
echo "=========================================="

sh "${INIT_DIR}/create-namespaces.sh"
sh "${INIT_DIR}/setup-search-attributes.sh"

if ! sh "${INIT_DIR}/validate.sh"; then
    echo "WARNING: validate.sh reported failures (continuing — bootstrap itself succeeded)" >&2
fi

echo "=========================================="
echo "Temporal bootstrap complete"
echo "=========================================="
