#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
#
# ============================================================================
# Create Dedicated Temporal MySQL User
# ============================================================================
# Parallels Docker MySQL's built-in MYSQL_USER creation mechanism
# (which only supports one additional user). This script creates
# a second user for the Temporal server with privileges limited
# to the temporal and temporal_visibility databases.
#
# Runs on first boot via /docker-entrypoint-initdb.d/

# Exit immediately if any command fails so the caller can detect errors.
set -e

TEMPORAL_USER="${TEMPORAL_MYSQL_USER:-temporal_user}"
TEMPORAL_PASS="${TEMPORAL_MYSQL_PASSWORD:?TEMPORAL_MYSQL_PASSWORD must be set}"

echo "Creating temporal MySQL user '${TEMPORAL_USER}'..."

mysql -u root -p"${MYSQL_ROOT_PASSWORD}" <<-EOSQL
  CREATE DATABASE IF NOT EXISTS \`temporal\`;
  CREATE DATABASE IF NOT EXISTS \`temporal_visibility\`;
  CREATE USER IF NOT EXISTS '${TEMPORAL_USER}'@'%' IDENTIFIED BY '${TEMPORAL_PASS}';
  GRANT ALL PRIVILEGES ON \`temporal\`.* TO '${TEMPORAL_USER}'@'%';
  GRANT ALL PRIVILEGES ON \`temporal_visibility\`.* TO '${TEMPORAL_USER}'@'%';
  FLUSH PRIVILEGES;
EOSQL

echo "Temporal MySQL user '${TEMPORAL_USER}' created successfully"
