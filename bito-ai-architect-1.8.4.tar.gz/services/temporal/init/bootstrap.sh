#!/bin/sh
#
# One-shot bootstrap orchestrator. Runs *inside* the ai-architect-temporal
# container after it becomes healthy. Invoked by scripts/service-manager.sh
# (deploy_temporal) via `docker exec`.
#
# Order:
#   1. create-namespaces.sh       (idempotent)
#   2. setup-search-attributes.sh (idempotent)
#   3. validate.sh                (non-fatal on failure — logged only)
#
# MySQL schema setup is handled by the temporalio/auto-setup image on first
# boot and is NOT invoked here. Run setup-mysql-schema.sh manually if you
# ever switch to a plain temporalio/server image.
#
set -eu

INIT_DIR="$(cd "$(dirname "$0")" && pwd)"

: "${TEMPORAL_ADDRESS:=ai-architect-temporal:7233}"
: "${NAMESPACE:=${DEFAULT_NAMESPACE:-cis-onprem}}"
: "${NAMESPACES:=default ${NAMESPACE}}"

export TEMPORAL_ADDRESS NAMESPACE NAMESPACES

echo "=========================================="
echo "Temporal bootstrap starting"
echo "  address:   ${TEMPORAL_ADDRESS}"
echo "  namespace: ${NAMESPACE}"
echo "=========================================="

sh "${INIT_DIR}/create-namespaces.sh"
sh "${INIT_DIR}/setup-search-attributes.sh"

if ! sh "${INIT_DIR}/validate.sh"; then
    echo "WARNING: validate.sh reported failures (continuing — bootstrap itself succeeded)" >&2
fi

echo "=========================================="
echo "Temporal bootstrap complete"
echo "=========================================="
