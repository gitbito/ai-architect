#!/bin/sh
#
# Ensure required Temporal namespaces exist.
#
# Idempotent: describe-then-create per namespace.
# Default NAMESPACES is tuned for cis-platform on-prem (cis-onprem).
#
set -eu

: "${TEMPORAL_ADDRESS:=ai-architect-temporal:7233}"
: "${NAMESPACES:=default cis-onprem}"

host=$(echo "${TEMPORAL_ADDRESS}" | cut -d: -f1)
port=$(echo "${TEMPORAL_ADDRESS}" | cut -d: -f2)

echo "Waiting for Temporal server port ${host}:${port}..."
nc -z -w 10 "${host}" "${port}"
echo "Temporal server port is available"

echo "Waiting for Temporal server to be healthy..."
max_attempts=12
attempt=0
until temporal operator cluster health --address "${TEMPORAL_ADDRESS}" >/dev/null 2>&1; do
    attempt=$((attempt + 1))
    if [ "${attempt}" -ge "${max_attempts}" ]; then
        echo "ERROR: Temporal did not become healthy after ${max_attempts} attempts" >&2
        exit 1
    fi
    echo "  not ready, retrying in 5s (attempt ${attempt}/${max_attempts})..."
    sleep 5
done
echo "Server is healthy."

for NAMESPACE in ${NAMESPACES}; do
    echo "Ensuring namespace '${NAMESPACE}'..."
    if temporal operator namespace describe -n "${NAMESPACE}" --address "${TEMPORAL_ADDRESS}" >/dev/null 2>&1; then
        echo "  already exists"
    else
        temporal operator namespace create -n "${NAMESPACE}" --address "${TEMPORAL_ADDRESS}"
        echo "  created"
    fi
done

echo "All namespaces ready."
