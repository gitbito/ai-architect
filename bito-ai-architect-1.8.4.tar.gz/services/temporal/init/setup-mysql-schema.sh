#!/bin/sh
#
# Temporal MySQL schema setup.
#
# NOTE: In the default cis-platform deployment we use the temporalio/auto-setup
# image, which runs this same logic internally on first boot. This script is
# kept here for (a) reference parity with the non-selfhosted deployment and
# (b) manual re-runs against an existing MySQL instance if the auto-setup
# container is ever swapped for a plain temporalio/server image.
#
set -eu

: "${MYSQL_SEEDS:=ai-architect-mysql}"
: "${DB_PORT:=3306}"
: "${MYSQL_USER:=temporal_user}"
: "${MYSQL_PWD:?MYSQL_PWD must be set}"

echo "Starting MySQL schema setup..."
echo "Waiting for MySQL port ${MYSQL_SEEDS}:${DB_PORT}..."
nc -z -w 10 "${MYSQL_SEEDS}" "${DB_PORT}"
echo "MySQL port is available"

# Temporal main database
temporal-sql-tool --plugin mysql8 --ep "${MYSQL_SEEDS}" -u "${MYSQL_USER}" --pw "${MYSQL_PWD}" -p "${DB_PORT}" --db temporal create || true
temporal-sql-tool --plugin mysql8 --ep "${MYSQL_SEEDS}" -u "${MYSQL_USER}" --pw "${MYSQL_PWD}" -p "${DB_PORT}" --db temporal setup-schema -v 0.0 || true
temporal-sql-tool --plugin mysql8 --ep "${MYSQL_SEEDS}" -u "${MYSQL_USER}" --pw "${MYSQL_PWD}" -p "${DB_PORT}" --db temporal update-schema -d /etc/temporal/schema/mysql/v8/temporal/versioned

# Temporal visibility database
temporal-sql-tool --plugin mysql8 --ep "${MYSQL_SEEDS}" -u "${MYSQL_USER}" --pw "${MYSQL_PWD}" -p "${DB_PORT}" --db temporal_visibility create || true
temporal-sql-tool --plugin mysql8 --ep "${MYSQL_SEEDS}" -u "${MYSQL_USER}" --pw "${MYSQL_PWD}" -p "${DB_PORT}" --db temporal_visibility setup-schema -v 0.0 || true
temporal-sql-tool --plugin mysql8 --ep "${MYSQL_SEEDS}" -u "${MYSQL_USER}" --pw "${MYSQL_PWD}" -p "${DB_PORT}" --db temporal_visibility update-schema -d /etc/temporal/schema/mysql/v8/visibility/versioned

echo "MySQL schema setup complete"
