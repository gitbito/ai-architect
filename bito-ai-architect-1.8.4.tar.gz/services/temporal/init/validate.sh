#!/bin/sh
#
# Validate a running Temporal deployment:
#   1. Cluster health
#   2. Namespace exists / is accessible
#   3. Workflow start/terminate round-trip (proves frontend+matching wired up)
#
set -eu

: "${TEMPORAL_ADDRESS:=ai-architect-temporal:7233}"
: "${NAMESPACE:=cis-onprem}"

echo "=== Temporal Validation ==="
echo "Address:   ${TEMPORAL_ADDRESS}"
echo "Namespace: ${NAMESPACE}"
echo

echo "=== Cluster health ==="
if out=$(temporal operator cluster health --address "${TEMPORAL_ADDRESS}" 2>&1); then
    echo "✓ healthy"
    echo "${out}"
else
    echo "✗ cluster health failed" >&2
    echo "${out}" >&2
    exit 1
fi

echo
echo "=== Namespace '${NAMESPACE}' ==="
if temporal operator namespace describe --namespace "${NAMESPACE}" --address "${TEMPORAL_ADDRESS}" >/dev/null 2>&1; then
    echo "✓ namespace accessible"
else
    echo "✗ namespace not accessible" >&2
    exit 1
fi

echo
echo "=== Workflow round-trip ==="
WORKFLOW_ID="validation-test-$(date +%s)"
TASK_QUEUE="validation-queue"

temporal workflow start \
    --workflow-id "${WORKFLOW_ID}" \
    --type "NonExistentWorkflow" \
    --task-queue "${TASK_QUEUE}" \
    --namespace "${NAMESPACE}" \
    --address "${TEMPORAL_ADDRESS}" \
    --execution-timeout 10s >/dev/null 2>&1 || true

if temporal workflow describe \
        --workflow-id "${WORKFLOW_ID}" \
        --namespace "${NAMESPACE}" \
        --address "${TEMPORAL_ADDRESS}" >/dev/null 2>&1; then
    echo "✓ workflow created — terminating test workflow"
    temporal workflow terminate \
        --workflow-id "${WORKFLOW_ID}" \
        --namespace "${NAMESPACE}" \
        --address "${TEMPORAL_ADDRESS}" \
        --reason "Validation complete" >/dev/null 2>&1 || true
else
    echo "✗ could not create validation workflow" >&2
    exit 1
fi

echo
echo "=== ✅ All validation checks passed ==="
