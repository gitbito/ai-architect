#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# scripts/lib/insights-prompts.sh — interactive prompts for insights features.

if [ -n "${_BITOARCH_INSIGHTS_PROMPTS_LOADED:-}" ]; then return 0 2>/dev/null || true; fi
_BITOARCH_INSIGHTS_PROMPTS_LOADED=1

ATLASSIAN_API_TOKEN_URL="${ATLASSIAN_API_TOKEN_URL:-https://id.atlassian.com/manage-profile/security/api-tokens}"

# Internal validators. Re-prompt on bad input; bail after 3 attempts.
_insights_validate_url() {
    local v="$1"
    [[ "$v" =~ ^https?://[^[:space:]]+$ ]]
}

_insights_validate_email() {
    local v="$1"
    [[ "$v" =~ ^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$ ]]
}

_insights_validate_uuid() {
    local v="$1"
    [[ "$v" =~ ^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$ ]]
}

# Live credential validation — hit the real API to confirm creds work.
_insights_normalize_jira_url() {
    local url="$1"
    url="${url%/}"
    url="${url%/browse}"
    url="${url%/jira}"
    url=$(echo "$url" | sed 's|/browse/.*$||')
    echo "$url"
}

_insights_validate_jira_creds() {
    local base_url="$1" email="$2" token="$3" host_type="$4"
    local api_path="/rest/api/3/myself"
    [ "$host_type" = "self" ] && api_path="/rest/api/2/myself"
    base_url=$(_insights_normalize_jira_url "$base_url")

    print_info "Validating Jira credentials..."
    local http_code
    if [ "$host_type" = "self" ]; then
        # Self-hosted: try Bearer token (PAT) first, fall back to Basic Auth
        http_code=$(curl -s -o /dev/null -w "%{http_code}" \
            -H "Authorization: Bearer ${token}" \
            --max-time 15 \
            "${base_url}${api_path}" 2>/dev/null)
        if [ "$http_code" != "200" ]; then
            http_code=$(curl -s -o /dev/null -w "%{http_code}" \
                -u "${email}:${token}" \
                --max-time 15 \
                "${base_url}${api_path}" 2>/dev/null)
        fi
    else
        http_code=$(curl -s -o /dev/null -w "%{http_code}" \
            -u "${email}:${token}" \
            --max-time 15 \
            "${base_url}${api_path}" 2>/dev/null)
    fi

    if [ "$http_code" = "200" ]; then
        print_success "Jira credentials validated successfully"
        return 0
    fi

    echo -e "${RED}✗${NC} Jira credential validation failed (HTTP ${http_code})"
    case "$http_code" in
        401) if [ "$host_type" = "self" ]; then
                 echo "  → Invalid credentials. For self-hosted, use a Personal Access Token (PAT)"
                 echo "    or username/password. Check your Jira Server admin settings."
             else
                 echo "  → Invalid API token or email. Verify the email address and"
                 echo "    generate a new token at: ${ATLASSIAN_API_TOKEN_URL}"
             fi ;;
        403) echo "  → Token lacks required permissions. Ensure the account has project access." ;;
        404) echo "  → Base URL may be incorrect. Check the URL matches your instance." ;;
        000) echo "  → Could not connect. Check the URL and network/proxy settings." ;;
        *)   echo "  → Unexpected error. Verify URL, email, and token." ;;
    esac
    return 1
}

_insights_fetch_jira_projects() {
    local base_url email="$2" token="$3" host_type="$4"
    base_url=$(_insights_normalize_jira_url "$1")
    local api_path="/rest/api/3/project/search?maxResults=50&orderBy=key"
    [ "$host_type" = "self" ] && api_path="/rest/api/2/project"

    local response
    if [ "$host_type" = "self" ]; then
        response=$(curl -s \
            -H "Authorization: Bearer ${token}" \
            --max-time 15 \
            "${base_url}${api_path}" 2>/dev/null)
        if [ -z "$response" ] || echo "$response" | jq -e '.errorMessages? // empty' >/dev/null 2>&1; then
            response=$(curl -s \
                -u "${email}:${token}" \
                --max-time 15 \
                "${base_url}${api_path}" 2>/dev/null)
        fi
    else
        response=$(curl -s \
            -u "${email}:${token}" \
            --max-time 15 \
            "${base_url}${api_path}" 2>/dev/null)
    fi
    if [ -z "$response" ]; then
        log_silent "insights: project fetch failed (empty response from ${base_url})"
        return 1
    fi

    local projects_json total_projects=""
    if [ "$host_type" = "self" ]; then
        projects_json="$response"
    else
        total_projects=$(echo "$response" | jq -r '.total // empty' 2>/dev/null)
        projects_json=$(echo "$response" | jq '.values // empty' 2>/dev/null)
    fi
    if [ -z "$projects_json" ]; then
        log_silent "insights: Jira project fetch returned no projects"
        return 1
    fi

    if [ -n "$total_projects" ] && [ "$total_projects" -gt 50 ] 2>/dev/null; then
        print_info "Showing 50 of ${total_projects} projects. Use ${YELLOW}bitoarch insights tracker-projects add KEY${NC} for projects not listed."
    fi

    echo "$projects_json" | jq -r '.[] | "\(.key)|\(.name)"' 2>/dev/null
}

# Displays a numbered list of Jira projects and handles interactive selection.
# Reads KEY|Name lines from stdin; outputs comma-separated selected keys.
# $1 = comma-separated currently-configured keys (marked with * in list).
_insights_select_jira_projects() {
    local current_keys="${1:-}"
    local _project_list
    _project_list=$(cat)
    [ -z "$_project_list" ] && return 1

    # Display goes to stderr so stdout is reserved for the result (captured by caller).
    echo "" >&2
    echo "Available projects:" >&2
    local _idx=0
    local -a _keys=() _names=()
    while IFS='|' read -r _key _name; do
        [ -z "$_key" ] && continue
        _idx=$((_idx + 1))
        _keys+=("$_key")
        _names+=("$_name")
        local _marker="  "
        if [ -n "$current_keys" ] && echo ",$current_keys," | grep -q ",$_key,"; then
            _marker="* "
        fi
        printf "  %s%3d) %-12s %s\n" "$_marker" "$_idx" "$_key" "$_name" >&2
    done <<< "$_project_list"
    [ -n "$current_keys" ] && echo "  (* = currently selected)" >&2

    echo "" >&2
    echo "Enter projects which you want to index (comma/space separated, e.g. 1,3,5 or 1-4 or 'all')" >&2
    echo "  Press Enter to keep current selection (or skip if none configured)." >&2
    local _selection=""
    read -r -p "  > " _selection < /dev/tty

    if [ -z "$_selection" ]; then
        echo "$current_keys"
        return 0
    fi

    local _selected_keys=""
    if [ "$_selection" = "all" ]; then
        _selected_keys=$(printf '%s,' "${_keys[@]}")
    else
        local _nums
        _nums=$(echo "$_selection" | tr ',' ' ' | tr -s ' ')
        for _item in $_nums; do
            if [[ "$_item" =~ ^([0-9]+)-([0-9]+)$ ]]; then
                local _from="${BASH_REMATCH[1]}" _to="${BASH_REMATCH[2]}"
                if [ "$_from" -gt "$_to" ]; then local _swap="$_from"; _from="$_to"; _to="$_swap"; fi
                for (( _n=_from; _n<=_to; _n++ )); do
                    [ "$_n" -ge 1 ] && [ "$_n" -le "${#_keys[@]}" ] && \
                        _selected_keys="${_selected_keys}${_keys[$((_n-1))]},"
                done
            elif [[ "$_item" =~ ^[0-9]+$ ]] && [ "$_item" -ge 1 ] && [ "$_item" -le "${#_keys[@]}" ]; then
                _selected_keys="${_selected_keys}${_keys[$((_item-1))]},"
            fi
        done
    fi
    _selected_keys="${_selected_keys%,}"
    echo "$_selected_keys"
}

_insights_validate_confluence_creds() {
    local base_url="$1" email="$2" token="$3"
    base_url="${base_url%/}"
    base_url="${base_url%/wiki}"

    print_info "Validating Confluence credentials..."
    local http_code
    http_code=$(curl -s -o /dev/null -w "%{http_code}" \
        -u "${email}:${token}" \
        --max-time 15 \
        "${base_url}/wiki/api/v2/spaces" 2>/dev/null)

    if [ "$http_code" = "200" ]; then
        print_success "Confluence credentials validated successfully"
        return 0
    fi

    echo -e "${RED}✗${NC} Confluence credential validation failed (HTTP ${http_code})"
    case "$http_code" in
        401|404) echo "  → Invalid API token, email, or URL. Verify the email address and URL,"
             echo "    and generate a new token at: ${ATLASSIAN_API_TOKEN_URL}" ;;
        403) echo "  → Token lacks Confluence access. Ensure the account has Confluence permissions." ;;
        000) echo "  → Could not connect. Check the URL and network/proxy settings." ;;
        *)   echo "  → Unexpected error. Verify URL, email, and token." ;;
    esac
    return 1
}

ask_git_insights_enabled() {
    if [ -n "${INSIGHTS_GIT_ENABLED:-}" ]; then
        return 0
    fi
    if [[ "${AUTO_SETUP:-}" == "true" ]] || [ ! -t 0 ]; then
        INSIGHTS_GIT_ENABLED="false"; export INSIGHTS_GIT_ENABLED; return 0
    fi
    echo ""
    echo -e "See documentation: ${BLUE}https://docs.bito.ai/ai-architect/installation/install-ai-architect-self-hosted#insights${NC}"
    echo ""
    echo -e "${BLUE}=== Git Insights (optional) ===${NC}"
    echo -e "Analyzes commit history to surface engineering activity insights."
    local ans=""
    read -r -p "Enable Git Insights? [Y/n]: " ans
    if [[ "$ans" =~ ^[Nn]$ ]]; then
        INSIGHTS_GIT_ENABLED="false"
    else
        INSIGHTS_GIT_ENABLED="true"
    fi
    export INSIGHTS_GIT_ENABLED
}

# Prompt for Jira project keys when they're missing. Tries the Jira projects API
# first for interactive selection; falls back to manual entry.
# Caller must have INSIGHTS_TICKET_TRACKER_BASE_URL, _EMAIL, _API_TOKEN,
# _HOST_TYPE already set.
_ask_ticket_tracker_project_keys() {
    # Resolve current project keys: yaml file takes precedence, env var as fallback.
    local _current_keys="${INSIGHTS_TICKET_TRACKER_PROJECT_KEYS:-}"
    if type _insights_tp_repo_config_path >/dev/null 2>&1; then
        local _pk_cfg
        _pk_cfg=$(_insights_tp_repo_config_path 2>/dev/null)
        if [ -n "$_pk_cfg" ] && [ -f "$_pk_cfg" ]; then
            local _yaml_keys
            _yaml_keys=$(_insights_tp_read_keys "$_pk_cfg" 2>/dev/null | paste -sd, -)
            [ -n "$_yaml_keys" ] && _current_keys="$_yaml_keys"
        fi
    fi
    [ -n "$_current_keys" ] && return 0
    if [ ! -t 0 ] || [[ "${AUTO_SETUP:-}" == "true" ]]; then
        return 0
    fi

    echo ""
    print_info "Fetching available Jira projects..."
    local _project_list=""
    _project_list=$(_insights_fetch_jira_projects \
        "$INSIGHTS_TICKET_TRACKER_BASE_URL" \
        "$INSIGHTS_TICKET_TRACKER_EMAIL" \
        "$INSIGHTS_TICKET_TRACKER_API_TOKEN" \
        "${INSIGHTS_TICKET_TRACKER_HOST_TYPE:-cloud}" 2>/dev/null) || true

    if [ -n "$_project_list" ]; then
        local _project_count
        _project_count=$(echo "$_project_list" | wc -l | tr -d ' ')
        print_info "Found ${_project_count} projects accessible with your Jira credentials."
        local _selected=""
        _selected=$(echo "$_project_list" | _insights_select_jira_projects "$_current_keys")
        INSIGHTS_TICKET_TRACKER_PROJECT_KEYS="$_selected"
    else
        echo -e "${YELLOW}⚠${NC}  Could not fetch project list from Jira. Falling back to manual entry."
        echo "Jira project keys to analyze (comma-separated, e.g. PROJ,INFRA)"
        echo "  Press Enter to skip and configure later."
        local _pk_raw=""
        local _pk_attempts=0
        while true; do
            read -r -p "  Project keys: " _pk_raw
            local _normalized=""
            _normalized=$(echo "$_pk_raw" | tr ',' '\n' | awk 'NF{gsub(/^ +| +$/,""); print}' | paste -sd, -)
            if [ -z "$_normalized" ]; then
                INSIGHTS_TICKET_TRACKER_PROJECT_KEYS=""
                break
            fi
            local _bad=""
            local _k
            for _k in $(echo "$_normalized" | tr ',' ' '); do
                if [[ ! "$_k" =~ ^[A-Z][A-Z0-9_]+$ ]]; then
                    _bad="$_k"
                    break
                fi
            done
            if [ -z "$_bad" ]; then
                INSIGHTS_TICKET_TRACKER_PROJECT_KEYS="$_normalized"
                break
            fi
            echo -e "${RED}✗${NC} \"$_bad\" doesn't look like a Jira project key (uppercase letters, digits, underscores)"
            _pk_attempts=$((_pk_attempts+1))
            [ "$_pk_attempts" -ge 3 ] && { print_error "Too many invalid attempts; aborting"; return 1; }
        done
    fi
    export INSIGHTS_TICKET_TRACKER_PROJECT_KEYS

    if [ -n "${INSIGHTS_TICKET_TRACKER_PROJECT_KEYS:-}" ]; then
        local _count
        _count=$(echo "$INSIGHTS_TICKET_TRACKER_PROJECT_KEYS" | awk -F, '{print NF}')
        print_info "Captured ${_count} project key(s); will be applied when services start."
    else
        print_info "No project keys configured. Add them later with:"
        echo -e "  ${YELLOW}bitoarch insights tracker-projects add KEY1 [KEY2 …]${NC}"
        echo -e "  ${YELLOW}bitoarch insights discover-tracker-projects${NC}  (list available projects)"
    fi
}

ask_ticket_tracker_config() {
    if [ -n "${INSIGHTS_TICKET_TRACKER_ENABLED:-}" ]; then
        if [ "${INSIGHTS_TICKET_TRACKER_ENABLED}" = "true" ] \
           && [ -t 0 ] && [[ "${AUTO_SETUP:-}" != "true" ]]; then
            if [ -n "${INSIGHTS_TICKET_TRACKER_BASE_URL:-}" ] \
               && [ -n "${INSIGHTS_TICKET_TRACKER_EMAIL:-}" ] \
               && [ -n "${INSIGHTS_TICKET_TRACKER_API_TOKEN:-}" ]; then
                if ! _insights_validate_jira_creds "$INSIGHTS_TICKET_TRACKER_BASE_URL" \
                        "$INSIGHTS_TICKET_TRACKER_EMAIL" "$INSIGHTS_TICKET_TRACKER_API_TOKEN" \
                        "${INSIGHTS_TICKET_TRACKER_HOST_TYPE:-cloud}"; then
                    local _retry=""
                    read -r -p "Existing Jira credentials failed validation. Re-enter? [Y/n]: " _retry
                    if [[ ! "$_retry" =~ ^[Nn]$ ]]; then
                        unset INSIGHTS_TICKET_TRACKER_ENABLED
                        ask_ticket_tracker_config
                        return $?
                    fi
                    echo -e "${YELLOW}⚠${NC}  Proceeding with unvalidated credentials. Update later with: ${YELLOW}bitoarch insights update-ticket-tracker${NC}"
                fi
                _ask_ticket_tracker_project_keys
                return 0
            fi
            echo -e "\n${YELLOW}⚠${NC}  Ticket Tracker enabled but credentials incomplete — prompting now."
        else
            return 0
        fi
    fi

    # Non-interactive / AUTO_SETUP: enable if pre-filled, else disable
    if [ ! -t 0 ] || [[ "${AUTO_SETUP:-}" == "true" ]]; then
        if [ -n "${INSIGHTS_TICKET_TRACKER_BASE_URL:-}" ] && \
           [ -n "${INSIGHTS_TICKET_TRACKER_EMAIL:-}" ] && \
           [ -n "${INSIGHTS_TICKET_TRACKER_API_TOKEN:-}" ]; then
            INSIGHTS_TICKET_TRACKER_ENABLED="true"
            INSIGHTS_TICKET_TRACKER_PROVIDER="${INSIGHTS_TICKET_TRACKER_PROVIDER:-jira}"
            INSIGHTS_TICKET_TRACKER_AUTH_TYPE="${INSIGHTS_TICKET_TRACKER_AUTH_TYPE:-api-token}"
            INSIGHTS_TICKET_TRACKER_HOST_TYPE="${INSIGHTS_TICKET_TRACKER_HOST_TYPE:-cloud}"
            export INSIGHTS_TICKET_TRACKER_ENABLED INSIGHTS_TICKET_TRACKER_PROVIDER \
                INSIGHTS_TICKET_TRACKER_AUTH_TYPE INSIGHTS_TICKET_TRACKER_BASE_URL \
                INSIGHTS_TICKET_TRACKER_EMAIL \
                INSIGHTS_TICKET_TRACKER_API_TOKEN INSIGHTS_TICKET_TRACKER_HOST_TYPE \
                INSIGHTS_TICKET_TRACKER_CLOUD_ID INSIGHTS_TICKET_TRACKER_PROJECT_KEYS
            return 0
        fi
        INSIGHTS_TICKET_TRACKER_ENABLED="false"
        export INSIGHTS_TICKET_TRACKER_ENABLED
        return 0
    fi

    if [[ "${_INSIGHTS_SKIP_ENABLE_PROMPT:-}" != "1" ]] && [ "${INSIGHTS_TICKET_TRACKER_ENABLED:-}" != "true" ]; then
        echo ""
        echo -e "${BLUE}=== Ticket Tracker Insights (optional) ===${NC}"
        echo -e "Links Jira ticket activity to engineering work for richer insights."
        local ans=""
        read -r -p "Enable Ticket Tracker Insights? [Y/n]: " ans
        if [[ "$ans" =~ ^[Nn]$ ]]; then
            INSIGHTS_TICKET_TRACKER_ENABLED="false"
            export INSIGHTS_TICKET_TRACKER_ENABLED
            return 0
        fi
    fi

    INSIGHTS_TICKET_TRACKER_ENABLED="true"
    INSIGHTS_TICKET_TRACKER_PROVIDER="${INSIGHTS_TICKET_TRACKER_PROVIDER:-jira}"
    INSIGHTS_TICKET_TRACKER_AUTH_TYPE="${INSIGHTS_TICKET_TRACKER_AUTH_TYPE:-api-token}"

    # Show existing values as defaults (press Enter to keep).
    local _cur_url="${INSIGHTS_TICKET_TRACKER_BASE_URL:-}"
    local _cur_email="${INSIGHTS_TICKET_TRACKER_EMAIL:-}"
    local _cur_host="${INSIGHTS_TICKET_TRACKER_HOST_TYPE:-}"
    local _cur_cloud="${INSIGHTS_TICKET_TRACKER_CLOUD_ID:-}"

    local _attempts
    _attempts=0
    while true; do
        local _default_hint=""
        [ -n "$_cur_url" ] && _default_hint=" [${_cur_url}]"
        echo ""
        echo "Atlassian site URL — the URL you visit in the browser"
        echo "  (e.g. https://acme.atlassian.net — NOT the api.atlassian.com/ex/jira/... form)"
        local _input=""
        read -r -p "  URL${_default_hint}: " _input
        [ -z "$_input" ] && [ -n "$_cur_url" ] && _input="$_cur_url"
        if _insights_validate_url "$_input"; then
            INSIGHTS_TICKET_TRACKER_BASE_URL=$(_insights_normalize_jira_url "$_input")
            break
        fi
        echo -e "${RED}✗${NC} URL must look like https://your-tenant.atlassian.net (no spaces)"
        _attempts=$((_attempts+1))
        [ "$_attempts" -ge 3 ] && { print_error "Too many invalid attempts; aborting"; return 1; }
    done

    _attempts=0
    while true; do
        local _default_hint=""
        [ -n "$_cur_email" ] && _default_hint=" [${_cur_email}]"
        local _input=""
        read -r -p "Email for Jira API${_default_hint}: " _input
        [ -z "$_input" ] && [ -n "$_cur_email" ] && _input="$_cur_email"
        if _insights_validate_email "$_input"; then
            INSIGHTS_TICKET_TRACKER_EMAIL="$_input"
            break
        fi
        echo -e "${RED}✗${NC} Doesn't look like a valid email address"
        _attempts=$((_attempts+1))
        [ "$_attempts" -ge 3 ] && { print_error "Too many invalid attempts; aborting"; return 1; }
    done

    local _token_hint=""
    [ -n "${INSIGHTS_TICKET_TRACKER_API_TOKEN:-}" ] && _token_hint=" (press Enter to keep current)"
    local _input=""
    read -s -p "Jira API token (input hidden)${_token_hint}: " _input
    echo ""
    [ -n "$_input" ] && INSIGHTS_TICKET_TRACKER_API_TOKEN="$_input"
    _attempts=0
    while [ -z "${INSIGHTS_TICKET_TRACKER_API_TOKEN:-}" ]; do
        read -s -p "Jira API token (input hidden): " INSIGHTS_TICKET_TRACKER_API_TOKEN
        echo ""
        _attempts=$((_attempts+1))
        [ "$_attempts" -ge 3 ] && { print_error "Too many empty attempts; aborting"; return 1; }
    done

    echo ""
    local _host_default_hint=""
    if [ -n "$_cur_host" ]; then
        local _host_num="1"
        [ "$_cur_host" = "self" ] && _host_num="2"
        _host_default_hint=" [${_host_num} = ${_cur_host}]"
    fi
    local host_choice=""
    while [ -z "$host_choice" ]; do
        read -r -p "Host type (1) cloud  (2) self${_host_default_hint}  [1]: " host_choice
        if [ -z "$host_choice" ]; then
            if [ -n "$_cur_host" ]; then
                INSIGHTS_TICKET_TRACKER_HOST_TYPE="$_cur_host"
            else
                INSIGHTS_TICKET_TRACKER_HOST_TYPE="cloud"
            fi
            host_choice="done"
        else
            case "$host_choice" in
                1) INSIGHTS_TICKET_TRACKER_HOST_TYPE="cloud" ;;
                2) INSIGHTS_TICKET_TRACKER_HOST_TYPE="self" ;;
                *) echo -e "${RED}✗${NC} Invalid choice"; host_choice="" ;;
            esac
        fi
    done

    if [ "$INSIGHTS_TICKET_TRACKER_HOST_TYPE" = "self" ] \
       && echo "$INSIGHTS_TICKET_TRACKER_BASE_URL" | grep -qi '\.atlassian\.net'; then
        print_warning "URL looks like Atlassian Cloud (*.atlassian.net) but host type is 'self'."
        local _confirm=""
        read -r -p "  Switch to cloud? [Y/n]: " _confirm
        if [[ ! "$_confirm" =~ ^[Nn]$ ]]; then
            INSIGHTS_TICKET_TRACKER_HOST_TYPE="cloud"
            echo -e "  → Host type set to ${GREEN}cloud${NC}"
        else
            echo -e "${RED}✗${NC} Cloud URL (*.atlassian.net) cannot be used with host type 'self'."
            echo -e "  Change the URL or select host type (1) cloud."
            unset INSIGHTS_TICKET_TRACKER_ENABLED
            ask_ticket_tracker_config
            return $?
        fi
    fi

    if [ "$INSIGHTS_TICKET_TRACKER_HOST_TYPE" = "cloud" ] && [ "$INSIGHTS_TICKET_TRACKER_AUTH_TYPE" != "api-token" ]; then
        _attempts=0
        while true; do
            local _default_hint=""
            [ -n "$_cur_cloud" ] && _default_hint=" [${_cur_cloud}]"
            echo "Cloud ID — UUID only, no URL."
            echo "  Find it by visiting https://${INSIGHTS_TICKET_TRACKER_BASE_URL#*//}/_edge/tenant_info"
            echo "  Copy the \"cloudId\" value (format: 8-4-4-4-12 hex chars)"
            local _input=""
            read -r -p "  Cloud ID${_default_hint}: " _input
            [ -z "$_input" ] && [ -n "$_cur_cloud" ] && _input="$_cur_cloud"
            if _insights_validate_uuid "$_input"; then
                INSIGHTS_TICKET_TRACKER_CLOUD_ID="$_input"
                break
            fi
            echo -e "${RED}✗${NC} Not a valid UUID — expected format 8-4-4-4-12 hex chars (e.g. 88384793-8547-4ed1-adf9-492d6539b990)"
            _attempts=$((_attempts+1))
            [ "$_attempts" -ge 3 ] && { print_error "Too many invalid attempts; aborting"; return 1; }
        done
    fi

    export INSIGHTS_TICKET_TRACKER_ENABLED INSIGHTS_TICKET_TRACKER_PROVIDER \
        INSIGHTS_TICKET_TRACKER_AUTH_TYPE INSIGHTS_TICKET_TRACKER_BASE_URL \
        INSIGHTS_TICKET_TRACKER_EMAIL \
        INSIGHTS_TICKET_TRACKER_API_TOKEN INSIGHTS_TICKET_TRACKER_HOST_TYPE \
        INSIGHTS_TICKET_TRACKER_CLOUD_ID INSIGHTS_TICKET_TRACKER_PROJECT_KEYS

    echo ""
    if ! _insights_validate_jira_creds "$INSIGHTS_TICKET_TRACKER_BASE_URL" \
            "$INSIGHTS_TICKET_TRACKER_EMAIL" "$INSIGHTS_TICKET_TRACKER_API_TOKEN" \
            "$INSIGHTS_TICKET_TRACKER_HOST_TYPE"; then
        local _retry=""
        read -r -p "Credentials failed validation. Retry? [Y/n]: " _retry
        if [[ ! "$_retry" =~ ^[Nn]$ ]]; then
            unset INSIGHTS_TICKET_TRACKER_ENABLED
            ask_ticket_tracker_config
            return $?
        fi
        echo -e "${YELLOW}⚠${NC}  Proceeding with unvalidated credentials. You can update later with: ${YELLOW}bitoarch insights update-ticket-tracker${NC}"
    fi

    # Resolve current project keys: yaml file takes precedence, env var as fallback.
    local _current_keys="${INSIGHTS_TICKET_TRACKER_PROJECT_KEYS:-}"
    if type _insights_tp_repo_config_path >/dev/null 2>&1; then
        local _pk_cfg
        _pk_cfg=$(_insights_tp_repo_config_path 2>/dev/null)
        if [ -n "$_pk_cfg" ] && [ -f "$_pk_cfg" ]; then
            local _yaml_keys
            _yaml_keys=$(_insights_tp_read_keys "$_pk_cfg" 2>/dev/null | paste -sd, -)
            [ -n "$_yaml_keys" ] && _current_keys="$_yaml_keys"
        fi
    fi

    # Fetch accessible Jira projects and let the user pick (mirrors repo selection flow).
    # Falls back to manual entry if the API call fails.
    echo ""
    print_info "Fetching available Jira projects..."
    local _project_list=""
    _project_list=$(_insights_fetch_jira_projects \
        "$INSIGHTS_TICKET_TRACKER_BASE_URL" \
        "$INSIGHTS_TICKET_TRACKER_EMAIL" \
        "$INSIGHTS_TICKET_TRACKER_API_TOKEN" \
        "$INSIGHTS_TICKET_TRACKER_HOST_TYPE" 2>/dev/null) || true

    if [ -n "$_project_list" ]; then
        local _project_count
        _project_count=$(echo "$_project_list" | wc -l | tr -d ' ')
        print_info "Found ${_project_count} projects accessible with your Jira credentials."
        local _selected=""
        _selected=$(echo "$_project_list" | _insights_select_jira_projects "$_current_keys")
        INSIGHTS_TICKET_TRACKER_PROJECT_KEYS="$_selected"
    elif [ -z "$_current_keys" ]; then
        echo -e "${YELLOW}⚠${NC}  Could not fetch project list from Jira. Falling back to manual entry."
        echo "Jira project keys to analyze (comma-separated, e.g. PROJ,INFRA)"
        echo "  Press Enter to skip and configure later."
        local _pk_raw=""
        local _pk_attempts=0
        while true; do
            read -r -p "  Project keys: " _pk_raw
            local _normalized=""
            _normalized=$(echo "$_pk_raw" | tr ',' '\n' | awk 'NF{gsub(/^ +| +$/,""); print}' | paste -sd, -)
            if [ -z "$_normalized" ]; then
                INSIGHTS_TICKET_TRACKER_PROJECT_KEYS=""
                break
            fi
            local _bad=""
            local _k
            for _k in $(echo "$_normalized" | tr ',' ' '); do
                if [[ ! "$_k" =~ ^[A-Z][A-Z0-9_]+$ ]]; then
                    _bad="$_k"
                    break
                fi
            done
            if [ -z "$_bad" ]; then
                INSIGHTS_TICKET_TRACKER_PROJECT_KEYS="$_normalized"
                break
            fi
            echo -e "${RED}✗${NC} \"$_bad\" doesn't look like a Jira project key (uppercase letters, digits, underscores)"
            _pk_attempts=$((_pk_attempts+1))
            [ "$_pk_attempts" -ge 3 ] && { print_error "Too many invalid attempts; aborting"; return 1; }
        done
    fi
    export INSIGHTS_TICKET_TRACKER_PROJECT_KEYS

    if [ -n "${INSIGHTS_TICKET_TRACKER_PROJECT_KEYS:-}" ]; then
        local _count
        _count=$(echo "$INSIGHTS_TICKET_TRACKER_PROJECT_KEYS" | awk -F, '{print NF}')
        print_info "Captured ${_count} project key(s); will be applied when services start."
    else
        print_info "No project keys configured. Add them later with:"
        echo -e "  ${YELLOW}bitoarch insights tracker-projects add KEY1 [KEY2 …]${NC}"
        echo -e "  ${YELLOW}bitoarch insights discover-tracker-projects${NC}  (list available projects)"
    fi
}

_ask_lookback_for_feature() {
    local _label="$1" _var="$2"
    local _cur="${!_var:-}"
    local _default="${_cur:-180}"

    # Auto-accept when this feature's lookback is already set,
    # or when running non-interactively. Otherwise prompt.
    if [ -n "$_cur" ] \
       || [ ! -t 0 ] || [[ "${AUTO_SETUP:-}" == "true" ]]; then
        eval "$_var=\"${_default}\""
        export "$_var"
        return 0
    fi

    local _input=""
    read -r -p "${_label} lookback days [${_default}]: " _input
    _input="${_input:-${_default}}"
    if [[ "$_input" =~ ^[0-9]+$ ]] && [ "$_input" -ge 1 ] && [ "$_input" -le 730 ]; then
        eval "$_var=\"$_input\""
    else
        echo -e "${YELLOW}⚠${NC}  Invalid value; using default of 180 days"
        eval "$_var=\"180\""
    fi
    export "$_var"

    if [ -n "$_cur" ] && [ "$_cur" != "${!_var}" ]; then
        echo ""
        print_warning "${_label} lookback changed from ${_cur} to ${!_var} days."
        if [ -z "${_INSIGHTS_SUPPRESS_RUN_HINT:-}" ]; then
            echo -e "  Run ${YELLOW}bitoarch insights run --force${NC} to re-analyze with the new window."
        fi
    fi
}

ask_insights_lookback_days() {
    # Only prompt when at least one insights feature is being enabled.
    if [ "${INSIGHTS_GIT_ENABLED:-}" != "true" ] && \
       [ "${INSIGHTS_TICKET_TRACKER_ENABLED:-}" != "true" ]; then
        return 0
    fi

    echo ""
    echo -e "${BLUE}=== Insights Lookback Period ===${NC}"
    echo -e "Number of days of history to analyze."

    if [ "${INSIGHTS_GIT_ENABLED:-}" = "true" ]; then
        _ask_lookback_for_feature "Git" "INSIGHTS_GIT_LOOKBACK_DAYS"
    fi
    if [ "${INSIGHTS_TICKET_TRACKER_ENABLED:-}" = "true" ]; then
        _ask_lookback_for_feature "Jira" "INSIGHTS_JIRA_LOOKBACK_DAYS"
    fi
}

ask_docs_config() {
    if [ -n "${INSIGHTS_DOCS_ENABLED:-}" ]; then
        if [ "${INSIGHTS_DOCS_ENABLED}" = "true" ] \
           && [ -t 0 ] && [[ "${AUTO_SETUP:-}" != "true" ]]; then
            if [ -n "${INSIGHTS_DOCS_URL:-}" ] \
               && [ -n "${INSIGHTS_DOCS_EMAIL:-}" ] \
               && [ -n "${INSIGHTS_DOCS_API_TOKEN:-}" ]; then
                if ! _insights_validate_confluence_creds "$INSIGHTS_DOCS_URL" \
                        "$INSIGHTS_DOCS_EMAIL" "$INSIGHTS_DOCS_API_TOKEN"; then
                    local _retry=""
                    read -r -p "Existing Confluence credentials failed validation. Re-enter? [Y/n]: " _retry
                    if [[ ! "$_retry" =~ ^[Nn]$ ]]; then
                        unset INSIGHTS_DOCS_ENABLED
                        ask_docs_config
                        return $?
                    fi
                    echo -e "${YELLOW}⚠${NC}  Proceeding with unvalidated credentials. Update later with: ${YELLOW}bitoarch insights update-doc-config${NC}"
                fi
                return 0
            fi
            echo -e "\n${YELLOW}⚠${NC}  Docs enabled but credentials incomplete — prompting now."
        else
            return 0
        fi
    fi
    if [[ "${_INSIGHTS_SKIP_ENABLE_PROMPT:-}" != "1" ]] && [ "${INSIGHTS_TICKET_TRACKER_ENABLED:-}" != "true" ]; then
        INSIGHTS_DOCS_ENABLED="false"
        export INSIGHTS_DOCS_ENABLED
        [ -t 0 ] && echo -e "\n${BLUE}ℹ${NC}  Skipping docs setup — requires ticket tracker to be enabled first."
        return 0
    fi

    # Non-interactive / AUTO_SETUP: accept pre-filled values or skip
    if [ ! -t 0 ] || [[ "${AUTO_SETUP:-}" == "true" ]]; then
        if [ -n "${INSIGHTS_DOCS_URL:-}" ] && \
           [ -n "${INSIGHTS_DOCS_EMAIL:-}" ] && \
           [ -n "${INSIGHTS_DOCS_API_TOKEN:-}" ]; then
            INSIGHTS_DOCS_ENABLED="true"
            INSIGHTS_DOCS_PROVIDER="${INSIGHTS_DOCS_PROVIDER:-confluence}"
            INSIGHTS_DOCS_AUTH_TYPE="${INSIGHTS_DOCS_AUTH_TYPE:-api-token}"
            export INSIGHTS_DOCS_ENABLED INSIGHTS_DOCS_PROVIDER INSIGHTS_DOCS_AUTH_TYPE \
                INSIGHTS_DOCS_URL INSIGHTS_DOCS_EMAIL INSIGHTS_DOCS_API_TOKEN INSIGHTS_DOCS_CLOUD_ID
            return 0
        fi
        INSIGHTS_DOCS_ENABLED="false"
        export INSIGHTS_DOCS_ENABLED
        return 0
    fi

    if [[ "${_INSIGHTS_SKIP_ENABLE_PROMPT:-}" != "1" ]] && [ "${INSIGHTS_DOCS_ENABLED:-}" != "true" ]; then
        echo ""
        echo -e "${BLUE}=== Confluence Docs (optional) ===${NC}"
        echo -e "Adds Confluence as docs source for richer ticket-link context."
        local ans=""
        read -r -p "Enable Confluence integration? [Y/n]: " ans
        if [[ "$ans" =~ ^[Nn]$ ]]; then
            INSIGHTS_DOCS_ENABLED="false"
            export INSIGHTS_DOCS_ENABLED
            return 0
        fi
    fi

    INSIGHTS_DOCS_ENABLED="true"
    INSIGHTS_DOCS_PROVIDER="${INSIGHTS_DOCS_PROVIDER:-confluence}"
    INSIGHTS_DOCS_AUTH_TYPE="${INSIGHTS_DOCS_AUTH_TYPE:-api-token}"

    local default_url="${INSIGHTS_DOCS_URL:-${INSIGHTS_TICKET_TRACKER_BASE_URL%/}}"
    local _cur_email="${INSIGHTS_DOCS_EMAIL:-${INSIGHTS_TICKET_TRACKER_EMAIL}}"
    local _cur_cloud="${INSIGHTS_DOCS_CLOUD_ID:-${INSIGHTS_TICKET_TRACKER_CLOUD_ID}}"

    echo ""
    local _attempts=0
    while true; do
        local _input=""
        read -r -p "Confluence URL [${default_url}]: " _input
        _input="${_input:-$default_url}"
        if _insights_validate_url "$_input"; then
            INSIGHTS_DOCS_URL="${_input%/}"
            INSIGHTS_DOCS_URL="${INSIGHTS_DOCS_URL%/wiki}"
            break
        fi
        echo -e "${RED}✗${NC} URL must look like https://your-tenant.atlassian.net (with or without /wiki — we normalize)"
        _attempts=$((_attempts+1))
        [ "$_attempts" -ge 3 ] && { print_error "Too many invalid attempts; aborting"; return 1; }
    done

    _attempts=0
    while true; do
        local _input=""
        read -r -p "Confluence email [${_cur_email}]: " _input
        _input="${_input:-$_cur_email}"
        if _insights_validate_email "$_input"; then
            INSIGHTS_DOCS_EMAIL="$_input"
            break
        fi
        echo -e "${RED}✗${NC} Doesn't look like a valid email address"
        _attempts=$((_attempts+1))
        [ "$_attempts" -ge 3 ] && { print_error "Too many invalid attempts; aborting"; return 1; }
    done

    local _token_hint=""
    [ -n "${INSIGHTS_DOCS_API_TOKEN:-}" ] && _token_hint=" (press Enter to keep current)"
    local _input=""
    read -s -p "Confluence API token (input hidden)${_token_hint}: " _input
    echo ""
    [ -n "$_input" ] && INSIGHTS_DOCS_API_TOKEN="$_input"
    _attempts=0
    while [ -z "${INSIGHTS_DOCS_API_TOKEN:-}" ]; do
        read -s -p "Confluence API token (input hidden): " INSIGHTS_DOCS_API_TOKEN
        echo ""
        _attempts=$((_attempts+1))
        [ "$_attempts" -ge 3 ] && { print_error "Too many empty attempts; aborting"; return 1; }
    done

    if [ "$INSIGHTS_DOCS_AUTH_TYPE" != "api-token" ]; then
        _attempts=0
        while true; do
            local _input=""
            read -r -p "Cloud ID [${_cur_cloud}] (UUID only, no URL): " _input
            _input="${_input:-$_cur_cloud}"
            if _insights_validate_uuid "$_input"; then
                INSIGHTS_DOCS_CLOUD_ID="$_input"
                break
            fi
            echo -e "${RED}✗${NC} Not a valid UUID — expected format 8-4-4-4-12 hex chars"
            _attempts=$((_attempts+1))
            [ "$_attempts" -ge 3 ] && { print_error "Too many invalid attempts; aborting"; return 1; }
        done
    fi

    export INSIGHTS_DOCS_ENABLED INSIGHTS_DOCS_PROVIDER INSIGHTS_DOCS_AUTH_TYPE \
        INSIGHTS_DOCS_URL INSIGHTS_DOCS_EMAIL INSIGHTS_DOCS_API_TOKEN INSIGHTS_DOCS_CLOUD_ID

    echo ""
    if ! _insights_validate_confluence_creds "$INSIGHTS_DOCS_URL" \
            "$INSIGHTS_DOCS_EMAIL" "$INSIGHTS_DOCS_API_TOKEN"; then
        local _retry=""
        read -r -p "Credentials failed validation. Retry? [Y/n]: " _retry
        if [[ ! "$_retry" =~ ^[Nn]$ ]]; then
            unset INSIGHTS_DOCS_ENABLED
            ask_docs_config
            return $?
        fi
        echo -e "${YELLOW}⚠${NC}  Proceeding with unvalidated credentials. You can update later with: ${YELLOW}bitoarch insights update-doc-config${NC}"
    fi
}

export -f _insights_normalize_jira_url
export -f _insights_fetch_jira_projects
export -f _insights_select_jira_projects
export -f ask_git_insights_enabled
export -f ask_ticket_tracker_config
export -f _ask_lookback_for_feature
export -f ask_insights_lookback_days
export -f ask_docs_config
