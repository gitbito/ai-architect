#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
#
# scripts/lib/install.sh
# -----------------------------------------------------------------------------
# install_run: edition-neutral install entry called by the CDN bootstraps
# (scripts/bitoarch-install.sh, scripts/bitoarch-install-standalone.sh).
#
#   - Applies $HOME/.bitoarch/install.yaml to env (seeded from install.yaml.default).
#   - Sources setup.sh and calls main "$@".
#   - On return, persists SKIP_SSO_PROMPT / AUTO_GENERATE_MCP_TOKEN /
#     COMPACT_INSTALL_PROGRESS to .env-bitoarch iff the caller set them true.
#   - Writes yaml back from env on rc=0.
# -----------------------------------------------------------------------------

if [ -n "${_BITOARCH_INSTALL_LIB_LOADED:-}" ]; then
    return 0
fi
_BITOARCH_INSTALL_LIB_LOADED=1

if [ -z "${SCRIPT_DIR:-}" ]; then
    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
fi
PLATFORM_DIR="${PLATFORM_DIR:-${SCRIPT_DIR}}"

# Deps are guarded with -f because bitoarch.sh's `restart --force` sources
# this file with SCRIPT_DIR pointing at scripts/, not repo root.
if [ -f "${SCRIPT_DIR}/scripts/setup-utils.sh" ]; then
    # shellcheck disable=SC1091
    source "${SCRIPT_DIR}/scripts/setup-utils.sh"
fi
if [ -f "${SCRIPT_DIR}/scripts/lib/cli-core.sh" ]; then
    # shellcheck disable=SC1091
    source "${SCRIPT_DIR}/scripts/lib/cli-core.sh"
fi
if [ -f "${SCRIPT_DIR}/scripts/lib/path-manager.sh" ]; then
    # shellcheck disable=SC1091
    source "${SCRIPT_DIR}/scripts/lib/path-manager.sh"
fi
if [ -f "${SCRIPT_DIR}/scripts/lib/install-yaml.sh" ]; then
    # shellcheck disable=SC1091
    source "${SCRIPT_DIR}/scripts/lib/install-yaml.sh"
elif [ -f "$(dirname "${BASH_SOURCE[0]}")/install-yaml.sh" ]; then
    # shellcheck disable=SC1091
    source "$(dirname "${BASH_SOURCE[0]}")/install-yaml.sh"
fi
if [ -f "${SCRIPT_DIR}/scripts/lib/mcp-installer.sh" ]; then
    # shellcheck disable=SC1091
    source "${SCRIPT_DIR}/scripts/lib/mcp-installer.sh"
fi
if [ -f "${SCRIPT_DIR}/scripts/lib/mcp-cert.sh" ]; then
    # shellcheck disable=SC1091
    source "${SCRIPT_DIR}/scripts/lib/mcp-cert.sh"
fi
if [ -f "${SCRIPT_DIR}/scripts/lib/node-trust.sh" ]; then
    # shellcheck disable=SC1091
    source "${SCRIPT_DIR}/scripts/lib/node-trust.sh"
fi
if [ -f "${SCRIPT_DIR}/scripts/lib/cert-cron.sh" ]; then
    # shellcheck disable=SC1091
    source "${SCRIPT_DIR}/scripts/lib/cert-cron.sh"
fi

# ---------------------------------------------------------------------------
# Insights hooks — called from setup.sh at the appropriate lifecycle points.
# Defined here so the call sites live in install.sh's domain, even though
# setup.sh still controls when they fire (during generate_env_file and after
# add-repos respectively).
# ---------------------------------------------------------------------------

_install_collect_insights_prompts() {
    command -v ask_git_insights_enabled >/dev/null 2>&1 || return 0
    ask_git_insights_enabled
    ask_ticket_tracker_config
    ask_docs_config
    ask_insights_lookback_days
    export INSIGHTS_SETUP_COMPLETE=true
}

_install_push_insights_config() {
    if command -v _config_push_insights_after_add_repos >/dev/null 2>&1; then
        _config_push_insights_after_add_repos
    fi
    # Sync project keys selected during install prompts into .bitoarch-config.yaml
    # so tracker-projects list / discover-tracker-projects stay consistent.
    if [ -n "${INSIGHTS_TICKET_TRACKER_PROJECT_KEYS:-}" ] \
       && command -v _insights_tp_has_yaml_tool >/dev/null 2>&1 \
       && _insights_tp_has_yaml_tool 2>/dev/null; then
        local _cfg=""
        command -v _insights_tp_repo_config_path >/dev/null 2>&1 \
            && _cfg=$(_insights_tp_repo_config_path 2>/dev/null)
        if [ -n "$_cfg" ] && [ -f "$_cfg" ]; then
            echo "${INSIGHTS_TICKET_TRACKER_PROJECT_KEYS}" | tr ',' '\n' \
                | _insights_tp_write_keys "$_cfg" 2>/dev/null || true
        fi
    fi
}

_install_persist_insights_env() {
    if command -v insights_persist_env >/dev/null 2>&1; then
        insights_persist_env "${1:?env_file required}"
    fi
}

# Idempotent: safe to re-invoke. Existing .env-bitoarch skips credential
# prompts and triggers a re-deploy.
install_run() {
    local yaml_config
    yaml_config="$(get_install_yaml_file)"
    while [ $# -gt 0 ]; do
        case "$1" in
            --config)    yaml_config="$2"; shift 2 ;;
            --config=*)  yaml_config="${1#--config=}"; shift ;;
            *)           shift ;;
        esac
    done

    _install_ensure_yaml_exists "$yaml_config"
    _install_apply_yaml_if_present "$yaml_config"

    # Standalone defaults: opt into HTTPS MCP transport + auto-register with
    # coding agents unless install.yaml / env explicitly overrides. SKIP_SSO_PROMPT
    # is the Standalone-mode discriminator set by bitoarch-install-standalone.sh.
    if [ "${SKIP_SSO_PROMPT:-false}" = "true" ]; then
        : "${MCP_TRANSPORT:=https}"
        : "${MCP_AUTO_INSTALL:=true}"
        export MCP_TRANSPORT MCP_AUTO_INSTALL
    fi

    # Pre-compose-up cert provisioning. Self-gates on MCP_TRANSPORT=https so
    # Enterprise installs are unaffected (HOST_MCP_CERT_DIR stays unset, compose
    # uses its default mount). Without this, the first docker-compose-up in
    # setup.sh's main runs without HOST_MCP_CERT_DIR + XMCP_INTERNAL_PORT, the
    # provider mounts an empty cert dir and crashes with EACCES on /opt/certs.
    if command -v mcp_cert_prepare_for_compose >/dev/null 2>&1; then
        mcp_cert_prepare_for_compose >/dev/null 2>&1 || true
    fi

    # shellcheck disable=SC1091
    source "${SCRIPT_DIR}/setup.sh"

    main "$@"
    local rc=$?

    # Coding-agent auto-registration runs only after a successful install
    # (services up + .env-bitoarch finalised). mcp_installer_run is itself
    # gated on MCP_AUTO_INSTALL + MCP_USER_EMAIL, so it is a no-op on
    # Enterprise / opt-out paths.
    if [ "$rc" -eq 0 ] && command -v mcp_installer_run >/dev/null 2>&1; then
        mcp_installer_run || true
    fi

    if [ "$rc" -eq 0 ] && command -v node_trust_install >/dev/null 2>&1; then
        node_trust_install || true
    fi

    if [ "$rc" -eq 0 ] && command -v cert_cron_install >/dev/null 2>&1; then
        cert_cron_install || true
    fi

    # Persist on any rc so a partial install still carries markers for
    # `bitoarch --help` gating.
    local env_file
    env_file=$(get_config_file 2>/dev/null)
    if [ -n "$env_file" ] && [ -f "$env_file" ]; then
        local flag
        for flag in SKIP_SSO_PROMPT AUTO_GENERATE_MCP_TOKEN COMPACT_INSTALL_PROGRESS; do
            [ "${!flag:-}" = "true" ] || continue
            grep -q "^${flag}=" "$env_file" 2>/dev/null || \
                echo "${flag}=true" >> "$env_file"
        done
    fi
    # Partial-prompt runs may leave stale env -- only write yaml on rc=0.
    if [ "$rc" -eq 0 ]; then
        _install_persist_yaml_from_env "$yaml_config"
    fi
    return "$rc"
}
