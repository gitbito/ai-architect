#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai

# Source centralized output rendering system
SETUP_UTILS_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [ -f "${SETUP_UTILS_DIR}/lib/output-blocks.sh" ]; then
    source "${SETUP_UTILS_DIR}/lib/output-blocks.sh"
elif [ -f "$(dirname "$SETUP_UTILS_DIR")/scripts/lib/output-blocks.sh" ]; then
    source "$(dirname "$SETUP_UTILS_DIR")/scripts/lib/output-blocks.sh"
fi

# Set default LOG_FILE if not already set (ensures logging always works)
# This is needed when setup-utils.sh is sourced early by path-manager.sh
if [ -z "$LOG_FILE" ]; then
    # Create a temporary log in the script's var/logs directory
    LOG_FILE="${SETUP_UTILS_DIR}/var/logs/setup.log"
    mkdir -p "$(dirname "$LOG_FILE")" 2>/dev/null || true
fi

# Logging function - always log to file, customer-friendly output to console
log() {
    echo "[$(date +'%Y-%m-%d %H:%M:%S')] $1" >> "$LOG_FILE" 2>&1
}

# Silent log - only to file, not to console (for technical details)
log_silent() {
    echo "[$(date +'%Y-%m-%d %H:%M:%S')] $1" >> "$LOG_FILE" 2>&1
}

print_command() {
    echo -e "${YELLOW}  →${NC} ${BLUE}$1${NC}"
    log "COMMAND: $1"
}

generate_secret() {
    # Ensure consistent output format - remove trailing newlines from both paths
    (openssl rand -base64 32 2>/dev/null || head -c 32 /dev/urandom | base64) | tr -d '\n'
}

generate_encryption_key() {
    # Generate 32 random bytes and encode as URL-safe base64 without padding
    # This follows the same logic as the Go implementation:
    # - 32 bytes (256-bit key)
    # - RawURLEncoding: URL-safe characters, no padding
    #
    # Pipe binary straight into base64 — never via a shell variable. Bash
    # command substitution strips NUL bytes (and Bash >=4.4 warns), which
    # would silently corrupt the key.
    if command -v openssl >/dev/null 2>&1; then
        openssl rand 32 2>/dev/null | base64 | tr '+/' '-_' | tr -d '=\n'
    else
        head -c 32 /dev/urandom | base64 | tr '+/' '-_' | tr -d '=\n'
    fi
}

encrypt_secret() {
    local plaintext="$1"
    local encryption_key="$2"
    
    # Check if openssl is available
    if ! command -v openssl >/dev/null 2>&1; then
        echo "Error: openssl is required for encryption" >&2
        return 1
    fi
    
    # Decode the URL-safe base64 encryption key (convert back from RawURLEncoding)
    # Add padding if needed, convert URL-safe chars back to standard base64
    local key_b64=$(echo -n "$encryption_key" | tr '_-' '/+')
    local padding_length=$((4 - ${#key_b64} % 4))
    if [ $padding_length -ne 4 ]; then
        key_b64="${key_b64}$(printf '=%.0s' $(seq 1 $padding_length))"
    fi

    # Create temp files for key and IV.
    # Binary key/IV bytes are written directly into these files — never into a
    # shell variable. Bash command substitution strips NUL bytes (and Bash
    # >=4.4 warns), which would silently corrupt key/IV material.
    local key_file=$(mktemp)
    local iv_file=$(mktemp)

    # Decode the key directly into the temp file
    echo -n "$key_b64" | base64 -d 2>/dev/null > "$key_file"
    if [ ! -s "$key_file" ]; then
        rm -f "$key_file" "$iv_file"
        echo "Error: Failed to decode encryption key" >&2
        return 1
    fi

    # Generate a 16-byte random IV for AES-256-CBC directly into the temp file
    openssl rand 16 2>/dev/null > "$iv_file"
    if [ ! -s "$iv_file" ]; then
        rm -f "$key_file" "$iv_file"
        echo "Error: Failed to generate IV" >&2
        return 1
    fi

    # Encrypt using AES-256-CBC (supported on both macOS and Linux)
    local ciphertext=$(echo -n "$plaintext" | openssl enc -aes-256-cbc -K "$(xxd -p -c 256 "$key_file" | tr -d '\n')" -iv "$(xxd -p -c 256 "$iv_file" | tr -d '\n')" 2>/dev/null | base64 | tr -d '\n')

    # Encode IV as base64 (use as nonce) — read from the file, not from a variable
    local iv_b64=$(base64 < "$iv_file" | tr -d '\n')

    # Clean up temp files
    rm -f "$key_file" "$iv_file"

    if [ -z "$ciphertext" ]; then
        echo "Error: Encryption failed" >&2
        return 1
    fi

    # Return in the format: enc:v1:<iv_base64>:<ciphertext_base64>
    echo "enc:v1:${iv_b64}:${ciphertext}"
}

# Decrypt a secret encrypted by encrypt_secret()
# Format: enc:v1:<iv_base64>:<ciphertext_base64>
# Returns plaintext on stdout; returns input as-is if not encrypted
decrypt_secret() {
    local encrypted="$1"
    local encryption_key="$2"

    # If not in encrypted format, return as-is
    case "$encrypted" in
        enc:v1:*) ;;
        *) echo "$encrypted"; return 0 ;;
    esac

    # Parse IV and ciphertext
    local iv_b64=$(echo "$encrypted" | cut -d: -f3)
    local ciphertext_b64=$(echo "$encrypted" | cut -d: -f4)

    # Decode encryption key (URL-safe base64 → standard base64)
    local key_b64=$(echo -n "$encryption_key" | tr '_-' '/+')
    local padding_length=$((4 - ${#key_b64} % 4))
    if [ $padding_length -ne 4 ]; then
        key_b64="${key_b64}$(printf '=%.0s' $(seq 1 $padding_length))"
    fi

    # Create temp files for key and IV
    local key_file=$(mktemp)
    local iv_file=$(mktemp)
    echo -n "$key_b64" | base64 -d 2>/dev/null > "$key_file"
    echo -n "$iv_b64" | base64 -d 2>/dev/null > "$iv_file"

    # Convert to hex for openssl
    local key_hex=$(xxd -p -c 256 "$key_file" | tr -d '\n')
    local iv_hex=$(xxd -p -c 256 "$iv_file" | tr -d '\n')

    # Clean up temp files
    rm -f "$key_file" "$iv_file"

    # Decrypt using AES-256-CBC
    local plaintext=$(echo -n "$ciphertext_b64" | base64 -d 2>/dev/null | \
        openssl enc -d -aes-256-cbc -K "$key_hex" -iv "$iv_hex" 2>/dev/null)

    if [ -n "$plaintext" ]; then
        echo "$plaintext"
    else
        echo "Warning: Failed to decrypt secret, passing through as-is" >&2
        echo "$encrypted"
    fi
}

# Decrypt encrypted env vars and export them so docker-compose picks up plaintext values
# Call this on the HOST before docker compose up
# Env vars override env_file values in docker-compose
decrypt_env_secrets() {
    local env_file="$1"

    if [ -z "$env_file" ] || [ ! -f "$env_file" ]; then
        return 0
    fi

    local enc_key=$(grep '^SECRETS_ENCRYPTION_KEY=' "$env_file" | cut -d= -f2-)
    if [ -z "$enc_key" ]; then
        return 0
    fi

    # Decrypt XMCP_SSO_TENANT_KEY if encrypted
    local tenant_key=$(grep '^XMCP_SSO_TENANT_KEY=' "$env_file" | cut -d= -f2-)
    if [ -n "$tenant_key" ]; then
        case "$tenant_key" in
            enc:v1:*)
                local decrypted=$(decrypt_secret "$tenant_key" "$enc_key")
                if [ -n "$decrypted" ] && [ "$decrypted" != "$tenant_key" ]; then
                    export XMCP_SSO_TENANT_KEY="$decrypted"
                fi
                ;;
        esac
    fi
}

is_container_environment() {
    [ -f /.dockerenv ] || grep -q -E 'docker|lxc|containerd' /proc/1/cgroup 2>/dev/null
}

is_arm64_mac() {
    [[ "$OSTYPE" == "darwin"* ]] && [[ "$(uname -m)" == "arm64" ]]
}

# Global state for the async loader. Matches progress_run's output format
# so install/deploy output looks identical to the lifecycle commands:
#   [+] <label> ⠙                   (animated while running)
#   [+] <label> ... ✓ done (Ns)     (final line on stop_loader)
LOADER_PID=""
LOADER_LABEL=""
LOADER_START=0
# "tty"  when we spawned an animated spinner (need to reprint prefix on stop)
# "nontty" when we pre-printed the prefix statically (only append suffix on stop)
LOADER_MODE=""

show_loader() {
    local message="$1"
    LOADER_LABEL="$message"
    LOADER_START=$SECONDS
    # Off a TTY (CI / pipes): print a single static start line, no spinner.
    # Pre-printing the prefix here means stop_loader only appends the suffix
    # ("✓ done (Ns)\n") to the same line.
    if [ ! -t 1 ] || [ "${BITOARCH_NO_SPINNER:-}" = "1" ]; then
        printf '[+] %s ... ' "$message"
        LOADER_PID=""
        LOADER_MODE="nontty"
        return
    fi
    LOADER_MODE="tty"
    (
        while true; do
            for s in '⠋' '⠙' '⠹' '⠸' '⠼' '⠴' '⠦' '⠧' '⠇' '⠏'; do
                printf '\r[+] %s %s' "$message" "$s"
                sleep 0.1
            done
        done
    ) &
    LOADER_PID=$!
}

# stop_loader [rc]
#   Stops the async spinner started by show_loader and emits a final line
#   in the progress_run format:  "[+] <label> ... ✓ done (Ns)" on rc=0,
#   "[+] <label> ... ✗ failed (Ns)" otherwise. No final line is emitted
#   when show_loader wasn't called (safe no-op).
stop_loader() {
    local rc="${1:-0}"
    if [[ -n "$LOADER_PID" ]]; then
        kill "$LOADER_PID" >/dev/null 2>&1
        wait "$LOADER_PID" 2>/dev/null
        LOADER_PID=""
        # Clear the spinner line before printing the final status.
        printf '\r\033[K'
    fi
    if [ -n "$LOADER_LABEL" ]; then
        local elapsed=$((SECONDS - LOADER_START))
        local color end_char
        if [ "$rc" -eq 0 ]; then
            color="${GREEN:-}"; end_char="✓ done"
        else
            color="${RED:-}"; end_char="✗ failed"
        fi
        if [ "$LOADER_MODE" = "nontty" ]; then
            # Prefix was already printed by show_loader; only append suffix.
            if [ "$rc" -eq 0 ]; then
                printf '%b✓%b done (%ds)\n' "${GREEN:-}" "${NC:-}" "$elapsed"
            else
                printf '%b✗%b failed (%ds)\n' "${RED:-}" "${NC:-}" "$elapsed" >&2
            fi
        else
            # TTY: spinner line was cleared above; re-emit the full line.
            if [ "$rc" -eq 0 ]; then
                printf '[+] %s ... %b✓%b done (%ds)\n' \
                    "$LOADER_LABEL" "${GREEN:-}" "${NC:-}" "$elapsed"
            else
                printf '[+] %s ... %b✗%b failed (%ds)\n' \
                    "$LOADER_LABEL" "${RED:-}" "${NC:-}" "$elapsed" >&2
            fi
        fi
        LOADER_LABEL=""
        LOADER_START=0
        LOADER_MODE=""
    fi
}

safe_call() {
    set +e
    "$@"
    local exit_code=$?
    set -e
    return $exit_code
}

################################################################################
# Git Credentials Collection (Shared between setup.sh and CLI)
################################################################################
collect_git_credentials() {
    # This function collects Git credentials matching setup.sh flow exactly
    # Returns: Sets global variables GIT_PROVIDER, GIT_DOMAIN_URL, GIT_USER, GIT_ACCESS_TOKEN
    
    # Note: NOT using 'local' so variables are exported to parent scope
    GIT_PROVIDER=""
    GIT_ACCESS_TOKEN=""
    GIT_DOMAIN_URL=""
    GIT_USER=""
    
    # Git Provider selection
    while [ -z "$GIT_PROVIDER" ]; do
        read -p "Select Git provider (1) GitLab  (2) GitHub  (3) Bitbucket  [1-3]: " git_choice

        case $git_choice in
            1) GIT_PROVIDER="gitlab" ;;
            2) GIT_PROVIDER="github" ;;
            3) GIT_PROVIDER="bitbucket" ;;
            *)
                echo -e "${RED}✗${NC} Invalid choice. Please select 1-3"
                ;;
        esac
    done

    # Enterprise version check 
    echo ""
    read -r -p "Is this an enterprise version of $GIT_PROVIDER (e.g., https://my.company.com)? (y/N):" is_enterprise
    if [[ "$is_enterprise" =~ ^[Yy]$ ]]; then
        while [ -z "$GIT_DOMAIN_URL" ]; do
            read -r -p "Enter domain for enterprise $GIT_PROVIDER: " GIT_DOMAIN_URL
            if [ -z "$GIT_DOMAIN_URL" ]; then
                echo -e "${RED}✗${NC} Git domain is required for enterprise"
            fi
        done
    fi

    # Bitbucket user configuration 
    if [[ "$GIT_PROVIDER" == "bitbucket" ]]; then
        echo ""
        echo -e "🛠 Configuring user authentication..."

        if [[ -z "$GIT_DOMAIN_URL" ]]; then
            # No domain → ask for email
            while [[ -z "$GIT_USER" ]]; do
                read -r -p "Enter your Bitbucket account email: " GIT_USER
                [[ -z "$GIT_USER" ]] && echo "⚠ Email is required. Please try again."
            done
        else
            # Domain exists → ask for username
            while [[ -z "$GIT_USER" ]]; do
                read -r -p "Enter your Bitbucket username: " GIT_USER
                [[ -z "$GIT_USER" ]] && echo "⚠ Username is required. Please try again."
            done
        fi

        echo -e "✅ Bitbucket user set: $GIT_USER"
    fi

    # Git Access Token input 
    while [ -z "$GIT_ACCESS_TOKEN" ]; do
        echo ""
        read -s -p "Enter Git access token (input hidden): " GIT_ACCESS_TOKEN
        if [ -z "$GIT_ACCESS_TOKEN" ]; then
            echo ""  # Newline after hidden input
            echo -e "${RED}✗${NC} Git access token is required"
            echo ""
        fi
    done

    echo ""  # Newline after hidden input
    
    # Print status message 
    print_info "Git provider configured (${GIT_PROVIDER})"

    
    # Export the collected values
    export GIT_PROVIDER
    export GIT_ACCESS_TOKEN
    export GIT_DOMAIN_URL
    export GIT_USER
    
    return 0
}

# Export the function
export -f collect_git_credentials

################################################################################
# Update Git Credentials in .env file (Complete flow)
# This function is used by platform-adapter update-git-creds and update-api-key
################################################################################
update_git_credentials_in_env() {
    local env_file="$1"
    
    if [ -z "$env_file" ]; then
        echo "Error: ENV_FILE path required"
        return 1
    fi
    
    # Collect Git credentials using shared function
    collect_git_credentials
    
    # Update Git credentials in .env file (using # as delimiter to handle @ in emails/tokens)
    sed -i.bak "s#^GIT_PROVIDER=.*#GIT_PROVIDER=$GIT_PROVIDER#" "$env_file" && rm -f "${env_file}.bak"
    sed -i.bak "s#^GIT_ACCESS_TOKEN=.*#GIT_ACCESS_TOKEN=$GIT_ACCESS_TOKEN#" "$env_file" && rm -f "${env_file}.bak"

    # Always update domain and user (blank them out for non-enterprise)
    sed -i.bak "s#^GIT_DOMAIN_URL=.*#GIT_DOMAIN_URL=$GIT_DOMAIN_URL#" "$env_file" && rm -f "${env_file}.bak"
    sed -i.bak "s#^GIT_USER=.*#GIT_USER=$GIT_USER#" "$env_file" && rm -f "${env_file}.bak"
    
    # Cleanup backup files created by sed
    rm -f "${env_file}.bak"
    return 0
}

# Export the function
export -f update_git_credentials_in_env

################################################################################
# Validate Bito API Key with output (Shared between setup.sh and CLI)
################################################################################
validate_and_print_bito_api_key_status() {
    local api_key="$1"
    local event_type="$2"              # "architect_install_started" or "architect_api_key_update"
    local tracking_url="$3"            # TRACKING_SERVICE_BASE_URL
    local success_message="$4"         # Custom success message
    local strict_mode="${5:-false}"    # true = fail on any non-200/201, false = warn on errors
    
    if [ -z "$api_key" ] || [ -z "$event_type" ] || [ -z "$tracking_url" ]; then
        return 1
    fi
    
    print_info "Validating API key..."

    # Build tracking data
    local tracking_data=$(cat <<TRACKING_EOF
{
    "deployment_mode": "self_hosted"
}
TRACKING_EOF
    )

    # Call tracking endpoint (suppress output to prevent HTTP status leakage)
    local tracking_http_status
    tracking_http_status=$(call_tracking_endpoint_event "$tracking_url" "$api_key" "$event_type" "$tracking_data" 2>/dev/null) || true

    # Handle validation result with messages
    if [ "$tracking_http_status" = "403" ]; then
        # Invalid API Key
        echo "❌ Invalid Bito API Key. Please verify your key and try again."
        echo "   Get your key at: https://alpha.bito.ai/home/advanced"
        return 1
    elif [ "$tracking_http_status" = "200" ] || [ "$tracking_http_status" = "201" ]; then
        # Valid API Key
        print_status "${success_message:-API key validated successfully}"
        return 0
    else
        # Tracking service unavailable or other error
        if [ "$strict_mode" = "true" ]; then
            print_error "Could not validate API key"
            echo "API key validation is required before updating. Please try again later."
            return 1
        else
            print_warning "Could not validate API key (tracking service unavailable)"
            return 0  # Non-blocking
        fi
    fi
}

# Export the function
export -f validate_and_print_bito_api_key_status
