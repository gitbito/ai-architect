# Feature Plan: `bitoarch export-index` / `bitoarch import-index`

> **Feature:** CLI wrappers for cis-manager's index archive API | **Priority:** Med | **Repo(s):** cis-platform (consumes cis-manager MR !615)
> **Engineer:** Rishabh Bohra | **Created:** 2026-10-14 | **Version:** v1
> **Related:** BITO-15600, cis-manager!615, cis-platform!441
> **Research channel:** Bito repository intelligence was unreachable (ECONNREFUSED); every fact below comes from local files of cis-platform (branch `BITO-15600`) and the cis-manager BITO-15600 branch. Checkpoints were not held with the user (autonomous run); decisions are recorded in *Open Questions / Decisions*.

## Table of Contents
1. [Context Summary](#context-summary)
2. [Selected Approach](#selected-approach)
3. [Codebase Patterns This Plan Follows](#codebase-patterns-this-plan-follows)
4. [Reusable Code & Utilities](#reusable-code--utilities)
5. [Architecture Overview](#architecture-overview)
6. [Implementation Breakdown](#implementation-breakdown)
7. [Cross-Repo Integration Points](#cross-repo-integration-points)
8. [Migration & Rollback Plan](#migration--rollback-plan)
9. [Open Questions / Decisions](#open-questions--decisions)
10. [Appendix A: Research Questions Asked](#appendix-a-research-questions-asked)

## Context Summary

**Requirement (from the user).** Two `bitoarch` commands:
- `export-index` — produce the workspace's index archive and hand the operator a local `.cisidx` file. The archive must **not** stay stored on the server afterwards and **no platform backup** (`scripts/backup.sh`: DB dump + configs + volume tar) is created as part of it.
- `import-index <file>` — given that same file, put the index back; behaves like the restore flow (verifies before touching anything, previous index is preserved until success, operator confirms).

**Repos involved.** cis-platform only (`scripts/bitoarch.sh`, `scripts/lib/adapters/manager-adapter.sh`, docs, tests). The server side is already on cis-manager `BITO-15600` (MR !615): `POST/GET/DELETE /api/v3/workspaces/archives…`, `PUT /api/v3/workspaces/archives/import`, `status.json` states `pending|ready|failed|importing|verified|imported|import_failed`.

**Existing analogue.** `manager_stop_indexing` (`scripts/lib/adapters/manager-adapter.sh:1056-1162`): `--help` heredoc, `BITO_API_KEY` guard, `MANAGER_URL` from `CIS_MANAGER_URL`/`CIS_MANAGER_EXTERNAL_PORT`, `ensure_manager_service_accessible`, direct `curl -s -w '\n%{http_code}' -H "Authorization: Bearer ${BITO_API_KEY}"`, body/code split with `tail -1` / `sed '$d'`, 409 handled as "workspace busy". Workflow + poll shape: `_remove_index_request_removal` (`:1758-1795`, 409/429 → warning + return 2) and `_remove_index_poll` (`:1797-1826`, `REMOVE_INDEX_POLL_INTERVAL`/`_TIMEOUT` env overrides, interval 0 test seam, prints a terminal phase).

**Architecture / conventions.**
- Dispatch: `scripts/bitoarch.sh:376-436` `case "$command"` → adapter function; env tier list at `:319-328` (HARD LOAD for domain commands); usage block `:153-166` (INDEXING section); help text per command lives in the adapter heredoc.
- Auth: single-tenant manager routes take `Authorization: Bearer ${BITO_API_KEY}` (every adapter call); `http_request`/`manager_api_call` (`scripts/lib/http-client.sh:28,206`) use `X-API-Key` and `eval`-built commands with no file-download/upload support → **not** used for binary transfer.
- k8s: `ensure_manager_service_accessible` (`manager-adapter.sh:24-30`) wraps `ensure_service_accessible "ai-architect-manager"`.
- Output: `print_info/print_error/print_success/print_warning` (`scripts/lib/cli-core.sh:93-111`), `mask_secrets` for server bodies, `${YELLOW}bitoarch …${NC}` hints.
- Tests: standalone harness `tests/standalone/test-remove-index.sh:20-120` sources the adapter headless, stubs `print_*`, `ensure_manager_service_accessible`, and `curl` (routed by method/URL, `-w` aware); suites registered in `tests/standalone/run-all-standalone-tests.sh:64-82`; CLI smoke tests use the PATH `curl` shim in `tests/cli/test-mocks.sh:166-185` with URL-pattern cases (`/api/v3/workspaces/backups` etc. at `:90-106`).
- Docs: `docs/CLI_REFERENCE.md:104-113` Indexing table; `docs/enterprise-setup-guide.md` mentions index commands.

**Restore-flow semantics to mirror** (`scripts/restore.sh:147-206`): pre-validation, refuses while the platform is running (host-level restore), interactive confirmation with a non-interactive failure path, "pre-restore backup". For the API-based import the platform must be **running**; the server keeps the previous index parked until success and reverts on failure, so the CLI needs confirmation + dry-run, not a host backup.

**Adjacent areas (default follow-on).** `scripts/backup.sh` nightly backup (unchanged; !441 already excludes `index-archives/`); k8s `kubectl cp` path for very large files; `bitoarch diagnose` bundle listing archives.

**Domain constraints.**
- ✅ Same workspace id + same `BITO_API_KEY` on both installs (server enforces `WORKSPACE_MISMATCH`/`KEY_MISMATCH`).
- ✅ Export/import share the workspace workflow ID → 409 while indexing/removal/insights run.
- ✅ Download is `Range`-resumable; upload must be `application/octet-stream` streamed; `source_path` must sit under the archive dir.
- ⚠️ Default archive retention on the server is 2; the CLI must delete explicitly to satisfy "not stored".

## Selected Approach

**Approach A (chosen): adapter functions + direct curl, server-side archive deleted after download.**
`manager_export_index` runs: POST export → poll `GET …/archives/{id}` until `ready|failed` → `curl -o <file>` download (resumable, `-C -`) → compare `sha256` with `X-Archive-SHA256` / `status.sha256` → `DELETE …/archives/{id}` (unless `--keep`) → print path + next steps. `manager_import_index` runs: local file sanity (exists, magic `CISIDX`) → optional `--dry-run` → confirmation (unless `--yes`) → `PUT …/archives/import --data-binary @file` (or `--source-path` passthrough) → poll until `imported|verified|import_failed|failed` → print summary + hint to `bitoarch index-status`.

Rejected:
- **B — shell out to `scripts/backup.sh`/`restore.sh`.** Those are whole-platform (DB dump + configs + volume), need the platform stopped, and the user explicitly asked for *no* backup creation.
- **C — route through `http_request`/`manager_api_call`.** Wrong auth header for single-tenant v3 routes, `eval`-built command, no `-o`/`--data-binary`; would need a rewrite of the shared helper for two call sites.

## Codebase Patterns This Plan Follows
| Pattern | Found In | Applied To | Evidence |
|---|---|---|---|
| Adapter command with `--help` heredoc, key guard, URL resolution, tunnel, direct curl | `scripts/lib/adapters/manager-adapter.sh:1056-1162` (`manager_stop_indexing`) | both new commands | `local MANAGER_URL="${CIS_MANAGER_URL:-http://localhost:${MANAGER_PORT}}"` / `ensure_manager_service_accessible` |
| Start workflow then poll with env-overridable interval/timeout, terminal phase on stdout | `:1758-1826` (`_remove_index_request_removal`, `_remove_index_poll`) | `_archive_poll_state` | `local interval="${REMOVE_INDEX_POLL_INTERVAL:-10}"` … `[ "$interval" -eq 0 ] && waited=$((waited + 1))` |
| 409 = workspace busy, retry hint | `:1778-1782` | export/import start | `409|429) print_warning "Workspace is busy — another workflow (indexing or insights) is running."` |
| Dispatch + HARD env tier + usage line | `scripts/bitoarch.sh:319-328, 376-436, 153-166` | wiring | `index-repos|index-status|…|import-repos|\` list; `index-status) manager_status "$@" ;;` |
| Headless adapter unit test with curl stub | `tests/standalone/test-remove-index.sh:20-120` | new `test-export-import-index.sh` | `source "${REPO_ROOT}/scripts/lib/adapters/manager-adapter.sh"`, `curl() { … case "$url" … }` |
| Docs table rows | `docs/CLI_REFERENCE.md:104-113` | reference | `| \`bitoarch stop-indexing\` | Stop indexing completely |` |

## Reusable Code & Utilities
| Utility | From | Used For |
|---|---|---|
| `ensure_manager_service_accessible` | `manager-adapter.sh:24` | k8s port-forward before any call |
| `print_info/print_error/print_success/print_warning`, `mask_secrets` | `scripts/lib/cli-core.sh`, `output-blocks.sh` | messaging |
| `_manager_api_get` (`:918`) | adapter | status polling GET with uniform error rendering (JSON mode not needed) |
| `sha256sum`/`shasum -a 256` fallback | coreutils / macOS | integrity check of the downloaded file |
| `print_suite_summary`, `assert_*` | `tests/standalone/test-assertions.sh` | tests |

## Architecture Overview
```
bitoarch export-index [-o FILE] [--scope S] [--exclude-dk-source-docs] [--keep] [--timeout N]
   │ POST /api/v3/workspaces/archives?scope=full          (202 → archive_id)
   │ GET  /api/v3/workspaces/archives/{id}  … poll → ready | failed
   │ GET  /api/v3/workspaces/archives/{id}/download  -o FILE  (-C - resumable)
   │ sha256(FILE) == status.sha256 ?  else error (file kept, archive kept)
   └ DELETE /api/v3/workspaces/archives/{id}               (skipped with --keep)
       → prints: FILE, size, sha256, "import on a fresh install with: bitoarch import-index FILE"

bitoarch import-index FILE [--dry-run] [--yes] [--scope S] [--timeout N]   (or --source-path PATH)
   │ local checks: readable, header magic "CISIDX", size > 0
   │ confirm (unless --yes/--dry-run): "replaces the live index of workspace …"
   │ PUT /api/v3/workspaces/archives/import[?dry_run=true] --data-binary @FILE  (202 → archive_id)
   │ GET …/archives/{id} … poll → verified | imported | import_failed | failed
   └ prints outcome; on import_failed shows status.error + hint; next: bitoarch index-status
```
No DB or config changes. Both commands are HARD-LOAD env commands (need `.env-bitoarch`).

## Implementation Breakdown

### Task 1: Shared archive helpers in the manager adapter
**Files**: `scripts/lib/adapters/manager-adapter.sh` (append after `manager_stop_indexing`)
**Type**: modify existing
**What to do**: add `_archive_manager_url`, `_archive_request` (method, path, extra curl args → sets `_ARCHIVE_HTTP_CODE`/`_ARCHIVE_BODY`), `_archive_poll_state <id> <terminal-regex>` (env `INDEX_ARCHIVE_POLL_INTERVAL` default 5, `INDEX_ARCHIVE_POLL_TIMEOUT` default 3600; prints final state, sets `_ARCHIVE_STATUS_JSON`), `_archive_sha256 <file>` (`sha256sum` or `shasum -a 256`), `_archive_busy_hint` (409/429 text).
**Verify**: `bash -n scripts/lib/adapters/manager-adapter.sh`; unit test in Task 4.

### Task 2: `manager_export_index`
**Files**: same adapter
**What to do**: options `--output|-o FILE` (default `./cis-index-<ws>-<archive_id>.cisidx`; the id is known after POST, so the default name is resolved then), `--scope basic|ai|all|full` (default full), `--exclude-dk-source-docs`, `--keep` (do not delete server copy), `--timeout SECS`, `--help`. Flow per Architecture. Download with `curl -sS -f -L -C - -D <hdrs> -o FILE`; verify sha256 against status `sha256`; on mismatch delete the partial file, keep the server archive, exit 1. Delete server archive on success unless `--keep`; a delete failure is a warning (file already safe) and prints the manual command. Never create or call `backup.sh`.
**Verify**: Task 4 tests (happy path, failed export, sha mismatch, busy 409, `--keep`).

### Task 3: `manager_import_index`
**Files**: same adapter
**What to do**: positional FILE or `--source-path PATH` (mutually exclusive), `--dry-run`, `--yes|-y`, `--scope`, `--timeout`, `--help`. Local checks (file exists, non-empty, first 6 bytes `CISIDX` via `head -c 6`). Confirmation prompt mirroring `restore.sh` wording (non-interactive without `--yes` → error, like `restore.sh:170`). Upload: `curl -sS -w '\n%{http_code}' -X PUT -H "Content-Type: application/octet-stream" --data-binary @FILE`. Map 400 `WORKSPACE_MISMATCH`, 415, 409 busy, other. Poll to terminal state; `verified` (dry run) and `imported` → success with counts from status (`file_count`, `repos`); `import_failed`/`failed` → print `error` + the failure-code table hint and `bitoarch index-status`.
**Verify**: Task 4 tests (happy, dry-run, mismatch 400, busy, import_failed, missing file, bad magic).

### Task 4: Standalone test suite
**Files**: `tests/standalone/test-export-import-index.sh` (new), `tests/standalone/run-all-standalone-tests.sh` (register after `test-remove-index.sh`)
**Pattern**: `tests/standalone/test-remove-index.sh`. Stub `curl` by method+URL; for the download case write bytes to the `-o` target and emit matching sha in the status JSON; set `INDEX_ARCHIVE_POLL_INTERVAL=0`.
**Verify**: `bash tests/standalone/test-export-import-index.sh` green; `bash tests/standalone/run-all-standalone-tests.sh` unchanged otherwise.

### Task 5: CLI wiring, mocks, docs
**Files**: `scripts/bitoarch.sh` (dispatch `export-index) manager_export_index "$@"`, `import-index) manager_import_index "$@"`, HARD-LOAD tier, usage lines under INDEXING), `tests/cli/test-mocks.sh` (cases for `/api/v3/workspaces/archives*` in both blocks so `bitoarch export-index --help` smoke tests stay hermetic), `tests/cli/test-manager-cli.sh` (help smoke tests), `docs/CLI_REFERENCE.md` (two rows + example), `docs/enterprise-setup-guide.md` (short "move index to a new install" paragraph linking the commands).
**Verify**: `bash -n scripts/bitoarch.sh`; `bash tests/cli/run-all-cli-tests.sh` (or at least `test-manager-cli.sh`).

## Cross-Repo Integration Points
| Source | Target | Type | Risk | Notes |
|---|---|---|---|---|
| cis-platform CLI | cis-manager v3 archive API (MR !615) | REST | Med | Commands 404 (`FEATURE_DISABLED`) or route-404 on a manager image without !615 — print "manager does not support index archives (upgrade cis-manager)". |
| cis-platform CLI | k8s port-forward | tunnel | Low | large downloads through the on-demand tunnel are slow; `--source-path` + `kubectl cp` noted as follow-on. |

## Migration & Rollback Plan
- No data/config migration. Feature gate = server-side `backup.archive.enabled`.
- Rollback = remove the two dispatch entries; adapter functions are additive.

## Open Questions / Decisions
- **Checkpoint 1–3 (not held):** context and Approach A adopted as above.
- Default output path: current working directory, `cis-index-<ws>-<id>.cisidx` (ws from the status JSON); `-o` overrides. Decision: do not default into `BACKUP_PATH` — the user wants the file shared out, not stored.
- "Not stored": delete server copy by default after a verified download; `--keep` opt-out. Server retention (2) still prunes anything kept.
- import confirmation text names the workspace and says the previous index is restored automatically on failure (server rename-swap), so no host backup is taken.
- Follow-on: `kubectl cp` helper for k8s large files; `bitoarch diagnose` listing archives.

## Appendix A: Research Questions Asked (local files)
| Question | Finding | Evidence |
|---|---|---|
| How are manager-backed commands dispatched and which env tier? | `case "$command"` → adapter fn; HARD LOAD list | `scripts/bitoarch.sh:319-328,376-436` |
| Closest adapter exemplar for a POST + poll command? | `manager_stop_indexing`, `_remove_index_request_removal`, `_remove_index_poll` | `manager-adapter.sh:1056-1162, 1758-1826` |
| What auth/URL conventions do adapter calls use? | `Authorization: Bearer ${BITO_API_KEY}`, `CIS_MANAGER_URL`/`CIS_MANAGER_EXTERNAL_PORT`, `ensure_manager_service_accessible` | `manager-adapter.sh:24-30, 1095-1105` |
| Can the shared HTTP helper do file download/upload? | No: `eval`-built curl, `-d` only, `X-API-Key` auth | `scripts/lib/http-client.sh:28-100, 206-216` |
| How are adapter functions unit-tested? | headless source + `curl()` stub routed by method/URL; `print_*` stubs | `tests/standalone/test-remove-index.sh:20-120`; registry `run-all-standalone-tests.sh:64-82` |
| How do CLI smoke tests stay hermetic? | PATH shim `curl` with URL cases | `tests/cli/test-mocks.sh:166-185, 90-106` |
| What does the restore flow require that import should mirror? | platform stopped + confirm + non-interactive failure; pre-restore backup | `scripts/restore.sh:147-206` |
| Where are commands documented? | usage block + `docs/CLI_REFERENCE.md` Indexing table | `bitoarch.sh:153-166`; `CLI_REFERENCE.md:104-113` |

*Generated by Claude Code on 2026-10-14 — local-file research only (repository intelligence unreachable).*
