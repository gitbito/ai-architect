#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PLATFORM_DIR="$SCRIPT_DIR"  # Explicitly save platform root directory

# Source path manager for standard Unix paths
source "${SCRIPT_DIR}/scripts/lib/path-manager.sh"
# Feature-flag helpers (sso_ui_suppressed, auto_generate_mcp_token,
# compact_install_progress). Read from env + .env-bitoarch -- install_run
# persists them for SA; prod leaves them unset → verbose legacy behavior.
# shellcheck disable=SC1091
source "${SCRIPT_DIR}/scripts/lib/sso-config.sh" 2>/dev/null || true

# Use path-manager functions for file locations
ENV_FILE="$(get_config_file)"
ENV_LLM_FILE="$(get_llm_config_file)"
LOG_FILE="$(get_setup_log)"

# Export for background processes (parallel deployment)
export ENV_FILE
export ENV_LLM_FILE
export LOG_FILE
export SCRIPT_DIR
export PLATFORM_DIR

SETUP_IN_PROGRESS=false
SERVICES_WERE_RUNNING=false
DEPLOYMENT_STARTED=false

ENV_GENERATOR="${SCRIPT_DIR}/scripts/env-generator.sh"
if [ ! -f "$ENV_GENERATOR" ]; then
    echo "ERROR: env-generator.sh not found at $ENV_GENERATOR"
    exit 1
fi
source "$ENV_GENERATOR"

# Source other utilities
source "${SCRIPT_DIR}/scripts/setup-utils.sh"
source "${SCRIPT_DIR}/scripts/docker-manager.sh"
# kubernetes-manager.sh is excluded from the Standalone tarball (SA is
# Docker-only by design). Guard the source so SA install doesn't die here;
# every K8s-specific caller (deploy_kubernetes, bitoarch.sh K8s branches)
# is already gated on deployment_type = kubernetes, so the functions
# defined here are never invoked in SA.
if [ -f "${SCRIPT_DIR}/scripts/kubernetes-manager.sh" ]; then
    source "${SCRIPT_DIR}/scripts/kubernetes-manager.sh"
fi
source "${SCRIPT_DIR}/scripts/prerequisites-manager.sh"
source "${SCRIPT_DIR}/scripts/service-manager.sh"
source "${SCRIPT_DIR}/scripts/sql-migration-manager.sh"
source "${SCRIPT_DIR}/scripts/lib/adapters/config-adapter.sh"
source "${SCRIPT_DIR}/scripts/lib/adapters/manager-adapter.sh"
source "${SCRIPT_DIR}/scripts/lib/adapters/tracker-adapter.sh"

# Source config-backup-manager for centralized backup utility
if [ -f "${SCRIPT_DIR}/scripts/lib/config-backup-manager.sh" ]; then
    source "${SCRIPT_DIR}/scripts/lib/config-backup-manager.sh"
fi

# -------------------------------------------------------------------
# Function: get_repo_count_from_config
# Parses .bitoarch-config.yaml and returns the count of configured repos
# -------------------------------------------------------------------
get_repo_count_from_config() {
    # Use path-manager to get actual config file location (standard or legacy)
    local config_file=$(get_repo_config_file)

    if [ ! -f "$config_file" ]; then
        echo "0"
        return 0
    fi

    # Exclude the seeded placeholder so fresh installs don't look reconfigured.
    local repo_count=$(grep -E "^\s*- namespace:" "$config_file" 2>/dev/null \
        | grep -Ev "your-username/your-repo-name" \
        | wc -l | tr -d ' ')
    echo "${repo_count:-0}"
}

ask_llm_config_choice() {
    echo ""
    echo -e "${BLUE}=== LLM Provider Configuration ===${NC}"
    read -r -p "Do you want to configure a custom LLM provider? (y/n): " configure_llm

    if [[ "$configure_llm" =~ ^[Yy]$ ]]; then
        return 0
    fi
    return 1
}

# Source shared LLM configuration functions
if [ -f "${SCRIPT_DIR}/scripts/lib/llm-config.sh" ]; then
    source "${SCRIPT_DIR}/scripts/lib/llm-config.sh"
fi

generate_env_file() {
    # Source constants for URLs (needed by notice + indexing blocks below)
    if [ -f "${SCRIPT_DIR}/scripts/lib/constants.sh" ]; then
        source "${SCRIPT_DIR}/scripts/lib/constants.sh"
    fi

    if [ -f "$ENV_FILE" ]; then
        # Re-install path: mirror fresh-install section order for visual parity.
        render_security_notice_block
        render_credentials_section_start_block
        print_info "Using existing configuration"
        echo ""
        render_indexing_information_block

        # Infer active provider from env file to match fresh-install status line.
        local _llm_tokens_set=""
        for _t in ANTHROPIC_API_TOKEN OPENAI_API_TOKEN PORTKEY_API_TOKEN; do
            if grep -qE "^${_t}=.+" "$ENV_FILE" 2>/dev/null; then
                _llm_tokens_set="$_t"
                break
            fi
        done
        if [ -z "$_llm_tokens_set" ]; then
            print_info "Using Bito's LLM keys to index your code. No LLM keys are required from you."
        else
            print_info "Using existing custom LLM configuration (${_llm_tokens_set%_API_TOKEN})"
        fi
        return
    fi

    # Notice is informational; shown on every fresh install regardless of
    # whether the API-key prompt follows.
    render_security_notice_block

    render_credentials_section_start_block

    # BITO_API_KEY is required. When pre-set via env (SA install.yaml),
    # skip the prompt header -- no prompt is about to follow.
    local BITO_API_KEY="${BITO_API_KEY:-}"
    if [ -z "$BITO_API_KEY" ]; then
        render_api_key_prompt_header_block
        while [ -z "$BITO_API_KEY" ]; do
            read -s -p "Enter your Bito API Key (input hidden): " BITO_API_KEY
            echo ""
            if [ -z "$BITO_API_KEY" ]; then
                echo -e "${RED}✗ Bito API Key cannot be empty. Please try again.${NC}"
                echo ""
            fi
        done
    fi


    echo ""
    
    # Call tracking endpoint with dummy data after user enters BITO_API_KEY
    # This sends a setup_started event to track the initialization
    local tracking_url=""
    if [ -f "${SCRIPT_DIR}/.env-bitoarch.default" ]; then
        tracking_url=$(grep "^TRACKING_SERVICE_BASE_URL=" "${SCRIPT_DIR}/.env-bitoarch.default" 2>/dev/null | cut -d'=' -f2)
        TRACKING_SERVICE_BASE_URL="$tracking_url"
    fi
    
    if [[ -n "$tracking_url" ]]; then
        # Build dummy data for tracking
        local tracking_data
        tracking_data=$(cat <<TRACKING_EOF
{
    "deployment_mode": "self_hosted"
}
TRACKING_EOF
        )
        
        # Non-strict install (matches development): fail on invalid key (403)
        # but warn-and-continue when the tracking endpoint is unreachable
        # (air-gapped / locked-down networks). Runtime auth failures surface
        # later via `bitoarch update-api-key` if the key turns out bad.
        if ! validate_and_print_bito_api_key_status "$BITO_API_KEY" "architect_install_started" "$tracking_url" "" "false"; then
            exit 1
        fi
    fi
    echo ""

    # Coding Agent Registration (Standalone HTTPS only). Optional -- registers
    # the local MCP endpoint with installed IDEs. Skipped on Enterprise (http
    # default) and when MCP_USER_EMAIL is pre-filled via install.yaml.
    if [ "${MCP_TRANSPORT:-http}" = "https" ] && [ -z "${MCP_USER_EMAIL:-}" ]; then
        echo -e "${BLUE}=== Coding Agent Registration ===${NC}"
        echo -e "${YELLOW}ℹ Optional - registers MCP with installed coding agents${NC}"
        echo ""
        echo -e "Supported: Claude Code, Cursor, Windsurf, VS Code, Junie. Press Enter to skip."
        echo ""
        read -r -p "Enter email for MCP registration: " MCP_USER_EMAIL
        echo ""
    fi

    # Collect Git Provider and Access Token (REQUIRED). Skip the
    # "=== Git Integration ===" header + docs-pointer block when both
    # provider AND token are already set (YAML pre-fill in SA). Prompts
    # below only fire when values are missing, so the header is only
    # useful when the user actually has to read it.
    local GIT_PROVIDER="${GIT_PROVIDER:-}"
    local GIT_ACCESS_TOKEN="${GIT_ACCESS_TOKEN:-}"
    local GIT_DOMAIN_URL="${GIT_DOMAIN_URL:-}"
    local GIT_USER="${GIT_USER:-}"

    if [ -z "$GIT_PROVIDER" ] || [ -z "$GIT_ACCESS_TOKEN" ]; then
        echo -e "${BLUE}=== Git Integration ===${NC}"
        echo -e "${YELLOW}⚠ Git provider and access token are required to proceed${NC}"
        echo ""
        echo -e "See documentation: ${BLUE}${GIT_TOKEN_DOCS_URL:-https://docs.bito.ai/ai-architect/install-ai-architect-self-hosted#git-provider}${NC}"
        echo ""
    fi
    
    # Git Provider selection
    while [ -z "$GIT_PROVIDER" ]; do
        read -p "Select Git provider (1) GitLab  (2) GitHub  (3) Bitbucket  [1-3]: " git_choice
        
        case $git_choice in
            1) GIT_PROVIDER="gitlab" ;;
            2) GIT_PROVIDER="github" ;;
            3) GIT_PROVIDER="bitbucket" ;;
            *)
                echo -e "${RED}✗${NC} Invalid choice. Please select 1-3"
                ;;
        esac
    done

    if [ -z "$GIT_ACCESS_TOKEN" ]; then
        echo ""
        read -r -p "Is this an enterprise version of $GIT_PROVIDER (e.g., https://my.company.com)? (y/N):" is_enterprise
        if [[ "$is_enterprise" =~ ^[Yy]$ ]]; then
            while [ -z "$GIT_DOMAIN_URL" ]; do
                read -r -p "Enter domain for enterprise $GIT_PROVIDER: " GIT_DOMAIN_URL
                if [ -z "$GIT_DOMAIN_URL" ]; then
                    echo -e "${RED}✗${NC} Git domain is required for enterprise"
                fi
            done
        fi
    fi

    if [ -z "$GIT_ACCESS_TOKEN" ]; then
        if [[ "$GIT_PROVIDER" == "bitbucket" ]]; then
            echo ""
            echo -e "🛠 Configuring user authentication..."

            if [[ -z "$GIT_DOMAIN_URL" ]]; then
                # No domain → ask for email
                while [[ -z "$GIT_USER" ]]; do
                    read -r -p "Enter your Bitbucket account email: " GIT_USER
                    [[ -z "$GIT_USER" ]] && echo "⚠ Email is required. Please try again."
                done
            else
                # Domain exists → ask for username
                while [[ -z "$GIT_USER" ]]; do
                    read -r -p "Enter your Bitbucket username: " GIT_USER
                    [[ -z "$GIT_USER" ]] && echo "⚠ Username is required. Please try again."
                done
            fi

            echo -e "✅ Bitbucket user set: $GIT_USER"
        fi
    fi


    
    # Git Access Token input
    while [ -z "$GIT_ACCESS_TOKEN" ]; do
        echo ""
        read -s -p "Enter Git access token (input hidden): " GIT_ACCESS_TOKEN
        if [ -z "$GIT_ACCESS_TOKEN" ]; then
            echo ""
            echo -e "${RED}✗${NC} Git access token is required"
            echo ""
        fi
    done
    
    echo ""
    print_info "Git provider configured (${GIT_PROVIDER})"

    # Send git integration tracking event
    # Determine if this is enterprise based on user response
    local is_enterprise_bool="false"
    if [[ "$is_enterprise" =~ ^[Yy]$ ]]; then
        is_enterprise_bool="true"
    fi

    # Call tracking with git integration event
    send_git_integration_tracking "$GIT_PROVIDER" "$is_enterprise_bool" "$GIT_DOMAIN_URL"

    render_indexing_information_block

    local tracking_url=""
    if [ -f "${SCRIPT_DIR}/.env-bitoarch.default" ]; then
        tracking_url=$(grep "^TRACKING_SERVICE_BASE_URL=" "${SCRIPT_DIR}/.env-bitoarch.default" 2>/dev/null | cut -d'=' -f2)
    fi

    local custom_llm_configured=false
    # Bito-hosted LLM takes precedence when indexing is enabled; else fall
    # back to yaml-preset tokens or interactive prompt via configure_llm_provider.
    if check_indexing_enabled "${tracking_url}" "${BITO_API_KEY}" >/dev/null 2>&1 ; then
        print_info "Using Bito's LLM keys to index your code. No LLM keys are required from you."
    else
        configure_llm_provider
        custom_llm_configured=true
    fi
    # env-generator.sh gates the "generated" banner on the same flag.
    export CUSTOM_LLM_CONFIGURED="$custom_llm_configured"

    if [[ "${AUTO_SETUP:-}" == "true" ]]; then
        print_info "Auto-setup mode: using defaults with secure generated passwords"
    elif [ "$custom_llm_configured" = "true" ]; then
        # Shown only when the user just made an LLM choice (otherwise nothing
        # to summarize).
        echo ""
        echo -e "${BLUE}${BOLD}⚡ Quick Configuration${NC}"
        echo "  Using defaults (recommended for quick setup)"
        echo ""
    fi
    
    DB_ROOT_PASS=$(generate_secret)
    DB_USER_PASS=$(generate_secret)
    JWT_SECRET=$(generate_secret)
    CIS_MANAGER_API_KEY=$(generate_secret)
    CIS_CONFIG_API_KEY=$(generate_secret)
    CIS_PROVIDER_API_KEY=$(generate_secret)
    SECRETS_ENCRYPTION_KEY=$(generate_encryption_key)
    
    # Read ONLY port defaults from .env-bitoarch.default if it exists (don't overwrite user inputs!)
    if [ -f "${SCRIPT_DIR}/.env-bitoarch.default" ]; then
        log_silent "Reading default port configuration from .env-bitoarch.default"
        # Extract only port variables using grep
        local temp_provider_port=$(grep "^CIS_PROVIDER_EXTERNAL_PORT=" "${SCRIPT_DIR}/.env-bitoarch.default" 2>/dev/null | cut -d'=' -f2 || echo "8080")
        local temp_manager_port=$(grep "^CIS_MANAGER_EXTERNAL_PORT=" "${SCRIPT_DIR}/.env-bitoarch.default" 2>/dev/null | cut -d'=' -f2 || echo "9090")
        local temp_config_port=$(grep "^CIS_CONFIG_EXTERNAL_PORT=" "${SCRIPT_DIR}/.env-bitoarch.default" 2>/dev/null | cut -d'=' -f2 || echo "8081")
        local temp_mysql_port=$(grep "^MYSQL_EXTERNAL_PORT=" "${SCRIPT_DIR}/.env-bitoarch.default" 2>/dev/null | cut -d'=' -f2 || echo "3306")
        local temp_tracker_port=$(grep "^CIS_TRACKER_EXTERNAL_PORT=" "${SCRIPT_DIR}/.env-bitoarch.default" 2>/dev/null | cut -d'=' -f2 || echo "9090")

        # Only use if not empty
        [ -n "$temp_provider_port" ] && CIS_PROVIDER_EXTERNAL_PORT="$temp_provider_port"
        [ -n "$temp_manager_port" ] && CIS_MANAGER_EXTERNAL_PORT="$temp_manager_port"
        [ -n "$temp_config_port" ] && CIS_CONFIG_EXTERNAL_PORT="$temp_config_port"
        [ -n "$temp_mysql_port" ] && MYSQL_EXTERNAL_PORT="$temp_mysql_port"
        [ -n "$temp_tracker_port" ] && CIS_TRACKER_EXTERNAL_PORT="$temp_tracker_port"
    fi
    
    # Load service versions from versions/service-versions.json (single source of truth)
    local versions_file="${SCRIPT_DIR}/versions/service-versions.json"
    if [ -f "$versions_file" ]; then
        if command -v jq >/dev/null 2>&1; then
            CIS_CONFIG_VERSION=$(jq -r '.services."cis-config".version' "$versions_file" 2>/dev/null || echo "latest")
            CIS_MANAGER_VERSION=$(jq -r '.services."cis-manager".version' "$versions_file" 2>/dev/null || echo "latest")
            CIS_PROVIDER_VERSION=$(jq -r '.services."cis-provider".version' "$versions_file" 2>/dev/null || echo "latest")
            CIS_TRACKER_VERSION=$(jq -r '.services."cis-tracker".version' "$versions_file" 2>/dev/null || echo "latest")
            TEMPORAL_VERSION=$(jq -r '.services."temporal".version' "$versions_file" 2>/dev/null || echo "latest")
            CIS_WORKER_VERSION=$(jq -r '.services."cis-worker".version' "$versions_file" 2>/dev/null || echo "latest")
        else
            # Fallback parsing without jq
            CIS_CONFIG_VERSION=$(grep -A 10 '"cis-config"' "$versions_file" | grep '"version"' | head -1 | cut -d'"' -f4 || echo "latest")
            CIS_MANAGER_VERSION=$(grep -A 10 '"cis-manager"' "$versions_file" | grep '"version"' | head -1 | cut -d'"' -f4 || echo "latest")
            CIS_PROVIDER_VERSION=$(grep -A 10 '"cis-provider"' "$versions_file" | grep '"version"' | head -1 | cut -d'"' -f4 || echo "latest")
            CIS_TRACKER_VERSION=$(grep -A 10 '"cis-tracker"' "$versions_file" | grep '"version"' | head -1 | cut -d'"' -f4 || echo "latest")
            TEMPORAL_VERSION=$(grep -A 10 '"temporal"' "$versions_file" | grep '"version"' | head -1 | cut -d'"' -f4 || echo "latest")
            CIS_WORKER_VERSION=$(grep -A 10 '"cis-worker"' "$versions_file" | grep '"version"' | head -1 | cut -d'"' -f4 || echo "latest")
        fi
        log_silent "Service versions loaded from $versions_file"
        log_silent "  AI Architect Config: $CIS_CONFIG_VERSION"
        log_silent "  AI Architect Manager: $CIS_MANAGER_VERSION"
        log_silent "  AI Architect Provider: $CIS_PROVIDER_VERSION"
        log_silent "  AI Architect Tracker: $CIS_TRACKER_VERSION"
        log_silent "  AI Architect Worker: $CIS_WORKER_VERSION"

    else
        print_warning "versions/service-versions.json not found, using 'latest' tags"
        CIS_CONFIG_VERSION="latest"
        CIS_MANAGER_VERSION="latest"
        CIS_PROVIDER_VERSION="latest"
        CIS_TRACKER_VERSION="latest"
    fi
    
    # Auto-generate the MCP access token silently. Power users can pre-seed
    # BITO_MCP_ACCESS_TOKEN in the environment (or .env-bitoarch) to supply
    # a custom token -- it will be respected if already set.
    if [ -z "${BITO_MCP_ACCESS_TOKEN:-}" ]; then
        BITO_MCP_ACCESS_TOKEN=$(generate_secret)
    fi


    
    # Use external ports from .env-bitoarch.default if available, otherwise use defaults
    CIS_PROVIDER_EXTERNAL_PORT=${CIS_PROVIDER_EXTERNAL_PORT:-8080}
    CIS_MANAGER_EXTERNAL_PORT=${CIS_MANAGER_EXTERNAL_PORT:-9090}
    CIS_CONFIG_EXTERNAL_PORT=${CIS_CONFIG_EXTERNAL_PORT:-8081}
    MYSQL_EXTERNAL_PORT=${MYSQL_EXTERNAL_PORT:-3306}
    CIS_TRACKER_EXTERNAL_PORT=${CIS_TRACKER_EXTERNAL_PORT:-9920}
    
    log_silent "Using port configurations: Provider:$CIS_PROVIDER_EXTERNAL_PORT Manager:$CIS_MANAGER_EXTERNAL_PORT Config:$CIS_CONFIG_EXTERNAL_PORT MySQL:$MYSQL_EXTERNAL_PORT Tracker:$CIS_TRACKER_EXTERNAL_PORT"
    log_silent "Secure passwords and tokens: auto-generated"
    
    log_silent "Generating .env-bitoarch from template (.env-bitoarch.default)..."
    
    # Call env-generator function with all collected parameters
    generate_env_with_params "$ENV_FILE" \
        "$BITO_API_KEY" "$DB_ROOT_PASS" "$DB_USER_PASS" "$JWT_SECRET" \
        "$CIS_MANAGER_API_KEY" "$CIS_CONFIG_API_KEY" "$CIS_PROVIDER_API_KEY" \
        "$BITO_MCP_ACCESS_TOKEN" "$SECRETS_ENCRYPTION_KEY" \
        "$CIS_CONFIG_VERSION" "$CIS_MANAGER_VERSION" "$CIS_PROVIDER_VERSION" \
        "$CIS_PROVIDER_EXTERNAL_PORT" "$CIS_MANAGER_EXTERNAL_PORT" "$CIS_CONFIG_EXTERNAL_PORT" "$MYSQL_EXTERNAL_PORT" \
        "$GIT_PROVIDER" "$GIT_ACCESS_TOKEN" "$GIT_DOMAIN_URL" "$GIT_USER" "$CIS_TRACKER_EXTERNAL_PORT" "$CIS_TRACKER_VERSION"
    
    [ $? -ne 0 ] && return 1

    log_silent "Env file created: $ENV_FILE"

    # Standalone install: collect email + flip MCP transport/auto-install
    # in .env-bitoarch so the cert + coding-agent flow opt in. Enterprise
    # (SKIP_SSO_PROMPT unset) keeps template defaults (http / false / "").
    if [ "${SKIP_SSO_PROMPT:-false}" = "true" ]; then
        if [ -n "${MCP_USER_EMAIL:-}" ] && \
           ! [[ "$MCP_USER_EMAIL" =~ ^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$ ]]; then
            print_warning "Invalid email '${MCP_USER_EMAIL}'; auto-registration disabled."
            MCP_USER_EMAIL=""
        fi
        : "${MCP_TRANSPORT:=https}"
        : "${MCP_AUTO_INSTALL:=true}"
        sed -i.bak \
            -e "s|^MCP_TRANSPORT=.*|MCP_TRANSPORT=${MCP_TRANSPORT}|" \
            -e "s|^MCP_AUTO_INSTALL=.*|MCP_AUTO_INSTALL=${MCP_AUTO_INSTALL}|" \
            -e "s|^MCP_USER_EMAIL=.*|MCP_USER_EMAIL=${MCP_USER_EMAIL}|" \
            "$ENV_FILE" 2>/dev/null && rm -f "${ENV_FILE}.bak"
        export MCP_TRANSPORT MCP_AUTO_INSTALL MCP_USER_EMAIL
    fi
}

prepare_data_directories() {
    log_silent "Preparing all service directories with proper permissions..."
    
    # Source .env to get directory paths if file exists
    if [ -f "$ENV_FILE" ]; then
        source "$ENV_FILE"
    fi
    
    # Get config directory from path-manager (handles standard vs legacy paths)
    local config_dir="$(get_config_dir)"

    # Ensure config directory exists and is writable
    mkdir -p "$config_dir" 2>/dev/null || {
        if command -v sudo >/dev/null 2>&1; then
            sudo mkdir -p "$config_dir"
            sudo chown -R "$USER:$(id -gn)" "$config_dir"
        fi
    }

    # Get log directory from path-manager (handles standard vs legacy paths)
    local log_dir="$(get_log_dir)"

    # Ensure log directory exists and is writable
    mkdir -p "$log_dir" 2>/dev/null || {
        if command -v sudo >/dev/null 2>&1; then
            sudo mkdir -p "$log_dir"
            sudo chown -R "$USER:$(id -gn)" "$log_dir"
        fi
    }

    # Create service-specific log directories
    create_log_dirs

    # Define all directories that need full permissions for containers
    local directories=(
        "${SCRIPT_DIR}/${HOST_DATA_DIR:-services/cis-provider/data}"
        "$log_dir"
        "${SCRIPT_DIR}/${HOST_PROVIDER_METADATA_DIR:-services/cis-provider/metadata}"
    )
    
    local failed_dirs=()
    local success_count=0
    
    # Create and set permissions for each directory
    for dir in "${directories[@]}"; do
        # Create directory if it doesn't exist
        mkdir -p "$dir" 2>/dev/null
        
        # Set 777 permissions (rwxrwxrwx) so any container user can read/write
        if chmod -R 777 "$dir" 2>/dev/null; then
            success_count=$((success_count + 1))
            log_silent "Set 777 permissions on $dir"
        else
            # Try with sudo if regular chmod fails
            if command -v sudo >/dev/null 2>&1 && sudo chmod -R 777 "$dir" 2>/dev/null; then
                success_count=$((success_count + 1))
                log_silent "Set 777 permissions with sudo on $dir"
            else
                failed_dirs+=("$dir")
            fi
        fi
    done
    
    # Report results
    if [ ${#failed_dirs[@]} -eq 0 ]; then
        log_silent "Set full permissions (777) on all service directories (${success_count}/${#directories[@]})"
    else
        print_warning "Failed to set permissions on ${#failed_dirs[@]} directories:"
        for dir in "${failed_dirs[@]}"; do
            echo "  - $dir"
        done
        print_warning "Please manually run: sudo chmod -R 777 ${failed_dirs[*]}"
        return 1
    fi
    
    log_silent "All service directories prepared with proper permissions"
}

prepare_service_sql_scripts() {
    log_silent "Preparing service SQL scripts for MySQL initialization..."
    
    local mysql_init_dir="${SCRIPT_DIR}/services/mysql/init"
    local scripts_copied=0
    
    # Copy cis-config SQL scripts (numbered 02-* to run after 00 and 01)
    local config_sql_dir="${SCRIPT_DIR}/services/cis-config/resources/sql"
    if [ -d "$config_sql_dir" ]; then
        for sql_file in "$config_sql_dir"/*.sql; do
            if [ -f "$sql_file" ]; then
                local filename=$(basename "$sql_file")
                local dest_file="${mysql_init_dir}/02-cis-config-${filename}"
                cp "$sql_file" "$dest_file"
                scripts_copied=$((scripts_copied + 1))
                log_silent "Copied: $filename -> 02-cis-config-${filename}"
            fi
        done
    fi
    
    # Copy cis-manager SQL scripts (database.sql first with 03-, others with 04-)
    local manager_sql_dir="${SCRIPT_DIR}/services/cis-manager/resources"
    if [ -d "$manager_sql_dir" ]; then
        # Handle database.sql separately with 03- prefix (must run first)
        if [ -f "$manager_sql_dir/database.sql" ]; then
            cp "$manager_sql_dir/database.sql" "${mysql_init_dir}/03-cis-manager-database.sql"
            scripts_copied=$((scripts_copied + 1))
            log_silent "Copied: database.sql -> 03-cis-manager-database.sql"
        fi

        # Copy all other SQL files with 04- prefix (run after database.sql)
        for sql_file in "$manager_sql_dir"/*.sql; do
            if [ -f "$sql_file" ]; then
                local filename=$(basename "$sql_file")
                # Skip database.sql as it's already handled above
                if [ "$filename" != "database.sql" ]; then
                    local dest_file="${mysql_init_dir}/04-cis-manager-${filename}"
                    cp "$sql_file" "$dest_file"
                    scripts_copied=$((scripts_copied + 1))
                    log_silent "Copied: $filename -> 04-cis-manager-${filename}"
                fi
            fi
        done
    fi
    
    if [ $scripts_copied -gt 0 ]; then
        log_silent "Prepared $scripts_copied SQL script(s) for MySQL initialization"
        log_silent "SQL scripts will execute in order: 00-*, 01-*, 02-*, 03-*, 04-*"
    else
        log_silent "No service SQL scripts found to prepare"
    fi
    
    return 0
}

ask_repo_setup_mode() {
    local choice_normalized=""
    local tracking_url=""
    if [ -f "${SCRIPT_DIR}/.env-bitoarch.default" ]; then
        tracking_url=$(grep "^TRACKING_SERVICE_BASE_URL=" "${SCRIPT_DIR}/.env-bitoarch.default" 2>/dev/null | cut -d'=' -f2)
    fi
    # AUTO_SETUP=true: skip the prompt and default to "auto" mode. Used by the
    # Standalone install bootstrap (--auto flag) and any CI/automation caller.
    if [[ "${AUTO_SETUP:-}" == "true" ]]; then
        choice="auto"
    fi
    while true; do
        if [[ "${AUTO_SETUP:-}" != "true" ]]; then
            echo ""
            read -r -p "Choose setup mode (auto/manual): " choice
        fi

        # Normalize: convert input to lowercase
        choice_normalized=$(echo "$choice" | tr '[:upper:]' '[:lower:]')

        case "$choice_normalized" in
            auto|a)
                SETUP_MODE="auto"
                echo ""
                print_info "⚙️  Auto mode selected. Saving configuration..."
                echo ""

                if [ -f "$ENV_LLM_FILE" ]; then
                    source "$ENV_LLM_FILE"
                fi

                config_repo_add_from_file_from_setup ".bitoarch-config.yaml"
                if [ $? -ne 0 ]; then
                    print_error "Failed to save configuration automatically."
                    render_manual_repo_config_block
                    SETUP_MODE="failed"
                    return 0
                fi

                print_status "Configuration saved successfully!"
                echo ""
                
                # Send tracking event for auto mode
               
                send_deployment_tracking "auto" "configuration_saved" ""
                
                manager_sync_simple
                echo ""
                return 0
                ;;

            manual|m)
                SETUP_MODE="manual"
                echo ""
                echo -e "🧩 Manual configuration selected."
                echo ""
                
                # Send tracking event for manual mode
               
                send_deployment_tracking "manual" "manual_setup_started" ""

                render_manual_config_instructions_block
                echo ""
                return 0
                ;;

            *)
                print_error "Invalid choice. Please type 'auto' or 'manual'."
                echo ""
                ;;
        esac
    done
}

setup_configuration() {
    # Load environment variables from .env-bitoarch if it exists
    # This is needed to fetch Git provider credentials (GIT_PROVIDER, GIT_ACCESS_TOKEN, BITO_API_KEY)
    if [ -f "$ENV_FILE" ]; then
        source "$ENV_FILE"
    fi
    
    # Check if we should skip repo reconfiguration
    local repo_count=$(get_repo_count_from_config)
    
    # Only ask if config already exists with repos
    if [ "$repo_count" -gt 0 ] && ! render_repo_reconfiguration_prompt_block "$repo_count"; then
        # Return 2 to indicate config was skipped (user said no)
        return 2
    fi

    
    # Proceed with configuration
    echo ""
    echo -e "⏳ Fetching repository list from your git provider (30-50s)..."

    # Start loader in background
#    show_loader "Fetching repository metadata"

    # Export deployment type for API calls
    export DEPLOYMENT_TYPE=$(get_deployment_type)

    create_repo_config_from_api
    load_cfg_exit_code=$?

    if [ $load_cfg_exit_code -ne 0 ]; then
        print_error "Failed to fetch repository information."
        render_manual_repo_config_block
        SETUP_MODE="failed"
        return 0
    fi


    echo ""
    # -------------------------------
    # 3. Ask user for auto/manual setup
    # -------------------------------

    render_repo_config_choice_block
    ask_repo_setup_mode

}

display_success() {
    source "$ENV_FILE"
    
    # Use block-level render function
    render_deploy_success_block \
        "$BITO_MCP_ACCESS_TOKEN" \
        "${MCP_TRANSPORT:-http}://localhost:$CIS_PROVIDER_EXTERNAL_PORT/mcp" \
        "$HOME/.local/bin/bitoarch" \
        "${GIT_PROVIDER}" \
        "${SETUP_MODE:-manual}"
}

# Prompt for SSO setup during initial deployment (shared by K8s and Docker).
#
# Gating (intentional double-layer):
#   1. Outer gate (caller): SKIP_SSO_PROMPT=true  → caller does NOT invoke us
#      (SA install suppresses the prompt; SSO deferred to `bitoarch sso setup`).
#   2. Inner gate (below):  SETUP_MODE=manual     → we return silently because
#      render_config_add_next_steps already lists "Configure SSO" as a numbered
#      step in the printed instructions; an interactive prompt would be
#      redundant. Auto mode gets the prompt (installation is ending; last
#      interactive moment for the user).
prompt_sso_setup() {
    if [[ "${SETUP_MODE:-}" != "manual" ]]; then
        # Re-source env so workspace_id from add-repos is available
        [ -f "$ENV_FILE" ] && source "$ENV_FILE"

        render_sso_config_prompt_block
        read -r -p "Would you like to configure SSO? (y/N): " sso_choice

        if [[ "$sso_choice" =~ ^[Yy]$ ]]; then
            if [ -f "${SCRIPT_DIR}/scripts/lib/adapters/xmcp-adapter.sh" ]; then
                source "${SCRIPT_DIR}/scripts/lib/adapters/xmcp-adapter.sh"
                handle_sso "setup" || true
            else
                print_warning "SSO adapter not found"
                echo -e "   Run ${YELLOW}bitoarch sso setup${NC} to configure SSO later"
            fi
        else
            render_sso_deferred_block
        fi
    fi
}

cleanup_on_interrupt() {
    local exit_code=${1:-1}

    # Stop the spinner/loader if running
    stop_loader 2>/dev/null || true

    echo ""
    
    if [[ "$DEPLOYMENT_STARTED" == "true" ]] && [[ "$SERVICES_WERE_RUNNING" == "false" ]]; then
        # print_warning emits its own ⚠ prefix; don't duplicate with 🧹.
        print_warning "Setup interrupted — cleaning up partial deployment..."
        
        local cleanup_cmd="${DOCKER_COMPOSE_CMD:-docker-compose}"
        
        printf "   %-25s" "Stopping Services"
        if eval "$cleanup_cmd down --timeout 30" >/dev/null 2>&1; then
            printf "${GREEN}✅${NC} Stopped gracefully\n"
        else
            printf "${YELLOW}⚠${NC} Timeout\n"
            eval "$cleanup_cmd kill" >/dev/null 2>&1 || true
            eval "$cleanup_cmd rm -f" >/dev/null 2>&1 || true
            printf "   %-25s${GREEN}✅${NC} Force stopped\n" "Cleanup"
        fi
        
        printf "   %-25s" "Releasing Resources"
        eval "$cleanup_cmd down --remove-orphans --volumes" >/dev/null 2>&1 || true
        printf "${GREEN}✅${NC} Released\n"
        
        print_status "Partial deployment cleaned up"
        print_info "You can safely re-run the install command now"
        
    elif [[ "$DEPLOYMENT_STARTED" == "true" ]] && [[ "$SERVICES_WERE_RUNNING" == "true" ]]; then
        print_info "Setup interrupted - existing services remain running"
        print_warning "Services may be in inconsistent state if restart was interrupted"
        print_info "Consider running: docker compose restart"
        
    else
        print_info "Setup cancelled - no changes made to services"
        if [[ "$SERVICES_WERE_RUNNING" == "true" ]]; then
            print_status "Your services remain running"
        fi
    fi
    
    exit $exit_code
}

cleanup_on_error() {
    if [[ "$DEPLOYMENT_STARTED" == "true" ]]; then
        print_error "Setup failed during deployment"
        cleanup_on_interrupt 1
    else
        print_error "Setup failed during initialization"
        print_info "No cleanup needed - services unaffected"
        exit 1
    fi
}

cleanup_on_sigint() {
    echo ""
    print_warning "Setup interrupted by user (Ctrl+C)"
    cleanup_on_interrupt 130
}

cleanup_on_sigterm() {
    echo ""
    print_warning "Setup terminated by system"
    cleanup_on_interrupt 143
}

install_cli() {
    local cli_source="${PLATFORM_DIR}/scripts/bitoarch.sh"
    local cli_bin_dir="$HOME/.local/bin"
    local cli_target="$cli_bin_dir/bitoarch"
    
    log_silent "Installing CLI to $cli_bin_dir"
    
    if [ ! -f "$cli_source" ]; then
        print_warning "CLI script not found, skipping CLI installation"
        log_silent "CLI not found at expected location: $cli_source"
        return 1
    fi
    
    # Create directory if it doesn't exist
    mkdir -p "$cli_bin_dir"
    
    # Make CLI executable and create symlink
    chmod +x "$cli_source"
    ln -sf "$cli_source" "$cli_target"
    
    # Add to PATH for current session (immediate availability)
    export PATH="$cli_bin_dir:$PATH"
    
    # Add to shell configs for future sessions (only if not already present)
    PATH_EXPORT_LINE='export PATH="$HOME/.local/bin:$PATH"'
    CLI_CONFIG_FILES="$HOME/.zshrc $HOME/.bashrc $HOME/.profile $HOME/.bash_profile"
    CLI_ADDED_TO_ANY=false
    CLI_FOUND_CONFIG=false
    
    for config_file in $CLI_CONFIG_FILES; do
        if [ -f "$config_file" ]; then
            CLI_FOUND_CONFIG=true
            # Check if PATH export already exists (using grep -F for fixed string matching)
            if ! grep -qF '.local/bin' "$config_file" 2>/dev/null; then
                echo "$PATH_EXPORT_LINE" >> "$config_file"
                log_silent "Added PATH to $config_file"
                CLI_ADDED_TO_ANY=true
            else
                log_silent "PATH already present in $config_file, skipping"
            fi
        fi
    done
    
    # Fallback: if no rc files found, create .bash_profile
    if [ "$CLI_FOUND_CONFIG" = "false" ]; then
        echo "$PATH_EXPORT_LINE" > "$HOME/.bash_profile"
        log_silent "No shell config files found, created $HOME/.bash_profile with PATH"
        CLI_ADDED_TO_ANY=true
    fi
    
    log_silent "CLI successfully installed to $cli_target"
    return 0
}

rotate_mcp_token() {
    local new_token="$1"
    
    print_info "Rotating MCP access token..."
    
    # Validate token is provided
    if [ -z "$new_token" ]; then
        print_error "Token cannot be empty"
        return 1
    fi
    
    # Update .env file
    if [ -f "$ENV_FILE" ]; then
        sed -i.bak "s/^BITO_MCP_ACCESS_TOKEN=.*/BITO_MCP_ACCESS_TOKEN=${new_token}/" "$ENV_FILE"
        print_status "Updated token in .env-bitoarch"
    else
        print_error ".env file not found"
        return 1
    fi
    
    # Reload environment
    source "$ENV_FILE"
    export BITO_MCP_ACCESS_TOKEN="$new_token"
    
    # Restart ai-architect-provider to pick up new token from environment
    print_info "Restarting ai-architect-provider service to apply new token..."
    cd "$(dirname "$SCRIPT_DIR")" 2>/dev/null || cd "$PLATFORM_DIR" 2>/dev/null || true
    eval "${DOCKER_COMPOSE_CMD:-docker-compose} restart ai-architect-provider" >/dev/null 2>&1
    
    echo ""
    print_status "MCP token rotated successfully"
    print_info "The provider will apply the new token from environment at startup"
    echo ""
    print_info "New MCP URL: ${MCP_TRANSPORT:-http}://localhost:${CIS_PROVIDER_EXTERNAL_PORT}/mcp"
    print_info "New Token: ${new_token}"
    echo ""
    
    return 0
}

# Check Docker Compose port availability
check_docker_ports() {
    log_silent "Checking port availability for Docker Compose..."
    
    # Read port values from .env-bitoarch.default
    local temp_provider_port=$(grep "^CIS_PROVIDER_EXTERNAL_PORT=" "${SCRIPT_DIR}/.env-bitoarch.default" 2>/dev/null | cut -d'=' -f2 || echo "8080")
    local temp_manager_port=$(grep "^CIS_MANAGER_EXTERNAL_PORT=" "${SCRIPT_DIR}/.env-bitoarch.default" 2>/dev/null | cut -d'=' -f2 || echo "9090")
    local temp_config_port=$(grep "^CIS_CONFIG_EXTERNAL_PORT=" "${SCRIPT_DIR}/.env-bitoarch.default" 2>/dev/null | cut -d'=' -f2 || echo "8081")
    local temp_mysql_port=$(grep "^MYSQL_EXTERNAL_PORT=" "${SCRIPT_DIR}/.env-bitoarch.default" 2>/dev/null | cut -d'=' -f2 || echo "3306")
    local temp_tracker_port=$(grep "^CIS_TRACKER_EXTERNAL_PORT=" "${SCRIPT_DIR}/.env-bitoarch.default" 2>/dev/null | cut -d'=' -f2 || echo "9920")
    
    local port_conflicts=()
    
    if command -v lsof >/dev/null 2>&1; then
        if lsof -i ":${temp_provider_port}" >/dev/null 2>&1; then
            port_conflicts+=("${temp_provider_port}")
        fi
        if lsof -i ":${temp_manager_port}" >/dev/null 2>&1; then
            port_conflicts+=("${temp_manager_port}")
        fi
        if lsof -i ":${temp_config_port}" >/dev/null 2>&1; then
            port_conflicts+=("${temp_config_port}")
        fi
        if lsof -i ":${temp_mysql_port}" >/dev/null 2>&1; then
            port_conflicts+=("${temp_mysql_port}")
        fi
        if lsof -i ":${temp_tracker_port}" >/dev/null 2>&1; then
            port_conflicts+=("${temp_tracker_port}")
        fi
    fi
    
    if [ ${#port_conflicts[@]} -gt 0 ]; then
        echo ""
        echo -e "${RED}⚠ Port conflicts detected${NC}"
        echo ""
        echo "The following ports are already in use:"
        for port in "${port_conflicts[@]}"; do
            echo -e "  - ${RED}${port}${NC}"
        done
        echo ""
        echo -e "${YELLOW}To resolve:${NC}"
        echo "  1. Edit .env-bitoarch.default and change the conflicting port values"
        echo "  2. Re-run your install command"
        echo ""
        exit 1
    fi

    print_status "All required ports are available"
}

# Check Kubernetes external port availability (for port-forwards)
check_k8s_external_ports() {
    print_info "Checking external port availability in Kubernetes cluster..."
    
    # Read port values from .env-bitoarch.default
    local temp_provider_port=$(grep "^CIS_PROVIDER_EXTERNAL_PORT=" "${SCRIPT_DIR}/.env-bitoarch.default" 2>/dev/null | cut -d'=' -f2 || echo "5001")
    local temp_manager_port=$(grep "^CIS_MANAGER_EXTERNAL_PORT=" "${SCRIPT_DIR}/.env-bitoarch.default" 2>/dev/null | cut -d'=' -f2 || echo "5002")
    local temp_config_port=$(grep "^CIS_CONFIG_EXTERNAL_PORT=" "${SCRIPT_DIR}/.env-bitoarch.default" 2>/dev/null | cut -d'=' -f2 || echo "5003")
    local temp_mysql_port=$(grep "^MYSQL_EXTERNAL_PORT=" "${SCRIPT_DIR}/.env-bitoarch.default" 2>/dev/null | cut -d'=' -f2 || echo "5004")
    local temp_tracker_port=$(grep "^CIS_TRACKER_EXTERNAL_PORT=" "${SCRIPT_DIR}/.env-bitoarch.default" 2>/dev/null | cut -d'=' -f2 || echo "5005")
    
    local ports=($temp_provider_port $temp_manager_port $temp_config_port $temp_mysql_port $temp_tracker_port)
    local conflicts=()
    
    # Check if jq is available for JSON parsing
    if command -v jq >/dev/null 2>&1; then
        # Check if any NodePort services already use these ports
        for port in "${ports[@]}"; do
            if kubectl get svc --all-namespaces -o json 2>/dev/null | \
               jq -r '.items[].spec.ports[]? | select(.nodePort=='$port') | .nodePort' 2>/dev/null | \
               grep -q "^${port}$"; then
                conflicts+=("$port")
            fi
        done
    else
        # Fallback: grep through kubectl output
        local all_nodeports=$(kubectl get svc --all-namespaces -o wide 2>/dev/null | grep -oE ":[0-9]{5}/" | tr -d ':/' | sort -u)
        for port in "${ports[@]}"; do
            if echo "$all_nodeports" | grep -q "^${port}$"; then
                conflicts+=("$port")
            fi
        done
    fi
    
    if [ ${#conflicts[@]} -gt 0 ]; then
        echo ""
        echo -e "${RED}⚠ Port conflicts detected${NC}"
        echo ""
        echo "The following ports are already in use in your Kubernetes cluster:"
        for port in "${conflicts[@]}"; do
            echo -e "  - ${RED}${port}${NC}"
        done
        echo ""
        echo -e "${YELLOW}To resolve:${NC}"
        echo "  1. Edit .env-bitoarch.default and change the conflicting port values"
        echo "  2. Re-run your install command"
        echo ""
        exit 1
    fi

    print_status "All required ports are available"
}

# Setup environment variables for CONFIG_URL (used by setup_configuration)
setup_env_for_config() {
    local deployment_type=$(get_deployment_type)
    
    if [ "$deployment_type" = "kubernetes" ]; then
        # Kubernetes: source .env-bitoarch for credentials, then set CONFIG_URL
        if [ -f "$ENV_FILE" ]; then
            source "$ENV_FILE"
        fi
        
        # Read port from .env-bitoarch.default if not set
        if [ -z "$CIS_CONFIG_EXTERNAL_PORT" ] && [ -f "${SCRIPT_DIR}/.env-bitoarch.default" ]; then
            CIS_CONFIG_EXTERNAL_PORT=$(grep "^CIS_CONFIG_EXTERNAL_PORT=" "${SCRIPT_DIR}/.env-bitoarch.default" 2>/dev/null | cut -d'=' -f2 || echo "5003")
        fi
        CIS_CONFIG_EXTERNAL_PORT=${CIS_CONFIG_EXTERNAL_PORT:-5003}
        
        # Port-forwards work through localhost regardless of cluster type (KIND, GKE, etc.)
        local config_host="localhost"
        local namespace="bito-ai-architect"
        
        # CRITICAL FIX: Wait for pods to be ready BEFORE setting up port-forwards
        # This ensures services are operational before API calls
        log_silent "Waiting for pods to be ready after restart..."
        if wait_for_k8s_services "$namespace" 180; then
            log_silent "All pods are ready"
        else
            print_warning "Some pods may still be initializing"
        fi
        
        # Capture service logs after pods are ready
        if [ -f "${SCRIPT_DIR}/scripts/unified-log-manager.sh" ]; then
            "${SCRIPT_DIR}/scripts/unified-log-manager.sh" sync || true
        fi
        
        # Clean up any stale port-forwards before creating new ones
        # (especially important after --force-restart when old pods are terminated)
        log_silent "Cleaning up old port-forwards..."
        pkill -f "kubectl.*port-forward.*${namespace}" 2>/dev/null || true
        sleep 2  # Brief pause to let processes die
        
        # Now setup port-forwards to healthy pods
        setup_port_forwards "$namespace"
        
        export CONFIG_URL="http://${config_host}:${CIS_CONFIG_EXTERNAL_PORT}"
        export CIS_CONFIG_EXTERNAL_PORT
        export DEPLOYMENT_TYPE="kubernetes"
    else
        # Docker: source .env-bitoarch and export necessary variables
        if [ -f "$ENV_FILE" ]; then
            source "$ENV_FILE"
            export CONFIG_URL="http://localhost:${CIS_CONFIG_EXTERNAL_PORT}"
            export DEPLOYMENT_TYPE="docker-compose"
        fi
    fi
}

# Ask user for deployment method
ask_deployment_method() {
    # Check if deployment type already exists (from previous setup)
    local existing_deployment=$(get_deployment_type)
    
    if [ "$existing_deployment" != "unknown" ]; then
        local deployment_display=""
        if [ "$existing_deployment" = "kubernetes" ]; then
            deployment_display="Kubernetes"
        else
            deployment_display="Docker Compose"
        fi
        
        print_info "Using existing deployment method: $deployment_display"
        DEPLOYMENT_METHOD="$existing_deployment"
        
        # Re-validate K8s prerequisites if kubernetes
        if [ "$DEPLOYMENT_METHOD" = "kubernetes" ]; then
            if ! check_k8s_prerequisites; then
                render_k8s_not_available_block
                exit 1
            fi
        fi
        return 0
    fi
    
    echo ""
    echo -e "${BLUE}=== Deployment Method ===${NC}"
    echo "Choose how to deploy Bito's AI Architect:"
    echo "  1) Docker Compose"
    echo "  2) Kubernetes (requires existing K8s cluster)"
    echo ""

    local choice=""
    read -p "Select deployment method [1-2, default: 1]: " choice
    choice=${choice:-1}

    case $choice in
        1)
            DEPLOYMENT_METHOD="docker-compose"
            print_info "Selected: Docker Compose"
            save_deployment_type "docker-compose"
            return 0
            ;;
        2)
            DEPLOYMENT_METHOD="kubernetes"
            print_info "Selected: Kubernetes"

            # Check K8s prerequisites (with auto-install)
            if ! check_k8s_prerequisites; then
                render_k8s_not_available_block
                exit 1
            fi
            
            save_deployment_type "kubernetes"
            return 0
            ;;
        *)
            print_warning "Invalid choice, using Docker Compose"
            DEPLOYMENT_METHOD="docker-compose"
            save_deployment_type "docker-compose"
            return 0
            ;;
    esac
}

# Deploy to Kubernetes
deploy_kubernetes() {
    log_silent "Deploying to Kubernetes..."
    
    # Source values-generator functions
    source "${SCRIPT_DIR}/scripts/values-generator.sh"
    
    # Extract latest provider default.json from image to update helm chart ConfigMap
    # This ensures fresh K8s deployments have the latest config from the image
    log_silent "Extracting latest provider configuration from image..."

    # Source env to get provider image
    if [ -f "$ENV_FILE" ]; then
        source "$ENV_FILE"
    fi

    local provider_image="${CIS_PROVIDER_IMAGE:-}"
    local helm_config_path="${SCRIPT_DIR}/helm-bitoarch/services/cis-provider/config/default.json"

    if [ -n "$provider_image" ]; then
        # Pull the image first to ensure we have the latest
        if docker pull "$provider_image" >> "$LOG_FILE" 2>&1; then
            # Create temp container and extract config
            if docker create --name temp-provider-config-fresh "$provider_image" >/dev/null 2>&1; then
                if docker cp temp-provider-config-fresh:/opt/bito/xmcp/config/default.json "$helm_config_path" 2>> "$LOG_FILE"; then
                    log_silent "Provider configuration extracted for Helm chart"
                else
                    print_warning "Could not extract provider config from image, using packaged config"
                fi
                docker rm temp-provider-config-fresh >/dev/null 2>&1 || true
            else
                print_warning "Could not create temp container for config extraction"
            fi
        else
            print_warning "Could not pull provider image for config extraction, using packaged config"
        fi
    else
        print_warning "Provider image not set, using packaged config"
    fi

    # Generate K8s values file from .env-bitoarch
    log_silent "Generating Kubernetes values from environment configuration..."

    # Get values file path from path-manager
    local values_file
    if type get_k8s_values_file >/dev/null 2>&1; then
        values_file=$(get_k8s_values_file)
    else
        values_file="${SCRIPT_DIR}/.bitoarch-values.yaml"
    fi
    
    if ! generate_k8s_values_from_env; then
        print_error "Failed to generate Kubernetes values"
        return 1
    fi
    
    log_silent "Generated Kubernetes values file: $values_file"
    
    # Deploy via Helm
    local namespace="bito-ai-architect"
    local chart_dir="${SCRIPT_DIR}/helm-bitoarch"
    
    if [ ! -f "$values_file" ]; then
        print_error "Values file not found: $values_file"
        return 1
    fi
    
    # Deploy
    if deploy_helm_chart "$chart_dir" "$values_file" "$namespace"; then
        if wait_for_k8s_services "$namespace"; then
            log_silent "Kubernetes deployment successful"
            get_k8s_service_status "$namespace"
            get_k8s_endpoints "$namespace"
            return 0
        else
            print_error "Kubernetes services failed to become ready"
            return 1
        fi
    else
        print_error "Helm deployment failed"
        return 1
    fi
}

# Silently restart/wait on the Temporal StatefulSet during k8s restart/update flows.
# action: "restart" restarts then waits; "status-only" just waits for rollout.
# log_target: file to capture kubectl output (default /dev/null).
# Returns non-zero if the rollout status times out or fails.
handle_temporal_statefulset() {
    local action="$1"
    local namespace="$2"
    local log_target="${3:-/dev/null}"
    if [[ "$action" == "restart" ]]; then
        kubectl rollout restart statefulset ai-architect-temporal -n "$namespace" >>"$log_target" 2>&1 || true
    fi
    kubectl rollout status statefulset ai-architect-temporal -n "$namespace" --timeout=3m >>"$log_target" 2>&1
}

# Silently run a docker-compose subcommand against the Temporal service.
# subcmd: the compose subcommand + flags, e.g. "restart", "pull",
#         "up -d --force-recreate", "up -d --force-recreate --no-deps".
# log_target: file to capture compose output (default /dev/null).
# Requires $compose_cmd to be defined in the caller's scope.
run_temporal_compose() {
    local subcmd="$1"
    local log_target="${2:-/dev/null}"
    eval "$compose_cmd --env-file .env-bitoarch $subcmd ai-architect-temporal" >>"$log_target" 2>&1
}

# Returns 0 if the service is shown to users, 1 if it's an internal-only
# dependency (status/progress goes to log_silent, not the terminal).
is_user_facing_service() {
    case "$1" in
        ai-architect-tracker) return 1 ;;
        *) return 0 ;;
    esac
}

main() {
    # Set up traps only for main deployment flow
    trap cleanup_on_error ERR
    trap cleanup_on_sigint SIGINT
    trap cleanup_on_sigterm SIGTERM
    
    # Rotate setup.log if needed before starting
    if [ -f "${SCRIPT_DIR}/scripts/unified-log-manager.sh" ]; then
        "${SCRIPT_DIR}/scripts/unified-log-manager.sh" rotate-setup 2>/dev/null || true
    fi
    
    echo -e "${BLUE}Bito's AI Architect - Installation${NC}"
    echo "===================================="
    echo ""

    # CRITICAL FIX: Create standard directories BEFORE any file operations
    # This prevents "No such file or directory" errors when saving deployment type
    local layout=$(get_layout)
    if [ "$layout" = "system" ] || [ "$layout" = "user" ]; then
        if ! create_standard_dirs "$layout" 2>/dev/null; then
            print_warning "Failed to create $layout directories, falling back to user layout"
            # Force user layout fallback
            export BITOARCH_LAYOUT="user"
            init_paths
            ENV_FILE="$(get_config_file)"
            ENV_LLM_FILE="$(get_llm_config_file)"
            LOG_FILE="$(get_setup_log)"
            if ! create_standard_dirs "user" 2>/dev/null; then
                print_error "Cannot create user directories, installation cannot proceed"
                exit 1
            fi
            log_silent "Forced fallback to user layout at ~/.local/bitoarch"
        fi
    fi

    # Ensure log directory exists before creating log file
    mkdir -p "$(dirname "$LOG_FILE")" 2>/dev/null || {
        if command -v sudo >/dev/null 2>&1; then
            sudo mkdir -p "$(dirname "$LOG_FILE")"
            sudo chown -R "$USER:$(id -gn)" "$(dirname "$LOG_FILE")"
        fi
    }

    touch "$LOG_FILE"

    touch "$LOG_FILE"
    log_silent "Bito's AI Architect setup started at $(date)"
    log_silent "Working directory: $SCRIPT_DIR"
    log_silent "Log file: $LOG_FILE"
    log_silent "Using layout: $(get_layout)"
    log_silent "Config directory: $(get_config_dir)"

    # Check if migration from legacy installation is needed
    if needs_migration && [ ! -f "$ENV_FILE" ]; then
        print_info "Legacy installation detected - migration will occur during first setup"
        log_silent "Migration will be triggered: legacy layout detected"
    fi

    check_prerequisites
    install_cli

    # Auto-migrate if this is an upgrade from legacy installation
    if needs_migration && [ -f "${PLATFORM_DIR}/.env-bitoarch" ]; then
        print_info "Migrating from legacy installation to standard Unix paths..."
        if "${SCRIPT_DIR}/scripts/migrate-to-standard-paths.sh" --auto; then
            print_status "Migration completed successfully"
            # Reinitialize paths after migration
            init_paths
            ENV_FILE="$(get_config_file)"
            ENV_LLM_FILE="$(get_llm_config_file)"
            LOG_FILE="$(get_setup_log)"
        else
            print_error "Migration failed"
            exit 1
        fi
    fi

    check_existing_services

    # Ask for deployment method (skipped when DEPLOYMENT_METHOD is already set,
    # e.g. by the Standalone install bootstrap which hard-codes docker-compose,
    # or by a user env-var pre-fill for non-interactive K8s installs).
    if [ -z "${DEPLOYMENT_METHOD:-}" ]; then
        ask_deployment_method
    else
        # Persist so post-install CLI (bitoarch status / logs / info) branches
        # correctly. The env-var pre-fill path bypasses ask_deployment_method,
        # which is where the save normally happens; do it here so K8s installs
        # don't fall back to Docker logic in the CLI.
        save_deployment_type "$DEPLOYMENT_METHOD"
    fi
    
    # Check ports based on deployment method (before collecting credentials)
    if [ "$DEPLOYMENT_METHOD" = "kubernetes" ]; then
        check_k8s_external_ports
    else
        check_docker_ports
    fi
    
    # CRITICAL: Create directories BEFORE generating env file
    # This ensures /usr/local/etc/bitoarch/ exists before we try to copy files there
    prepare_data_directories

    # Now collect credentials (only if ports are available)
    generate_env_file
    
    # Deploy based on selected method
    if [ "$DEPLOYMENT_METHOD" = "kubernetes" ]; then
        # Kubernetes deployment path
        log_silent "Deployment method: Kubernetes"
        
        if deploy_kubernetes; then
            # Kubernetes deployment: Always use localhost with port-forwards
            local namespace="bito-ai-architect"
            local config_host="localhost"
            
            # Read port from .env-bitoarch if available
            if [ -f "$ENV_FILE" ]; then
                source "$ENV_FILE"
            fi
            if [ -z "$CIS_CONFIG_EXTERNAL_PORT" ] && [ -f "${SCRIPT_DIR}/.env-bitoarch.default" ]; then
                CIS_CONFIG_EXTERNAL_PORT=$(grep "^CIS_CONFIG_EXTERNAL_PORT=" "${SCRIPT_DIR}/.env-bitoarch.default" 2>/dev/null | cut -d'=' -f2 || echo "5003")
            fi
            CIS_CONFIG_EXTERNAL_PORT=${CIS_CONFIG_EXTERNAL_PORT:-5003}
            
            # Export CONFIG_URL with localhost (port-forwards work on all K8s clusters)
            export CONFIG_URL="http://${config_host}:${CIS_CONFIG_EXTERNAL_PORT}"
            export CIS_CONFIG_EXTERNAL_PORT
            export DEPLOYMENT_TYPE="kubernetes"
            
            # CRITICAL: Verify pods are still ready before setting up port-forwards
            # (they should be from deploy_kubernetes, but double-check for reliability)
            log_silent "Verifying pods are ready before configuration..."
            if wait_for_k8s_services "$namespace" 60; then
                log_silent "All pods are ready"
            else
                print_warning "Some pods may still be initializing"
            fi
            
            # Capture service logs after pods are ready
            if [ -f "${SCRIPT_DIR}/scripts/unified-log-manager.sh" ]; then
                "${SCRIPT_DIR}/scripts/unified-log-manager.sh" sync || true
            fi

            # Setup port-forwards for CLI access to healthy pods
            setup_port_forwards "bito-ai-architect"
            
            # Capture return code without triggering set -e error trap
            local config_result=0
            setup_configuration || config_result=$?

            # Only show full success block for fresh setups (return 0 or 1)
            # Skip for existing config unchanged (return 2)
            if [ $config_result -ne 2 ]; then
                # Skip SSO prompt when caller requests it (e.g. Standalone
                # install, which defers SSO to post-install via `bitoarch sso setup`).
                [ "${SKIP_SSO_PROMPT:-false}" = "true" ] || prompt_sso_setup
                display_success
                log_silent "Bito's AI Architect setup completed successfully at $(date)"
            else
                log_silent "Repository configuration unchanged - setup completed at $(date)"
                exit 0
            fi
        else
            print_error "Kubernetes deployment failed"
            print_info "Check detailed logs: $LOG_FILE"
            exit 1
        fi
    else
        # Docker Compose deployment path (existing flow)
        log_silent "Deployment method: Docker Compose"

        prepare_service_sql_scripts  # Copy service SQL scripts to MySQL init directory

        # Pre-compose-up: provision HTTPS cert + flip XMCP_INTERNAL_PORT.
        # Self-gating on MCP_TRANSPORT=https; harmless on http installs.
        if [ -f "${SCRIPT_DIR}/scripts/lib/mcp-cert.sh" ]; then
            # shellcheck disable=SC1091
            source "${SCRIPT_DIR}/scripts/lib/mcp-cert.sh"
            mcp_cert_prepare_for_compose 2>/dev/null || true
        fi

        deploy_services

        if wait_for_services; then
            validate_deployment
            render_deploy_success_banner

            # Capture service logs after initial deployment
            if [ -f "${SCRIPT_DIR}/scripts/unified-log-manager.sh" ]; then
                "${SCRIPT_DIR}/scripts/unified-log-manager.sh" sync || true
            fi

            # Capture return code without triggering set -e error trap
            local config_result=0
            setup_configuration || config_result=$?

            # Only show full success block for fresh setups (return 0 or 1)
            # Skip for existing config unchanged (return 2)
            if [ $config_result -ne 2 ]; then
                # Skip SSO prompt when caller requests it (e.g. Standalone
                # install, which defers SSO to post-install via `bitoarch sso setup`).
                [ "${SKIP_SSO_PROMPT:-false}" = "true" ] || prompt_sso_setup
                display_success
            fi

            log_silent "Bito's AI Architect setup completed successfully at $(date)"
        else
            echo ""
            print_error "Service health check failed"
            print_info "Check detailed logs: $LOG_FILE"
            print_info "View service logs: ${DOCKER_COMPOSE_CMD:-docker-compose} logs"
            
            # Show CLI installation status
            local cli_target="$HOME/.local/bin/bitoarch"
            if [ -L "$cli_target" ] || [ -f "$cli_target" ]; then
                echo ""
                print_status "CLI installed to ~/.local/bin/bitoarch"
                print_info "To activate: source ~/.${SHELL##*/}rc (or restart terminal)"
            fi
            
            exit 1
        fi
    fi
}

show_status() {
    echo -e "${BLUE}AI Architect - Service Status${NC}"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo ""
    
    local running_services=$(docker ps -q --filter "name=ai-architect-" 2>/dev/null | wc -l)
    
    if [ "$running_services" -eq 0 ]; then
        print_warning "No AI Architect services are currently running"
        echo ""
        # Unified CLI: bitoarch is installed by setup.sh in both prod and
        # standalone, so this hint works in both modes.
        print_info "To start services, run: ${YELLOW}bitoarch start${NC}"
        return 0
    fi
    
    local services=(
        "ai-architect-mysql:MySQL Database:3306"
        "ai-architect-config:AI Architect Config:8081"
        "ai-architect-manager:AI Architect Manager:9090"
        "ai-architect-provider:AI Architect Provider:8080"
        "ai-architect-worker:AI Architect Worker:"
    )
    
    echo -e "${BLUE}📊 Service Health & Status${NC}"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    
    for service_info in "${services[@]}"; do
        local container_name=$(echo "$service_info" | cut -d: -f1)
        local display_name=$(echo "$service_info" | cut -d: -f2)
        local port=$(echo "$service_info" | cut -d: -f3)
        
        if ! docker ps -a --format '{{.Names}}' | grep -q "^${container_name}$"; then
            printf "   %-25s ${YELLOW}➖ Not Created${NC}\n" "$display_name"
            continue
        fi
        
        local status=$(docker inspect --format='{{.State.Status}}' "$container_name" 2>/dev/null || echo "unknown")
        local health=$(docker inspect --format='{{.State.Health.Status}}' "$container_name" 2>/dev/null || echo "no_health")
        
        local running_time=0
        local started_at=$(docker inspect --format='{{.State.StartedAt}}' "$container_name" 2>/dev/null)
        
        if [ -n "$started_at" ] && [ "$started_at" != "0001-01-01T00:00:00Z" ]; then
            local clean_time=$(echo "$started_at" | sed 's/\.[0-9]*Z$/Z/')
            
            local start_epoch=""
            if [[ "$OSTYPE" == "darwin"* ]]; then
                local time_no_z=$(echo "$clean_time" | sed 's/Z$//')
                start_epoch=$(date -u -j -f "%Y-%m-%dT%H:%M:%S" "$time_no_z" "+%s" 2>/dev/null || echo "")
            else
                start_epoch=$(date -d "$clean_time" "+%s" 2>/dev/null || echo "")
            fi
            
            if [ -n "$start_epoch" ] && [ "$start_epoch" -gt 0 ]; then
                local now=$(date +%s)
                running_time=$((now - start_epoch))
            fi
        fi
        
        local uptime_str=""
        if [ "$running_time" -gt 0 ]; then
            if [ "$running_time" -lt 60 ]; then
                uptime_str="${running_time}s"
            elif [ "$running_time" -lt 3600 ]; then
                uptime_str="$((running_time / 60))m"
            else
                uptime_str="$((running_time / 3600))h"
            fi
        fi
        
        # Build detail string — conditionally include port
        local detail_str=""
        if [ -n "$port" ]; then
            detail_str="(up ${uptime_str}, port ${port})"
        else
            detail_str="(up ${uptime_str})"
        fi
        local static_detail=""
        if [ -n "$port" ]; then
            static_detail="(port ${port})"
        fi

        case "$status" in
            "running")
                if [[ "$health" == "healthy" ]]; then
                    printf "   %-25s ${GREEN}✅ Healthy${NC}      ${detail_str}\n" "$display_name"
                elif [[ "$health" == "starting" ]]; then
                    printf "   %-25s ${YELLOW}⏳ Starting${NC}     ${detail_str}\n" "$display_name"
                elif [[ "$health" == "unhealthy" ]]; then
                    printf "   %-25s ${RED}⚠️  Unhealthy${NC}   ${detail_str}\n" "$display_name"
                else
                    printf "   %-25s ${GREEN}✅ Running${NC}      ${detail_str}\n" "$display_name"
                fi
                ;;
            "restarting")
                printf "   %-25s ${YELLOW}🔄 Restarting${NC}   ${static_detail}\n" "$display_name"
                ;;
            "exited"|"dead")
                printf "   %-25s ${RED}⏹️  Stopped${NC}      ${static_detail}\n" "$display_name"
                ;;
            "created")
                printf "   %-25s ${YELLOW}📦 Created${NC}      ${static_detail}\n" "$display_name"
                ;;
            *)
                printf "   %-25s ${YELLOW}❓ Unknown${NC}      ${static_detail}\n" "$display_name"
                ;;
        esac
    done
    
    echo ""
    echo -e "${BLUE}🔧 Quick Commands${NC}"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo -e "  • View logs:                 ${YELLOW}bitoarch logs${NC}"
    echo -e "  • Restart services:          ${YELLOW}bitoarch restart${NC}"
    echo -e "  • Force Restart services:    ${YELLOW}bitoarch restart --force${NC}"
    echo -e "  • Stop services:             ${YELLOW}bitoarch stop${NC}"
    echo ""
}

show_help() {
    echo "AI Architect Setup Script"
    echo ""
    echo "Usage: $0 [options]"
    echo ""
    echo "Options:"
    echo "  --help, -h        Show this help message"
    echo "  --status          Show current service status"
    echo "  --logs            Show service logs"
    echo "  --stop            Stop all services (preserves containers)"
    echo "  --restart         Restart all services"
    echo "  --force-restart   Restart all services and reapply env variables"
    echo "  --update          Force pull latest images based on service-versions.json and restart services"
    echo "  --clean           Remove all data and services"
    echo ""
}

# Source guard: when setup.sh is sourced by another script (e.g. Standalone's
# scripts/lib/install.sh delegating to main()), the CLI dispatcher below must
# NOT auto-run. When setup.sh is executed directly (legacy production flow),
# everything runs as before.
if [ "${BASH_SOURCE[0]}" != "${0}" ]; then
    return 0 2>/dev/null || true
fi

case "${1:-}" in
    --help|-h)
        show_help
        ;;
    --status)
        # Check deployment type
        DEPLOYMENT_TYPE=$(get_deployment_type)
        
        if [ "$DEPLOYMENT_TYPE" = "kubernetes" ]; then
            # Kubernetes status
            namespace="bito-ai-architect"
            
            # Check if any deployments exist and are running (not scaled to 0)
            deployment_count=$(kubectl get deployment -n "$namespace" -l "app.kubernetes.io/name=bitoarch" 2>/dev/null | wc -l | xargs)
            
            if [ "$deployment_count" -le 1 ]; then
                # No deployments found (only header line or namespace doesn't exist)
                echo -e "${BLUE}AI Architect - Service Status${NC}"
                echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
                echo ""
                print_warning "No AI Architect services are currently running"
                echo ""
                print_info "To start services, run: ${YELLOW}bitoarch start${NC}"
                exit 0
            fi
            
            # Check if deployments are scaled to 0 (stopped)
            running_replicas=$(kubectl get deployment -n "$namespace" -l "app.kubernetes.io/name=bitoarch" -o jsonpath='{.items[*].spec.replicas}' 2>/dev/null | tr ' ' '+' | bc 2>/dev/null || echo "0")
            
            if [ "$running_replicas" -eq 0 ]; then
                # Deployments exist but are scaled to 0 (stopped)
                echo -e "${BLUE}AI Architect - Service Status${NC}"
                echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
                echo ""
                print_warning "No AI Architect services are currently running"
                echo ""
                print_info "To start services, run: ${YELLOW}bitoarch start${NC}"
                exit 0
            fi
            
            get_k8s_service_status "$namespace"
            get_k8s_endpoints "$namespace"
        else
            # Docker Compose status
            show_status
        fi
        ;;
    --logs)
        # Check deployment type
        DEPLOYMENT_TYPE=$(get_deployment_type)
        
        if [ "$DEPLOYMENT_TYPE" = "kubernetes" ]; then
            # Kubernetes logs
            namespace="bito-ai-architect"
            get_k8s_logs "$namespace" "" "true"
        else
            # Docker Compose logs
            compose_cmd="${DOCKER_COMPOSE_CMD:-}"
            if [ -z "$compose_cmd" ]; then
                if command -v docker >/dev/null 2>&1 && docker compose version >/dev/null 2>&1; then
                    compose_cmd="docker compose"
                elif command -v docker-compose >/dev/null 2>&1; then
                    compose_cmd="docker-compose"
                else
                    print_error "Neither 'docker compose' nor 'docker-compose' found"
                    exit 1
                fi
            fi
            eval "${compose_cmd} --env-file \"${ENV_FILE}\" logs -f"
        fi
        ;;
    --stop)
        print_info "Stopping Bito's AI Architect services..."
        
        # Check deployment type
        DEPLOYMENT_TYPE=$(get_deployment_type)
        
        if [ "$DEPLOYMENT_TYPE" = "kubernetes" ]; then
            # Kubernetes stop (scale to 0 + delete services to free NodePorts)
            namespace="bito-ai-architect"
            
            # Check if services are running (not already stopped/scaled to 0)
            if ! check_k8s_services_running "$namespace"; then
                render_services_not_running_block
                exit 0
            fi
            
            # Capture logs BEFORE stopping (while pods still exist)
            if [ -f "${SCRIPT_DIR}/scripts/unified-log-manager.sh" ]; then
                "${SCRIPT_DIR}/scripts/unified-log-manager.sh" sync || true
            fi
            
            print_info "Stopping Kubernetes deployment..."
            
            # Kill port-forwards first (so they don't point to deleted pods)
            if command -v kill_port_forwards >/dev/null 2>&1; then
                kill_port_forwards "$namespace"
            else
                # Inline cleanup if function not available
                PF_PIDS=$(ps aux | grep "kubectl port-forward" | grep -E "(-n |--namespace=|-n=)$namespace" | grep -v grep | awk '{print $2}')
                if [ -n "$PF_PIDS" ]; then
                    print_info "Terminating port-forwards..."
                    echo "$PF_PIDS" | xargs kill -9 2>/dev/null || true
                fi
            fi
            
            if kubectl scale deployment --all --replicas=0 -n "$namespace" >/dev/null 2>&1; then
                print_info "Pods stopped (scaled to 0 replicas)"
            else
                print_warning "Failed to scale deployments"
            fi

            # Temporal is a StatefulSet (helm-bitoarch/templates/16-temporal-statefulset.yaml)
            # — `kubectl scale deployment --all` does NOT touch StatefulSets, so scale them
            # to 0 explicitly. `|| true` keeps stop idempotent for installs without any
            # StatefulSets.
            kubectl scale statefulset --all --replicas=0 -n "$namespace" >/dev/null 2>&1 || true

            # Delete services to free NodePorts (matching Docker Compose behavior)
            if kubectl delete svc --all -n "$namespace" >/dev/null 2>&1; then
                print_status "Services deleted - NodePorts freed"
            else
                print_warning "Failed to delete services"
            fi
            
            print_status "Kubernetes deployment stopped"
        else
            # Docker Compose stop
            compose_cmd="${DOCKER_COMPOSE_CMD:-}"
            if [ -z "$compose_cmd" ]; then
                if command -v docker >/dev/null 2>&1 && docker compose version >/dev/null 2>&1; then
                    compose_cmd="docker compose"
                elif command -v docker-compose >/dev/null 2>&1; then
                    compose_cmd="docker-compose"
                else
                    print_error "Neither 'docker compose' nor 'docker-compose' found"
                    exit 1
                fi
            fi
            
            # Capture logs BEFORE stopping (while containers still exist)
            if [ -f "${SCRIPT_DIR}/scripts/unified-log-manager.sh" ]; then
                "${SCRIPT_DIR}/scripts/unified-log-manager.sh" sync || true
            fi
            
            # Stop services (preserve containers for quick restart).
            # Use absolute paths for both -f and --env-file so the command
            # works regardless of the caller's CWD (bitoarch stop is invoked
            # from anywhere; dispatcher does not cd). ENV_FILE is path-manager-
            # resolved; COMPOSE_FILE is pinned to the repo root.
            compose_file="${SCRIPT_DIR}/docker-compose.yml"
            compose_base="$compose_cmd -f \"$compose_file\""
            if [ -f "$ENV_FILE" ]; then
                compose_base="$compose_base --env-file \"$ENV_FILE\""
            fi
            if eval "$compose_base stop" >> "$LOG_FILE" 2>&1; then
                print_status "Services stopped (containers preserved)"
            else
                print_error "Failed to stop services"
                print_info "Trying force stop..."
                eval "$compose_base kill" >> "$LOG_FILE" 2>&1 || true
            fi
        fi
        
        render_stop_complete_block
        ;;
    --clean)
        # Shared with scripts/lib/uninstall.sh; CLI symlink preserved here.
        # shellcheck disable=SC1091
        source "${SCRIPT_DIR}/scripts/lib/reset.sh"
        reset_run
        ;;
    --from-existing-config)
        print_info "Starting AI Architect with existing configuration..."
        
        # Check if config exists
        if [[ ! -f ".env-bitoarch" ]]; then
            print_error "No existing configuration found (.env-bitoarch missing)"
            exit 1
        fi
        
        # Must call check_prerequisites to initialize DOCKER_COMPOSE_CMD
        check_prerequisites
        install_cli
        check_existing_services
        check_ports
        prepare_data_directories
        prepare_service_sql_scripts

        if [ -f "${SCRIPT_DIR}/scripts/lib/mcp-cert.sh" ]; then
            # shellcheck disable=SC1091
            source "${SCRIPT_DIR}/scripts/lib/mcp-cert.sh"
            mcp_cert_prepare_for_compose 2>/dev/null || true
        fi

        # Now deploy with existing config
        deploy_services
        
        if wait_for_services; then
            validate_deployment
            print_status "Services started successfully with existing configuration"
        else
            print_error "Service health check failed"
            exit 1
        fi
        exit 0
        ;;
    --restart)
        print_info "Restarting AI Architect services..."
        
        # Check deployment type
        DEPLOYMENT_TYPE=$(get_deployment_type)
        
        if [ "$DEPLOYMENT_TYPE" = "kubernetes" ]; then
            namespace="bito-ai-architect"

            # NOTE: --restart is the back-end for both `bitoarch restart` (bounce
            # running services) AND `bitoarch start` (come up from a stopped
            # state). `bitoarch stop` scales deployments to 0 and deletes
            # Services to free NodePorts, so the "stopped" state we must handle
            # here is exactly: release exists, deployments at 0 replicas,
            # Services deleted. We do NOT early-exit when services are not
            # running -- that is the path that leads to redeploy below.

            # Capture logs BEFORE restart (while old pods still exist)
            if [ -f "${SCRIPT_DIR}/scripts/unified-log-manager.sh" ]; then
                "${SCRIPT_DIR}/scripts/unified-log-manager.sh" sync || true
            fi

            # Check if services exist (trim whitespace from wc -l for macOS/Linux compatibility)
            svc_count=$(kubectl get svc -n "$namespace" 2>/dev/null | wc -l | xargs)

            if [ "$svc_count" -le 1 ]; then
                # Services were deleted (only header line), need to redeploy via Helm
                print_info "Services were stopped, redeploying..."

                # Source values-generator to regenerate if needed
                source "${SCRIPT_DIR}/scripts/values-generator.sh"

                # Values file lives under the path-manager-resolved config
                # dir (e.g. /usr/local/etc/bitoarch), NOT SCRIPT_DIR. Fall
                # back to SCRIPT_DIR only when path-manager isn't loaded.
                values_file=""
                if type get_k8s_values_file >/dev/null 2>&1; then
                    values_file=$(get_k8s_values_file)
                fi
                [ -z "$values_file" ] && values_file="${SCRIPT_DIR}/.bitoarch-values.yaml"

                # Regenerate the values file if it's missing (generator
                # writes to the same get_k8s_values_file location).
                if [ ! -f "$values_file" ]; then
                    print_info "Regenerating Kubernetes values..."
                    if ! generate_k8s_values_from_env; then
                        print_error "Failed to generate Kubernetes values"
                        exit 1
                    fi
                fi

                # Redeploy via Helm (will recreate services and scale up)
                if helm upgrade bitoarch "${SCRIPT_DIR}/helm-bitoarch" \
                    --namespace "$namespace" \
                    --values "$values_file" \
                    --wait \
                    --timeout "${K8S_HELM_TIMEOUT:-10m}" >/dev/null 2>&1; then
                    print_status "Services redeployed successfully"
                else
                    print_error "Failed to redeploy services"
                    exit 1
                fi
            else
                # Services exist, just restart pods
                echo ""
                log_silent "Restarting deployments in order..."
                
                # Restart all deployments at once (parallel for speed)
                if ! kubectl -n "$namespace" rollout restart deployment -l "app.kubernetes.io/name=bitoarch" >/dev/null 2>&1; then
                    echo ""
                    print_error "Failed to initiate restart"
                    print_info "Check logs: kubectl logs -n $namespace"
                    exit 1
                fi

                # Temporal is a StatefulSet, not a Deployment — restart it separately
                kubectl -n "$namespace" rollout restart statefulset -l "app.kubernetes.io/name=bitoarch" >/dev/null 2>&1 || true

                # User-facing services only (tracker is background). Per-deployment
                # rollout status is tracked silently via log_silent; we emit a
                # single summary line at the end for a compact UX consistent
                # with `bitoarch restart` Docker path.
                deployments=("ai-architect-mysql" "ai-architect-config" "ai-architect-manager" "ai-architect-provider" "ai-architect-tracker" "ai-architect-temporal" "ai-architect-worker")
                restart_failed=false

                for deployment in "${deployments[@]}"; do
                    if [[ "$deployment" == "ai-architect-temporal" ]]; then
                        handle_temporal_statefulset "status-only" "$namespace" || restart_failed=true
                        continue
                    fi

                    # Tracker needs longer timeout due to init container dependencies on config/manager
                    timeout="3m"
                    if [[ "$deployment" == "ai-architect-tracker" ]]; then
                        timeout="10m"
                    fi

                    is_user_facing_service "$deployment" && printf "   %-25s" "$deployment"

                    # Check if deployment rolled out successfully
                    if kubectl rollout status deployment "$deployment" -n "$namespace" --timeout=3m >/dev/null 2>&1; then
                        log_silent "  ✅ $deployment restarted"
                    else
                        log_silent "  ⏱ $deployment timed out"
                        restart_failed=true
                    fi
                done

                if [ "$restart_failed" = true ]; then
                    print_warning "Some deployments timed out"
                    print_info "Services may still be starting - check status: ${YELLOW}bitoarch status${NC}"
                else
                    print_status "All deployments restarted successfully"
                    print_info "Check status: ${YELLOW}bitoarch status${NC}"
                fi
            fi
            
            # Setup environment for config API calls (works for both Docker & K8s)
            setup_env_for_config
            
            # Ask if user wants to reconfigure repos after restart
            # Capture return code without triggering set -e error trap
            setup_configuration || true
        else
            # Docker Compose restart
            compose_cmd="${DOCKER_COMPOSE_CMD:-}"
            if [ -z "$compose_cmd" ]; then
                if command -v docker >/dev/null 2>&1 && docker compose version >/dev/null 2>&1; then
                    compose_cmd="docker compose"
                elif command -v docker-compose >/dev/null 2>&1; then
                    compose_cmd="docker-compose"
                else
                    print_error "Neither 'docker compose' nor 'docker-compose' found"
                    exit 1
                fi
            fi

            # Check if services are running
            running_services=$(docker ps -q --filter "name=ai-architect-" 2>/dev/null | wc -l)
            if [ "$running_services" -eq 0 ]; then
                render_services_not_running_block
                exit 0
            fi

            # Capture logs BEFORE restart (while old containers still exist)
            if [ -f "${SCRIPT_DIR}/scripts/unified-log-manager.sh" ]; then
                "${SCRIPT_DIR}/scripts/unified-log-manager.sh" sync || true
            fi

            # Restart all services
            echo ""

            # `docker compose restart` does not honor depends_on; cis-manager
            # and cis-config panic if MySQL isn't ready. Use `stop + up -d`
            # so compose gates dependents on MySQL healthy.
            services="ai-architect-mysql ai-architect-temporal ai-architect-config ai-architect-manager ai-architect-worker ai-architect-provider ai-architect-tracker"
            restart_failed=false

            if eval "$compose_cmd -f \"${SCRIPT_DIR}/docker-compose.yml\" --env-file \"$ENV_FILE\" stop $services" >/dev/null 2>&1 && \
               eval "$compose_cmd -f \"${SCRIPT_DIR}/docker-compose.yml\" --env-file \"$ENV_FILE\" up -d $services" >/dev/null 2>&1; then
                print_status "All services restarted successfully"
                print_info "Check status: ${YELLOW}bitoarch status${NC}"
            else
                restart_failed=true
                print_warning "Restart failed"
                print_info "Check logs: ${YELLOW}bitoarch logs${NC}"
                exit 1
            fi
            
            # Ask if user wants to reconfigure repos after restart
            setup_configuration
        fi
        ;;
      --force-restart)
        print_info "Force Restarting AI Architect services with updated configuration..."

        # Backup .env-bitoarch before applying changes (silent)
        if [ -f "$ENV_FILE" ] && command -v backup_config_file >/dev/null 2>&1; then
            backup_config_file "$ENV_FILE" "env" >/dev/null 2>&1
        fi

        # Check deployment type
        DEPLOYMENT_TYPE=$(get_deployment_type)
        
        if [ "$DEPLOYMENT_TYPE" = "kubernetes" ]; then
            # Kubernetes force restart with config update
            namespace="bito-ai-architect"
            
            # Check if services are running (not stopped/scaled to 0)
            if ! check_k8s_services_running "$namespace"; then
                render_services_not_running_block
                exit 0
            fi
            
            # Capture logs BEFORE force restart (while old pods still exist)
            if [ -f "${SCRIPT_DIR}/scripts/unified-log-manager.sh" ]; then
                "${SCRIPT_DIR}/scripts/unified-log-manager.sh" sync || true
            fi
            
            log_silent "Regenerating Kubernetes configuration from .env-bitoarch..."

            # Reload install.yaml -> env_file BEFORE regenerating helm values,
            # so any user edits to $HOME/.bitoarch/install.yaml (api key,
            # ports, resource limits) flow into the K8s deployment. This
            # gives K8s prod the same live-reload contract as Docker.
            # No-op when yaml absent. Sources install-yaml.sh directly (not
            # install.sh) -- only the helpers are needed here.
            if [ -f "${SCRIPT_DIR}/scripts/lib/install-yaml.sh" ]; then
                # shellcheck disable=SC1091
                source "${SCRIPT_DIR}/scripts/lib/install-yaml.sh"
                command -v validate_install_yaml_api_key >/dev/null 2>&1 \
                    && { validate_install_yaml_api_key "$ENV_FILE" || exit 1; }
                command -v apply_install_yaml_to_env_file >/dev/null 2>&1 \
                    && apply_install_yaml_to_env_file "$ENV_FILE"
            fi

            # Regenerate values from .env-bitoarch
            source "${SCRIPT_DIR}/scripts/values-generator.sh"
            if ! generate_k8s_values_from_env; then
                print_error "Failed to regenerate Kubernetes values"
                exit 1
            fi
            
            log_silent "Configuration regenerated"
            
            # Apply updated configuration via Helm upgrade
            # Don't use --reuse-values with --values (contradictory flags cause conflicts)
            # Helm won't modify PVCs since their specs haven't changed - only ConfigMaps/Secrets are updated
            # Use get_k8s_values_file to get actual file path (supports standard Unix paths)
            k8s_values_file="$(get_k8s_values_file)"
            log_silent "Applying configuration update via Helm..."
            if helm upgrade bitoarch "${SCRIPT_DIR}/helm-bitoarch" \
                --namespace "$namespace" \
                --values "$k8s_values_file" \
                --wait \
                --timeout 5m 2>&1 | tee -a "$LOG_FILE" | grep -q "has been upgraded"; then
                log_silent "Configuration applied successfully"
            else
                print_warning "Helm upgrade may have timed out (check logs)"
                log_silent "Continuing with pod restart..."
            fi

            log_silent "Force restarting services with updated configuration..."

            # User-facing services only; tracker is a background service.
            # Per-deployment status goes to setup.log via log_silent; a single
            # summary line hits the terminal (compact UX, consistent with
            # bitoarch CLI path).
            deployments=("ai-architect-mysql" "ai-architect-config" "ai-architect-manager" "ai-architect-provider" "ai-architect-tracker" "ai-architect-temporal" "ai-architect-worker")
            restart_failed=false
            for deployment in "${deployments[@]}"; do

                if [[ "$deployment" == "ai-architect-temporal" ]]; then
                    handle_temporal_statefulset "restart" "$namespace" || restart_failed=true
                    continue
                fi

                is_user_facing_service "$deployment" && printf "   %-25s" "$deployment"

                if kubectl rollout restart deployment "$deployment" -n "$namespace" >/dev/null 2>&1; then
                    if kubectl rollout status deployment "$deployment" -n "$namespace" --timeout=$timeout >/dev/null 2>&1; then
                        log_silent "  ✅ $deployment restarted"
                    else
                        log_silent "  ⏱ $deployment timed out"
                        restart_failed=true
                    fi
                else
                    log_silent "  ❌ $deployment failed"
                    restart_failed=true
                fi
            done

            if [ "$restart_failed" = true ]; then
                print_warning "Some deployments failed or timed out"
                print_info "Check status: ${YELLOW}bitoarch status${NC}"
            else
                print_status "All services force restarted successfully with updated configuration"
                print_info "Check status: ${YELLOW}bitoarch status${NC}"
            fi
            
            # Setup environment for config API calls (works for both Docker & K8s)
            setup_env_for_config
            
            # Ask if user wants to reconfigure repos after restart
            # Capture return code without triggering set -e error trap
            setup_configuration || true
        else
            # Docker Compose force restart with config update
            
            # Determine docker compose command
            compose_cmd="${DOCKER_COMPOSE_CMD:-}"
            if [ -z "$compose_cmd" ]; then
                if command -v docker >/dev/null 2>&1 && docker compose version >/dev/null 2>&1; then
                    compose_cmd="docker compose"
                elif command -v docker-compose >/dev/null 2>&1; then
                    compose_cmd="docker-compose"
                else
                    print_error "Neither 'docker compose' nor 'docker-compose' found"
                    exit 1
                fi
            fi

            # Check if services are running
            running_services=$(docker ps -q --filter "name=ai-architect-" 2>/dev/null | wc -l)
            if [ "$running_services" -eq 0 ]; then
                render_services_not_running_block
                exit 0
            fi

            # Capture logs BEFORE force restart (while old containers still exist)
            if [ -f "${SCRIPT_DIR}/scripts/unified-log-manager.sh" ]; then
                "${SCRIPT_DIR}/scripts/unified-log-manager.sh" sync || true
            fi

            # Force recreate all services with updated environment
            echo ""
            log_silent "Force restarting services with updated configuration..."

            # Single `up -d --force-recreate` (no per-service loop, no
            # --no-deps) so compose gates config/manager on MySQL healthy.
            services="ai-architect-mysql ai-architect-temporal ai-architect-config ai-architect-manager ai-architect-worker ai-architect-provider ai-architect-tracker"
            restart_failed=false

            if eval "$compose_cmd -f \"${SCRIPT_DIR}/docker-compose.yml\" --env-file \"$ENV_FILE\" up -d --force-recreate $services" >/dev/null 2>&1; then
                print_status "All services force restarted successfully with updated configuration"
                print_info "Check status: ${YELLOW}bitoarch status${NC}"
            else
                restart_failed=true
                print_warning "Force restart failed"
                print_info "Check logs: ${YELLOW}bitoarch logs${NC}"
                exit 1
            fi
            
            # Ask if user wants to reconfigure repos after restart
            setup_configuration
        fi
        ;;
    --update)
        print_info "Updating AI Architect - Force pulling latest images and restarting services..."
        
        # Backup .env-bitoarch before update (silent)
        if [ -f "$ENV_FILE" ] && command -v backup_config_file >/dev/null 2>&1; then
            backup_config_file "$ENV_FILE" "env" >/dev/null 2>&1
        fi
        
        # Check deployment type
        DEPLOYMENT_TYPE=$(get_deployment_type)
        
        # Load service versions from versions/service-versions.json
        versions_file="${SCRIPT_DIR}/versions/service-versions.json"
        if [ ! -f "$versions_file" ]; then
            print_error "versions/service-versions.json not found"
            exit 1
        fi
        
        if [ "$DEPLOYMENT_TYPE" = "kubernetes" ]; then
            # Kubernetes update
            namespace="bito-ai-architect"
            
            # Check if services are running (not stopped/scaled to 0)
            if ! check_k8s_services_running "$namespace"; then
                render_services_not_running_block
                exit 0
            fi
            
            # Capture logs BEFORE update (while old pods still exist)
            if [ -f "${SCRIPT_DIR}/scripts/unified-log-manager.sh" ]; then
                "${SCRIPT_DIR}/scripts/unified-log-manager.sh" sync || true
            fi
            
            print_info "Pulling latest images for Kubernetes deployment..."
            echo ""
            
            # Read versions and images from service-versions.json
            if command -v jq >/dev/null 2>&1; then
                CIS_CONFIG_VERSION=$(jq -r '.services."cis-config".version' "$versions_file" 2>/dev/null || echo "latest")
                CIS_CONFIG_IMAGE_BASE=$(jq -r '.services."cis-config".image' "$versions_file" 2>/dev/null || echo "docker.io/bitoai/cis-config")
                
                CIS_MANAGER_VERSION=$(jq -r '.services."cis-manager".version' "$versions_file" 2>/dev/null || echo "latest")
                CIS_MANAGER_IMAGE_BASE=$(jq -r '.services."cis-manager".image' "$versions_file" 2>/dev/null || echo "docker.io/bitoai/cis-manager")
                
                CIS_PROVIDER_VERSION=$(jq -r '.services."cis-provider".version' "$versions_file" 2>/dev/null || echo "latest")
                CIS_PROVIDER_IMAGE_BASE=$(jq -r '.services."cis-provider".image' "$versions_file" 2>/dev/null || echo "docker.io/bitoai/cis-provider")
                
                CIS_TRACKER_VERSION=$(jq -r '.services."cis-tracker".version' "$versions_file" 2>/dev/null || echo "latest")
                CIS_TRACKER_IMAGE_BASE=$(jq -r '.services."cis-tracker".image' "$versions_file" 2>/dev/null || echo "docker.io/bitoai/cis-tracker")

                CIS_WORKER_VERSION=$(jq -r '.services."cis-worker".version' "$versions_file" 2>/dev/null || echo "latest")
                CIS_WORKER_IMAGE_BASE=$(jq -r '.services."cis-worker".image' "$versions_file" 2>/dev/null || echo "docker.io/bitoai/cis-worker")
            else
                CIS_CONFIG_VERSION=$(grep -A 10 '"cis-config"' "$versions_file" | grep '"version"' | head -1 | cut -d'"' -f4 || echo "latest")
                CIS_CONFIG_IMAGE_BASE=$(grep -A 10 '"cis-config"' "$versions_file" | grep '"image"' | head -1 | cut -d'"' -f4 || echo "docker.io/bitoai/cis-config")
                
                CIS_MANAGER_VERSION=$(grep -A 10 '"cis-manager"' "$versions_file" | grep '"version"' | head -1 | cut -d'"' -f4 || echo "latest")
                CIS_MANAGER_IMAGE_BASE=$(grep -A 10 '"cis-manager"' "$versions_file" | grep '"image"' | head -1 | cut -d'"' -f4 || echo "docker.io/bitoai/cis-manager")
                
                CIS_PROVIDER_VERSION=$(grep -A 10 '"cis-provider"' "$versions_file" | grep '"version"' | head -1 | cut -d'"' -f4 || echo "latest")
                CIS_PROVIDER_IMAGE_BASE=$(grep -A 10 '"cis-provider"' "$versions_file" | grep '"image"' | head -1 | cut -d'"' -f4 || echo "docker.io/bitoai/cis-provider")
                
                CIS_TRACKER_VERSION=$(grep -A 10 '"cis-tracker"' "$versions_file" | grep '"version"' | head -1 | cut -d'"' -f4 || echo "latest")
                CIS_TRACKER_IMAGE_BASE=$(grep -A 10 '"cis-tracker"' "$versions_file" | grep '"image"' | head -1 | cut -d'"' -f4 || echo "docker.io/bitoai/cis-tracker")

                CIS_WORKER_VERSION=$(grep -A 10 '"cis-worker"' "$versions_file" | grep '"version"' | head -1 | cut -d'"' -f4 || echo "latest")
                CIS_WORKER_IMAGE_BASE=$(grep -A 10 '"cis-worker"' "$versions_file" | grep '"image"' | head -1 | cut -d'"' -f4 || echo "docker.io/bitoai/cis-worker")
            fi
            
            log_silent "Target versions:"
            log_silent "  AI Architect Config: $CIS_CONFIG_VERSION"
            log_silent "  AI Architect Manager: $CIS_MANAGER_VERSION"
            log_silent "  AI Architect Provider: $CIS_PROVIDER_VERSION"
            log_silent "  AI Architect Tracker: $CIS_TRACKER_VERSION"
            log_silent "  AI Architect Worker: $CIS_WORKER_VERSION"
            echo ""
            
            # Update .env-bitoarch with new versions AND images (use real file, not symlink)
            env_config_file="$(get_config_file)"
            if [ -f "$env_config_file" ]; then
                sed -i.bak "s|^CIS_CONFIG_VERSION=.*|CIS_CONFIG_VERSION=${CIS_CONFIG_VERSION}|" "$env_config_file"
                sed -i.bak "s|^CIS_CONFIG_IMAGE=.*|CIS_CONFIG_IMAGE=${CIS_CONFIG_IMAGE_BASE}:${CIS_CONFIG_VERSION}|" "$env_config_file"
                
                sed -i.bak "s|^CIS_MANAGER_VERSION=.*|CIS_MANAGER_VERSION=${CIS_MANAGER_VERSION}|" "$env_config_file"
                sed -i.bak "s|^CIS_MANAGER_IMAGE=.*|CIS_MANAGER_IMAGE=${CIS_MANAGER_IMAGE_BASE}:${CIS_MANAGER_VERSION}|" "$env_config_file"
                
                sed -i.bak "s|^CIS_PROVIDER_VERSION=.*|CIS_PROVIDER_VERSION=${CIS_PROVIDER_VERSION}|" "$env_config_file"
                sed -i.bak "s|^CIS_PROVIDER_IMAGE=.*|CIS_PROVIDER_IMAGE=${CIS_PROVIDER_IMAGE_BASE}:${CIS_PROVIDER_VERSION}|" "$env_config_file"
                
                sed -i.bak "s|^CIS_TRACKER_VERSION=.*|CIS_TRACKER_VERSION=${CIS_TRACKER_VERSION}|" "$env_config_file"
                sed -i.bak "s|^CIS_TRACKER_IMAGE=.*|CIS_TRACKER_IMAGE=${CIS_TRACKER_IMAGE_BASE}:${CIS_TRACKER_VERSION}|" "$env_config_file"
            fi
            
            # Regenerate values with new versions and imagePullPolicy=Always to force pull
            source "${SCRIPT_DIR}/scripts/values-generator.sh"
            if ! generate_k8s_values_from_env "Always"; then
                print_error "Failed to regenerate Kubernetes values"
                exit 1
            fi
            
            # Extract latest provider default.json from new image to update helm chart ConfigMap
            print_info "Extracting latest provider configuration from new image..."
            provider_image="${CIS_PROVIDER_IMAGE_BASE}:${CIS_PROVIDER_VERSION}"
            helm_config_path="${SCRIPT_DIR}/helm-bitoarch/services/cis-provider/config/default.json"

            # Pull the image first to ensure we have the latest
            if docker pull "$provider_image" >> "$LOG_FILE" 2>&1; then
                # Create temp container and extract config
                if docker create --name temp-provider-config-k8s "$provider_image" >/dev/null 2>&1; then
                    if docker cp temp-provider-config-k8s:/opt/bito/xmcp/config/default.json "$helm_config_path" 2>> "$LOG_FILE"; then
                        log_silent "Provider configuration extracted for Helm chart"
                    else
                        print_warning "Could not extract provider config from image, using existing config"
                    fi
                    docker rm temp-provider-config-k8s >/dev/null 2>&1 || true
                else
                    print_warning "Could not create temp container for config extraction"
                fi
            else
                print_warning "Could not pull provider image for config extraction"
            fi

            # Apply updated configuration via Helm upgrade (will pull new images)
            # Use get_k8s_values_file to get actual file path (supports standard Unix paths)
            k8s_values_file="$(get_k8s_values_file)"
            print_info "Applying update via Helm (pulling new images)..."
            if helm upgrade bitoarch "${SCRIPT_DIR}/helm-bitoarch" \
                --namespace "$namespace" \
                --values "$k8s_values_file" \
                --wait \
                --timeout 10m >> "$LOG_FILE" 2>&1; then
                print_status "Images updated successfully"
            else
                print_error "Failed to apply update"
                print_info "Check logs: cat $LOG_FILE"
                print_info "Check Helm release: helm list -n $namespace"
                exit 1
            fi
            
            echo ""
            print_info "Restarting services with updated images..."
            
            deployments=("ai-architect-mysql" "ai-architect-config" "ai-architect-manager" "ai-architect-provider" "ai-architect-tracker" "ai-architect-temporal" "ai-architect-worker")
            restart_failed=false

            for deployment in "${deployments[@]}"; do
                if [[ "$deployment" == "ai-architect-temporal" ]]; then
                    handle_temporal_statefulset "restart" "$namespace" "$LOG_FILE" || restart_failed=true
                    continue
                fi

                if is_user_facing_service "$deployment"; then
                    printf "   %-25s" "$deployment"
                    if kubectl rollout restart deployment "$deployment" -n "$namespace" >> "$LOG_FILE" 2>&1; then
                        if kubectl rollout status deployment "$deployment" -n "$namespace" --timeout=3m >> "$LOG_FILE" 2>&1; then
                            printf "${GREEN}✅ Updated${NC}\n"
                        else
                            printf "${YELLOW}⏱ Timeout${NC}\n"
                            restart_failed=true
                        fi
                    else
                        printf "${RED}❌ Failed${NC}\n"
                        restart_failed=true
                    fi
                else
                    if kubectl rollout restart deployment "$deployment" -n "$namespace" >> "$LOG_FILE" 2>&1; then
                        if kubectl rollout status deployment "$deployment" -n "$namespace" --timeout=3m >> "$LOG_FILE" 2>&1; then
                            log_silent "  ✅ $deployment updated"
                        else
                            log_silent "  ⏱ $deployment timed out"
                            restart_failed=true
                        fi
                    else
                        log_silent "  ❌ $deployment failed"
                        restart_failed=true
                    fi
                fi
            done
            
            echo ""
            if [ "$restart_failed" = true ]; then
                print_warning "Some services failed or timed out"
                print_info "Check status: ${YELLOW}bitoarch status${NC}"
                exit 1
            else
                print_status "All services updated successfully"
                
                # Refresh port-forwards to point to new pods after update
                print_info "Refreshing port-forwards for updated pods..."
                pkill -f "kubectl.*port-forward.*${namespace}" 2>/dev/null || true
                sleep 2
                
                # Wait for pods to be stable before recreating port-forwards
                if wait_for_k8s_services "$namespace" 60; then
                    # Capture service logs after update
                    if [ -f "${SCRIPT_DIR}/scripts/unified-log-manager.sh" ]; then
                        "${SCRIPT_DIR}/scripts/unified-log-manager.sh" sync || true
                    fi
                    
                    setup_port_forwards "$namespace"
                    print_status "Port-forwards refreshed"
                fi
                
                print_info "Check status: ${YELLOW}bitoarch status${NC}"
            fi
        else
            # Docker Compose update
            compose_cmd="${DOCKER_COMPOSE_CMD:-}"
            if [ -z "$compose_cmd" ]; then
                if command -v docker >/dev/null 2>&1 && docker compose version >/dev/null 2>&1; then
                    compose_cmd="docker compose"
                elif command -v docker-compose >/dev/null 2>&1; then
                    compose_cmd="docker-compose"
                else
                    print_error "Neither 'docker compose' nor 'docker-compose' found"
                    exit 1
                fi
            fi
            
            # Check if services are running
            running_services=$(docker ps -q --filter "name=ai-architect-" 2>/dev/null | wc -l)
            if [ "$running_services" -eq 0 ]; then
                print_warning "No AI Architect services are currently running"
                print_info "To start services, run: ${YELLOW}bitoarch start${NC}"
                exit 0
            fi
            
            # Capture logs BEFORE update (while old containers still exist)
            if [ -f "${SCRIPT_DIR}/scripts/unified-log-manager.sh" ]; then
                "${SCRIPT_DIR}/scripts/unified-log-manager.sh" sync || true
            fi
            
            # DOCKER FIX: Refresh versions from service-versions.json to .env-bitoarch
            # This replaces the manual sed commands and ensures single source of truth
            # Use get_config_file to get actual file path (not symlink) for sed compatibility
            env_config_file="$(get_config_file)"
            print_info "Refreshing service versions from ${versions_file}..."
            if ! refresh_versions_from_service_json "$env_config_file"; then
                print_error "Failed to refresh versions from service-versions.json"
                exit 1
            fi

            # Source the updated env file to get version info for display
            source "$env_config_file"

            # Extract versions from IMAGE variables (format: docker.io/bitoai/service:version)
            config_version="${CIS_CONFIG_IMAGE##*:}"
            manager_version="${CIS_MANAGER_IMAGE##*:}"
            provider_version="${CIS_PROVIDER_IMAGE##*:}"
            tracker_version="${CIS_TRACKER_IMAGE##*:}"
            mysql_version="${MYSQL_IMAGE##*:}"

            log_silent "Target versions from ${versions_file}:"
            log_silent "  AI Architect Config: ${config_version}"
            log_silent "  AI Architect Manager: ${manager_version}"
            log_silent "  AI Architect Provider: ${provider_version}"
            log_silent "  AI Architect Tracker: ${tracker_version}"
            log_silent "  MySQL: ${mysql_version}"
            echo ""
                        
            echo ""
            print_info "Pulling latest images (this may take a few minutes)..."
            
            # Pull images one by one with progress
            services=("ai-architect-mysql" "ai-architect-temporal" "ai-architect-config" "ai-architect-manager" "ai-architect-worker" "ai-architect-provider" "ai-architect-tracker")
            pull_failed=false
            
            for service in "${services[@]}"; do
                if [ "$service" = "ai-architect-temporal" ]; then
                    run_temporal_compose "pull" "$LOG_FILE" || pull_failed=true
                    continue
                fi

                if is_user_facing_service "$service"; then
                    printf "   %-25s" "$service"
                    if eval "$compose_cmd -f \"${SCRIPT_DIR}/docker-compose.yml\" --env-file \"$ENV_FILE\" pull $service" >> "$LOG_FILE" 2>&1; then
                        printf "${GREEN}✅ Pulled${NC}\n"
                    else
                        printf "${RED}❌ Failed${NC}\n"
                        pull_failed=true
                    fi
                else
                    if eval "$compose_cmd -f \"${SCRIPT_DIR}/docker-compose.yml\" --env-file \"$ENV_FILE\" pull $service" >> "$LOG_FILE" 2>&1; then
                        log_silent "  ✅ $service pulled"
                    else
                        log_silent "  ❌ $service pull failed"
                        pull_failed=true
                    fi
                fi
            done
            
            if [ "$pull_failed" = true ]; then
                echo ""
                print_error "Failed to pull some images"
                print_info "Check logs: cat $LOG_FILE"
                exit 1
            fi
            
            # Extract latest provider default.json from new image
            echo ""
            print_info "Extracting latest provider configuration from new image..."
            docker_config_path="${SCRIPT_DIR}/services/cis-provider/config/default.json"

            # Create temp container and extract config
            if docker create --name temp-provider-config-docker "${CIS_PROVIDER_IMAGE}" >/dev/null 2>&1; then
                if docker cp temp-provider-config-docker:/opt/bito/xmcp/config/default.json "$docker_config_path" 2>> "$LOG_FILE"; then
                    chmod 666 "$docker_config_path"
                    print_status "Provider configuration extracted from latest image"
                else
                    print_warning "Could not extract provider config from image, using existing config"
                fi
                docker rm temp-provider-config-docker >/dev/null 2>&1 || true
            else
                print_warning "Could not create temp container for config extraction"
            fi

            echo ""
            print_info "Restarting services with updated images..."

            # Single `up -d --force-recreate` without --no-deps so compose
            # brings MySQL up first and gates config/manager on MySQL healthy.
            # A per-service loop with --no-deps would race MySQL startup.
            services_str="ai-architect-mysql ai-architect-config ai-architect-manager ai-architect-provider ai-architect-tracker ai-architect-temporal ai-architect-worker"
            restart_failed=false
            if eval "$compose_cmd -f \"${SCRIPT_DIR}/docker-compose.yml\" --env-file \"$ENV_FILE\" up -d --force-recreate $services_str" >> "$LOG_FILE" 2>&1; then
                print_status "All services updated successfully with latest images"
                print_info "Check status: ${YELLOW}bitoarch status${NC}"
            else
                restart_failed=true
                print_warning "Update failed"
                print_info "Check logs: ${YELLOW}bitoarch logs${NC}"
                exit 1
            fi
        fi
        ;;
    *)
        # Check if an unknown option was provided
        if [[ "${1:-}" == --* ]]; then
            print_error "Unknown option: ${1}"
            echo ""
            show_help
            exit 1
        else
            # No option provided, run main setup
            main
        fi
        ;;
esac
