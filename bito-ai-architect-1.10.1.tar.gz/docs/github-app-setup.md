# GitHub App Authentication — Setup Guide

Bito AI Architect can authenticate to GitHub as a **GitHub App** instead of a Personal
Access Token (PAT). App auth is org-owned, scoped to the repositories you install it
on, and uses short-lived installation tokens minted on demand — so no long-lived PAT
sits in your configuration.

App auth is **optional and additive**: PAT stays the default and existing PAT installs
are unaffected. App auth is supported for **GitHub only** (github.com and GitHub
Enterprise Server), for cloning, indexing, and Git insights.

> **MVP scope:** App auth is used for **authentication and repository enumeration
> only**. There is **no browser flow, no OAuth, and no webhook/callback** to configure.
> You create and install the App in GitHub yourself, then hand three values to the
> installer: the **App ID**, an **Installation ID**, and the App's **private-key
> `.pem`**.

---

## Prerequisites

- Admin access to the GitHub **organization** (or account) that owns the repositories.
- The ability to create and install a GitHub App in that org.
- A host that can run the AI Architect installer (Docker Compose, Standalone, or
  Kubernetes).

---

## 1. Create the GitHub App

1. Go to **Organization → Settings → Developer settings → GitHub Apps → New GitHub
   App** (for a personal account: **Settings → Developer settings → GitHub Apps**).
2. **Name / Homepage URL:** any values (e.g. `bito-ai-architect`). Homepage URL is not
   used by AI Architect.
3. **Webhook:** **uncheck "Active"**. AI Architect does not use webhooks.
4. **Repository permissions** — grant **Read-only**:

   | Permission | Access | Why |
   |------------|--------|-----|
   | **Contents** | Read-only | Clone and read repository source for indexing |
   | **Metadata** | Read-only | Mandatory; lists repositories and basic metadata |

   No other permissions are required. Grant nothing you don't need.
5. **Where can this app be installed?** Choose **Only on this account** (keep it
   private to your org).
6. Click **Create GitHub App**.

## 2. Generate the private key (`.pem`)

1. On the App's **General** page, under **Private keys**, click **Generate a private
   key**.
2. GitHub downloads a `*.pem` file. **Store it securely** — you will point the
   installer at this file path. It is the App's master credential.

## 3. Install the App and collect the IDs

1. On the App page, open **Install App** and install it on the **organization** (all
   repositories, or a selected subset — AI Architect indexes only the repositories you
   later configure).
2. **App ID** — on the App's **General** page, near the top ("App ID: `123456`").
3. **Installation ID** — after installing, open the installation's settings page; the
   URL ends with the numeric installation id, e.g.
   `.../settings/installations/12345678` → Installation ID is `12345678`.

You now have the three values you need: **App ID**, **Installation ID**, and the path
to the **`.pem`** file.

---

## 4. Configure AI Architect for App auth

Pick **one** of the following. In every case the installer reads the `.pem` from the
path you give and **base64-encodes it into a single environment variable** — the key
file itself is never copied elsewhere, and the key is never printed (only a fingerprint
and byte count are shown).

### Option A — `install.yaml` (non-interactive)

Set the `git` block in `install.yaml` (see `install.yaml.default`):

```yaml
git:
  provider: "github"
  auth_type: "app"                 # personal_access_token (default) | app
  app_id: "123456"
  installation_id: "12345678"
  private_key_path: "/absolute/path/to/app-key.pem"   # auto base64-encoded
  # access_token is not used for app auth
  # domain_url: "https://ghe.example.com"   # GitHub Enterprise Server only
```

Then run the install bootstrap as usual. Leave `auth_type` empty (or set
`personal_access_token`) to keep using a PAT.

### Option B — interactive install

During `git` setup the installer asks, for GitHub:

```
Select GitHub auth method (1) Personal Access Token  (2) GitHub App  [1-2] (default 1):
```

Choose **2**, then enter the **App ID**, the **path to the `.pem`**, and the
**Installation ID** (in that order — it mirrors GitHub's own flow: create the App and
its key first, then install it). The installer prints a key fingerprint (never the
key).

### Option C — after install / rotating credentials

Use the CLI at any time:

```bash
bitoarch update-git-creds
```

Choose GitHub → GitHub App and supply the values. To **rotate the private key**, supply
the path to a **new** `.pem`; to keep the current key, press **Enter** at the key
prompt. Changes take effect **without a container restart**. After updating, apply the
change with `bitoarch add-repos` or `bitoarch update-repos`.

---

## GitHub Enterprise Server (GHES)

Set the enterprise domain (`git.domain_url` in `install.yaml`, or answer "yes" to the
enterprise prompt). AI Architect derives the GHES API base automatically
(`https://<host>/api/v3`). App creation, permissions, and installation are the same as
on github.com.

---

## How the credentials are stored and protected

- The `.pem` is base64-encoded into `GIT_APP_PRIVATE_KEY_B64` in `.env-bitoarch`
  (permissions `600`), the same transport used for the PAT today. There is **no `.pem`
  file mount**.
- On save, cis-config stores the private key **encrypted at rest** (AES-256-GCM) and
  mints short-lived installation tokens per request. The key is **never returned by any
  read API** and is **redacted in diagnostics** (`bitoarch diagnose` masks
  `PRIVATE_KEY`).
- Rotate the key in place via `bitoarch update-git-creds` (Option C) — no restart, no
  file swap.

---

## Troubleshooting

| Symptom | Likely cause | Fix |
|---------|--------------|-----|
| Save/enumeration fails with a `4xx` "couldn't authenticate to GitHub with the provided App credentials" | Wrong Installation ID, `.pem` doesn't match the App ID, or the App isn't installed on the target repos | Re-check App ID / Installation ID (Steps 1–3) and that the App is installed; re-run `update-git-creds` |
| Repository list is empty | App not installed on the repos you expect, or missing **Metadata: Read** | Install the App on the org/repos; verify permissions |
| Clone/index 401/403 at runtime | Missing **Contents: Read** | Add Contents (Read) to the App and re-check |

The installer never echoes the private key; error messages reference the App ID and
Installation ID only.
