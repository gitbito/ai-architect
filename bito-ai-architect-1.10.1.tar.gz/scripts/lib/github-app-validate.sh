#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# scripts/lib/github-app-validate.sh
# Two-step, setup-time validation of GitHub App credentials, DIRECTLY against the
# GitHub API (cis-config isn't up while the installer is still prompting):
#
#   api-1  GET {base}/app                          -> verifies App ID + private key
#          (run right after the .pem is entered)      (JWT signed by the key; 401 = bad)
#   api-2  GET {base}/app/installations/{id}       -> verifies the Installation ID
#          (run right after the installation id)      (404 = not found / not installed)
#
# Each check logs the request and the API response (HTTP code + a short body snippet)
# via log_silent so the setup log shows clearly whether it succeeded. The private key
# is decoded to a 0600 temp file for openssl and removed immediately; neither the key
# nor the JWT is ever logged or echoed.

# Load guard (this file is always sourced, never executed).
if [ -n "${_BITOARCH_GH_APP_VALIDATE_LOADED:-}" ]; then
    return 0
fi
_BITOARCH_GH_APP_VALIDATE_LOADED=1

# No-op fallbacks so this file can be sourced standalone (e.g. for testing) without
# the full CLI helper set. The real print_*/log_silent win when already defined.
command -v log_silent    >/dev/null 2>&1 || log_silent()    { :; }
command -v print_error   >/dev/null 2>&1 || print_error()   { echo "✗ $*" >&2; }
command -v print_info    >/dev/null 2>&1 || print_info()    { echo "ℹ $*"; }
command -v print_warning >/dev/null 2>&1 || print_warning() { echo "⚠ $*"; }

# Derive the GitHub REST API base URL from the git domain.
#   empty / github.com  -> https://api.github.com
#   GHES host           -> https://<host>/api/v3
_gh_app_api_base() {
    local domain="$1"
    case "$domain" in
        ""|"https://github.com"|"http://github.com"|"github.com")
            echo "https://api.github.com"; return 0 ;;
    esac
    domain="${domain%/}"
    case "$domain" in
        http://*|https://*) ;;
        *) domain="https://${domain}" ;;
    esac
    echo "${domain}/api/v3"
}

# base64url (no padding) of stdin.
_gh_b64url() { openssl base64 -e -A 2>/dev/null | tr '+/' '-_' | tr -d '='; }

# Mint a short-lived RS256 JWT for GitHub App auth.
# Args: <app_id> <pem_file>. Echoes the JWT; returns 1 on signing failure.
# Claims: iss=app_id, iat=now-60 (clock skew), exp=now+540 (< GitHub's 10-min max).
_gh_app_mint_jwt() {
    local app_id="$1" pem_file="$2" now iat exp header payload signing_input sig
    now=$(date +%s); iat=$((now - 60)); exp=$((now + 540))
    header='{"alg":"RS256","typ":"JWT"}'
    payload=$(printf '{"iat":%s,"exp":%s,"iss":"%s"}' "$iat" "$exp" "$app_id")
    signing_input="$(printf '%s' "$header" | _gh_b64url).$(printf '%s' "$payload" | _gh_b64url)"
    sig=$(printf '%s' "$signing_input" | openssl dgst -sha256 -sign "$pem_file" 2>/dev/null | _gh_b64url)
    [ -n "$sig" ] || return 1
    printf '%s.%s' "$signing_input" "$sig"
}

# Decode a base64 PEM to a 0600 temp file, mint a JWT, remove the file.
# Args: <app_id> <pem_b64>. Echoes the JWT; returns 1 if the key is bad.
_gh_app_jwt_from_b64() {
    local app_id="$1" pem_b64="$2" pem_file jwt rc
    pem_file=$(mktemp 2>/dev/null) || return 1
    chmod 600 "$pem_file" 2>/dev/null || true
    # openssl decodes portably (GNU base64 uses -d, BSD/macOS -D); openssl is already
    # required here for JWT signing, so no extra dependency.
    printf '%s' "$pem_b64" | openssl base64 -d -A > "$pem_file" 2>/dev/null
    if [ ! -s "$pem_file" ]; then rm -f "$pem_file"; return 1; fi
    jwt=$(_gh_app_mint_jwt "$app_id" "$pem_file"); rc=$?
    rm -f "$pem_file"
    { [ "$rc" -eq 0 ] && [ -n "$jwt" ]; } || return 1
    printf '%s' "$jwt"
}

# Authenticated GET. Args: <jwt> <url>. Echoes "<body>\n<http_code>"; curl rc via return.
_gh_app_api_get() {
    curl -s -w '\n%{http_code}' --max-time 20 \
        --location "$2" \
        --header "Accept: application/vnd.github+json" \
        --header "Authorization: Bearer $1" \
        --header "X-GitHub-Api-Version: 2022-11-28" 2>/dev/null
}

# One-line, non-sensitive snippet of a response body for the log.
_gh_app_body_snippet() { printf '%s' "$1" | tr '\n\r\t' '   ' | cut -c1-200; }

# ── api-1: verify App ID + private key via GET /app ─────────────────────────
# Args: <app_id> <private_key_b64> <domain>
# 0 = valid; 1 = invalid (App ID/key); 2 = could not check (no tools / unreachable).
validate_github_app_key() {
    local app_id="$1" pem_b64="$2" domain="$3"
    if ! command -v openssl >/dev/null 2>&1 || ! command -v curl >/dev/null 2>&1; then
        log_silent "GitHub App key check: SKIPPED (openssl/curl unavailable)"; return 2
    fi
    if [ -z "$app_id" ] || [ -z "$pem_b64" ]; then
        log_silent "GitHub App key check: SKIPPED (app_id/private_key not present)"; return 2
    fi
    local jwt
    if ! jwt=$(_gh_app_jwt_from_b64 "$app_id" "$pem_b64"); then
        log_silent "GitHub App key check: FAILED (could not sign JWT — private key invalid)"
        print_error "The GitHub App private key is invalid (could not sign a token)."
        return 1
    fi
    local base resp rc code body
    base=$(_gh_app_api_base "$domain")
    log_silent "GitHub App key check (api-1): GET ${base}/app (app_id=${app_id})"
    resp=$(_gh_app_api_get "$jwt" "${base}/app"); rc=$?
    code="${resp##*$'\n'}"; body="${resp%$'\n'*}"
    if [ "$rc" -ne 0 ] || ! printf '%s' "$code" | grep -qE '^[0-9]+$'; then
        log_silent "GitHub App key check (api-1): SKIPPED (GitHub unreachable at ${base}, curl rc=$rc)"; return 2
    fi
    case "$code" in
        2*) log_silent "GitHub App key check (api-1): SUCCESS (HTTP ${code}) response: $(_gh_app_body_snippet "$body")"; return 0 ;;
        401) log_silent "GitHub App key check (api-1): FAILED (HTTP 401) response: $(_gh_app_body_snippet "$body")"
             print_error "GitHub rejected the App ID / private key (401). Check the App ID and that the .pem matches it."; return 1 ;;
        *)  log_silent "GitHub App key check (api-1): FAILED (HTTP ${code}) response: $(_gh_app_body_snippet "$body")"
            print_error "GitHub App key check failed (HTTP ${code})."; return 1 ;;
    esac
}

# ── api-2: verify the installation via GET /app/installations/{id} ──────────
# Args: <app_id> <installation_id> <private_key_b64> <domain>
# 0 = valid; 1 = invalid (installation); 2 = could not check.
validate_github_app_installation() {
    local app_id="$1" installation_id="$2" pem_b64="$3" domain="$4"
    if ! command -v openssl >/dev/null 2>&1 || ! command -v curl >/dev/null 2>&1; then
        log_silent "GitHub App installation check: SKIPPED (openssl/curl unavailable)"; return 2
    fi
    if [ -z "$app_id" ] || [ -z "$installation_id" ] || [ -z "$pem_b64" ]; then
        log_silent "GitHub App installation check: SKIPPED (inputs not all present)"; return 2
    fi
    local jwt
    if ! jwt=$(_gh_app_jwt_from_b64 "$app_id" "$pem_b64"); then
        log_silent "GitHub App installation check: FAILED (could not sign JWT — private key invalid)"
        print_error "The GitHub App private key is invalid (could not sign a token)."
        return 1
    fi
    local base resp rc code body
    base=$(_gh_app_api_base "$domain")
    log_silent "GitHub App installation check (api-2): GET ${base}/app/installations/${installation_id} (app_id=${app_id})"
    resp=$(_gh_app_api_get "$jwt" "${base}/app/installations/${installation_id}"); rc=$?
    code="${resp##*$'\n'}"; body="${resp%$'\n'*}"
    if [ "$rc" -ne 0 ] || ! printf '%s' "$code" | grep -qE '^[0-9]+$'; then
        log_silent "GitHub App installation check (api-2): SKIPPED (GitHub unreachable at ${base}, curl rc=$rc)"; return 2
    fi
    case "$code" in
        2*) log_silent "GitHub App installation check (api-2): SUCCESS (HTTP ${code}) response: $(_gh_app_body_snippet "$body")"; return 0 ;;
        404) log_silent "GitHub App installation check (api-2): FAILED (HTTP 404) response: $(_gh_app_body_snippet "$body")"
             print_error "Installation ID ${installation_id} was not found for this App (404). Check the Installation ID and that the App is installed."; return 1 ;;
        401) log_silent "GitHub App installation check (api-2): FAILED (HTTP 401) response: $(_gh_app_body_snippet "$body")"
             print_error "GitHub rejected the credentials for the installation check (401)."; return 1 ;;
        *)  log_silent "GitHub App installation check (api-2): FAILED (HTTP ${code}) response: $(_gh_app_body_snippet "$body")"
            print_error "GitHub App installation check failed (HTTP ${code})."; return 1 ;;
    esac
}

export -f _gh_app_api_base _gh_b64url _gh_app_mint_jwt _gh_app_jwt_from_b64 \
    _gh_app_api_get _gh_app_body_snippet validate_github_app_key \
    validate_github_app_installation 2>/dev/null || true
