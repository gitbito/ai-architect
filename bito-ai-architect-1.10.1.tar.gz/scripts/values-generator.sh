#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# Kubernetes Values Generator
# Generates .bitoarch-values.yaml from user input and service versions

# Determine script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && cd .. && pwd)"

# Source existing output functions
source "${SCRIPT_DIR}/scripts/lib/output-blocks.sh" 2>/dev/null || {
    # Fallback if not sourced correctly
    GREEN='\033[0;32m'
    RED='\033[0;31m'
    BLUE='\033[0;34m'
    YELLOW='\033[1;33m'
    NC='\033[0m'
    print_status() { echo -e "${GREEN}✓${NC} $1"; }
    print_error() { echo -e "${RED}✗${NC} $1"; }
    print_info() { echo -e "${BLUE}ℹ${NC} $1"; }
    print_warning() { echo -e "${YELLOW}⚠${NC} $1"; }
}


# Check if external ports are available in the cluster (for port-forwards)
check_external_port_availability() {
    local provider_port="${1:-5001}"
    local manager_port="${2:-5002}"
    local config_port="${3:-5003}"
    local tracker_port="${4:-5005}"
    local mysql_port="${5:-5004}"
    
    # Get all NodePorts in use
    local used_ports=$(kubectl get svc --all-namespaces -o json 2>/dev/null | \
        jq -r '.items[].spec.ports[]? | select(.nodePort != null) | .nodePort' 2>/dev/null || echo "")
    
    local conflicts=()
    for port in $provider_port $manager_port $config_port $tracker_port $mysql_port; do
        if echo "$used_ports" | grep -q "^${port}$"; then
            conflicts+=($port)
        fi
    done
    
    if [ ${#conflicts[@]} -gt 0 ]; then
        echo "conflicts:${conflicts[*]}"
        return 1
    else
        echo "available"
        return 0
    fi
}

# Detect storage class from cluster
detect_storage_class() {
    # Get default storage class
    local default_sc=$(kubectl get storageclass -o json 2>/dev/null | \
        jq -r '.items[] | select(.metadata.annotations["storageclass.kubernetes.io/is-default-class"]=="true") | .metadata.name' 2>/dev/null || echo "")
    
    if [[ -n "$default_sc" ]]; then
        echo "$default_sc"
        return 0
    fi
    
    # If no default, get first available
    local first_sc=$(kubectl get storageclass -o json 2>/dev/null | \
        jq -r '.items[0].metadata.name' 2>/dev/null || echo "")
    
    if [[ -n "$first_sc" ]]; then
        echo "$first_sc"
        return 0
    fi
    
    # Return empty (will use cluster default)
    echo ""
    return 0
}

# Validate generated values file
validate_bitoarch_values() {
    local values_file="$1"
    
    if [[ ! -f "$values_file" ]]; then
        print_error "Values file not found: $values_file"
        return 1
    fi
    
    # Check if file is valid YAML
    if command -v yq >/dev/null 2>&1; then
        if ! yq eval '.' "$values_file" >/dev/null 2>&1; then
            print_error "Invalid YAML in values file"
            return 1
        fi
    elif command -v python3 >/dev/null 2>&1; then
        if ! python3 -c "import yaml; yaml.safe_load(open('$values_file'))" 2>/dev/null; then
            print_error "Invalid YAML in values file"
            return 1
        fi
    fi
    
    # Check for unsubstituted variables
    if grep -q '^\${' "$values_file" 2>/dev/null; then
        print_warning "Some variables may not be substituted in $values_file"
    fi
    
    return 0
}

# Read all environment variables from file
read_all_env_vars() {
    local env_file="$1"
    
    if [[ ! -f "$env_file" ]]; then
        return 1
    fi
    
    # Read all KEY=VALUE pairs, excluding comments and empty lines
    grep -E '^[A-Z_][A-Z0-9_]*=' "$env_file" | while IFS='=' read -r key value; do
        # Remove quotes if present
        value=$(echo "$value" | sed -e 's/^"//' -e 's/"$//' -e "s/^'//" -e "s/'$//")
        echo "$key: \"$value\""
    done
}

# Validate required environment variables.
# INSIGHTS_* and AGENT_INTEGRATION_LB_URL are intentionally NOT in this list:
# they are optional features (insights opt-in) or self-hosted-disabling knobs
# (AGENT_INTEGRATION_LB_URL must stay empty in self-hosted to disable managed
# fallback in cis-config). They flow through to Helm values via the generic
# env-var passthrough in read_all_env_vars().
validate_required_env_vars() {
    local required_vars=(
        "MYSQL_ROOT_PASSWORD"
        "MYSQL_PASSWORD"
        "MYSQL_USER"
        "MYSQL_DATABASE"
        "BITO_API_KEY"
        "JWT_SECRET"
    )
    
    local missing=()
    for var in "${required_vars[@]}"; do
        if [[ -z "${!var}" ]]; then
            missing+=("$var")
        fi
    done
    
    if [[ ${#missing[@]} -gt 0 ]]; then
        print_error "Missing required environment variables:"
        printf '  - %s\n' "${missing[@]}"
        print_info "These variables must be set in .env-bitoarch"
        return 1
    fi
    
    return 0
}

# Generate Kubernetes values file directly from env files
# Parameters:
#   $1 - optional: imagePullPolicy override ("Always" for updates, default: "IfNotPresent")
generate_k8s_values_from_env() {
    # Source path-manager if not already loaded
    if ! type get_k8s_values_file >/dev/null 2>&1; then
        source "${SCRIPT_DIR}/scripts/lib/path-manager.sh" 2>/dev/null || true
    fi

    local image_pull_policy="${1:-IfNotPresent}"

    # Use path-manager to get config file location (handles standard vs legacy paths)
    local env_default="${SCRIPT_DIR}/.env-bitoarch.default"
    local env_file
    if type get_config_file >/dev/null 2>&1; then
        env_file=$(get_config_file)
    else
        env_file="${SCRIPT_DIR}/.env-bitoarch"
    fi

    local output_file
    if type get_k8s_values_file >/dev/null 2>&1; then
        output_file=$(get_k8s_values_file)
    else
        output_file="${SCRIPT_DIR}/.bitoarch-values.yaml"
    fi
    
    # Source default env file
    if [[ ! -f "$env_default" ]]; then
        print_error "Default environment file not found: $env_default"
        return 1
    fi
    
    set -a
    source "$env_default" 2>/dev/null
    set +a
    
    # Override with user env file if exists
    if [[ -f "$env_file" ]]; then
        set -a
        source "$env_file" 2>/dev/null
        set +a
    fi
    
    # Validate required variables
    if ! validate_required_env_vars; then
        return 1
    fi
    
    # Validate required environment variables from env files
    if [[ -z "$CIS_CONFIG_IMAGE" ]]; then
        print_error "CIS_CONFIG_IMAGE is not set in environment files"
        return 1
    fi
    if [[ -z "$CIS_MANAGER_IMAGE" ]]; then
        print_error "CIS_MANAGER_IMAGE is not set in environment files"
        return 1
    fi
    if [[ -z "$CIS_PROVIDER_IMAGE" ]]; then
        print_error "CIS_PROVIDER_IMAGE is not set in environment files"
        return 1
    fi
    if [[ -z "$CIS_TRACKER_IMAGE" ]]; then
        print_error "CIS_TRACKER_IMAGE is not set in environment files"
        return 1
    fi
    if [[ -z "$MYSQL_IMAGE" ]]; then
        print_error "MYSQL_IMAGE is not set in environment files"
        return 1
    fi
    if [[ -z "$TZ" ]]; then
        print_error "TZ is not set in environment files"
        return 1
    fi
    if [[ -z "$LOG_LEVEL" ]]; then
        print_error "LOG_LEVEL is not set in environment files"
        return 1
    fi
    if [[ -z "$NODE_ENV" ]]; then
        print_error "NODE_ENV is not set in environment files"
        return 1
    fi
    if [[ -z "$TEMPORAL_IMAGE" ]]; then
        print_error "TEMPORAL_IMAGE is not set in environment files"
        return 1
    fi
    if [[ -z "$CIS_WORKER_IMAGE" ]]; then
        print_error "CIS_WORKER_IMAGE is not set in environment files"
        return 1
    fi
    
    # Detect storage class
    local storage_class=$(detect_storage_class)
    
    # Validate storage class was detected
    if [[ -z "$storage_class" ]]; then
        print_error "Failed to detect storage class. Please ensure your Kubernetes cluster has a default storage class configured."
        return 1
    fi
    
    # Ingress front door: no BITOARCH_INGRESS_CLASS -> ship the bundled
    # controller under the dedicated class; set -> reference the customer's
    # controller and render none of ours. Exposure defaults to NodePort on EVERY
    # cluster: one uniform, conflict-free front door at 30080/30443 that never
    # fights for node 80 (kind reaches it via extraPortMappings for 30080/30443 —
    # see the manual testing guide). Override via BITOARCH_INGRESS_EXPOSURE
    # (hostport binds node 80/443 directly; loadbalancer for cloud LBs).
    local ing_bundled=true ing_class="${BITOARCH_INGRESS_CLASS:-}"
    if [ -n "$ing_class" ]; then ing_bundled=false; else ing_class="ai-architect-nginx"; fi
    local ing_exposure="${BITOARCH_INGRESS_EXPOSURE:-nodeport}"
    type log_silent >/dev/null 2>&1 && log_silent "ingress: mode=$([ "$ing_bundled" = "true" ] && echo bundled || echo "external (class ${ing_class})") exposure=${ing_exposure}"

    # NodePorts must fall in the Kubernetes NodePort range; reject out-of-range up front
    # (fail values generation) instead of the API server rejecting the Service at apply time.
    local ing_np_http="${BITOARCH_INGRESS_NODEPORT_HTTP:-30080}" ing_np_https="${BITOARCH_INGRESS_NODEPORT_HTTPS:-30443}"
    if [ "$ing_bundled" = "true" ] && [ "$ing_exposure" = "nodeport" ]; then
        local _np
        for _np in "$ing_np_http" "$ing_np_https"; do
            if ! printf '%s' "$_np" | grep -Eq '^[0-9]+$' || [ "$_np" -lt 30000 ] || [ "$_np" -gt 32767 ]; then
                print_error "Ingress NodePort '${_np}' is out of range (must be 30000-32767). Set BITOARCH_INGRESS_NODEPORT_HTTP/HTTPS to valid NodePorts."
                return 1
            fi
        done
    fi

    # Generate YAML with complete structure matching templates
    cat > "$output_file" <<EOF
# Bito AI Architect Kubernetes Values
# Generated from .env-bitoarch

# Global configuration
global:
  namespace: bito-ai-architect
  imagePullPolicy: ${image_pull_policy}
  logLevel: ${LOG_LEVEL}

# Complete image paths (includes registry, org, image name, and tag)
images:
  config: ${CIS_CONFIG_IMAGE}
  manager: ${CIS_MANAGER_IMAGE}
  provider: ${CIS_PROVIDER_IMAGE}
  tracker: ${CIS_TRACKER_IMAGE}
  mysql: ${MYSQL_IMAGE}
  temporal: ${TEMPORAL_IMAGE}
  worker: ${CIS_WORKER_IMAGE}

# Internal ports (container ports)
internalPorts:
  config: ${CIS_CONFIG_PORT:-8081}
  manager: ${CIS_MANAGER_PORT:-9090}
  provider: ${XMCP_HTTP_PORT:-8080}
  tracker: ${CIS_TRACKING_PORT:-9920}
  mysql: ${MYSQL_PORT:-3306}
  temporal: ${TEMPORAL_PORT:-7233}

# External ports (NodePort)
externalPorts:
  config: ${CIS_CONFIG_EXTERNAL_PORT:-5003}
  manager: ${CIS_MANAGER_EXTERNAL_PORT:-5002}
  provider: ${CIS_PROVIDER_EXTERNAL_PORT:-5001}
  tracker: ${CIS_TRACKER_EXTERNAL_PORT:-5005}
  mysql: ${MYSQL_EXTERNAL_PORT:-5004}
  temporal: ${TEMPORAL_EXTERNAL_PORT:-5006}

# Environment variables
environment:
  timezone: ${TZ}
  logLevel: ${LOG_LEVEL}
  nodeEnv: ${NODE_ENV}
  mysqlHost: ${DB_HOST:-ai-architect-mysql}
  mysqlPort: ${DB_PORT:-3306}
  configServiceUrl: http://ai-architect-config:${CIS_CONFIG_PORT:-8081}
  managerServiceUrl: http://ai-architect-manager:${CIS_MANAGER_PORT:-9090}
  temporalHostPort: ${TEMPORAL_HOST_PORT:-ai-architect-temporal:7233}
  temporalNamespace: ${TEMPORAL_NAMESPACE:-cis-onprem}
  temporalWorkerVersioningEnabled: ${TEMPORAL_WORKER_VERSIONING_ENABLED:-true}
  temporalWorkerDeploymentName: ${TEMPORAL_WORKER_DEPLOYMENT_NAME:-cis-manager-workers}
  temporalWorkerBuildId: ${TEMPORAL_WORKER_BUILD_ID:-1.0.0}
  temporalWorkerTaskQueues: ${TEMPORAL_WORKER_TASK_QUEUES:-cis-workflow-queue,cis-git-queue,cis-indexing-queue,cis-llm-api-queue,cis-tracking-queue,cis-cleanup-queue}
  storagePath: ${STORAGE_PATH:-/opt/bito/ai-architect/data}
  backupPath: ${BACKUP_PATH:-/opt/bito/ai-architect/backups}
  tempPath: ${TEMP_PATH:-/opt/bito/ai-architect/temp}
  metadataPath: ${METADATA_PATH:-/opt/bito/ai-architect/metadata}
  cloneDir: ${CIS_CLONE_DIR:-/opt/bito/ai-architect/data/clone-dir}
  cisCloneDir: ${CIS_CLONE_DIR:-/opt/bito/ai-architect/data/clone-dir}
  indexDataDir: ${INDEX_DATA_DIR:-/opt/bito/ai-architect/data/index-data}
  insightsDataPath: ${INSIGHTS_DATA_PATH:-/s3_ticket_insights}

# Storage configuration
storage:
  enabled: true
  className: ${storage_class}
  accessMode: ${STORAGE_ACCESS_MODE:-ReadWriteOnce}
  mysql:
    size: 10Gi
  data:
    size: 20Gi

  wingman:
    size: ${WINGMAN_PVC_SIZE:-5Gi}
  backups:
    size: 10Gi
  temp:
    size: 5Gi
  logs:
    size: 5Gi
  insights:
    size: 5Gi

# Shared Wingman shelf populate (chart-owned Job: templates/07b-wingman-populate.yaml)
wingman:
  populate:
    enabled: true
    image: ${WINGMAN_POPULATE_IMAGE:-busybox:1.36}
    downloadBaseUrl: "${WINGMAN_DOWNLOAD_BASE_URL:-}"
    mcpInstallerBaseUrl: "${MCP_INSTALLER_BASE_URL:-}"
    hostArch: ${WINGMAN_HOST_ARCH:-x86_64}
    binaryName: ${WINGMAN_BINARY_NAME:-bito-wingman}
    shelfKeep: "${WINGMAN_SHELF_KEEP:-2}"

# Security context
securityContext:
  fsGroup: 1000

# Namespace configuration
namespace:
  name: bito-ai-architect
  create: false  # Let Helm manage with --create-namespace flag

# Service account
serviceAccount:
  name: bitoarch-sa
  create: true

# RBAC configuration
# Set to false if your cluster user has limited permissions (common on GKE/GCP)
# The application doesn't require RBAC roles to function
rbac:
  create: false

# Secrets
secrets:
  mysqlRootPassword: ${MYSQL_ROOT_PASSWORD}
  mysqlPassword: ${MYSQL_PASSWORD}
  mysqlUser: ${MYSQL_USER}
  mysqlDatabase: ${MYSQL_DATABASE}
  temporalMysqlUser: ${TEMPORAL_MYSQL_USER:-temporal_user}
  temporalMysqlPassword: ${TEMPORAL_MYSQL_PASSWORD}
  bitoApiKey: ${BITO_API_KEY}
  cisManagerApiKey: ${CIS_MANAGER_API_KEY:-${BITO_API_KEY}}
  cisConfigApiKey: ${CIS_CONFIG_API_KEY:-${BITO_API_KEY}}
  cisProviderApiKey: ${CIS_PROVIDER_API_KEY:-${BITO_API_KEY}}
  gitProvider: ${GIT_PROVIDER}
  gitAccessToken: ${GIT_ACCESS_TOKEN}
  gitDomainUrl: ${GIT_DOMAIN_URL:-}
  gitUser: ${GIT_USER:-}
  # GitHub App auth (optional; empty for PAT installs). gitAppPrivateKey holds the
  # base64-encoded PEM (single line), consumed by cis-config as GIT_APP_PRIVATE_KEY_B64.
  gitAuthType: ${GIT_AUTH_TYPE:-}
  gitAppId: ${GIT_APP_ID:-}
  gitInstallationId: ${GIT_INSTALLATION_ID:-}
  gitAppPrivateKey: "${GIT_APP_PRIVATE_KEY_B64:-}"
  jwtSecret: ${JWT_SECRET}
  mcpAccessToken: ${BITO_MCP_ACCESS_TOKEN}
  encryptionKey: ${SECRETS_ENCRYPTION_KEY}

# LLM API Tokens (optional)
llm:
  anthropic:
    apiToken: ${ANTHROPIC_API_TOKEN:-}
  openai:
    apiToken: ${OPENAI_API_TOKEN:-}

# MySQL configuration
mysql:
  enabled: true
  image:
    repository: ${MYSQL_IMAGE_REPO}
    tag: ${MYSQL_IMAGE_TAG}
  replicaCount: 1
  healthCheck:
    enabled: true
    initialDelaySeconds: 30
    periodSeconds: 10
    timeoutSeconds: 5
    failureThreshold: 3

# CIS Config service
cisConfig:
  enabled: true
  image:
    repository: cis-config
  replicaCount: 1
  healthCheck:
    enabled: true
    initialDelaySeconds: 20
    periodSeconds: 10
    timeoutSeconds: 5
    failureThreshold: 5

# CIS Manager service
cisManager:
  enabled: true
  image:
    repository: cis-manager
  replicaCount: 1
  healthCheck:
    enabled: true
    # startupProbe covers warmup (~310s budget); readiness/liveness flip as soon as /health serves.
    startupInitialDelaySeconds: 10
    startupPeriodSeconds: 10
    startupTimeoutSeconds: 5
    startupFailureThreshold: 30
    initialDelaySeconds: 5
    periodSeconds: 10
    timeoutSeconds: 5
    failureThreshold: 3

# CIS Provider service
cisProvider:
  enabled: true
  image:
    repository: xmcp
  replicaCount: 1
  healthCheck:
    enabled: true
    # startupProbe covers default.json init + xmcp warmup; readiness flips when /health serves.
    startupInitialDelaySeconds: 10
    startupPeriodSeconds: 10
    startupTimeoutSeconds: 5
    startupFailureThreshold: 30
    initialDelaySeconds: 5
    periodSeconds: 10
    timeoutSeconds: 5
    failureThreshold: 3

# CIS Tracker service
cisTracker:
  enabled: true
  image:
    repository: cis-tracking
  replicaCount: 1
  healthCheck:
    enabled: true
    initialDelaySeconds: 20
    periodSeconds: 10
    timeoutSeconds: 5
    failureThreshold: 5

# Temporal server (workflow orchestration)
temporal:
  enabled: true
  image:
    repository: temporal
  replicaCount: 1
  healthCheck:
    enabled: true
    startupInitialDelaySeconds: 30
    startupPeriodSeconds: 10
    startupTimeoutSeconds: 5
    startupFailureThreshold: 15
    initialDelaySeconds: 20
    periodSeconds: 10
    timeoutSeconds: 5
    failureThreshold: 3

# CIS Worker (Temporal worker for distributed execution)
cisWorker:
  enabled: true
  image:
    repository: cis-worker
  replicaCount: ${CIS_WORKER_REPLICA_COUNT:-1}
  healthCheck:
    enabled: true
    # Trivial PID-1 liveness check; no warmup delay needed.
    initialDelaySeconds: 10
    periodSeconds: 10
    timeoutSeconds: 5
    failureThreshold: 5

# Ingress configuration (for external access via Ingress Controller)
ingress:
  enabled: true
  # One shared class/host for base + all plugins (BITOARCH_INGRESS_CLASS/HOST) = one front door.
  className: ${ing_class}  # bundled ai-architect-nginx, or your controller via BITOARCH_INGRESS_CLASS
  host: "${BITOARCH_INGRESS_HOST:-}"  # empty = accept all hosts, or set to your domain
  # Strip the /api/<service> route prefix (services serve at root). nginx-specific;
  # for another controller use its equivalent and reset pathType/pathSuffix to Prefix/"".
  annotations:
    nginx.ingress.kubernetes.io/use-regex: "true"
    nginx.ingress.kubernetes.io/rewrite-target: /\$2
  pathType: ImplementationSpecific
  pathSuffix: "(/|\$)(.*)"
  paths:
    provider: ${BITOARCH_INGRESS_PATH_PROVIDER:-/api/provider}
    manager: ${BITOARCH_INGRESS_PATH_MANAGER:-/api/manager}
    config: ${BITOARCH_INGRESS_PATH_CONFIG:-/api/config}
    tracker: ${BITOARCH_INGRESS_PATH_TRACKER:-/api/tracker}
  tls:
    enabled: false
    secretName: ""  # Name of TLS secret if using HTTPS

# Bundled ingress controller (the platform front door); skipped entirely when
# BITOARCH_INGRESS_CLASS points at an existing controller.
ingressController:
  enabled: ${ing_bundled}
  image: ${BITOARCH_INGRESS_CONTROLLER_IMAGE:-registry.k8s.io/ingress-nginx/controller:v1.11.5}
  exposure: ${ing_exposure}
  nodePorts:
    http: ${ing_np_http}
    https: ${ing_np_https}

# Resource limits
resources:
  config:
    limits:
      cpu: 500m
      memory: 512Mi
    requests:
      cpu: 250m
      memory: 256Mi
  manager:
    limits:
      cpu: 2000m
      memory: 2Gi
    requests:
      cpu: 1000m
      memory: 1Gi
  provider:
    limits:
      cpu: 2000m
      memory: 2Gi
    requests:
      cpu: 1000m
      memory: 1Gi
  tracker:
    limits:
      cpu: 500m
      memory: 512Mi
    requests:
      cpu: 250m
      memory: 256Mi
  mysql:
    limits:
      cpu: 1000m
      memory: 2Gi
    requests:
      cpu: 500m
      memory: 1Gi
  temporal:
    limits:
      cpu: 1000m
      memory: 2Gi
    requests:
      cpu: 500m
      memory: 1Gi
  worker:
    limits:
      cpu: 2000m
      memory: 2Gi
    requests:
      cpu: 1000m
      memory: 1Gi

# All environment variables (auto-imported from .env-bitoarch)
# This section contains ALL variables from the env file
environmentAll:
EOF
    
    log_silent "Auto-importing all environment variables..."
    
    if [[ -f "$env_file" ]]; then
        read_all_env_vars "$env_file" | sed 's/^/  /' >> "$output_file"
    else
        print_warning "User env file not found: $env_file"
    fi
    
    # Close the YAML
    echo "" >> "$output_file"
    
    if [[ ! -s "$output_file" ]]; then
        print_error "Failed to generate values file"
        return 1
    fi
    
    log_silent "Generated Kubernetes values file: $output_file"

    # Stage the busybox populate script into the chart's files/ dir so the chart-owned
    # populate Job (templates/07b-wingman-populate.yaml) can embed it via .Files.Get.
    # Single source of truth is scripts/wingman-shelf-populate.sh (shared with docker
    # compose + the on-demand CLI Job); this runs before every helm operation and this
    # function is k8s-only, so docker is unaffected. Same pattern as the provider
    # default.json the installer already writes into the chart tree before helm.
    # Perms: dir 0755, file 0644 -- helm must READ it for .Files.Get; the Job runs it
    # via `sh` (no exec bit needed) off a ConfigMap mount.
    local _wm_src="${SCRIPT_DIR}/scripts/wingman-shelf-populate.sh"
    local _wm_files_dir="${SCRIPT_DIR}/helm-bitoarch/files"
    if [[ -f "$_wm_src" ]]; then
        if mkdir -p "$_wm_files_dir" 2>/dev/null \
           && chmod 0755 "$_wm_files_dir" 2>/dev/null \
           && cp -f "$_wm_src" "$_wm_files_dir/wingman-shelf-populate.sh" 2>/dev/null \
           && chmod 0644 "$_wm_files_dir/wingman-shelf-populate.sh" 2>/dev/null; then
            log_silent "Staged wingman-shelf-populate.sh into the helm chart files/ dir"
        else
            print_warning "Could not stage wingman-shelf-populate.sh into the helm chart; the populate Job will no-op (services self-download Wingman)"
        fi
    else
        print_warning "wingman-shelf-populate.sh not found at ${_wm_src}; skipping chart populate staging"
    fi
    return 0
}

# Export functions for use in setup.sh
if [[ "${BASH_SOURCE[0]}" != "${0}" ]]; then
    # Script is being sourced
    export -f check_external_port_availability
    export -f detect_storage_class
    export -f validate_required_env_vars
    export -f validate_bitoarch_values
    export -f generate_k8s_values_from_env
else
    # Script is being executed directly
    print_info "Generating Kubernetes values file from environment configuration..."
    
    if generate_k8s_values_from_env; then
        print_status "Values file generated successfully"
        exit 0
    else
        print_error "Failed to generate values file"
        exit 1
    fi
fi
