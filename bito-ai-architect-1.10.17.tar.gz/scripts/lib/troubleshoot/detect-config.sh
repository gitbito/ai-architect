#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
# Bito's AI Architect CLI - Troubleshoot / Config section
#
# Reads the configuration state from cis-config with three read-only GETs and
# maps what is missing onto codes the config service's own catalog explains.
# An entitlement or key problem surfaces here first, because the config GET
# is entitlement-gated; it is reported as a general finding, never as a
# configuration one, and the remaining GETs are skipped since they would
# only repeat it.

if [ -n "${_BITOARCH_TROUBLESHOOT_DETECT_CONFIG_LOADED:-}" ]; then
    return 0
fi
_BITOARCH_TROUBLESHOOT_DETECT_CONFIG_LOADED=1

# GET one config endpoint. Returns: 0 = 2xx, 1 = 404, 2 = a general finding
# was recorded (stop), 3 = anything else (recorded as an uncoded warning).
_ts_config_get() {
    local path="$1" rc classified
    _ts_http_get "${CONFIG_URL}${path}"
    rc=$?
    if classified=$(_ts_classify_http config "$rc" "$_TS_HTTP_CODE" "$_TS_HTTP_BODY"); then
        if [ -n "$classified" ]; then
            _ts_add_classified "$classified"
            return 2
        fi
        return 0
    fi
    [ "$_TS_HTTP_CODE" = "404" ] && return 1
    troubleshoot_add_finding "" config warn "config service returned HTTP ${_TS_HTTP_CODE:-none} for ${path}"
    return 3
}

troubleshoot_collect_config() {
    local repo_count limit

    # Config-file findings recorded by diagnose (YAML validity) come first.
    troubleshoot_collect_config_files

    if [ -z "${CONFIG_URL:-}" ]; then
        troubleshoot_add_finding "" config warn "services not configured on this host (pre-install)"
        return 0
    fi
    _ts_services_blocked && return 0
    type ensure_config_service_accessible >/dev/null 2>&1 && ensure_config_service_accessible

    _ts_config_get "/api/v1/config"
    case $? in
        1) troubleshoot_add_finding CONFIG_NOT_FOUND config "$(_ts_severity_for CONFIG_NOT_FOUND fail)" ""; return 0 ;;
        2|3) return 0 ;;
    esac
    limit="${CIS_REPO_LIMIT:-}"
    if [ -n "$limit" ] && printf '%s' "$limit" | grep -Eq '^[0-9]+$'; then
        repo_count=$(printf '%s' "$_TS_HTTP_BODY" | jq -r '(.repositories // []) | length' 2>/dev/null)
        if [ -n "$repo_count" ] && [ "$repo_count" -gt "$limit" ] 2>/dev/null; then
            troubleshoot_add_finding REPO_LIMIT_EXCEEDED config warn "${repo_count} configured, limit ${limit}"
        fi
    fi

    _ts_config_get "/api/v1/config/llm"
    case $? in
        1) troubleshoot_add_finding LLM_CONFIG_MISSING config "$(_ts_severity_for LLM_CONFIG_MISSING fail)" "" ;;
        2) return 0 ;;
    esac

    _ts_config_get "/api/v1/config/scheduler"
    case $? in
        1) troubleshoot_add_finding SCHEDULER_CONFIG_MISSING config "$(_ts_severity_for SCHEDULER_CONFIG_MISSING warn)" "" ;;
    esac
    return 0
}
