#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
# Bito's AI Architect CLI - Troubleshoot / Catalogs
#
# A troubleshooting catalog maps a stable finding code to what it means and
# how to fix it. Every owner ships one in the same shape -- the platform file
# beside this script, the services inside their images -- and this module is
# the only place that reads them: validate, merge (platform wins on a code
# collision), resolve one code, list codes. Nothing here prints findings.

if [ -n "${_BITOARCH_TROUBLESHOOT_CATALOG_LOADED:-}" ]; then
    return 0
fi
_BITOARCH_TROUBLESHOOT_CATALOG_LOADED=1

_TS_LIB_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Merged catalog document and the list of where its entries came from.
_TS_CATALOG_JSON=""
_TS_CATALOG_SOURCES="[]"

# ─── Time helpers (shared by the readers and detectors) ───────────────────

# RFC-3339 timestamp -> epoch seconds. Fractional seconds are dropped and a
# "Z" or "+hh:mm" offset is accepted. BSD date needs -j -f, GNU date -d; the
# GNU form is probed once. Prints nothing when the value is unparseable.
_ts_epoch_of() {
    local iso="$1" plain
    [ -n "$iso" ] || return 1
    if date -u -d @0 >/dev/null 2>&1; then
        date -u -d "$iso" +%s 2>/dev/null
        return
    fi
    plain=$(printf '%s' "$iso" | sed -E 's/\.[0-9]+//')
    case "$plain" in
        *Z) date -u -j -f '%Y-%m-%dT%H:%M:%SZ' "$plain" +%s 2>/dev/null ;;
        *)  date -u -j -f '%Y-%m-%dT%H:%M:%S%z' "$(printf '%s' "$plain" | sed -E 's/([+-][0-9]{2}):([0-9]{2})$/\1\2/')" +%s 2>/dev/null ;;
    esac
}

# Epoch seconds -> ISO-8601 UTC.
_ts_iso_of_epoch() {
    local epoch="$1"
    if date -u -d @0 >/dev/null 2>&1; then
        date -u -d "@${epoch}" +%Y-%m-%dT%H:%M:%SZ 2>/dev/null
    else
        date -u -r "$epoch" +%Y-%m-%dT%H:%M:%SZ 2>/dev/null
    fi
}

# Modification time of a file as epoch seconds. GNU first: GNU `stat -f` is
# "file system status" and prints a block of text before failing, so trying
# the BSD form first on Linux would corrupt the value.
_ts_mtime_of() {
    stat -c %Y "$1" 2>/dev/null || stat -f %m "$1" 2>/dev/null
}

# Severity for a coded finding, taken from its catalog entry so a code the
# owner marked as a warning renders as one; $2 applies when the code is unknown.
_ts_severity_for() {
    local code="$1" default="${2:-fail}" sev
    sev=$(troubleshoot_resolve "$code" 2>/dev/null | jq -r '.severity // ""' 2>/dev/null)
    case "$sev" in
        warning) echo warn ;;
        error)   echo fail ;;
        *)       echo "$default" ;;
    esac
}

# The soft kube-context pin lets read-only commands run with an unresolvable
# context, on the contract that they report it instead of querying: a
# port-forward would target whatever cluster the ambient context names. Returns
# 0 (and records the finding once) when service calls must be skipped.
_ts_services_blocked() {
    [ -n "${BITOARCH_KUBE_UNREACHABLE:-}" ] || return 1
    troubleshoot_add_finding K8S_CONTEXT_MISSING general "$(_ts_severity_for K8S_CONTEXT_MISSING fail)" \
        "cluster.yaml context '${BITOARCH_KUBE_UNREACHABLE}' is not in your kubeconfig; services were not queried"
    return 0
}

# Prints one line per schema violation; returns 1 when any was found. A file
# that is not JSON at all is reported the same way. The whole check is one jq
# program so the platform file and a fetched service body are judged alike.
troubleshoot_catalog_validate() {
    local file="$1"
    local problems
    if [ ! -f "$file" ]; then
        echo "catalog file not found: $file"
        return 1
    fi
    if ! jq -e . "$file" >/dev/null 2>&1; then
        echo "catalog is not valid JSON"
        return 1
    fi
    local jq_err
    jq_err=$(mktemp)
    # A validator that cannot run must not pass the document it could not check.
    if ! problems=$(jq -r '
        def req(cond; msg): if cond then empty else msg end;
        def sections: ["setup","services","config","index","general"];
        def known_keys: ["schema_version","source","version","entries"];
        def entries: (.entries // []) | if type == "array" then . else [] end;
        [
          req(type == "object"; "root is not an object"),
          (if type == "object" then
            req(((keys - known_keys) | length) == 0; "unknown top-level key: " + ((keys - known_keys) | join(","))),
            req(.schema_version == 1; "schema_version must be 1"),
            req((.source | type) == "string" and (.source as $s | ["platform","cis-manager","cis-config"] | index($s) != null); "source must be platform, cis-manager or cis-config"),
            req((.version | type) == "string"; "version must be a string"),
            req((.entries | type) == "array" and ((.entries | length) > 0); "entries must be a non-empty array")
          else empty end),
          ( entries | to_entries[] | .key as $i | .value as $e |
            ($e.code // "?" | tostring) as $c |
            req(($e | type) == "object"; "entry \($i): not an object"),
            req(($e.code | type) == "string" and ($e.code | test("^[A-Z][A-Z0-9_]+$")); "entry \($i): code must match ^[A-Z][A-Z0-9_]+$"),
            req((sections | index($e.section)) != null; "entry \($i) (\($c)): section must be one of setup, services, config, index, general"),
            req((["error","warning"] | index($e.severity)) != null; "entry \($i) (\($c)): severity must be error or warning"),
            req(($e.title | type) == "string" and (($e.title | length) > 0); "entry \($i) (\($c)): title is required"),
            req(($e.causes | type) == "array" and (($e.causes | length) > 0) and all($e.causes[]; type == "string"); "entry \($i) (\($c)): causes must be a non-empty array of strings"),
            req(($e.fixes | type) == "array" and (($e.fixes | length) > 0)
                and all($e.fixes[]; type == "object" and (.text | type) == "string" and ((.text | length) > 0)
                        and ((.command // "") | type) == "string"); "entry \($i) (\($c)): fixes must be a non-empty array of {text, command?}"),
            req((($e.category // "") | type) == "string"; "entry \($i) (\($c)): category must be a string"),
            req((($e.docs_url // "") | type) == "string"; "entry \($i) (\($c)): docs_url must be a string")
          ),
          ( entries | map(.code) | group_by(.) | map(select(length > 1)) | .[] | "duplicate code: \(.[0])" )
        ] | .[]' "$file" 2>"$jq_err"); then
        echo "catalog validator failed: $(head -1 "$jq_err")"
        rm -f "$jq_err"
        return 1
    fi
    rm -f "$jq_err"
    if [ -n "$problems" ]; then
        printf '%s\n' "$problems"
        return 1
    fi
    return 0
}

# Loads the catalog shipped with the CLI. An invalid platform catalog is a
# packaging defect, not a runtime condition, so it is an error.
troubleshoot_catalog_load_platform() {
    local file="${_TS_LIB_DIR}/catalog-platform.json"
    local problems
    if ! problems=$(troubleshoot_catalog_validate "$file"); then
        print_error "Platform troubleshooting catalog is invalid: $(printf '%s' "$problems" | head -1)"
        return 2
    fi
    _TS_CATALOG_JSON=$(cat "$file")
    # The reported version is the platform's own, read from the versions
    # manifest CI bumps on every release; the string inside the catalog file is
    # only a fallback, so the two cannot drift apart.
    local live
    live=$(jq -r '.platform_info.version // empty' "${_TS_LIB_DIR}/../../../versions/service-versions.json" 2>/dev/null)
    _TS_CATALOG_SOURCES=$(jq -c --arg live "$live" \
        '[{source: .source, version: (if $live != "" then $live else .version end), origin: "builtin"}]' "$file")
    return 0
}

# Merges an already-validated catalog document into the merged one. On a code
# collision the entry already present wins -- the platform is loaded first, so
# it can override a service's wording -- and the operator is told once.
# Usage: troubleshoot_catalog_merge <json> [origin] [cached_at]
troubleshoot_catalog_merge() {
    local json="$1" origin="${2:-fetched}" cached_at="${3:-}"
    local collisions code existing new_source
    existing=$(printf '%s' "$_TS_CATALOG_SOURCES" | jq -r 'map(.source) | join("/")')
    new_source=$(printf '%s' "$json" | jq -r '.source // "unknown"')
    collisions=$(jq -n -r --argjson a "$_TS_CATALOG_JSON" --argjson b "$json" \
        '[$b.entries[].code] as $new | [$a.entries[].code] | map(select(. as $c | $new | index($c) != null)) | .[]')
    for code in $collisions; do
        print_warning "Troubleshooting code ${code} defined by both ${existing} and ${new_source}; using ${existing}"
    done
    _TS_CATALOG_JSON=$(jq -n -c --argjson a "$_TS_CATALOG_JSON" --argjson b "$json" \
        '($a.entries | map(.code)) as $have
         | $a | .entries += ($b.entries | map(select(.code as $c | ($have | index($c)) == null)))')
    _TS_CATALOG_SOURCES=$(jq -n -c --argjson s "$_TS_CATALOG_SOURCES" --argjson b "$json" \
        --arg origin "$origin" --arg cached_at "$cached_at" \
        '$s + [ {source: ($b.source // "unknown"), version: ($b.version // "unknown"), origin: $origin}
                + (if $cached_at != "" then {cached_at: $cached_at} else {} end) ]')
    return 0
}

# Prints the entry for a code as one JSON object; nothing and rc 1 when the
# merged catalog has no such code.
troubleshoot_resolve() {
    local code="$1" entry
    [ -n "$code" ] || return 1
    entry=$(printf '%s' "$_TS_CATALOG_JSON" | jq -c --arg c "$code" '.entries[] | select(.code == $c)' 2>/dev/null | head -1)
    [ -n "$entry" ] || return 1
    printf '%s\n' "$entry"
    return 0
}

# code<TAB>section<TAB>title, sorted by section then code; optional section filter.
troubleshoot_catalog_codes() {
    local section="${1:-}"
    printf '%s' "$_TS_CATALOG_JSON" | jq -r --arg s "$section" '
        .entries | map(select($s == "" or .section == $s))
        | sort_by(.section, .code) | .[] | [.code, .section, .title] | @tsv'
}

# ─── Service catalogs ─────────────────────────────────────────────────────
# Each service ships its own catalog inside its image and serves it behind
# the same access-key check as its status API. The CLI fetches it, validates
# it, caches it, and falls back to the cache when the service cannot be
# reached. Nothing from a response body is ever printed; outcomes become
# general-section findings instead.

troubleshoot_cache_dir()  { echo "${TROUBLESHOOT_CACHE_DIR:-${HOME}/.bitoarch/cache/troubleshoot}"; }
troubleshoot_cache_file() { echo "$(troubleshoot_cache_dir)/$1.json"; }

# GET with the Bearer key the services check. Sets _TS_HTTP_CODE and
# _TS_HTTP_BODY; returns curl's rc, or 99 without calling curl when the key
# is unset (so the caller can say "key missing" rather than "rejected").
_TS_HTTP_CODE=""
_TS_HTTP_BODY=""
_ts_http_get() {
    local url="$1" response rc
    _TS_HTTP_CODE=""
    _TS_HTTP_BODY=""
    [ -n "${BITO_API_KEY:-}" ] || return 99
    response=$(curl -s -w '\n%{http_code}' --max-time "${TROUBLESHOOT_HTTP_TIMEOUT:-15}" -X GET \
        -H "Authorization: Bearer ${BITO_API_KEY}" "$url" 2>/dev/null)
    rc=$?
    [ $rc -eq 0 ] || return $rc
    _TS_HTTP_CODE=$(printf '%s\n' "$response" | tail -1)
    _TS_HTTP_BODY=$(printf '%s\n' "$response" | sed '$d')
    return 0
}

# Maps an HTTP outcome onto a general-section finding, printed as
# code<TAB>severity<TAB>detail. Prints nothing for 2xx. Returns 1 when the
# outcome is not a general condition (a 404 or an unexpected status), so the
# caller decides what it means for its own section.
_ts_classify_http() {
    local svc="$1" rc="$2" code="$3" body="$4" upper
    upper=$(printf '%s' "$svc" | tr '[:lower:]' '[:upper:]')
    if [ "$rc" = "99" ]; then
        printf 'API_KEY_MISSING\tfail\t\n'
        return 0
    fi
    if [ "$rc" != "0" ] || [ -z "$code" ] || [ "$code" = "000" ]; then
        printf 'SERVICE_UNREACHABLE_%s\tfail\tconnection failed (curl rc %s)\n' "$upper" "$rc"
        return 0
    fi
    case "$code" in
        2*) return 0 ;;
        401) printf 'API_KEY_REJECTED\tfail\t%s returned 401\n' "$svc"; return 0 ;;
        400)
            case "$body" in
                *"wrong access key"*) printf 'API_KEY_REJECTED\tfail\t%s rejected the key\n' "$svc"; return 0 ;;
            esac
            return 1 ;;
        403)
            case "$body" in
                *"project_info feature is disabled"*) printf 'ENTITLEMENT_DENIED\tfail\t%s reports the workspace is not entitled\n' "$svc"; return 0 ;;
                *"Invalid authorization key"*)        printf 'API_KEY_REJECTED\tfail\t%s rejected the key\n' "$svc"; return 0 ;;
            esac
            return 1 ;;
        502)
            case "$body" in
                *"failed to fetch project-info context"*) printf 'BITO_CLOUD_UNREACHABLE\tfail\t%s cannot reach Bito to verify the workspace\n' "$svc"; return 0 ;;
            esac
            return 1 ;;
    esac
    return 1
}

# Adds the finding printed by _ts_classify_http (one row) to the accumulator.
_ts_add_classified() {
    local row="$1"
    [ -n "$row" ] || return 0
    _ts_split_row "${row%%	*}	general	${row#*	}"
    troubleshoot_add_finding "$_TS_ROW_CODE" general "$_TS_ROW_SEVERITY" "$_TS_ROW_DETAIL"
}

# Merges the cached copy of a service catalog, if there is a valid one.
# Returns 1 when there is none. $2 non-empty adds GUIDANCE_STALE past 7 days.
_ts_catalog_use_cache() {
    local svc="$1" warn_if_stale="${2:-}" cache mtime now age_days cached_at
    cache=$(troubleshoot_cache_file "$svc")
    [ -f "$cache" ] || return 1
    troubleshoot_catalog_validate "$cache" >/dev/null 2>&1 || return 1
    mtime=$(_ts_mtime_of "$cache")
    now=$(date -u +%s)
    cached_at=$(_ts_iso_of_epoch "${mtime:-$now}")
    troubleshoot_catalog_merge "$(cat "$cache")" cached "$cached_at"
    if [ -n "$warn_if_stale" ] && [ -n "$mtime" ]; then
        age_days=$(( (now - mtime) / 86400 ))
        if [ "$age_days" -gt 7 ]; then
            troubleshoot_add_finding GUIDANCE_STALE general warn "${svc} catalog cached ${age_days} days ago"
        fi
    fi
    type log_silent >/dev/null 2>&1 && log_silent "troubleshoot: using cached ${svc} catalog from ${cached_at}"
    return 0
}

# Fetches, validates, caches and merges one service's catalog; on any failure
# records why and falls back to the cache. $1: manager | config.
troubleshoot_catalog_fetch() {
    local svc="$1" url="" tmp dir cache rc classified problems general_added=""
    case "$svc" in
        manager)
            [ -n "${MANAGER_URL:-}" ] || return 0
            url="${MANAGER_URL}/api/v3/troubleshoot"
            type ensure_manager_service_accessible >/dev/null 2>&1 && ensure_manager_service_accessible ;;
        config)
            [ -n "${CONFIG_URL:-}" ] || return 0
            url="${CONFIG_URL}/api/v1/troubleshoot"
            type ensure_config_service_accessible >/dev/null 2>&1 && ensure_config_service_accessible ;;
        *) return 1 ;;
    esac

    _ts_http_get "$url"
    rc=$?
    case "$_TS_HTTP_CODE" in
        2*)
            if [ "$rc" -eq 0 ]; then
                tmp=$(mktemp)
                printf '%s' "$_TS_HTTP_BODY" > "$tmp"
                if problems=$(troubleshoot_catalog_validate "$tmp"); then
                    cache=$(troubleshoot_cache_file "$svc")
                    dir=$(dirname "$cache")
                    if mkdir -p "$dir" 2>/dev/null && chmod 600 "$tmp" 2>/dev/null && mv "$tmp" "$cache" 2>/dev/null; then
                        type log_silent >/dev/null 2>&1 && log_silent "troubleshoot: fetched ${svc} catalog into ${cache}"
                    else
                        rm -f "$tmp"
                        type log_silent >/dev/null 2>&1 && log_silent "troubleshoot: fetched ${svc} catalog; cache write to ${dir} failed"
                    fi
                    troubleshoot_catalog_merge "$_TS_HTTP_BODY" fetched
                    return 0
                fi
                rm -f "$tmp"
                troubleshoot_add_finding GUIDANCE_UNAVAILABLE general warn "${svc} catalog is invalid: $(printf '%s' "$problems" | head -1)"
                general_added=1
                type log_silent >/dev/null 2>&1 && log_silent "troubleshoot: ${svc} catalog invalid: $(printf '%s' "$problems" | head -1)"
            fi
            ;;
    esac
    if [ -z "$general_added" ]; then
        if classified=$(_ts_classify_http "$svc" "$rc" "$_TS_HTTP_CODE" "$_TS_HTTP_BODY"); then
            _ts_add_classified "$classified"
            general_added=1
        elif [ "$_TS_HTTP_CODE" = "404" ]; then
            troubleshoot_add_finding GUIDANCE_UNAVAILABLE general warn "${svc} build predates troubleshooting catalogs"
            general_added=1
        else
            troubleshoot_add_finding GUIDANCE_UNAVAILABLE general warn "${svc} returned HTTP ${_TS_HTTP_CODE:-none} for its catalog"
            general_added=1
        fi
        type log_silent >/dev/null 2>&1 && log_silent "troubleshoot: ${svc} catalog fetch failed (rc ${rc}, http ${_TS_HTTP_CODE:-none})"
    fi
    _ts_catalog_use_cache "$svc" warn && return 0
    return 1
}

# Network path: both services. Pre-install (no URLs) adds nothing.
troubleshoot_catalog_fetch_all() {
    if _ts_services_blocked; then
        troubleshoot_catalog_load_cached_all
        return 0
    fi
    troubleshoot_catalog_fetch manager
    troubleshoot_catalog_fetch config
    return 0
}

# Offline path for lookups and listings: cached copies only, never the network.
troubleshoot_catalog_load_cached_all() {
    _ts_catalog_use_cache manager
    _ts_catalog_use_cache config
    return 0
}
