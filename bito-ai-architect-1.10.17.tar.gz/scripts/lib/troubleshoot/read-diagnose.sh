#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
# Bito's AI Architect CLI - Troubleshoot / Last diagnose run
#
# Reads the findings `bitoarch diagnose` recorded and turns them into the
# setup, services and general sections. Reading is all it does: the probes
# stay in diagnose, so this module never calls docker, kubectl or curl.

if [ -n "${_BITOARCH_TROUBLESHOOT_READ_DIAGNOSE_LOADED:-}" ]; then
    return 0
fi
_BITOARCH_TROUBLESHOOT_READ_DIAGNOSE_LOADED=1

_TS_READ_DIAGNOSE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# The shared time helpers live in catalog.sh; pull it in when this file is
# loaded on its own (tests, support scripts).
if ! type _ts_epoch_of >/dev/null 2>&1; then
    # shellcheck source=/dev/null
    . "${_TS_READ_DIAGNOSE_DIR}/catalog.sh"
fi

# Which diagnose sections feed each troubleshoot section. Also the coverage
# contract: a troubleshoot section whose diagnose sections never ran must say
# so rather than read "no issues".
_ts_diagnose_sections_for() {
    case "$1" in
        setup)    echo "prereqs install filesystem cert wingman" ;;
        services) echo "services connectivity ingress plugins" ;;
        config)   echo "config" ;;
        *)        echo "" ;;
    esac
}

# Same path diagnose writes to (duplicated rather than sourced: the tests load
# this file on its own, and diagnose.sh drags the whole platform in).
troubleshoot_diagnose_file() {
    echo "${BITOARCH_DIAGNOSTICS_DIR:-${HOME}/.bitoarch/diagnostics}/last-run.json"
}

# Outcome of the last read, shared by the collectors and the renderer:
#   _TS_DIAG_STATE      ok | missing
#   _TS_DIAG_RUN_AT     generated_at of the run (empty when missing)
#   _TS_DIAG_RUN_STALE  1 when any recorded section is older than
#                       TROUBLESHOOT_DIAGNOSE_MAX_AGE_HOURS
#   _TS_DIAG_STALE_DETAIL  which section and when, for the finding
#   _TS_DIAG_SECTIONS_RUN  space-joined diagnose sections any run covered
_TS_DIAG_STATE=""
_TS_DIAG_RUN_AT=""
_TS_DIAG_RUN_STALE=""
_TS_DIAG_STALE_DETAIL=""
_TS_DIAG_SECTIONS_RUN=""

# Prints one line per finding: code<TAB>section<TAB>severity<TAB>message, with
# the diagnose section already mapped onto the troubleshoot section it belongs
# to. Returns 1 (and prints nothing) when there is no usable run.
troubleshoot_read_diagnose_findings() {
    local file now run_epoch max_hours age_hours oldest oldest_section oldest_at section_at line sec at
    file=$(troubleshoot_diagnose_file)
    _TS_DIAG_STATE="missing"
    _TS_DIAG_RUN_AT=""
    _TS_DIAG_RUN_STALE=""
    _TS_DIAG_STALE_DETAIL=""
    _TS_DIAG_SECTIONS_RUN=""

    [ -f "$file" ] || return 1
    jq -e '.schema_version == 1 and (.findings | type == "array")' "$file" >/dev/null 2>&1 || return 1

    _TS_DIAG_STATE="ok"
    _TS_DIAG_RUN_AT=$(jq -r '.generated_at // ""' "$file")
    _TS_DIAG_SECTIONS_RUN=$(jq -r '(.sections_run // []) | join(" ")' "$file")

    # Sections are merged across runs, so staleness is judged per section: the
    # oldest recorded section decides. Files from before per-section stamps
    # fall back to the run timestamp.
    max_hours="${TROUBLESHOOT_DIAGNOSE_MAX_AGE_HOURS:-24}"
    now=$(date -u +%s)
    oldest=""; oldest_section=""; oldest_at=""
    section_at=$(jq -r '(.section_run_at // {}) | to_entries[] | [.key, .value] | @tsv' "$file" 2>/dev/null)
    if [ -z "$section_at" ]; then
        section_at="run	${_TS_DIAG_RUN_AT}"
    fi
    while IFS= read -r line; do
        [ -n "$line" ] || continue
        sec="${line%%	*}"; at="${line#*	}"
        run_epoch=$(_ts_epoch_of "$at")
        [ -n "$run_epoch" ] || continue
        if [ -z "$oldest" ] || [ "$run_epoch" -lt "$oldest" ]; then
            oldest="$run_epoch"; oldest_section="$sec"; oldest_at="$at"
        fi
    done <<EOF3
$section_at
EOF3
    if [ -n "$oldest" ] && [ "$now" -ge "$oldest" ] 2>/dev/null; then
        age_hours=$(( (now - oldest) / 3600 ))
        if [ "$age_hours" -ge "$max_hours" ] 2>/dev/null; then
            _TS_DIAG_RUN_STALE=1
            _TS_DIAG_STALE_DETAIL="${oldest_section} last run ${oldest_at}"
        fi
    fi

    # Diagnose groups checks by what it probes; troubleshoot groups by what the
    # operator fixes. Config-file checks keep their own section, runtime probes
    # become services, everything else is setup.
    jq -r '
        def tsection:
            . as $s
            | if $s == "config" then "config"
              elif (["services","connectivity","ingress","plugins"] | index($s)) != null then "services"
              else "setup" end;
        .findings[]
        | [ (.code // ""), ((.section // "") | tsection), (.severity // "fail"),
            ((.message // "") | gsub("[\n\r\t]+"; " ")) ]
        | @tsv' "$file" 2>/dev/null
    return 0
}

# The run is read once per invocation; collectors share the rows. The reader
# is run with its output redirected, not substituted: a subshell would keep
# the _TS_DIAG_* state it sets away from this shell.
_TS_DIAG_LOADED=""
_TS_DIAG_ROWS=""
_ts_diag_load() {
    [ -n "$_TS_DIAG_LOADED" ] && return 0
    _TS_DIAG_LOADED=1
    local tmp
    tmp=$(mktemp 2>/dev/null) || tmp="/tmp/.bitoarch-ts-rows.$$"
    if troubleshoot_read_diagnose_findings > "$tmp" 2>/dev/null; then
        _TS_DIAG_ROWS=$(cat "$tmp")
    else
        _TS_DIAG_ROWS=""
    fi
    rm -f "$tmp"
    return 0
}

# Diagnose sections that feed troubleshoot section $1 but have never run on
# this host, space-joined; empty when fully covered or when no run exists.
_ts_diag_uncovered_for() {
    local want="$1" dsec missing=""
    [ "$_TS_DIAG_STATE" = "ok" ] || return 0
    for dsec in $(_ts_diagnose_sections_for "$want"); do
        case " $_TS_DIAG_SECTIONS_RUN " in
            *" $dsec "*) ;;
            *) missing="${missing:+$missing }$dsec" ;;
        esac
    done
    printf '%s' "$missing"
}

# Adds every recorded finding whose troubleshoot section is $1, then one
# warning when part of that section was never probed. A heredoc, not a pipe,
# so troubleshoot_add_finding mutates this shell's accumulator.
_ts_diag_collect_section() {
    local want="$1" line missing
    _ts_diag_load
    if [ -n "$_TS_DIAG_ROWS" ]; then
        while IFS= read -r line; do
            [ -n "$line" ] || continue
            _ts_split_row "$line"
            [ "$_TS_ROW_SECTION" = "$want" ] || continue
            troubleshoot_add_finding "$_TS_ROW_CODE" "$_TS_ROW_SECTION" "$_TS_ROW_SEVERITY" "$_TS_ROW_DETAIL"
        done <<EOF2
$_TS_DIAG_ROWS
EOF2
    fi
    missing=$(_ts_diag_uncovered_for "$want")
    if [ -n "$missing" ]; then
        troubleshoot_add_finding DIAGNOSE_RUN_PARTIAL "$want" warn "diagnose sections never run: $(printf '%s' "$missing" | tr ' ' ',')"
    fi
    return 0
}

troubleshoot_collect_setup()    { _ts_diag_collect_section setup; }
troubleshoot_collect_services() { _ts_diag_collect_section services; }

# Diagnose's config-file findings (YAML validity) land in the config section.
# A collector that also reads the config service redefines
# troubleshoot_collect_config and calls troubleshoot_collect_config_files first.
troubleshoot_collect_config_files() { _ts_diag_collect_section config; }
troubleshoot_collect_config()       { troubleshoot_collect_config_files; }

# Run-state problems that are not a check result themselves.
troubleshoot_collect_general() {
    _ts_diag_load
    if [ "$_TS_DIAG_STATE" != "ok" ]; then
        troubleshoot_add_finding DIAGNOSE_RUN_MISSING general warn ""
        return 0
    fi
    if [ -n "$_TS_DIAG_RUN_STALE" ]; then
        troubleshoot_add_finding DIAGNOSE_RUN_STALE general warn "${_TS_DIAG_STALE_DETAIL:-last run ${_TS_DIAG_RUN_AT}}"
    fi
    return 0
}
