#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
# Bito's AI Architect CLI - Troubleshoot / Index section
#
# Reads the latest index session from the manager's status API and turns the
# error codes it carries into findings. Codes are opaque here: what a code
# means lives in the manager's catalog, which is what makes this detector
# thin. One read-only GET; the manager adapter's own helper is not used
# because it renders errors to the terminal, and a detector must stay silent.

if [ -n "${_BITOARCH_TROUBLESHOOT_DETECT_INDEX_LOADED:-}" ]; then
    return 0
fi
_BITOARCH_TROUBLESHOOT_DETECT_INDEX_LOADED=1

# Hours without a new event after which a running session is reported stalled.
_ts_stall_hours() { echo "${TROUBLESHOOT_STALL_HOURS:-2}"; }

troubleshoot_collect_index() {
    local rc classified body session_id configured paused status started latest latest_epoch now hours
    local line code count sample detail

    if [ -z "${MANAGER_URL:-}" ]; then
        troubleshoot_add_finding "" index warn "services not configured on this host (pre-install)"
        return 0
    fi
    _ts_services_blocked && return 0
    type ensure_manager_service_accessible >/dev/null 2>&1 && ensure_manager_service_accessible

    _ts_http_get "${MANAGER_URL}/api/v3/indexing-status?verbose=true"
    rc=$?
    if classified=$(_ts_classify_http manager "$rc" "$_TS_HTTP_CODE" "$_TS_HTTP_BODY"); then
        if [ -n "$classified" ]; then
            _ts_add_classified "$classified"
            return 0
        fi
    else
        troubleshoot_add_finding "" index warn "manager status returned HTTP ${_TS_HTTP_CODE:-none}"
        return 0
    fi

    body="$_TS_HTTP_BODY"
    if ! printf '%s' "$body" | jq -e 'type == "object"' >/dev/null 2>&1; then
        troubleshoot_add_finding "" index warn "manager status response could not be parsed"
        return 0
    fi

    session_id=$(printf '%s' "$body" | jq -r '.session_id // "" | tostring')
    if [ -z "$session_id" ] || [ "$session_id" = "null" ]; then
        troubleshoot_add_finding INDEX_NEVER_RUN index warn ""
        return 0
    fi

    configured=$(printf '%s' "$body" | jq -r '.configured_repos // 0')
    [ "$configured" = "0" ] && troubleshoot_add_finding INDEX_NO_REPOS index warn ""

    paused=$(printf '%s' "$body" | jq -r '
        ((.status // "") | ascii_downcase) as $s
        | if (["paused","pausing"] | index($s)) != null then "true" else "false" end')
    [ "$paused" = "true" ] && troubleshoot_add_finding INDEX_PAUSED index warn "session ${session_id}"

    # One finding per code across repositories, with the repository count and
    # the first message as a redacted sample. Outcome is the server's own
    # classification: a coded failure is reported even on a repository the
    # server still counts as success.
    while IFS= read -r line; do
        [ -n "$line" ] || continue
        code="${line%%	*}"; line="${line#*	}"
        count="${line%%	*}"
        case "$line" in *"	"*) sample="${line#*	}" ;; *) sample="" ;; esac
        sample=$(printf '%s' "$sample" | _ts_redact | cut -c1-80)
        detail="${count} repositories"
        [ -n "$sample" ] && detail="${detail}, e.g. ${sample}"
        troubleshoot_add_finding "$code" index "$(_ts_severity_for "$code" fail)" "$detail"
    done <<EOF2
$(printf '%s' "$body" | jq -r '
    [ (.repositories // [])[] | select(.repo_name != null and .repo_name != "") | . as $r
      | (($r.details // {}).failed_event_details // [])[]
      | select((.error_code // "") != "")
      | {code: .error_code, repo: $r.repo_name, message: ((.message // "") | gsub("[\n\r\t]+"; " "))} ]
    | group_by(.code)
    | map({code: .[0].code, repos: (map(.repo) | unique | length), sample: .[0].message})
    | sort_by(.code) | .[] | [.code, (.repos | tostring), .sample] | @tsv' 2>/dev/null)
EOF2

    while IFS= read -r code; do
        [ -n "$code" ] || continue
        troubleshoot_add_finding "$code" index "$(_ts_severity_for "$code" fail)" "workspace-level stage"
    done <<EOF2
$(printf '%s' "$body" | jq -r '((.workspace_level_index // {}).failed_event_details // [])[] | select((.error_code // "") != "") | .error_code' 2>/dev/null | sort -u)
EOF2

    # A session that is still "running" but has written no index event for
    # longer than the stall window is almost always a worker that died
    # mid-run. The signal is the manager's session-level last_event_at (the
    # newest index_log row of the session); without it there is no verdict.
    # Per-repository last_update is deliberately not used: it is the metadata
    # row's update time, written at first clone and at finalize, not progress.
    status=$(printf '%s' "$body" | jq -r '(.status // "") | ascii_downcase')
    case "$status" in
        running|pending|resuming)
            started=$(printf '%s' "$body" | jq -r '.session_started_at // ""')
            latest=$(printf '%s' "$body" | jq -r '.last_event_at // ""')
            latest_epoch=$(_ts_epoch_of "$latest")
            now=$(date -u +%s)
            if [ -n "$latest_epoch" ] && [ "$now" -ge "$latest_epoch" ] 2>/dev/null; then
                hours=$(( (now - latest_epoch) / 3600 ))
                if [ "$hours" -ge "$(_ts_stall_hours)" ] 2>/dev/null; then
                    troubleshoot_add_finding INDEX_STALLED index "$(_ts_severity_for INDEX_STALLED fail)" \
                        "session ${session_id} ${status} since ${started:-unknown}, no index event for ${hours}h"
                fi
            fi
            ;;
    esac
    return 0
}
