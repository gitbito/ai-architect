#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
# Bito's AI Architect CLI - Troubleshoot / Rendering
#
# Owns the finding accumulator and everything the operator reads: the per-
# section text report, the --output json document, --list and the single-code
# lookup. Every finding detail that came from a service or a diagnose message
# passes through one redactor before it is printed or serialised -- index
# messages carry git stderr, which embeds the authenticated clone URL.

if [ -n "${_BITOARCH_TROUBLESHOOT_RENDER_LOADED:-}" ]; then
    return 0
fi
_BITOARCH_TROUBLESHOOT_RENDER_LOADED=1

_TS_RENDER_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Canonical redactor from the diagnose bundle when it is not loaded yet (tests,
# a trimmed install). Failing closed would print nothing useful; falling back
# to the inline pattern set is the compromise index-status already makes.
if ! type mask_stream >/dev/null 2>&1; then
    # shellcheck source=/dev/null
    . "${_TS_RENDER_DIR}/../diagnose/mask-secrets.sh" 2>/dev/null || true
fi

# stdin -> stdout. The userinfo rule always runs: a provider credential with no
# recognisable prefix only shows up as scheme://user:secret@host.
_ts_redact() {
    if type _index_status_redact >/dev/null 2>&1; then
        _index_status_redact
        return 0
    fi
    if type mask_stream >/dev/null 2>&1; then
        sed -E 's#(https?://)[^/[:space:]@]+@#\1***REDACTED***@#g' | mask_stream
        return 0
    fi
    sed -E \
        -e 's#(https?://)[^/[:space:]@]+@#\1***REDACTED***@#g' \
        -e 's/(glpat-|gh[pousr]_|github_pat_|xox[abprs]-)[A-Za-z0-9_-]{8,}/\1***REDACTED***/g' \
        -e 's/(AKIA|ASIA)[A-Z0-9]{16}/\1***REDACTED***/g' \
        -e 's/([Bb][Ee][Aa][Rr][Ee][Rr][[:space:]]+)[A-Za-z0-9._-]{8,}/\1***REDACTED***/g'
}

# ─── Accumulator ─────────────────────────────────────────────────────────
# One finding per line: code<TAB>section<TAB>severity<TAB>detail. Severity is
# fail or warn. A coded finding with the same detail is recorded once, so a
# general condition (an unreachable service, say) is not repeated by every
# collector that ran into it.
_TS_FINDINGS=""

troubleshoot_findings_reset() { _TS_FINDINGS=""; }

# Splits one row into _TS_ROW_CODE / _SECTION / _SEVERITY / _DETAIL. Parameter
# expansion rather than `read` with a tab IFS: tab is IFS whitespace, so `read`
# would swallow an empty leading code field and shift every column.
_ts_split_row() {
    local line="$1" rest
    _TS_ROW_CODE="${line%%	*}"; rest="${line#*	}"
    _TS_ROW_SECTION="${rest%%	*}"; rest="${rest#*	}"
    _TS_ROW_SEVERITY="${rest%%	*}"
    case "$rest" in
        *"	"*) _TS_ROW_DETAIL="${rest#*	}" ;;
        *)     _TS_ROW_DETAIL="" ;;
    esac
    return 0
}

troubleshoot_add_finding() {
    local code="$1" section="$2" severity="$3" detail="${4:-}" line
    detail=$(printf '%s' "$detail" | tr '\t\n' '  ')
    line="${code}	${section}	${severity}	${detail}"
    if [ -n "$code" ]; then
        case "$_TS_FINDINGS" in
            *"${line}
"*) return 0 ;;
        esac
    fi
    _TS_FINDINGS="${_TS_FINDINGS}${line}
"
    return 0
}

troubleshoot_findings_count() {
    printf '%s' "$_TS_FINDINGS" | awk 'NF { n++ } END { print n + 0 }'
}

_ts_count_severity() {
    printf '%s' "$_TS_FINDINGS" | awk -F'\t' -v s="$1" '$3 == s { n++ } END { print n + 0 }'
}

# 0 when at least one finding belongs to section $1.
_ts_section_has_findings() {
    [ "$(printf '%s' "$_TS_FINDINGS" | awk -F'\t' -v s="$1" '$2 == s { n++ } END { print n + 0 }')" -gt 0 ]
}

# 2 when any finding is a failure, 1 when only warnings, else 0.
troubleshoot_findings_exit_code() {
    if [ "$(_ts_count_severity fail)" -gt 0 ]; then echo 2
    elif [ "$(_ts_count_severity warn)" -gt 0 ]; then echo 1
    else echo 0; fi
}

# ─── Text ────────────────────────────────────────────────────────────────

_ts_section_title() {
    case "$1" in
        setup)    echo "Setup" ;;
        services) echo "Services" ;;
        config)   echo "Config" ;;
        index)    echo "Index" ;;
        general)  echo "General" ;;
        *)        echo "$1" ;;
    esac
}

# Prints one finding block. $4 (detail) may be empty for lookups.
_ts_render_finding() {
    local code="$1" severity="$2" detail="${3:-}"
    local entry title causes docs mark n text cmd
    detail=$(printf '%s' "$detail" | _ts_redact)
    case "$severity" in
        fail) mark="${RED}✗${NC}" ;;
        *)    mark="${YELLOW}⚠${NC}" ;;
    esac

    if [ -z "$code" ]; then
        printf '  %b %s\n' "$mark" "$detail"
        printf '    No guidance for this check yet. Collect a bundle and contact support:  %b\n' \
            "${YELLOW}bitoarch diagnose --bundle${NC}"
        return 0
    fi

    if ! entry=$(troubleshoot_resolve "$code"); then
        printf '  %b %s%s  %b\n' "$mark" "No guidance for this code" "${detail:+ ($detail)}" "${BLUE}[${code}]${NC}"
        entry=$(troubleshoot_resolve UNKNOWN_CODE) || return 0
    else
        title=$(printf '%s' "$entry" | jq -r '.title')
        printf '  %b %s%s  %b\n' "$mark" "$title" "${detail:+ ($detail)}" "${BLUE}[${code}]${NC}"
    fi

    causes=$(printf '%s' "$entry" | jq -r '.causes | join("; ")')
    printf '    Likely cause: %s\n' "$causes"
    n=0
    while IFS=$'\t' read -r text cmd; do
        [ -n "$text" ] || continue
        n=$((n + 1))
        if [ $n -eq 1 ]; then printf '    Fix:  '; else printf '          '; fi
        if [ -n "$cmd" ]; then
            printf '%d. %s:  %b\n' "$n" "$text" "${YELLOW}${cmd}${NC}"
        else
            printf '%d. %s\n' "$n" "$text"
        fi
    done <<EOF2
$(printf '%s' "$entry" | jq -r '.fixes[] | [.text, (.command // "")] | @tsv')
EOF2
    docs=$(printf '%s' "$entry" | jq -r '.docs_url // ""')
    [ -n "$docs" ] && printf '    Docs: %s\n' "$docs"
    return 0
}

# Names each guidance source and where it came from. Versions stay out of the
# text report (they are in --output json); a cached source shows when it was
# fetched so an operator can judge how current the advice is.
_ts_guidance_line() {
    printf '%s' "${_TS_CATALOG_SOURCES:-[]}" | jq -r '
        map(.source + " (" + .origin + (if .cached_at then " " + .cached_at else "" end) + ")")
        | join(", ")'
}

# Full report. $1: space-separated sections to show, in order.
troubleshoot_render_text() {
    local sections="$1" section shown line fails warns
    print_header "Bito's AI Architect Troubleshoot"
    echo ""
    for section in $sections; do
        print_subheader "▶ $(_ts_section_title "$section")"
        shown=0
        while IFS= read -r line; do
            [ -n "$line" ] || continue
            _ts_split_row "$line"
            [ "$_TS_ROW_SECTION" = "$section" ] || continue
            shown=$((shown + 1))
            _ts_render_finding "$_TS_ROW_CODE" "$_TS_ROW_SEVERITY" "$_TS_ROW_DETAIL"
        done <<EOF2
$_TS_FINDINGS
EOF2
        if [ $shown -eq 0 ]; then
            if ! type "troubleshoot_collect_${section}" >/dev/null 2>&1; then
                print_info "no checks for this section in this build"
            elif [ "${_TS_DIAG_STATE:-}" = "missing" ] && { [ "$section" = "setup" ] || [ "$section" = "services" ]; }; then
                print_info "no diagnose run recorded; run: ${YELLOW}bitoarch diagnose${NC}"
            else
                print_success "no issues"
            fi
        fi
        echo ""
    done

    fails=$(_ts_count_severity fail)
    warns=$(_ts_count_severity warn)
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo "Findings: $(troubleshoot_findings_count) (${fails} issues, ${warns} warnings)"
    if [ -n "${_TS_DIAG_RUN_AT:-}" ]; then
        echo "Inputs: diagnose run ${_TS_DIAG_RUN_AT}${_TS_DIAG_RUN_STALE:+ (stale)}"
    else
        echo "Inputs: no diagnose run recorded"
    fi
    echo "Guidance: $(_ts_guidance_line)"
}

# ─── JSON ────────────────────────────────────────────────────────────────

troubleshoot_render_json() {
    local cat="${_TS_CATALOG_JSON:-}"
    [ -n "$cat" ] || cat='{"entries":[]}'
    printf '%s' "$_TS_FINDINGS" | _ts_redact | jq -R -s \
        --argjson cat "$cat" \
        --argjson sources "${_TS_CATALOG_SOURCES:-[]}" \
        --arg at "$(date -u +%Y-%m-%dT%H:%M:%SZ)" \
        --arg run_at "${_TS_DIAG_RUN_AT:-}" --arg stale "${_TS_DIAG_RUN_STALE:-}" '
        { schema_version: 1,
          generated_at: $at,
          inputs: { diagnose_run: (if $run_at == "" then null else {generated_at: $run_at, stale: ($stale == "1")} end) },
          sources: $sources,
          findings: ( split("\n") | map(select(. != ""))
                      | map(split("\t") | {code: .[0], section: .[1], severity: .[2], detail: (.[3:] | join(" "))}
                            | . as $f | . + {entry: (($cat.entries | map(select(.code == $f.code)) | first) // null)}) ) }'
}

# ─── --list ──────────────────────────────────────────────────────────────

troubleshoot_render_list() {
    local section="${1:-}" code sec title
    printf "  ${BOLD}%-34s %-9s %s${NC}\n" "CODE" "SECTION" "TITLE"
    while IFS=$'\t' read -r code sec title; do
        [ -n "$code" ] || continue
        printf '  %-34s %-9s %s\n' "$code" "$sec" "$title"
    done <<EOF2
$(troubleshoot_catalog_codes "$section")
EOF2
    echo ""
    echo "Guidance: $(_ts_guidance_line)"
}

# Machine-readable listing: the merged entries of one section, or all.
troubleshoot_render_list_json() {
    local section="${1:-}"
    printf '%s' "$_TS_CATALOG_JSON" | jq --arg s "$section" --argjson sources "${_TS_CATALOG_SOURCES:-[]}" '
        { schema_version: 1, sources: $sources,
          entries: (.entries | map(select($s == "" or .section == $s)) | sort_by(.section, .code)) }'
}

# Machine-readable lookup. rc 0 when known, 1 otherwise; the document says which.
troubleshoot_render_lookup_json() {
    local code="$1" entry rc=0
    entry=$(troubleshoot_resolve "$code") || { entry="null"; rc=1; }
    jq -n --arg c "$code" --argjson e "$entry" --argjson sources "${_TS_CATALOG_SOURCES:-[]}" \
        '{ schema_version: 1, code: $c, found: ($e != null), sources: $sources, entry: $e }'
    return $rc
}

# ─── Lookup ──────────────────────────────────────────────────────────────

# rc 0 when the code is known, 1 otherwise (the UNKNOWN_CODE advice is shown).
troubleshoot_render_lookup() {
    local code="$1" entry severity
    if entry=$(troubleshoot_resolve "$code"); then
        severity=$(printf '%s' "$entry" | jq -r 'if .severity == "warning" then "warn" else "fail" end')
        echo ""
        _ts_render_finding "$code" "$severity" ""
        echo ""
        echo "Guidance: $(_ts_guidance_line)"
        return 0
    fi
    print_error "Unknown troubleshoot code: $code"
    echo ""
    _ts_render_finding "UNKNOWN_CODE" warn ""
    echo ""
    return 1
}
