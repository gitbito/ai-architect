#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
# Bito's AI Architect CLI - Troubleshoot
#
# `bitoarch troubleshoot` explains failures that were already observed and says
# what to do about them. It is an interpreter, not a probe: the setup and
# services sections come from the findings the last `bitoarch diagnose` run
# recorded, the index and config sections from read-only service API calls.
# Guidance is resolved against troubleshooting catalogs -- one built into the
# CLI (scripts/lib/troubleshoot/catalog-platform.json) and, once a collector
# registers them, one served by each service -- so a finding carries a stable
# code and the meaning of that code lives with whoever owns it.
#
# Layout (mirrors diagnose/):
#   troubleshoot/catalog.sh        catalog load / validate / merge / resolve
#   troubleshoot/read-diagnose.sh  last diagnose run -> findings (setup, services, general)
#   troubleshoot/render.sh         finding accumulator + text / json / list / lookup output
#   troubleshoot/detect-index.sh   latest index session -> findings (index)
#   troubleshoot/detect-config.sh  cis-config state -> findings (config)
#
# Section collectors are discovered by name (troubleshoot_collect_<section>) so
# a later library can add the index and config collectors without touching the
# loop below.

if [ -n "${_BITOARCH_TROUBLESHOOT_LOADED:-}" ]; then
    return 0
fi
_BITOARCH_TROUBLESHOOT_LOADED=1

_TROUBLESHOOT_LIB_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/troubleshoot"
if [ -d "$_TROUBLESHOOT_LIB_DIR" ]; then
    # shellcheck disable=SC1090,SC1091
    source "${_TROUBLESHOOT_LIB_DIR}/catalog.sh"
    # shellcheck disable=SC1090,SC1091
    source "${_TROUBLESHOOT_LIB_DIR}/read-diagnose.sh"
    # shellcheck disable=SC1090,SC1091
    source "${_TROUBLESHOOT_LIB_DIR}/render.sh"
    # shellcheck disable=SC1090,SC1091
    source "${_TROUBLESHOOT_LIB_DIR}/detect-index.sh"
    # shellcheck disable=SC1090,SC1091
    source "${_TROUBLESHOOT_LIB_DIR}/detect-config.sh"
fi

# Render order. Also the only values --section accepts.
_TS_SECTIONS="setup services config index general"

_platform_troubleshoot_help() {
    cat << 'EOF2'
USAGE:
  bitoarch troubleshoot [CODE] [OPTIONS]

DESCRIPTION:
  Explains the failures already observed on this host and prints likely causes
  and fixes, grouped by section: setup, services, config, index, general.
  Interprets the most recent `bitoarch diagnose` run; it does not probe the
  host itself. Guidance comes from troubleshooting catalogs: one built into the
  CLI and, when the services are reachable, one served by each service.

OPTIONS:
  <CODE>                    Look up one code (shown in brackets in the output,
                            or in `bitoarch index-status --failures`)
  --section <name>          Only one section: setup, services, config, index, general
  --list                    List every known code with its section and title
  --output json|text        Machine-readable output (default: text)
  --refresh                 Re-fetch service catalogs instead of using the cache
  --help, -h                Show this help

EXIT CODES:
  0  no issues   1  warnings only (or unknown code)   2  issues found (or bad arguments)

EXAMPLES:
  bitoarch diagnose && bitoarch troubleshoot
  bitoarch troubleshoot --section index
  bitoarch troubleshoot CLONE_AUTH_FAILED
  bitoarch troubleshoot --list --section general
  bitoarch troubleshoot --output json
EOF2
}

# Populates _TS_OPT_*. Returns 2 on a bad argument. Unknown flags warn and
# continue (same contract as diagnose); a bare word is only accepted when it
# looks like a code, so a stray path or typo cannot be mistaken for one.
_platform_troubleshoot_parse() {
    _TS_OPT_SECTION=""
    _TS_OPT_OUTPUT="text"
    _TS_OPT_REFRESH=""
    _TS_OPT_LIST=""
    _TS_OPT_CODE=""

    while [[ $# -gt 0 ]]; do
        case "$1" in
            --section)
                if [ -z "${2:-}" ]; then
                    print_error "--section requires a name"
                    return 2
                fi
                _TS_OPT_SECTION="$2"; shift 2 ;;
            --section=*) _TS_OPT_SECTION="${1#--section=}"; shift ;;
            --output)
                if [ -z "${2:-}" ]; then
                    print_error "--output requires text or json"
                    return 2
                fi
                _TS_OPT_OUTPUT="$2"; shift 2 ;;
            --output=*) _TS_OPT_OUTPUT="${1#--output=}"; shift ;;
            --list) _TS_OPT_LIST=1; shift ;;
            --refresh) _TS_OPT_REFRESH=1; shift ;;
            -*) print_warning "Ignoring unknown flag: $1"; shift ;;
            *)
                if [ -n "$_TS_OPT_CODE" ]; then
                    print_error "Only one code can be looked up at a time (got '$1' after '$_TS_OPT_CODE')"
                    return 2
                fi
                if printf '%s' "$1" | grep -Eq '^[A-Z][A-Z0-9_]+$'; then
                    _TS_OPT_CODE="$1"
                else
                    print_error "Not a troubleshoot code: '$1' (codes look like CLONE_AUTH_FAILED)"
                    return 2
                fi
                shift ;;
        esac
    done

    if [ -n "$_TS_OPT_SECTION" ]; then
        case " $_TS_SECTIONS " in
            *" $_TS_OPT_SECTION "*) ;;
            *)
                print_error "Unknown section: $_TS_OPT_SECTION"
                echo "Valid: setup, services, config, index, general" >&2
                return 2 ;;
        esac
    fi
    case "$_TS_OPT_OUTPUT" in
        text|json) ;;
        *) print_error "--output must be text or json (got '$_TS_OPT_OUTPUT')"; return 2 ;;
    esac
    return 0
}

# Entry point invoked by bitoarch.sh's dispatcher.
platform_troubleshoot() {
    if [ "${1:-}" = "--help" ] || [ "${1:-}" = "-h" ]; then
        _platform_troubleshoot_help
        return 0
    fi

    # Sourced helpers may leak errexit; collectors return non-zero by design.
    set +e

    _platform_troubleshoot_parse "$@" || return $?

    if ! command -v jq >/dev/null 2>&1; then
        print_error "jq is required for bitoarch troubleshoot"
        return 2
    fi

    troubleshoot_catalog_load_platform || return 2
    _TS_REFRESH="${_TS_OPT_REFRESH:-}"
    troubleshoot_findings_reset

    # Lookups and listings stay fast and offline: cached service catalogs
    # unless --refresh asks for the network.
    if [ -n "$_TS_OPT_CODE" ] || [ -n "$_TS_OPT_LIST" ]; then
        if [ -n "$_TS_REFRESH" ]; then
            troubleshoot_catalog_fetch_all
        else
            troubleshoot_catalog_load_cached_all
        fi
        if [ -n "$_TS_OPT_CODE" ]; then
            if [ "$_TS_OPT_OUTPUT" = "json" ]; then
                troubleshoot_render_lookup_json "$_TS_OPT_CODE"
            else
                troubleshoot_render_lookup "$_TS_OPT_CODE"
            fi
            return $?
        fi
        if [ "$_TS_OPT_OUTPUT" = "json" ]; then
            troubleshoot_render_list_json "$_TS_OPT_SECTION"
        else
            troubleshoot_render_list "$_TS_OPT_SECTION"
        fi
        return 0
    fi

    # A full run always asks the services; the cache is the fallback.
    troubleshoot_catalog_fetch_all

    local sections="$_TS_SECTIONS"
    [ -n "$_TS_OPT_SECTION" ] && sections="$_TS_OPT_SECTION"

    # The footer reports which diagnose run fed the report; load it even when
    # the requested sections do not read it, so a single-section run does not
    # claim that no run exists.
    type _ts_diag_load >/dev/null 2>&1 && _ts_diag_load

    local section
    for section in $sections; do
        if type "troubleshoot_collect_${section}" >/dev/null 2>&1; then
            "troubleshoot_collect_${section}"
        fi
    done

    # A key, entitlement or connectivity problem met while collecting one
    # section is recorded under general; a single-section run must still show
    # it, or the section reads "no issues" next to a failing exit code.
    if [ "$sections" != "$_TS_SECTIONS" ] && _ts_section_has_findings general; then
        case " $sections " in
            *" general "*) ;;
            *) sections="$sections general" ;;
        esac
    fi

    if [ "$_TS_OPT_OUTPUT" = "json" ]; then
        troubleshoot_render_json
    else
        troubleshoot_render_text "$sections"
    fi

    local rc
    rc=$(troubleshoot_findings_exit_code)
    if type log_silent >/dev/null 2>&1; then
        log_silent "troubleshoot: $(troubleshoot_findings_count) findings (rc=$rc)"
    fi
    return "$rc"
}
