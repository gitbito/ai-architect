# Bito's AI Architect CLI — Command Reference

Complete reference for the `bitoarch` command-line interface.

`bitoarch` is installed globally by the install bootstrap and works against Docker Compose, Standalone, and Kubernetes deployments. All commands support `--help` for per-command usage.

---

## Getting Help

| Command | Shows |
|---------|-------|
| `bitoarch --help` \| `-h` | Top-level help with all commands |
| `bitoarch <command> --help` | Command-specific usage and flags |
| `bitoarch --version` \| `-v` | CLI version |

---

## Status

Pre-install-safe — these commands degrade gracefully if services aren't running yet.

| Command | Description |
|---------|-------------|
| `bitoarch status` | Show all services status |
| `bitoarch health` | Check health of all services |
| `bitoarch info` | Show platform information (version, ports, endpoints) |
| `bitoarch diagnose` | Live pass/warn/fail sweep across prereqs, install, filesystem, config, services, connectivity, and certs |
| `bitoarch diagnose --bundle` | Collect a sharable `diagnostics-<timestamp>.tar.gz` for Bito support. Secrets auto-redacted. Optional: `--output <path>`, `--keep-workdir` |
| `bitoarch troubleshoot [CODE]` | Explain the failures recorded by the last `bitoarch diagnose` run (and, once the services are reachable, the latest index session and config state) with likely causes and fixes. `--section setup\|services\|config\|index\|general` shows one section; `--list` lists every known code; `CODE` looks one up (as printed in brackets or by `index-status --failures`); `--output json`; `--refresh` re-fetches service guidance. Guidance for index and config codes comes from the cis-manager and cis-config images and is cached locally, so it follows a service release without a CLI update. A single `--section` still shows General when a key, entitlement or connectivity problem was met. `bitoarch diagnose --section <name>` runs are merged per section into the recorded run; sections no run has covered are reported as `DIAGNOSE_RUN_PARTIAL` |

**Examples:**

```bash
bitoarch diagnose                              # live sweep
bitoarch diagnose --verbose
bitoarch diagnose --section services           # one section only
bitoarch diagnose --bundle                     # produce .tar.gz for support
bitoarch diagnose --bundle --output /tmp/debug
```

The bundle includes system info, service status + resource usage, last 1000 lines of container + app logs, redacted `.env`, DB health, connectivity probes, indexing status, temporal status, and local tracking events (on-prem analytics events captured under `tracking/`; embedded tokens/secrets are masked, while event fields such as email and ip_address are retained for support triage). Share the resulting archive with support@bito.ai.

---

## Lifecycle

| Command | Description |
|---------|-------------|
| `bitoarch start` | Start stopped services (idempotent) |
| `bitoarch stop` | Stop all services (keeps data) |
| `bitoarch restart [--force]` | Restart services. `--force` reloads env and recreates containers |
| `bitoarch logs [service]` | Tail service logs (`-f`). All services if `service` omitted |
| `bitoarch update` | Refresh service images per `versions/service-versions.json` (installed plugins update too) |
| `bitoarch upgrade [--version=<ver>]` | Upgrade platform (latest by default). Blue/green tarball swap; data preserved |
| `bitoarch uninstall` | Remove the services. Data and config are kept; `bitoarch start` restores |
| `bitoarch uninstall --purge` | Remove services, volumes, config, and logs. Keeps install directory and config backups |

**Examples:**

```bash
bitoarch restart --force            # reload env + recreate containers
bitoarch logs cis-provider          # tail one service
bitoarch upgrade                    # upgrade to latest
bitoarch upgrade --version=1.8.0    # upgrade to a specific version
```

> Rollback is not supported after a successful upgrade. The tarball keeps the previous install at `<parent>/bito-ai-architect-<old>` until you remove it.

---

## Repositories

| Command | Description |
|---------|-------------|
| `bitoarch add-repo <namespace>` | Add one repository (e.g. `myorg/my-repo`) |
| `bitoarch remove-repo <namespace>` | Remove one repository from the configuration (index data stays until purged) |
| `bitoarch remove-index [<namespace>...] [--dry-run] [--yes]` | Purge repository index data (shards, DB rows, clones). No arguments: purge every repo still indexed but no longer configured (config untouched). With namespaces: remove from config first, then purge |
| `bitoarch add-repos [file]` | Load repos from YAML. Uses `.bitoarch-config.yaml` if `file` omitted |
| `bitoarch update-repos [file]` | Update repos from YAML. Uses `.bitoarch-config.yaml` if `file` omitted |
| `bitoarch repo-info <name> [--dependencies]` | Show repository details (add `--dependencies` to include incoming/outgoing deps) |
| `bitoarch fetch-repo-list [--force-load]` | Sync repo list from your git provider. `--force-load` ignores local cache (not available for the `local` provider) |
| `bitoarch import-repos <path> [--allow-non-git]` | Copy pre-cloned repositories from a host directory into the platform and register them as `local/<dir>` (requires the `local` git provider; no git credentials). Re-run after pulling new commits or adding repos — unchanged repos are skipped. `--allow-non-git` also imports plain source trees (git history is synthesized; such repos are always fully re-indexed on change) |

**Examples:**

```bash
bitoarch add-repo myorg/backend-api
bitoarch add-repo mygroup/mysubgroup/backend-api   # GitLab nested subgroup
bitoarch add-repos                           # loads default config
bitoarch add-repos ./custom-repos.yaml
bitoarch repo-info backend-api --dependencies
bitoarch remove-index --dry-run              # preview orphaned indexes
bitoarch remove-index myorg/backend-api      # remove from config + purge index
bitoarch import-repos ~/repos                # local provider: import pre-cloned repos
```

> `import-repos` (local provider) scans the immediate subdirectories of `<path>` for git clones, copies them onto the platform's shared clone volume (works on Docker Compose and Kubernetes, single- or multi-node — no extra mounts), removes their `origin` remote in the copy, and registers each with cis-config. Indexing never contacts a remote for `local` repos: an unchanged HEAD is skipped, a new HEAD is indexed incrementally. `remove-repo` keeps the imported copy on disk for a fast re-add. Every repository must be readable by the user running the command: an unreadable file or directory fails that repository's import (and leaves any previously imported copy untouched) rather than copying it partially.

> `remove-index` reconcile mode (no arguments) and post-purge verification read the `repo_metadata` table and need `MYSQL_ROOT_PASSWORD` in the environment. While indexing or insights analysis is running the workspace is busy — retry after it completes.

---

## Indexing

| Command | Description |
|---------|-------------|
| `bitoarch show-config` | Show current indexing configuration |
| `bitoarch index-repos [OPTIONS]` | Trigger workspace repository indexing. `--mode force\|incremental` overrides the automatic per-repository decision; `--repo <ns>` (repeatable) limits the run to specific repositories; `--only-new-repos` skips incremental updates for existing repos; `--yes` confirms a workspace-wide rebuild non-interactively |
| `bitoarch index-status [OPTIONS]` | Check indexing status for the latest index session or one you name. `--failures` shows only failed repositories with every errored event and its reason; `--in-progress` shows only unfinished repositories with the stage each is executing; `--session <id>` reports a specific session; `--sessions` lists recent sessions; `--events` shows the session's audit entries; `--csv [<file>]` writes repository rows to CSV; `--all` forces the full table; `--raw` dumps the full API response; `--output json` emits machine-readable JSON; `--watch [<secs>]` repaints the view on an interval (default 60s, minimum 5s) until Ctrl+C |
| `bitoarch index-repo-list` | List indexed repositories |
| `bitoarch pause-indexing` | Pause an in-progress indexing run |
| `bitoarch resume-indexing` | Resume a paused indexing run |
| `bitoarch stop-indexing` | Stop indexing completely |
| `bitoarch create-index-scheduler` | Create scheduled indexing tasks |
| `bitoarch update-index-scheduler` | Update existing scheduled indexing tasks |
| `bitoarch export-index [OPTIONS]` | Export the workspace index into one protected `.cisidx` archive on the local path. `-o <file-or-dir/>` sets the output (default `./cis-index-<ws>-<id>.cisidx`; a directory receives that default name); `--scope basic\|ai\|all\|full` (default `full`); `--exclude-dk-source-docs`; `--keep` leaves the copy on the manager (deleted by default so nothing stays stored); `--timeout <secs>`. The download resumes interrupted transfers. No platform backup is created |
| `bitoarch import-index <file> [OPTIONS]` | Restore the workspace index from an archive made by `export-index` on an installation with the **same workspace id and Bito API key**. Verifies before changing anything; the previous index is kept until success and restored on failure. `--dry-run` verifies only (the upload is not kept; a real import sends the file again); `--yes` skips the prompt; `--scope` (a `basic`/`ai` import leaves repos needing a full run); `--source-path <path>` imports a file already copied under the manager's archive directory (must be readable by uid 1000; `docker cp` leaves files root-owned); `--timeout <secs>`. Uploads stream from disk with no size limit |

**Examples:**

```bash
bitoarch index-repos
bitoarch index-repos --only-new-repos
bitoarch index-status                        # summary + per-repo table
bitoarch index-status --failures             # what failed, and why
bitoarch index-status --in-progress          # what is running right now
bitoarch index-status --sessions             # recent index sessions
bitoarch index-status --session <id> --failures   # a previous run
bitoarch index-status --csv ./status.csv     # export every repository row
bitoarch index-status --raw                  # debugging
bitoarch index-status --output json          # scriptable
bitoarch index-status --watch 60              # live view, refreshed every 60s
bitoarch index-status --in-progress --watch   # default interval
bitoarch index-repo-list
bitoarch export-index -o /tmp/workspace-index.cisidx   # move the index to a fresh install
bitoarch import-index /tmp/workspace-index.cisidx --dry-run
bitoarch import-index /tmp/workspace-index.cisidx --yes
```

Archive network tunables (environment): `INDEX_ARCHIVE_HTTP_TIMEOUT` (status/control calls, 120s), `INDEX_ARCHIVE_CONNECT_TIMEOUT` (30s), `INDEX_ARCHIVE_STALL_SECS` (abort a transfer below 1 B/s for this long, 120s), `INDEX_ARCHIVE_DOWNLOAD_ATTEMPTS` (resumed download attempts, 3), `INDEX_ARCHIVE_POLL_INTERVAL` / `INDEX_ARCHIVE_POLL_TIMEOUT` / `INDEX_ARCHIVE_POLL_MAX_FAILURES` / `INDEX_ARCHIVE_POLL_MAX_MISSING` (status polling: 5s, 3600s, 12 consecutive connection failures, 3 consecutive 404s).

**Repository-level output**

Up to 25 repository rows print as a table. Above that the rows are written to a
CSV under `~/.bitoarch/reports/` and the path is printed instead, so the summary
stays readable in a large workspace. The count is taken *after* filtering, so
`--failures` with a handful of failures still prints on screen even when the
session covers hundreds of repositories. `--all` forces the table; `--csv <file>`
chooses the path and forces CSV at any row count.

The CSV has one row per repository, plus one row per errored event — a
repository with three failed events contributes three rows. Columns:
`repo,outcome,stage,event,error_code,error_message`. `outcome` is the server's
own classification, so a coded skip on an otherwise healthy repository is not
reported as a failure.

The export honours the active filter: `--in-progress --csv` writes only the
in-progress repositories. With `--events`, `--csv` exports that session's audit
rows using the manager's own CSV rendering.

`--csv` is rejected rather than silently ignored when combined with
`--sessions`, `--raw` or `--json`. `--failures` and `--in-progress` also apply
to `--json` / `--output json`, and cannot be combined with `--raw`.

Error messages are redacted before being printed or written: git echoes the
authenticated clone URL in its stderr, and the CLI must not put a token on a
terminal or into a file.

**Error codes**

Failures carry a stable `error_code` (for example `ZOEKT_TIMEOUT`,
`BASIC_INDEX_OOM`, `CLONE_AUTH_FAILED`, `ACTIVITY_HEARTBEAT_TIMEOUT`) alongside
the human-readable reason. Event names are shown as display names; the error
code is the identifier to branch on in scripts.

**Choosing a mode**

With no `--mode`, the system decides per repository whether it needs a first full index or an incremental update. Pass `--mode` only to override that.

| You want to | Run |
|---|---|
| Update everything that changed (the normal case) | `bitoarch index-repos` |
| Rebuild one repository from scratch | `bitoarch index-repos --mode force --repo myorg/api` |
| Rebuild several from scratch | `bitoarch index-repos --mode force --repo myorg/api --repo myorg/web` |
| Rebuild the whole workspace from scratch | `bitoarch index-repos --mode force` |
| Update one already-indexed repository | `bitoarch index-repos --mode incremental --repo myorg/api` |
| Index only newly added repositories | `bitoarch index-repos --only-new-repos` |

- **`--mode force`** rebuilds the index whether or not one already exists. On the whole workspace it re-runs AI analysis for every repository and is the slowest operation available, so it asks for confirmation; pass `--yes` to skip the prompt in a script.
- **`--mode incremental`** indexes only what changed. It needs an existing index to compare against, so repositories that have never been indexed are skipped and listed in the output rather than quietly given a first full index — index those without `--mode` first. If none of the repositories you asked for has an index, the command fails and says so.
- `--mode` cannot be combined with `--only-new-repos`; they ask for opposite things.

> One indexing job runs per workspace at a time. `--repo` limits which repositories are indexed — it does not let two runs proceed in parallel. If you add a repo mid-run, re-trigger `index-repos` after the current job finishes.

---

## Configuration

| Command | Description |
|---------|-------------|
| `bitoarch update-api-key` | Update Bito API key (interactive or `--api-key <key> [--restart]`) |
| `bitoarch update-git-creds` | Update Git provider credentials (interactive or `--provider <p> --token <t> [--restart]`) |
| `bitoarch update-llm-config` | Update custom LLM provider configuration (interactive) |
| `bitoarch rotate-mcp-token [<new-token>]` | Rotate MCP access token. Omit arg to auto-generate |
| `bitoarch config path [env\|repos\|llm]` | Print the absolute path of a config file (default: `env`) |
| `bitoarch config edit [env\|repos\|llm]` | Open a config file in `$EDITOR` (default: `env`) |

**Config file types:**

| Type | File | Purpose |
|------|------|---------|
| `env` | `.env-bitoarch` | Main environment config (ports, credentials, secrets) |
| `repos` | `.bitoarch-config.yaml` | Repository list |
| `llm` | `.env-llm-bitoarch` | Custom LLM provider configuration |

**Examples:**

```bash
bitoarch config path repos          # prints path to .bitoarch-config.yaml
bitoarch config edit env            # edit .env-bitoarch
bitoarch update-api-key --api-key bito_xxx --restart
bitoarch update-git-creds --provider github --token ghp_xxx --restart
bitoarch rotate-mcp-token           # auto-generates a new token
```

---

## Insights

Optional features that analyze commit history, Jira tickets, and Confluence docs to surface engineering activity insights. Each feature runs independently; all three work better together.

| Command | Description |
|---------|-------------|
| `bitoarch insights config` | Show enabled insights features, providers, and credentials |
| `bitoarch insights status` | Show detailed insights workflow status (phase, per-feature progress) |
| `bitoarch insights run [--force]` | Run insights analysis on-demand (independent of indexing). `--force` re-runs even if data hasn't changed |
| `bitoarch insights enable <feature>` | Enable an insights feature (interactive). Features: `git`, `ticket-tracker`, `docs` |
| `bitoarch insights disable <feature>` | Disable an insights feature |
| `bitoarch insights tracker-projects list` | List currently configured project keys |
| `bitoarch insights tracker-projects add <KEY> [KEY …]` | Add project keys to analyze |
| `bitoarch insights tracker-projects remove <KEY> [KEY …]` | Remove project keys |
| `bitoarch insights tracker-projects set <KEY> [KEY …]` | Replace all configured keys |
| `bitoarch insights discover-tracker-projects` | List accessible ticket-tracker projects with markers for currently selected ones |
| `bitoarch insights update-ticket-tracker` | Update ticket-tracker credentials (interactive) |
| `bitoarch insights update-doc-config` | Update doc integration credentials (interactive) |

**Prerequisites:**

| Feature | Requires |
|---------|----------|
| Git Insights | Git provider credentials (already configured during install) |
| Ticket Tracker | Jira base URL + email + [Atlassian API token](https://id.atlassian.com/manage-profile/security/api-tokens) |
| Docs | Confluence URL + email + Atlassian API token |

**Examples:**

```bash
bitoarch insights enable git
bitoarch insights enable ticket-tracker       # prompts for Jira creds
bitoarch insights enable docs                 # prompts for Confluence creds
bitoarch insights config                      # verify what's enabled
bitoarch insights run                         # trigger analysis
bitoarch insights run --force                 # re-run even if no new data

bitoarch insights discover-tracker-projects   # interactive project selection
bitoarch insights tracker-projects add PROJ INFRA

bitoarch insights update-ticket-tracker       # rotate Jira token
bitoarch insights update-doc-config           # rotate Confluence token
```

**Lookback window:**

Insights analyzes the most recent N days of history (default 180). Git and Jira can have separate windows via `INSIGHTS_GIT_LOOKBACK_DAYS` and `INSIGHTS_JIRA_LOOKBACK_DAYS` in `.env-bitoarch`. Use `bitoarch insights set-lookback [git|ticket-tracker] [DAYS]` to change.

**Troubleshooting:**

```bash
# "Existing Jira credentials failed validation"
# → Atlassian API token may have expired. Regenerate at
#   https://id.atlassian.com/manage-profile/security/api-tokens
bitoarch insights update-ticket-tracker

# Confluence URL issues (double /wiki path)
# → Provide the base URL without /wiki (e.g. https://acme.atlassian.net)
bitoarch insights update-doc-config

# "Create base config first"
# → Run bitoarch add-repos before enabling insights
bitoarch add-repos
bitoarch insights enable ticket-tracker
```

---

## SSO

SSO is optional and disabled by default (bearer-token auth). When enabled, `bitoarch mcp-info` reflects the active auth mode.

| Command | Description |
|---------|-------------|
| `bitoarch sso setup` | Configure SSO (interactive: Enterprise IdP or Bito) |
| `bitoarch sso status` | Check SSO configuration and IdP verification |
| `bitoarch sso enable` | Re-enable previously disabled SSO |
| `bitoarch sso disable` | Disable SSO (interactive: temporary or permanent) |
| `bitoarch sso rotate-key` | Rotate SSO tenant management key |

**Auth modes:**

| Mode | Description |
|------|-------------|
| Bearer Token | Default — static MCP access token (SSO disabled) |
| Bito | SSO via Bito — no external IdP required |
| Enterprise IdP | SSO via your SAML/OIDC provider (Okta, Azure AD, etc.) |

**Examples:**

```bash
bitoarch sso setup
bitoarch sso status
bitoarch sso disable                # choose temporary or permanent
bitoarch sso enable                 # after temporary disable
bitoarch sso rotate-key
```

---

## MCP

| Command | Description |
|---------|-------------|
| `bitoarch mcp-info` | Show MCP URL, access token, and active auth mode |
| `bitoarch mcp-test` | End-to-end MCP connectivity check |
| `bitoarch mcp-tools [--details] [--summary] [--output <file>]` | List available MCP tools |
| `bitoarch mcp-tool-info <name>` | Show details for one MCP tool |
| `bitoarch mcp-capabilities [--output <file>]` | Show MCP server capabilities |

**Examples:**

```bash
bitoarch mcp-info
bitoarch mcp-test
bitoarch mcp-tools --details
bitoarch mcp-tool-info search_code
bitoarch mcp-capabilities --output caps.json
```

> Standalone installs additionally expose `bitoarch mcp-install` (auto-register the local MCP with installed coding agents) and `bitoarch mcp-cert` (HTTPS cert lifecycle). See the [Standalone Setup Guide](standalone-setup-guide.md).

---

## Common Workflows

### First-time setup

Install runs via the bootstrap (`curl … | bash` / `./scripts/bitoarch-install.sh`), not a `bitoarch` subcommand. On a host without internet access, install from the air-gapped bundle with `--bundle <path>` (see [Air-gapped install](enterprise-setup-guide.md#air-gapped-install-no-internet-on-the-host)). When required values (Bito API key, git provider/token) are missing, the bootstrap asks how to provide them: **[1] Standard** opens `~/.bitoarch/install.yaml` in your `$EDITOR` to fill everything in one pass, or **[2] Guided** prompts for each value in turn. The choice is skipped under `--auto` / no TTY and when the values are already pre-seeded. See the [standalone](standalone-setup-guide.md) / [enterprise](enterprise-setup-guide.md) setup guides for details. After install:

```bash
bitoarch status                     # verify services are up
bitoarch add-repos                  # load repos from .bitoarch-config.yaml
bitoarch index-repos                # start indexing
bitoarch index-status               # monitor progress
bitoarch mcp-info                   # grab MCP URL + token for your client
```

### Adding new repositories

```bash
bitoarch add-repo myorg/new-repo
bitoarch index-repos                # index only the new repo will still trigger a run
# or:
bitoarch index-repos --only-new-repos
```

### Indexing control

```bash
bitoarch index-repos
bitoarch pause-indexing
bitoarch resume-indexing
bitoarch stop-indexing
```

### Daily operations

```bash
bitoarch status
bitoarch health
bitoarch index-status
bitoarch index-repo-list
```

### Troubleshooting

```bash
bitoarch diagnose                   # record what is broken (pass/warn/fail per section)
bitoarch troubleshoot               # explain it: likely causes and fixes per section
bitoarch troubleshoot CLONE_AUTH_FAILED   # one code, as printed by index-status --failures
bitoarch diagnose --bundle          # collect everything for support@bito.ai
```

Supporting commands:

```bash
bitoarch status
bitoarch health
bitoarch logs                       # all services
bitoarch logs cis-manager           # one service
bitoarch index-status --raw
bitoarch mcp-test
bitoarch show-config
```

### Insights

```bash
bitoarch insights enable git
bitoarch insights enable ticket-tracker
bitoarch insights run
bitoarch insights config
```

### Credential rotation

```bash
bitoarch update-api-key
bitoarch update-git-creds
bitoarch insights update-ticket-tracker      # Jira token
bitoarch insights update-doc-config          # Confluence token
bitoarch rotate-mcp-token
bitoarch sso rotate-key             # only if SSO is enabled
```

### Tear-down

```bash
bitoarch stop                       # pause services
bitoarch uninstall --purge          # remove services + volumes + config (keeps install dir + backups)
bitoarch uninstall                  # remove services; data + config kept (start restores)
```

---

## Environment Variables

Config lives in `.env-bitoarch` (path: `bitoarch config path env`). Key variables:

| Variable | Purpose |
|----------|---------|
| `BITO_API_KEY` | Bito authentication key |
| `BITO_WORKSPACE_ID` | Bito workspace ID. cis-config needs it to create its first config row when it answers BYOK entitlement locally (`ENTITLEMENT_BYOK_LOCAL_BYPASS_ENABLED=true`: off by default, turned on for air-gapped installs with `byok_local_bypass_enabled: "true"` in install.yaml), so repositories can be saved without reaching Bito. In that mode the installer takes it from `bito_workspace_id` in install.yaml; only when it is not set there does it ask, and with no terminal to ask on it stops. A value already set here is never overwritten |
| `GIT_PROVIDER` | Git provider (`github`, `gitlab`, `bitbucket`, `azure-devops`, `local`). `local` is credential-less: repositories are pre-imported with `bitoarch import-repos` |
| `GIT_ACCESS_TOKEN` | Git personal access token |
| `BITO_MCP_ACCESS_TOKEN` | MCP server access token |
| `CIS_PROVIDER_EXTERNAL_PORT` | MCP server port (default: 5001 standalone / 8080 k8s) |
| `CIS_MANAGER_EXTERNAL_PORT` | Manager API port |
| `CIS_CONFIG_EXTERNAL_PORT` | Config API port |
| `CIS_TRACKER_EXTERNAL_PORT` | Tracker API port |
| `MYSQL_EXTERNAL_PORT` | MySQL port-forward port (Kubernetes only; Docker does not publish MySQL) |
| `CIS_PROVIDER_BIND_ADDRESS` | Docker: address the MCP port listens on. Empty means every interface on Enterprise and `127.0.0.1` on Standalone; set `0.0.0.0` on Standalone to listen on every IPv4 interface |
| `INGRESS_BIND_ADDRESS` | Docker: address the ingress port listens on. Empty means every interface on Enterprise and `127.0.0.1` on Standalone; set `0.0.0.0` on Standalone to listen on every IPv4 interface |
| `INSIGHTS_GIT_ENABLED` | Enable git commit insights (`true`/`false`) |
| `INSIGHTS_TICKET_TRACKER_ENABLED` | Enable Jira ticket insights (`true`/`false`) |
| `INSIGHTS_DOCS_ENABLED` | Enable Confluence docs insights (`true`/`false`) |
| `INSIGHTS_GIT_LOOKBACK_DAYS` | Git insights lookback period (default: 180 days) |
| `INSIGHTS_JIRA_LOOKBACK_DAYS` | Jira insights lookback period (default: 180 days) |
| `CIS_REPO_LIMIT` | Max repositories configurable for indexing (default: 50; server hard-max: 500). Editable in `.env-bitoarch` + re-run `bitoarch config apply` — no reinstall |
| `CIS_REPO_SIZE_LIMIT` | Max indexable size per repository, in bytes (default: 5368709120 = 5GB) |
| `TEMPORAL_TASK_QUEUE_INDEXING_CONCURRENCY` | How many repositories are basic-indexed in parallel (platform default: 1, safe for minimum-sized hosts; the service falls back to its own default of 5 when unset). Positive integer only. Raise on hosts with memory/disk headroom for a faster initial index. Editable in `.env-bitoarch` + `bitoarch restart` (`--force` on Kubernetes — a plain restart does not re-read the env file there); effective value shown by `bitoarch show-config` |
| `SCHEDULER_BASIC_INDEX_INTERVAL` | XMCP incremental (basic) index interval (default: 1h; configurable, e.g. `1h`, `24h`) |
| `CIS_WORKER_MEMORY_LIMIT` | cis-worker container memory limit, compose format (default: `7g`). Drives the compose limit and the Kubernetes pod memory limit. Editable in `.env-bitoarch` + `bitoarch restart --force` — no release needed. See [Worker memory sizing](#worker-memory-sizing) |
| `CIS_MODULE_BASIC_INDEX_NODE_HEAP_MB` | Node heap for the basic indexer, in MB (default: `5120`). **Change together with `CIS_WORKER_MEMORY_LIMIT`** — the worker keeps headroom for its non-heap memory, so the usable heap ceiling is the limit minus `max(25%, 1024MB)`; a heap above the ceiling only warns and is clamped by the worker at runtime |
| `STORAGE_ACCESS_MODE` | Access mode for shared app-data PVCs (Kubernetes; default `ReadWriteOnce`). Set `ReadWriteMany` for multi-node shared storage |
| `SHARED_STORAGE_CLASS` | StorageClass for shared app-data PVCs (Kubernetes; empty = global/auto-detected). Any RWX provider — EFS / GCP Filestore / Azure Files / NFS / Rook-Ceph |
| `MYSQL_STORAGE_CLASS` | StorageClass for the MySQL PVC (Kubernetes; empty = global). Keep on block storage — never NFS/RWX |
| `INDEX_STATUS_TABLE_MAX_ROWS` | How many repository rows `bitoarch index-status` prints before writing them to CSV instead (default: 25). Counted after `--failures` / `--in-progress` filtering |
| `BITOARCH_REPORTS_DIR` | Where `bitoarch index-status` writes CSV exports (default: `~/.bitoarch/reports`) |
| `INDEX_STATUS_FAILURE_PREVIEW` | How many failed events `bitoarch index-status` previews inline before pointing at `--failures` (default: 5) |
| `WATCH_DEFAULT_INTERVAL_SECS` | Interval used by a bare `--watch` when no seconds are given (default: 60) |
| `WATCH_MIN_INTERVAL_SECS` | Smallest interval `--watch` accepts; lower values are rejected (default: 5) |
| `TROUBLESHOOT_DIAGNOSE_MAX_AGE_HOURS` | How old a diagnose run may be before `bitoarch troubleshoot` marks it stale (default: 24) |
| `TROUBLESHOOT_CACHE_DIR` | Where `bitoarch troubleshoot` caches the guidance catalogs fetched from cis-manager and cis-config (default: `~/.bitoarch/cache/troubleshoot`) |
| `TROUBLESHOOT_STALL_HOURS` | Hours without a new event after which `bitoarch troubleshoot` reports a running index session as stalled (default: 2) |
| `TROUBLESHOOT_HTTP_TIMEOUT` | Seconds `bitoarch troubleshoot` waits for each service request (default: 15) |
| `BITOARCH_REQUIRE_SIGNED_ARTIFACTS` | `1`/`true`/`yes` refuses a release that has no published signature. Default `0`: an unsigned release is installed, and that is recorded in `setup.log`. Installing from a package on disk (`--bundle <path>`) defaults to `1`: only `0`/`false`/`no` installs a bundle without the `.asc` beside it. A published signature that fails, or cannot be checked, is refused either way. Set in the environment of the installer (`curl -fsSL <url> \| BITOARCH_REQUIRE_SIGNED_ARTIFACTS=1 bash`) or of `bitoarch upgrade`. The Wingman populate job checks digests only and ignores it |
| `BITOARCH_PUBLISHER_KEY` | Public key that `bitoarch upgrade` checks signatures against (default: `share/keys/bitoco-publisher.asc` in the install). The installers always use the key embedded in them. Leave unset outside testing |
| _(no env var)_ | The kubectl context is **not** settable by environment variable. Set `context:` in `cluster.yaml`; empty there means the current context is used (the installer asks you to confirm it) |
| `K8S_IMAGE_PULL_SECRET` | Existing docker-registry secret in the namespace for private registries (Kubernetes; empty = public pulls). Usually set via `cluster.yaml` |

See `.env-bitoarch.default` in the install directory for the full list with defaults.

### Worker memory sizing

The cis-worker runs the indexer, so it is the service to size for the host. The default (`7g`, with a `5120`MB Node heap) covers most deployments; size it explicitly for larger indexing workloads or smaller hosts. One knob for both deployment methods — `CIS_WORKER_MEMORY_LIMIT` sets the compose limit and the Kubernetes pod memory limit (the pod's scheduler request stays fixed at `1Gi`). How to set it:

- **At install:** `resources.cis_worker_memory` in `~/.bitoarch/install.yaml`.
- **After install:** edit `.env-bitoarch` (`bitoarch config edit env`), then `bitoarch restart --force`. Kubernetes deploys regenerate the Helm values from the env file, so the pod resources follow.

Change `CIS_WORKER_MEMORY_LIMIT` and `CIS_MODULE_BASIC_INDEX_NODE_HEAP_MB` **together**. The worker reserves headroom for its non-heap memory (the Go process, the zoekt/ctags/git subprocesses, Node's own overhead), so the usable heap ceiling is the limit minus `max(25%, 1024MB)` — for example a `7g` limit backs a `5376`MB heap. The platform never rewrites your values: the installer warns when the worker limit looks too large for the host's memory, setup and `restart` warn when the heap exceeds the ceiling (naming the value it will be capped to), and the worker clamps an over-sized heap at runtime against the live cgroup so a bad pairing degrades instead of crashing.

### Storage classes (Kubernetes, multi-node / shared storage)

By default all persistent volumes use the cluster's auto-detected StorageClass with `ReadWriteOnce` — unchanged for existing single-node and Docker Compose installs. To run across multiple nodes, put shared application data on a `ReadWriteMany` (RWX) class while keeping MySQL on block storage:

| Scenario | Settings |
|----------|----------|
| Default (single node / Docker) | none — local class + `ReadWriteOnce` |
| Multi-node, shared RWX storage | `SHARED_STORAGE_CLASS=<rwx-class>`, `STORAGE_ACCESS_MODE=ReadWriteMany`, `MYSQL_STORAGE_CLASS=<block-class>`. The chart never creates a StorageClass by default, so the cluster's existing classes are used with no extra action |

`<rwx-class>` is any ReadWriteMany-capable StorageClass (AWS EFS `efs.csi.aws.com`, GCP Filestore, Azure Files, NFS subdir provisioner, Rook-Ceph). MySQL must stay on a block / `ReadWriteOnce` class — databases are not safe on NFS/EFS.

> **Migrating an existing install:** a PVC's access mode and StorageClass are immutable after creation. An existing single-node install cannot switch to RWX in place — provision new PVCs on the RWX class and copy the data over before switching.

---

## Related Docs

- [Standalone Setup Guide](standalone-setup-guide.md) — single-machine developer install (shipped with standalone tarball)
- [Enterprise Setup Guide](enterprise-setup-guide.md) — multi-user / shared-server install, Docker Compose or Kubernetes (shipped with enterprise tarball)
