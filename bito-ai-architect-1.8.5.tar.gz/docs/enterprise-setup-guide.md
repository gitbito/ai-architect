# Bito's AI Architect — Enterprise Setup Guide

Enterprise install for multi-user or shared-server deployments. Supports Docker Compose and Kubernetes — the installer prompts you to pick.

> **Evaluating on your laptop?** Use the faster [Standalone Setup Guide](standalone-setup-guide.md) instead (one-command install, under 5 minutes).

---

## 1. Prerequisites

### Common (all deployments)

- **Bito API key** — from https://alpha.bito.ai/home/advanced
- **Git provider credentials** — GitHub, GitLab, or Bitbucket personal access token
- **Package tarball** — `bito-cis-*.tar.gz` from your release channel

### Docker Compose

| | Minimum | Recommended |
|--|--------|-------------|
| Docker | Desktop 20.10+ with Compose v2 | Docker Desktop 4.x+ |
| Docker RAM | 6 GB | 8 GB+ |
| Docker CPUs | 3 | 4+ |
| Disk | 10 GB | 50 GB+ |
| Ports | 5001–5005 free on localhost | Same (or customize) |

### Kubernetes

- `kubectl` and `helm` 3.x installed locally
- Access to a Kubernetes cluster (cluster config reachable via `kubectl cluster-info`)
- Ingress Controller (nginx, traefik, etc.) configured by your cluster admin — or use port-forward for testing
- Cluster resources: minimum 4 CPUs and 8 GB RAM available for the namespace

---

## 2. Install

```bash
tar -xzf bito-cis-*.tar.gz
cd bito-cis-*
./scripts/bitoarch-install.sh
```

You'll be prompted for:

1. **Deployment method** — Docker Compose (1) or Kubernetes (2)
2. **Bito API Key**
3. **Git provider** — GitLab / GitHub / Bitbucket + personal access token

The installer will:
- Validate prerequisites (Docker or kubectl/helm, ports, resources)
- Generate secure passwords, JWT, MCP token
- Deploy services (Provider, Manager, Config, Tracker, MySQL)
- Install the `bitoarch` CLI globally
- Print your MCP URL and access token on success

### Customize ports (optional)

Edit `.env-bitoarch.default` **before** install to override default ports:

```bash
CIS_PROVIDER_EXTERNAL_PORT=5001   # MCP server
CIS_MANAGER_EXTERNAL_PORT=5002
CIS_CONFIG_EXTERNAL_PORT=5003
MYSQL_EXTERNAL_PORT=5004
CIS_TRACKER_EXTERNAL_PORT=5005
```

---

## 3. Connect MCP client

Get your MCP URL and token:

```bash
bitoarch mcp-info
```

### Claude Desktop

`~/Library/Application Support/Claude/claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "ai-architect": {
      "url": "http://<host>:5001/mcp",
      "headers": { "Authorization": "Bearer <TOKEN>" }
    }
  }
}
```

### Cursor / VS Code

Settings → MCP → Add Server. Paste URL + token.

---

## 4. Add repositories

Edit `.bitoarch-config.yaml`:

```yaml
repository:
  configured_repos:
    - namespace: your-org/backend-api
    - namespace: your-org/frontend-app
```

Apply and index:

```bash
bitoarch add-repos
bitoarch index-repos
bitoarch index-status
```

Status values: `in_progress` | `completed` | `failed`. See `bitoarch index-status --raw` for the full API payload.

---

## 5. Insights (optional)

Insights features analyze commit history, Jira tickets, and Confluence docs to surface engineering activity metrics. They run independently of code indexing and are optional.

**During install:** the installer prompts for each feature. Pre-seed via `~/.bitoarch/install.yaml` to skip prompts (uncomment the `insights:` section and fill in values).

**After install:**

```bash
bitoarch insights enable git              # commit-history insights (reuses git creds)
bitoarch insights enable ticket-tracker   # prompts for Jira base URL + email + API token
bitoarch insights enable docs             # prompts for Confluence URL + email + API token
bitoarch insights run                     # trigger analysis
bitoarch insights config                  # check what's enabled
```

**Manage Jira project scope:**

```bash
bitoarch insights discover-tracker-projects   # interactive selection from accessible projects
bitoarch insights tracker-projects list       # show current keys
bitoarch insights tracker-projects add PROJ   # add a project key
bitoarch insights tracker-projects remove PROJ
```

**Credential rotation:**

```bash
bitoarch insights update-ticket-tracker    # re-enter Jira creds (validates before saving)
bitoarch insights update-doc-config        # re-enter Confluence creds
```

> Atlassian API tokens: [id.atlassian.com/manage-profile/security/api-tokens](https://id.atlassian.com/manage-profile/security/api-tokens). Provide the Confluence base URL without `/wiki` — the platform normalizes it automatically.

Full command list: [CLI Reference — Insights](CLI_REFERENCE.md#insights).

---

## 6. Deployment-specific notes

### Docker Compose

Services expose ports 5001–5005 on `localhost`. Logs live in `var/logs/` and in `docker compose logs`.

```bash
bitoarch status          # service health
bitoarch logs            # tail all services
bitoarch logs cis-provider
```

### Kubernetes

Services run in the `bito-ai-architect` namespace with ClusterIP (internal-only). External access requires an Ingress Controller or port-forward.

**Via Ingress (recommended for enterprise):**

```bash
curl http://your-domain.com/api/provider/health
curl http://your-domain.com/api/manager/health
curl http://your-domain.com/api/config/health
curl http://your-domain.com/api/tracker/health
```

**Via port-forward (testing/dev):**

```bash
kubectl port-forward svc/ai-architect-provider 8080:8080 -n bito-ai-architect
curl http://localhost:8080/health
```

**In-cluster (pod-to-pod):**

```bash
kubectl run curl --image=curlimages/curl -it --rm --restart=Never -n bito-ai-architect -- \
  curl http://ai-architect-provider:8080/health
```

**Check pods:**

```bash
kubectl get pods -n bito-ai-architect
kubectl logs -n bito-ai-architect -l app.kubernetes.io/component=provider --tail=100 -f
```

---

## 7. Operations

```bash
bitoarch status                     # health
bitoarch logs [service]             # tail
bitoarch restart                    # restart services
bitoarch restart --force            # reload env + recreate
bitoarch update                     # pull latest images (per versions/service-versions.json)
bitoarch upgrade                    # upgrade platform (blue/green, data preserved)
bitoarch upgrade --version=1.8.0    # upgrade to a specific version
```

Full command list: [CLI Reference](CLI_REFERENCE.md).

---

## 8. Credentials & SSO

Secrets live in `.env-bitoarch` (path: `bitoarch config path env`):

- `BITO_API_KEY` — Bito authentication
- `GIT_ACCESS_TOKEN` — Git provider PAT
- `BITO_MCP_ACCESS_TOKEN` — MCP server token (auto-generated)
- Database passwords and JWT secret (auto-generated)

**Keep `.env-bitoarch` secure — back it up.**

### Rotate credentials

```bash
bitoarch update-api-key
bitoarch update-git-creds
bitoarch rotate-mcp-token
```

### SSO (optional)

By default, MCP uses a static bearer token. Enable SSO for user-level auth:

```bash
bitoarch sso setup       # choose Enterprise IdP (SAML/OIDC) or Bito
bitoarch sso status
bitoarch sso disable     # temporary or permanent
bitoarch sso enable      # re-enable after temporary disable
bitoarch sso rotate-key
```

When SSO is enabled, `bitoarch mcp-info` reflects the active auth mode.

---

## 9. Troubleshooting

```bash
# Live diagnostic sweep — pass/warn/fail per section
bitoarch diagnose
bitoarch diagnose --verbose

# Services not starting — check logs
bitoarch logs
tail -f setup.log

# Port conflicts (Docker Compose) — edit BEFORE install
vim .env-bitoarch.default   # change CIS_*_EXTERNAL_PORT values

# Indexing stuck
bitoarch index-status --raw
bitoarch logs cis-manager
bitoarch stop-indexing && bitoarch index-repos

# Kubernetes pod issues
kubectl describe pod <pod> -n bito-ai-architect
kubectl logs <pod> -n bito-ai-architect --previous    # after CrashLoopBackOff

# MCP connectivity check
bitoarch mcp-test
```

**Escalating to Bito support:** run `bitoarch diagnose --bundle` to produce a redacted `.tar.gz` containing system info, logs, config, DB health, and indexing/temporal state. Share the archive with support@bito.ai when opening a ticket.

---

## 10. Uninstall

```bash
bitoarch reset        # wipe containers/volumes/config; keep install dir
bitoarch uninstall    # full removal
```

Docker images are kept — run `docker image prune` to reclaim disk.

For Kubernetes, `bitoarch uninstall` removes the Helm release and namespace.

---

## 11. Additional Resources

- [CLI Reference](CLI_REFERENCE.md) — complete command documentation
- [Setup Guide](https://docs.bito.ai/ai-architect/install-ai-architect-self-hosted) — official self-hosted install docs
- [How to Use AI Architect](https://docs.bito.ai/ai-architect/install-ai-architect-self-hosted#how-to-use-ai-architect) — integrations with Claude, Cursor, etc.
