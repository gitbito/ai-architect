#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
#
# Integrity verification for first-party artifacts downloaded from the CDN.
#
# The release pipeline publishes two side-cars next to an artifact:
#   <artifact-url>.sha256   sha256sum format: "<hex>  <filename>"
#   <artifact-url>.asc      detached GPG signature, made with the publisher key
#                           bundled at share/keys/bitoco-publisher.asc
# Whichever of the two is published is checked, and both must pass when both
# exist. This is the same trust model the plugin installer already uses
# (scripts/lib/plugin/plugin-updater.sh); this file exists separately because it
# is sourced from upgrade.sh, which must not pull in the plugin stack.
#
# The digest alone only proves the bytes arrived intact -- it is published to the
# same bucket as the artifact, so anything able to replace one can replace the
# other. The signature is the check that survives a compromised CDN.
#
# BITOARCH_REQUIRE_SIGNED_ARTIFACTS controls what happens when no signature is
# published for an artifact: 0 (default) continues, 1 refuses. It stays at 0 until
# the pipeline publishes signatures for every artifact, because older releases on
# the CDN will never gain one. Only a refusal is shown; everything that lets an
# artifact through -- a digest verified with no signature beside it included --
# goes to the log.

# Prevent multiple sourcing
if [ -n "${_BITOARCH_VERIFY_ARTIFACT_LOADED:-}" ]; then
    return 0
fi
_BITOARCH_VERIFY_ARTIFACT_LOADED=1

_va_msg() {   # <level> <text>
    if [ "$1" = err ]; then
        if type msg_error >/dev/null 2>&1; then msg_error "$2" >&2; else printf 'ERROR: %s\n' "$2" >&2; fi
    fi
    type log_silent >/dev/null 2>&1 && log_silent "verify-artifact: $2"
    return 0
}

_va_publisher_key() {
    if [ -n "${BITOARCH_PUBLISHER_KEY:-}" ]; then printf '%s' "$BITOARCH_PUBLISHER_KEY"; return 0; fi
    printf '%s' "$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." 2>/dev/null && pwd)/share/keys/bitoco-publisher.asc"
}

_va_sha256() {
    if command -v sha256sum >/dev/null 2>&1; then sha256sum "$1" 2>/dev/null | awk '{print $1}'
    elif command -v shasum >/dev/null 2>&1; then shasum -a 256 "$1" 2>/dev/null | awk '{print $1}'
    else return 1; fi
}

_va_require_signed() {
    case "${BITOARCH_REQUIRE_SIGNED_ARTIFACTS:-0}" in 1|true|TRUE|yes|YES) return 0 ;; *) return 1 ;; esac
}

# Side-car fetches: seconds per attempt, which also caps the whole retry window,
# and how many times a transient failure is retried.
_VA_FETCH_TIMEOUT=60
_VA_FETCH_RETRIES=2
_VA_CURLE_FILE_COULDNT_READ_FILE=37   # curl's exit for a file:// URL that does not exist

# Fetch a side-car: rc 0 fetched, 1 not published, 2 could not fetch. The CDN
# answers 403/404 for a key that does not exist, as a missing file:// URL answers
# _VA_CURLE_FILE_COULDNT_READ_FILE; anything else -- a timeout, a reset, a 5xx -- is
# not "not published", and reading it as such would let one blip skip the check.
_va_fetch() {   # <url> <dest>
    local code rc=0
    code="$(curl -sfL -m "$_VA_FETCH_TIMEOUT" --retry "$_VA_FETCH_RETRIES" \
        --retry-max-time "$_VA_FETCH_TIMEOUT" -o "$2" -w '%{http_code}' "$1" 2>/dev/null)" || rc=$?
    [ "$rc" -eq 0 ] && return 0
    rm -f "$2" 2>/dev/null
    case "$code" in 403|404) return 1 ;; esac
    [ "$rc" -eq "$_VA_CURLE_FILE_COULDNT_READ_FILE" ] && return 1
    return 2
}

# Verify <file> against the digest (<url>.sha256) and detached signature
# (<url>.asc) published beside it.
# rc 0 = verified, or not enforced; rc 1 = reject (tampered, or unverifiable).
verify_artifact() {   # <file> <url> [<label>]
    local file="$1" url="$2" label="${3:-$(basename "$1")}" key asc sum home rc expected actual got
    local checked=0

    # An empty URL fetches nothing, which would read exactly like "no side-cars
    # published" and pass by default -- a caller bug turned into a silent skip.
    if [ -z "$url" ] || [ ! -s "$file" ]; then
        _va_msg err "nothing to verify for ${label} (missing file or URL); refusing to use it."
        return 1
    fi

    # --- published digest -----------------------------------------------------
    sum="${file}.sha256"
    got=0; _va_fetch "${url}.sha256" "$sum" || got=$?
    if [ "$got" -eq 2 ]; then
        _va_msg err "could not fetch the published digest for ${label}; refusing to use it."
        return 1
    elif [ "$got" -eq 0 ]; then
        expected="$(awk 'NR==1{print $1}' "$sum" 2>/dev/null)"
        rm -f "$sum" 2>/dev/null
        actual="$(_va_sha256 "$file")"
        if [ -z "$expected" ]; then
            _va_msg err "the published digest for ${label} is unreadable; refusing to use it."
            return 1
        elif [ -z "$actual" ]; then
            _va_msg err "no sha256sum/shasum available to check ${label}; refusing to use it."
            return 1
        elif [ "$expected" != "$actual" ]; then
            _va_msg err "SHA-256 mismatch for ${label} (expected ${expected}, got ${actual}); refusing to use it."
            return 1
        fi
        checked=1
        type log_silent >/dev/null 2>&1 && log_silent "verify-artifact: ${label} digest verified"
    fi

    # --- published signature --------------------------------------------------
    key="$(_va_publisher_key)"
    if [ ! -f "$key" ]; then
        _va_msg warn "publisher key not bundled at ${key}; the origin of ${label} cannot be verified."
        _va_require_signed && { _va_msg err "signed artifacts are required; refusing ${label}."; return 1; }
        return 0
    fi

    asc="${file}.asc"
    got=0; _va_fetch "${url}.asc" "$asc" || got=$?
    if [ "$got" -eq 2 ]; then
        _va_msg err "could not fetch the signature for ${label}; refusing to use it."
        return 1
    elif [ "$got" -eq 1 ]; then
        if [ "$checked" -eq 1 ]; then
            _va_msg warn "${label} matches its published digest, but no signature is published, so its origin is unverified (${url}.asc)."
        else
            _va_msg warn "no published digest or signature for ${label}; continuing unverified (${url}.asc)."
        fi
        _va_require_signed && { _va_msg err "signed artifacts are required; refusing ${label}."; return 1; }
        return 0
    fi

    # A signature exists, so the artifact is verifiable and anything short of a
    # good verification is a rejection -- including a missing gpg.
    if ! command -v gpg >/dev/null 2>&1; then
        rm -f "$asc" 2>/dev/null
        _va_msg err "${label} is signed but gpg is not installed; refusing to use an unverified artifact."
        return 1
    fi

    # A throwaway keyring, so only the publisher key can vouch for the artifact.
    # Unguarded, a failed mktemp hands gpg an empty --homedir.
    if ! home="$(mktemp -d)" || [ -z "$home" ]; then
        rm -f "$asc" 2>/dev/null
        _va_msg err "could not create a keyring to verify ${label}; refusing to use it."
        return 1
    fi
    if ! gpg --homedir "$home" --batch --quiet --import "$key" 2>"$home/gpg.err"; then
        rc=2
    elif gpg --homedir "$home" --batch --quiet --verify "$asc" "$file" 2>"$home/gpg.err"; then
        rc=0
    else
        rc=1
    fi
    # gpg's own reason, for the log: an expired key reads differently from a bad signature.
    [ "$rc" -ne 0 ] && type log_silent >/dev/null 2>&1 \
        && log_silent "verify-artifact: gpg: $(tail -1 "$home/gpg.err" 2>/dev/null | sed 's/^gpg: //')"
    rm -rf "$home" 2>/dev/null; rm -f "$asc" 2>/dev/null

    # A key that will not load is a packaging fault, not a tampered artifact --
    # reporting it as a failed signature would send the operator after the wrong one.
    if [ "$rc" -eq 2 ]; then
        _va_msg err "the bundled publisher key at ${key} could not be loaded; cannot verify ${label}, refusing to use it."
        return 1
    elif [ "$rc" -ne 0 ]; then
        _va_msg err "signature verification FAILED for ${label}; refusing to use it."
        return 1
    fi
    type log_silent >/dev/null 2>&1 && log_silent "verify-artifact: ${label} signature verified"
    return 0
}
