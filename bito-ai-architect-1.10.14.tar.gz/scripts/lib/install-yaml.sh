#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
#
# scripts/lib/install-yaml.sh
# YAML <-> env translation for $HOME/.bitoarch/install.yaml.
# Parsers: yq (preserves comments on writeback) or python3+PyYAML (read-only).
# Mapping: _install_yaml_mapping_pairs — single source of truth for yaml <-> env.

if [ -n "${_BITOARCH_INSTALL_YAML_LOADED:-}" ]; then
    return 0
fi
_BITOARCH_INSTALL_YAML_LOADED=1

if [ -z "${SCRIPT_DIR:-}" ]; then
    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
fi

# Defensive sourcing so callers that bypass install.sh orchestration
# (restart --force, setup.sh --force-restart) still have print_* / log_silent
# / get_install_yaml_file. Load guards make this a no-op when already sourced.
if [ -f "${SCRIPT_DIR}/scripts/lib/path-manager.sh" ]; then
    # shellcheck disable=SC1091
    source "${SCRIPT_DIR}/scripts/lib/path-manager.sh"
fi
if [ -f "${SCRIPT_DIR}/scripts/lib/cli-core.sh" ]; then
    # shellcheck disable=SC1091
    source "${SCRIPT_DIR}/scripts/lib/cli-core.sh"
fi
if [ -f "${SCRIPT_DIR}/scripts/setup-utils.sh" ]; then
    # shellcheck disable=SC1091
    source "${SCRIPT_DIR}/scripts/setup-utils.sh"
fi
# LLM registry supplies the .llm.* yaml<->env rows in _install_yaml_mapping_pairs.
# Resolved relative to this file so it loads even if SCRIPT_DIR is stale/unset.
_llm_registry_path="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/llm-registry.sh"
if [ -f "$_llm_registry_path" ]; then
    # shellcheck disable=SC1090
    source "$_llm_registry_path"
fi
unset _llm_registry_path

# Shared editor helper (open_editor_with_normalization) for the install-time
# pre-seed editor. Resolved relative to this file so it loads regardless of the
# caller's SCRIPT_DIR convention (repo root vs scripts/).
_editor_lib_path="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/editor.sh"
if [ -f "$_editor_lib_path" ]; then
    # shellcheck disable=SC1090
    source "$_editor_lib_path"
fi
unset _editor_lib_path

# Content hash of a file (sha256; empty when absent/unhashable). Portable:
# sha256sum (linux) -> shasum (macOS) -> openssl.
_install_yaml_hash() {
    [ -f "$1" ] || return 0
    if command -v sha256sum >/dev/null 2>&1; then sha256sum "$1" 2>/dev/null | awk '{print $1}'
    elif command -v shasum >/dev/null 2>&1;   then shasum -a 256 "$1" 2>/dev/null | awk '{print $1}'
    elif command -v openssl >/dev/null 2>&1;  then openssl dgst -sha256 "$1" 2>/dev/null | awk '{print $NF}'
    fi
}

# Marker holding the hash of the install.yaml content that was last APPLIED to
# this env file. Lets `restart --force` re-apply the yaml ONLY when the operator
# actually edited it — interactive reconfigures (insights/Jira/plugin flows write
# the env, never the yaml) must not be stomped back to install-time values.
_install_yaml_marker_path() { printf '%s/.install-yaml.last-applied' "$(dirname "$1")"; }

install_yaml_record_applied() {   # <env_file>  checkpoint the current yaml as applied
    local yaml hash dir
    [ -n "${1:-}" ] && [ -f "$1" ] || return 0
    yaml=$(get_install_yaml_file 2>/dev/null); [ -n "$yaml" ] && [ -f "$yaml" ] || return 0
    hash="$(_install_yaml_hash "$yaml")"; [ -n "$hash" ] || return 0
    dir="$(dirname "$1")"
    # Both markers: at install end the base env AND the plugin envs are in sync
    # with the yaml, so the first `restart --force` must guard both (the plugins
    # marker is otherwise seeded only on the reapply path — plugin_preseed_reapply_config).
    printf '%s\n' "$hash" > "${dir}/.install-yaml.last-applied" 2>/dev/null || true
    printf '%s\n' "$hash" > "${dir}/.install-yaml.plugins.last-applied" 2>/dev/null || true
}

# Pre-fill setup.sh env from yaml. Silent when yaml absent; exits on parse failure.
_install_apply_yaml_if_present() {
    local yaml="$1"
    if [ ! -f "$yaml" ]; then
        log_silent "No install yaml at $yaml; prompts will run interactively"
        return 0
    fi

    local exports
    exports=$(_install_yaml_to_env "$yaml") || {
        if command -v print_error >/dev/null 2>&1; then
            print_error "Failed to parse ${yaml}"
        else
            echo "ERROR: Failed to parse ${yaml}" >&2
        fi
        exit 1
    }

    if [ -n "$exports" ]; then
        # shellcheck disable=SC1090
        eval "$exports"
        log_silent "Loaded install values from ${yaml}"
    fi

    _install_apply_deployment_method "$yaml"
}

# Pre-fill DEPLOYMENT_METHOD from `.deployment.method` on fresh installs only.
# Not in the mapping table: that table writes back into .env-bitoarch on
# restart --force, and the saved .deployment-type must stay authoritative.
_install_apply_deployment_method() {
    local yaml="$1" method
    [ -n "${DEPLOYMENT_METHOD:-}" ] && return 0
    if command -v get_deployment_type >/dev/null 2>&1 && \
       [ "$(get_deployment_type 2>/dev/null)" != "unknown" ]; then
        return 0
    fi
    method=$(_install_yaml_read_value "$yaml" '.deployment.method')
    case "$method" in
        ''|null|~) return 0 ;;
        docker|docker-compose) export DEPLOYMENT_METHOD="docker-compose" ;;
        kubernetes|k8s)        export DEPLOYMENT_METHOD="kubernetes" ;;
        *)
            print_warning "install.yaml: unknown deployment.method '${method}' (use docker or kubernetes); you will be prompted"
            return 0
            ;;
    esac
    log_silent "Deployment method '${DEPLOYMENT_METHOD}' pre-set from install.yaml"
}

# yaml_path <-> env_key pairs, one per line.
_install_yaml_mapping_pairs() {
    cat <<'EOF'
.bito_api_key              BITO_API_KEY
.user_email                MCP_USER_EMAIL
.deployment.ingress.class     BITOARCH_INGRESS_CLASS
.deployment.ingress.exposure  BITOARCH_INGRESS_EXPOSURE
.git.provider              GIT_PROVIDER
.git.access_token          GIT_ACCESS_TOKEN
.git.domain_url            GIT_DOMAIN_URL
.git.user                  GIT_USER
.git.organization          GIT_AZURE_ORG
.git.auth_type             GIT_AUTH_TYPE
.git.app_id                GIT_APP_ID
.git.installation_id       GIT_INSTALLATION_ID
.git.private_key_path      GIT_APP_PRIVATE_KEY_B64
.resources.mysql_memory    MYSQL_MEMORY_LIMIT
.resources.mysql_cpu       MYSQL_CPU_LIMIT
.resources.cis_manager_cpu CIS_MANAGER_CPU_LIMIT
.resources.cis_worker_memory  CIS_WORKER_MEMORY_LIMIT
.ports.cis_provider        CIS_PROVIDER_EXTERNAL_PORT
.ports.cis_manager         CIS_MANAGER_EXTERNAL_PORT
.ports.cis_config          CIS_CONFIG_EXTERNAL_PORT
.ports.mysql               MYSQL_EXTERNAL_PORT
.ports.cis_tracker         CIS_TRACKER_EXTERNAL_PORT
.insights.git                          INSIGHTS_GIT_ENABLED
.insights.ticket_tracker.enabled       INSIGHTS_TICKET_TRACKER_ENABLED
.insights.ticket_tracker.provider      INSIGHTS_TICKET_TRACKER_PROVIDER
.insights.ticket_tracker.auth_type     INSIGHTS_TICKET_TRACKER_AUTH_TYPE
.jira.domain                           JIRA_DOMAIN
.jira.email                            JIRA_EMAIL
.jira.api_token                        JIRA_API_TOKEN
.jira.host_type                        JIRA_HOST_TYPE
.jira.cloud_id                         JIRA_CLOUD_ID
.insights.ticket_tracker.project_keys  INSIGHTS_TICKET_TRACKER_PROJECT_KEYS
.insights.git_lookback_days            INSIGHTS_GIT_LOOKBACK_DAYS
.insights.jira_lookback_days           INSIGHTS_JIRA_LOOKBACK_DAYS
.llm.plugin_model          LLM_PLUGIN_MODEL
.llm.plugin_provider       LLM_PLUGIN_PROVIDER
.llm.ai_index_model        LLM_AI_INDEX_MODEL
EOF
    # LLM provider rows are derived from the registry (single source of truth).
    _llm_yaml_pairs
}

# Resolve a GitHub App private-key .pem path to single-line base64. The multi-line
# PEM can't live in an env var otherwise; base64 (alphabet [A-Za-z0-9+/=], no
# newline or '#') survives both the eval-export and the sed env writer. Mirrors the
# Vertex service-account precedent (_pre_vertex_sa_file). Expands a leading ~.
# Prints base64 on success; returns 1 for a missing/unreadable path or a file that
# isn't a PEM (caller skips it, never persists a raw path). Never echoes contents.
_git_pem_path_to_b64() {
    local v="$1"
    # Literal tilde patterns (a path the operator may have typed with ~); the
    # quotes keep them literal in the case match -- SC2088 is a false positive here.
    # shellcheck disable=SC2088
    case "$v" in
        "~")   v="$HOME" ;;
        "~/"*) v="$HOME/${v#\~/}" ;;
    esac
    [ -f "$v" ] || return 1
    grep -q "BEGIN.*PRIVATE KEY" "$v" 2>/dev/null || return 1
    base64 < "$v" | tr -d '\n'
}

# Read yaml value at <path>. Prefers yq, falls back to python3. Empty on miss.
# Supports an array-index segment (e.g. docs[0]) for the collection docs shape.
_install_yaml_read_value_raw() {
    local yaml="$1" path="$2"
    if command -v yq >/dev/null 2>&1; then
        yq eval "$path" "$yaml" 2>/dev/null
    elif command -v python3 >/dev/null 2>&1; then
        python3 -c "
import yaml, re
with open('$yaml') as f: data = yaml.safe_load(f) or {}
cur = data
for k in '$path'.lstrip('.').split('.'):
    m = re.match(r'^(.*)\[(\d+)\]\$', k)
    idx = None
    if m: k, idx = m.group(1), int(m.group(2))
    if isinstance(cur, dict) and k in cur: cur = cur[k]
    else: cur = None; break
    if idx is not None:
        if isinstance(cur, list) and 0 <= idx < len(cur): cur = cur[idx]
        else: cur = None; break
print(cur if cur is not None else '')
" 2>/dev/null
    fi
}

# Read yaml value, with a legacy-object fallback for the docs collection: a
# docs[0].x path (array shape) falls back to docs.x (pre-array object shape) so
# existing single-provider installs still load.
_install_yaml_read_value() {
    local yaml="$1" path="$2" value
    value=$(_install_yaml_read_value_raw "$yaml" "$path")
    if { [ -z "$value" ] || [ "$value" = "null" ]; } && [ "$path" != "${path//\[0\]/}" ]; then
        value=$(_install_yaml_read_value_raw "$yaml" "${path//\[0\]/}")
    fi
    printf '%s\n' "$value"
}

# Docs is a provider collection: iterate .insights.docs[] entries and emit
# KEY=VALUE lines for the per-provider env vars. Supports the array shape (one
# entry per provider, so both Confluence and Google Docs can coexist) and the
# legacy single-object shape (read as one entry via the docs[0] fallback above).
_install_docs_kv() {
    local yaml="$1"
    local found=0
    local conf_on="" goog_on=""
    local url="" email="" token="" auth="" cloud=""
    local cid="" csec="" rtok=""
    local i=0 prov en
    while [ "$i" -lt 8 ]; do
        prov=$(_install_yaml_read_value "$yaml" ".insights.docs[$i].provider")
        if [ -z "$prov" ] || [ "$prov" = "null" ] || [ "$prov" = "~" ]; then
            break
        fi
        found=1
        en=$(_install_yaml_read_value "$yaml" ".insights.docs[$i].enabled")
        case "$prov" in
            google_docs)
                goog_on="$en"
                cid=$(_install_yaml_read_value "$yaml" ".insights.docs[$i].client_id")
                csec=$(_install_yaml_read_value "$yaml" ".insights.docs[$i].client_secret")
                rtok=$(_install_yaml_read_value "$yaml" ".insights.docs[$i].refresh_token")
                ;;
            *)
                conf_on="$en"
                url=$(_install_yaml_read_value "$yaml" ".insights.docs[$i].url")
                email=$(_install_yaml_read_value "$yaml" ".insights.docs[$i].email")
                token=$(_install_yaml_read_value "$yaml" ".insights.docs[$i].api_token")
                auth=$(_install_yaml_read_value "$yaml" ".insights.docs[$i].auth_type")
                cloud=$(_install_yaml_read_value "$yaml" ".insights.docs[$i].cloud_id")
                ;;
        esac
        i=$((i+1))
    done

    [ "$found" = "0" ] && return 0

    # Normalize missing-key sentinels to empty so they aren't emitted.
    local _v
    for _v in url email token auth cloud cid csec rtok conf_on goog_on; do
        case "${!_v}" in null|"~") printf -v "$_v" '%s' "" ;; esac
    done

    local conf_flag="false" goog_flag="false" any="false"
    [ "$conf_on" = "true" ] && { conf_flag="true"; any="true"; }
    [ "$goog_on" = "true" ] && { goog_flag="true"; any="true"; }

    printf 'INSIGHTS_DOCS_ENABLED=%s\n' "$any"
    printf 'INSIGHTS_DOCS_CONFLUENCE_ENABLED=%s\n' "$conf_flag"
    printf 'INSIGHTS_DOCS_GOOGLE_ENABLED=%s\n' "$goog_flag"
    [ -n "$url" ]   && printf 'INSIGHTS_DOCS_URL=%s\n' "$url"
    [ -n "$email" ] && printf 'INSIGHTS_DOCS_EMAIL=%s\n' "$email"
    [ -n "$token" ] && printf 'INSIGHTS_DOCS_API_TOKEN=%s\n' "$token"
    [ -n "$auth" ]  && printf 'INSIGHTS_DOCS_AUTH_TYPE=%s\n' "$auth"
    [ -n "$cloud" ] && printf 'INSIGHTS_DOCS_CLOUD_ID=%s\n' "$cloud"
    [ -n "$cid" ]   && printf 'INSIGHTS_DOCS_CLIENT_ID=%s\n' "$cid"
    [ -n "$csec" ]  && printf 'INSIGHTS_DOCS_CLIENT_SECRET=%s\n' "$csec"
    [ -n "$rtok" ]  && printf 'INSIGHTS_DOCS_REFRESH_TOKEN=%s\n' "$rtok"
}

# YAML -> `export KEY='value'` lines. Returns 1 if no parser available.
_install_yaml_to_env() {
    local yaml="$1"
    if ! command -v yq >/dev/null 2>&1 && ! command -v python3 >/dev/null 2>&1; then
        print_error "Neither yq nor python3 available; cannot parse YAML"
        return 1
    fi

    while IFS= read -r line || [ -n "$line" ]; do
        [ -z "$line" ] && continue
        case "$line" in \#*) continue ;; esac
        local path envkey value
        path=$(echo "$line" | awk '{print $1}')
        envkey=$(echo "$line" | awk '{print $2}')
        [ -z "$envkey" ] && continue
        value=$(_install_yaml_read_value "$yaml" "$path")
        # A GitHub App private-key path resolves to single-line base64 (a multi-line
        # PEM can't live in an env var). A value that doesn't resolve to a PEM is
        # skipped, not exported raw. Mirrors the Vertex hook in the writeback lane.
        if [ "$path" = ".git.private_key_path" ] \
           && [ -n "$value" ] && [ "$value" != "null" ] && [ "$value" != "~" ]; then
            if ! value="$(_git_pem_path_to_b64 "$value")"; then
                log_silent "install-yaml: rejecting ${path}: not a readable PEM file"
                continue
            fi
        fi
        if [ -n "$value" ] && [ "$value" != "null" ] && [ "$value" != "~" ]; then
            local escaped=${value//\'/\'\\\'\'}
            echo "export ${envkey}='${escaped}'"
        fi
    done < <(_install_yaml_mapping_pairs)

    # Docs is a provider collection, handled separately from the flat mapping.
    local dk dvalue
    while IFS='=' read -r dk dvalue; do
        [ -z "$dk" ] && continue
        local escaped=${dvalue//\'/\'\\\'\'}
        echo "export ${dk}='${escaped}'"
    done < <(_install_docs_kv "$yaml")
}

# Validate yaml's bito_api_key against tracking endpoint when it differs from env.
# Strict: unreachable endpoint returns 1 (user explicitly changed credentials).
validate_install_yaml_api_key() {
    local env_file="$1"
    local yaml
    yaml=$(get_install_yaml_file)
    [ -f "$yaml" ] || return 0
    [ -f "$env_file" ] || return 0

    local yaml_key cur_key
    yaml_key=$(_install_yaml_read_value "$yaml" '.bito_api_key')
    case "$yaml_key" in ''|null|~) return 0 ;; esac

    cur_key=$(grep -E '^BITO_API_KEY=' "$env_file" 2>/dev/null \
        | cut -d= -f2- | head -1 | tr -d '"' | tr -d "'")

    [ "$yaml_key" = "$cur_key" ] && return 0

    # Resolve deps relative to this file so restart --force works without install.sh orchestration.
    local lib_root scripts_root
    lib_root="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    scripts_root="$(cd "$lib_root/.." && pwd)"
    if ! command -v validate_and_print_bito_api_key_status >/dev/null 2>&1 \
       && [ -f "$scripts_root/setup-utils.sh" ]; then
        source "$scripts_root/setup-utils.sh" 2>/dev/null || true
    fi
    if ! command -v call_tracking_endpoint_event >/dev/null 2>&1 \
       && [ -f "$lib_root/adapters/tracker-adapter.sh" ]; then
        source "$lib_root/adapters/tracker-adapter.sh" 2>/dev/null || true
    fi
    if ! command -v validate_and_print_bito_api_key_status >/dev/null 2>&1; then
        return 0
    fi

    local tracking_url
    tracking_url=$(grep -E '^TRACKING_SERVICE_BASE_URL=' "$env_file" 2>/dev/null \
        | cut -d= -f2- | head -1 | tr -d '"' | tr -d "'")
    if [ -z "$tracking_url" ]; then
        print_error "Cannot validate new API key: TRACKING_SERVICE_BASE_URL not set in env file"
        return 1
    fi

    echo ""
    print_info "New Bito API Key detected in ~/.bitoarch/install.yaml -- validating..."
    if validate_and_print_bito_api_key_status "$yaml_key" "architect_api_key_update" \
            "$tracking_url" "New API key validated" "true"; then
        return 0
    fi
    echo ""
    print_error "Aborting: new API key failed validation. Existing deployment left running."
    print_info "Edit ${YELLOW}~/.bitoarch/install.yaml${NC} and re-run ${YELLOW}bitoarch restart --force${NC}."
    return 1
}

# Reload mapped KEY=VALUE lines from yaml into their target env file (restart
# --force). Routing: .llm.* keys are written to the separate LLM env file
# (.env-llm-bitoarch) -- never the main env file, where they don't belong and
# break downstream parsing; all other keys go to the main env_file. Existing
# keys are replaced in place; a key not yet present is appended on its own
# line (newline-safe). No-op if yaml/env absent or no parser.
apply_install_yaml_to_env_file() {
    local env_file="$1" mode="${2:-}"
    local yaml llm_file
    yaml=$(get_install_yaml_file)
    [ -f "$yaml" ] || return 0
    [ -f "$env_file" ] || return 0
    if ! command -v yq >/dev/null 2>&1 && ! command -v python3 >/dev/null 2>&1; then
        return 0
    fi
    # --if-changed (restart --force): re-apply only when the operator actually
    # edited the yaml since the last apply. Otherwise interactive reconfigures
    # (insights/Jira flows write the env, never the yaml) revert to install-time
    # values on every restart --force. Missing marker = pre-guard install: apply
    # once (today's behavior) and record.
    local _iy_hash; _iy_hash="$(_install_yaml_hash "$yaml")"
    if [ "$mode" = "--if-changed" ] && [ -n "$_iy_hash" ] \
       && [ "$_iy_hash" = "$(cat "$(_install_yaml_marker_path "$env_file")" 2>/dev/null)" ]; then
        log_silent "install-yaml: unchanged since last apply; keeping current env (interactive changes preserved)"
        return 0
    fi
    # LLM credentials live in a sibling file (co-located by design; mirrors
    # get_llm_config_file). Deriving it from env_file keeps both writes in the
    # same config dir without depending on global path state.
    llm_file="$(dirname "$env_file")/.env-llm-bitoarch"

    local tmp_main tmp_llm
    tmp_main=$(mktemp) || return 1
    cp "$env_file" "$tmp_main" || { rm -f "$tmp_main"; return 1; }
    tmp_llm=$(mktemp) || { rm -f "$tmp_main"; return 1; }
    [ -f "$llm_file" ] && { cp "$llm_file" "$tmp_llm" || { rm -f "$tmp_main" "$tmp_llm"; return 1; }; }

    local updated_main=0 updated_llm=0
    while IFS= read -r line || [ -n "$line" ]; do
        [ -z "$line" ] && continue
        case "$line" in \#*) continue ;; esac
        local path envkey value target
        path=$(echo "$line" | awk '{print $1}')
        envkey=$(echo "$line" | awk '{print $2}')
        [ -z "$envkey" ] && continue
        value=$(_install_yaml_read_value "$yaml" "$path")
        if [ -z "$value" ] || [ "$value" = "null" ] || [ "$value" = "~" ]; then
            continue
        fi
        # Newlines would break the single-line sed substitution; reject and log.
        case "$value" in
            *$'\n'*|*$'\r'*)
                log_silent "install-yaml: rejecting ${path}: value contains newline"
                continue
                ;;
        esac
        # vertex_service_account_key_json may carry a file path; resolve it to
        # base64 via the same registry hook the install lane uses, so both lanes
        # behave identically. A value that doesn't resolve is skipped, not
        # persisted raw.
        if [ "$path" = ".llm.vertex_service_account_key_json" ]; then
            if ! value="$(_pre_vertex_sa_file "$value")"; then
                log_silent "install-yaml: rejecting ${path}: invalid Vertex service-account value"
                continue
            fi
        fi
        # The GitHub App private-key path resolves to single-line base64 the same
        # way (multi-line PEM can't survive a single-line env write); a value that
        # isn't a readable PEM is skipped, not persisted raw.
        if [ "$path" = ".git.private_key_path" ]; then
            if ! value="$(_git_pem_path_to_b64 "$value")"; then
                log_silent "install-yaml: rejecting ${path}: not a readable PEM file"
                continue
            fi
        fi
        # Route .llm.* secrets to the LLM env file; everything else to main.
        case "$path" in
            .llm.*) target="$tmp_llm" ;;
            *)      target="$tmp_main" ;;
        esac
        # Escape for sed replacement: backslash, slash, ampersand.
        local esc=${value//\\/\\\\}
        esc=${esc//\//\\\/}
        esc=${esc//&/\\&}
        if grep -q "^${envkey}=" "$target" 2>/dev/null; then
            sed -i.bak "s/^${envkey}=.*/${envkey}=${esc}/" "$target" && rm -f "${target}.bak"
        else
            # Append on its own line: ensure the file ends with a newline first
            # so the new key can't be concatenated onto the previous last line.
            if [ -s "$target" ] && [ -n "$(tail -c1 "$target")" ]; then
                printf '\n' >> "$target"
            fi
            echo "${envkey}=${value}" >> "$target"
        fi
        if [ "$target" = "$tmp_llm" ]; then updated_llm=1; else updated_main=1; fi
    done < <(_install_yaml_mapping_pairs)

    # Docs collection (per-provider) — written to the main env file.
    local dk dvalue
    while IFS='=' read -r dk dvalue; do
        [ -z "$dk" ] && continue
        case "$dvalue" in
            *$'\n'*|*$'\r'*)
                log_silent "install-yaml: rejecting ${dk}: value contains newline"
                continue
                ;;
        esac
        local desc=${dvalue//\\/\\\\}
        desc=${desc//\//\\\/}
        desc=${desc//&/\\&}
        if grep -q "^${dk}=" "$tmp_main" 2>/dev/null; then
            sed -i.bak "s/^${dk}=.*/${dk}=${desc}/" "$tmp_main" && rm -f "${tmp_main}.bak"
        else
            if [ -s "$tmp_main" ] && [ -n "$(tail -c1 "$tmp_main")" ]; then
                printf '\n' >> "$tmp_main"
            fi
            echo "${dk}=${dvalue}" >> "$tmp_main"
        fi
        updated_main=1
    done < <(_install_docs_kv "$yaml")

    if [ "$updated_main" -eq 1 ]; then
        mv "$tmp_main" "$env_file"
    else
        rm -f "$tmp_main"
    fi
    if [ "$updated_llm" -eq 1 ]; then
        mv "$tmp_llm" "$llm_file" && chmod 600 "$llm_file" 2>/dev/null
    else
        rm -f "$tmp_llm"
    fi
    [ -n "$_iy_hash" ] && printf '%s\n' "$_iy_hash" > "$(_install_yaml_marker_path "$env_file")" 2>/dev/null || true
    return 0
}

# Seed home yaml from template at repo root (idempotent).
_install_ensure_yaml_exists() {
    local yaml="$1"
    [ -f "$yaml" ] && return 0
    # Prefer $SCRIPT_DIR from caller; else climb two levels from this file.
    local template
    if [ -n "${SCRIPT_DIR:-}" ] && [ -f "${SCRIPT_DIR}/install.yaml.default" ]; then
        template="${SCRIPT_DIR}/install.yaml.default"
    else
        template="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)/install.yaml.default"
    fi
    if [ ! -f "$template" ]; then
        log_silent "Install yaml template missing at $template; skipping seed"
        return 0
    fi
    local dir
    dir=$(dirname "$yaml")
    mkdir -p "$dir" 2>/dev/null || return 1
    cp "$template" "$yaml" 2>/dev/null && \
        log_silent "Seeded install yaml at $yaml from template"
}

# ---------------------------------------------------------------------------
# Inline pre-seed editor
# When the install bootstrap runs interactively and the mandatory values are
# missing, offer the operator a choice: open an editor and fill the config in
# one pass ("Standard"), or answer the existing step-by-step prompts ("Guided").
# This removes the need to download + fill install.yaml.default before the curl.
# ---------------------------------------------------------------------------

# Mandatory install values that gate the choice. Bito API key + git provider and
# access token must all be present to proceed non-interactively; azure-devops
# additionally needs the org (it forms the clone/API URL root). Returns 0 when
# all are present, 1 otherwise. Mirrors the required-field handling in setup.sh's
# credential prompts.
_install_mandatory_present() {
    [ -n "${BITO_API_KEY:-}" ]     || return 1
    [ -n "${GIT_PROVIDER:-}" ]     || return 1
    # The local provider is credential-less (pre-imported repositories); every
    # other provider needs an access token.
    if [ "${GIT_PROVIDER:-}" != "local" ]; then
        [ -n "${GIT_ACCESS_TOKEN:-}" ] || return 1
    fi
    if [ "${GIT_PROVIDER:-}" = "azure-devops" ] && [ -z "${GIT_AZURE_ORG:-}" ]; then
        return 1
    fi
    return 0
}

# Ensure a usable YAML parser exists before opening the editor. The prereq
# install normally runs later (inside setup.sh), so on a fresh host a parser may
# not be present yet. python3 only counts when PyYAML is importable -- a bare
# python3 without PyYAML cannot read the file, the same rule check_cli_tools
# applies. Tries the idempotent, arch-aware install_yq first, then PyYAML.
# Returns 0 if a parser is usable afterwards, 1 if none could be obtained.
_install_ensure_yaml_parser() {
    command -v yq >/dev/null 2>&1 && return 0
    if command -v python3 >/dev/null 2>&1 && python3 -c "import yaml" >/dev/null 2>&1; then
        return 0
    fi
    # Source prerequisites-manager.sh on demand (install_run doesn't pull it in)
    # so we can reuse install_yq / install_python_pyyaml.
    if ! command -v install_yq >/dev/null 2>&1; then
        local _pm
        for _pm in "${SCRIPT_DIR}/scripts/prerequisites-manager.sh" \
                   "$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)/prerequisites-manager.sh"; do
            if [ -f "$_pm" ]; then
                # shellcheck disable=SC1090
                source "$_pm" 2>/dev/null || true
                break
            fi
        done
    fi
    if command -v install_yq >/dev/null 2>&1; then
        install_yq >> "${LOG_FILE:-/dev/null}" 2>&1 || true
    fi
    command -v yq >/dev/null 2>&1 && return 0
    if command -v install_python_pyyaml >/dev/null 2>&1; then
        install_python_pyyaml >> "${LOG_FILE:-/dev/null}" 2>&1 || true
    fi
    command -v python3 >/dev/null 2>&1 && python3 -c "import yaml" >/dev/null 2>&1
}

# Returns 0 if the YAML at <file> parses cleanly, 1 if malformed. Prefers yq,
# falls back to python3. Returns 0 ("can't tell") when no parser is available —
# callers gate on _install_ensure_yaml_parser first.
_install_yaml_is_valid() {
    local yaml="$1"
    [ -f "$yaml" ] || return 1
    if command -v yq >/dev/null 2>&1; then
        yq eval '.' "$yaml" >/dev/null 2>&1
        return $?
    elif command -v python3 >/dev/null 2>&1; then
        python3 -c "import sys,yaml; yaml.safe_load(open(sys.argv[1]))" "$yaml" >/dev/null 2>&1
        return $?
    fi
    return 0
}

# Ask how to provide configuration. Sets INSTALL_SEED_CHOICE to "editor" or
# "guided". Defaults to "guided" on empty input (guided always works). Avoids
# the term "pre-seed" — both options are entered by hand; only the style differs.
_install_prompt_seed_choice() {
    local choice
    echo ""
    echo "Choose how you want to configure the installation:"
    echo "  [1] Standard: open an editor and update all values at once"
    echo "  [2] Guided:   enter each value step by step based on prompts"
    while true; do
        read -r -p "Choose [1-2] (default 2): " choice
        case "$choice" in
            1)    INSTALL_SEED_CHOICE="editor";  return 0 ;;
            ""|2) INSTALL_SEED_CHOICE="guided";  return 0 ;;
            *)    echo "  Please enter 1 or 2." ;;
        esac
    done
}

# Standard path: seed the home yaml if absent, open it in an editor, and apply
# the result to the environment. Re-validation has two cases:
#   - parses but mandatory still blank -> continue; setup.sh's own required-field
#     prompt loops collect them. No re-open.
#   - YAML won't parse -> re-open exactly once; if still unparseable, restore the
#     file to its pre-edit state and fall back to Guided (env is unchanged).
# We can't lean on open_editor_with_normalization's EDITOR_PRE_EDIT_BACKUP here:
# it is re-taken on the re-open, so after attempt 1 it points at the already-
# broken file (and in the install path the backup manager isn't sourced, so it's
# usually empty). So snapshot the original once, before the loop, and restore
# that. Never hard-fails an interactive install: the apply path here deliberately
# does NOT use _install_apply_yaml_if_present (which exits non-zero on a parse
# failure), and a corrupt edit is rolled back rather than left on disk.
_install_editor_preseed() {
    local yaml="$1"

    if ! _install_ensure_yaml_parser; then
        print_warning "No YAML parser (yq/python3) available; falling back to step-by-step prompts."
        log_silent "install: no yaml parser for editor pre-seed; falling back to guided"
        return 0
    fi
    if ! command -v open_editor_with_normalization >/dev/null 2>&1; then
        log_silent "install: editor helper unavailable; falling back to guided prompts"
        return 0
    fi

    _install_ensure_yaml_exists "$yaml"

    # Snapshot the pre-edit file so an unparseable edit can be rolled back
    # instead of leaving a corrupt install.yaml on disk (operator-owned file).
    local _orig_snapshot=""
    if [ -f "$yaml" ]; then
        _orig_snapshot="$(mktemp 2>/dev/null)" || _orig_snapshot=""
        [ -n "$_orig_snapshot" ] && cp "$yaml" "$_orig_snapshot" 2>/dev/null
    fi

    local attempt=0
    while :; do
        open_editor_with_normalization "$yaml" "install"

        if _install_yaml_is_valid "$yaml"; then
            # Apply directly (not via _install_apply_yaml_if_present, which
            # exits non-zero on parse failure). Empty mandatory values are fine
            # here — setup.sh's own prompt loops will collect them.
            local exports
            exports=$(_install_yaml_to_env "$yaml" 2>/dev/null) || exports=""
            if [ -n "$exports" ]; then
                # shellcheck disable=SC1090
                eval "$exports"
                log_silent "install: applied values from edited $yaml"
            else
                log_silent "install: edited $yaml parsed but set no mapped values"
            fi
            [ -n "$_orig_snapshot" ] && rm -f "$_orig_snapshot" 2>/dev/null
            return 0
        fi

        # Malformed YAML — re-open once, then restore + fall back to Guided.
        if [ "$attempt" -lt 1 ]; then
            attempt=$((attempt + 1))
            print_warning "Could not parse ${yaml}. Re-opening the editor so you can fix it..."
            continue
        fi
        print_warning "Still could not parse ${yaml}; switching to step-by-step prompts."
        # Don't leave a corrupt install.yaml behind: restore the pre-edit file.
        if [ -n "$_orig_snapshot" ] && [ -f "$_orig_snapshot" ]; then
            cp "$_orig_snapshot" "$yaml" 2>/dev/null \
                && log_silent "install: restored install.yaml to its pre-edit state after unparseable edits"
        fi
        [ -n "$_orig_snapshot" ] && rm -f "$_orig_snapshot" 2>/dev/null
        log_silent "install: yaml unparseable after one re-edit; falling back to guided"
        return 0
    done
}

# Entry point called from setup.sh's generate_env_file (fresh-install path), after
# install_run has applied the yaml and exported BITOARCH_INSTALL_YAML_FILE. When
# the mandatory values are missing AND we're interactive, offer Standard vs Guided.
# No-op under AUTO_SETUP (env var, exported by the bootstraps), a non-TTY stdin,
# or when the mandatory values are already present (pre-filled install.yaml).
_install_maybe_offer_editor() {
    local yaml="$1"
    [ -t 0 ] || return 0
    [ "${AUTO_SETUP:-}" = "true" ] && return 0
    _install_mandatory_present && return 0

    INSTALL_SEED_CHOICE=""
    _install_prompt_seed_choice
    if [ "$INSTALL_SEED_CHOICE" = "editor" ]; then
        _install_editor_preseed "$yaml"
    fi
    # "guided" -> return; setup.sh's existing prompts collect the values.
    return 0
}
