#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
# Bito's AI Architect - Output Rendering System
# Block-level output functions for coherent, structured user-facing messages
# Business logic calls these render functions with data - presentation is isolated here

# Load guard: paired with output-formatter.sh (which sources this file) so the
# mutual source between the two does not recurse.
if [ -n "${_BITOARCH_OUTPUT_BLOCKS_LOADED:-}" ]; then
    return 0
fi
_BITOARCH_OUTPUT_BLOCKS_LOADED=1

# ============================================================================
# COLOR DEFINITIONS
# ============================================================================
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[1;34m'
CYAN='\033[0;36m'
NC='\033[0m'
BOLD='\033[1m'
DIM='\033[2m'

# ============================================================================
# PATH MANAGER INTEGRATION
# ============================================================================
# Source path-manager for config file path resolution
SCRIPT_DIR="${SCRIPT_DIR:-$(cd "$(dirname "${BASH_SOURCE[0]}")" && cd ../.. && pwd)}"
if [ -f "${SCRIPT_DIR}/scripts/lib/path-manager.sh" ]; then
    source "${SCRIPT_DIR}/scripts/lib/path-manager.sh"
fi
# Constants (BITOARCH_USER_SERVICES / bitoarch_user_service_count, service
# display names, docs URLs). Load-guarded; no-op if already sourced upstream.
if [ -f "${SCRIPT_DIR}/scripts/lib/constants.sh" ]; then
    # shellcheck disable=SC1091
    source "${SCRIPT_DIR}/scripts/lib/constants.sh"
fi
# SSO gating helper (scripts/lib/bitoarch-config.sh::sso_ui_suppressed).
# Sourced here so render_config_add_next_steps / render_deploy_success_block
# can gate their "Configure SSO" bullets on the flag.
if [ -f "${SCRIPT_DIR}/scripts/lib/bitoarch-config.sh" ]; then
    # shellcheck disable=SC1091
    source "${SCRIPT_DIR}/scripts/lib/bitoarch-config.sh"
fi
# Field-level formatters (format_bytes, mask_secrets) used by the config render
# blocks below. Load-guarded on both sides, so this is a no-op when callers
# already sourced output-formatter.sh upstream.
if [ -f "${SCRIPT_DIR}/scripts/lib/output-formatter.sh" ]; then
    # shellcheck disable=SC1091
    source "${SCRIPT_DIR}/scripts/lib/output-formatter.sh"
fi
# LLM provider registry (llm_registry + _llm_cost_rows) drives the per-provider
# rows in render_indexing_information_block. Load-guarded; a no-op when a caller
# (setup.sh, via llm-config.sh) already sourced it upstream.
if [ -f "${SCRIPT_DIR}/scripts/lib/llm-registry.sh" ]; then
    # shellcheck disable=SC1091
    source "${SCRIPT_DIR}/scripts/lib/llm-registry.sh"
fi

# ============================================================================
# SIMPLE MESSAGE FUNCTIONS (1-2 lines)
# ============================================================================

# Success message (✓ green)
msg_success() {
    echo -e "${GREEN}✓${NC} $1"
    log_silent "SUCCESS: $1"
}

# Info message (ℹ blue)
msg_info() {
    echo -e "${BLUE}ℹ${NC} $1"
    log_silent "INFO: $1"
}

# Warning message (⚠ yellow)
msg_warn() {
    echo -e "${YELLOW}⚠${NC} $1"
    log_silent "WARNING: $1"
}

# Error message (✗ red)
msg_error() {
    echo -e "${RED}✗${NC} $1"
    log_silent "ERROR: $1"
}

# Backward compatibility aliases
print_status() { msg_success "$1"; }
print_info() { msg_info "$1"; }
print_warning() { msg_warn "$1"; }
print_error() { msg_error "$1"; }

# Technical logging (silent)
log_technical() {
    log_silent "TECHNICAL: $1"
}

# ============================================================================
# LIFECYCLE BLOCKS (start / restart / update)
# Compact success + failure blocks shared across lifecycle commands.
# ============================================================================

# banner_label: e.g. "AI Architect Restarted"
# rc: 0 = healthy; 2 = services up but still warming (different banner)
render_lifecycle_success_block() {
    local banner_label="$1" rc="$2"
    command -v load_env_config >/dev/null 2>&1 && load_env_config >/dev/null 2>&1 || true
    local mcp_url="${PROVIDER_URL:-http://localhost:${CIS_PROVIDER_EXTERNAL_PORT:-5001}}/mcp"
    echo ""
    if [ "$rc" -eq 0 ]; then
        echo -e "${GREEN}✅ ${banner_label}${NC}"
    else
        echo -e "${YELLOW}⏳ AI Architect Starting${NC}"
        echo -e "   Services are up; some are still warming up."
        echo -e "   Check ${YELLOW}bitoarch status${NC} in a few seconds to confirm."
    fi
    echo -e "${BLUE}🔗 MCP endpoint:${NC}  ${mcp_url}"
    echo ""
    echo -e "${BLUE}💡 Next Steps${NC}"
    echo -e "   • Check status:  ${YELLOW}bitoarch status${NC}"
    echo -e "   • IDE setup:     ${YELLOW}bitoarch mcp-info${NC}"
    # Show SSO hint only when (a) SSO UI is NOT suppressed (prod default)
    # AND (b) SSO is not already configured. Avoids nagging users who have
    # SSO set up already, and stays hidden for SA installs where SSO is
    # deferred to `bitoarch sso setup` on demand.
    if (! command -v sso_ui_suppressed >/dev/null 2>&1 || ! sso_ui_suppressed) \
       && [ "${XMCP_SSO_ENABLED:-false}" != "true" ]; then
        echo -e "   • Configure SSO: ${YELLOW}bitoarch sso setup${NC}"
    fi
    echo ""
}

# verb: "start" | "restart" | "recreate" | "update"
# Emits to stderr. Uses list_failing_services when available (docker-manager.sh)
# to enumerate which services didn't come up.
render_lifecycle_failure_block() {
    local verb="$1"
    {
        echo ""
        echo "  AI Architect failed to ${verb}."
        if command -v list_failing_services >/dev/null 2>&1; then
            local failing count total
            failing=$(list_failing_services)
            if [ -n "$failing" ]; then
                count=$(printf '%s\n' "$failing" | grep -c '^')
                total=$(command -v bitoarch_user_service_count >/dev/null 2>&1 \
                        && bitoarch_user_service_count || echo '?')
                echo "  ${count} of ${total} services did not reach running state:"
                printf '%s\n' "$failing"
                echo ""
                printf '%s\n' "$failing" \
                    | sed -E 's/^    - ([a-z-]+) .*/           bitoarch logs \1/' \
                    | sed '1s/^           /  Inspect: /'
            fi
        fi
    } >&2
}

# ============================================================================
# DEPLOYMENT BLOCKS
# ============================================================================

render_deploy_success_banner() {
    echo ""
    echo -e "${GREEN}🎉 Bito's AI Architect is successfully deployed! 🎉${NC}"
    echo ""
}

# Shown by the installer's EXIT trap when setup exits non-zero without already
# printing a closing. Guarantees the operator never sees a bare, silent exit.
render_install_incomplete_block() {
    echo ""
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo -e "${RED}✗ Setup did not finish.${NC}"
    echo ""
    echo "  This is usually temporary. A service may still be starting, an image"
    echo "  pull can be slow, or the network blipped. Re-running resumes where it"
    echo "  left off, and your configuration and data are kept."
    echo ""
    echo -e "  Try again:     ${YELLOW}bitoarch start${NC}"
    echo -e "  See logs:      ${YELLOW}bitoarch logs${NC}"
    echo -e "  Check status:  ${YELLOW}bitoarch status${NC}"
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo ""
}

# Standard rule/title/rule section band (matches the PLUGINS + INDEXING headers).
render_section_band() {   # <emoji> <TITLE-CAPS>
    local rule="━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo -e "${BLUE}${rule}${NC}"
    echo -e "${BLUE}${BOLD}${1} ${2}${NC}"
    echo -e "${BLUE}${rule}${NC}"
}

render_deploy_success_block() {
    local mcp_token="$1"
    local mcp_url="$2"
    local cli_path="$3"
    local git_provider="$4"
    local setup_mode="${5:-manual}"

    # Auth-aware MCP info display, under the themed install-flow band header.
    _MCP_SHOW_BAND=1 render_mcp_config_block "$mcp_url" "$mcp_token"

    # Standalone mode (SKIP_SSO_PROMPT=true) skips the Next Steps block --
    # the bootstrap surfaces its own post-install guidance (MCP registration
    # summary + IDE restart hints) and the CLI activation step is redundant.
    if [ "${SKIP_SSO_PROMPT:-false}" != "true" ]; then
        # Single numbered Next Steps block. In manual mode the authoritative
        # to-do list is render_manual_config_instructions_block (edit repos /
        # save / index / SSO) rendered earlier in setup.sh; repeating those
        # items here is redundant, so manual gets only CLI activation + docs.
        # Auto mode shows activate + status check + SSO (if not suppressed).
        echo ""
        render_section_band "🚀" "AI ARCHITECT: NEXT STEPS"
        echo ""
        local step=1
        echo -e "  ${step}. Activate CLI:       ${YELLOW}source ~/.${SHELL##*/}rc${NC} (or restart terminal)"
        step=$((step + 1))
        if [[ "$setup_mode" != "manual" ]]; then
            echo -e "  ${step}. Check status:       ${YELLOW}bitoarch status${NC}"
            step=$((step + 1))
            if ! command -v sso_ui_suppressed >/dev/null 2>&1 || ! sso_ui_suppressed; then
                echo -e "  ${step}. Configure SSO:      ${YELLOW}bitoarch sso setup${NC}"
            fi
        fi
        echo ""
        echo -e "  Docs: ${BLUE}${AI_ARCHITECT_DOCS_HOME_URL:-https://docs.bito.ai/ai-architect}${NC}"
        echo ""
    fi
}

render_deploy_failure_block() {
    local failed_service="$1"
    local error_msg="$2"
    local log_file="$3"
    
    echo ""
    echo -e "${RED}❌ Platform Deployment Failed${NC}"
    echo ""
    echo -e "${YELLOW}⚠️ Issue${NC}"
    echo -e "   Service: ${BOLD}${failed_service}${NC}"
    echo -e "   Error: ${error_msg}"
    echo ""
    echo -e "${BLUE}🔍 Troubleshooting${NC}"
    echo -e "   • Check logs:   ${YELLOW}bitoarch logs ${failed_service}${NC}"
    echo -e "   • View details: ${YELLOW}cat ${log_file}${NC}"
    echo -e "   • Restart:      ${YELLOW}bitoarch restart${NC}"
    echo ""
}

# ============================================================================
# CONFIG COMMAND BLOCKS
# ============================================================================

# Resolve the indexable size for display: prefer the platform-enforced
# CIS_REPO_SIZE_LIMIT (bytes, rendered human-readable); fall back to the
# service-reported value when the env is unavailable. cis-config reports the
# value as a raw byte count (it mirrors CIS_REPO_SIZE_LIMIT), so the fallback
# is formatted too; format_bytes passes legacy pre-formatted values through.
_resolve_size_limit() {
    local config_json="$1"
    if [ -n "${CIS_REPO_SIZE_LIMIT:-}" ]; then
        format_bytes "$CIS_REPO_SIZE_LIMIT"
    else
        format_bytes "$(echo "$config_json" | jq -r '.repository.repo_size_limit // "N/A"')"
    fi
}

# Positive-integer test for tuning knobs (warn-and-ignore idiom of
# cluster-yaml.sh's replicas handling).
_is_positive_int() {
    case "$1" in
        ''|*[!0-9]*) return 1 ;;
        *) [ "$1" -gt 0 ] ;;
    esac
}

# The two defaults deliberately differ: the platform ships 1
# (.env-bitoarch.default, conservative for minimum-sized hosts) while
# cis-manager's own application.properties has 5 — what a container the env
# key never reached actually runs. Exported so child shells that inherit the
# exported renderer resolve them too.
export _BASIC_INDEX_PLATFORM_DEFAULT=1
export _BASIC_INDEX_SERVICE_DEFAULT=5

# The command that applies an .env-bitoarch edit: Compose recreates on a
# config-hash change under plain restart, but on Kubernetes only --force
# regenerates the helm values from the env file.
_basic_index_apply_cmd() {
    local dt="docker-compose" dt_file=""
    command -v get_deployment_type_file >/dev/null 2>&1 && dt_file=$(get_deployment_type_file)
    [ -n "$dt_file" ] && [ -f "$dt_file" ] && dt=$(cat "$dt_file")
    if [ "$dt" = "kubernetes" ]; then
        echo "bitoarch restart --force"
    else
        echo "bitoarch restart"
    fi
}

# Basic-index concurrency for display: prefer the running worker's live
# TEMPORAL_TASK_QUEUE_INDEXING_CONCURRENCY (what indexing actually runs with);
# fall back to the host-configured value when the probe is inconclusive. A
# hand-edited .env-bitoarch diverges from the running worker until the change
# is applied, so flag the pending value when the two disagree.
_resolve_basic_index_concurrency() {
    local configured="${TEMPORAL_TASK_QUEUE_INDEXING_CONCURRENCY:-$_BASIC_INDEX_PLATFORM_DEFAULT}"
    local live="" probe_rc=2
    if command -v worker_live_env_value >/dev/null 2>&1; then
        live=$(worker_live_env_value TEMPORAL_TASK_QUEUE_INDEXING_CONCURRENCY 2>/dev/null)
        probe_rc=$?
    fi
    # rc=1: worker reachable but key unset (container predates the knob) — it
    # runs the service's shipped default, not the host-configured value.
    [ "$probe_rc" -eq 1 ] && live="$_BASIC_INDEX_SERVICE_DEFAULT"

    # A non-positive-integer value must not display as effective: cis-manager
    # silently ignores unparseable values, and Temporal treats <=0 as "no
    # limit" (1000 activity slots).
    local bad=""
    _is_positive_int "$configured" || bad="$configured"
    if [ -n "$live" ] && ! _is_positive_int "$live"; then bad="$live"; fi
    if [ -n "$bad" ]; then
        echo "'$bad' is INVALID — TEMPORAL_TASK_QUEUE_INDEXING_CONCURRENCY must be a positive integer (0/negative removes the worker's limit entirely); fix .env-bitoarch and apply with '$(_basic_index_apply_cmd)'"
        return 0
    fi

    if [ -n "$live" ] && [ "$live" != "$configured" ]; then
        echo "$live (configured: $configured — apply with '$(_basic_index_apply_cmd)')"
    else
        echo "${live:-$configured}"
    fi
}

render_config_get_summary_block() {
    local config_json="$1"
    
    if ! command -v jq >/dev/null 2>&1; then
        echo ""
        echo -e "${GREEN}✅ Configuration Retrieved${NC}"
        echo ""
        echo "$config_json"
        return 0
    fi
    
    echo ""
    echo -e "${GREEN}✅ Configuration Retrieved${NC}"
    echo ""
    echo -e "${BLUE}📊 Repository Configuration${NC}"
    echo ""
    
    # Exclude seeded placeholder (your-username/your-repo-name) from count + listing
    local repo_count=$(echo "$config_json" | jq -r '[.repository.configured_repos[]? | select(.namespace != "your-username/your-repo-name")] | length' 2>/dev/null || echo "0")
    local repo_limit=$(echo "$config_json" | jq -r '.repository.repo_limit // "N/A"')
    local size_limit=$(_resolve_size_limit "$config_json")
    local basic_index_concurrency=$(_resolve_basic_index_concurrency)

    echo "  Repository Limit: $repo_limit"
    echo "  Repository Size Limit(Indexable size): $size_limit"
    echo "  Basic Index Concurrency: $basic_index_concurrency"
    echo "  Total Repositories: $repo_count"
    echo ""

    if [ "$repo_count" -gt 0 ]; then
        echo -e "${BLUE}📁 Configured Repositories${NC}"
        if [ "$repo_count" -le 5 ]; then
            echo "$config_json" | jq -r '.repository.configured_repos[]? | select(.namespace != "your-username/your-repo-name") | .namespace' 2>/dev/null | while read -r ns; do
                echo "  • $ns"
            done
        else
            echo "$config_json" | jq -r '[.repository.configured_repos[]? | select(.namespace != "your-username/your-repo-name")] | .[0:5][] | .namespace' 2>/dev/null | while read -r ns; do
                echo "  • $ns"
            done
            echo "  ... and $((repo_count - 5)) more"
        fi
        echo ""
    fi
    
    echo -e "${BLUE}💡 Tip:${NC} Use ${YELLOW}--raw${NC} to see full configuration"
    echo ""
}

render_config_get_raw_block() {
    local config_json="$1"
    
    echo ""
    echo -e "${GREEN}✅ Configuration Retrieved${NC}"
    echo ""
    echo "# Raw API Response (secrets masked for security)"
    echo ""
    mask_secrets "$config_json"
    echo ""
}

render_config_get_success_block() {
    local config_json="$1"
    
    echo ""
    echo -e "${GREEN}✅ Configuration Retrieved${NC}"
    echo ""
    if command -v jq >/dev/null 2>&1 && echo "$config_json" | jq . >/dev/null 2>&1; then
        echo "$config_json" | jq '.'
    else
        echo "$config_json"
    fi
    echo ""
}

render_config_get_failure_block() {
    local http_code="$1"
    local error_body="$2"
    
    echo ""
    echo -e "${RED}❌ Failed to Retrieve Configuration${NC}"
    echo ""
    echo -e "${YELLOW}⚠️ Details${NC}"
    echo -e "   HTTP Status: ${http_code}"
    echo -e "   Response: ${error_body}"
    echo ""
    echo -e "${BLUE}🔍 Check${NC}"
    echo -e "   • Is BITO_API_KEY set correctly in .env-bitoarch?"
    echo -e "   • Is AI Architect Config service running? ${YELLOW}bitoarch status${NC}"
    echo ""
}

render_config_add_success_block() {
    local config_json="$1"
    local show_raw="${2:-false}"
    
    if ! command -v jq >/dev/null 2>&1; then
        # Fallback without jq
        echo ""
        echo -e "${GREEN}✅ Configuration Added Successfully${NC}"
        echo ""
        return 0
    fi
    
    # If --raw flag, show full masked response
    if [ "$show_raw" = "true" ]; then
        echo ""
        echo -e "${GREEN}✅ Configuration Added Successfully${NC}"
        echo ""
        echo "# Raw API Response (secrets masked for security)"
        echo ""
        mask_secrets "$config_json"
        echo ""
        return 0
    fi
    
    # Extract customer-relevant fields only. Exclude seeded placeholder from count + listing.
    local repo_count=$(echo "$config_json" | jq -r '[.repository.configured_repos[]? | select(.namespace != "your-username/your-repo-name")] | length' 2>/dev/null || echo "0")
    local repo_limit=$(echo "$config_json" | jq -r '.repository.repo_limit // "N/A"')
    local size_limit=$(_resolve_size_limit "$config_json")
    local git_provider=$(echo "$config_json" | jq -r '.integration.git.provider // "N/A"')

    echo ""
    echo -e "${GREEN}✅ Configuration Added Successfully${NC}"
    echo ""
    echo -e "${BLUE}📊 Repository Configuration${NC}"
    echo -e "   • Git provider: ${BOLD}${git_provider}${NC}"
    echo -e "   • Total repositories: ${BOLD}${repo_count}${NC}"
    echo -e "   • Repo limit: ${repo_limit}"
    echo -e "   • Indexable size (per repository): ${size_limit}"
    echo -e "   • Re-indexing interval: manual"
    echo ""

    # Show repository list if not too many
    if [ "$repo_count" -gt 0 ] && [ "$repo_count" -le 10 ]; then
        echo -e "${BLUE}📁 Configured Repositories${NC}"
        echo "$config_json" | jq -r '.repository.configured_repos[]? | select(.namespace != "your-username/your-repo-name") | .namespace' 2>/dev/null | while read -r ns; do
            echo "   • $ns"
        done
        echo ""
    elif [ "$repo_count" -gt 10 ]; then
        echo -e "${BLUE}📁 Configured Repositories${NC}"
        echo "$config_json" | jq -r '[.repository.configured_repos[]? | select(.namespace != "your-username/your-repo-name")] | .[0:5][] | .namespace' 2>/dev/null | while read -r ns; do
            echo "   • $ns"
        done
        echo "   ... and $((repo_count - 5)) more"
        echo ""
    fi
}

render_config_add_next_steps() {
    echo -e "${BLUE}🚀 Next Steps${NC}"
    echo -e "   1. Start indexing:     ${YELLOW}bitoarch index-repos${NC}"
    echo -e "   2. Monitor progress:   ${YELLOW}bitoarch index-status${NC}"
    # Gate on the existing SKIP_SSO_PROMPT flag (via sso_ui_suppressed
    # in path-manager.sh). SA install_run sets it; prod leaves it unset.
    if ! command -v sso_ui_suppressed >/dev/null 2>&1 || ! sso_ui_suppressed; then
        echo -e "   3. Configure SSO:      ${YELLOW}bitoarch sso setup${NC}"
    fi
    echo ""
}

render_config_add_failure_block() {
    local http_code="$1"
    local error_body="$2"
    
    echo ""
    echo -e "${RED}❌ Configuration Add Failed${NC}"
    echo ""
    
    # Parse error message if JSON
    local error_msg="$error_body"
    if command -v jq >/dev/null 2>&1 && echo "$error_body" | jq . >/dev/null 2>&1; then
        error_msg=$(echo "$error_body" | jq -r '.error // .message // "Unknown error"')
    fi
    
    echo -e "${YELLOW}⚠️ Details${NC}"
    echo -e "   HTTP Status: ${http_code}"
    echo -e "   Error: ${error_msg}"
    echo ""
    
    # Provide specific guidance based on error
    if echo "$error_msg" | grep -qi "already exists"; then
        echo -e "${BLUE}💡 Tip${NC}"
        echo -e "   Configuration already exists. Use ${YELLOW}bitoarch update-repos${NC} to update it"
        echo ""
    else
        echo -e "${BLUE}🔍 Check${NC}"
        echo -e "   • Is BITO_API_KEY set correctly in .env-bitoarch?"
        echo -e "   • Is GIT_PROVIDER set in .env-bitoarch?"
        echo -e "   • Is GIT_ACCESS_TOKEN set in .env-bitoarch?"
        echo -e "   • Is AI Architect Config service running? ${YELLOW}bitoarch status${NC}"
        echo ""
    fi
}

render_namespace_added_block() {
    local namespace="$1"
    local config_file="$2"
    
    echo ""
    echo -e "${GREEN}✅ Namespace Added${NC}"
    echo ""
    echo -e "${BLUE}📝 Details${NC}"
    echo -e "   • Namespace: ${BOLD}${namespace}${NC}"
    echo -e "   • File: ${config_file}"
    echo ""
    echo -e "${BLUE}🚀 Next Step${NC}"
    echo -e "   Apply changes: ${YELLOW}bitoarch add-repos${NC}"
    echo ""
}

render_namespace_removed_block() {
    local namespace="$1"
    local config_file="$2"
    
    echo ""
    echo -e "${GREEN}✅ Namespace Removed${NC}"
    echo ""
    echo -e "${BLUE}📝 Details${NC}"
    echo -e "   • Namespace: ${BOLD}${namespace}${NC}"
    echo -e "   • File: ${config_file}"
    echo ""
    echo -e "${BLUE}🚀 Next Step${NC}"
    echo -e "   Update config: ${YELLOW}bitoarch update-repos${NC}"
    echo ""
}

render_repo_add_success_block() {
    local namespace="$1"
    local response_json="$2"
    
    if ! command -v jq >/dev/null 2>&1; then
        echo ""
        echo -e "${GREEN}✅ Repository Added Successfully${NC}"
        echo ""
        echo -e "   • Namespace: ${BOLD}${namespace}${NC}"
        echo ""
        return 0
    fi
    
    # Extract details from response
    local workspace_id=$(echo "$response_json" | jq -r '.workspace_id // "N/A"')
    local repo_count=$(echo "$response_json" | jq -r '.configured_repos | length' 2>/dev/null || echo "0")
    
    echo ""
    echo -e "${GREEN}✅ Repository Added Successfully${NC}"
    echo ""
    echo -e "${BLUE}📝 Details${NC}"
    echo -e "   • Namespace: ${BOLD}${namespace}${NC}"
    echo -e "   • Workspace ID: ${workspace_id}"
    echo -e "   • Total Repositories: ${repo_count}"
    echo ""
    
    # Show configured repos if not too many
    if [ "$repo_count" -gt 0 ] && [ "$repo_count" -le 10 ]; then
        echo -e "${BLUE}📁 Configured Repositories${NC}"
        echo "$response_json" | jq -r '.configured_repos[]?.namespace // empty' 2>/dev/null | while read -r ns; do
            if [ "$ns" = "$namespace" ]; then
                echo -e "   • ${BOLD}${ns}${NC} ${GREEN}(newly added)${NC}"
            else
                echo "   • $ns"
            fi
        done
        echo ""
    elif [ "$repo_count" -gt 10 ]; then
        echo -e "${BLUE}📁 Recently Added${NC}"
        echo -e "   • ${BOLD}${namespace}${NC}"
        echo ""
    fi
    
    echo -e "${BLUE}🚀 Next Steps${NC}"
    echo -e "   1. View all repositories: ${YELLOW}bitoarch show-config${NC}"
    echo -e "   2. Start indexing: ${YELLOW}bitoarch index-repos${NC}"
    echo ""
}

render_repo_add_failure_block() {
    local namespace="$1"
    local http_code="$2"
    local error_body="$3"
    
    # Parse error message if JSON
    local error_msg="$error_body"
    if command -v jq >/dev/null 2>&1 && echo "$error_body" | jq . >/dev/null 2>&1; then
        error_msg=$(echo "$error_body" | jq -r '.error // .message // "Unknown error"')
    fi
    
    # Check for configuration not found error first
    if echo "$error_msg" | grep -qi "configuration not found"; then
        echo ""
        echo -e "${BLUE}💡 Configuration Not Initialized${NC}"
        echo -e "   AI Architect configuration has not been created yet."
        echo ""
        echo -e "${BLUE}🔧 To Fix${NC}"
        echo -e "   Run: ${YELLOW}bitoarch add-repos${NC}"
        echo ""
        echo -e "   This will initialize the configuration with your repositories."
        echo ""
        return 0
    fi
    
    # For other errors, show full details
    echo ""
    echo -e "${RED}❌ Failed to Add Repository${NC}"
    echo ""
    
    echo -e "${YELLOW}⚠️ Details${NC}"
    echo -e "   • Namespace: ${namespace}"
    echo -e "   • HTTP Status: ${http_code}"
    echo -e "   • Error: ${error_msg}"
    echo ""
    
    # Provide specific guidance based on error
    if echo "$error_msg" | grep -qi "already exists"; then
        echo -e "${BLUE}💡 Note${NC}"
        echo -e "   Repository '${namespace}' is already configured"
        echo ""
    elif echo "$error_msg" | grep -qi "authentication\|authorization\|unauthorized"; then
        echo -e "${BLUE}🔍 Check${NC}"
        echo -e "   • Is BITO_API_KEY set correctly in .env-bitoarch?"
        echo -e "   • Verify token has correct permissions"
        echo ""
    else
        echo -e "${BLUE}🔍 Check${NC}"
        echo -e "   • Is BITO_API_KEY set correctly in .env-bitoarch?"
        echo -e "   • Is AI Architect Config service running? ${YELLOW}bitoarch status${NC}"
        echo -e "   • Check service logs: ${YELLOW}docker logs ai-architect-config${NC}"
        echo ""
    fi
}

render_repo_remove_success_block() {
    local namespace="$1"
    local response_json="$2"
    
    if ! command -v jq >/dev/null 2>&1; then
        echo ""
        echo -e "${GREEN}✅ Repository Removed Successfully${NC}"
        echo ""
        echo -e "   • Namespace: ${BOLD}${namespace}${NC}"
        echo ""
        return 0
    fi
    
    # Extract details from response
    local workspace_id=$(echo "$response_json" | jq -r '.workspace_id // "N/A"')
    local repo_count=$(echo "$response_json" | jq -r '.configured_repos | length' 2>/dev/null || echo "0")
    
    echo ""
    echo -e "${GREEN}✅ Repository Removed Successfully${NC}"
    echo ""
    echo -e "${BLUE}📝 Details${NC}"
    echo -e "   • Namespace: ${BOLD}${namespace}${NC}"
    echo -e "   • Workspace ID: ${workspace_id}"
    echo -e "   • Remaining Repositories: ${repo_count}"
    echo ""
    
    # Show remaining repos if not too many
    if [ "$repo_count" -gt 0 ] && [ "$repo_count" -le 10 ]; then
        echo -e "${BLUE}📁 Remaining Configured Repositories${NC}"
        echo "$response_json" | jq -r '.configured_repos[]?.namespace // empty' 2>/dev/null | while read -r ns; do
            echo "   • $ns"
        done
        echo ""
    fi
    
    echo -e "${BLUE}🚀 Next Steps${NC}"
    echo -e "   1. View all repositories: ${YELLOW}bitoarch show-config${NC}"
    echo -e "   2. Purge its index data: ${YELLOW}bitoarch remove-index ${namespace}${NC}"
    echo ""
}

render_repo_remove_failure_block() {
    local namespace="$1"
    local http_code="$2"
    local error_body="$3"
    
    echo ""
    echo -e "${RED}❌ Failed to Remove Repository${NC}"
    echo ""
    
    # Parse error message if JSON
    local error_msg="$error_body"
    if command -v jq >/dev/null 2>&1 && echo "$error_body" | jq . >/dev/null 2>&1; then
        error_msg=$(echo "$error_body" | jq -r '.error // .message // "Unknown error"')
    fi
    
    echo -e "${YELLOW}⚠️ Details${NC}"
    echo -e "   • Namespace: ${namespace}"
    echo -e "   • HTTP Status: ${http_code}"
    echo -e "   • Error: ${error_msg}"
    echo ""
    
    # Provide specific guidance based on error
    if echo "$error_msg" | grep -qi "not found\|does not exist"; then
        echo -e "${BLUE}💡 Note${NC}"
        echo -e "   Repository '${namespace}' is not in the configuration"
        echo -e "   • View configured repos: ${YELLOW}bitoarch show-config${NC}"
        echo ""
    elif echo "$error_msg" | grep -qi "authentication\|authorization\|unauthorized"; then
        echo -e "${BLUE}🔍 Check${NC}"
        echo -e "   • Is BITO_API_KEY set correctly in .env-bitoarch?"
        echo -e "   • Verify token has correct permissions"
        echo ""
    else
        echo -e "${BLUE}🔍 Check${NC}"
        echo -e "   • Is BITO_API_KEY set correctly in .env-bitoarch?"
        echo -e "   • Is AI Architect Config service running? ${YELLOW}bitoarch status${NC}"
        echo -e "   • Check service logs: ${YELLOW}docker logs ai-architect-config${NC}"
        echo ""
    fi
}

render_fetch_repo_list_failure_block() {
    local http_code="$1"
    local error_body="$2"
    
    # Parse error message if JSON
    local error_msg="$error_body"
    if command -v jq >/dev/null 2>&1 && echo "$error_body" | jq . >/dev/null 2>&1; then
        error_msg=$(echo "$error_body" | jq -r '.error // .message // "Unknown error"')
    fi
    
    # Special handling ONLY for 401 Unauthorized (invalid/expired token)
    if [ "$http_code" = "401" ]; then
        echo ""
        echo -e "${RED}❌ Authentication Failed${NC}"
        echo ""
        echo -e "${YELLOW}⚠️ Unauthorized (401)${NC}"
        echo -e "   Invalid or expired Git access token"
        echo ""
        echo -e "${BLUE}📋 Possible Causes${NC}"
        echo -e "   • Git access token is incorrect"
        echo -e "   • Token has expired or been revoked"
        echo -e "   • Token doesn't have required permissions"
        echo ""
        echo -e "${BLUE}🔧 Resolution${NC}"
        echo -e "   1. Verify your Git access token at your Git provider"
        echo -e "   2. Update credentials: ${YELLOW}bitoarch update-git-creds${NC}"
        echo ""
        return 0
    fi
    
    # Generic error handling for all other HTTP codes (like other commands)
    echo ""
    echo -e "${RED}❌ Failed to Fetch Repository List${NC}"
    echo ""
    echo -e "${YELLOW}⚠️ Details${NC}"
    echo -e "   HTTP Status: ${http_code}"
    echo -e "   Error: ${error_msg}"
    echo ""
    echo -e "${BLUE}🔍 Check${NC}"
    echo -e "   • Is BITO_API_KEY set correctly in .env-bitoarch?"
    echo -e "   • Is GIT_PROVIDER set in .env-bitoarch?"
    echo -e "   • Is GIT_ACCESS_TOKEN set in .env-bitoarch?"
    echo -e "   • Is AI Architect Config service running? ${YELLOW}bitoarch status${NC}"
    echo ""
}

# ============================================================================
# MANAGER SYNC BLOCKS
# ============================================================================

render_sync_started_block() {
    local workspace_id="$1"
    local index_type="$2"
    local repo_count="$3"
    
    echo ""
    echo -e "${GREEN}✅ Indexing Initiated${NC}"
    echo ""
    echo -e "${BLUE}📊 Indexing Details${NC}"
    echo -e "   • Workspace: ${BOLD}${workspace_id}${NC}"
    echo -e "   • Type: ${index_type}"
    [ -n "$repo_count" ] && echo -e "   • Repositories: ${repo_count}"
    echo ""
    echo -e "${BLUE}🔍 Monitor Progress${NC}"
    echo -e "   ${YELLOW}bitoarch index-status${NC}"
    echo ""
}

render_sync_failure_block() {
    local workspace_id="$1"
    local error_msg="$2"
    
    echo ""
    echo -e "${RED}❌ Indexing Failed${NC}"
    echo ""
    echo -e "${YELLOW}⚠️ Details${NC}"
    echo -e "   • Workspace: ${workspace_id}"
    echo -e "   • Error: ${error_msg}"
    echo ""
    echo -e "${BLUE}🔍 Troubleshoot${NC}"
    echo -e "   • Verify configuration: ${YELLOW}bitoarch show-config${NC}"
    echo -e "   • Check service health: ${YELLOW}bitoarch status${NC}"
    echo ""
}

render_status_block() {
    local status_json="$1"
    
    echo ""
    echo -e "${BLUE}📊 Index Status${NC}"
    echo ""
    if command -v jq >/dev/null 2>&1 && echo "$status_json" | jq . >/dev/null 2>&1; then
        # Extract key fields for customer-centric view
        local state=$(echo "$status_json" | jq -r '.state // "unknown"')
        local progress=$(echo "$status_json" | jq -r '.progress // "0"')
        local total=$(echo "$status_json" | jq -r '.total // "0"')
        
        echo -e "   • State: ${BOLD}${state}${NC}"
        echo -e "   • Progress: ${progress}/${total}"
        echo ""
        
        # Show full JSON for details
        echo -e "${BLUE}📋 Full Details${NC}"
        echo "$status_json" | jq '.'
    else
        echo "$status_json"
    fi
    echo ""
}

# ============================================================================
# PLATFORM STATUS BLOCKS
# ============================================================================

render_platform_status_block() {
    local healthy_count="$1"
    local total_count="$2"
    local services_detail="$3"
    
    echo ""
    echo -e "${BLUE}🖥️  Platform Status${NC}"
    echo ""
    
    if [ "$healthy_count" -eq "$total_count" ]; then
        echo -e "${GREEN}✅ All Services Healthy${NC} (${healthy_count}/${total_count})"
    elif [ "$healthy_count" -gt 0 ]; then
        echo -e "${YELLOW}⚠️  Partial Health${NC} (${healthy_count}/${total_count})"
    else
        echo -e "${RED}❌ All Services Down${NC} (${healthy_count}/${total_count})"
    fi
    
    echo ""
    echo -e "${BLUE}📋 Services${NC}"
    echo "$services_detail"
    echo ""
    echo -e "${BLUE}🔧 Quick Actions${NC}"
    echo -e "   • View logs: ${YELLOW}bitoarch logs${NC}"
    echo -e "   • Restart:   ${YELLOW}bitoarch restart${NC}"
    echo ""
}

# ============================================================================
# MCP PROVIDER BLOCKS
# ============================================================================

render_mcp_tools_list_block() {
    local tools_json="$1"
    local show_details="${2:-false}"
    
    if [ "$show_details" = "true" ]; then
        # Full details - show complete JSON response
        echo ""
        echo -e "${BLUE}MCP Tools (Detailed)${NC}"
        echo ""
        if command -v jq >/dev/null 2>&1; then
            echo "$tools_json" | jq '.'
        else
            echo "$tools_json"
        fi
        echo ""
    else
        # Just names - clean list
        echo ""
        echo -e "${CYAN}Available MCP Tools:${NC}"
        echo ""
        if command -v jq >/dev/null 2>&1; then
            # Extract tool names from result.tools array
            local tool_names=$(echo "$tools_json" | jq -r '.result.tools[]?.name // empty' 2>/dev/null)
            if [ -n "$tool_names" ]; then
                echo "$tool_names" | while read -r tool; do
                    echo "  • $tool"
                done
            else
                echo "  No tools found"
            fi
        else
            echo "$tools_json"
        fi
        echo ""
        echo -e "${BLUE}💡 Tips:${NC}"
        echo -e "   • Use ${YELLOW}--details${NC} flag to see full tool information"
        echo -e "   • Get specific tool info: ${YELLOW}bitoarch mcp-tool-info <toolname>${NC}"
        echo ""
    fi
}

render_mcp_capabilities_block() {
    local capabilities_json="$1"

    echo ""
    echo -e "${CYAN}MCP Server Capabilities:${NC}"
    echo ""

    if command -v jq >/dev/null 2>&1; then
        local err_msg
        err_msg=$(echo "$capabilities_json" | jq -r '.error.message // empty' 2>/dev/null)
        if [ -n "$err_msg" ]; then
            echo -e "${RED}✗${NC} Server returned an error: $err_msg"
            echo ""
            return 0
        fi

        local server_name server_version proto_version
        server_name=$(echo "$capabilities_json" | jq -r '.result.serverInfo.name // "—"' 2>/dev/null)
        server_version=$(echo "$capabilities_json" | jq -r '.result.serverInfo.version // "—"' 2>/dev/null)
        proto_version=$(echo "$capabilities_json" | jq -r '.result.protocolVersion // "—"' 2>/dev/null)

        echo -e "  ${BLUE}Server:${NC}   ${server_name} ${server_version}"
        echo -e "  ${BLUE}Protocol:${NC} ${proto_version}"
        echo ""
        echo -e "  ${BLUE}Capabilities:${NC}"
        local caps
        caps=$(echo "$capabilities_json" | jq -r '.result.capabilities // {} | to_entries[]? | "    • \(.key)"' 2>/dev/null)
        if [ -n "$caps" ]; then
            echo "$caps"
        else
            echo "    (none advertised)"
        fi
    else
        echo "$capabilities_json"
    fi
    echo ""
}

render_mcp_test_success_block() {
    local mcp_url="$1"
    
    echo ""
    echo -e "${GREEN}✅ MCP Connection Test Passed${NC}"
    echo ""
    echo -e "${BLUE}🔍 Results${NC}"
    echo -e "   • Health check: ${GREEN}OK${NC}"
    echo -e "   • MCP endpoint: ${GREEN}OK${NC}"
    echo -e "   • Authentication: ${GREEN}OK${NC}"
    echo ""
    echo -e "${BLUE}🌐 Endpoint${NC}"
    echo -e "   ${mcp_url}"
    echo ""
}

render_mcp_test_failure_block() {
    local mcp_url="$1"
    local failure_reason="$2"
    
    echo ""
    echo -e "${RED}❌ MCP Connection Test Failed${NC}"
    echo ""
    echo -e "${YELLOW}⚠️ Issue${NC}"
    echo -e "   ${failure_reason}"
    echo ""
    echo -e "${BLUE}🔍 Troubleshoot${NC}"
    echo -e "   • Check service: ${YELLOW}bitoarch status${NC}"
    echo -e "   • Verify token in .env-bitoarch: BITO_MCP_ACCESS_TOKEN"
    echo -e "   • Test URL: ${mcp_url}"
    echo ""
}

# ============================================================================
# TOKEN ROTATION BLOCKS
# ============================================================================

render_token_rotated_block() {
    local new_token="$1"
    local mcp_url="$2"
    
    echo ""
    echo -e "${GREEN}✅ MCP Token Rotated${NC}"
    echo ""
    echo -e "${BLUE}🔑 New Credentials${NC}"
    echo -e "   • Token: ${BOLD}${new_token}${NC}"
    echo -e "   • URL: ${mcp_url}"
    echo ""
    echo -e "${GREEN}💡 Important${NC}"
    echo -e "   Update your MCP client configuration with the new token!"
    echo ""
}

# ============================================================================
# MCP CONFIGURATION BLOCKS
# ============================================================================

render_mcp_drift_block() {
    local drifted_keys="$1"

    echo ""
    echo -e "${YELLOW}⚠️  Restart required to apply configuration changes${NC}"
    echo -e "   ${BLUE}Pending:${NC} ${BOLD}${drifted_keys}${NC}"
    echo -e "   ${BLUE}Run:${NC}     ${YELLOW}bitoarch restart --force${NC}"
}

render_mcp_config_block() {
    local mcp_url="$1"
    local mcp_token="$2"
    local oauth_enabled="${3:-${MCP_OAUTH_ENABLED:-false}}"
    local sso_enabled="${4:-${XMCP_SSO_ENABLED:-false}}"
    local sso_provider="${5:-${XMCP_SSO_DEFAULT_PROVIDER:-}}"
    local sso_project_id="${6:-${XMCP_SSO_PROJECT_ID:-}}"
    local url_note="${7:-}"

    echo ""
    # Install flow (render_deploy_success_block) uses the themed section band;
    # the standalone `bitoarch mcp` display keeps the compact plain title.
    if [ "${_MCP_SHOW_BAND:-0}" = "1" ] && type render_section_band >/dev/null 2>&1; then
        render_section_band "🔗" "AI ARCHITECT: MCP SERVER"
        echo ""
    else
        echo -e "${BLUE}${BOLD}🔗 MCP Server${NC}"
    fi
    echo -e "  ${BLUE}URL:${NC}    ${mcp_url}"
    [ -n "$url_note" ] && echo -e "          ${YELLOW}${url_note}${NC}"
    
    # Determine auth display based on OAuth/SSO state
    if [ "$oauth_enabled" = "true" ] && [ "$sso_enabled" = "true" ]; then
        # SSO enabled — no static access token
        echo -e "  ${BLUE}OAuth:${NC}  Enabled"
        if [ "$sso_provider" = "bito" ] || { [ "$sso_provider" = "descope" ] && [ -z "$sso_project_id" ]; }; then
            echo -e "  ${BLUE}Auth:${NC}   SSO via Bito"
        else
            echo -e "  ${BLUE}Auth:${NC}   SSO via Enterprise IdP"
        fi
    elif [ "$oauth_enabled" = "true" ]; then
        # OAuth enabled, SSO not configured
        echo -e "  ${BLUE}Token:${NC}  ${mcp_token}"
        echo -e "  ${BLUE}Auth:${NC}   Bearer Token (OAuth enabled)"
    else
        # Basic auth
        echo -e "  ${BLUE}Token:${NC}  ${mcp_token}"
        echo -e "  ${BLUE}Auth:${NC}   Bearer Token"
    fi

    # On HTTPS installs the auto-installer might not have run (no email
    # supplied at install, or the user wants to register an additional IDE
    # later). Print the manual curl one-liner so they always have a
    # copy/paste path; suppress on http installs where the docs link is
    # the canonical reference.
    if [ "${MCP_TRANSPORT:-http}" = "https" ] && \
       { [ "${MCP_AUTO_INSTALL:-false}" != "true" ] || [ -z "${MCP_USER_EMAIL:-}" ]; }; then
        echo ""
        echo -e "  ${BLUE}Register manually:${NC}"
        echo -e "    ${YELLOW}curl -fsSL ${MCP_INSTALLER_BASE_URL:-https://mcp-setup.bito.ai}/install.sh | bash${NC}"
    fi

    echo ""
    echo -e "  Test: ${YELLOW}bitoarch mcp-test${NC}"
    if [ "${MCP_TRANSPORT:-http}" = "https" ]; then
        echo -e "  Docs: ${BLUE}${BITO_STANDALONE_MCP_DOCS_URL:-https://docs.bito.ai/ai-architect/standalone-mcp-coding-agents}${NC}"
    else
        echo -e "  Docs: ${BLUE}${MCP_SETUP_DOCS_URL:-https://docs.bito.ai/ai-architect/install-ai-architect-self-hosted#setting-up-ai-architect-mcp-in-coding-agents}${NC}"
    fi
    echo ""
}

# ============================================================================
# CLEANUP BLOCKS
# ============================================================================

# K8s access summary: service isolation + how the MCP endpoint and webhooks are published.
# Ingress copy tracks the controller in use: bundled NGINX (default) vs the customer's
# own class (BITOARCH_INGRESS_CLASS non-empty = bring-your-own).
render_k8s_access_block() {
    local namespace="${1:-bito-ai-architect}"
    local ing_class="${BITOARCH_INGRESS_CLASS:-}"

    echo ""
    echo -e "${BLUE}🌐 Network Access${NC}"
    echo -e "   • Services:   private to the cluster (namespace: ${namespace}); no service is exposed directly"
    if [ -n "${BITOARCH_INGRESS_HOST:-}" ]; then
        if [ -n "$ing_class" ]; then
            echo -e "   • Ingress:    https://${BITOARCH_INGRESS_HOST} — served by your ingress controller (class: ${ing_class})"
        else
            echo -e "   • Ingress:    https://${BITOARCH_INGRESS_HOST} — served by the built-in NGINX ingress controller (class: ai-architect-nginx)"
        fi
    else
        if [ -n "$ing_class" ]; then
            echo -e "   • Ingress:    the MCP endpoint and integration webhooks are routed through your ingress controller (class: ${ing_class})"
        else
            echo -e "   • Ingress:    AI Architect includes a built-in NGINX ingress controller (class: ai-architect-nginx) that"
            echo -e "                 publishes the MCP endpoint and integration webhooks — no additional setup required"
            echo -e "                 To use your own ingress controller instead, set ${YELLOW}BITOARCH_INGRESS_CLASS=<your-class>${NC}"
        fi
        echo -e "                 To route a domain, set ${YELLOW}BITOARCH_INGRESS_HOST=<your-domain>${NC} and run ${YELLOW}bitoarch restart --force${NC}"
    fi
    echo ""
}

render_clean_complete_block() {
    local removed_services="$1"
    local removed_volumes="$2"
    
    echo ""
    echo -e "${GREEN}✅ AI Architect Cleanup Complete${NC}"
    echo ""
    echo -e "${BLUE}🗑️  Removed${NC}"
    echo -e "   • Services: ${removed_services}"
    echo -e "   • Data volumes: ${removed_volumes}"
    echo -e "   • Local directories: Cleared"
    echo ""
    echo -e "${BLUE}💡 Next Steps${NC}"
    echo -e "   • Re-run your install command to reinstall"
    echo -e "   • All data has been permanently removed"
    echo ""
}

# Symmetric with `bitoarch start`'s success body. Matches product visual
# vocabulary: GREEN ✅ banner, BLUE 💡 header for Next Steps, YELLOW commands.
# The one-sentence "preserved" subline explains what stop does vs. reset
# (the whole reason someone ran stop instead of reset).
render_stop_complete_block() {
    echo ""
    echo -e "${GREEN}✅ AI Architect Stopped${NC}"
    echo -e "   Containers, data, and config preserved."
    echo ""
    echo -e "${BLUE}💡 Next Steps${NC}"
    echo -e "   • Resume:    ${YELLOW}bitoarch start${NC}"
    echo -e "   • Wipe data: ${YELLOW}bitoarch uninstall --purge${NC}"
    echo ""
}

render_services_not_running_block() {
    echo ""
    echo -e "${YELLOW}⚠️  AI Architect Services Not Running${NC}"
    echo ""
    echo -e "${BLUE}💡 To Start Services${NC}"
    echo -e "   • Run: ${YELLOW}bitoarch start${NC}"
    echo ""
}

# ============================================================================
# CONFIGURATION BLOCKS
# ============================================================================

render_manual_repo_config_block() {
    local repo_config_file
    if type get_repo_config_file >/dev/null 2>&1; then
        repo_config_file="$(get_repo_config_file)"
    else
        repo_config_file=".bitoarch-config.yaml"
    fi
    
    echo ""
    echo -e "${CYAN}📝 Manual Configuration Required${NC}"
    echo -e "   Use the default template file to configure repositories:"
    echo -e "   1. Copy template: ${YELLOW}cp .bitoarch-config.default.yaml ${repo_config_file}${NC}"
    echo -e "   2. Edit file and add your repositories"
    echo -e "   3. Save configuration: ${YELLOW}bitoarch add-repos${NC}"
    echo -e "   4. Start indexing: ${YELLOW}bitoarch index-repos${NC}"
    echo ""
}

# Probes cis-config for create-vs-update. Local yaml count is unreliable
# (setup writes repos before the first POST). Any error defaults to add-repos.
_detect_repo_config_command() {
    local default_command="add-repos"
    if [ -z "${BITO_API_KEY:-}" ]; then
        echo "$default_command"
        return
    fi

    local config_port="${CIS_CONFIG_EXTERNAL_PORT:-5003}"
    local config_url="${CONFIG_URL:-http://localhost:${config_port}}"
    local http_code
    http_code=$(curl -s -o /dev/null -w '%{http_code}' \
        --max-time 3 \
        -H "Authorization: Bearer ${BITO_API_KEY}" \
        "${config_url}/api/v1/config" 2>/dev/null)

    if [ -n "$http_code" ] && [ "$http_code" -ge 200 ] && [ "$http_code" -lt 300 ]; then
        echo "update-repos"
    else
        echo "$default_command"
    fi
}

render_repo_config_choice_block() {
    local config_command
    config_command=$(_detect_repo_config_command)

    echo -e "${BLUE}📘 Review repositories${NC}  (edit with: ${YELLOW}bitoarch config edit repos${NC})"
    echo -e "   Each repository indexed consumes LLM tokens. Remove any you don't want."
    echo ""
    echo -e "${BLUE}🛠  Choose setup mode${NC}"
    echo -e "   1) ${YELLOW}auto${NC}    Save + start indexing (recommended)"
    echo -e "   2) ${YELLOW}manual${NC}  Review, then run: ${YELLOW}bitoarch ${config_command}${NC} && ${YELLOW}bitoarch index-repos${NC}"
    echo ""
}

render_manual_config_instructions_block() {
    local config_command step=1
    config_command=$(_detect_repo_config_command)

    echo -e "${BLUE}📘 Manual Setup${NC}"
    echo -e "   ${step}. Edit repos: ${YELLOW}bitoarch config edit repos${NC}"; step=$((step + 1))
    echo -e "   ${step}. Save:       ${YELLOW}bitoarch ${config_command}${NC}"; step=$((step + 1))
    echo -e "   ${step}. Index:      ${YELLOW}bitoarch index-repos${NC}"; step=$((step + 1))
    if ! command -v sso_ui_suppressed >/dev/null 2>&1 || ! sso_ui_suppressed; then
        echo -e "   ${step}. SSO:        ${YELLOW}bitoarch sso setup${NC}"; step=$((step + 1))
    fi
    echo -e "   ${step}. Plugins:    ${YELLOW}bitoarch plugin install <name>${NC}  (optional — run ${YELLOW}bitoarch plugin list${NC} for names)"
    echo ""
    echo -e "🙌 All set! Finish these steps & your environment will be ready."
}

# ============================================================================
# SETUP-SPECIFIC BLOCKS
# ============================================================================

render_security_notice_block() {
    # Security + telemetry reminder. Safe to call in any flow (fresh install,
    # re-install, upgrade). Callers that immediately follow with the API-key
    # prompt should also invoke render_api_key_prompt_header_block.
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo -e "${BLUE}${BOLD}📝 SECURITY & PRIVACY${NC}"
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo ""
    echo -e "${GREEN}🔐 Bito's AI Architect learns your codebase.${NC}"
    echo ""
    echo -e "This on-prem installation is totally secure:"
    echo -e "  ${GREEN}✓${NC} No data about your code will ever be sent to Bito"
    echo -e "  ${GREEN}✓${NC} Bito has no access to your code"
    echo ""
    echo -e "${BLUE}ℹ${NC} Bito does collect some minimal telemetry data about your usage, including:"
    echo "  - How many requests you make"
    echo "  - Which Bito Workspace you are connected to"
    echo ""
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
}

# Extracted from render_security_notice_block so it only prints when an API
# key prompt actually follows. Callers: setup.sh's fresh-install flow.
render_api_key_prompt_header_block() {
    # Source constants if not already loaded
    if [ -z "$BITO_API_KEY_URL" ]; then
        local SCRIPT_DIR="${SCRIPT_DIR:-$(cd "$(dirname "${BASH_SOURCE[0]}")" && cd ../.. && pwd)}"
        if [ -f "${SCRIPT_DIR}/scripts/lib/constants.sh" ]; then
            source "${SCRIPT_DIR}/scripts/lib/constants.sh"
        fi
    fi
    echo ""
    echo -e "${BLUE}=== Bito's AI Architect Setup ===${NC}"
    echo -e "${YELLOW}🔑 Bito API Key is required to proceed${NC}"
    echo ""
    echo -e "Please get your key at ${BLUE}${BITO_API_KEY_URL:-https://alpha.bito.ai/home/advanced}${NC}"
    echo ""
}

render_git_integration_header_block() {
    # Source constants if not already loaded
    if [ -z "$GIT_TOKEN_DOCS_URL" ]; then
        local SCRIPT_DIR="${SCRIPT_DIR:-$(cd "$(dirname "${BASH_SOURCE[0]}")" && cd ../.. && pwd)}"
        if [ -f "${SCRIPT_DIR}/scripts/lib/constants.sh" ]; then
            source "${SCRIPT_DIR}/scripts/lib/constants.sh"
        fi
    fi

    echo -e "${BLUE}=== Git Integration ===${NC}"
    echo -e "${YELLOW}⚠ Git provider and access token are required to proceed${NC}"
    echo ""
    echo -e "See documentation: ${BLUE}${GIT_TOKEN_DOCS_URL:-https://docs.bito.ai/ai-architect/install-ai-architect-self-hosted#git-provider}${NC}"
    echo ""
}

# Title + underline style; single separator so we don't stack bars when the
# preceding Notice block and the following Indexing block both render their
# own borders.
render_credentials_section_start_block() {
    echo -e "${BLUE}${BOLD}🔧 QUICK CONFIGURATION${NC}"
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
}

# ============================================================================
# ERROR BLOCKS (GENERIC)
# ============================================================================

render_error_missing_dependency_block() {
    local tool_name="$1"
    local install_hint="$2"
    
    echo ""
    echo -e "${RED}❌ Missing Required Tool${NC}"
    echo ""
    echo -e "${YELLOW}⚠️ Required${NC}"
    echo -e "   ${BOLD}${tool_name}${NC} is required for this operation"
    echo ""
    echo -e "${BLUE}📦 Install${NC}"
    echo -e "   ${install_hint}"
    echo ""
}

render_error_env_var_missing_block() {
    local var_name="$1"
    local hint="$2"
    
    echo ""
    echo -e "${RED}❌ Missing Environment Variable${NC}"
    echo ""
    echo -e "${YELLOW}⚠️ Required${NC}"
    echo -e "   ${BOLD}${var_name}${NC} not found in environment"
    echo ""
    echo -e "${BLUE}🔧 Fix${NC}"
    echo -e "   ${hint}"
    echo ""
}

render_error_file_not_found_block() {
    local file_path="$1"
    local expected_location="$2"
    
    echo ""
    echo -e "${RED}❌ File Not Found${NC}"
    echo ""
    echo -e "${YELLOW}⚠️ Missing${NC}"
    echo -e "   ${file_path}"
    echo ""
    [ -n "$expected_location" ] && echo -e "${BLUE}📁 Expected Location${NC}"
    [ -n "$expected_location" ] && echo -e "   ${expected_location}"
    [ -n "$expected_location" ] && echo ""
}

# ============================================================================
# HELPER FUNCTIONS
# ============================================================================

# Silent logging (no output, just log file)
log_silent() {
    local message="$1"
    [ -n "${LOG_FILE:-}" ] && echo "[$(date +'%Y-%m-%d %H:%M:%S')] $message" >> "$LOG_FILE"
}

# Log-only banner for service lifecycle events (not shown to customer)
log_service_lifecycle_banner() {
    local operation="$1"  # "Starting", "Restarting", "Stopping"
    
    log_silent "========================================"
    log_silent "AI Architect Platform ${operation}"
    log_silent "========================================"
}

# ============================================================================
# INDEXING INFORMATION BLOCK
# ============================================================================

render_indexing_information_block() {
    echo ""
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo -e "${BLUE}${BOLD}📊 AI ARCHITECT: INDEXING INFORMATION${NC}"
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo ""
    echo "🧠 AI Architect uses LLMs to build a knowledge graph of your code."
    echo "🔒 Runs fully on-prem. Only basic telemetry is sent to Bito."
    echo "🛡️ Your code and artifacts never leave your environment."
    echo ""
    echo -e "${YELLOW}💰 Indexing cost estimates:${NC}"
    echo "Models below are benchmark defaults/recommendations, not the full supported list."
    echo "Costs may vary by model, provider pricing, and source code structure."
    echo ""
    # Rows are data-driven from the LLM registry (_llm_cost_rows), printed in
    # info_display.order. A row with a cost per MB shows its default_model + figure;
    # a row without one (gateways / routed providers) shows its default_model label
    # and info_display.message, since the cost depends on the model it routes to.
    # Order, labels, and messaging all live in the registry -- nothing hardcoded.
    local _id _label _model _cost _msg
    while IFS=$'\x1f' read -r _id _label _model _cost _msg; do
        if [ -n "$_cost" ]; then
            printf '  • %-24s %-26s ~$%s per MB\n' "$_label" "$_model" "$_cost"
        else
            printf '  • %-24s %-26s %s\n' "$_label" "$_model" "$_msg"
        fi
    done < <(_llm_cost_rows)
    echo ""
    echo "We index source code only; binaries/ZIPs/TARs/images are skipped."
    echo ""
    echo -e "${BLUE}📚 Provider setup guides:${NC} ${AI_ARCHITECT_DOCS_HOME_URL}"
    echo ""
    echo -e "${BLUE}❓ Questions about standard setup, pricing, or Enterprise deployment?${NC}"
    echo "📧 Email: support@bito.ai"
    echo ""
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo ""
}

# ============================================================================
# KUBERNETES DEPLOYMENT BLOCKS
# ============================================================================

render_k8s_deploy_success_block() {
    local mcp_token="$1"
    local mcp_url="$2"
    local namespace="$3"
    local setup_mode="${4:-manual}"
    
    echo ""
    echo -e "${GREEN}🎉 Bito AI Architect deployed to Kubernetes! 🎉${NC}"
    echo ""
    echo -e "${BLUE}🔑 MCP Server Configuration${NC}"
    echo ""
    echo -e "${YELLOW}⚠️ You will need this information to set up your MCP server in your coding agent${NC}"
    echo -e "${YELLOW}  (Claude, Cursor, Codex, Copilot, etc):${NC}"
    echo ""
    echo -e "  • Bito MCP URL:          ${CYAN}${mcp_url}${NC}"
    echo -e "  • Bito MCP Access Token: ${CYAN}${mcp_token}${NC}"
    echo ""
    echo -e "${BLUE}🔧 CLI Commands${NC}"
    echo ""
    echo -e "  • Activate CLI:       ${YELLOW}source ~/.${SHELL##*/}rc${NC} (or restart terminal)"
    echo -e "  • Check status:       ${YELLOW}bitoarch status${NC}"
    echo -e "  • View logs:          ${YELLOW}bitoarch logs${NC}"
    echo -e "  • View MCP tools:     ${YELLOW}bitoarch mcp-tools${NC}"
    echo ""
    
    if [[ "$setup_mode" == "manual" ]]; then
        echo -e "${BLUE}🚀 Next Steps${NC}"
        echo ""
        echo -e "  1. Add repositories:    ${YELLOW}bitoarch add-repos${NC}"
        echo -e "  2. Start indexing:      ${YELLOW}bitoarch index-repos${NC}"
        echo -e "  3. Monitor progress:    ${YELLOW}bitoarch index-status${NC}"
        echo ""
    fi
    
    echo -e "${BLUE}☸️  Kubernetes Deployment${NC}"
    echo -e "  • Namespace: ${namespace}"
    echo -e "  • Documentation: ${YELLOW}${AI_ARCHITECT_DOCS_HOME_URL}${NC}"
    echo ""
}

render_k8s_deploy_failure_block() {
    local error_msg="$1"
    local log_file="${2:-}"
    
    echo ""
    echo -e "${RED}❌ Kubernetes Deployment Failed${NC}"
    echo ""
    echo -e "${YELLOW}⚠️ Issue${NC}"
    echo -e "   ${error_msg}"
    echo ""
    echo -e "${BLUE}🔍 Troubleshooting${NC}"
    echo -e "   • Check status: ${YELLOW}bitoarch status${NC}"
    echo -e "   • View logs:    ${YELLOW}bitoarch logs${NC}"
    [ -n "$log_file" ] && echo -e "   • Setup log:    ${YELLOW}cat ${log_file}${NC}"
    echo -e "   • Restart:      ${YELLOW}bitoarch restart${NC}"
    echo ""
}

render_deployment_method_choice_block() {
    echo ""
    echo -e "${BLUE}=== Deployment Method Selection ===${NC}"
    echo ""
    echo "Choose your deployment platform:"
    echo ""
    echo "  1) Docker Compose (Recommended for single server)"
    echo "     • Quick setup (5-10 minutes)"
    echo "     • Requirements: Docker Desktop or Docker Engine"
    echo "     • Resource: 4GB RAM, 10GB disk"
    echo "     • Best for: Single server, development, small teams"
    echo ""
    echo "  2) Kubernetes (Recommended for enterprise/scale)"
    echo "     • High availability with auto-healing"
    echo "     • Requirements: kubectl, helm, running K8s cluster"
    echo "     • Resource: 8GB RAM, 20GB disk"
    echo "     • Best for: Multi-server, production, large deployments"
    echo ""
}

render_repo_reconfiguration_prompt_block() {
    local repo_count="$1"
    
    echo ""
    echo -e "${BLUE}=== Repository Configuration ===${NC}"
    msg_info "Found existing repository configuration with ${repo_count} repository(ies)"
    echo ""
    read -r -p "Do you want to reconfigure repositories? (y/N): " reconfigure
    
    # Return the user's choice via exit code
    if [[ "$reconfigure" =~ ^[Yy]$ ]]; then
        msg_info "Will fetch and reconfigure repository list..."
        return 0
    else
        echo ""
        msg_success "Repository configuration preserved"
        return 1
    fi
}

render_k8s_prerequisites_check_block() {
    local kubectl_version="$1"
    local helm_version="$2"
    local k8s_version="$3"
    
    echo ""
    echo -e "${BLUE}☸️  Kubernetes Prerequisites${NC}"
    echo ""
    echo -e "  ${GREEN}✓${NC} kubectl: ${kubectl_version}"
    echo -e "  ${GREEN}✓${NC} helm: ${helm_version}"
    echo -e "  ${GREEN}✓${NC} cluster: ${k8s_version}"
    echo ""
}

render_k8s_node_port_conflict_block() {
    local conflicting_ports="$1"
    
    echo ""
     echo -e "${RED}❌ Port Conflicts Detected${NC}"
    echo ""
    echo -e "${YELLOW}⚠️ Conflicting Ports${NC}"
    echo -e "   ${conflicting_ports}"
    echo ""
    echo -e "${YELLOW}To resolve:${NC}"
    echo -e "   Update ports in: ${YELLOW}.env-bitoarch.default${NC}"
    echo ""
}

render_k8s_not_available_block() {
    echo ""
    print_error "Cannot proceed with Kubernetes deployment"
    echo ""
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo ""
    echo "⚠️  Kubernetes Cluster Not Available"
    echo ""
    echo "The selected deployment requires a running Kubernetes cluster."
    echo ""
    echo "To validate your Kubernetes setup, run:"
    echo "  kubectl cluster-info"
    echo "  kubectl get nodes"
    echo ""
    echo "If you have a Kubernetes cluster:"
    echo "  • Ensure it's running"
    echo "  • Verify kubectl context: kubectl config current-context"
    echo "  • Check connectivity: kubectl cluster-info"
    echo ""
    echo "If you don't have a Kubernetes cluster:"
    echo "  • Re-run the install and select Docker Compose (option 1)"
    echo ""
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo ""
}

# ============================================================================
# SSO CONFIGURATION BLOCKS
# ============================================================================

render_sso_config_prompt_block() {
    echo ""
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo -e "${BLUE}${BOLD}🔐 AI ARCHITECT: SSO CONFIGURATION${NC}"
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo ""
    echo "SSO enables secure authentication for MCP Server access."
    echo -e "You can choose Enterprise IdP (SAML/OIDC) or Bito during setup."
    echo ""
}

render_sso_deferred_block() {
    echo ""
    msg_info "SSO configuration deferred"
    echo ""
    echo -e "${BLUE}💡 To configure SSO later:${NC}"
    echo -e "   ${YELLOW}bitoarch sso setup${NC}"
    echo ""
}

render_sso_setup_url_block() {
    local setup_url="$1"
    local expiry_display="${2:-30 minutes}"
    
    echo ""
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo -e "${BLUE}${BOLD}🔐 Identity Provider Configuration${NC}"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo ""
    echo -e "${YELLOW}⚠️  Action Required${NC}"
    echo ""
    echo "Open the following URL to configure your IdP (SAML/OIDC):"
    echo ""
    echo -e "   ${CYAN}${BOLD}${setup_url}${NC}"
    echo ""
    echo -e "${BLUE}📋 Configuration Steps${NC}"
    echo "  1. Open URL in your browser"
    echo "  2. Configure IdP settings (SAML or OIDC)"
    echo "  3. Add your domains (optional)"
    echo "  4. Test IdP connection"
    echo "  5. Save configuration"
    echo ""
    echo -e "⏰ This URL expires in ${YELLOW}${expiry_display}${NC}"
    echo ""
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo ""
}

render_sso_setup_complete_block() {
    echo ""
    echo -e "${GREEN}✅ SSO Configuration Complete${NC}"
    echo ""
    echo -e "${BLUE}📊 Configuration Status${NC}"
    echo -e "   • SSO: ${GREEN}Enabled${NC}"
    echo ""
    echo -e "${BLUE}🔧 SSO Commands${NC}"
    echo -e "   • Check status:  ${YELLOW}bitoarch sso status${NC}"
    echo -e "   • Rotate key:    ${YELLOW}bitoarch sso rotate-key${NC}"
    echo ""
}

render_sso_verify_success_block() {
    echo ""
    echo -e "${GREEN}✅ SSO Verification Successful${NC}"
    echo -e "   Identity Provider configured and verified."
    echo ""
}

render_sso_verify_failed_block() {
    echo ""
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo -e "${BLUE}${BOLD}🔐 AI ARCHITECT: SSO VERIFICATION${NC}"
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo ""
    echo -e "⚠️  Identity Provider (IdP) has not been configured yet."
    echo ""
    echo -e "   Run: ${YELLOW}bitoarch sso setup${NC}"
    echo ""
}

render_sso_already_configured_block() {
    echo ""
    echo -e "${GREEN}✅ SSO is already configured for your AI Architect MCP${NC}"
    echo ""
}

# ── SSO Disable Blocks ──

render_sso_disable_prompt_block() {
    local current_mode="$1"
    
    echo ""
    echo -e "${BLUE}=== SSO Configuration ===${NC}"
    echo ""
    echo -e "${GREEN}✓${NC} SSO is currently enabled"
    [ -n "$current_mode" ] && echo -e "   Mode: ${BOLD}${current_mode}${NC}"
    echo ""
    echo "How would you like to disable SSO?"
    echo ""
    echo "  1) ⏸️  Temporarily disable"
    echo "     • SSO authentication will be paused"
    echo "     • IdP configuration is preserved"
    echo -e "     • Re-enable anytime with: ${YELLOW}bitoarch sso enable${NC}"
    echo ""
    echo "  2) 🗑️  Permanently remove"
    echo "     • Deletes IdP configuration from server"
    echo "     • Removes all SSO settings"
    echo "     • Full reconfiguration needed to re-enable"
    echo ""
}

render_sso_disable_bito_prompt_block() {
    echo ""
    echo -e "${BLUE}=== SSO Configuration ===${NC}"
    echo ""
    echo -e "${GREEN}✓${NC} SSO enabled via Bito"
    echo ""
    echo "   Disabling will revert to basic OAuth (Bearer Token)."
    echo ""
}

render_sso_disabled_temp_block() {
    local mcp_token="$1"
    
    echo ""
    echo -e "⏸️  ${GREEN}SSO temporarily disabled${NC}"
    echo ""
    echo "   Authentication will fall back to Bearer Token."
    [ -n "$mcp_token" ] && echo -e "   • MCP Token: ${CYAN}${mcp_token}${NC}"
    echo ""
    echo -e "   • Re-enable:     ${YELLOW}bitoarch sso enable${NC}"
    echo -e "   • Check status:  ${YELLOW}bitoarch sso status${NC}"
    echo ""
}

render_sso_disabled_permanent_block() {
    local mcp_token="$1"
    
    echo ""
    echo -e "🗑️  ${GREEN}SSO permanently removed${NC}"
    echo ""
    echo "   IdP configuration has been deleted."
    echo "   Authentication reverted to Bearer Token."
    [ -n "$mcp_token" ] && echo -e "   • MCP Token: ${CYAN}${mcp_token}${NC}"
    echo ""
    echo -e "   • Reconfigure:   ${YELLOW}bitoarch sso setup${NC}"
    echo -e "   • Check status:  ${YELLOW}bitoarch sso status${NC}"
    echo ""
}

# ── SSO Enable Blocks ──

render_sso_enabled_block() {
    local auth_mode="$1"
    
    echo ""
    echo -e "${GREEN}✅ SSO enabled successfully${NC}"
    echo ""
    echo -e "   • Authentication: ${BOLD}${auth_mode}${NC}"
    echo -e "   • Check status:   ${YELLOW}bitoarch sso status${NC}"
    echo ""
}

render_sso_already_enabled_block() {
    local auth_mode="$1"
    
    echo ""
    echo -e "${BLUE}ℹ️${NC}  SSO is already enabled"
    [ -n "$auth_mode" ] && echo -e "   • Mode: ${BOLD}${auth_mode}${NC}"
    echo ""
    echo -e "   • Check status:  ${YELLOW}bitoarch sso status${NC}"
    echo ""
}

render_sso_enable_incomplete_block() {
    echo ""
    echo -e "ℹ️  SSO Configuration Incomplete..."
    echo ""
    echo -e "   • Configure SSO :  ${YELLOW}bitoarch sso setup${NC}"
    echo ""
}

# ── SSO Status Blocks ──

render_sso_status_verified_block() {
    local workspace_id="$1"
    local auth_mode="$2"
    local oauth_enabled="$3"
    
    echo ""
    echo -e "${BLUE}=== SSO Status ===${NC}"
    echo ""
    echo -e "${GREEN}✓${NC} SSO is enabled and verified"
    echo ""
    echo -e "${BLUE}📊 Configuration${NC}"
    echo -e "   • Authentication:  ${BOLD}${auth_mode}${NC}"
    echo -e "   • Workspace ID:    ${workspace_id}"
    echo -e "   • OAuth:           ${oauth_enabled}"
    echo -e "   • IdP Status:      ${GREEN}✓ Connected${NC}"
    echo ""
    echo -e "${BLUE}🔧 SSO Commands${NC}"
    echo -e "   • Rotate key:    ${YELLOW}bitoarch sso rotate-key${NC}"
    echo -e "   • Disable SSO:   ${YELLOW}bitoarch sso disable${NC}"
    echo ""
}

render_sso_status_unverified_block() {
    local workspace_id="$1"
    local oauth_enabled="$2"
    
    echo ""
    echo -e "${BLUE}=== SSO Status ===${NC}"
    echo ""
    echo -e "${YELLOW}⚠${NC} SSO is enabled but IdP is not configured"
    echo ""
    echo -e "${BLUE}📊 Configuration${NC}"
    echo -e "   • Authentication:  ${BOLD}Bito (fallback)${NC}"
    echo -e "   • Workspace ID:    ${workspace_id}"
    echo -e "   • OAuth:           ${oauth_enabled}"
    echo -e "   • IdP Status:      ${RED}✗ Not configured${NC}"
    echo ""
    echo -e "${BLUE}ℹ${NC} Since IdP configuration is pending, Bito is used as fallback."
    echo ""
    echo -e "${BLUE}🔧 Next Steps${NC}"
    echo -e "   • Configure IdP:  ${YELLOW}bitoarch sso setup${NC}"
    echo -e "   • Disable SSO:    ${YELLOW}bitoarch sso disable${NC}"
    echo ""
}

render_sso_status_bito_block() {
    local workspace_id="$1"
    local oauth_enabled="$2"
    
    echo ""
    echo -e "${BLUE}=== SSO Status ===${NC}"
    echo ""
    echo -e "${GREEN}✓${NC} SSO is enabled via Bito"
    echo ""
    echo -e "${BLUE}📊 Configuration${NC}"
    echo -e "   • Authentication:  ${BOLD}Bito${NC}"
    echo -e "   • Workspace ID:    ${workspace_id}"
    echo -e "   • OAuth:           ${oauth_enabled}"
    echo -e "   • IdP Status:      ${YELLOW}— Not configured${NC}"
    echo ""
    echo -e "${BLUE}🔧 SSO Commands${NC}"
    echo -e "   • Configure IdP:  ${YELLOW}bitoarch sso setup${NC}"
    echo -e "   • Disable SSO:    ${YELLOW}bitoarch sso disable${NC}"
    echo ""
}

render_sso_status_disabled_block() {
    echo ""
    echo -e "${BLUE}=== SSO Status ===${NC}"
    echo ""
    echo -e "${YELLOW}🔒 SSO is not enabled${NC}"
    echo ""
    echo -e "   To configure SSO, run: ${YELLOW}bitoarch sso setup${NC}"
    echo ""
}

# ── SSO Setup IdP Choice Block ──

render_sso_idp_choice_block() {
    echo ""
    echo -e "🏢 Enterprise IdP supports SAML/OIDC providers (Okta, Azure AD, etc.)"
    echo -e "🔑 If you don't have one, Bito will handle authentication for you."
    echo ""
}

render_sso_bito_auth_enabled_block() {
    echo ""
    echo -e "${GREEN}✅ SSO Configuration Complete${NC}"
    echo ""
    echo -e "${BLUE}📊 Configuration Status${NC}"
    echo -e "   • SSO: ${GREEN}Enabled${NC}"
    echo -e "   • Authentication: Bito"
    echo ""
    echo -e "${BLUE}🔧 SSO Commands${NC}"
    echo -e "   • Check status:  ${YELLOW}bitoarch sso status${NC}"
    echo -e "   • Disable SSO:   ${YELLOW}bitoarch sso disable${NC}"
    echo ""
}

render_sso_key_rotated_block() {
    echo ""
    echo -e "${GREEN}✅ SSO tenant key rotated${NC}"
    echo ""
    echo -e "   • Check status:  ${YELLOW}bitoarch sso status${NC}"
    echo ""
}

render_sso_rotate_not_enabled_block() {
    echo ""
    echo -e "${BLUE}=== 🔑 SSO Key Rotation ===${NC}"
    echo ""
    echo -e "SSO configuration Incomplete"
    echo ""
    echo -e "🚀   Run: ${YELLOW}bitoarch sso setup${NC} to configure now"
    echo ""
}

render_sso_rotate_requires_idp_block() {
    echo ""
    echo -e "${BLUE}=== 🔑 SSO Key Rotation ===${NC}"
    echo ""
    echo -e "${GREEN}✓${NC} SSO is enabled via Bito"
    echo ""
    echo -e "   Key rotation is only required for Enterprise IdP"
    echo -e "   To configure SSO via Enterprise IdP: ${YELLOW}bitoarch sso setup${NC}"
    echo ""
}

render_sso_workspace_invalid_block() {
    local workspace_id="$1"
    echo ""
    echo -e "${RED}❌ Workspace ID ${workspace_id} is not authorized for SSO setup${NC}"
    echo ""
    echo -e "${BLUE}📋 To resolve${NC}"
    echo -e "   • Update repository configuration: ${YELLOW}bitoarch update-repos${NC}"
    echo -e "   • Retry SSO setup: ${YELLOW}bitoarch sso setup${NC}"
    echo ""
}

render_sso_workspace_required_block() {
    echo ""
    echo -e "${YELLOW}⚠${NC}  Repository configuration is required before SSO setup"
    echo ""
    echo -e "${BLUE}🚀 Next Steps${NC}"
    echo -e "   Complete/Update repository configuration:"
    echo -e "   • Add config:    ${YELLOW}bitoarch add-repos${NC}"
    echo -e "   • Update config: ${YELLOW}bitoarch update-repos${NC} (if already added earlier)"
    echo ""
    echo -e "   Then run SSO setup:"
    echo -e "   • ${YELLOW}bitoarch sso setup${NC}"
    echo ""
}

# Export all functions
export -f msg_success
export -f msg_info
export -f msg_warn
export -f msg_error
export -f print_status
export -f print_info
export -f print_warning
export -f print_error
export -f log_silent
export -f log_technical
export -f render_section_band
export -f render_deploy_success_block
export -f render_deploy_failure_block
export -f _resolve_size_limit
export -f _is_positive_int
export -f _basic_index_apply_cmd
export -f _resolve_basic_index_concurrency
export -f render_config_get_summary_block
export -f render_config_get_raw_block
export -f render_config_get_success_block
export -f render_config_get_failure_block
export -f render_config_add_success_block
export -f render_config_add_failure_block
export -f render_namespace_added_block
export -f render_namespace_removed_block
export -f render_repo_add_success_block
export -f render_repo_add_failure_block
export -f render_repo_remove_success_block
export -f render_repo_remove_failure_block
export -f render_fetch_repo_list_failure_block
export -f render_sync_started_block
export -f render_sync_failure_block
export -f render_status_block
export -f render_platform_status_block
export -f render_mcp_tools_list_block
export -f render_mcp_test_success_block
export -f render_mcp_test_failure_block
export -f render_token_rotated_block
export -f render_mcp_drift_block
export -f render_mcp_config_block
export -f render_manual_repo_config_block
export -f render_repo_config_choice_block
export -f render_manual_config_instructions_block
export -f render_error_missing_dependency_block
export -f render_error_env_var_missing_block
export -f render_error_file_not_found_block
export -f render_k8s_deploy_success_block
export -f render_k8s_deploy_failure_block
export -f render_deployment_method_choice_block
export -f render_k8s_prerequisites_check_block
export -f render_k8s_node_port_conflict_block
export -f render_k8s_not_available_block
export -f render_sso_config_prompt_block
export -f render_sso_deferred_block
export -f render_sso_setup_url_block
export -f render_sso_setup_complete_block
export -f render_sso_verify_success_block
export -f render_sso_verify_failed_block
export -f render_sso_already_configured_block
export -f render_sso_disable_prompt_block
export -f render_sso_disable_bito_prompt_block
export -f render_sso_disabled_temp_block
export -f render_sso_disabled_permanent_block
export -f render_sso_enabled_block
export -f render_sso_already_enabled_block
export -f render_sso_enable_incomplete_block
export -f render_sso_status_verified_block
export -f render_sso_status_unverified_block
export -f render_sso_status_bito_block
export -f render_sso_status_disabled_block
export -f render_sso_idp_choice_block
export -f render_sso_bito_auth_enabled_block
export -f render_sso_key_rotated_block
export -f render_sso_rotate_not_enabled_block
export -f render_sso_rotate_requires_idp_block
export -f render_sso_workspace_invalid_block
export -f render_sso_workspace_required_block
