#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
#
# scripts/lib/watcher.sh
# -----------------------------------------------------------------------------
# Generic watch/poll loop for CLI commands.
#
# Public API:
#   watch_loop <interval_secs> <label> <render_fn> [args...]
#
# Carries no domain knowledge. Any command whose output can be produced by a
# single function call gets a watch mode by passing that function here.
#
# Design notes:
#
#  - Render FIRST, then paint. Each tick captures the render function's whole
#    output into a variable before clearing, so the screen is never blank while
#    the work happens. Clearing first flickers on every tick.
#
#  - Clears with \033[H\033[2J (home + viewport) and deliberately NOT \033[3J,
#    which erases scrollback and would throw away the operator's history.
#
#  - Interrupts set a flag rather than returning from inside the trap handler.
#    SIGINT kills the foreground sleep, the flag flips, and the loop exits
#    normally with its trap restored.
#
#  - A failing render function does not end the watch: its output is painted as
#    that tick's snapshot and polling continues. Surviving a brief outage is the
#    point of a watch mode.
#
#  - Capturing the render function in $(...) is safe for callers that open a
#    Kubernetes port-forward: start_port_forward redirects all three fds and
#    disowns, so nothing inherits the capture pipe and holds it open.
# -----------------------------------------------------------------------------

if [ -n "${_BITOARCH_WATCHER_LOADED:-}" ]; then
    return 0
fi
_BITOARCH_WATCHER_LOADED=1

: "${BLUE:=$'\033[0;34m'}"
: "${NC:=$'\033[0m'}"

# Set by the INT/TERM trap to break the loop at the top of the next iteration.
_WATCH_STOP=0

# Reject anything that is not a whole number of seconds at or above the floor.
_watch_validate_interval() {
    local raw="$1"
    local min="${WATCH_MIN_INTERVAL_SECS:-5}"

    case "$raw" in
        ''|*[!0-9]*)
            print_error "--watch interval must be a whole number of seconds (got: ${raw:-empty})"
            return 1
            ;;
    esac

    if [ "$raw" -lt "$min" ]; then
        print_error "--watch interval must be at least ${min}s (got: ${raw}s)"
        return 1
    fi

    return 0
}

# Home the cursor and clear the viewport, leaving scrollback intact.
_watch_clear_screen() {
    printf '\033[H\033[2J'
}

# Reinstate a handler captured by `trap -p`, or clear the signal when the
# caller had none.
_watch_restore_trap() {
    local sig="$1" saved="$2"
    if [ -n "$saved" ]; then
        eval "$saved"
    else
        trap - "$sig"
    fi
}

# Re-run render_fn every interval seconds until interrupted.
watch_loop() {
    local interval="$1" label="$2" render_fn="$3"
    shift 3

    _watch_validate_interval "$interval" || return 1

    if ! type "$render_fn" >/dev/null 2>&1; then
        print_error "watch_loop: no such render function: ${render_fn}"
        return 1
    fi

    local is_tty=false
    if [ -t 1 ]; then
        is_tty=true
    fi

    local ticks=0
    local snapshot stamp

    # Save whatever the caller already had installed. `trap - INT TERM` would
    # discard it, and this utility exists to be called from commands that set
    # their own handlers. `trap -p` emits a re-executable statement, or nothing
    # when no handler is set.
    local prev_int prev_term
    prev_int="$(trap -p INT)"
    prev_term="$(trap -p TERM)"

    _WATCH_STOP=0
    trap '_WATCH_STOP=1' INT TERM

    while [ "$_WATCH_STOP" -eq 0 ]; do
        snapshot="$("$render_fn" "$@" 2>&1)"
        stamp="$(date +%H:%M:%S)"

        if [ "$is_tty" = "true" ]; then
            _watch_clear_screen
            printf '%bWatching %s every %ss — last refresh %s (Ctrl+C to stop)%b\n\n' \
                "$BLUE" "$label" "$interval" "$stamp" "$NC"
        else
            printf '───── %s — %s ─────\n' "$label" "$stamp"
        fi
        printf '%s\n' "$snapshot"

        ticks=$((ticks + 1))
        if [ -n "${_WATCH_MAX_TICKS:-}" ] && [ "$ticks" -ge "$_WATCH_MAX_TICKS" ]; then
            break
        fi

        if [ "$_WATCH_STOP" -ne 0 ]; then
            break
        fi
        sleep "$interval" || true
    done

    _watch_restore_trap INT "$prev_int"
    _watch_restore_trap TERM "$prev_term"

    if [ "$is_tty" = "true" ]; then
        printf '\n'
    fi
    return 0
}

export -f watch_loop
export -f _watch_validate_interval
export -f _watch_clear_screen
export -f _watch_restore_trap
