#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
#
# scripts/lib/install.sh
# -----------------------------------------------------------------------------
# install_run: edition-neutral install entry called by the CDN bootstraps
# (scripts/bitoarch-install.sh, scripts/bitoarch-install-standalone.sh).
#
#   - Applies $HOME/.bitoarch/install.yaml to env (seeded from install.yaml.default).
#   - Sources setup.sh and calls main "$@".
#   - On return, persists SKIP_SSO_PROMPT / AUTO_GENERATE_MCP_TOKEN /
#     COMPACT_INSTALL_PROGRESS to .env-bitoarch iff the caller set them true.
#   - install.yaml is operator-owned: read at start, never written back.
# -----------------------------------------------------------------------------

if [ -n "${_BITOARCH_INSTALL_LIB_LOADED:-}" ]; then
    return 0
fi
_BITOARCH_INSTALL_LIB_LOADED=1

if [ -z "${SCRIPT_DIR:-}" ]; then
    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
fi
PLATFORM_DIR="${PLATFORM_DIR:-${SCRIPT_DIR}}"

# Deps are guarded with -f because bitoarch.sh's `restart --force` sources
# this file with SCRIPT_DIR pointing at scripts/, not repo root.
if [ -f "${SCRIPT_DIR}/scripts/setup-utils.sh" ]; then
    # shellcheck disable=SC1091
    source "${SCRIPT_DIR}/scripts/setup-utils.sh"
fi
if [ -f "${SCRIPT_DIR}/scripts/lib/cli-core.sh" ]; then
    # shellcheck disable=SC1091
    source "${SCRIPT_DIR}/scripts/lib/cli-core.sh"
fi
if [ -f "${SCRIPT_DIR}/scripts/lib/path-manager.sh" ]; then
    # shellcheck disable=SC1091
    source "${SCRIPT_DIR}/scripts/lib/path-manager.sh"
fi
if [ -f "${SCRIPT_DIR}/scripts/lib/install-yaml.sh" ]; then
    # shellcheck disable=SC1091
    source "${SCRIPT_DIR}/scripts/lib/install-yaml.sh"
elif [ -f "$(dirname "${BASH_SOURCE[0]}")/install-yaml.sh" ]; then
    # shellcheck disable=SC1091
    source "$(dirname "${BASH_SOURCE[0]}")/install-yaml.sh"
fi
if [ -f "${SCRIPT_DIR}/scripts/lib/mcp-installer.sh" ]; then
    # shellcheck disable=SC1091
    source "${SCRIPT_DIR}/scripts/lib/mcp-installer.sh"
fi
if [ -f "${SCRIPT_DIR}/scripts/lib/mcp-cert.sh" ]; then
    # shellcheck disable=SC1091
    source "${SCRIPT_DIR}/scripts/lib/mcp-cert.sh"
fi
if [ -f "${SCRIPT_DIR}/scripts/lib/node-trust.sh" ]; then
    # shellcheck disable=SC1091
    source "${SCRIPT_DIR}/scripts/lib/node-trust.sh"
fi
if [ -f "${SCRIPT_DIR}/scripts/lib/cert-cron.sh" ]; then
    # shellcheck disable=SC1091
    source "${SCRIPT_DIR}/scripts/lib/cert-cron.sh"
fi
if [ -f "${SCRIPT_DIR}/scripts/lib/auto-recovery/restart-policy.sh" ]; then
    # shellcheck disable=SC1091
    source "${SCRIPT_DIR}/scripts/lib/auto-recovery/restart-policy.sh"
fi
if [ -f "${SCRIPT_DIR}/scripts/lib/auto-recovery/autostart.sh" ]; then
    # shellcheck disable=SC1091
    source "${SCRIPT_DIR}/scripts/lib/auto-recovery/autostart.sh"
fi

# ---------------------------------------------------------------------------
# Insights hooks — called from setup.sh at the appropriate lifecycle points.
# Defined here so the call sites live in install.sh's domain, even though
# setup.sh still controls when they fire (during generate_env_file and after
# add-repos respectively).
# ---------------------------------------------------------------------------

_install_collect_insights_prompts() {
    command -v ask_git_insights_enabled >/dev/null 2>&1 || return 0
    # Fresh top-level run: clear the instance-switch flag a prior aborted ticket-tracker
    # config may have left set (it's a global that survives the in-function host-type
    # re-loop, so it's reset at the entry rather than inside the function).
    unset _INSIGHTS_JIRA_INSTANCE_CHANGED
    ask_git_insights_enabled
    ask_ticket_tracker_config
    # Clear the re-entry flag a ticket-tracker credential retry may have left set, so
    # it can't suppress the docs "Enable Confluence?" consent prompt below.
    unset _INSIGHTS_SKIP_ENABLE_PROMPT
    ask_docs_config
    ask_insights_lookback_days
    export INSIGHTS_SETUP_COMPLETE=true
}

_install_push_insights_config() {
    if command -v _config_push_insights_after_add_repos >/dev/null 2>&1; then
        _config_push_insights_after_add_repos
    fi
    # Sync project keys selected during install prompts into .bitoarch-config.yaml
    # so tracker-projects list / discover-tracker-projects stay consistent.
    if [ -n "${INSIGHTS_TICKET_TRACKER_PROJECT_KEYS:-}" ] \
       && command -v _insights_tp_has_yaml_tool >/dev/null 2>&1 \
       && _insights_tp_has_yaml_tool 2>/dev/null; then
        local _cfg=""
        command -v _insights_tp_repo_config_path >/dev/null 2>&1 \
            && _cfg=$(_insights_tp_repo_config_path 2>/dev/null)
        if [ -n "$_cfg" ] && [ -f "$_cfg" ]; then
            echo "${INSIGHTS_TICKET_TRACKER_PROJECT_KEYS}" | tr ',' '\n' \
                | _insights_tp_write_keys "$_cfg" 2>/dev/null || true
        fi
    fi
}

_install_persist_insights_env() {
    if command -v insights_persist_env >/dev/null 2>&1; then
        insights_persist_env "${1:?env_file required}"
    fi
}

# Apply Standalone-mode env defaults (gated on SKIP_SSO_PROMPT). Also
# called from scripts/upgrade.sh so new defaults added in later releases
# reach existing installs on upgrade.
_install_apply_standalone_defaults() {
    if [ "${SKIP_SSO_PROMPT:-false}" = "true" ]; then
        : "${MCP_TRANSPORT:=https}"
        : "${MCP_AUTO_INSTALL:=true}"
        : "${BITOARCH_AUTORECOVERY:=true}"
        export MCP_TRANSPORT MCP_AUTO_INSTALL BITOARCH_AUTORECOVERY
    fi
}

# Persist install-mode flags to .env-bitoarch so subsequent invocations
# see them via the install-flag predicates. Idempotent. Also called from
# scripts/upgrade.sh so any flags added during upgrade survive across runs.
_install_persist_mode_flags() {
    local env_file
    env_file=$(get_config_file 2>/dev/null)
    [ -n "$env_file" ] && [ -f "$env_file" ] || return 0
    local flag
    for flag in SKIP_SSO_PROMPT AUTO_GENERATE_MCP_TOKEN COMPACT_INSTALL_PROGRESS BITOARCH_AUTORECOVERY; do
        [ "${!flag:-}" = "true" ] || continue
        grep -q "^${flag}=" "$env_file" 2>/dev/null || \
            echo "${flag}=true" >> "$env_file"
    done
}


# Idempotent: safe to re-invoke. Existing .env-bitoarch skips credential
# prompts and triggers a re-deploy.
install_run() {
    local yaml_config
    yaml_config="$(get_install_yaml_file)"
    while [ $# -gt 0 ]; do
        case "$1" in
            --config)    yaml_config="$2"; shift 2 ;;
            --config=*)  yaml_config="${1#--config=}"; shift ;;
            *)           shift ;;
        esac
    done

    _install_ensure_yaml_exists "$yaml_config"
    _install_apply_yaml_if_present "$yaml_config"

    # Expose the resolved install.yaml path so setup.sh can offer the
    # Standard/Guided quick-configuration choice under its QUICK CONFIGURATION
    # header on the fresh-install path (honoring a --config override). The choice
    # itself lives in setup.sh's credentials section, not here, so it renders as
    # part of that section and only on a fresh install.
    export BITOARCH_INSTALL_YAML_FILE="$yaml_config"

    _install_apply_standalone_defaults

    if command -v restart_policy_migrate >/dev/null 2>&1; then
        restart_policy_migrate || true
    fi

    # Pre-compose-up cert provisioning. Self-gates on MCP_TRANSPORT=https so
    # Enterprise installs are unaffected (HOST_MCP_CERT_DIR stays unset, compose
    # uses its default mount). Without this, the first docker-compose-up in
    # setup.sh's main runs without HOST_MCP_CERT_DIR + XMCP_INTERNAL_PORT, the
    # provider mounts an empty cert dir and crashes with EACCES on /opt/certs.
    if command -v mcp_cert_prepare_for_compose >/dev/null 2>&1; then
        mcp_cert_prepare_for_compose >/dev/null 2>&1 || true
    fi

    # shellcheck disable=SC1091
    source "${SCRIPT_DIR}/setup.sh"

    # Closing order is owned HERE (not by setup.sh main): plugin offer first,
    # then the MCP + Next Steps block — standalone right before the MCP
    # installer, enterprise effectively last (the installer is a no-op there).
    BITOARCH_DEFER_SUCCESS_BLOCK=1
    main "$@"
    local rc=$?
    BITOARCH_DEFER_SUCCESS_BLOCK=0

    # Install + configure any plugins declared in install.yaml /
    # offer the catalog. Runs after the base is healthy so plugin deps/DB are
    # available; best-effort and a no-op when nothing is declared. Rendered
    # BEFORE the MCP + Next Steps closing so the closing isn't buried mid-flow.
    if [ "$rc" -eq 0 ]; then
        local _install_libdir
        _install_libdir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
        # shellcheck source=/dev/null
        . "${_install_libdir}/plugin/preseed.sh" 2>/dev/null || true
        if command -v plugin_setup_phase >/dev/null 2>&1; then
            # SETUP_MODE (set by main's repo-config step) gates the interactive offer to AUTO mode.
            plugin_setup_phase "$yaml_config" "${SETUP_MODE:-}" || true
        else
            command -v log_silent >/dev/null 2>&1 && log_silent "plugin phase skipped: preseed.sh not loadable from ${_install_libdir}/plugin" || true
        fi
    fi

    # Checkpoint install.yaml as applied: env and yaml agree at install end, so
    # a later `restart --force` re-applies the yaml only if the operator edits it
    # (interactive reconfigures of insights/Jira keys survive).
    if [ "$rc" -eq 0 ] && command -v install_yaml_record_applied >/dev/null 2>&1; then
        install_yaml_record_applied "$(get_config_file 2>/dev/null)" || true
    fi

    # Deferred closing (MCP Server + Next Steps): after the plugin phase, right
    # before the coding-agent registration below.
    if [ "$rc" -eq 0 ] && command -v display_success >/dev/null 2>&1; then
        display_success
    fi

    # Coding-agent auto-registration runs only after a successful install
    # (services up + .env-bitoarch finalised). mcp_installer_run is itself
    # gated on MCP_AUTO_INSTALL + MCP_USER_EMAIL, so it is a no-op on
    # Enterprise / opt-out paths.
    if [ "$rc" -eq 0 ] && command -v mcp_installer_run >/dev/null 2>&1; then
        mcp_installer_run || true
    fi

    if [ "$rc" -eq 0 ] && command -v node_trust_install >/dev/null 2>&1; then
        node_trust_install || true
    fi

    if [ "$rc" -eq 0 ] && command -v cert_cron_install >/dev/null 2>&1; then
        cert_cron_install || true
    fi

    if [ "$rc" -eq 0 ] && command -v autostart_install >/dev/null 2>&1; then
        autostart_install || true
    fi

    # Re-run on fresh installs: .env-bitoarch did not exist before main, so
    # the earlier pre-main call was a no-op. After main creates it, write
    # the one-time marker so a customer who later opts back to on-failure:3
    # is not re-migrated on the next install_run.
    if [ "$rc" -eq 0 ] && command -v restart_policy_migrate >/dev/null 2>&1; then
        restart_policy_migrate || true
    fi

    # Persist on any rc so a partial install still carries markers for
    # `bitoarch --help` gating.
    _install_persist_mode_flags
    # install.yaml is operator-owned: the installer reads it but never writes
    # back to it, so the user's file (comments, formatting, exact values) is
    # left exactly as authored.
    return "$rc"
}
