#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
# Bito's AI Architect CLI - Manager Adapter
# Provides manager_sync_simple (used by index-repos) and manager_status (used by index-status)

# Source http-client for K8s port-forward support
if [ -z "$SCRIPT_DIR" ]; then
    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && cd ../.. && pwd)"
fi
source "${SCRIPT_DIR}/scripts/lib/http-client.sh" 2>/dev/null || true
source "${SCRIPT_DIR}/scripts/lib/output-fields.sh" 2>/dev/null || true

# Ensure manager service is accessible (handles K8s port-forward automatically)
ensure_manager_service_accessible() {
    # Get port from environment
    local MANAGER_PORT="${CIS_MANAGER_EXTERNAL_PORT:-5002}"
    
    # Ensure service is accessible (no-op for Docker, sets up port-forward for K8s)
    ensure_service_accessible "ai-architect-manager" "$MANAGER_PORT" 2>/dev/null || true
}

# Normalize and validate a --mode value into _MANAGER_INDEX_MODE.
#
# The result comes back through a global rather than stdout so the error messages
# below reach the terminal the same way every other error in this file does. Under
# command substitution they needed >&2 to avoid being captured, which left
# `bitoarch ... 2>/dev/null` silently discarding exactly this validation.
#
# "full" is rejected explicitly rather than as a generic unknown: it is the word a
# user reading the pipeline internals reaches for, and it means something else
# there (repo-level and cross-repo full indexing are separate decisions).
_MANAGER_INDEX_MODE=""
_manager_normalize_index_mode() {
    local raw
    raw=$(printf '%s' "${1:-}" | tr '[:upper:]' '[:lower:]')
    _MANAGER_INDEX_MODE=""
    case "$raw" in
        force|incremental)
            _MANAGER_INDEX_MODE="$raw"
            return 0
            ;;
        full)
            print_error "--mode full is not valid; use --mode force to rebuild an index"
            return 1
            ;;
        "")
            print_error "--mode requires a value: force or incremental"
            return 1
            ;;
        *)
            print_error "--mode must be force or incremental (got: ${raw})"
            return 1
            ;;
    esac
}

# Build the sync-workspace request body. Emits nothing when there is nothing to
# send, so a plain `index-repos` keeps posting with no body exactly as before.
#
# jq is a hard requirement, as it already is elsewhere in this file and in every
# other request builder across these scripts.
# Returns the body through _MANAGER_SYNC_BODY rather than stdout, and reports
# failure through its exit status. Emitting it on stdout meant a caller had to
# capture that stdout, which then swallowed anything print_error wrote — and
# print_error is not reliably a stderr function here: cli-core defines it with
# >&2, unified-log-manager redefines it without. With jq missing, the resulting
# capture sent "\x1b[0;31m✗\x1b[0m jq is required ..." as the JSON request body
# and the server rejected it with a message about an invalid character.
_manager_build_sync_body() {
    _MANAGER_SYNC_BODY=""
    local mode="$1"
    shift

    if [ -z "$mode" ] && [ $# -eq 0 ]; then
        return 0
    fi
    if ! command -v jq >/dev/null 2>&1; then
        print_error "jq is required to send --mode or --repo"
        return 1
    fi

    local repos_json='[]'
    if [ $# -gt 0 ]; then
        repos_json=$(printf '%s\n' "$@" | jq -R . | jq -s .)
    fi
    _MANAGER_SYNC_BODY=$(jq -nc --arg mode "$mode" --argjson repos "$repos_json" \
        '(if $mode == "" then {} else {mode: $mode} end)
         + (if ($repos | length) == 0 then {} else {repos: $repos} end)')
}

# Simple repository indexing (with optional mode, repo selection and only-new-repos)
manager_sync_simple() {
    local only_new_repos="false"
    local index_mode=""
    local assume_yes="false"
    local repos=()

    # Parse flags
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --help|-h)
                cat << 'EOF'
USAGE:
  bitoarch index-repos [OPTIONS]

DESCRIPTION:
  Trigger repository indexing. This command initiates the indexing
  process for all configured repositories. Indexing typically takes 3-10 minutes
  per repository depending on size.

  With no options the system decides per repository whether it needs a first
  full index or an incremental update. Use --mode only to override that.

OPTIONS:
  --mode <mode>     Override the automatic decision:
                      force        rebuild the index from scratch, whether or
                                   not one already exists
                      incremental  index only what changed; repositories with
                                   no existing index are skipped and listed
  --repo <ns>       Limit the run to this repository (repeatable). Omit to
                    cover the whole workspace
  --only-new-repos  Index only new repositories (skip incremental indexing
                    for existing repos that already have commits indexed)
  --yes, -y         Skip the confirmation prompt for a workspace-wide rebuild
  --help, -h        Show this help

EXAMPLES:
  # Start indexing all configured repositories (default behavior)
  bitoarch index-repos

  # Rebuild one repository from scratch
  bitoarch index-repos --mode force --repo myorg/my-repo

  # Rebuild two repositories from scratch
  bitoarch index-repos --mode force --repo myorg/api --repo myorg/web

  # Rebuild the entire workspace from scratch (slow, re-runs AI analysis)
  bitoarch index-repos --mode force

  # Update one already-indexed repository from its latest commits
  bitoarch index-repos --mode incremental --repo myorg/my-repo

  # Index only newly added repositories, skip incremental updates for existing repos
  bitoarch index-repos --only-new-repos

  # Check indexing progress
  bitoarch index-status

NOTES:
  - Requires BITO_API_KEY to be configured in environment
  - Repositories must be configured first (use 'bitoarch add-repo')
  - One indexing job runs per workspace at a time. --repo limits which
    repositories are indexed; it does not let two runs proceed in parallel
  - --mode incremental only covers repositories that already have an index.
    Any that do not are skipped and listed in the output; run without
    --mode to create their first index
  - --mode force on the whole workspace re-runs AI analysis for every
    repository and is the slowest operation available
  - --mode cannot be combined with --only-new-repos
EOF
                return 0
                ;;
            --only-new-repos)
                only_new_repos="true"
                shift
                ;;
            --mode)
                _manager_normalize_index_mode "${2:-}" || return 1
                index_mode="$_MANAGER_INDEX_MODE"
                shift 2
                ;;
            --mode=*)
                _manager_normalize_index_mode "${1#*=}" || return 1
                index_mode="$_MANAGER_INDEX_MODE"
                shift
                ;;
            --repo|--repository)
                if [ -z "${2:-}" ]; then
                    print_error "--repo requires a repository namespace (e.g. myorg/my-repo)"
                    return 1
                fi
                repos+=("$2")
                shift 2
                ;;
            --repo=*|--repository=*)
                if [ -z "${1#*=}" ]; then
                    print_error "--repo requires a repository namespace (e.g. myorg/my-repo)"
                    return 1
                fi
                repos+=("${1#*=}")
                shift
                ;;
            --yes|-y)
                assume_yes="true"
                shift
                ;;
            -*)
                print_error "Unknown option: $1"
                print_info "Run bitoarch index-repos --help for the accepted options."
                return 1
                ;;
            *)
                print_error "Unexpected argument: $1"
                print_info "Repositories are named with --repo <namespace>."
                return 1
                ;;
        esac
    done

    # Reject locally what the server would reject anyway, so the user finds out
    # before a round trip.
    if [ -n "$index_mode" ] && [ "$only_new_repos" = "true" ]; then
        print_error "--mode and --only-new-repos cannot be used together"
        print_info "--only-new-repos skips repositories that are already indexed, which is the opposite of what --mode ${index_mode} asks for."
        return 1
    fi
    if [ ${#repos[@]} -gt 0 ] && [ "$only_new_repos" = "true" ]; then
        print_error "--repo and --only-new-repos cannot be used together"
        print_info "--only-new-repos skips repositories that are already indexed, which is every repository you named."
        return 1
    fi

    if [ ${#repos[@]} -gt 0 ]; then
        local repo
        if type _is_valid_repo_namespace >/dev/null 2>&1; then
            for repo in "${repos[@]}"; do
                if ! _is_valid_repo_namespace "$repo"; then
                    print_error "Invalid repository namespace: ${repo}"
                    print_info "Expected <org>/<repo>, for example myorg/my-repo"
                    return 1
                fi
            done
        fi
    fi

    # A workspace-wide rebuild re-runs AI analysis for every repository, so make it
    # a deliberate choice. Scoped rebuilds are cheap enough not to ask.
    if [ "$index_mode" = "force" ] && [ ${#repos[@]} -eq 0 ] && [ "$assume_yes" != "true" ]; then
        echo ""
        print_warning "This rebuilds the index for every configured repository from scratch."
        print_info "To rebuild just one, use: bitoarch index-repos --mode force --repo <namespace>"
        echo ""
        if [ ! -t 0 ]; then
            print_error "Refusing to start a workspace-wide rebuild without confirmation."
            print_info "Re-run with --yes to confirm non-interactively."
            return 1
        fi
        local _confirm_rebuild=""
        read -r -p "Rebuild the whole workspace? [y/N]: " _confirm_rebuild
        case "$_confirm_rebuild" in
            [Yy]|[Yy][Ee][Ss]) ;;
            *)
                print_info "Cancelled. Nothing was indexed."
                return 1
                ;;
        esac
    fi

    # Get BITO API key from environment
    if [ -z "$BITO_API_KEY" ]; then
        print_error "BITO_API_KEY not found in environment"
        return 1
    fi
    
    # Get manager external port from environment (default to 5002)
    local MANAGER_PORT="${CIS_MANAGER_EXTERNAL_PORT:-5002}"
    local MANAGER_URL="${CIS_MANAGER_URL:-http://localhost:${MANAGER_PORT}}"
    
    # Ensure manager service is accessible (sets up port-forward for K8s if needed)
    ensure_manager_service_accessible
    
    # Guard: refuse to start indexing while insights analysis is in progress.
    local _ins_guard=""
    _ins_guard=$(curl -s --connect-timeout 3 --max-time 10 \
        -H "Authorization: Bearer ${BITO_API_KEY}" \
        "${MANAGER_URL}/api/v3/insights/status" 2>/dev/null) || true
    if [ -n "$_ins_guard" ] && command -v jq >/dev/null 2>&1; then
        local _ins_state
        _ins_state=$(echo "$_ins_guard" | jq -r '.status // empty' 2>/dev/null) || true
        if [ "$_ins_state" = "running" ]; then
            print_error "Insights analysis is currently in progress."
            echo -e "  Indexing cannot run while insights analysis is active."
            echo -e "  Wait for it to complete, or stop it with:"
            echo -e "    ${YELLOW}bitoarch stop-indexing${NC}"
            return 1
        fi
    fi

    # Build API endpoint with query parameter if needed
    local api_endpoint="${MANAGER_URL}/api/v3/sync-workspace"
    if [ "$only_new_repos" = "true" ]; then
        api_endpoint="${api_endpoint}?only_new_repos=true"
        print_info "Initiating indexing for new repositories only..."
    elif [ -n "$index_mode" ] || [ ${#repos[@]} -gt 0 ]; then
        local _scope_label="the whole workspace"
        [ ${#repos[@]} -gt 0 ] && _scope_label="${repos[*]}"
        case "$index_mode" in
            force)       print_info "Rebuilding from scratch: ${_scope_label}..." ;;
            incremental) print_info "Applying incremental updates: ${_scope_label}..." ;;
            *)           print_info "Initiating repository indexing: ${_scope_label}..." ;;
        esac
    else
        print_info "Initiating repository indexing..."
    fi

    # Only sent when a mode or a repository selection was given; a plain run still
    # posts with no body, exactly as before.
    local request_body=""
    if ! _manager_build_sync_body "$index_mode" "${repos[@]+"${repos[@]}"}"; then
        return 1
    fi
    request_body="$_MANAGER_SYNC_BODY"

    # Make API call directly with curl
    local curl_args=(-s -w '\n%{http_code}' -X POST -H "Authorization: $BITO_API_KEY")
    if [ -n "$request_body" ]; then
        curl_args+=(-H "Content-Type: application/json" -d "$request_body")
    fi
    local response=$(curl "${curl_args[@]}" "${api_endpoint}" 2>/dev/null)

    # Extract HTTP code from last line
    local http_code=$(echo "$response" | tail -1)
    local body=$(echo "$response" | sed '$d')
    
    # Use field-based rendering
    if [ "$http_code" -ge 200 ] && [ "$http_code" -lt 300 ]; then
        echo ""
        echo -e "${GREEN}✅ Repository Indexing Initiated${NC}"
        echo ""
        
        # Extract message from response
        if command -v jq >/dev/null 2>&1; then
            local message=$(echo "$body" | jq -r '.message // "repository enqueued for processing"')
            echo -e "${BLUE}Status:${NC}"
            echo "  • $message"

            # An incremental run leaves out repositories with no existing index to
            # diff against. Name them so "why did only some of my repos run" answers
            # itself. Rendered unconditionally — see the note below the field check
            # for why the mode does not need testing here.
            local skipped
            skipped=$(echo "$body" | jq -r '.skipped_repositories[]?' 2>/dev/null)
            if [ -n "$skipped" ]; then
                echo ""
                # cis-manager populates skipped_repositories only for an
                # incremental override — the field is set inside the branch that
                # requires a mode, and only mode=incremental can skip anything.
                # An earlier version gated this wording on the mode as well,
                # which read as defensive but could never change what rendered.
                print_warning "Skipped — no existing index to update:"
                echo "$skipped" | sed 's/^/  • /'
                print_info "Index these first with: bitoarch index-repos (no --mode)"
            fi
        else
            echo "$body"
        fi

        # Show indexing information
        echo ""
        echo -e "${CYAN}${BOLD}📊 Note:${NC}"
        echo -e "${BOLD}Indexing has started, and will take approximately 3-10 minutes per repo. Smaller repos take less time${NC}"
        echo -e "${BOLD}You can check the status of your indexing by typing ${YELLOW}bitoarch index-status${NC}${BOLD} from your CLI${NC}"
        
        return 0
    else
        # A 409 used to mean one thing: a run is already going. It now also covers
        # "--mode incremental was asked for and none of these repos has an index",
        # where nothing is running and stop-indexing is the wrong advice. Only claim
        # a run is in progress when the server's message actually says so; otherwise
        # fall through so the server's own explanation reaches the user.
        if [ "$http_code" = "409" ]; then
            local _conflict_msg=""
            if command -v jq >/dev/null 2>&1; then
                _conflict_msg=$(echo "$body" | jq -r '.message // ""' 2>/dev/null)
            fi
            case "$_conflict_msg" in
                *"in progress"*|*"already"*|"")
                    print_warning "Indexing is already in progress for this workspace."
                    print_info "Use bitoarch stop-indexing to cancel, then retry."
                    return 1
                    ;;
                *)
                    # A conflict that is not a running workflow. The server rejected the
                    # request before starting anything, so nothing failed and nothing is
                    # running: "Failed" overstates it, and the wait-for-the-current-run
                    # note below would be actively wrong. Render the server's own
                    # explanation and stop here.
                    render_command_error "Repository Indexing Not Possible" "$body" "$MANAGER_SYNC_ERROR_OUTPUT"
                    return 1
                    ;;
            esac
        fi

        render_command_error "Repository Indexing Failed" "$body" "$MANAGER_SYNC_ERROR_OUTPUT"
        
        # Special handling for QUEUE_FULL error
        if command -v jq >/dev/null 2>&1; then
            local error_type=$(echo "$body" | jq -r '.error // ""' 2>/dev/null)
            if [ "$error_type" = "QUEUE_FULL" ] || [ "$error_type" = "CONFLICT" ]; then
                echo -e "${BLUE}Note:${NC}"
                echo "  Indexing is already in progress for your current repositories."
                echo "  New repositories can only be indexed after the ongoing process completes."
                echo ""
                echo -e "${YELLOW}Next Steps:${NC}"
                echo -e "  1. Wait for current indexing to finish (check with: ${YELLOW}bitoarch index-status${NC})"
                echo -e "  2. Once complete, run ${YELLOW}bitoarch index-repos${NC} again to index newly added repos"
                echo ""
            fi
        fi
        
        return 1
    fi
}

manager_trigger_insights() {
    if [ -z "$BITO_API_KEY" ]; then
        print_error "BITO_API_KEY not found in environment"
        return 1
    fi

    local MANAGER_PORT="${CIS_MANAGER_EXTERNAL_PORT:-5002}"
    local MANAGER_URL="${CIS_MANAGER_URL:-http://localhost:${MANAGER_PORT}}"

    ensure_manager_service_accessible

    # Guard: refuse to start insights while another insights run is in progress.
    local _ins_guard=""
    _ins_guard=$(curl -s --connect-timeout 3 --max-time 10 \
        -H "Authorization: Bearer ${BITO_API_KEY}" \
        "${MANAGER_URL}/api/v3/insights/status" 2>/dev/null) || true
    if [ -n "$_ins_guard" ] && command -v jq >/dev/null 2>&1; then
        local _ins_state
        _ins_state=$(echo "$_ins_guard" | jq -r '.status // empty' 2>/dev/null) || true
        if [ "$_ins_state" = "running" ]; then
            echo -e "${YELLOW}Insights analysis is already in progress for this workspace.${NC}"
            echo -e "  Check progress with: ${YELLOW}bitoarch insights status${NC}"
            echo -e "  To cancel and restart: ${YELLOW}bitoarch stop-indexing${NC}"
            return 1
        fi
    fi

    # Guard: check indexing state — refuse if running, warn if never completed.
    local _idx_resp
    _idx_resp=$(curl -s --max-time 10 \
        -H "Authorization: Bearer ${BITO_API_KEY}" \
        "${MANAGER_URL}/api/v3/indexing-status?verbose=true" 2>/dev/null) || true
    if [ -n "$_idx_resp" ] && command -v jq >/dev/null 2>&1; then
        local _idx_state _idx_total _idx_completed
        _idx_state=$(echo "$_idx_resp" | jq -r '.status // "unknown"' 2>/dev/null) || true
        _idx_total=$(echo "$_idx_resp" | jq -r '.total_repos // 0' 2>/dev/null) || true
        _idx_completed=$(echo "$_idx_resp" | jq -r '.completed_repos // 0' 2>/dev/null) || true
        case "$_idx_state" in
            running|indexing|in_progress|pausing|resuming|stopping)
                print_error "Indexing is currently in progress (state: ${_idx_state})."
                echo -e "  Insights analysis cannot run while indexing is active."
                echo -e "  Wait for indexing to complete, or stop it with:"
                echo -e "    ${YELLOW}bitoarch stop-indexing${NC}"
                return 1
                ;;
            failed|error)
                # Per-repo failures live in .repositories[].details (verbose
                # response), not a top-level array. Surface each failed repo and
                # which indexing event failed (e.g. "clone" for bad git creds).
                local _fail_details
                _fail_details=$(echo "$_idx_resp" | jq -r '
                    (.repositories // [])[]
                    | select((.details.outcome // "") == "failure")
                    | "  - \(.repo_name // .details.repo_name // "unknown"): "
                      + ((.details.failed_events // []) | if length == 0 then "indexing failed" else "failed at " + join(", ") end)
                ' 2>/dev/null) || true
                if [ "${_idx_completed:-0}" -gt 0 ] 2>/dev/null; then
                    # Partial failure: some repos indexed. Warn and list the failures,
                    # but proceed — insights runs over the successfully-indexed subset.
                    print_warning "Some repositories failed to index; insights will run over the ${_idx_completed} successfully-indexed repo(s)."
                    if [ -n "$_fail_details" ]; then
                        echo -e "  Failed repositories:"
                        echo "$_fail_details"
                    fi
                    echo -e "  To include the rest, fix and re-run: ${YELLOW}bitoarch index-repos${NC}"
                else
                    # Nothing indexed successfully — there is no subset to analyze.
                    print_error "Repository indexing failed."
                    echo -e "  Insights analysis requires successfully indexed repository data."
                    if [ -n "$_fail_details" ]; then
                        echo -e "  Failed repositories:"
                        echo "$_fail_details"
                    fi
                    echo -e "  Fix the issue and re-run indexing:"
                    echo -e "    ${YELLOW}bitoarch index-repos${NC}"
                    return 1
                fi
                ;;
            *)
                if [ "${_idx_total:-0}" = "0" ] || [ "${_idx_completed:-0}" = "0" ]; then
                    print_error "Repository indexing has not completed yet."
                    echo -e "  Insights analysis requires indexed repository data."
                    echo -e "  Run indexing first:"
                    echo -e "    ${YELLOW}bitoarch index-repos${NC}"
                    return 1
                fi
                ;;
        esac
    fi

    local force="false"
    if [[ "${1:-}" == "--force" ]]; then
        force="true"
        print_info "Triggering insights analysis (force full re-analysis)..."
    else
        print_info "Triggering insights analysis..."
    fi

    local response
    response=$(curl -s -w '\n%{http_code}' \
        -X POST \
        -H "Authorization: Bearer $BITO_API_KEY" \
        -H "Content-Type: application/json" \
        -d "{\"force\": $force}" \
        "${MANAGER_URL}/api/v3/insights" 2>/dev/null)

    local http_code
    http_code=$(echo "$response" | tail -1)
    local body
    body=$(echo "$response" | sed '$d')

    if [ "$http_code" -ge 200 ] && [ "$http_code" -lt 300 ]; then
        echo ""
        print_success "Insights analysis triggered"
        if command -v jq >/dev/null 2>&1; then
            local msg
            msg=$(echo "$body" | jq -r '.message // "insights workflow started"')
            print_info "$msg"
        fi
        echo ""
        echo -e "This runs in the background. Check progress with:"
        echo -e "  ${YELLOW}bitoarch insights status${NC}"
        return 0
    fi

    if [ "$http_code" = "409" ]; then
        local _msg=""
        if command -v jq >/dev/null 2>&1; then
            _msg=$(echo "$body" | jq -r '.message // ""' 2>/dev/null)
        fi
        if echo "$_msg" | grep -qi 'indexing is currently in progress'; then
            echo -e "${YELLOW}Indexing is currently in progress for this workspace.${NC}"
            echo -e "  Wait for indexing to complete, or stop it with:"
            echo -e "    ${YELLOW}bitoarch stop-indexing${NC}"
        else
            echo -e "${YELLOW}Insights analysis is already in progress for this workspace.${NC}"
            echo -e "Use ${YELLOW}bitoarch stop-indexing${NC} to cancel, then retry."
        fi
        return 1
    fi

    if [ "$http_code" = "404" ]; then
        print_error "Insights features are not enabled. Enable them first:"
        echo -e "  ${YELLOW}bitoarch insights enable git${NC}"
        echo -e "  ${YELLOW}bitoarch insights enable ticket-tracker${NC}"
        return 1
    fi

    print_error "Failed to trigger insights (HTTP ${http_code})"
    [ -n "$body" ] && echo "  $body"
    echo -e "${YELLOW}Next Steps:${NC}"
    echo -e "  1. Check services are running: ${YELLOW}bitoarch status${NC}"
    echo -e "  2. Check insights config:      ${YELLOW}bitoarch insights config${NC}"
    return 1
}

# Get sync status
manager_status() {
    local view_mode="default"
    local repo_filter="all"
    local session_id=""
    local sub_view=""
    local csv_target=""
    local force_csv=false
    local force_table=false
    local watch_interval=""

    # Parse flags
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --help|-h)
                cat << 'HELPEOF'
STATUS COMMAND

USAGE:
  bitoarch index-status [OPTIONS]

DESCRIPTION:
  Get indexing status - the current index, or by index id.

OPTIONS:
  --session <id>        Report a specific index session (default: latest)
  --sessions            List recent index sessions
  --events              Show this session's audit entries
  --failures            Only failed repos, with each errored event and reason
  --in-progress         Only repos still indexing, with the stage running now
  --all                 Print the full table even above the CSV threshold
  --watch [<secs>]      Refresh the view every <secs> (default: 60, min: 5)
  --watcher [<secs>]    Alias for --watch
  --csv [<file>]        Write repo-level rows to CSV instead of the terminal
                        (with --events, exports that session's audit rows)
  --raw                 Show raw unfiltered JSON response
  --json                Machine-readable filtered JSON output
  --output json         Same as --json
  --help, -h            Show this help

FLAG COMBINATIONS:
  --failures and --in-progress filter the repo table, and also apply to
  --json / --output json. They cannot be combined with --raw, which is by
  definition the unfiltered payload.
  --csv works with the default repo view and with --events, in the default
  output mode. It is rejected with --sessions, --raw and --json rather than
  being silently ignored.
  --watch repaints the default view, --failures and --in-progress. It is
  rejected with --sessions, --events, --raw, --output json and --csv.
  A watched run never writes a CSV: above the row threshold it shows the
  first rows and a count instead. Stop it with Ctrl+C.

OUTPUT MODES:
  default       Summary, then the per-repo table
  --failures    Failed repos only: repo, stage it stopped at, errored
                events, error code and reason
  --in-progress Unfinished repos only, with the stage each is executing
  --raw         Complete API response (for debugging)
  --output json Filtered JSON for automation/scripting

REPO-LEVEL OUTPUT:
  Up to 25 rows print as a table; more go to a CSV under ~/.bitoarch/reports
  and the path is printed. Use --all for the table, --csv <file> for a path.

EXAMPLES:
  # Quick status check with the repo table
  bitoarch index-status

  # What failed, and why
  bitoarch index-status --failures

  # What is running right now
  bitoarch index-status --in-progress

  # A previous run
  bitoarch index-status --sessions
  bitoarch index-status --session <session-id> --failures

  # Export every repo row
  bitoarch index-status --csv ./index-status.csv

  # Follow an index run live
  bitoarch index-status --watch 60
  bitoarch index-status --in-progress --watch

  # For automation
  bitoarch index-status --output json | jq '.status'
HELPEOF
                return 0
                ;;
            --raw|--verbose)
                view_mode="raw"
                shift
                ;;
            --json)
                view_mode="json"
                shift
                ;;
            --output)
                if [ "$2" = "json" ]; then
                    view_mode="json"
                    shift 2
                else
                    print_error "Unknown output format: $2"
                    return 1
                fi
                ;;
            --session)
                if [ -z "$2" ] || [[ "$2" == --* ]]; then
                    print_error "--session requires a session id"
                    return 1
                fi
                session_id="$2"
                shift 2
                ;;
            --sessions)
                sub_view="sessions"
                shift
                ;;
            --events)
                sub_view="events"
                shift
                ;;
            --failures)
                repo_filter="failures"
                shift
                ;;
            --in-progress)
                repo_filter="in-progress"
                shift
                ;;
            --all)
                force_table=true
                shift
                ;;
            --csv=*)
                force_csv=true
                csv_target="${1#--csv=}"
                if [ -z "$csv_target" ]; then
                    print_error "--csv= requires a file path"
                    return 1
                fi
                shift
                ;;
            --csv)
                force_csv=true
                # An optional path: bare --csv writes to the default location.
                # Any leading dash is a flag, not a filename -- `--csv -h`
                # must show help, not create a file named "-h".
                if [ -n "$2" ] && [[ "$2" != -* ]]; then
                    csv_target="$2"
                    shift 2
                else
                    shift
                fi
                ;;
            --watch=*|--watcher=*)
                watch_interval="${1#*=}"
                if [ -z "$watch_interval" ]; then
                    print_error "--watch= requires a number of seconds"
                    return 1
                fi
                shift
                ;;
            --watch|--watcher)
                # Optional value, same idiom as --csv above: a leading dash is a
                # flag, not an interval, so `--watch --failures` keeps --failures.
                if [ -n "$2" ] && [[ "$2" != -* ]]; then
                    watch_interval="$2"
                    shift 2
                else
                    watch_interval="${WATCH_DEFAULT_INTERVAL_SECS:-60}"
                    shift
                fi
                ;;
            *)
                print_warning "Unknown option: $1"
                shift
                ;;
        esac
    done

    if [ "$repo_filter" != "all" ] && [ "$view_mode" = "raw" ]; then
        print_error "--raw returns the unfiltered API response; it cannot be combined with --${repo_filter}"
        return 1
    fi
    # --csv is a repo-level export. --events has a server-side CSV and is
    # handled below; the rest have nothing to export, and silently accepting
    # the flag while writing no file is worse than refusing it.
    if [ "$force_csv" = "true" ]; then
        case "$sub_view:$view_mode" in
            sessions:*)
                print_error "--csv is not supported with --sessions"
                return 1
                ;;
            *:raw|*:json)
                print_error "--csv cannot be combined with --raw or --output json"
                return 1
                ;;
        esac
    fi

    # --watch drives a live, repainting view. The modes below are either a
    # one-shot dump (--raw, --output json), a different resource (--sessions,
    # --events), or a file export (--csv) -- refusing beats silently ignoring.
    if [ -n "$watch_interval" ]; then
        case "$sub_view:$view_mode" in
            sessions:*)
                print_error "--watch is not supported with --sessions"
                return 1
                ;;
            events:*)
                print_error "--watch is not supported with --events"
                return 1
                ;;
            *:raw)
                print_error "--watch renders a live view; it cannot be combined with --raw"
                return 1
                ;;
            *:json)
                print_error "--watch renders a live view; it cannot be combined with --output json"
                return 1
                ;;
        esac
        if [ "$force_csv" = "true" ]; then
            print_error "--watch cannot be combined with --csv; a watched run writes no CSV"
            return 1
        fi
    fi

    # Get BITO API key from environment
    if [ -z "$BITO_API_KEY" ]; then
        print_error "BITO_API_KEY not found in environment"
        return 1
    fi

    local MANAGER_PORT="${CIS_MANAGER_EXTERNAL_PORT:-5002}"
    local MANAGER_URL="${CIS_MANAGER_URL:-http://localhost:${MANAGER_PORT}}"

    # Ensure manager service is accessible (sets up port-forward for K8s if needed)
    ensure_manager_service_accessible

    case "$sub_view" in
        sessions)
            _manager_render_sessions "$MANAGER_URL" "$view_mode"
            return $?
            ;;
        events)
            _manager_render_events "$MANAGER_URL" "$view_mode" "$session_id" \
                "$force_csv" "$csv_target"
            return $?
            ;;
    esac

    if [ -n "$watch_interval" ]; then
        # A watched run never spills to CSV -- see index_status_emit.
        _INDEX_STATUS_NO_CSV=true
        watch_loop "$watch_interval" "index-status" \
            _manager_status_render_once \
            "$MANAGER_URL" "$view_mode" "$repo_filter" "$session_id" \
            "$csv_target" "$force_csv" "$force_table" "true"
        local watch_rc=$?
        _INDEX_STATUS_NO_CSV=false
        return $watch_rc
    fi

    _manager_status_render_once \
        "$MANAGER_URL" "$view_mode" "$repo_filter" "$session_id" \
        "$csv_target" "$force_csv" "$force_table" "false"
    return $?
}

# Fetch and render exactly one index-status snapshot.
#
# Split out of manager_status so the same render can be called once or driven by
# watch_loop. Takes every resolved parameter explicitly rather than reading the
# caller's locals, so it works unchanged inside the loop's output capture.
#
# quiet suppresses the "Fetching..." line, which would otherwise be baked into
# every captured snapshot under a watch.
_manager_status_render_once() {
    local manager_url="$1" view_mode="$2" repo_filter="$3" session_id="$4"
    local csv_target="$5" force_csv="$6" force_table="$7" quiet="$8"

    # Re-checked every call: a Kubernetes port-forward can die mid-watch, and
    # this is a no-op on Docker and when the forward is already alive.
    ensure_manager_service_accessible

    # Verbose is what carries the per-repo details every view below needs.
    local endpoint="${manager_url}${CIS_MANAGER_INDEXING_STATUS_PATH}?verbose=true"
    [ -n "$session_id" ] && endpoint="${endpoint}&session_id=$(_manager_urlencode "$session_id")"

    if [ "$view_mode" != "json" ] && [ "$quiet" != "true" ]; then
        print_info "Fetching index status..."
    fi

    local body
    if ! _manager_api_get "$endpoint" "$view_mode"; then
        return 1
    fi
    body="$_MANAGER_API_BODY"

    # Render based on view mode
    case "$view_mode" in
        raw)
            render_manager_status_raw "$body"
            ;;
        json)
            render_manager_status_json "$body" "$repo_filter"
            ;;
        *)
            if [ "$repo_filter" != "all" ]; then
                render_index_status_filtered "$body" "$repo_filter" \
                    "$csv_target" "$force_csv" "$force_table"
            else
                _INDEX_STATUS_CSV_TARGET="$csv_target"
                _INDEX_STATUS_FORCE_CSV="$force_csv"
                _INDEX_STATUS_FORCE_TABLE="$force_table"
                render_manager_status_default "$body"
                _INDEX_STATUS_CSV_TARGET=""
                _INDEX_STATUS_FORCE_CSV=false
                _INDEX_STATUS_FORCE_TABLE=false
            fi
            ;;
    esac

    return 0
}

# Percent-encode a value for use in a query string. Session ids are UUIDs, so
# this only has to defend against a caller passing something unexpected.
_manager_urlencode() {
    printf '%s' "$1" | sed -e 's/[^A-Za-z0-9._~-]/_/g'
}

# GET an endpoint, handling connection and HTTP errors uniformly.
# On success sets _MANAGER_API_BODY; on failure renders the error and returns 1.
_manager_api_get() {
    local endpoint="$1" view_mode="$2"
    _MANAGER_API_BODY=""

    local response curl_exit
    response=$(curl -s -w '\n%{http_code}' --max-time 30 \
        -X GET \
        -H "Authorization: Bearer ${BITO_API_KEY}" \
        "$endpoint" 2>/dev/null)
    curl_exit=$?

    if [ $curl_exit -ne 0 ]; then
        if [ "$view_mode" = "json" ]; then
            echo '{"error": "connection_failed", "message": "Failed to connect to CIS Manager"}'
        else
            render_manager_status_error "connection_failed" "Failed to connect to CIS Manager" "$endpoint"
        fi
        return 1
    fi

    local http_code body
    http_code=$(echo "$response" | tail -1)
    body=$(echo "$response" | sed '$d')

    if [ "$http_code" -lt 200 ] || [ "$http_code" -ge 300 ]; then
        if [ "$view_mode" = "json" ]; then
            echo "{\"error\": \"http_$http_code\", \"message\": \"API request failed\"}"
        elif [ "$http_code" = "404" ] && echo "$body" | grep -q "SESSION_NOT_FOUND"; then
            print_error "No such index session for this workspace."
            echo -e "  Run ${YELLOW}bitoarch index-status --sessions${NC} to list sessions."
        else
            render_manager_status_error "$http_code" "$body" "$endpoint"
        fi
        return 1
    fi

    _MANAGER_API_BODY="$body"
    return 0
}

# --sessions: list the workspace's recent index sessions.
_manager_render_sessions() {
    local manager_url="$1" view_mode="$2"
    local endpoint="${manager_url}${CIS_MANAGER_INDEX_SESSIONS_PATH}"

    [ "$view_mode" != "json" ] && print_info "Fetching index sessions..."

    if ! _manager_api_get "$endpoint" "$view_mode"; then
        return 1
    fi

    case "$view_mode" in
        # render_manager_status_raw prefixes a human header, which makes the
        # documented machine-readable mode unparseable; emit the payload alone.
        json) _manager_emit_json "$_MANAGER_API_BODY" ;;
        raw)  render_manager_status_raw "$_MANAGER_API_BODY" ;;
        *)    render_index_sessions "$_MANAGER_API_BODY" ;;
    esac
}

# --events: show one session's audit entries. Without --session, the latest
# session is resolved from the status endpoint first, because the events
# endpoint is addressed by session id.
_manager_render_events() {
    local manager_url="$1" view_mode="$2" session_id="$3"
    local force_csv="${4:-false}" csv_target="${5:-}"

    if [ -z "$session_id" ]; then
        if ! _manager_api_get "${manager_url}${CIS_MANAGER_INDEXING_STATUS_PATH}" "$view_mode"; then
            return 1
        fi
        session_id=$(echo "$_MANAGER_API_BODY" | jq -r '.session_id // ""' 2>/dev/null)
        if [ -z "$session_id" ]; then
            print_error "No index session found for this workspace yet."
            return 1
        fi
    fi

    local encoded endpoint
    encoded=$(_manager_urlencode "$session_id")
    endpoint="${manager_url}${CIS_MANAGER_INDEX_SESSIONS_PATH}/${encoded}/events"

    # The manager already renders these rows as CSV (Go encoding/csv, with the
    # same columns), so export by asking for that format rather than
    # re-serialising the JSON here.
    if [ "$force_csv" = "true" ]; then
        _manager_export_events_csv "${endpoint}?format=csv" "$session_id" "$csv_target"
        return $?
    fi

    [ "$view_mode" != "json" ] && print_info "Fetching session events..."

    if ! _manager_api_get "$endpoint" "$view_mode"; then
        return 1
    fi

    case "$view_mode" in
        json) _manager_emit_json "$_MANAGER_API_BODY" ;;
        raw)  render_manager_status_raw "$_MANAGER_API_BODY" ;;
        *)    render_index_session_events "$_MANAGER_API_BODY" ;;
    esac
}

# Emit a payload as bare JSON, with no header or progress text, so the output
# can be piped straight into jq.
_manager_emit_json() {
    if command -v jq >/dev/null 2>&1; then
        echo "$1" | jq . | _index_status_redact
    else
        printf '%s\n' "$1" | _index_status_redact
    fi
}

# Pause indexing (DEPRECATED - not supported in v3)
manager_pause_indexing() {
    echo ""
    echo -e "${YELLOW}Pause/resume is not available in the v3 workflow engine.${NC}"
    echo ""
    echo -e "${BLUE}Alternatives:${NC}"
    echo -e "  Stop indexing:     ${YELLOW}bitoarch stop-indexing${NC}"
    echo -e "  Restart indexing:  ${YELLOW}bitoarch index-repos${NC}"
    echo ""
    return 1
}

# Resume indexing (DEPRECATED - not supported in v3)
manager_resume_indexing() {
    echo ""
    echo -e "${YELLOW}Pause/resume is not available in the v3 workflow engine.${NC}"
    echo ""
    echo -e "${BLUE}Alternatives:${NC}"
    echo -e "  Stop indexing:     ${YELLOW}bitoarch stop-indexing${NC}"
    echo -e "  Restart indexing:  ${YELLOW}bitoarch index-repos${NC}"
    echo ""
    return 1
}

# Stop indexing
manager_stop_indexing() {
    # Check for help first
    if [ "$1" = "--help" ] || [ "$1" = "-h" ]; then
        cat << 'EOF'
USAGE:
  bitoarch stop-indexing

DESCRIPTION:
  Completely stop the current indexing process. This terminates all
  indexing operations and clears the indexing queue. Unlike pause,
  this action cannot be resumed and will lose current progress.

OPTIONS:
  --help, -h    Show this help

EXAMPLES:
  # Stop indexing completely
  bitoarch stop-indexing

  # Start fresh indexing later
  bitoarch index-repos

  # Check status
  bitoarch index-status

NOTES:
  - Requires BITO_API_KEY to be configured in environment
  - This action cannot be undone - progress will be lost
  - Use 'pause-indexing' if you want to resume later
  - After stopping, use 'index-repos' to start fresh
EOF
        return 0
    fi

    # Get BITO API key from environment
    if [ -z "$BITO_API_KEY" ]; then
        print_error "BITO_API_KEY not found in environment"
        return 1
    fi

    # Get manager external port from environment (default to 5002)
    local MANAGER_PORT="${CIS_MANAGER_EXTERNAL_PORT:-5002}"
    local MANAGER_URL="${CIS_MANAGER_URL:-http://localhost:${MANAGER_PORT}}"

    # Ensure manager service is accessible (sets up port-forward for K8s if needed)
    ensure_manager_service_accessible

    print_info "Stopping indexing process..."

    # Make API call directly with curl
    local response=$(curl -s -w '\n%{http_code}' \
        -X POST \
        -H "Authorization: Bearer ${BITO_API_KEY}" \
        "${MANAGER_URL}/api/v3/indexing/stop" 2>/dev/null)

    # Extract HTTP code from last line
    local http_code=$(echo "$response" | tail -1)
    local body=$(echo "$response" | sed '$d')

    # Check for success (200 status code)
    if [ "$http_code" = "200" ]; then
        echo ""

        local message=""
        if command -v jq >/dev/null 2>&1; then
            message=$(echo "$body" | jq -r '.message // ""')
        fi

        case "$message" in
            *indexing*insights*)
                echo -e "${GREEN}✅ Indexing and Insights Stopped${NC}" ;;
            *insights*)
                echo -e "${GREEN}✅ Insights Stopped${NC}" ;;
            *)
                echo -e "${GREEN}✅ Indexing Stopped${NC}" ;;
        esac

        echo ""
        echo -e "${CYAN}${BOLD}📊 Next Steps:${NC}"
        echo -e "${BOLD}• Start fresh indexing: ${YELLOW}bitoarch index-repos${NC}${BOLD}"
        echo -e "${BOLD}• Check status: ${YELLOW}bitoarch index-status${NC}${BOLD}"

        return 0
    else
        if [ "$http_code" = "409" ]; then
            echo ""
            echo -e "${YELLOW}No indexing or insights workflow is currently running for this workspace.${NC}"
            echo -e "Start a new indexing run with ${YELLOW}bitoarch index-repos${NC}."
            return 0
        fi
        echo ""
        echo -e "${RED}✗ Failed to Stop Indexing${NC}"
        echo ""
        echo -e "${BLUE}Error Details:${NC}"
        echo "  • HTTP Status: $http_code"
        echo "  • Response: $body"
        echo ""
        echo -e "${BLUE}Troubleshooting:${NC}"
        echo -e "  • Check if indexing is currently running: ${YELLOW}bitoarch index-status${NC}"
        echo -e "  • Verify BITO_API_KEY in environment"
        echo -e "  • Check if CIS Manager is accessible: ${YELLOW}bitoarch status${NC}"
        echo ""

        return 1
    fi
}

# Render functions for manager status
render_manager_status_default() {
    local response="$1"
    
    if ! command -v jq >/dev/null 2>&1; then
        print_error "jq is required for parsing"
        echo "$response"
        return 1
    fi

    echo ""

    render_index_session_header "$response"

    # -----------------------------
    # 1) Configured Repositories
    # -----------------------------
    echo -e "${BLUE}Configured Repositories${NC}"
    echo ""

    local configured=$(echo "$response" | jq -r '.configured_repos // 0')
    echo "  Configured: $configured"
    echo -e "  ${BLUE}Note:${NC} Config can change while an index session is running."
    echo ""

    # -----------------------------
    # 2) Repo-level Index Status
    # -----------------------------
    echo -e "${BLUE}Index Status (Repo-level)${NC}"
    echo ""

    local state=$(echo "$response" | jq -r '.status // "unknown"')
    local completed=$(echo "$response" | jq -r '.completed_repos // 0')
    local total=$(echo "$response" | jq -r '.total_repos // 0')
    local in_progress=$(echo "$response" | jq -r '.in_progress_repos // 0')
    local failed=$(echo "$response" | jq -r '.failed_repos // 0')

    local display_state="$state"
    local state_message=""
    local is_indexing_control_state=false

    # Handle new indexing control states first
    case "$state" in
        "pausing")
            display_state="pausing"
            state_message="Indexing is being paused..."
            is_indexing_control_state=true
            ;;
        "paused")
            display_state="paused"
            state_message="Indexing is paused. Use ${YELLOW}'bitoarch resume-indexing'${NC} to continue."
            is_indexing_control_state=true
            ;;
        "stopping")
            display_state="stopping"
            state_message="Indexing is being stopped..."
            is_indexing_control_state=true
            ;;
        "stopped")
            display_state="stopped"
            state_message="Indexing has been stopped. Use ${YELLOW}'bitoarch index-repos'${NC} to restart."
            is_indexing_control_state=true
            ;;
        "resuming")
            display_state="resuming"
            state_message="Indexing is resuming..."
            is_indexing_control_state=true
            ;;
        *)
            ;;
    esac

    if [ "$failed" -gt 0 ] && [ "$is_indexing_control_state" = "false" ]; then
        if [ "$state" = "running" ] || [ "$state" = "indexing" ] || [ "$state" = "in_progress" ]; then
            display_state="running (with failures)"
        elif [ "$state" = "completed" ] || [ "$state" = "success" ]; then
            display_state="completed with errors"
        fi
    fi

    # Keep same repo-level State rendering
    # Show status with appropriate emoji and colors
    case "$display_state" in
        "pausing")
            echo -e "  State: ${YELLOW}⏸️  $display_state${NC}"
            ;;
        "paused")
            echo -e "  State: ${BLUE}⏸️  $display_state${NC}"
            ;;
        "stopping")
            echo -e "  State: ${YELLOW}⏹️  $display_state${NC}"
            ;;
        "stopped")
            echo -e "  State: ${RED}⏹️  $display_state${NC}"
            ;;
        "resuming")
            echo -e "  State: ${YELLOW}▶️  $display_state${NC}"
            ;;
        "indexing"|"running"|"in_progress")
            echo -e "  State: ${YELLOW}⏳ $display_state${NC}"
            ;;
        "running (with failures)")
            echo -e "  State: ${YELLOW}⚠️  $display_state${NC}"
            ;;
        "completed"|"success")
            echo -e "  State: ${GREEN}✓ $display_state${NC}"
            ;;
        "completed with errors")
            echo -e "  State: ${YELLOW}⚠️  $display_state${NC}"
            ;;
        "failed"|"error")
            echo -e "  State: ${RED}✗ $display_state${NC}"
            ;;
        "idle"|"waiting")
            echo -e "  State: ${BLUE}• $display_state${NC}"
            ;;
        *)
            echo -e "  State: $display_state"
            ;;
    esac

    if [ -n "$state_message" ]; then
        echo -e "  Message: $state_message"
    fi



    # Show progress and failure details only for running, success, and failed states
    local show_progress=false
    if [ "$state" = "running" ] || [ "$state" = "success" ] || [ "$state" = "completed" ] || [ "$state" = "failed" ]; then
        show_progress=true
    fi

    if [ "$show_progress" = "true" ]; then
        echo "  Progress: $completed / $total completed"
        if [ "$in_progress" -gt 0 ]; then
            echo "  In Progress: $in_progress"
        fi
        if [ "$failed" -gt 0 ]; then
            echo -e "  ${RED}Failed: $failed${NC}"
        fi

        if [ "$failed" -gt 0 ]; then
            echo ""
            echo -e "${RED}❌ Failed Repositories:${NC}"

            # Reasons come from repositories[].details.failed_event_details.
            # The older .failed_repo_details / .failures lookups this replaced
            # matched nothing the API has ever returned, so this block always
            # fell through to the bare count.
            local failed_details
            local preview_limit=$INDEX_STATUS_FAILURE_PREVIEW
            failed_details=$(echo "$response" | jq -r --argjson limit "$preview_limit" '
                [ (.repositories // [])[]
                  | . as $r
                  | (($r.details.failed_event_details) // [])[]
                  | "  • \($r.repo_name): \(.event) — \(.error_code // "no code"): \(.message // "no reason recorded")"
                ] | .[0:$limit] | .[]
            ' 2>/dev/null)

            if [ -n "$failed_details" ]; then
                # Same redaction as the --failures view: these are the same
                # messages, reached by a different render path.
                printf '%s\n' "$failed_details" | _index_status_redact
                local failed_total
                failed_total=$(echo "$response" | jq -r '
                    [ (.repositories // [])[] | ((.details.failed_event_details) // [])[] ] | length
                ' 2>/dev/null)
                if [ "${failed_total:-0}" -gt "$preview_limit" ] 2>/dev/null; then
                    echo -e "  • ... and $((failed_total - preview_limit)) more — run ${YELLOW}bitoarch index-status --failures${NC}"
                fi
            else
                echo -e "  • $failed repository(ies) failed — run ${YELLOW}bitoarch index-status --failures${NC}"
            fi
        fi
    fi

    echo ""

    # -----------------------------
    # 3) Workspace-level Index Status
    # -----------------------------
    echo -e "${BLUE}Index Status (Cross-Repo)${NC}"
    echo ""

    local ws_total ws_success ws_failure ws_in_progress
    ws_total=$(echo "$response" | jq -r '.workspace_level_index.total // 0')
    ws_success=$(echo "$response" | jq -r '.workspace_level_index.success // 0')
    ws_failure=$(echo "$response" | jq -r '.workspace_level_index.failure // 0')
    ws_in_progress=$(echo "$response" | jq -r '.workspace_level_index.in_progress // 0')
    cross_repo_status=$(echo "$response" | jq -r '.workspace_level_index.ws_status // "pending"')

    case "$cross_repo_status" in
        "pausing")
            echo -e "  State: ${YELLOW}⏸️  $cross_repo_status${NC}"
            ;;
        "paused")
            echo -e "  State: ${BLUE}⏸️  $cross_repo_status${NC}"
            ;;
        "stopping")
            echo -e "  State: ${YELLOW}⏹️  $cross_repo_status${NC}"
            ;;
        "stopped")
            echo -e "  State: ${RED}⏹️  $cross_repo_status${NC}"
            ;;
        "resuming")
            echo -e "  State: ${YELLOW}▶️  $cross_repo_status${NC}"
            ;;
        "indexing"|"running"|"in_progress")
            echo -e "  State: ${YELLOW}⏳ $cross_repo_status${NC}"
            ;;
        "running (with failures)")
            echo -e "  State: ${YELLOW}⚠️  $cross_repo_status${NC}"
            ;;
        "completed"|"success")
            echo -e "  State: ${GREEN}✓ $cross_repo_status${NC}"
            ;;
        "completed with errors")
            echo -e "  State: ${YELLOW}⚠️  $cross_repo_status${NC}"
            ;;
        "failed"|"error")
            echo -e "  State: ${RED}✗ $cross_repo_status${NC}"
            ;;
        "idle"|"waiting")
            echo -e "  State: ${BLUE}• $cross_repo_status${NC}"
            ;;
        *)
            echo -e "  State: $cross_repo_status"
            ;;
    esac

    # Match repo-level style: "Progress: X / Y completed" + optional In Progress + Failed
#    echo "  Progress: $ws_success / $ws_total completed"
    if [ "$cross_repo_status" = "running" ] || [ "$cross_repo_status" = "success" ] || [ "$cross_repo_status" = "failed" ]; then
        if [ "$ws_in_progress" -gt 0 ]; then
            echo "  Cross-Repo indexing in-Progress"
        fi
        if [ "$ws_failure" -gt 0 ]; then
            echo -e "  ${RED}Cross-Repo indexing failed${NC}"
        fi
    fi


    # Per-repo table (or a CSV path above the row threshold).
    _render_index_status_repo_block "$response"

    # Insights status block (before Next Steps so user sees it first).
    # Sets _INSIGHTS_RENDER_STATE for use in summary below.
    _INSIGHTS_RENDER_STATE=""
    _render_index_status_insights_block "$configured"

    local _insights_state="$_INSIGHTS_RENDER_STATE"

    local _indexing_done=false
    if [[ ( "$state" == "completed" || "$state" == "success" ) \
       && ( "$cross_repo_status" == "completed" || "$cross_repo_status" == "success" ) ]]; then
        _indexing_done=true
    fi

    if [ "$_indexing_done" = "true" ]; then
        # Source constants if not already loaded
        if [ -z "$MCP_SETUP_DOCS_URL" ]; then
            local _adapter_dir
            _adapter_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
            source "${_adapter_dir}/../constants.sh" 2>/dev/null || true
        fi

        echo ""
        if [ "$_insights_state" = "running" ]; then
            echo -e "${GREEN}✅ Repo Indexing Complete!${NC}"
            echo -e "${YELLOW}⏳ Insights analysis in progress...${NC}"
        elif [ "$_insights_state" = "completed" ]; then
            echo -e "${GREEN}✅ Indexing & Insights Complete!${NC}"
        elif [ "$_insights_state" = "failed" ]; then
            echo -e "${GREEN}✅ Repo Indexing Complete!${NC}"
            echo -e "${RED}✗ Insights analysis failed.${NC} Run ${YELLOW}bitoarch insights status${NC} for details."
        else
            echo -e "${GREEN}✅ Indexing Complete!${NC}"
        fi
        echo ""
        echo -e "${BLUE}📖 Next Steps:${NC}"
        echo -e "  Set up your MCP server to access the indexed repositories"
        echo -e "  ${YELLOW}Guide: ${MCP_SETUP_DOCS_URL:-https://docs.bito.ai/ai-architect/install-ai-architect-self-hosted#setting-up-ai-architect-mcp-in-coding-agents}${NC}"
        echo ""
    else
        echo ""
        echo -e "${BLUE}💡 Options:${NC}"
        echo -e "  • ${YELLOW}--failures${NC}     Failed repos only, with each errored event and reason"
        echo -e "  • ${YELLOW}--in-progress${NC}  Repos still indexing, with the stage running now"
        echo -e "  • ${YELLOW}--raw${NC}          Show complete API response with full error details"
        echo ""
    fi
}

_render_index_status_insights_block() {
    local _configured_repos="${1:-0}"
    [ -z "${BITO_API_KEY:-}" ] && return 0
    command -v jq >/dev/null 2>&1 || return 0

    local MANAGER_PORT="${CIS_MANAGER_EXTERNAL_PORT:-5002}"
    local _mgr_url="${CIS_MANAGER_URL:-http://localhost:${MANAGER_PORT}}"

    local _ins_resp _ins_http
    _ins_resp=$(curl -s -w '\n%{http_code}' --connect-timeout 3 --max-time 15 \
        -H "Authorization: Bearer ${BITO_API_KEY}" \
        "${_mgr_url}/api/v3/insights/status" 2>/dev/null) || true
    _ins_http=$(echo "$_ins_resp" | tail -1)
    _ins_resp=$(echo "$_ins_resp" | sed '$d')

    echo ""
    echo -e "${BLUE}Insights Status${NC}"
    echo ""

    if [ "$_ins_http" = "404" ] || [ -z "$_ins_resp" ]; then
        echo -e "  State: ${BLUE}• not started${NC}"
    elif [[ ! "$_ins_http" =~ ^2 ]]; then
        echo -e "  State: ${YELLOW}• unavailable${NC} (service returned ${_ins_http})"
    else
        local _ins_state
        _ins_state=$(echo "$_ins_resp" | jq -r '.status // empty' 2>/dev/null)
        [ "$_ins_state" = "completed" ] && _ins_state="success"
        if [ -z "$_ins_state" ] || [ "$_ins_state" = "not_started" ]; then
            echo -e "  State: ${BLUE}• not started${NC}"
        else
            local _ins_icon _ins_color
            case "$_ins_state" in
                running)
                    _ins_icon="⏳"; _ins_color="${YELLOW}" ;;
                success)
                    _ins_icon="✓";  _ins_color="${GREEN}" ;;
                cancelled)
                    _ins_icon="⏹️";  _ins_color="${YELLOW}" ;;
                failed)
                    _ins_icon="✗";  _ins_color="${RED}" ;;
                *)
                    _ins_icon="•";  _ins_color="${NC}" ;;
            esac
            echo -e "  State: ${_ins_color}${_ins_icon} ${_ins_state}${NC}"
            # No "covers N but M configured" staleness warning here: git.total excludes
            # skipped/never-processed repos, so configured_repos > git.total is normal
            # for any workspace with a skipped repo and would nag falsely. (The same
            # warning was dropped from `insights status` as obsolete — the cumulative
            # counts already reflect newly-added repos.)
            echo -e "  Run ${YELLOW}bitoarch insights status${NC} for details"
            _INSIGHTS_RENDER_STATE="$_ins_state"
        fi
    fi
}

render_manager_status_raw() {
    local response="$1"
    
    echo "# Raw API Response (credentials redacted)"
    echo ""

    # Unfiltered, but not unredacted: error messages carry git stderr with the
    # authenticated clone URL in it, and an older manager does not strip it
    # server-side. The placeholder is JSON-safe, so the payload stays parseable.
    if command -v jq >/dev/null 2>&1; then
        echo "$response" | jq . | _index_status_redact
    else
        printf '%s\n' "$response" | _index_status_redact
    fi
}

render_manager_status_json() {
    local response="$1"
    local repo_filter="${2:-all}"

    # Filtered JSON for machine consumption - map from actual API fields.
    # repo_filter mirrors --failures / --in-progress so a script combining them
    # with --output json gets the same rows the table would show, rather than
    # silently receiving every repository.
    if command -v jq >/dev/null 2>&1; then
        echo "$response" | jq --arg filter "$repo_filter" '{
            status: .status,
            session_id: .session_id,
            is_latest_session: .is_latest_session,
            session_started_at: .session_started_at,
            session_ended_at: .session_ended_at,
            total_repos: .total_repos,
            completed_repos: .completed_repos,
            in_progress_repos: .in_progress_repos,
            failed_repos: .failed_repos,
            percentage_completion: .percentage_completion,
            repositories: [
                (.repositories // [])[]
                | select(.repo_name != null and .repo_name != "")
                | select(
                    if $filter == "failures" then
                        ((.details.outcome == "failure")
                         or (((.details.failed_event_details) // []) | length > 0))
                    elif $filter == "in-progress" then
                        .details.outcome == "in_progress"
                    else true end)
                | {
                    repo: .repo_name,
                    outcome: (.details.outcome // "unknown"),
                    stage: (.details.stage // null),
                    failures: [ (.details.failed_event_details // [])[]
                                | {event: .event, error_code: .error_code, message: .message} ]
                  }
            ]
        }' | _index_status_redact
    else
        echo '{"error": "jq required for JSON output"}'
    fi
}

render_manager_status_error() {
    local error_type="$1"
    local error_msg="$2"
    local endpoint="$3"
    
    echo ""
    echo -e "${RED}✗ Failed to retrieve index status${NC}"
    echo ""
    echo -e "${BLUE}Error Details:${NC}"
    
    if [ "$error_type" = "connection_failed" ]; then
        echo "  • Type: Connection Error"
        echo "  • Endpoint: $endpoint"
        echo "  • Message: $error_msg"
    else
        echo "  • HTTP Status: $error_type"
        echo "  • Endpoint: $endpoint"
        echo "  • Response: $error_msg"
    fi
    
    echo ""
    echo -e "${BLUE}Troubleshooting:${NC}"
    echo -e "  • Check if CIS Manager is running: ${YELLOW}bitoarch status${NC}"
    echo -e "  • Verify BITO_API_KEY in .env"
    echo -e "  • Check logs: ${YELLOW}bitoarch logs${NC}"
    echo ""
}


_manager_scheduler_api() {
    local http_method="$1"

    if [ -z "$BITO_API_KEY" ]; then
        print_error "BITO_API_KEY not found in environment"
        return 1
    fi

    local MANAGER_PORT="${CIS_MANAGER_EXTERNAL_PORT:-5002}"
    local MANAGER_URL="${CIS_MANAGER_URL:-http://localhost:${MANAGER_PORT}}"
    ensure_manager_service_accessible

    if [ "$http_method" == "POST" ]; then
      print_info "creating scheduler tasks..."
    else
      print_info "updating scheduler tasks..."
    fi

    local response
    response=$(curl -s -w '\n%{http_code}' \
        -X "${http_method}" \
        -H "Authorization: Bearer ${BITO_API_KEY}" \
        -H "Content-Type: application/json" \
        "${MANAGER_URL}/api/v2/scheduler/workspace/tasks" 2>/dev/null)

    local http_code
    http_code=$(echo "$response" | tail -1)
    local body
    body=$(echo "$response" | sed '$d')

    if [ "$http_code" -ge 200 ] && [ "$http_code" -lt 300 ]; then
        echo ""
        if [ "$http_method" == "POST" ]; then
          echo -e "${GREEN}✅ Scheduler Tasks created Successfully${NC}"
        else
          echo -e "${GREEN}✅ Scheduler Tasks updated Successfully${NC}"
        fi
        echo ""
        echo -e "${CYAN}${BOLD}📊 Next Steps:${NC}"
        echo -e "${BOLD}• Check status: ${YELLOW}bitoarch index-status${NC}${BOLD}"
        echo -e "${BOLD}• Trigger indexing: ${YELLOW}bitoarch index-repos${NC}${BOLD}"
        echo ""
        return 0
    else
        echo ""
        if [ "$http_method" == "POST" ]; then
          echo -e "${RED}✗ Failed to create Scheduler Tasks${NC}"
        else
          echo -e "${RED}✗ Failed to update Scheduler Tasks${NC}"
        fi
        echo ""
        echo -e "${BLUE}Error Details:${NC}"
        echo "  • HTTP Status: $http_code"
        echo "  • Response: $body"
        echo ""
        if [ "$http_method" == "PUT" ]; then
          echo -e "${BLUE}Troubleshooting:${NC}"
          echo -e "  • Ensure scheduler tasks are created first: ${YELLOW}bitoarch create-index-scheduler${NC}"
          echo ""
        fi
        return 1
    fi
}

manager_scheduler_create() {
    if [ "$1" = "--help" ] || [ "$1" = "-h" ]; then
        cat << 'EOF'
USAGE:
  bitoarch create-index-scheduler

DESCRIPTION:
  Create scheduler tasks for the workspace. This sets up scheduled
  indexing tasks based on the configured intervals in the configurations.

OPTIONS:
  --help, -h    Show this help

EXAMPLES:
  bitoarch create-index-scheduler

NOTES:
  - Requires BITO_API_KEY to be configured in environment
EOF
        return 0
    fi

    _manager_scheduler_api "POST"
}

# Update scheduler tasks
manager_scheduler_update() {
    if [ "$1" = "--help" ] || [ "$1" = "-h" ]; then
        cat << 'EOF'
USAGE:
  bitoarch update-index-scheduler

DESCRIPTION:
  Update existing scheduler tasks for the workspace. This refreshes
  the scheduled indexing task configurations based on the current
  configurations.

OPTIONS:
  --help, -h    Show this help

EXAMPLES:
  bitoarch update-index-scheduler

NOTES:
  - Requires BITO_API_KEY to be configured in environment
  - Scheduler tasks must be created first using 'bitoarch create-index-scheduler'
EOF
        return 0
    fi

    _manager_scheduler_api "PUT"
}

# ─── remove-index: purge repository indexes ─────────────────────────────────
# The removal API (DELETE /api/v3/repositories) runs cis-manager's Temporal
# repo-removal workflow (zoekt shards, DB rows, clone dirs, relink/TF-IDF).
# Its status endpoint reports completed/100% even when nothing matched, so
# verification re-reads repo_metadata — the source of truth for what is
# actually still indexed.

_remove_index_db_name() {
    printf '%s' "${MYSQL_DATABASE:-code_intelligence}"
}

# Full config from cis-config (GET /api/v1/config): body on stdout, rc 1 on
# any non-2xx/transport failure. Caller extracts workspace_id + configured repos.
_remove_index_fetch_config() {
    ensure_config_service_accessible
    local CONFIG_PORT="${CIS_CONFIG_EXTERNAL_PORT:-5003}"
    local CONFIG_URL="${CONFIG_URL:-http://localhost:${CONFIG_PORT}}"
    local resp code
    resp=$(curl -s -w '\n%{http_code}' --max-time 15 \
        -H "Authorization: Bearer ${BITO_API_KEY}" \
        "${CONFIG_URL}/api/v1/config" 2>/dev/null) || true
    code=$(printf '%s\n' "$resp" | tail -1)
    case "$code" in
        2[0-9][0-9]) printf '%s\n' "$resp" | sed '$d'; return 0 ;;
        *) return 1 ;;
    esac
}

# Indexed namespaces for a workspace, one per line (repo_metadata.repo_name
# holds the full namespace). rc non-zero = could not query; empty output with
# rc 0 = genuinely nothing indexed.
_remove_index_fetch_indexed() {
    local ws="$1"
    sql_exec_query "$(_remove_index_db_name)" \
        "SELECT repo_name FROM repo_metadata WHERE workspace_id=${ws};"
}

# Start the removal workflow for the given namespaces.
# rc: 0 accepted (202), 2 busy — another workflow holds the workspace
# (409) or a transient start error (429), retry later — 1 anything else.
_remove_index_request_removal() {
    local ws="$1"
    shift
    local ns_json
    ns_json=$(printf '%s\n' "$@" | jq -R . | jq -s -c .)
    local MANAGER_PORT="${CIS_MANAGER_EXTERNAL_PORT:-5002}"
    local MANAGER_URL="${CIS_MANAGER_URL:-http://localhost:${MANAGER_PORT}}"
    local response
    response=$(curl -s -w '\n%{http_code}' --max-time 30 \
        -X DELETE \
        -H "Content-Type: application/json" \
        -H "Authorization: Bearer ${BITO_API_KEY}" \
        -d "{\"namespaces\":${ns_json}}" \
        "${MANAGER_URL}/api/v3/repositories?workspace_id=${ws}" 2>/dev/null)
    local http_code body
    http_code=$(echo "$response" | tail -1)
    body=$(echo "$response" | sed '$d')
    case "$http_code" in
        2[0-9][0-9])
            return 0
            ;;
        409|429)
            print_warning "Workspace is busy — another workflow (indexing or insights) is running."
            echo -e "  Wait for it to finish (check: ${YELLOW}bitoarch index-status${NC}), then retry."
            return 2
            ;;
        *)
            print_error "Index removal request failed (HTTP ${http_code:-n/a})"
            if [ -n "$body" ]; then
                echo "$body" | mask_secrets
            fi
            return 1
            ;;
    esac
}

# Poll removal-status until the workflow reaches a terminal phase.
# Prints completed|failed|timeout on stdout; keep it otherwise silent so
# callers can capture the phase via command substitution.
_remove_index_poll() {
    local ws="$1"
    local interval="${REMOVE_INDEX_POLL_INTERVAL:-10}"
    local timeout="${REMOVE_INDEX_POLL_TIMEOUT:-900}"
    local MANAGER_PORT="${CIS_MANAGER_EXTERNAL_PORT:-5002}"
    local MANAGER_URL="${CIS_MANAGER_URL:-http://localhost:${MANAGER_PORT}}"
    local waited=0 resp phase
    while [ "$waited" -le "$timeout" ]; do
        resp=$(curl -s --max-time 10 \
            -H "Authorization: Bearer ${BITO_API_KEY}" \
            "${MANAGER_URL}/api/v3/repositories/removal-status?workspace_id=${ws}" 2>/dev/null)
        phase=$(echo "$resp" | jq -r '.phase // empty' 2>/dev/null)
        case "$phase" in
            completed|failed)
                printf '%s' "$phase"
                return 0
                ;;
        esac
        sleep "$interval"
        waited=$((waited + interval))
        # interval=0 is a test-only setting; never spin forever on it.
        [ "$interval" -eq 0 ] && waited=$((waited + 1))
    done
    printf 'timeout'
    return 1
}

# Purge mode edits the configuration before the index purge; when anything
# after that point fails, name the state left behind — "retry" alone reads
# as "nothing happened". No-op with no arguments (reconcile mode).
_remove_index_note_config_removed() {
    [ "$#" -gt 0 ] || return 0
    echo ""
    print_warning "Already removed from the configuration (index NOT purged): $*"
    echo -e "  The scheduled sync will no longer re-index these repositories."
    echo -e "  Re-run ${YELLOW}bitoarch remove-index $*${NC} once the workspace is free to purge the index."
}

manager_remove_index() {
    local dry_run="false" assume_yes="false"
    local namespaces=()

    while [[ $# -gt 0 ]]; do
        case "$1" in
            --help|-h)
                cat << 'EOF'
USAGE:
  bitoarch remove-index [<namespace>...] [OPTIONS]

DESCRIPTION:
  Purge repository indexes (zoekt shards, database rows, clone directories)
  via cis-manager's removal workflow.

  Without arguments, reconciles the index against the configured repository
  list: every repository still indexed but no longer configured is purged.
  The configuration itself is not modified.

  With namespaces, each repository is removed from the configuration first
  and its index is purged afterwards, so the scheduled sync cannot re-index
  it in between.

OPTIONS:
  --dry-run     Show what would be purged without changing anything
  --yes, -y     Skip the confirmation prompt
  --help, -h    Show this help

EXAMPLES:
  # Purge everything indexed but no longer configured
  bitoarch remove-index

  # Preview the same without purging
  bitoarch remove-index --dry-run

  # Fully remove one repository (configuration + index)
  bitoarch remove-index myorg/myrepo

NOTES:
  - Requires BITO_API_KEY to be set in environment
  - Reconcile mode and post-purge verification read the repo_metadata table
    and require MYSQL_ROOT_PASSWORD in environment
  - While indexing or insights analysis is running the workspace is busy;
    retry after it completes (check: bitoarch index-status)
EOF
                return 0
                ;;
            --dry-run)
                dry_run="true"
                shift
                ;;
            --yes|-y)
                assume_yes="true"
                shift
                ;;
            -*)
                print_error "Unknown option: $1"
                return 1
                ;;
            *)
                namespaces+=("$1")
                shift
                ;;
        esac
    done

    if [ -z "$BITO_API_KEY" ]; then
        print_error "BITO_API_KEY not found in environment"
        return 1
    fi
    if ! command -v jq >/dev/null 2>&1; then
        print_error "jq is required for remove-index"
        return 1
    fi

    local ns
    if [ ${#namespaces[@]} -gt 0 ] && type _is_valid_repo_namespace >/dev/null 2>&1; then
        for ns in "${namespaces[@]}"; do
            if ! _is_valid_repo_namespace "$ns"; then
                print_error "Invalid namespace format: ${ns} (expected org/repo)"
                return 1
            fi
        done
    fi

    local config_json workspace_id configured
    config_json=$(_remove_index_fetch_config)
    if [ $? -ne 0 ] || [ -z "$config_json" ]; then
        print_error "Failed to fetch configuration from config service"
        return 1
    fi
    workspace_id=$(echo "$config_json" | jq -r '.workspace_id // empty' 2>/dev/null)
    case "$workspace_id" in
        ''|*[!0-9]*)
            print_error "Could not determine workspace id from configuration"
            return 1
            ;;
    esac
    configured=$(echo "$config_json" | jq -r '.repository.configured_repos[]?.namespace // empty' 2>/dev/null)

    # Pre-purge snapshot of what is indexed. Required for reconcile mode
    # (it IS the diff input); in purge mode it only powers verification, so
    # its absence degrades to a warning instead of blocking the purge.
    local sql_ok="true" indexed=""
    if sql_exec_ready; then
        indexed=$(_remove_index_fetch_indexed "$workspace_id") || sql_ok="false"
    else
        sql_ok="false"
    fi

    local targets=""
    if [ ${#namespaces[@]} -eq 0 ]; then
        # Reconcile mode: indexed minus configured.
        if [ "$sql_ok" != "true" ]; then
            print_error "Reconcile mode needs read access to the repo_metadata table."
            echo -e "  Set ${YELLOW}MYSQL_ROOT_PASSWORD${NC} in the environment (and ensure the MySQL"
            echo -e "  container/pod is reachable), or name the repositories explicitly:"
            echo -e "    ${YELLOW}bitoarch remove-index <namespace>...${NC}"
            return 1
        fi
        if [ -z "$configured" ] && [ -n "$indexed" ]; then
            print_error "No repositories are configured but the index is not empty."
            echo -e "  Refusing to purge the whole workspace from reconcile mode — if this is"
            echo -e "  intentional, name the repositories explicitly:"
            echo -e "    ${YELLOW}bitoarch remove-index <namespace>...${NC}"
            return 1
        fi
        while IFS= read -r ns; do
            [ -z "$ns" ] && continue
            if ! printf '%s\n' "$configured" | grep -Fxq "$ns"; then
                targets="${targets}${ns}
"
            fi
        done <<< "$indexed"
        if [ -z "$targets" ]; then
            print_success "Index matches the configured repositories — nothing to purge."
            return 0
        fi
    else
        for ns in "${namespaces[@]}"; do
            targets="${targets}${ns}
"
        done
    fi

    echo ""
    if [ ${#namespaces[@]} -eq 0 ]; then
        echo -e "${BLUE}Indexed repositories no longer in configuration:${NC}"
    else
        echo -e "${BLUE}Repositories to remove from configuration and index:${NC}"
    fi
    printf '%s' "$targets" | while IFS= read -r ns; do
        [ -n "$ns" ] && echo "   • $ns"
    done
    echo ""

    if [ "$dry_run" = "true" ]; then
        print_info "Dry run — nothing was changed."
        return 0
    fi

    if [ "$assume_yes" != "true" ]; then
        local _ri_reply=""
        read -r -p "Purge the index data for these repositories? [y/N]: " _ri_reply
        case "$_ri_reply" in
            [yY]|[yY][eE][sS]) ;;
            *)
                print_info "Aborted — nothing was changed."
                return 1
                ;;
        esac
    fi

    # Purge mode: configuration first, so the scheduled sync cannot re-index
    # the repo between index purge and config removal. A config failure
    # aborts before anything destructive happens.
    if [ ${#namespaces[@]} -gt 0 ]; then
        local cfg_out
        for ns in "${namespaces[@]}"; do
            print_info "Removing '${ns}' from configuration..."
            # The full remove-repo success block (and its next-step hints)
            # is noise inside this flow; keep its output for failures only.
            if ! cfg_out=$(config_repo_remove_namespace "$ns" 2>&1); then
                printf '%s\n' "$cfg_out"
                print_error "Failed to remove '${ns}' from configuration — index left untouched."
                return 1
            fi
        done
        print_success "Configuration updated."
    fi

    # Repos with no index rows would only add noise to the removal workflow;
    # purge-mode targets that were config-only are already done at this point.
    local removal_list=""
    if [ "$sql_ok" = "true" ]; then
        while IFS= read -r ns; do
            [ -z "$ns" ] && continue
            if printf '%s\n' "$indexed" | grep -Fxq "$ns"; then
                removal_list="${removal_list}${ns}
"
            else
                print_info "'${ns}' is not indexed — nothing to purge for it."
            fi
        done <<< "$targets"
        if [ -z "$removal_list" ]; then
            print_success "Nothing indexed to purge."
            return 0
        fi
    else
        removal_list="$targets"
        print_warning "MYSQL_ROOT_PASSWORD not set — skipping index lookup and post-purge verification."
    fi

    ensure_manager_service_accessible

    # Feed the whole batch to one workflow run (the API accepts a list).
    local removal_args=()
    while IFS= read -r ns; do
        [ -n "$ns" ] && removal_args+=("$ns")
    done <<< "$removal_list"

    print_info "Starting index removal workflow for ${#removal_args[@]} repository(ies)..."
    _remove_index_request_removal "$workspace_id" "${removal_args[@]}"
    local req_rc=$?
    if [ "$req_rc" -ne 0 ]; then
        _remove_index_note_config_removed "${namespaces[@]}"
        return 1
    fi

    print_info "Waiting for the removal workflow to finish (this can take a few minutes)..."
    local phase
    phase=$(_remove_index_poll "$workspace_id")
    if [ "$phase" = "timeout" ]; then
        print_warning "Timed out waiting for the removal workflow — verifying current state anyway."
    fi

    # Verification against repo_metadata. The workflow reports completed even
    # when a namespace matched nothing, so the DB re-read decides the outcome.
    if [ "$sql_ok" != "true" ]; then
        if [ "$phase" = "completed" ]; then
            print_success "Removal workflow completed (verification skipped)."
            return 0
        fi
        print_error "Removal workflow reported: ${phase}"
        _remove_index_note_config_removed "${namespaces[@]}"
        return 1
    fi

    local post_indexed purged="" still=""
    post_indexed=$(_remove_index_fetch_indexed "$workspace_id")
    if [ $? -ne 0 ]; then
        print_warning "Could not re-read repo_metadata for verification (workflow phase: ${phase})."
        [ "$phase" = "completed" ] && return 0
        return 1
    fi
    for ns in "${removal_args[@]}"; do
        if printf '%s\n' "$post_indexed" | grep -Fxq "$ns"; then
            still="${still}${ns}
"
        else
            purged="${purged}${ns}
"
        fi
    done

    echo ""
    if [ -n "$purged" ]; then
        echo -e "${GREEN}✅ Purged from index:${NC}"
        printf '%s' "$purged" | while IFS= read -r ns; do
            [ -n "$ns" ] && echo "   • $ns"
        done
    fi
    if [ -n "$still" ]; then
        echo -e "${RED}❌ Still indexed (removal did not complete):${NC}"
        printf '%s' "$still" | while IFS= read -r ns; do
            [ -n "$ns" ] && echo "   • $ns"
        done
        echo ""
        echo -e "  Check ${YELLOW}bitoarch index-status${NC} and retry ${YELLOW}bitoarch remove-index${NC} later."
        _remove_index_note_config_removed "${namespaces[@]}"
        return 1
    fi

    echo ""
    echo -e "${BLUE}🚀 Next Steps${NC}"
    echo -e "   1. View configured repositories: ${YELLOW}bitoarch show-config${NC}"
    echo -e "   2. Check indexing status:        ${YELLOW}bitoarch index-status${NC}"
    echo ""
    return 0
}

# Export functions
export -f manager_sync_simple
export -f manager_status
export -f _manager_status_render_once
export -f manager_pause_indexing
export -f manager_resume_indexing
export -f manager_stop_indexing
export -f _manager_scheduler_api
export -f manager_scheduler_create
export -f manager_scheduler_update
export -f manager_remove_index
export -f _remove_index_note_config_removed
export -f _remove_index_db_name
export -f _remove_index_fetch_config
export -f _remove_index_fetch_indexed
export -f _remove_index_request_removal
export -f _remove_index_poll

# Stream the manager's CSV rendering of a session's events to a file.
# Written atomically so an interrupted download never leaves a partial file
# that looks complete.
_manager_export_events_csv() {
    local endpoint="$1" session_id="$2" target="$3"

    if [ -z "$target" ]; then
        target="$(get_reports_dir)/index-session-${session_id:0:8}-events-$(date +%Y%m%d-%H%M%S).csv"
    fi

    local dir tmp http_code
    dir="$(dirname "$target")"
    if ! mkdir -p "$dir" 2>/dev/null; then
        print_error "Cannot create report directory: $dir"
        return 1
    fi
    tmp="${target}.tmp.$$"

    http_code=$(curl -s -o "$tmp" -w '%{http_code}' --max-time 60 \
        -H "Authorization: Bearer ${BITO_API_KEY}" \
        "$endpoint" 2>/dev/null)

    if [ "${http_code:-000}" -lt 200 ] || [ "${http_code:-000}" -ge 300 ]; then
        rm -f "$tmp" 2>/dev/null
        print_error "Failed to export session events (HTTP ${http_code})"
        return 1
    fi

    # Every other CSV path in the CLI redacts; this one wrote the response
    # straight to disk. The manager redacts server-side, but an older manager
    # does not, and this file lands on the operator's filesystem.
    if ! _index_status_redact < "$tmp" > "${tmp}.clean" 2>/dev/null; then
        rm -f "$tmp" "${tmp}.clean" 2>/dev/null
        print_error "Failed to redact session events export"
        return 1
    fi
    mv "${tmp}.clean" "$tmp" 2>/dev/null

    if ! mv "$tmp" "$target" 2>/dev/null; then
        rm -f "$tmp" 2>/dev/null
        print_error "Failed to finalize CSV: $target"
        return 1
    fi

    print_success "Session events exported to CSV"
    echo "  File: ${target}"
    return 0
}
