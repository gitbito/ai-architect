#!/bin/sh
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
# ============================================================================
# xMCP Provider Config Processor
# ============================================================================
# Processes config at container startup by mapping JSON fields to env vars
# Uses jq for type-safe JSON manipulation
# ============================================================================

set -e

CONFIG_FILE="/opt/bito/xmcp/config/default.json"
CONFIG_TEMP="${CONFIG_FILE}.tmp"

# Check if config exists
if [ ! -f "$CONFIG_FILE" ]; then
    echo "ERROR: Config not found at $CONFIG_FILE"
    exit 1
fi

# ── Decrypt SSO tenant key if encrypted ──
if [ -n "${XMCP_SSO_TENANT_KEY:-}" ] && [ -n "${SECRETS_ENCRYPTION_KEY:-}" ]; then
    case "$XMCP_SSO_TENANT_KEY" in
        enc:v1:*)
            decrypted=$(node -e '
const crypto = require("crypto");
const [,, ivB64, ctB64] = process.env.XMCP_SSO_TENANT_KEY.split(":");
let keyB64 = process.env.SECRETS_ENCRYPTION_KEY.replace(/_/g, "/").replace(/-/g, "+");
while (keyB64.length % 4 !== 0) keyB64 += "=";
const key = Buffer.from(keyB64, "base64");
const iv = Buffer.from(ivB64, "base64");
const ct = Buffer.from(ctB64, "base64");
const decipher = crypto.createDecipheriv("aes-256-cbc", key, iv);
let plain = decipher.update(ct, undefined, "utf8");
plain += decipher.final("utf8");
process.stdout.write(plain);
' 2>/dev/null) || true
            if [ -n "$decrypted" ]; then
                XMCP_SSO_TENANT_KEY="$decrypted"
                echo "✓ SSO tenant key decrypted"
            fi
            ;;
    esac
fi

echo "✓ Processing configuration with environment values..."

# Check if jq is available, install if missing (containers run as root, no sudo needed)
if ! command -v jq >/dev/null 2>&1; then
    echo "ℹ jq not found, installing..."
    
    jq_installed=false
    
    # Try package managers
    if command -v apk >/dev/null 2>&1; then
        echo "  Trying apk (Alpine)..."
        if apk add --no-cache jq 2>&1; then
            jq_installed=true
        fi
    elif command -v apt-get >/dev/null 2>&1; then
        echo "  Trying apt-get (Debian/Ubuntu)..."
        if apt-get update 2>&1 && apt-get install -y jq 2>&1; then
            jq_installed=true
        fi
    elif command -v yum >/dev/null 2>&1; then
        echo "  Trying yum (RHEL/CentOS)..."
        if yum install -y jq 2>&1; then
            jq_installed=true
        fi
    elif command -v dnf >/dev/null 2>&1; then
        echo "  Trying dnf (Fedora/RHEL 8+)..."
        if dnf install -y jq 2>&1; then
            jq_installed=true
        fi
    fi
    
    # Fallback: download jq binary directly
    # Note: Using jq 1.8.1 from official jqlang/jq repo (1.6 has known CVEs)
    # Supports both macOS (testing) and Linux (production)
    if [ "$jq_installed" = "false" ]; then
        echo "  Package manager installation failed, downloading jq binary..."
        if command -v curl >/dev/null 2>&1 || command -v wget >/dev/null 2>&1; then
            JQ_VERSION="1.8.1"
            
            # Detect platform and architecture
            OS=$(uname -s | tr '[:upper:]' '[:lower:]')
            ARCH=$(uname -m)
            case "$ARCH" in
                x86_64|amd64) JQ_ARCH="amd64" ;;
                aarch64|arm64) JQ_ARCH="arm64" ;;
                *) echo "ERROR: Unsupported architecture: $ARCH"; exit 1 ;;
            esac
            
            JQ_URL="https://github.com/jqlang/jq/releases/download/jq-${JQ_VERSION}/jq-${OS}-${JQ_ARCH}"
            
            if command -v curl >/dev/null 2>&1; then
                curl -sL "$JQ_URL" -o /usr/local/bin/jq && chmod +x /usr/local/bin/jq && jq_installed=true
            elif command -v wget >/dev/null 2>&1; then
                wget -q "$JQ_URL" -O /usr/local/bin/jq && chmod +x /usr/local/bin/jq && jq_installed=true
            fi
        fi
    fi
    
    if [ "$jq_installed" = "true" ] && command -v jq >/dev/null 2>&1; then
        echo "✓ jq installed successfully"
    else
        echo "ERROR: Failed to install jq"
        echo "Please ensure jq is available in the container image"
        exit 1
    fi
fi

# The rebuilt config carries the signing secret and tokens: create it owner-only,
# so the mv below leaves the provider's config unreadable to other accounts.
rm -f "$CONFIG_TEMP"
(umask 077 && : > "$CONFIG_TEMP")

# Update specific JSON paths with environment variable values
# Uses --arg for safe string handling and type conversion where needed
# Write to temp file first for atomic update
# WORKAROUND: xmcp's https-unified.js reads cert paths from
# config.transport.https.{keyPath,certPath} (top level), but its ConfigManager
# only populates config.transport.https.ssl.{keyPath,certPath} from env. Until
# xmcp normalizes the schema we explicitly set the top-level fields here so
# the explicit-paths branch wins over the broken __dirname-based fallback
# (which mis-resolves to /opt/certs in the bundled image). HTTP mode never
# reads these, so this is a no-op for Enterprise.
jq \
--arg port "${XMCP_HTTP_PORT:-8080}" \
--arg host "${CIS_SERVER_HOST:-0.0.0.0}" \
  --arg apiKey "${CIS_PROVIDER_API_KEY}" \
  --arg bearerToken "${BITO_MCP_ACCESS_TOKEN}" \
  --arg oauthEnabled "${MCP_OAUTH_ENABLED}" \
  --arg dataDir "${XMCP_DATA_DIR}" \
  --arg metadataDir "${XMCP_METADATA_DIR}" \
  --arg reposDir "${CIS_CLONE_DIR}" \
  --arg zoektBinary "${ZOEKT_BINARY_PATH:-/usr/local/bin/zoekt}" \
  --arg jwtSecret "${JWT_SECRET}" \
  --arg configUrl "http://ai-architect-config:${CIS_CONFIG_PORT:-8081}" \
  --arg managerUrl "http://ai-architect-manager:${CIS_MANAGER_PORT:-9090}" \
  --arg logLevel "${LOG_LEVEL:-info}" \
  --arg httpsKeyPath "${XMCP_HTTPS_KEY_PATH:-/opt/bito/xmcp/certs/server.key}" \
  --arg httpsCertPath "${XMCP_HTTPS_CERT_PATH:-/opt/bito/xmcp/certs/server.crt}" \
  --arg ssoEnabled "${XMCP_SSO_ENABLED:-false}" \
  --arg ssoDeploymentBito "${XMCP_SSO_DEPLOYMENT_BITO:-false}" \
  --arg ssoDefaultProvider "${XMCP_SSO_DEFAULT_PROVIDER:-descope}" \
  --arg ssoFallbackEnabled "${XMCP_SSO_FALLBACK_ENABLED:-true}" \
  --arg ssoFallbackBitoAuthUrl "${XMCP_SSO_FALLBACK_BITO_AUTH_URL:-}" \
  --arg ssoMgmtApiUrl "${XMCP_SSO_MGMT_API_URL:-}" \
  --arg ssoSessionDuration "${XMCP_SSO_SESSION_DURATION:-360}" \
  --arg ssoRefreshTokenTtl "${XMCP_SSO_REFRESH_TOKEN_TTL:-300}" \
  --arg ssoSessionMaxConcurrent "${XMCP_SSO_SESSION_MAX_CONCURRENT:-2}" \
  --arg ssoProjectId "${XMCP_SSO_PROJECT_ID:-}" \
  --arg ssoTenantKey "${XMCP_SSO_TENANT_KEY:-}" \
  --arg ssoDefaultWorkspaceId "${XMCP_SSO_DEFAULT_WORKSPACE_ID:-}" \
  --arg ssoSkipTenantVerification "${XMCP_SSO_SKIP_TENANT_VERIFICATION:-false}" \
  '
  .transport.http.port = ($port | tonumber) |
  .transport.http.host = $host |
  .transport.http.internalApiKey = $apiKey |
  .transport.http.bearerToken = $bearerToken |
  .transport.http.oauth.enabled = ($oauthEnabled == "true") |
  .transport.https.host = $host |
  .transport.https.keyPath = $httpsKeyPath |
  .transport.https.certPath = $httpsCertPath |
  .transport.https.internalApiKey = $apiKey |
  .transport.https.bearerToken = $bearerToken |
  .transport.https.oauth.enabled = ($oauthEnabled == "true") |
  .data.dataDir = $dataDir |
  .data.metadataDir = $metadataDir |
  .data.reposDir = $reposDir |
  .zoekt.binaryPath = $zoektBinary |
  .services.cis_config_url = $configUrl |
  .services.cis_manager_url = $managerUrl |
  .auth.jwt_secret = $jwtSecret |
  .auth.bearer_token = $bearerToken |
  .logging.level = $logLevel |
  .sso.enabled = ($ssoEnabled == "true") |
  .sso.deployment.bito = ($ssoDeploymentBito == "true") |
  .sso.defaultProvider = $ssoDefaultProvider |
  .sso.fallback.enabled = ($ssoFallbackEnabled == "true") |
  .sso.skipTenantVerification = ($ssoSkipTenantVerification == "true") |
  .sso.session.duration = ($ssoSessionDuration | tonumber) |
  .sso.session.refreshTokenTtl = ($ssoRefreshTokenTtl | tonumber) |
  .sso.session.maxConcurrent = ($ssoSessionMaxConcurrent | tonumber) |
  if ($ssoMgmtApiUrl != "") then
    .sso.mgmtApiUrl = $ssoMgmtApiUrl
  else . end |
  if ($ssoProjectId != "") then 
    .sso.providers.descope.projectId = $ssoProjectId 
  else . end |
  if ($ssoTenantKey != "") then 
    .sso.providers.descope.managementKey = $ssoTenantKey 
  else . end |
  if ($ssoDefaultWorkspaceId != "") then 
    .sso.defaultWorkspaceId = $ssoDefaultWorkspaceId 
  else . end |
  if ($ssoFallbackBitoAuthUrl != "") then
    .sso.fallback.bitoAuthUrl = $ssoFallbackBitoAuthUrl
  else . end
  ' "$CONFIG_FILE" > "$CONFIG_TEMP"

if ! jq_err=$(jq empty "$CONFIG_TEMP" 2>&1); then
    echo "ERROR: Processed config is not valid JSON: $(printf '%s' "$jq_err" | head -c 300)"
    rm -f "$CONFIG_TEMP"
    exit 1
fi

if ! mv "$CONFIG_TEMP" "$CONFIG_FILE"; then
    echo "ERROR: Failed to write processed config to $CONFIG_FILE"
    rm -f "$CONFIG_TEMP"
    exit 1
fi

echo "✓ Configuration processed successfully and written to $CONFIG_FILE"
echo ""
echo "Starting xMCP Server with config: $CONFIG_FILE"
echo "========================================"

# Execute the default container command
exec "$@"
