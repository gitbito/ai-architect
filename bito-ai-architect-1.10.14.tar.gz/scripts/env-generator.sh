#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai

# errexit only when EXECUTED as a script -- when sourced (xmcp-adapter, bitoarch mcp
# flows) a top-level `set -e` would leak into the whole CLI shell and kill it on the
# first incidentally non-zero statement far away from here.
if [ "${BASH_SOURCE[0]}" == "${0}" ]; then set -e; fi

# Use SCRIPT_DIR from caller if already set (when sourced), otherwise calculate it
if [ -z "${SCRIPT_DIR:-}" ]; then
    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
fi

# Source path-manager if available (for standard paths)
if [ -f "${SCRIPT_DIR}/scripts/lib/path-manager.sh" ]; then
    source "${SCRIPT_DIR}/scripts/lib/path-manager.sh"
fi

# Lib paths resolve from this file's own location, never from SCRIPT_DIR:
# callers source this file with SCRIPT_DIR at either the install root
# (setup.sh) or scripts/ (bitoarch.sh, adapters).
ENV_GEN_LIB_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/lib"

# bash SKIPS any command whose redirect it cannot open, so pointing stderr
# straight at $LOG_FILE would stop these libs from loading at all whenever the
# log directory is missing or unwritable (a purge removes it mid-run). Resolve
# a usable sink first; /dev/null keeps the source itself unconditional.
ENV_GEN_ERR_LOG="/dev/null"
if [ -n "${LOG_FILE:-}" ] && [ -d "${LOG_FILE%/*}" ] \
   && { [ -w "${LOG_FILE}" ] || [ -w "${LOG_FILE%/*}" ]; }; then
    ENV_GEN_ERR_LOG="${LOG_FILE}"
fi

# Output layer (print_* echo to console AND log to setup.log) — required for
# the operator-facing warnings below. Load-guarded; no-op under setup.sh.
# shellcheck disable=SC1091
source "${ENV_GEN_LIB_DIR}/output-blocks.sh" 2>>"${ENV_GEN_ERR_LOG}" || true
if ! type print_warning >/dev/null 2>&1; then
    print_warning() { echo -e "⚠ $1"; log_silent "WARNING: $1"; }
fi

# Worker memory sizing helpers (shared with values-generator.sh)
# shellcheck disable=SC1091
source "${ENV_GEN_LIB_DIR}/worker-memory.sh" 2>>"${ENV_GEN_ERR_LOG}" || true
# Record the outcome, not just any stderr: a lib that fails to load leaves the
# worker memory checks silently skipped, which is what an operator needs told.
if ! type mem_to_mb >/dev/null 2>&1; then
    log_silent "env-generator: ${ENV_GEN_LIB_DIR}/worker-memory.sh did not load; worker memory checks are skipped"
fi

ENV_EXAMPLE="${SCRIPT_DIR}/.env-bitoarch.default"

# Source setup utilities for helper functions
if [ -f "${SCRIPT_DIR}/scripts/setup-utils.sh" ]; then
    source "${SCRIPT_DIR}/scripts/setup-utils.sh"
else
    generate_secret() {
        openssl rand -base64 32 2>/dev/null || head -c 32 /dev/urandom | base64
    }
    
    generate_encryption_key() {
        openssl rand -base64 32 2>/dev/null || head -c 32 /dev/urandom | base64 | tr -d '=' | tr '+/' '-_'
    }
fi

set_env_key_value() {
    local key="$1"
    local value="$2"
    local file="$3"

    # Create file if missing
    touch "$file"

    # If key exists → replace value
    if grep -q "^${key}=" "$file"; then
        # Use sed to replace entire line where KEY=...
        sed -i.bak "s|^${key}=.*|${key}=${value}|" "$file"
    else
        # Append new entry
        echo "${key}=${value}" >> "$file"
    fi
}

# Function to refresh service versions from service-versions.json to .env-bitoarch
# This is used by ./setup.sh --update to sync versions before pulling images
refresh_versions_from_service_json() {
    local env_file="${1:-.env-bitoarch}"
    local versions_file="${SCRIPT_DIR}/versions/service-versions.json"
    
    if [ ! -f "$env_file" ]; then
        echo "Error: Environment file not found: $env_file"
        return 1
    fi
    
    if [ ! -f "$versions_file" ]; then
        echo "Error: Service versions file not found: $versions_file"
        return 1
    fi
    
    if ! command -v jq >/dev/null 2>&1; then
        echo "Warning: jq not found, using fallback grep parsing"
        # Fallback parsing without jq
        local config_ver=$(grep -A 10 '"cis-config"' "$versions_file" | grep '"version"' | head -1 | cut -d'"' -f4 || echo "latest")
        local config_img=$(grep -A 10 '"cis-config"' "$versions_file" | grep '"image"' | head -1 | cut -d'"' -f4 || echo "docker.io/bitoai/cis-config")
        
        local manager_ver=$(grep -A 10 '"cis-manager"' "$versions_file" | grep '"version"' | head -1 | cut -d'"' -f4 || echo "latest")
        local manager_img=$(grep -A 10 '"cis-manager"' "$versions_file" | grep '"image"' | head -1 | cut -d'"' -f4 || echo "docker.io/bitoai/cis-manager")
        
        local provider_ver=$(grep -A 10 '"cis-provider"' "$versions_file" | grep '"version"' | head -1 | cut -d'"' -f4 || echo "latest")
        local provider_img=$(grep -A 10 '"cis-provider"' "$versions_file" | grep '"image"' | head -1 | cut -d'"' -f4 || echo "docker.io/bitoai/xmcp")
        
        local tracker_ver=$(grep -A 10 '"cis-tracker"' "$versions_file" | grep '"version"' | head -1 | cut -d'"' -f4 || echo "latest")
        local tracker_img=$(grep -A 10 '"cis-tracker"' "$versions_file" | grep '"image"' | head -1 | cut -d'"' -f4 || echo "docker.io/bitoai/cis-tracking")
        
        local mysql_ver=$(grep -A 10 '"mysql"' "$versions_file" | grep '"version"' | head -1 | cut -d'"' -f4 || echo "8.0")
        local mysql_img=$(grep -A 10 '"mysql"' "$versions_file" | grep '"image"' | head -1 | cut -d'"' -f4 || echo "mysql")

        local worker_ver=$(grep -A 10 '"cis-worker"' "$versions_file" | grep '"version"' | head -1 | cut -d'"' -f4 || echo "latest")
        local worker_img=$(grep -A 10 '"cis-worker"' "$versions_file" | grep '"image"' | head -1 | cut -d'"' -f4 || echo "docker.io/bitoai/cis-worker")

        local temporal_ver=$(grep -A 10 '"temporal"' "$versions_file" | grep '"version"' | head -1 | cut -d'"' -f4 || echo "1.29.1")
        local temporal_img=$(grep -A 10 '"temporal"' "$versions_file" | grep '"image"' | head -1 | cut -d'"' -f4 || echo "temporalio/auto-setup")
    else
        # Use jq for reliable JSON parsing
        local config_ver=$(jq -r '.services."cis-config".version' "$versions_file" 2>/dev/null || echo "latest")
        local config_img=$(jq -r '.services."cis-config".image' "$versions_file" 2>/dev/null || echo "docker.io/bitoai/cis-config")
        
        local manager_ver=$(jq -r '.services."cis-manager".version' "$versions_file" 2>/dev/null || echo "latest")
        local manager_img=$(jq -r '.services."cis-manager".image' "$versions_file" 2>/dev/null || echo "docker.io/bitoai/cis-manager")
        
        local provider_ver=$(jq -r '.services."cis-provider".version' "$versions_file" 2>/dev/null || echo "latest")
        local provider_img=$(jq -r '.services."cis-provider".image' "$versions_file" 2>/dev/null || echo "docker.io/bitoai/xmcp")
        
        local tracker_ver=$(jq -r '.services."cis-tracker".version' "$versions_file" 2>/dev/null || echo "latest")
        local tracker_img=$(jq -r '.services."cis-tracker".image' "$versions_file" 2>/dev/null || echo "docker.io/bitoai/cis-tracking")
        
        local mysql_ver=$(jq -r '.services."mysql".version' "$versions_file" 2>/dev/null || echo "8.0")
        local mysql_img=$(jq -r '.services."mysql".image' "$versions_file" 2>/dev/null || echo "mysql")

        local worker_ver=$(jq -r '.services."cis-worker".version' "$versions_file" 2>/dev/null || echo "latest")
        local worker_img=$(jq -r '.services."cis-worker".image' "$versions_file" 2>/dev/null || echo "docker.io/bitoai/cis-worker")

        local temporal_ver=$(jq -r '.services."temporal".version' "$versions_file" 2>/dev/null || echo "1.29.1")
        local temporal_img=$(jq -r '.services."temporal".image' "$versions_file" 2>/dev/null || echo "temporalio/auto-setup")
    fi
    
    # Update VERSION variables
    sed -i.bak "s|^CIS_CONFIG_VERSION=.*|CIS_CONFIG_VERSION=${config_ver}|" "$env_file"
    sed -i.bak "s|^CIS_MANAGER_VERSION=.*|CIS_MANAGER_VERSION=${manager_ver}|" "$env_file"
    sed -i.bak "s|^CIS_PROVIDER_VERSION=.*|CIS_PROVIDER_VERSION=${provider_ver}|" "$env_file"
    sed -i.bak "s|^CIS_TRACKER_VERSION=.*|CIS_TRACKER_VERSION=${tracker_ver}|" "$env_file"
    
    # Update complete IMAGE paths (image:version)
    sed -i.bak "s|^CIS_CONFIG_IMAGE=.*|CIS_CONFIG_IMAGE=${config_img}:${config_ver}|" "$env_file"
    sed -i.bak "s|^CIS_MANAGER_IMAGE=.*|CIS_MANAGER_IMAGE=${manager_img}:${manager_ver}|" "$env_file"
    sed -i.bak "s|^CIS_PROVIDER_IMAGE=.*|CIS_PROVIDER_IMAGE=${provider_img}:${provider_ver}|" "$env_file"
    sed -i.bak "s|^CIS_TRACKER_IMAGE=.*|CIS_TRACKER_IMAGE=${tracker_img}:${tracker_ver}|" "$env_file"
    sed -i.bak "s|^MYSQL_IMAGE=.*|MYSQL_IMAGE=${mysql_img}:${mysql_ver}|" "$env_file"
    sed -i.bak "s|^CIS_WORKER_IMAGE=.*|CIS_WORKER_IMAGE=${worker_img}:${worker_ver}|" "$env_file"
    sed -i.bak "s|^TEMPORAL_IMAGE=.*|TEMPORAL_IMAGE=${temporal_img}:${temporal_ver}|" "$env_file"
    
    # Clean up backup files
    rm -f "${env_file}.bak"
    
    echo "✓ Refreshed service versions from $versions_file to $env_file"
    return 0
}

to_int_floor() {
    awk -v v="$1" 'BEGIN { printf "%d", v }'
}

round_cpu_band() {
    local v
    v="$(to_int_floor "$1")"
    if (( v < 2 )); then echo 1
    elif (( v < 4 )); then echo 2
    elif (( v < 8 )); then echo 4
    else echo 8
    fi
}

detect_resource_caps() {

    local output_file="$1"
    log_silent "env file path details: $output_file"

    # Operator presets (install.yaml resources / exported environment) must win
    # over the computed caps — capture them before the calculations below
    # overwrite the same globals, or they are silently lost.
    local _preset_provider_cpu="${CIS_PROVIDER_CPU_LIMIT:-}"
    local _preset_worker_cpu="${CIS_WORKER_CPU_LIMIT:-}"
    local _preset_provider_mem="${CIS_PROVIDER_MEMORY_LIMIT:-}"
    local _preset_worker_mem="${CIS_WORKER_MEMORY_LIMIT:-}"
    local _preset_manager_cpu="${CIS_MANAGER_CPU_LIMIT:-}"
    local _preset_manager_mem="${CIS_MANAGER_MEMORY_LIMIT:-}"
    local _preset_mysql_mem="${MYSQL_MEMORY_LIMIT:-}"
    local _preset_mysql_cpu="${MYSQL_CPU_LIMIT:-}"

    local OS
    OS="$(uname -s)"

    # -------------------------------
    # Detect CPU cores
    # -------------------------------
    local TOTAL_CORES
    if [[ "$OS" == "Darwin" ]]; then
        TOTAL_CORES="$(sysctl -n hw.ncpu)"
    else
        TOTAL_CORES="$(nproc)"
    fi

    # -------------------------------
    # Detect total memory (GB)
    # -------------------------------
    local TOTAL_MEM_GB
    if [[ "$OS" == "Darwin" ]]; then
        TOTAL_MEM_GB="$(($(sysctl -n hw.memsize) / 1024 / 1024 / 1024))"
    else
        TOTAL_MEM_GB="$(free -g | awk '/^Mem:/ {print $2}')"
    fi

    # Safety fallback
    TOTAL_CORES="${TOTAL_CORES:-4}"
    TOTAL_MEM_GB="${TOTAL_MEM_GB:-8}"

    # -------------------------------
    # Baseline (4 cores / 8 GB)
    # -------------------------------
    local BASE_CORES=4
    local BASE_MEM=8

    local BASE_PROVIDER_MEM=1

    local BASE_PROVIDER_CPU=1.0
    local BASE_WORKER_CPU=2.0

    # -------------------------------
    # Scale factors
    # -------------------------------
    local CPU_SCALE MEM_SCALE
    CPU_SCALE=$(awk "BEGIN {print $TOTAL_CORES / $BASE_CORES}")
    MEM_SCALE=$(awk "BEGIN {print $TOTAL_MEM_GB / $BASE_MEM}")

    # -------------------------------
    # OS-specific tuning
    # -------------------------------
    local CPU_FACTOR MEM_FACTOR
    if [[ "$OS" == "Darwin" ]]; then
        # macOS – conservative
        CPU_FACTOR=0.6
        MEM_FACTOR=0.6
    else
        # Linux – aggressive but safe
        CPU_FACTOR=0.85
        MEM_FACTOR=0.8
    fi

    # -------------------------------
    # Final calculations
    # -------------------------------
    CIS_PROVIDER_CPU_LIMIT=$(awk "BEGIN {
        v=$BASE_PROVIDER_CPU * $CPU_SCALE * $CPU_FACTOR;
        if (v < 1.0) v=1.0;
        printf \"%.2f\", v
    }")

    CIS_WORKER_CPU_LIMIT=$(awk "BEGIN {
        v=$BASE_WORKER_CPU * $CPU_SCALE * $CPU_FACTOR;
        if (v < 2.0) v=2.0;
        printf \"%.2f\", v
    }")

    CIS_PROVIDER_MEMORY_LIMIT=$(awk "BEGIN {
        v=$BASE_PROVIDER_MEM * $MEM_SCALE * $MEM_FACTOR;
        if (v < 1) v=1;
        printf \"%dg\", int(v)
    }")

    CIS_PROVIDER_CPU_LIMIT="$(round_cpu_band "${CIS_PROVIDER_CPU_LIMIT}")"
    CIS_WORKER_CPU_LIMIT="$(round_cpu_band "${CIS_WORKER_CPU_LIMIT}")"

    local provider_cpu="${_preset_provider_cpu:-${CIS_PROVIDER_CPU_LIMIT}}"
    local worker_cpu="${_preset_worker_cpu:-${CIS_WORKER_CPU_LIMIT}}"
    local provider_mem="${_preset_provider_mem:-${CIS_PROVIDER_MEMORY_LIMIT}}"
    # Worker memory is deliberately NOT host-scaled: one flat default that
    # covers most deployments; operators size up (or down) explicitly. When the
    # host looks too small for it we warn rather than silently shrink.
    local worker_mem="${_preset_worker_mem:-${WORKER_MEMORY_DEFAULT_LIMIT:-7g}}"

    log_silent ""
    log_silent "🖥 System detected:"
    log_silent "   OS:        $OS"
    log_silent "   CPU cores: $TOTAL_CORES"
    log_silent "   Memory:    ${TOTAL_MEM_GB}GB"
    log_silent ""
    log_silent "🚀 Resource caps applied:"
    log_silent "   CIS_PROVIDER_CPU_LIMIT=$provider_cpu"
    log_silent "   CIS_WORKER_CPU_LIMIT=$worker_cpu"
    log_silent "   CIS_PROVIDER_MEMORY_LIMIT=$provider_mem"
    log_silent "   CIS_WORKER_MEMORY_LIMIT=$worker_mem"

    set_env_key_value "CIS_PROVIDER_CPU_LIMIT" "${provider_cpu}" "${output_file}"
    set_env_key_value "CIS_WORKER_CPU_LIMIT" "${worker_cpu}" "${output_file}"
    set_env_key_value "CIS_PROVIDER_MEMORY_LIMIT" "${provider_mem}" "${output_file}"
    set_env_key_value "CIS_WORKER_MEMORY_LIMIT" "${worker_mem}" "${output_file}"

    # Manager and MySQL caps are yaml-only — write through only when pre-set.
    if [ -n "${_preset_manager_cpu}" ]; then
        set_env_key_value "CIS_MANAGER_CPU_LIMIT" "${_preset_manager_cpu}" "${output_file}"
    fi
    if [ -n "${_preset_manager_mem}" ]; then
        set_env_key_value "CIS_MANAGER_MEMORY_LIMIT" "${_preset_manager_mem}" "${output_file}"
    fi
    if [ -n "${_preset_mysql_mem}" ]; then
        set_env_key_value "MYSQL_MEMORY_LIMIT" "${_preset_mysql_mem}" "${output_file}"
    fi
    if [ -n "${_preset_mysql_cpu}" ]; then
        set_env_key_value "MYSQL_CPU_LIMIT" "${_preset_mysql_cpu}" "${output_file}"
    fi

    warn_worker_memory_fit "${TOTAL_MEM_GB}" "${worker_mem}" "${output_file}"
}

# Operator values are never rewritten — when they can't work together, say so
# and name the keys to change. cis-worker itself clamps an over-sized heap at
# runtime, so a bad pairing degrades rather than crashes; the warning is what
# lets the operator fix it deliberately. print_warning (output layer) echoes
# to the console and records the same line in setup.log.
warn_worker_memory_fit() {
    local total_mem_gb="$1" worker_mem="$2" output_file="$3" heap_mb

    if ! type worker_mem_exceeds_host >/dev/null 2>&1; then
        log_silent "worker-memory.sh helpers unavailable; skipping worker memory fit checks"
        return 0
    fi

    if worker_mem_exceeds_host "${total_mem_gb}" "${worker_mem}"; then
        print_warning "This host has ${total_mem_gb}GB memory and the cis-worker limit is ${worker_mem}. If the host is memory-constrained, lower BOTH CIS_WORKER_MEMORY_LIMIT and CIS_MODULE_BASIC_INDEX_NODE_HEAP_MB in .env-bitoarch ('bitoarch config edit env'), then 'bitoarch restart --force'."
    fi

    heap_mb="${CIS_MODULE_BASIC_INDEX_NODE_HEAP_MB:-}"
    if [ -z "$heap_mb" ]; then
        heap_mb=$(grep -E '^CIS_MODULE_BASIC_INDEX_NODE_HEAP_MB=' "$output_file" 2>>"${LOG_FILE:-/dev/null}" | tail -1 | cut -d= -f2-) || true
    fi
    # Warn on the ceiling (limit - headroom), not the raw limit: a heap that
    # fits the container but not once headroom is reserved is still trimmed at
    # runtime, so heap == limit must warn too. Name the capped value so the
    # operator sees what they will actually get.
    if worker_heap_exceeds_ceiling "${worker_mem}" "${heap_mb:-}"; then
        local ceiling_mb
        ceiling_mb=$(worker_heap_ceiling_mb "${worker_mem}")
        print_warning "CIS_MODULE_BASIC_INDEX_NODE_HEAP_MB (${heap_mb}MB) exceeds what the cis-worker memory limit (${worker_mem}) can back after headroom; the worker will cap the Node heap to ${ceiling_mb}MB at runtime. Raise CIS_WORKER_MEMORY_LIMIT or lower the heap together in .env-bitoarch, then 'bitoarch restart --force'."
    fi
}


# Function to generate .env-bitoarch with all parameters
# Called by setup.sh with collected values, or standalone with auto-generated values
generate_env_with_params() {
    local output_file="$1"
    local bito_api_key="$2"
    local db_root_pass="$3"
    local db_user_pass="$4"
    local jwt_secret="$5"
    local cis_manager_api_key="$6"
    local cis_config_api_key="$7"
    local cis_provider_api_key="$8"
    local bito_mcp_access_token="$9"
    local secrets_encryption_key="${10}"
    local cis_config_version="${11}"
    local cis_manager_version="${12}"
    local cis_provider_version="${13}"
    local cis_provider_external_port="${14:-8080}"
    local cis_manager_external_port="${15:-9090}"
    local cis_config_external_port="${16:-8081}"
    local mysql_external_port="${17:-3306}"
    local git_provider="${18:-gitlab}"
    local git_access_token="${19}"
    local git_domain="${20}"
    local git_user="${21}"
    local cis_tracker_external_port="${22}"
    local cis_tracker_version="${23}"
    local git_azure_org="${24}"
    
    [ ! -f "$ENV_EXAMPLE" ] && echo "Error: $ENV_EXAMPLE not found" && return 1
    
    # Ensure target directory exists
    local output_dir="$(dirname "$output_file")"
    mkdir -p "$output_dir" 2>/dev/null || true
    
    # Copy template (gets ALL properties with defaults)
    log_silent "Data: $output_file"
    cp "$ENV_EXAMPLE" "$output_file"
    
    # Replace generated values
    sed -i.bak "s/# Generated on .*/# Generated on $(date)/" "$output_file"
    sed -i.bak "s|MYSQL_ROOT_PASSWORD=.*|MYSQL_ROOT_PASSWORD=${db_root_pass}|" "$output_file"
    sed -i.bak "s|MYSQL_PASSWORD=.*|MYSQL_PASSWORD=${db_user_pass}|" "$output_file"
    # Generate temporal MySQL password (dedicated user, not root)
    local temporal_mysql_pass=$(generate_secret)
    sed -i.bak "s|TEMPORAL_MYSQL_PASSWORD=.*|TEMPORAL_MYSQL_PASSWORD=${temporal_mysql_pass}|" "$output_file"
    sed -i.bak "s|JWT_SECRET=.*|JWT_SECRET=${jwt_secret}|" "$output_file"
    sed -i.bak "s|BITO_API_KEY=.*|BITO_API_KEY=${bito_api_key}|" "$output_file"
    sed -i.bak "s|BITO_MCP_ACCESS_TOKEN=.*|BITO_MCP_ACCESS_TOKEN=${bito_mcp_access_token}|" "$output_file"
    sed -i.bak "s|CIS_MANAGER_API_KEY=.*|CIS_MANAGER_API_KEY=${cis_manager_api_key}|" "$output_file"
    sed -i.bak "s|CIS_CONFIG_API_KEY=.*|CIS_CONFIG_API_KEY=${cis_config_api_key}|" "$output_file"
    sed -i.bak "s|CIS_PROVIDER_API_KEY=.*|CIS_PROVIDER_API_KEY=${cis_provider_api_key}|" "$output_file"
    sed -i.bak "s|SECRETS_ENCRYPTION_KEY=.*|SECRETS_ENCRYPTION_KEY=${secrets_encryption_key}|" "$output_file"
    sed -i.bak "s|CIS_CONFIG_VERSION=.*|CIS_CONFIG_VERSION=${cis_config_version}|" "$output_file"
    sed -i.bak "s|CIS_MANAGER_VERSION=.*|CIS_MANAGER_VERSION=${cis_manager_version}|" "$output_file"
    sed -i.bak "s|CIS_PROVIDER_VERSION=.*|CIS_PROVIDER_VERSION=${cis_provider_version}|" "$output_file"
    sed -i.bak "s|CIS_PROVIDER_EXTERNAL_PORT=.*|CIS_PROVIDER_EXTERNAL_PORT=${cis_provider_external_port}|" "$output_file"
    sed -i.bak "s|CIS_MANAGER_EXTERNAL_PORT=.*|CIS_MANAGER_EXTERNAL_PORT=${cis_manager_external_port}|" "$output_file"
    sed -i.bak "s|CIS_CONFIG_EXTERNAL_PORT=.*|CIS_CONFIG_EXTERNAL_PORT=${cis_config_external_port}|" "$output_file"
    sed -i.bak "s|MYSQL_EXTERNAL_PORT=.*|MYSQL_EXTERNAL_PORT=${mysql_external_port}|" "$output_file"
    sed -i.bak "s|GIT_PROVIDER=.*|GIT_PROVIDER=${git_provider}|" "$output_file"
    sed -i.bak "s|GIT_ACCESS_TOKEN=.*|GIT_ACCESS_TOKEN=${git_access_token}|" "$output_file"
    sed -i.bak "s|GIT_DOMAIN_URL=.*|GIT_DOMAIN_URL=${git_domain}|" "$output_file"
    sed -i.bak "s|GIT_USER=.*|GIT_USER=${git_user}|" "$output_file"
    sed -i.bak "s|GIT_AZURE_ORG=.*|GIT_AZURE_ORG=${git_azure_org}|" "$output_file"
    # GitHub App auth (additive; empty for PAT installs). Not positional args --
    # read from the (dynamically-scoped / exported) GIT_* env the collector set, so
    # both the interactive and install.yaml lanes persist them. base64 has no
    # '|' so it is safe as the sed replacement with a '|' delimiter.
    sed -i.bak "s|GIT_AUTH_TYPE=.*|GIT_AUTH_TYPE=${GIT_AUTH_TYPE:-}|" "$output_file"
    sed -i.bak "s|GIT_APP_ID=.*|GIT_APP_ID=${GIT_APP_ID:-}|" "$output_file"
    sed -i.bak "s|GIT_INSTALLATION_ID=.*|GIT_INSTALLATION_ID=${GIT_INSTALLATION_ID:-}|" "$output_file"
    sed -i.bak "s|GIT_APP_PRIVATE_KEY_B64=.*|GIT_APP_PRIVATE_KEY_B64=${GIT_APP_PRIVATE_KEY_B64:-}|" "$output_file"
    sed -i.bak "s|CIS_TRACKER_EXTERNAL_PORT=.*|CIS_TRACKER_EXTERNAL_PORT=${cis_tracker_external_port}|" "$output_file"
    sed -i.bak "s|CIS_TRACKER_VERSION=.*|CIS_TRACKER_VERSION=${cis_tracker_version}|" "$output_file"
    
    # Set HOST_LOG_DIR using path-manager if available (for docker-compose volume mounts)
    if command -v get_log_dir >/dev/null 2>&1; then
        local log_dir="$(get_log_dir)"
        sed -i.bak "s|HOST_LOG_DIR=.*|HOST_LOG_DIR=${log_dir}|" "$output_file"
    fi
    
    # Update complete image paths from service-versions.json
    local versions_file="${SCRIPT_DIR}/versions/service-versions.json"
    if [ -f "$versions_file" ] && command -v jq >/dev/null 2>&1; then
        local config_img=$(jq -r '.services."cis-config".image' "$versions_file" 2>/dev/null || echo "docker.io/bitoai/cis-config")
        local config_ver=$(jq -r '.services."cis-config".version' "$versions_file" 2>/dev/null || echo "latest")
        sed -i.bak "s|CIS_CONFIG_IMAGE=.*|CIS_CONFIG_IMAGE=${config_img}:${config_ver}|" "$output_file"
        
        local manager_img=$(jq -r '.services."cis-manager".image' "$versions_file" 2>/dev/null || echo "docker.io/bitoai/cis-manager")
        local manager_ver=$(jq -r '.services."cis-manager".version' "$versions_file" 2>/dev/null || echo "latest")
        sed -i.bak "s|CIS_MANAGER_IMAGE=.*|CIS_MANAGER_IMAGE=${manager_img}:${manager_ver}|" "$output_file"
        
        local provider_img=$(jq -r '.services."cis-provider".image' "$versions_file" 2>/dev/null || echo "docker.io/bitoai/xmcp")
        local provider_ver=$(jq -r '.services."cis-provider".version' "$versions_file" 2>/dev/null || echo "latest")
        sed -i.bak "s|CIS_PROVIDER_IMAGE=.*|CIS_PROVIDER_IMAGE=${provider_img}:${provider_ver}|" "$output_file"
        
        local tracker_img=$(jq -r '.services."cis-tracker".image' "$versions_file" 2>/dev/null || echo "docker.io/bitoai/cis-tracking")
        local tracker_ver=$(jq -r '.services."cis-tracker".version' "$versions_file" 2>/dev/null || echo "latest")
        sed -i.bak "s|CIS_TRACKER_IMAGE=.*|CIS_TRACKER_IMAGE=${tracker_img}:${tracker_ver}|" "$output_file"
        
        local mysql_img=$(jq -r '.services."mysql".image' "$versions_file" 2>/dev/null || echo "mysql")
        local mysql_ver=$(jq -r '.services."mysql".version' "$versions_file" 2>/dev/null || echo "8.0")
        sed -i.bak "s|MYSQL_IMAGE=.*|MYSQL_IMAGE=${mysql_img}:${mysql_ver}|" "$output_file"

        local worker_img=$(jq -r '.services."cis-worker".image' "$versions_file" 2>/dev/null || echo "docker.io/bitoai/cis-worker")
        local worker_ver=$(jq -r '.services."cis-worker".version' "$versions_file" 2>/dev/null || echo "latest")
        sed -i.bak "s|CIS_WORKER_IMAGE=.*|CIS_WORKER_IMAGE=${worker_img}:${worker_ver}|" "$output_file"

        local temporal_img=$(jq -r '.services."temporal".image' "$versions_file" 2>/dev/null || echo "temporalio/auto-setup")
        local temporal_ver=$(jq -r '.services."temporal".version' "$versions_file" 2>/dev/null || echo "1.29.1")
        sed -i.bak "s|TEMPORAL_IMAGE=.*|TEMPORAL_IMAGE=${temporal_img}:${temporal_ver}|" "$output_file"
    fi

    detect_resource_caps ${output_file}

    rm -f "${output_file}.bak"
    chmod 600 "$output_file"
    
    # Surface "Environment file generated" only when the user just made an
    # explicit config choice (custom LLM prompts ran). When the caller used
    # Bito's LLM keys automatically (check_indexing_enabled = true), there
    # was nothing to acknowledge -- the line is noise, log-only.
    if [[ "${CUSTOM_LLM_CONFIGURED:-}" == "true" ]]; then
        echo "✓ Environment file generated"
    fi
    log_silent "Environment file generated at: $output_file"
    return 0
}

# Simplified function for standalone use (auto-generates everything)
generate_env_file() {
    local output_file="${1:-.env-bitoarch}"
    
    [ ! -f "$ENV_EXAMPLE" ] && echo "Error: $ENV_EXAMPLE not found" && return 1
    
    # Auto-generate all secrets
    local DB_ROOT_PASS=$(generate_secret)
    local DB_USER_PASS=$(generate_secret)
    local JWT_SECRET=$(generate_secret)
    local BITO_API_KEY=$(generate_secret)
    local CIS_MANAGER_API_KEY=$(generate_secret)
    local CIS_CONFIG_API_KEY=$(generate_secret)
    local CIS_PROVIDER_API_KEY=$(generate_secret)
    local BITO_MCP_ACCESS_TOKEN=$(generate_secret)
    local SECRETS_ENCRYPTION_KEY=$(generate_encryption_key)
    
    # Load complete image paths from service-versions.json
    local CIS_CONFIG_IMAGE="docker.io/bitoai/cis-config:latest"
    local CIS_MANAGER_IMAGE="docker.io/bitoai/cis-manager:latest"
    local CIS_PROVIDER_IMAGE="docker.io/bitoai/xmcp:latest"
    local CIS_TRACKER_IMAGE="docker.io/bitoai/cis-tracking:latest"
    local MYSQL_IMAGE="mysql:8.0"
    local CIS_WORKER_IMAGE="docker.io/bitoai/cis-worker:latest"
    local TEMPORAL_IMAGE="temporalio/auto-setup:1.29.1"
    
    local versions_file="${SCRIPT_DIR}/versions/service-versions.json"
    if [ -f "$versions_file" ] && command -v jq >/dev/null 2>&1; then
        # Build complete image paths: registry/org/image:version
        local config_img=$(jq -r '.services."cis-config".image' "$versions_file" 2>/dev/null || echo "docker.io/bitoai/cis-config")
        local config_ver=$(jq -r '.services."cis-config".version' "$versions_file" 2>/dev/null || echo "latest")
        CIS_CONFIG_IMAGE="${config_img}:${config_ver}"
        
        local manager_img=$(jq -r '.services."cis-manager".image' "$versions_file" 2>/dev/null || echo "docker.io/bitoai/cis-manager")
        local manager_ver=$(jq -r '.services."cis-manager".version' "$versions_file" 2>/dev/null || echo "latest")
        CIS_MANAGER_IMAGE="${manager_img}:${manager_ver}"
        
        local provider_img=$(jq -r '.services."cis-provider".image' "$versions_file" 2>/dev/null || echo "docker.io/bitoai/xmcp")
        local provider_ver=$(jq -r '.services."cis-provider".version' "$versions_file" 2>/dev/null || echo "latest")
        CIS_PROVIDER_IMAGE="${provider_img}:${provider_ver}"
        
        local tracker_img=$(jq -r '.services."cis-tracker".image' "$versions_file" 2>/dev/null || echo "docker.io/bitoai/cis-tracking")
        local tracker_ver=$(jq -r '.services."cis-tracker".version' "$versions_file" 2>/dev/null || echo "latest")
        CIS_TRACKER_IMAGE="${tracker_img}:${tracker_ver}"
        
        local mysql_img=$(jq -r '.services."mysql".image' "$versions_file" 2>/dev/null || echo "mysql")
        local mysql_ver=$(jq -r '.services."mysql".version' "$versions_file" 2>/dev/null || echo "8.0")
        MYSQL_IMAGE="${mysql_img}:${mysql_ver}"

        local worker_img=$(jq -r '.services."cis-worker".image' "$versions_file" 2>/dev/null || echo "docker.io/bitoai/cis-worker")
        local worker_ver=$(jq -r '.services."cis-worker".version' "$versions_file" 2>/dev/null || echo "latest")
        CIS_WORKER_IMAGE="${worker_img}:${worker_ver}"

        local temporal_img=$(jq -r '.services."temporal".image' "$versions_file" 2>/dev/null || echo "temporalio/auto-setup")
        local temporal_ver=$(jq -r '.services."temporal".version' "$versions_file" 2>/dev/null || echo "1.29.1")
        TEMPORAL_IMAGE="${temporal_img}:${temporal_ver}"
    fi
    
    # Call shared function
    generate_env_with_params "$output_file" \
        "$BITO_API_KEY" "$DB_ROOT_PASS" "$DB_USER_PASS" "$JWT_SECRET" \
        "$CIS_MANAGER_API_KEY" "$CIS_CONFIG_API_KEY" "$CIS_PROVIDER_API_KEY" \
        "$BITO_MCP_ACCESS_TOKEN" "$SECRETS_ENCRYPTION_KEY" \
        "$CIS_CONFIG_VERSION" "$CIS_MANAGER_VERSION" "$CIS_PROVIDER_VERSION"
    
    return $?
}

# Main
if [ "${BASH_SOURCE[0]}" == "${0}" ]; then
    generate_env_file "${1:-.env-bitoarch-test}"
fi
