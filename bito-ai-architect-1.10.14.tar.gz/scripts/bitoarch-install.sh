#!/bin/bash
#
# Copyright (c) 2023-2025 Bito Inc.
# All rights reserved.
#
# This source code is proprietary and confidential to Bito Inc.
# Unauthorized copying, modification, distribution, or use is strictly prohibited.
#
# For licensing information, see the COPYRIGHT file in the root directory.
#
# @company Bito Inc.
# @website https://bito.ai
#
# scripts/bitoarch-install.sh
# -----------------------------------------------------------------------------
# PRODUCTION edition install bootstrap.
#
# Two modes, auto-detected:
#
#   LOCAL mode
#     Run from inside an already-extracted tarball. scripts/lib/install.sh and
#     docker-compose.yml are present alongside. Action: install from current
#     dir (no download, no extract).
#
#   CDN mode
#     Fetched via `curl | bash`. Action: download the production tarball from
#     UPGRADE_DOWNLOAD_URL, extract to ~/bito-ai-architect, then install.
#
# Install flow:
#   install_run() in scripts/lib/install.sh sources setup.sh and calls its
#   main(). The production install path is entirely driven by setup.sh; this
#   bootstrap exists only to handle the curl|bash / tarball-extraction step.
#
# CDN URL (CDN mode only):
#   Defaults to the production CDN; UPGRADE_DOWNLOAD_URL overrides it. The
#   staging pipeline rewrites the default when publishing at that origin.
#
# Distribution:
#   Hosted at CDN AND shipped in the production tarball (same file serves
#   both modes). Standalone has a sibling bootstrap at
#   scripts/bitoarch-install-standalone.sh hosted on a separate CDN URL.
#
# -----------------------------------------------------------------------------
# INTENTIONAL DUPLICATION with scripts/bitoarch-install-standalone.sh
# -----------------------------------------------------------------------------
#   This file and scripts/bitoarch-install-standalone.sh are siblings served
#   from TWO separate CDN URLs (production vs standalone). Each must be FULLY
#   SELF-CONTAINED because it is the `curl | bash` target -- it runs before
#   any tarball has been downloaded, so it cannot `source` any other file.
#
#   MUST STAY DIVERGENT (edition-specific):
#     - Header comment block (edition docs)
#     - TARBALL_FILENAME / TARBALL_URL / TEMP_DIR / EDITION constants
#     - show_help() body (edition UX)
#
#   MUST STAY IDENTICAL (keep in lockstep when editing either file):
#     - _bootstrap_die, parse_args, bootstrap_check_prerequisites,
#       bootstrap_download, _bootstrap_publisher_key, _bootstrap_sha256,
#       _bootstrap_fetch, _bootstrap_verify, bootstrap_extract,
#       bootstrap_handoff_to_install_run, cleanup, main
#
#   Any edit to a shared function here MUST also land in the sibling file
#   (and vice versa). A future packaging-time concatenation pass could remove
#   the duplication by sourcing a lib file into both bootstraps at publish
#   time, but today the manual lockstep is the cost of curl|bash.
# -----------------------------------------------------------------------------

set -e

# Buffer the whole script so bash doesn't re-read fd 0 after exec 0</dev/tty.
{

# -----------------------------------------------------------------------------
# Configuration (env-var driven; see header)
# -----------------------------------------------------------------------------
# Defaults to the production CDN so a curl|bash install needs no env setup.
# No colon in the expansion: an explicitly empty UPGRADE_DOWNLOAD_URL must
# still reach the CDN-mode guard instead of silently falling back to the
# public origin, which a mirrored or air-gapped install must never do.
# The staging pipeline rewrites this whole line (and VERSION) at publish time.
DOWNLOAD_BASE_URL="${UPGRADE_DOWNLOAD_URL-https://aiarch.bito.ai}"
VERSION="latest"
TARBALL_FILENAME="bito-ai-architect-${VERSION}.tar.gz"
TARBALL_URL="${DOWNLOAD_BASE_URL}/${VERSION}/${TARBALL_FILENAME}"
TEMP_DIR="/tmp/bito-install-$$"
EDITION="production"
# Side-car fetches: seconds per attempt, which also caps the whole retry window,
# and how many times a transient failure is retried.
SIDECAR_FETCH_TIMEOUT=60
SIDECAR_FETCH_RETRIES=2
CURLE_FILE_COULDNT_READ_FILE=37   # curl's exit for a file:// URL that does not exist

# Resolve our own on-disk location (through any symlinks)
_SCRIPT_SELF="${BASH_SOURCE[0]}"
while [[ -L "$_SCRIPT_SELF" ]]; do
    _SCRIPT_SELF="$(readlink "$_SCRIPT_SELF")"
done
SCRIPT_OWN_DIR="$(cd "$(dirname "$_SCRIPT_SELF")" && pwd)"
TARBALL_ROOT_CANDIDATE="$(cd "${SCRIPT_OWN_DIR}/.." && pwd)"

# Auto-detect mode
if [[ -f "${TARBALL_ROOT_CANDIDATE}/scripts/lib/install.sh" ]] \
   && [[ -f "${TARBALL_ROOT_CANDIDATE}/docker-compose.yml" ]]; then
    INSTALL_MODE="local"
    INSTALL_DIR="$TARBALL_ROOT_CANDIDATE"
else
    INSTALL_MODE="cdn"
    INSTALL_DIR="${HOME}/bito-ai-architect"
fi

# -----------------------------------------------------------------------------
# Minimal bootstrap-only error helper. User-visible install output is produced
# by setup.sh via cli-core's print_* (sourced during install_run), so we don't
# introduce any new decoration here.
# -----------------------------------------------------------------------------
_bootstrap_die() { echo "ERROR: $*" >&2; exit 1; }

# -----------------------------------------------------------------------------
# Help
# -----------------------------------------------------------------------------
show_help() {
    cat <<EOF
Bito AI Architect -- Install (Production edition)

USAGE:
  ./scripts/bitoarch-install.sh [--auto] [--help]

MODES:
  INTERACTIVE (default)   Prompts for any required values.
  AUTO / NON-INTERACTIVE  (AUTO_SETUP=true or --auto) No prompts.

OPTIONS:
  --auto, --non-interactive   Same as AUTO_SETUP=true
  --help, -h                  Show this help

ENV VARS:
  AUTO_SETUP=true             Non-interactive mode
  UPGRADE_DOWNLOAD_URL=<url>  Install CDN base URL (CDN mode only)
EOF
}

# -----------------------------------------------------------------------------
# Parse args (--help, --auto). Unknown args forwarded to install_run.
# -----------------------------------------------------------------------------
parse_args() {
    INSTALL_EXTRA_ARGS=()
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --help|-h)                  show_help; exit 0 ;;
            --auto|--non-interactive)   export AUTO_SETUP=true; shift ;;
            *)                          INSTALL_EXTRA_ARGS+=("$1"); shift ;;
        esac
    done
}

# -----------------------------------------------------------------------------
# CDN-only prerequisites (URL set, curl+tar present). Docker-running check is
# done by setup.sh's check_prerequisites, so we don't duplicate it here.
# gpg is needed only for a signed release. Without it, a signed release is
# refused here -- before the download, not after it -- and an unsigned one
# carries on without a word.
# -----------------------------------------------------------------------------
bootstrap_check_prerequisites() {
    if [[ "$INSTALL_MODE" = "cdn" ]]; then
        if [[ -z "$DOWNLOAD_BASE_URL" ]]; then
            _bootstrap_die "UPGRADE_DOWNLOAD_URL is not set (required in CDN mode)."
        fi
        local missing=()
        for tool in curl tar; do
            command -v "$tool" >/dev/null 2>&1 || missing+=("$tool")
        done
        if [[ ${#missing[@]} -gt 0 ]]; then
            _bootstrap_die "Missing required tools: ${missing[*]}"
        fi
        if ! command -v gpg >/dev/null 2>&1 \
           && curl -sfI -m 30 "${TARBALL_URL}.asc" >/dev/null 2>&1; then
            _bootstrap_die "This release is signed but gpg is not installed. Install gnupg and re-run."
        fi
    fi
}

# -----------------------------------------------------------------------------
# CDN mode: download tarball
# -----------------------------------------------------------------------------
bootstrap_download() {
    mkdir -p "$TEMP_DIR"
    local tarball_url="$TARBALL_URL"
    local tarball_path="${TEMP_DIR}/${TARBALL_FILENAME}"

    if ! curl -# -L -f -o "$tarball_path" "$tarball_url"; then
        _bootstrap_die "Download failed: ${tarball_url}"
    fi
    [[ -s "$tarball_path" ]] || _bootstrap_die "Downloaded file is empty"
    _bootstrap_verify "$tarball_path" "$tarball_url"
    echo "$tarball_path"
}

# -----------------------------------------------------------------------------
# CDN mode: verify the tarball against its published detached signature
# -----------------------------------------------------------------------------
# The publisher key is embedded rather than read from share/keys/ because that
# file only exists once the tarball is extracted -- a key taken from the archive
# being verified proves nothing. Keep it byte-identical to
# share/keys/bitoco-publisher.asc; tests/standalone/test-artifact-signing.sh
# fails if the two drift apart.
#
# BITOARCH_REQUIRE_SIGNED_ARTIFACTS=1 turns a missing signature into a failure.
# It defaults to off while releases without a published signature are still
# installable.
_bootstrap_publisher_key() {
    cat <<'BITOARCH_PUBLISHER_KEY_EOF'
-----BEGIN PGP PUBLIC KEY BLOCK-----

mQINBGo9KDYBEAC44BspSFDfVG0lINTxRZ1JiAi/dmxhVVe5LzuPZYq6FGtGOP/k
lmWoMZNLw73zJAn9W1qDobipSAXI/gHCpEdgkH+m9Craez3mnV3Id0K08WpK/ZqT
63x9+TpJ/a4UAq+6+fqOCnBb8XS6gW0az9AJx8Lq46r9H3F+kSQf4hFcfYtjSR61
R7RlRvUzf1Lo/qcDg2vFeDsg6ciPtlwSccjP66Hj8I0APXYSe8r7vQBRBrYuEGiu
BIj9Fo2v7f94/6Jc0dHLoesQl/Fk3tDX7J2NDxOXCpJm+zsdIspFZPwnHNCP+8FT
VOE1fam9xZp68qjg4ygALqqVpUTe5icAUsLmyHlo7nqXgAszzii6h5iWbIKM2/kr
Jls6gSrUxPHTtXIZIWoeU5Cev7sDx/RaxDMiGUGNnrYFRJ7yqxdQ3MM59UOxsUi1
Txdjvh/EZkWZWK0+DUuyYLJ0Lqmxz3gangZx2eAXqPQLKo7LH3NoZ7uglMcajbd0
0VukDvoFyuDYO2uLLAzzG8yFmKqP9QGR0vbS8xcqRDSebe1ehD77gg9XPcSPIB5F
DmJo5QQzb+7IxIIWuYjvxl05UqbP829v8O8H1YVZS5wuQVbdrGwq2RNgZK9RdcFC
UNOfi47XdrLyA1Dxrhd+D2kXIb7NQOgLgQ3OCmL45hrk9nWsoawAfGMWWQARAQAB
tClCaXRvIFBsdWdpbiBQdWJsaXNoZXIgPHB1Ymxpc2hlckBiaXRvLmFpPokCVAQT
AQoAPhYhBBR4zMF9p+LdIdSEYL6taogfhmOhBQJqPSg2AhsDBQkDwmcABQsJCAcC
BhUKCQgLAgQWAgMBAh4BAheAAAoJEL6taogfhmOhB5kQAKOX3MX6StBniJ1wkc+4
c+tuqHV9Vv2V4sSAl5shJzFFau8raznpzTd0A9ItR+YJsa4Vx4vJnXPmnnQ2CMtt
KrsiCNJxYe6Pkim595G0vZFNCSTH0gQ78nHyzKo4GKAopGBbvVdxFSMmxCIsm6uI
9tNP40+dNpbRYXclyZ6HiUflQjH0c2iVpqBvpqLyrKgd4GLa7+csvCuAA1JPXr40
j5BICqcpUSE1n4VFno45f8C28/rnMD72SB8yG/nwPWxwwNMJiT47KGIPFFZJ5HK0
gYJGgUzNdge/iKCYcgR0K+/cgFeUpSeILSLih04qtGjEZ3JUtKzp4vCh7eRREoKE
I+R724scrcubPdEcSrFCcBJoWk4AhtewJXTEu4DXdXCAJYudZKLpTZbDubMYIpQ8
vRVRB4k2hqNimsmv8R8OSSNlW8HFTPqTOIEhdLD0yUWiKU7a4i9a1RGuihd0ETuW
CsBecpeCMUPCnQZ1m0+Kr+caXJMisrEj7S6u38L8XA1wNWRwbfhh8zd2oQsyVinB
soO/tmwHQ8C5Dd0PKt0qW130LnEFjNB6UKXYNJg9tR0uWrz0hSCUuSAe8biszysm
TSlz4TkeoluZ5haLaBCutz+d3Wd1JKHmYONI4SV50zWOMSqsZ/k2CjwpwS2YKTQE
tQjpbovlhg0Rxp3Sn+D4w9GB
=YsHi
-----END PGP PUBLIC KEY BLOCK-----
BITOARCH_PUBLISHER_KEY_EOF
}

_bootstrap_sha256() {
    if command -v sha256sum >/dev/null 2>&1; then sha256sum "$1" 2>/dev/null | awk '{print $1}'
    elif command -v shasum >/dev/null 2>&1; then shasum -a 256 "$1" 2>/dev/null | awk '{print $1}'
    else return 1; fi
}

# Fetch a side-car: rc 0 fetched, 1 not published, 2 could not fetch. The CDN
# answers 403/404 for a key that does not exist, as a missing file:// URL answers
# CURLE_FILE_COULDNT_READ_FILE; anything else -- a timeout, a reset, a 5xx -- is
# not "not published", and reading it as such would let one blip skip the check.
_bootstrap_fetch() {   # <url> <dest>
    local code rc=0
    code="$(curl -sfL -m "$SIDECAR_FETCH_TIMEOUT" --retry "$SIDECAR_FETCH_RETRIES" \
        --retry-max-time "$SIDECAR_FETCH_TIMEOUT" -o "$2" -w '%{http_code}' "$1" 2>/dev/null)" || rc=$?
    [[ $rc -eq 0 ]] && return 0
    rm -f "$2" 2>/dev/null
    [[ $code == 403 || $code == 404 || $rc -eq $CURLE_FILE_COULDNT_READ_FILE ]] && return 1
    return 2
}

_bootstrap_verify() {
    local tarball="$1" url="$2" asc="${1}.asc" sum="${1}.sha256" key="${TEMP_DIR}/publisher.asc" home rc
    local required=0 expected actual got
    case "${BITOARCH_REQUIRE_SIGNED_ARTIFACTS:-0}" in 1|true|TRUE|yes|YES) required=1 ;; esac

    # Published digest ("<hex>  <filename>"): catches a truncated or corrupted
    # download. It lives in the same bucket as the tarball, so it is not a
    # defence against a tampered CDN -- the signature below is.
    got=0; _bootstrap_fetch "${url}.sha256" "$sum" || got=$?
    [[ $got -ne 2 ]] || _bootstrap_die "Could not fetch the published digest for ${url}. Refusing to install."
    if [[ $got -eq 0 ]]; then
        expected="$(awk 'NR==1{print $1}' "$sum" 2>/dev/null)"
        rm -f "$sum" 2>/dev/null
        actual="$(_bootstrap_sha256 "$tarball")"
        [[ -n "$expected" ]] || _bootstrap_die "The published digest for ${url} is unreadable."
        [[ -n "$actual" ]]   || _bootstrap_die "No sha256sum/shasum available to check ${url}."
        [[ "$expected" == "$actual" ]] \
            || _bootstrap_die "SHA-256 mismatch for ${url} (expected ${expected}, got ${actual}). Refusing to install."
    fi

    got=0; _bootstrap_fetch "${url}.asc" "$asc" || got=$?
    [[ $got -ne 2 ]] || _bootstrap_die "Could not fetch the signature for ${url}. Refusing to install."
    if [[ $got -eq 1 ]]; then
        if [[ $required -eq 1 ]]; then
            _bootstrap_die "No published signature for ${url} and signed artifacts are required."
        fi
        return 0
    fi

    if ! command -v gpg >/dev/null 2>&1; then
        rm -f "$asc" 2>/dev/null
        _bootstrap_die "This release is signed but gpg is not installed. Install gnupg and re-run."
    fi

    _bootstrap_publisher_key > "$key"
    # A throwaway keyring, so only the publisher key can vouch for the tarball.
    # Unguarded, a failed mktemp hands gpg an empty --homedir.
    if ! home="$(mktemp -d)" || [[ -z "$home" ]]; then
        rm -f "$asc" "$key" 2>/dev/null
        _bootstrap_die "Could not create a keyring to verify ${url}. Refusing to install."
    fi
    if ! gpg --homedir "$home" --batch --quiet --import "$key" 2>/dev/null; then
        rc=2
    elif gpg --homedir "$home" --batch --quiet --verify "$asc" "$tarball" 2>/dev/null; then
        rc=0
    else
        rc=1
    fi
    rm -rf "$home" 2>/dev/null; rm -f "$asc" "$key" 2>/dev/null
    # A key that will not load is a packaging fault, not a tampered tarball --
    # reporting it as a failed signature would send the operator after the wrong one.
    if [[ $rc -eq 2 ]]; then
        _bootstrap_die "The publisher key embedded in this installer could not be loaded. Refusing to install."
    fi
    [[ $rc -eq 0 ]] || _bootstrap_die "Signature verification FAILED for ${url}. Refusing to install."
}

# -----------------------------------------------------------------------------
# CDN mode: extract tarball (idempotent; replaces existing install dir)
# -----------------------------------------------------------------------------
bootstrap_extract() {
    local tarball_path="$1"
    mkdir -p "$INSTALL_DIR"
    # On extract failure, keep the dir only if the canonical tarball marker
    # (scripts/lib/install.sh) exists -- that lets a retry proceed.
    if ! tar -xzf "$tarball_path" -C "$INSTALL_DIR" --strip-components=1; then
        [[ -f "${INSTALL_DIR}/scripts/lib/install.sh" ]] || rm -rf "$INSTALL_DIR"
        _bootstrap_die "Extraction failed"
    fi
    if [[ ! -f "${INSTALL_DIR}/scripts/lib/install.sh" ]]; then
        _bootstrap_die "Invalid package (missing scripts/lib/install.sh)"
    fi
    find "${INSTALL_DIR}/scripts" -name "*.sh" -type f -exec chmod +x {} \; 2>/dev/null || true
    # Both `bitoarch` CLI and `setup.sh` ship in both tarballs; chmod both
    # unconditionally so this function stays identical across siblings.
    # Both files already ship with the exec bit set, so a chmod failure must
    # warn, never abort the install (these scripts run under `set -e`).
    [[ -f "${INSTALL_DIR}/bitoarch" ]] && { chmod +x "${INSTALL_DIR}/bitoarch" || echo "WARN: could not chmod +x ${INSTALL_DIR}/bitoarch" >&2; }
    [[ -f "${INSTALL_DIR}/setup.sh" ]] && { chmod +x "${INSTALL_DIR}/setup.sh" || echo "WARN: could not chmod +x ${INSTALL_DIR}/setup.sh" >&2; }
    true
}

# -----------------------------------------------------------------------------
# Handoff: set SCRIPT_DIR/PLATFORM_DIR (prod convention), source the install
# library, call install_run (which delegates to setup.sh::main).
#
# set +e is required because install_run sources adapter files that do
# `source <optional> || true`, and bash's source builtin interacts badly with
# set -e on missing files. setup.sh::main has explicit error handling where
# termination matters.
# -----------------------------------------------------------------------------
bootstrap_handoff_to_install_run() {
    cd "$INSTALL_DIR" || exit 1

    # Reconnect stdin to the terminal so interactive prompts work when the
    # script is piped through curl|bash.
    if [[ ! -t 0 ]]; then
        [ -r /dev/tty ] || _bootstrap_die "Interactive prompts require /dev/tty. Re-run as: curl -fsSL <url> -o install.sh && bash install.sh"
        exec 0</dev/tty
    fi

    export SCRIPT_DIR="${INSTALL_DIR}"
    export PLATFORM_DIR="${INSTALL_DIR}"

    set +e
    # shellcheck disable=SC1091
    source "${SCRIPT_DIR}/scripts/setup-utils.sh"
    # shellcheck disable=SC1091
    source "${SCRIPT_DIR}/scripts/lib/cli-core.sh"
    # shellcheck disable=SC1091
    source "${SCRIPT_DIR}/scripts/lib/path-manager.sh"
    # shellcheck disable=SC1091
    source "${SCRIPT_DIR}/scripts/lib/install.sh"

    install_run "$@"
}

# -----------------------------------------------------------------------------
# Cleanup + trap
# -----------------------------------------------------------------------------
cleanup() {
    local rc=$?
    [[ -d "$TEMP_DIR" ]] && rm -rf "$TEMP_DIR"
    # Guarantee a closing on any non-zero exit that did not already print one (never a silent exit).
    if [ "$rc" -ne 0 ] && [ -z "${_BITOARCH_INSTALL_CLOSED:-}" ]; then
        if type render_install_incomplete_block >/dev/null 2>&1; then
            render_install_incomplete_block >&2
        else
            printf '\n\033[0;31m✗ Setup did not finish.\033[0m Re-run to resume: bitoarch start (logs: bitoarch logs)\n\n' >&2
        fi
    fi
    return 0   # Don't let a missing TEMP_DIR (e.g. after --help) flip exit code
}
trap cleanup EXIT

# -----------------------------------------------------------------------------
# Main
# -----------------------------------------------------------------------------
main() {
    parse_args "$@"
    bootstrap_check_prerequisites

    if [[ "$INSTALL_MODE" = "cdn" ]]; then
        local tarball_path
        tarball_path=$(bootstrap_download)
        bootstrap_extract "$tarball_path"
    fi

    bootstrap_handoff_to_install_run "${INSTALL_EXTRA_ARGS[@]}"
}

main "$@"
exit "$?"

} # end script buffer
